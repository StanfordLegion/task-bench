package x10.glb;

/**
 * <p>Class that collects lifeline statistics of GLB
 * </p>
 */
@x10.runtime.impl.java.X10Generated
final public class Logger extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Logger> $RTT = 
        x10.rtt.NamedType.<Logger> make("x10.glb.Logger",
                                        Logger.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Logger $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.lastStartStopLiveTimeStamp = $deserializer.readLong();
        $_obj.lifelineNodesReceived = $deserializer.readLong();
        $_obj.lifelineStealsAttempted = $deserializer.readLong();
        $_obj.lifelineStealsPerpetrated = $deserializer.readLong();
        $_obj.lifelineStealsReceived = $deserializer.readLong();
        $_obj.lifelineStealsSuffered = $deserializer.readLong();
        $_obj.nodesCount = $deserializer.readLong();
        $_obj.nodesGiven = $deserializer.readLong();
        $_obj.nodesReceived = $deserializer.readLong();
        $_obj.startTime = $deserializer.readLong();
        $_obj.stealsAttempted = $deserializer.readLong();
        $_obj.stealsPerpetrated = $deserializer.readLong();
        $_obj.stealsReceived = $deserializer.readLong();
        $_obj.stealsSuffered = $deserializer.readLong();
        $_obj.timeAlive = $deserializer.readLong();
        $_obj.timeDead = $deserializer.readLong();
        $_obj.timeReference = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.glb.Logger $_obj = new x10.glb.Logger((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.lastStartStopLiveTimeStamp);
        $serializer.write(this.lifelineNodesReceived);
        $serializer.write(this.lifelineStealsAttempted);
        $serializer.write(this.lifelineStealsPerpetrated);
        $serializer.write(this.lifelineStealsReceived);
        $serializer.write(this.lifelineStealsSuffered);
        $serializer.write(this.nodesCount);
        $serializer.write(this.nodesGiven);
        $serializer.write(this.nodesReceived);
        $serializer.write(this.startTime);
        $serializer.write(this.stealsAttempted);
        $serializer.write(this.stealsPerpetrated);
        $serializer.write(this.stealsReceived);
        $serializer.write(this.stealsSuffered);
        $serializer.write(this.timeAlive);
        $serializer.write(this.timeDead);
        $serializer.write(this.timeReference);
        
    }
    
    // constructor just for allocation
    public Logger(final java.lang.System[] $dummy) {
        
    }
    
    

    
    //#line 21 "x10/glb/Logger.x10"
    public long nodesCount;
    
    //#line 22 "x10/glb/Logger.x10"
    public long nodesGiven;
    
    //#line 23 "x10/glb/Logger.x10"
    public long lifelineNodesReceived;
    
    //#line 26 "x10/glb/Logger.x10"
    public long stealsAttempted;
    
    //#line 27 "x10/glb/Logger.x10"
    public long stealsPerpetrated;
    
    //#line 28 "x10/glb/Logger.x10"
    public long stealsReceived;
    
    //#line 29 "x10/glb/Logger.x10"
    public long stealsSuffered;
    
    //#line 30 "x10/glb/Logger.x10"
    public long nodesReceived;
    
    //#line 33 "x10/glb/Logger.x10"
    public long lifelineStealsAttempted;
    
    //#line 34 "x10/glb/Logger.x10"
    public long lifelineStealsPerpetrated;
    
    //#line 35 "x10/glb/Logger.x10"
    public long lifelineStealsReceived;
    
    //#line 36 "x10/glb/Logger.x10"
    public long lifelineStealsSuffered;
    
    //#line 40 "x10/glb/Logger.x10"
    public long lastStartStopLiveTimeStamp;
    
    //#line 41 "x10/glb/Logger.x10"
    public long timeAlive;
    
    //#line 42 "x10/glb/Logger.x10"
    public long timeDead;
    
    //#line 43 "x10/glb/Logger.x10"
    public long startTime;
    
    //#line 44 "x10/glb/Logger.x10"
    public long timeReference;
    
    
    //#line 52 "x10/glb/Logger.x10"
    /**
     * Constructor
     * @param b true, called when prior-calculation; false, called when post-calculation
     */
    // creation method for java code (1-phase java constructor)
    public Logger(final boolean b) {
        this((java.lang.System[]) null);
        x10$glb$Logger$$init$S(b);
    }
    
    // constructor for non-virtual call
    final public x10.glb.Logger x10$glb$Logger$$init$S(final boolean b) {
         {
            
            //#line 52 "x10/glb/Logger.x10"
            
            
            //#line 18 "x10/glb/Logger.x10"
            this.__fieldInitializers_x10_glb_Logger();
            
            //#line 53 "x10/glb/Logger.x10"
            if (b) {
                
                //#line 53 "x10/glb/Logger.x10"
                final x10.util.Team t$127752 = ((x10.util.Team)(x10.util.Team.get$WORLD()));
                
                //#line 53 "x10/glb/Logger.x10"
                t$127752.barrier();
            }
            
            //#line 40 . "x10/lang/System.x10"
            final long t$127753 = java.lang.System.nanoTime();
            
            //#line 54 "x10/glb/Logger.x10"
            this.timeReference = t$127753;
        }
        return this;
    }
    
    
    
    //#line 61 "x10/glb/Logger.x10"
    /**
     * Timer is started before processing, which includes calculation, distribution and requesting/rejects tasks
     */
    public void startLive() {
        
        //#line 62 "x10/glb/Logger.x10"
        final long time = java.lang.System.nanoTime();
        
        //#line 63 "x10/glb/Logger.x10"
        final long t$127754 = this.startTime;
        
        //#line 63 "x10/glb/Logger.x10"
        final boolean t$127755 = ((long) t$127754) == ((long) 0L);
        
        //#line 63 "x10/glb/Logger.x10"
        if (t$127755) {
            
            //#line 63 "x10/glb/Logger.x10"
            this.startTime = time;
        }
        
        //#line 64 "x10/glb/Logger.x10"
        final long t$127756 = this.lastStartStopLiveTimeStamp;
        
        //#line 64 "x10/glb/Logger.x10"
        final boolean t$127761 = ((t$127756) >= (((long)(0L))));
        
        //#line 64 "x10/glb/Logger.x10"
        if (t$127761) {
            
            //#line 65 "x10/glb/Logger.x10"
            final long t$127758 = this.timeDead;
            
            //#line 65 "x10/glb/Logger.x10"
            final long t$127757 = this.lastStartStopLiveTimeStamp;
            
            //#line 65 "x10/glb/Logger.x10"
            final long t$127759 = ((time) - (((long)(t$127757))));
            
            //#line 65 "x10/glb/Logger.x10"
            final long t$127760 = ((t$127758) + (((long)(t$127759))));
            
            //#line 65 "x10/glb/Logger.x10"
            this.timeDead = t$127760;
        }
        
        //#line 67 "x10/glb/Logger.x10"
        this.lastStartStopLiveTimeStamp = time;
    }
    
    
    //#line 73 "x10/glb/Logger.x10"
    /**
     * Timer is stopped when running out of tasks and failing to steal any task
     */
    public void stopLive() {
        
        //#line 74 "x10/glb/Logger.x10"
        final long time = java.lang.System.nanoTime();
        
        //#line 75 "x10/glb/Logger.x10"
        final long t$127763 = this.timeAlive;
        
        //#line 75 "x10/glb/Logger.x10"
        final long t$127762 = this.lastStartStopLiveTimeStamp;
        
        //#line 75 "x10/glb/Logger.x10"
        final long t$127764 = ((time) - (((long)(t$127762))));
        
        //#line 75 "x10/glb/Logger.x10"
        final long t$127765 = ((t$127763) + (((long)(t$127764))));
        
        //#line 75 "x10/glb/Logger.x10"
        this.timeAlive = t$127765;
        
        //#line 76 "x10/glb/Logger.x10"
        this.lastStartStopLiveTimeStamp = time;
    }
    
    
    //#line 83 "x10/glb/Logger.x10"
    /**
     * Aggregate stats for all places
     * @param logs log from every place
     */
    public void collect__0$1x10$glb$Logger$2(final x10.core.Rail logs) {
        
        //#line 84 "x10/glb/Logger.x10"
        final long size$120687 = ((x10.core.Rail<x10.glb.Logger>)logs).size;
        
        //#line 84 "x10/glb/Logger.x10"
        long idx$127909 = 0L;
        {
            
            //#line 84 "x10/glb/Logger.x10"
            final x10.glb.Logger[] logs$value$127912 = ((x10.glb.Logger[])logs.value);
            
            //#line 84 "x10/glb/Logger.x10"
            for (;
                 true;
                 ) {
                
                //#line 84 "x10/glb/Logger.x10"
                final boolean t$127911 = ((idx$127909) < (((long)(size$120687))));
                
                //#line 84 "x10/glb/Logger.x10"
                if (!(t$127911)) {
                    
                    //#line 84 "x10/glb/Logger.x10"
                    break;
                }
                
                //#line 84 "x10/glb/Logger.x10"
                final x10.glb.Logger l$127906 = ((x10.glb.Logger)(((x10.glb.Logger)logs$value$127912[(int)idx$127909])));
                
                //#line 84 "x10/glb/Logger.x10"
                this.add(((x10.glb.Logger)(l$127906)));
                
                //#line 84 "x10/glb/Logger.x10"
                final long t$127908 = ((idx$127909) + (((long)(1L))));
                
                //#line 84 "x10/glb/Logger.x10"
                idx$127909 = t$127908;
            }
        }
    }
    
    
    //#line 90 "x10/glb/Logger.x10"
    /**
     * Print out the actual workload re-distribution by showing the steals that were carried out.
     */
    public void stats() {
        
        //#line 91 "x10/glb/Logger.x10"
        final x10.io.Printer t$127779 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
        
        //#line 91 "x10/glb/Logger.x10"
        final long t$127772 = this.nodesGiven;
        
        //#line 91 "x10/glb/Logger.x10"
        final java.lang.String t$127773 = (((x10.core.Long.$box(t$127772))) + (" Task items stolen = "));
        
        //#line 91 "x10/glb/Logger.x10"
        final long t$127774 = this.nodesReceived;
        
        //#line 91 "x10/glb/Logger.x10"
        final java.lang.String t$127775 = ((t$127773) + ((x10.core.Long.$box(t$127774))));
        
        //#line 91 "x10/glb/Logger.x10"
        final java.lang.String t$127776 = ((t$127775) + (" (direct) + "));
        
        //#line 92 "x10/glb/Logger.x10"
        final long t$127777 = this.lifelineNodesReceived;
        
        //#line 91 "x10/glb/Logger.x10"
        final java.lang.String t$127778 = ((t$127776) + ((x10.core.Long.$box(t$127777))));
        
        //#line 91 "x10/glb/Logger.x10"
        final java.lang.String t$127780 = ((t$127778) + (" (lifeline)."));
        
        //#line 91 "x10/glb/Logger.x10"
        t$127779.println(((java.lang.Object)(t$127780)));
        
        //#line 93 "x10/glb/Logger.x10"
        final x10.io.Printer t$127782 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
        
        //#line 93 "x10/glb/Logger.x10"
        final long t$127781 = this.stealsPerpetrated;
        
        //#line 93 "x10/glb/Logger.x10"
        final java.lang.String t$127783 = (((x10.core.Long.$box(t$127781))) + (" successful direct steals."));
        
        //#line 93 "x10/glb/Logger.x10"
        t$127782.println(((java.lang.Object)(t$127783)));
        
        //#line 94 "x10/glb/Logger.x10"
        final x10.io.Printer t$127785 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
        
        //#line 94 "x10/glb/Logger.x10"
        final long t$127784 = this.lifelineStealsPerpetrated;
        
        //#line 94 "x10/glb/Logger.x10"
        final java.lang.String t$127786 = (((x10.core.Long.$box(t$127784))) + (" successful lifeline steals."));
        
        //#line 94 "x10/glb/Logger.x10"
        t$127785.println(((java.lang.Object)(t$127786)));
    }
    
    
    //#line 104 "x10/glb/Logger.x10"
    /**
     * Gets part of the string.
     * @param str original string
     * @param start starting index of the string
     * @param end ending index of the string
     * @return string from start to end
     */
    public static java.lang.String sub(final java.lang.String str, final int start, final int end) {
        
        //#line 104 "x10/glb/Logger.x10"
        final int t$127787 = (str).length();
        
        //#line 104 "x10/glb/Logger.x10"
        final int t$127788 = java.lang.Math.min(((int)(end)),((int)(t$127787)));
        
        //#line 104 "x10/glb/Logger.x10"
        final java.lang.String t$127789 = (str).substring(((int)(start)), ((int)(t$127788)));
        
        //#line 104 "x10/glb/Logger.x10"
        return t$127789;
    }
    
    
    //#line 110 "x10/glb/Logger.x10"
    /**
     * Sum up stat with another logger
     * @param other another logger to sum up with
     */
    public void add(final x10.glb.Logger other) {
        
        //#line 111 "x10/glb/Logger.x10"
        final long t$127790 = this.nodesCount;
        
        //#line 111 "x10/glb/Logger.x10"
        final long t$127791 = other.nodesCount;
        
        //#line 111 "x10/glb/Logger.x10"
        final long t$127792 = ((t$127790) + (((long)(t$127791))));
        
        //#line 111 "x10/glb/Logger.x10"
        this.nodesCount = t$127792;
        
        //#line 112 "x10/glb/Logger.x10"
        final long t$127793 = this.nodesGiven;
        
        //#line 112 "x10/glb/Logger.x10"
        final long t$127794 = other.nodesGiven;
        
        //#line 112 "x10/glb/Logger.x10"
        final long t$127795 = ((t$127793) + (((long)(t$127794))));
        
        //#line 112 "x10/glb/Logger.x10"
        this.nodesGiven = t$127795;
        
        //#line 113 "x10/glb/Logger.x10"
        final long t$127796 = this.nodesReceived;
        
        //#line 113 "x10/glb/Logger.x10"
        final long t$127797 = other.nodesReceived;
        
        //#line 113 "x10/glb/Logger.x10"
        final long t$127798 = ((t$127796) + (((long)(t$127797))));
        
        //#line 113 "x10/glb/Logger.x10"
        this.nodesReceived = t$127798;
        
        //#line 114 "x10/glb/Logger.x10"
        final long t$127799 = this.stealsPerpetrated;
        
        //#line 114 "x10/glb/Logger.x10"
        final long t$127800 = other.stealsPerpetrated;
        
        //#line 114 "x10/glb/Logger.x10"
        final long t$127801 = ((t$127799) + (((long)(t$127800))));
        
        //#line 114 "x10/glb/Logger.x10"
        this.stealsPerpetrated = t$127801;
        
        //#line 115 "x10/glb/Logger.x10"
        final long t$127802 = this.lifelineNodesReceived;
        
        //#line 115 "x10/glb/Logger.x10"
        final long t$127803 = other.lifelineNodesReceived;
        
        //#line 115 "x10/glb/Logger.x10"
        final long t$127804 = ((t$127802) + (((long)(t$127803))));
        
        //#line 115 "x10/glb/Logger.x10"
        this.lifelineNodesReceived = t$127804;
        
        //#line 116 "x10/glb/Logger.x10"
        final long t$127805 = this.lifelineStealsPerpetrated;
        
        //#line 116 "x10/glb/Logger.x10"
        final long t$127806 = other.lifelineStealsPerpetrated;
        
        //#line 116 "x10/glb/Logger.x10"
        final long t$127807 = ((t$127805) + (((long)(t$127806))));
        
        //#line 116 "x10/glb/Logger.x10"
        this.lifelineStealsPerpetrated = t$127807;
    }
    
    
    //#line 123 "x10/glb/Logger.x10"
    /**
     * Print out more detailed lifeline stats when verbose flag turned on
     * @param verbose verbose flag true when {@link GLBParameters} show glb flag is on.
     */
    public x10.glb.Logger get(final boolean verbose) {
        
        //#line 124 "x10/glb/Logger.x10"
        if (verbose) {
            
            //#line 125 "x10/glb/Logger.x10"
            final x10.io.Printer t$127903 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
            
            //#line 125 "x10/glb/Logger.x10"
            final long t$127808 = x10.x10rt.X10RT.here().id;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127809 = (("") + ((x10.core.Long.$box(t$127808))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127814 = ((t$127809) + (" -> "));
            
            //#line 126 "x10/glb/Logger.x10"
            final long t$127810 = this.timeAlive;
            
            //#line 126 "x10/glb/Logger.x10"
            final double t$127811 = ((double)(long)(((long)(t$127810))));
            
            //#line 126 "x10/glb/Logger.x10"
            final double t$127812 = ((t$127811) / (((double)(1.0E9))));
            
            //#line 126 "x10/glb/Logger.x10"
            final java.lang.String t$127813 = (("") + ((x10.core.Double.$box(t$127812))));
            
            //#line 126 "x10/glb/Logger.x10"
            final java.lang.String t$127815 = x10.glb.Logger.sub(((java.lang.String)(t$127813)), (int)(0), (int)(6));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127816 = ((t$127814) + (t$127815));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127821 = ((t$127816) + (" : "));
            
            //#line 127 "x10/glb/Logger.x10"
            final long t$127817 = this.timeDead;
            
            //#line 127 "x10/glb/Logger.x10"
            final double t$127818 = ((double)(long)(((long)(t$127817))));
            
            //#line 127 "x10/glb/Logger.x10"
            final double t$127819 = ((t$127818) / (((double)(1.0E9))));
            
            //#line 127 "x10/glb/Logger.x10"
            final java.lang.String t$127820 = (("") + ((x10.core.Double.$box(t$127819))));
            
            //#line 127 "x10/glb/Logger.x10"
            final java.lang.String t$127822 = x10.glb.Logger.sub(((java.lang.String)(t$127820)), (int)(0), (int)(6));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127823 = ((t$127821) + (t$127822));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127830 = ((t$127823) + (" : "));
            
            //#line 128 "x10/glb/Logger.x10"
            final long t$127824 = this.timeAlive;
            
            //#line 128 "x10/glb/Logger.x10"
            final long t$127825 = this.timeDead;
            
            //#line 128 "x10/glb/Logger.x10"
            final long t$127826 = ((t$127824) + (((long)(t$127825))));
            
            //#line 128 "x10/glb/Logger.x10"
            final double t$127827 = ((double)(long)(((long)(t$127826))));
            
            //#line 128 "x10/glb/Logger.x10"
            final double t$127828 = ((t$127827) / (((double)(1.0E9))));
            
            //#line 128 "x10/glb/Logger.x10"
            final java.lang.String t$127829 = (("") + ((x10.core.Double.$box(t$127828))));
            
            //#line 128 "x10/glb/Logger.x10"
            final java.lang.String t$127831 = x10.glb.Logger.sub(((java.lang.String)(t$127829)), (int)(0), (int)(6));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127832 = ((t$127830) + (t$127831));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127842 = ((t$127832) + (" : "));
            
            //#line 129 "x10/glb/Logger.x10"
            final long t$127833 = this.timeAlive;
            
            //#line 129 "x10/glb/Logger.x10"
            final double t$127834 = ((double)(long)(((long)(t$127833))));
            
            //#line 129 "x10/glb/Logger.x10"
            final double t$127838 = ((100.0) * (((double)(t$127834))));
            
            //#line 129 "x10/glb/Logger.x10"
            final long t$127835 = this.timeAlive;
            
            //#line 129 "x10/glb/Logger.x10"
            final long t$127836 = this.timeDead;
            
            //#line 129 "x10/glb/Logger.x10"
            final long t$127837 = ((t$127835) + (((long)(t$127836))));
            
            //#line 129 "x10/glb/Logger.x10"
            final double t$127839 = ((double)(long)(((long)(t$127837))));
            
            //#line 129 "x10/glb/Logger.x10"
            final double t$127840 = ((t$127838) / (((double)(t$127839))));
            
            //#line 129 "x10/glb/Logger.x10"
            final java.lang.String t$127841 = (("") + ((x10.core.Double.$box(t$127840))));
            
            //#line 129 "x10/glb/Logger.x10"
            final java.lang.String t$127843 = x10.glb.Logger.sub(((java.lang.String)(t$127841)), (int)(0), (int)(6));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127844 = ((t$127842) + (t$127843));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127845 = ((t$127844) + ("%"));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127852 = ((t$127845) + (" :: "));
            
            //#line 130 "x10/glb/Logger.x10"
            final long t$127846 = this.startTime;
            
            //#line 130 "x10/glb/Logger.x10"
            final long t$127847 = this.timeReference;
            
            //#line 130 "x10/glb/Logger.x10"
            final long t$127848 = ((t$127846) - (((long)(t$127847))));
            
            //#line 130 "x10/glb/Logger.x10"
            final double t$127849 = ((double)(long)(((long)(t$127848))));
            
            //#line 130 "x10/glb/Logger.x10"
            final double t$127850 = ((t$127849) / (((double)(1.0E9))));
            
            //#line 130 "x10/glb/Logger.x10"
            final java.lang.String t$127851 = (("") + ((x10.core.Double.$box(t$127850))));
            
            //#line 130 "x10/glb/Logger.x10"
            final java.lang.String t$127853 = x10.glb.Logger.sub(((java.lang.String)(t$127851)), (int)(0), (int)(6));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127854 = ((t$127852) + (t$127853));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127861 = ((t$127854) + (" : "));
            
            //#line 131 "x10/glb/Logger.x10"
            final long t$127855 = this.lastStartStopLiveTimeStamp;
            
            //#line 131 "x10/glb/Logger.x10"
            final long t$127856 = this.timeReference;
            
            //#line 131 "x10/glb/Logger.x10"
            final long t$127857 = ((t$127855) - (((long)(t$127856))));
            
            //#line 131 "x10/glb/Logger.x10"
            final double t$127858 = ((double)(long)(((long)(t$127857))));
            
            //#line 131 "x10/glb/Logger.x10"
            final double t$127859 = ((t$127858) / (((double)(1.0E9))));
            
            //#line 131 "x10/glb/Logger.x10"
            final java.lang.String t$127860 = (("") + ((x10.core.Double.$box(t$127859))));
            
            //#line 131 "x10/glb/Logger.x10"
            final java.lang.String t$127862 = x10.glb.Logger.sub(((java.lang.String)(t$127860)), (int)(0), (int)(6));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127863 = ((t$127861) + (t$127862));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127864 = ((t$127863) + (" :: "));
            
            //#line 132 "x10/glb/Logger.x10"
            final long t$127865 = this.nodesCount;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127866 = ((t$127864) + ((x10.core.Long.$box(t$127865))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127867 = ((t$127866) + (" :: "));
            
            //#line 133 "x10/glb/Logger.x10"
            final long t$127868 = this.nodesGiven;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127869 = ((t$127867) + ((x10.core.Long.$box(t$127868))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127870 = ((t$127869) + (" : "));
            
            //#line 134 "x10/glb/Logger.x10"
            final long t$127871 = this.nodesReceived;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127872 = ((t$127870) + ((x10.core.Long.$box(t$127871))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127873 = ((t$127872) + (" : "));
            
            //#line 135 "x10/glb/Logger.x10"
            final long t$127874 = this.lifelineNodesReceived;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127875 = ((t$127873) + ((x10.core.Long.$box(t$127874))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127876 = ((t$127875) + (" :: "));
            
            //#line 136 "x10/glb/Logger.x10"
            final long t$127877 = this.stealsReceived;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127878 = ((t$127876) + ((x10.core.Long.$box(t$127877))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127879 = ((t$127878) + (" : "));
            
            //#line 137 "x10/glb/Logger.x10"
            final long t$127880 = this.lifelineStealsReceived;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127881 = ((t$127879) + ((x10.core.Long.$box(t$127880))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127882 = ((t$127881) + (" :: "));
            
            //#line 138 "x10/glb/Logger.x10"
            final long t$127883 = this.stealsSuffered;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127884 = ((t$127882) + ((x10.core.Long.$box(t$127883))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127885 = ((t$127884) + (" : "));
            
            //#line 139 "x10/glb/Logger.x10"
            final long t$127886 = this.lifelineStealsSuffered;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127887 = ((t$127885) + ((x10.core.Long.$box(t$127886))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127888 = ((t$127887) + (" :: "));
            
            //#line 140 "x10/glb/Logger.x10"
            final long t$127889 = this.stealsAttempted;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127890 = ((t$127888) + ((x10.core.Long.$box(t$127889))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127893 = ((t$127890) + (" : "));
            
            //#line 141 "x10/glb/Logger.x10"
            final long t$127891 = this.stealsAttempted;
            
            //#line 141 "x10/glb/Logger.x10"
            final long t$127892 = this.stealsPerpetrated;
            
            //#line 141 "x10/glb/Logger.x10"
            final long t$127894 = ((t$127891) - (((long)(t$127892))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127895 = ((t$127893) + ((x10.core.Long.$box(t$127894))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127896 = ((t$127895) + (" :: "));
            
            //#line 142 "x10/glb/Logger.x10"
            final long t$127897 = this.lifelineStealsAttempted;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127898 = ((t$127896) + ((x10.core.Long.$box(t$127897))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127901 = ((t$127898) + (" : "));
            
            //#line 143 "x10/glb/Logger.x10"
            final long t$127899 = this.lifelineStealsAttempted;
            
            //#line 143 "x10/glb/Logger.x10"
            final long t$127900 = this.lifelineStealsPerpetrated;
            
            //#line 143 "x10/glb/Logger.x10"
            final long t$127902 = ((t$127899) - (((long)(t$127900))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$127904 = ((t$127901) + ((x10.core.Long.$box(t$127902))));
            
            //#line 125 "x10/glb/Logger.x10"
            t$127903.println(((java.lang.Object)(t$127904)));
        }
        
        //#line 145 "x10/glb/Logger.x10"
        return this;
    }
    
    
    //#line 18 "x10/glb/Logger.x10"
    final public x10.glb.Logger x10$glb$Logger$$this$x10$glb$Logger() {
        
        //#line 18 "x10/glb/Logger.x10"
        return x10.glb.Logger.this;
    }
    
    
    //#line 18 "x10/glb/Logger.x10"
    final public void __fieldInitializers_x10_glb_Logger() {
        
        //#line 18 "x10/glb/Logger.x10"
        this.nodesCount = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.nodesGiven = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.lifelineNodesReceived = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.stealsAttempted = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.stealsPerpetrated = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.stealsReceived = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.stealsSuffered = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.nodesReceived = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.lifelineStealsAttempted = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.lifelineStealsPerpetrated = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.lifelineStealsReceived = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.lifelineStealsSuffered = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.lastStartStopLiveTimeStamp = -1L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.timeAlive = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.timeDead = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.startTime = 0L;
    }
}

