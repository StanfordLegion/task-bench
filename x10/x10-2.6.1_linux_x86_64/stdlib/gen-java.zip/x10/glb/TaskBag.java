package x10.glb;

/**
 * <p>TaskBag interface
 * </p>
 */
@x10.runtime.impl.java.X10Generated
public interface TaskBag extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<TaskBag> $RTT = 
        x10.rtt.NamedType.<TaskBag> make("x10.glb.TaskBag", TaskBag.class);
    
    

    
    
    //#line 21 "x10/glb/TaskBag.x10"
    /**
     * Returns the size of TaskBag
     */
    long size$O();
}

