package x10.glb;


/**
 * The local runner for the GLB framework. An instance of this class runs at each
 * place and provides the context within which user-specified tasks execute and
 * are load balanced across all places.
 * @param <Queue> Concrete TaskQueue type
 * @param <R> Result type.
 */
@x10.runtime.impl.java.X10Generated
final public class Worker<$Queue, $R> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Worker> $RTT = 
        x10.rtt.NamedType.<Worker> make("x10.glb.Worker",
                                        Worker.class,
                                        2);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
        $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
        $_obj.P = $deserializer.readLong();
        $_obj.context = $deserializer.readObject();
        $_obj.lifelineThieves = $deserializer.readObject();
        $_obj.lifelines = $deserializer.readObject();
        $_obj.lifelinesActivated = $deserializer.readObject();
        $_obj.logger = $deserializer.readObject();
        $_obj.m = $deserializer.readInt();
        $_obj.n = $deserializer.readInt();
        $_obj.queue = $deserializer.readObject();
        $_obj.random = $deserializer.readObject();
        $_obj.thieves = $deserializer.readObject();
        $_obj.victims = $deserializer.readObject();
        $_obj.w = $deserializer.readInt();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.glb.Worker $_obj = new x10.glb.Worker((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$Queue);
        $serializer.write(this.$R);
        $serializer.write(this.P);
        $serializer.write(this.context);
        $serializer.write(this.lifelineThieves);
        $serializer.write(this.lifelines);
        $serializer.write(this.lifelinesActivated);
        $serializer.write(this.logger);
        $serializer.write(this.m);
        $serializer.write(this.n);
        $serializer.write(this.queue);
        $serializer.write(this.random);
        $serializer.write(this.thieves);
        $serializer.write(this.victims);
        $serializer.write(this.w);
        
    }
    
    // constructor just for allocation
    public Worker(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
        x10.glb.Worker.$initParams(this, $Queue, $R);
        
    }
    
    private x10.rtt.Type $Queue;
    private x10.rtt.Type $R;
    
    // initializer of type parameters
    public static void $initParams(final Worker $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
        $this.$Queue = $Queue;
        $this.$R = $R;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$glb$Worker$$Queue$2 {}
    

    
    //#line 29 "x10/glb/Worker.x10"
    /** TaskQueue, responsible for crunching numbers */
    public $Queue queue;
    
    //#line 32 "x10/glb/Worker.x10"
    /** Read as I am the "lifeline buddy" of my "lifelineThieves" */
    public x10.glb.FixedSizeStack<x10.core.Long> lifelineThieves;
    
    //#line 36 "x10/glb/Worker.x10"
    /** Thieves that send stealing requests*/
    public x10.glb.FixedSizeStack<x10.core.Long> thieves;
    
    //#line 39 "x10/glb/Worker.x10"
    /** Lifeline buddies */
    public x10.core.Rail<x10.core.Long> lifelines;
    
    //#line 45 "x10/glb/Worker.x10"
    /** The data structure to keep a key invariant: 
     * At any time, at most one message has been sent on an
     * outgoing lifeline (and hence at most one message has
     * been received on an incoming lifeline).*/
    public x10.core.Rail<x10.core.Boolean> lifelinesActivated;
    
    //#line 50 "x10/glb/Worker.x10"
    /** The granularity of tasks to run in a batch before starts to probe network to respond to work-stealing 
     * requests. The smaller n is, the more responsive to the work-stealing requests; on the other hand, less focused
     * on computation */
    public int n;
    
    //#line 53 "x10/glb/Worker.x10"
    /** Number of random victims to probe before sending requests to lifeline buddy*/
    public int w;
    
    //#line 56 "x10/glb/Worker.x10"
    /** Maximum number of random victims */
    public int m;
    
    //#line 60 "x10/glb/Worker.x10"
    /** Random number, used when picking a non-lifeline victim/buddy. Important to seed with place id, otherwise
      BG/Q, the random sequence will be exactly same at different places*/
    public x10.util.Random random;
    
    //#line 64 "x10/glb/Worker.x10"
    /** Random buddies, a runner first probes its random buddy, only when none of the random buddies responds
     *  it starts to probe its lifeline buddies */
    public x10.core.Rail<x10.core.Long> victims;
    
    //#line 67 "x10/glb/Worker.x10"
    /** Logger to record the work-stealing status */
    public x10.glb.Logger logger;
    
    //#line 70 "x10/glb/Worker.x10"
    /** Variables used for synchronization, made sure not to be optimized out by the compiler */
    volatile public transient boolean active;
    
    //#line 71 "x10/glb/Worker.x10"
    volatile public transient boolean empty;
    
    //#line 72 "x10/glb/Worker.x10"
    volatile public transient boolean waiting;
    
    //#line 75 "x10/glb/Worker.x10"
    public long P;
    
    //#line 78 "x10/glb/Worker.x10"
    public x10.glb.Context<$Queue, $R> context;
    
    
    //#line 90 "x10/glb/Worker.x10"
    /**
     * Class constructor
     * @param init function closure to init the local {@link TaskQueue}
     * @param n same to this.n
     * @param w same to this.w
     * @param m same to this.m
     * @param l power of lifeline graph
     * @param z base of lifeline graph
     * @param tree true if the workload is dynamically generated, false if the workload can be statically generated
     */
    // creation method for java code (1-phase java constructor)
    public Worker(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.core.fun.Fun_0_0<$Queue> init, final int n, final int w, final int l, final int z, final int m, final boolean tree, __0$1x10$glb$Worker$$Queue$2 $dummy) {
        this((java.lang.System[]) null, $Queue, $R);
        x10$glb$Worker$$init$S(init, n, w, l, z, m, tree, (x10.glb.Worker.__0$1x10$glb$Worker$$Queue$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.glb.Worker<$Queue, $R> x10$glb$Worker$$init$S(final x10.core.fun.Fun_0_0<$Queue> init, final int n, final int w, final int l, final int z, final int m, final boolean tree, __0$1x10$glb$Worker$$Queue$2 $dummy) {
         {
            
            //#line 90 "x10/glb/Worker.x10"
            
            
            //#line 27 "x10/glb/Worker.x10"
            this.__fieldInitializers_x10_glb_Worker();
            
            //#line 91 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).n = n;
            
            //#line 92 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).w = w;
            
            //#line 93 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).m = m;
            
            //#line 94 "x10/glb/Worker.x10"
            final long t$128102 = ((long)(((int)(z))));
            
            //#line 94 "x10/glb/Worker.x10"
            final x10.core.Rail t$128103 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, t$128102, (x10.core.Long.$box(-1L)), (x10.core.Rail.__1x10$lang$Rail$$T) null)));
            
            //#line 94 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).lifelines = ((x10.core.Rail)(t$128103));
            
            //#line 96 "x10/glb/Worker.x10"
            final long h = ((long)x10.x10rt.X10RT.hereId());
            
            //#line 98 "x10/glb/Worker.x10"
            final long t$128104 = ((long)(((int)(m))));
            
            //#line 98 "x10/glb/Worker.x10"
            final x10.core.Rail t$128105 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, t$128104)));
            
            //#line 98 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).victims = ((x10.core.Rail)(t$128105));
            
            //#line 99 "x10/glb/Worker.x10"
            final long t$128106 = this.P;
            
            //#line 99 "x10/glb/Worker.x10"
            final boolean t$128120 = ((t$128106) > (((long)(1L))));
            
            //#line 99 "x10/glb/Worker.x10"
            if (t$128120) {
                
                //#line 99 "x10/glb/Worker.x10"
                long i = 0L;
                
                //#line 99 "x10/glb/Worker.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 99 "x10/glb/Worker.x10"
                    final long t$128109 = ((long)(((int)(m))));
                    
                    //#line 99 "x10/glb/Worker.x10"
                    final boolean t$128119 = ((i) < (((long)(t$128109))));
                    
                    //#line 99 "x10/glb/Worker.x10"
                    if (!(t$128119)) {
                        
                        //#line 99 "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 100 "x10/glb/Worker.x10"
                    while (true) {
                        
                        //#line 100 "x10/glb/Worker.x10"
                        final x10.core.Rail t$128572 = ((x10.core.Rail)(this.victims));
                        
                        //#line 100 "x10/glb/Worker.x10"
                        final x10.util.Random t$128574 = ((x10.util.Random)(this.random));
                        
                        //#line 100 "x10/glb/Worker.x10"
                        final long t$128575 = this.P;
                        
                        //#line 100 "x10/glb/Worker.x10"
                        final long t$128576 = t$128574.nextLong$O((long)(t$128575));
                        
                        //#line 100 "x10/glb/Worker.x10"
                        final long t$128577 = x10.core.Long.$unbox(((long[])t$128572.value)[(int)i] = t$128576);
                        
                        //#line 100 "x10/glb/Worker.x10"
                        final boolean t$128578 = ((long) t$128577) == ((long) h);
                        
                        //#line 100 "x10/glb/Worker.x10"
                        if (!(t$128578)) {
                            
                            //#line 100 "x10/glb/Worker.x10"
                            break;
                        }
                    }
                    
                    //#line 99 "x10/glb/Worker.x10"
                    final long t$128580 = ((i) + (((long)(1L))));
                    
                    //#line 99 "x10/glb/Worker.x10"
                    i = t$128580;
                }
            }
            
            //#line 104 "x10/glb/Worker.x10"
            long x = 1L;
            
            //#line 105 "x10/glb/Worker.x10"
            long t = 0L;
            
            //#line 106 "x10/glb/Worker.x10"
            long j$128635 = 0L;
            
            //#line 106 "x10/glb/Worker.x10"
            for (;
                 true;
                 ) {
                
                //#line 106 "x10/glb/Worker.x10"
                final long t$128637 = ((long)(((int)(z))));
                
                //#line 106 "x10/glb/Worker.x10"
                final boolean t$128638 = ((j$128635) < (((long)(t$128637))));
                
                //#line 106 "x10/glb/Worker.x10"
                if (!(t$128638)) {
                    
                    //#line 106 "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 107 "x10/glb/Worker.x10"
                long v$128614 = h;
                
                //#line 108 "x10/glb/Worker.x10"
                long k$128610 = 1L;
                
                //#line 108 "x10/glb/Worker.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 108 "x10/glb/Worker.x10"
                    final long t$128612 = ((long)(((int)(l))));
                    
                    //#line 108 "x10/glb/Worker.x10"
                    final boolean t$128613 = ((k$128610) < (((long)(t$128612))));
                    
                    //#line 108 "x10/glb/Worker.x10"
                    if (!(t$128613)) {
                        
                        //#line 108 "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$128584 = ((long)(((int)(l))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$128585 = ((x) * (((long)(t$128584))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$128586 = ((v$128614) % (((long)(t$128585))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$128587 = ((v$128614) - (((long)(t$128586))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$128590 = ((long)(((int)(l))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$128591 = ((x) * (((long)(t$128590))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$128592 = ((v$128614) + (((long)(t$128591))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$128594 = ((t$128592) - (((long)(x))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$128596 = ((long)(((int)(l))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$128597 = ((x) * (((long)(t$128596))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$128598 = ((t$128594) % (((long)(t$128597))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$128599 = ((t$128587) + (((long)(t$128598))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    v$128614 = t$128599;
                    
                    //#line 110 "x10/glb/Worker.x10"
                    final long t$128601 = this.P;
                    
                    //#line 110 "x10/glb/Worker.x10"
                    final boolean t$128602 = ((v$128614) < (((long)(t$128601))));
                    
                    //#line 110 "x10/glb/Worker.x10"
                    if (t$128602) {
                        
                        //#line 111 "x10/glb/Worker.x10"
                        final x10.core.Rail t$128603 = ((x10.core.Rail)(this.lifelines));
                        
                        //#line 111 "x10/glb/Worker.x10"
                        final long pre$128604 = t;
                        
                        //#line 111 "x10/glb/Worker.x10"
                        final long t$128606 = ((t) + (((long)(1L))));
                        
                        //#line 111 "x10/glb/Worker.x10"
                        t = t$128606;
                        
                        //#line 111 "x10/glb/Worker.x10"
                        ((long[])t$128603.value)[(int)pre$128604] = v$128614;
                        
                        //#line 112 "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 108 "x10/glb/Worker.x10"
                    final long t$128609 = ((k$128610) + (((long)(1L))));
                    
                    //#line 108 "x10/glb/Worker.x10"
                    k$128610 = t$128609;
                }
                
                //#line 115 "x10/glb/Worker.x10"
                final long t$128616 = ((long)(((int)(l))));
                
                //#line 115 "x10/glb/Worker.x10"
                final long t$128617 = ((x) * (((long)(t$128616))));
                
                //#line 115 "x10/glb/Worker.x10"
                x = t$128617;
                
                //#line 106 "x10/glb/Worker.x10"
                final long t$128619 = ((j$128635) + (((long)(1L))));
                
                //#line 106 "x10/glb/Worker.x10"
                j$128635 = t$128619;
            }
            
            //#line 118 "x10/glb/Worker.x10"
            final $Queue t$128162 = (($Queue)(((x10.core.fun.Fun_0_0<$Queue>)init).$apply$G()));
            
            //#line 118 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).queue = (($Queue)(t$128162));
            
            //#line 119 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack alloc$118636 = ((x10.glb.FixedSizeStack)(new x10.glb.FixedSizeStack<x10.core.Long>((java.lang.System[]) null, x10.rtt.Types.LONG)));
            
            //#line 119 "x10/glb/Worker.x10"
            final x10.core.Rail t$128639 = ((x10.core.Rail)(this.lifelines));
            
            //#line 119 "x10/glb/Worker.x10"
            final long t$128640 = ((x10.core.Rail<x10.core.Long>)t$128639).size;
            
            //#line 119 "x10/glb/Worker.x10"
            final long t$128641 = ((t$128640) + (((long)(3L))));
            
            //#line 119 "x10/glb/Worker.x10"
            alloc$118636.x10$glb$FixedSizeStack$$init$S(t$128641);
            
            //#line 119 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).lifelineThieves = ((x10.glb.FixedSizeStack)(alloc$118636));
            
            //#line 120 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack alloc$118637 = ((x10.glb.FixedSizeStack)(new x10.glb.FixedSizeStack<x10.core.Long>((java.lang.System[]) null, x10.rtt.Types.LONG)));
            
            //#line 120 "x10/glb/Worker.x10"
            final long t$128642 = this.P;
            
            //#line 120 "x10/glb/Worker.x10"
            alloc$118637.x10$glb$FixedSizeStack$$init$S(((long)(t$128642)));
            
            //#line 120 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).thieves = ((x10.glb.FixedSizeStack)(alloc$118637));
            
            //#line 121 "x10/glb/Worker.x10"
            final long t$128167 = this.P;
            
            //#line 121 "x10/glb/Worker.x10"
            final x10.core.Rail t$128168 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Boolean>(x10.rtt.Types.BOOLEAN, ((long)(t$128167)))));
            
            //#line 121 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).lifelinesActivated = ((x10.core.Rail)(t$128168));
            
            //#line 123 "x10/glb/Worker.x10"
            if (tree) {
                
                //#line 125 "x10/glb/Worker.x10"
                final long t$128169 = ((3L) * (((long)(h))));
                
                //#line 125 "x10/glb/Worker.x10"
                final long t$128170 = ((t$128169) + (((long)(1L))));
                
                //#line 125 "x10/glb/Worker.x10"
                final long t$128171 = this.P;
                
                //#line 125 "x10/glb/Worker.x10"
                final boolean t$128178 = ((t$128170) < (((long)(t$128171))));
                
                //#line 125 "x10/glb/Worker.x10"
                if (t$128178) {
                    
                    //#line 125 "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$127914 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
                    
                    //#line 125 "x10/glb/Worker.x10"
                    final long t$128172 = ((3L) * (((long)(h))));
                    
                    //#line 125 "x10/glb/Worker.x10"
                    final long t$127913 = ((t$128172) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$128620 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$127914).data));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128621 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127914).size;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128622 = ((t$128621) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128623 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127914).size = t$128622;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128624 = ((t$128623) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    ((long[])t$128620.value)[(int)t$128624] = t$127913;
                }
                
                //#line 126 "x10/glb/Worker.x10"
                final long t$128179 = ((3L) * (((long)(h))));
                
                //#line 126 "x10/glb/Worker.x10"
                final long t$128180 = ((t$128179) + (((long)(2L))));
                
                //#line 126 "x10/glb/Worker.x10"
                final long t$128181 = this.P;
                
                //#line 126 "x10/glb/Worker.x10"
                final boolean t$128188 = ((t$128180) < (((long)(t$128181))));
                
                //#line 126 "x10/glb/Worker.x10"
                if (t$128188) {
                    
                    //#line 126 "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$127917 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
                    
                    //#line 126 "x10/glb/Worker.x10"
                    final long t$128182 = ((3L) * (((long)(h))));
                    
                    //#line 126 "x10/glb/Worker.x10"
                    final long t$127916 = ((t$128182) + (((long)(2L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$128625 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$127917).data));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128626 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127917).size;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128627 = ((t$128626) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128628 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127917).size = t$128627;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128629 = ((t$128628) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    ((long[])t$128625.value)[(int)t$128629] = t$127916;
                }
                
                //#line 127 "x10/glb/Worker.x10"
                final long t$128189 = ((3L) * (((long)(h))));
                
                //#line 127 "x10/glb/Worker.x10"
                final long t$128190 = ((t$128189) + (((long)(3L))));
                
                //#line 127 "x10/glb/Worker.x10"
                final long t$128191 = this.P;
                
                //#line 127 "x10/glb/Worker.x10"
                final boolean t$128198 = ((t$128190) < (((long)(t$128191))));
                
                //#line 127 "x10/glb/Worker.x10"
                if (t$128198) {
                    
                    //#line 127 "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$127920 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
                    
                    //#line 127 "x10/glb/Worker.x10"
                    final long t$128192 = ((3L) * (((long)(h))));
                    
                    //#line 127 "x10/glb/Worker.x10"
                    final long t$127919 = ((t$128192) + (((long)(3L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$128630 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$127920).data));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128631 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127920).size;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128632 = ((t$128631) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128633 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127920).size = t$128632;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128634 = ((t$128633) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    ((long[])t$128630.value)[(int)t$128634] = t$127919;
                }
                
                //#line 128 "x10/glb/Worker.x10"
                final boolean t$128202 = ((h) > (((long)(0L))));
                
                //#line 128 "x10/glb/Worker.x10"
                if (t$128202) {
                    
                    //#line 128 "x10/glb/Worker.x10"
                    final x10.core.Rail t$128200 = ((x10.core.Rail)(this.lifelinesActivated));
                    
                    //#line 128 "x10/glb/Worker.x10"
                    final long t$128199 = ((h) - (((long)(1L))));
                    
                    //#line 128 "x10/glb/Worker.x10"
                    final long t$128201 = ((t$128199) / (((long)(3L))));
                    
                    //#line 128 "x10/glb/Worker.x10"
                    ((boolean[])t$128200.value)[(int)t$128201] = true;
                }
            }
            
            //#line 131 "x10/glb/Worker.x10"
            final x10.glb.Logger alloc$118638 = ((x10.glb.Logger)(new x10.glb.Logger((java.lang.System[]) null)));
            
            //#line 131 "x10/glb/Worker.x10"
            alloc$118638.x10$glb$Logger$$init$S(((boolean)(true)));
            
            //#line 131 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).logger = ((x10.glb.Logger)(alloc$118638));
        }
        return this;
    }
    
    
    
    //#line 142 "x10/glb/Worker.x10"
    /**
     * Main process function of Worker. It does 4 things:
     * (1) execute at most n tasks 
     * (2) respond to stealing requests
     * (3) when not worth sharing tasks, reject the stealing requests 
     * (4) when running out of tasks, steal from others
     * @param st the place local handle of Worker
     */
    final public void processStack__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 143 "x10/glb/Worker.x10"
        boolean t$128275 = false;
        
        //#line 143 "x10/glb/Worker.x10"
        do  {
            
            //#line 144 "x10/glb/Worker.x10"
            while (true) {
                
                //#line 144 "x10/glb/Worker.x10"
                final $Queue t$128746 = (($Queue)(this.queue));
                
                //#line 144 "x10/glb/Worker.x10"
                final int t$128747 = this.n;
                
                //#line 144 "x10/glb/Worker.x10"
                final long t$128748 = ((long)(((int)(t$128747))));
                
                //#line 144 "x10/glb/Worker.x10"
                final x10.glb.Context t$128749 = ((x10.glb.Context)(this.context));
                
                //#line 144 "x10/glb/Worker.x10"
                final boolean t$128750 = x10.core.Boolean.$unbox(((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128746)).process$Z((long)(t$128748), ((x10.glb.Context)(t$128749)), x10.rtt.ParameterizedType.make(x10.glb.Context.$RTT, $Queue, $R)));
                
                //#line 144 "x10/glb/Worker.x10"
                if (!(t$128750)) {
                    
                    //#line 144 "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 145 "x10/glb/Worker.x10"
                x10.xrx.Runtime.probe();
                
                //#line 146 "x10/glb/Worker.x10"
                final x10.glb.Worker this$128719 = ((x10.glb.Worker)(this));
                
                //#line 146 "x10/glb/Worker.x10"
                final x10.lang.PlaceLocalHandle st$128720 = ((x10.lang.PlaceLocalHandle)(st));
                
                //#line 186 . "x10/glb/Worker.x10"
                x10.glb.TaskBag loot$128705 =  null;
                
                //#line 187 . "x10/glb/Worker.x10"
                while (true) {
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128706 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128719).thieves));
                    
                    //#line 55 .. "x10/glb/FixedSizeStack.x10"
                    final long t$128707 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128706).size;
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    boolean t$128708 = ((t$128707) > (((long)(0L))));
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    if (!(t$128708)) {
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        final x10.glb.FixedSizeStack this$128709 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128719).lifelineThieves));
                        
                        //#line 55 .. "x10/glb/FixedSizeStack.x10"
                        final long t$128710 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128709).size;
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        t$128708 = ((t$128710) > (((long)(0L))));
                    }
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    boolean t$128711 = t$128708;
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    if (t$128708) {
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        final $Queue t$128712 = (($Queue)(((x10.glb.Worker<$Queue, $R>)this$128719).queue));
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        final x10.glb.TaskBag t$128713 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128712)).split();
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        final x10.glb.TaskBag t$128714 = loot$128705 = ((x10.glb.TaskBag)(t$128713));
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        t$128711 = ((t$128714) != (null));
                    }
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    if (!(t$128711)) {
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 188 . "x10/glb/Worker.x10"
                    final x10.lang.PlaceLocalHandle st$128683 = ((x10.lang.PlaceLocalHandle)(st$128720));
                    
                    //#line 188 . "x10/glb/Worker.x10"
                    final x10.glb.TaskBag loot$128684 = ((x10.glb.TaskBag)(loot$128705));
                    
                    //#line 162 .. "x10/glb/Worker.x10"
                    final long victim$128645 = ((long)x10.x10rt.X10RT.hereId());
                    
                    //#line 163 .. "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$128646 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128719).logger));
                    
                    //#line 163 .. "x10/glb/Worker.x10"
                    final long t$128647 = obj$128646.nodesGiven;
                    
                    //#line 163 .. "x10/glb/Worker.x10"
                    final long t$128648 = loot$128705.size$O();
                    
                    //#line 163 .. "x10/glb/Worker.x10"
                    final long t$128649 = ((t$128647) + (((long)(t$128648))));
                    
                    //#line 163 .. "x10/glb/Worker.x10"
                    obj$128646.nodesGiven = t$128649;
                    
                    //#line 164 .. "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128650 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128719).thieves));
                    
                    //#line 55 ... "x10/glb/FixedSizeStack.x10"
                    final long t$128651 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128650).size;
                    
                    //#line 164 .. "x10/glb/Worker.x10"
                    final boolean t$128652 = ((t$128651) > (((long)(0L))));
                    
                    //#line 164 .. "x10/glb/Worker.x10"
                    if (t$128652) {
                        
                        //#line 165 .. "x10/glb/Worker.x10"
                        final x10.glb.FixedSizeStack this$128653 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128719).thieves));
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final x10.core.Rail t$128654 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128653).data));
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final long t$128655 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128653).size;
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final long t$128656 = ((t$128655) - (((long)(1L))));
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final long t$128657 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128653).size = t$128656;
                        
                        //#line 165 .. "x10/glb/Worker.x10"
                        final long thief$128658 = ((long[])t$128654.value)[(int)t$128657];
                        
                        //#line 166 .. "x10/glb/Worker.x10"
                        final boolean t$128659 = ((thief$128658) >= (((long)(0L))));
                        
                        //#line 166 .. "x10/glb/Worker.x10"
                        if (t$128659) {
                            
                            //#line 167 .. "x10/glb/Worker.x10"
                            final x10.glb.Logger obj$128660 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128719).logger));
                            
                            //#line 167 .. "x10/glb/Worker.x10"
                            final long t$128661 = obj$128660.lifelineStealsSuffered;
                            
                            //#line 167 .. "x10/glb/Worker.x10"
                            final long t$128662 = ((t$128661) + (((long)(1L))));
                            
                            //#line 167 .. "x10/glb/Worker.x10"
                            obj$128660.lifelineStealsSuffered = t$128662;
                            
                            //#line 168 .. "x10/glb/Worker.x10"
                            final x10.lang.Place alloc$128663 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                            
                            //#line 168 .. "x10/glb/Worker.x10"
                            alloc$128663.x10$lang$Place$$init$S(((long)(thief$128658)));
                            
                            //#line 168 .. "x10/glb/Worker.x10"
                            x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128663)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$70<$Queue, $R>($Queue, $R, st$128683, loot$128684, victim$128645, (x10.glb.Worker.$Closure$70.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$70$$Queue$3x10$glb$Worker$$Closure$70$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                        } else {
                            
                            //#line 170 .. "x10/glb/Worker.x10"
                            final x10.glb.Logger obj$128666 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128719).logger));
                            
                            //#line 170 .. "x10/glb/Worker.x10"
                            final long t$128667 = obj$128666.stealsSuffered;
                            
                            //#line 170 .. "x10/glb/Worker.x10"
                            final long t$128668 = ((t$128667) + (((long)(1L))));
                            
                            //#line 170 .. "x10/glb/Worker.x10"
                            obj$128666.stealsSuffered = t$128668;
                            
                            //#line 171 .. "x10/glb/Worker.x10"
                            final x10.lang.Place alloc$128669 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                            
                            //#line 171 .. "x10/glb/Worker.x10"
                            final long t$128643 = (-(thief$128658));
                            
                            //#line 171 .. "x10/glb/Worker.x10"
                            final long t$128644 = ((t$128643) - (((long)(1L))));
                            
                            //#line 171 .. "x10/glb/Worker.x10"
                            alloc$128669.x10$lang$Place$$init$S(t$128644);
                            
                            //#line 171 .. "x10/glb/Worker.x10"
                            x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128669)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$71<$Queue, $R>($Queue, $R, st$128683, loot$128684, (x10.glb.Worker.$Closure$71.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$71$$Queue$3x10$glb$Worker$$Closure$71$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                        }
                    } else {
                        
                        //#line 174 .. "x10/glb/Worker.x10"
                        final x10.glb.Logger obj$128672 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128719).logger));
                        
                        //#line 174 .. "x10/glb/Worker.x10"
                        final long t$128673 = obj$128672.lifelineStealsSuffered;
                        
                        //#line 174 .. "x10/glb/Worker.x10"
                        final long t$128674 = ((t$128673) + (((long)(1L))));
                        
                        //#line 174 .. "x10/glb/Worker.x10"
                        obj$128672.lifelineStealsSuffered = t$128674;
                        
                        //#line 175 .. "x10/glb/Worker.x10"
                        final x10.glb.FixedSizeStack this$128675 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128719).lifelineThieves));
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final x10.core.Rail t$128676 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128675).data));
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final long t$128677 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128675).size;
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final long t$128678 = ((t$128677) - (((long)(1L))));
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final long t$128679 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128675).size = t$128678;
                        
                        //#line 175 .. "x10/glb/Worker.x10"
                        final long thief$128680 = ((long[])t$128676.value)[(int)t$128679];
                        
                        //#line 176 .. "x10/glb/Worker.x10"
                        final x10.lang.Place alloc$128681 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 176 .. "x10/glb/Worker.x10"
                        alloc$128681.x10$lang$Place$$init$S(((long)(thief$128680)));
                        
                        //#line 176 .. "x10/glb/Worker.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$128681)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$72<$Queue, $R>($Queue, $R, st$128683, loot$128684, victim$128645, (x10.glb.Worker.$Closure$72.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$72$$Queue$3x10$glb$Worker$$Closure$72$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
                
                //#line 147 "x10/glb/Worker.x10"
                final x10.glb.Worker this$128721 = ((x10.glb.Worker)(this));
                
                //#line 147 "x10/glb/Worker.x10"
                final x10.lang.PlaceLocalHandle st$128722 = ((x10.lang.PlaceLocalHandle)(st));
                
                //#line 198 . "x10/glb/Worker.x10"
                while (true) {
                    
                    //#line 198 . "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128716 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128721).thieves));
                    
                    //#line 55 .. "x10/glb/FixedSizeStack.x10"
                    final long t$128717 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128716).size;
                    
                    //#line 198 . "x10/glb/Worker.x10"
                    final boolean t$128718 = ((t$128717) > (((long)(0L))));
                    
                    //#line 198 . "x10/glb/Worker.x10"
                    if (!(t$128718)) {
                        
                        //#line 198 . "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 199 . "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128692 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128721).thieves));
                    
                    //#line 44 .. "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$128693 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128692).data));
                    
                    //#line 44 .. "x10/glb/FixedSizeStack.x10"
                    final long t$128694 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128692).size;
                    
                    //#line 44 .. "x10/glb/FixedSizeStack.x10"
                    final long t$128695 = ((t$128694) - (((long)(1L))));
                    
                    //#line 44 .. "x10/glb/FixedSizeStack.x10"
                    final long t$128696 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128692).size = t$128695;
                    
                    //#line 199 . "x10/glb/Worker.x10"
                    final long thief$128697 = ((long[])t$128693.value)[(int)t$128696];
                    
                    //#line 200 . "x10/glb/Worker.x10"
                    final boolean t$128698 = ((thief$128697) >= (((long)(0L))));
                    
                    //#line 200 . "x10/glb/Worker.x10"
                    if (t$128698) {
                        
                        //#line 201 . "x10/glb/Worker.x10"
                        final x10.glb.FixedSizeStack this$128699 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128721).lifelineThieves));
                        
                        //#line 49 .. "x10/glb/FixedSizeStack.x10"
                        final x10.core.Rail t$128685 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128699).data));
                        
                        //#line 49 .. "x10/glb/FixedSizeStack.x10"
                        final long t$128686 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128699).size;
                        
                        //#line 49 .. "x10/glb/FixedSizeStack.x10"
                        final long t$128687 = ((t$128686) + (((long)(1L))));
                        
                        //#line 49 .. "x10/glb/FixedSizeStack.x10"
                        final long t$128688 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128699).size = t$128687;
                        
                        //#line 49 .. "x10/glb/FixedSizeStack.x10"
                        final long t$128689 = ((t$128688) - (((long)(1L))));
                        
                        //#line 49 .. "x10/glb/FixedSizeStack.x10"
                        ((long[])t$128685.value)[(int)t$128689] = thief$128697;
                        
                        //#line 202 . "x10/glb/Worker.x10"
                        final x10.lang.Place alloc$128701 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 202 . "x10/glb/Worker.x10"
                        alloc$128701.x10$lang$Place$$init$S(((long)(thief$128697)));
                        
                        //#line 202 . "x10/glb/Worker.x10"
                        x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128701)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$73<$Queue, $R>($Queue, $R, st$128722, (x10.glb.Worker.$Closure$73.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$73$$Queue$3x10$glb$Worker$$Closure$73$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    } else {
                        
                        //#line 204 . "x10/glb/Worker.x10"
                        final x10.lang.Place alloc$128703 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 204 . "x10/glb/Worker.x10"
                        final long t$128690 = (-(thief$128697));
                        
                        //#line 204 . "x10/glb/Worker.x10"
                        final long t$128691 = ((t$128690) - (((long)(1L))));
                        
                        //#line 204 . "x10/glb/Worker.x10"
                        alloc$128703.x10$lang$Place$$init$S(t$128691);
                        
                        //#line 204 . "x10/glb/Worker.x10"
                        x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128703)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$74<$Queue, $R>($Queue, $R, st$128722, (x10.glb.Worker.$Closure$74.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$74$$Queue$3x10$glb$Worker$$Closure$74$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }
            
            //#line 149 "x10/glb/Worker.x10"
            final x10.glb.Worker this$128751 = ((x10.glb.Worker)(this));
            
            //#line 149 "x10/glb/Worker.x10"
            final x10.lang.PlaceLocalHandle st$128752 = ((x10.lang.PlaceLocalHandle)(st));
            
            //#line 198 . "x10/glb/Worker.x10"
            while (true) {
                
                //#line 198 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$128743 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128751).thieves));
                
                //#line 55 .. "x10/glb/FixedSizeStack.x10"
                final long t$128744 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128743).size;
                
                //#line 198 . "x10/glb/Worker.x10"
                final boolean t$128745 = ((t$128744) > (((long)(0L))));
                
                //#line 198 . "x10/glb/Worker.x10"
                if (!(t$128745)) {
                    
                    //#line 198 . "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 199 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$128730 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128751).thieves));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final x10.core.Rail t$128731 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128730).data));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$128732 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128730).size;
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$128733 = ((t$128732) - (((long)(1L))));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$128734 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128730).size = t$128733;
                
                //#line 199 . "x10/glb/Worker.x10"
                final long thief$128735 = ((long[])t$128731.value)[(int)t$128734];
                
                //#line 200 . "x10/glb/Worker.x10"
                final boolean t$128736 = ((thief$128735) >= (((long)(0L))));
                
                //#line 200 . "x10/glb/Worker.x10"
                if (t$128736) {
                    
                    //#line 201 . "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128737 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128751).lifelineThieves));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$128723 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128737).data));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$128724 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128737).size;
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$128725 = ((t$128724) + (((long)(1L))));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$128726 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128737).size = t$128725;
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$128727 = ((t$128726) - (((long)(1L))));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    ((long[])t$128723.value)[(int)t$128727] = thief$128735;
                    
                    //#line 202 . "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$128739 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 202 . "x10/glb/Worker.x10"
                    alloc$128739.x10$lang$Place$$init$S(((long)(thief$128735)));
                    
                    //#line 202 . "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128739)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$75<$Queue, $R>($Queue, $R, st$128752, (x10.glb.Worker.$Closure$75.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$75$$Queue$3x10$glb$Worker$$Closure$75$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                } else {
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$128741 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    final long t$128728 = (-(thief$128735));
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    final long t$128729 = ((t$128728) - (((long)(1L))));
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    alloc$128741.x10$lang$Place$$init$S(t$128729);
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128741)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$76<$Queue, $R>($Queue, $R, st$128752, (x10.glb.Worker.$Closure$76.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$76$$Queue$3x10$glb$Worker$$Closure$76$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                }
            }
            
            //#line 150 "x10/glb/Worker.x10"
            final boolean t$128276 = this.steal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2$O(((x10.lang.PlaceLocalHandle)(st)));
            
            //#line 143 "x10/glb/Worker.x10"
            t$128275 = t$128276;
        }while(t$128275); 
    }
    
    
    //#line 161 "x10/glb/Worker.x10"
    /**
     * Send out the workload to thieves. At this point, either thieves or lifelinetheives 
     * is non-empty (or both are non-empty). Note sending workload to the lifeline thieve
     * is the only place that uses async (instead of uncounted async as in other places),
     * which means when only all lifeline requests are responded can the framework be terminated.
     * @param st place local handle of LJR
     * @param loot the taskbag(aka workload) to send out
     */
    public void give__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st, final x10.glb.TaskBag loot) {
        
        //#line 162 "x10/glb/Worker.x10"
        final long victim = ((long)x10.x10rt.X10RT.hereId());
        
        //#line 163 "x10/glb/Worker.x10"
        final x10.glb.Logger obj$118274 = ((x10.glb.Logger)(this.logger));
        
        //#line 163 "x10/glb/Worker.x10"
        final long t$128277 = obj$118274.nodesGiven;
        
        //#line 163 "x10/glb/Worker.x10"
        final long t$128278 = loot.size$O();
        
        //#line 163 "x10/glb/Worker.x10"
        final long t$128279 = ((t$128277) + (((long)(t$128278))));
        
        //#line 163 "x10/glb/Worker.x10"
        obj$118274.nodesGiven = t$128279;
        
        //#line 164 "x10/glb/Worker.x10"
        final x10.glb.FixedSizeStack this$127975 = ((x10.glb.FixedSizeStack)(this.thieves));
        
        //#line 55 . "x10/glb/FixedSizeStack.x10"
        final long t$128280 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127975).size;
        
        //#line 164 "x10/glb/Worker.x10"
        final boolean t$128303 = ((t$128280) > (((long)(0L))));
        
        //#line 164 "x10/glb/Worker.x10"
        if (t$128303) {
            
            //#line 165 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack this$127977 = ((x10.glb.FixedSizeStack)(this.thieves));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final x10.core.Rail t$128283 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$127977).data));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128281 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127977).size;
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128282 = ((t$128281) - (((long)(1L))));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128284 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127977).size = t$128282;
            
            //#line 165 "x10/glb/Worker.x10"
            final long thief = ((long[])t$128283.value)[(int)t$128284];
            
            //#line 166 "x10/glb/Worker.x10"
            final boolean t$128295 = ((thief) >= (((long)(0L))));
            
            //#line 166 "x10/glb/Worker.x10"
            if (t$128295) {
                
                //#line 167 "x10/glb/Worker.x10"
                final x10.glb.Logger obj$118296 = ((x10.glb.Logger)(this.logger));
                
                //#line 167 "x10/glb/Worker.x10"
                final long t$128285 = obj$118296.lifelineStealsSuffered;
                
                //#line 167 "x10/glb/Worker.x10"
                final long t$128286 = ((t$128285) + (((long)(1L))));
                
                //#line 167 "x10/glb/Worker.x10"
                obj$118296.lifelineStealsSuffered = t$128286;
                
                //#line 168 "x10/glb/Worker.x10"
                final x10.lang.Place alloc$118639 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 168 "x10/glb/Worker.x10"
                alloc$118639.x10$lang$Place$$init$S(((long)(thief)));
                
                //#line 168 "x10/glb/Worker.x10"
                x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$118639)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$77<$Queue, $R>($Queue, $R, st, loot, victim, (x10.glb.Worker.$Closure$77.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$77$$Queue$3x10$glb$Worker$$Closure$77$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            } else {
                
                //#line 170 "x10/glb/Worker.x10"
                final x10.glb.Logger obj$118304 = ((x10.glb.Logger)(this.logger));
                
                //#line 170 "x10/glb/Worker.x10"
                final long t$128289 = obj$118304.stealsSuffered;
                
                //#line 170 "x10/glb/Worker.x10"
                final long t$128290 = ((t$128289) + (((long)(1L))));
                
                //#line 170 "x10/glb/Worker.x10"
                obj$118304.stealsSuffered = t$128290;
                
                //#line 171 "x10/glb/Worker.x10"
                final x10.lang.Place alloc$118640 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 171 "x10/glb/Worker.x10"
                final long t$128753 = (-(thief));
                
                //#line 171 "x10/glb/Worker.x10"
                final long t$128754 = ((t$128753) - (((long)(1L))));
                
                //#line 171 "x10/glb/Worker.x10"
                alloc$118640.x10$lang$Place$$init$S(t$128754);
                
                //#line 171 "x10/glb/Worker.x10"
                x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$118640)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$78<$Queue, $R>($Queue, $R, st, loot, (x10.glb.Worker.$Closure$78.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$78$$Queue$3x10$glb$Worker$$Closure$78$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            }
        } else {
            
            //#line 174 "x10/glb/Worker.x10"
            final x10.glb.Logger obj$118326 = ((x10.glb.Logger)(this.logger));
            
            //#line 174 "x10/glb/Worker.x10"
            final long t$128296 = obj$118326.lifelineStealsSuffered;
            
            //#line 174 "x10/glb/Worker.x10"
            final long t$128297 = ((t$128296) + (((long)(1L))));
            
            //#line 174 "x10/glb/Worker.x10"
            obj$118326.lifelineStealsSuffered = t$128297;
            
            //#line 175 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack this$127979 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final x10.core.Rail t$128300 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$127979).data));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128298 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127979).size;
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128299 = ((t$128298) - (((long)(1L))));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128301 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127979).size = t$128299;
            
            //#line 175 "x10/glb/Worker.x10"
            final long thief = ((long[])t$128300.value)[(int)t$128301];
            
            //#line 176 "x10/glb/Worker.x10"
            final x10.lang.Place alloc$118641 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 176 "x10/glb/Worker.x10"
            alloc$118641.x10$lang$Place$$init$S(((long)(thief)));
            
            //#line 176 "x10/glb/Worker.x10"
            x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$118641)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$79<$Queue, $R>($Queue, $R, st, loot, victim, (x10.glb.Worker.$Closure$79.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$79$$Queue$3x10$glb$Worker$$Closure$79$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 185 "x10/glb/Worker.x10"
    /**
     * Distribute works to (lifeline) thieves by calling the 
     * {@link #give(st:PlaceLocalHandle[Worker[Queue, R]], loot:TaskBag) method
     * @param st place local handle of Worker
     */
    public void distribute__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 186 "x10/glb/Worker.x10"
        x10.glb.TaskBag loot =  null;
        
        //#line 187 "x10/glb/Worker.x10"
        while (true) {
            
            //#line 187 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack this$127981 = ((x10.glb.FixedSizeStack)(this.thieves));
            
            //#line 55 . "x10/glb/FixedSizeStack.x10"
            final long t$128304 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127981).size;
            
            //#line 187 "x10/glb/Worker.x10"
            boolean t$128306 = ((t$128304) > (((long)(0L))));
            
            //#line 187 "x10/glb/Worker.x10"
            if (!(t$128306)) {
                
                //#line 187 "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$127983 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
                
                //#line 55 . "x10/glb/FixedSizeStack.x10"
                final long t$128305 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$127983).size;
                
                //#line 187 "x10/glb/Worker.x10"
                t$128306 = ((t$128305) > (((long)(0L))));
            }
            
            //#line 187 "x10/glb/Worker.x10"
            boolean t$128310 = t$128306;
            
            //#line 187 "x10/glb/Worker.x10"
            if (t$128306) {
                
                //#line 187 "x10/glb/Worker.x10"
                final $Queue t$128307 = (($Queue)(this.queue));
                
                //#line 187 "x10/glb/Worker.x10"
                final x10.glb.TaskBag t$128308 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128307)).split();
                
                //#line 187 "x10/glb/Worker.x10"
                final x10.glb.TaskBag t$128309 = loot = ((x10.glb.TaskBag)(t$128308));
                
                //#line 187 "x10/glb/Worker.x10"
                t$128310 = ((t$128309) != (null));
            }
            
            //#line 187 "x10/glb/Worker.x10"
            if (!(t$128310)) {
                
                //#line 187 "x10/glb/Worker.x10"
                break;
            }
            
            //#line 188 "x10/glb/Worker.x10"
            final x10.glb.Worker this$128795 = ((x10.glb.Worker)(this));
            
            //#line 188 "x10/glb/Worker.x10"
            final x10.lang.PlaceLocalHandle st$128796 = ((x10.lang.PlaceLocalHandle)(st));
            
            //#line 188 "x10/glb/Worker.x10"
            final x10.glb.TaskBag loot$128797 = ((x10.glb.TaskBag)(loot));
            
            //#line 162 . "x10/glb/Worker.x10"
            final long victim$128757 = ((long)x10.x10rt.X10RT.hereId());
            
            //#line 163 . "x10/glb/Worker.x10"
            final x10.glb.Logger obj$128758 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128795).logger));
            
            //#line 163 . "x10/glb/Worker.x10"
            final long t$128759 = obj$128758.nodesGiven;
            
            //#line 163 . "x10/glb/Worker.x10"
            final long t$128760 = loot.size$O();
            
            //#line 163 . "x10/glb/Worker.x10"
            final long t$128761 = ((t$128759) + (((long)(t$128760))));
            
            //#line 163 . "x10/glb/Worker.x10"
            obj$128758.nodesGiven = t$128761;
            
            //#line 164 . "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack this$128762 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128795).thieves));
            
            //#line 55 .. "x10/glb/FixedSizeStack.x10"
            final long t$128763 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128762).size;
            
            //#line 164 . "x10/glb/Worker.x10"
            final boolean t$128764 = ((t$128763) > (((long)(0L))));
            
            //#line 164 . "x10/glb/Worker.x10"
            if (t$128764) {
                
                //#line 165 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$128765 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128795).thieves));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final x10.core.Rail t$128766 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128765).data));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$128767 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128765).size;
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$128768 = ((t$128767) - (((long)(1L))));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$128769 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128765).size = t$128768;
                
                //#line 165 . "x10/glb/Worker.x10"
                final long thief$128770 = ((long[])t$128766.value)[(int)t$128769];
                
                //#line 166 . "x10/glb/Worker.x10"
                final boolean t$128771 = ((thief$128770) >= (((long)(0L))));
                
                //#line 166 . "x10/glb/Worker.x10"
                if (t$128771) {
                    
                    //#line 167 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$128772 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128795).logger));
                    
                    //#line 167 . "x10/glb/Worker.x10"
                    final long t$128773 = obj$128772.lifelineStealsSuffered;
                    
                    //#line 167 . "x10/glb/Worker.x10"
                    final long t$128774 = ((t$128773) + (((long)(1L))));
                    
                    //#line 167 . "x10/glb/Worker.x10"
                    obj$128772.lifelineStealsSuffered = t$128774;
                    
                    //#line 168 . "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$128775 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 168 . "x10/glb/Worker.x10"
                    alloc$128775.x10$lang$Place$$init$S(((long)(thief$128770)));
                    
                    //#line 168 . "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128775)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$80<$Queue, $R>($Queue, $R, st$128796, loot$128797, victim$128757, (x10.glb.Worker.$Closure$80.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$80$$Queue$3x10$glb$Worker$$Closure$80$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                } else {
                    
                    //#line 170 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$128778 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128795).logger));
                    
                    //#line 170 . "x10/glb/Worker.x10"
                    final long t$128779 = obj$128778.stealsSuffered;
                    
                    //#line 170 . "x10/glb/Worker.x10"
                    final long t$128780 = ((t$128779) + (((long)(1L))));
                    
                    //#line 170 . "x10/glb/Worker.x10"
                    obj$128778.stealsSuffered = t$128780;
                    
                    //#line 171 . "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$128781 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 171 . "x10/glb/Worker.x10"
                    final long t$128755 = (-(thief$128770));
                    
                    //#line 171 . "x10/glb/Worker.x10"
                    final long t$128756 = ((t$128755) - (((long)(1L))));
                    
                    //#line 171 . "x10/glb/Worker.x10"
                    alloc$128781.x10$lang$Place$$init$S(t$128756);
                    
                    //#line 171 . "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128781)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$81<$Queue, $R>($Queue, $R, st$128796, loot$128797, (x10.glb.Worker.$Closure$81.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$81$$Queue$3x10$glb$Worker$$Closure$81$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                }
            } else {
                
                //#line 174 . "x10/glb/Worker.x10"
                final x10.glb.Logger obj$128784 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128795).logger));
                
                //#line 174 . "x10/glb/Worker.x10"
                final long t$128785 = obj$128784.lifelineStealsSuffered;
                
                //#line 174 . "x10/glb/Worker.x10"
                final long t$128786 = ((t$128785) + (((long)(1L))));
                
                //#line 174 . "x10/glb/Worker.x10"
                obj$128784.lifelineStealsSuffered = t$128786;
                
                //#line 175 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$128787 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128795).lifelineThieves));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final x10.core.Rail t$128788 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128787).data));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$128789 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128787).size;
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$128790 = ((t$128789) - (((long)(1L))));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$128791 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128787).size = t$128790;
                
                //#line 175 . "x10/glb/Worker.x10"
                final long thief$128792 = ((long[])t$128788.value)[(int)t$128791];
                
                //#line 176 . "x10/glb/Worker.x10"
                final x10.lang.Place alloc$128793 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 176 . "x10/glb/Worker.x10"
                alloc$128793.x10$lang$Place$$init$S(((long)(thief$128792)));
                
                //#line 176 . "x10/glb/Worker.x10"
                x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$128793)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$82<$Queue, $R>($Queue, $R, st$128796, loot$128797, victim$128757, (x10.glb.Worker.$Closure$82.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$82$$Queue$3x10$glb$Worker$$Closure$82$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            }
        }
    }
    
    
    //#line 197 "x10/glb/Worker.x10"
    /**
     * Rejecting thieves when no task to share (or worth sharing). Note, never reject lifeline thief,
     * instead put it into the lifelineThieves stack,
     * @param st place local handle of Worker
     */
    public void reject__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 198 "x10/glb/Worker.x10"
        while (true) {
            
            //#line 198 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack this$128005 = ((x10.glb.FixedSizeStack)(this.thieves));
            
            //#line 55 . "x10/glb/FixedSizeStack.x10"
            final long t$128339 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128005).size;
            
            //#line 198 "x10/glb/Worker.x10"
            final boolean t$128354 = ((t$128339) > (((long)(0L))));
            
            //#line 198 "x10/glb/Worker.x10"
            if (!(t$128354)) {
                
                //#line 198 "x10/glb/Worker.x10"
                break;
            }
            
            //#line 199 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack this$128805 = ((x10.glb.FixedSizeStack)(this.thieves));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final x10.core.Rail t$128806 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128805).data));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128807 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128805).size;
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128808 = ((t$128807) - (((long)(1L))));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128809 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128805).size = t$128808;
            
            //#line 199 "x10/glb/Worker.x10"
            final long thief$128810 = ((long[])t$128806.value)[(int)t$128809];
            
            //#line 200 "x10/glb/Worker.x10"
            final boolean t$128811 = ((thief$128810) >= (((long)(0L))));
            
            //#line 200 "x10/glb/Worker.x10"
            if (t$128811) {
                
                //#line 201 "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$128812 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
                
                //#line 49 . "x10/glb/FixedSizeStack.x10"
                final x10.core.Rail t$128798 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128812).data));
                
                //#line 49 . "x10/glb/FixedSizeStack.x10"
                final long t$128799 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128812).size;
                
                //#line 49 . "x10/glb/FixedSizeStack.x10"
                final long t$128800 = ((t$128799) + (((long)(1L))));
                
                //#line 49 . "x10/glb/FixedSizeStack.x10"
                final long t$128801 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128812).size = t$128800;
                
                //#line 49 . "x10/glb/FixedSizeStack.x10"
                final long t$128802 = ((t$128801) - (((long)(1L))));
                
                //#line 49 . "x10/glb/FixedSizeStack.x10"
                ((long[])t$128798.value)[(int)t$128802] = thief$128810;
                
                //#line 202 "x10/glb/Worker.x10"
                final x10.lang.Place alloc$128814 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 202 "x10/glb/Worker.x10"
                alloc$128814.x10$lang$Place$$init$S(((long)(thief$128810)));
                
                //#line 202 "x10/glb/Worker.x10"
                x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128814)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$83<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$83.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$83$$Queue$3x10$glb$Worker$$Closure$83$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            } else {
                
                //#line 204 "x10/glb/Worker.x10"
                final x10.lang.Place alloc$128816 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 204 "x10/glb/Worker.x10"
                final long t$128803 = (-(thief$128810));
                
                //#line 204 "x10/glb/Worker.x10"
                final long t$128804 = ((t$128803) - (((long)(1L))));
                
                //#line 204 "x10/glb/Worker.x10"
                alloc$128816.x10$lang$Place$$init$S(t$128804);
                
                //#line 204 "x10/glb/Worker.x10"
                x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128816)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$84<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$84.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$84$$Queue$3x10$glb$Worker$$Closure$84$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            }
        }
    }
    
    
    //#line 221 "x10/glb/Worker.x10"
    /**
     * Send out steal requests.
     * It does following things:
     * (1) Probes w random victims and send out stealing requests by calling into 
     * {@link #request(st:PlaceLocalHandle[Worker[Queue, R]], thief:Long, lifeline:Boolean)}
     * (2) If probing random victims fails, resort to lifeline buddies
     * In both case, it sends out the request and wait on the thieves' response, which either comes from
     * (i){@link #reject(PlaceLocalHandle[Worker[Queue, R]])} when victim has no workload to share
     * or (ii) {@link #give(PlaceLocalHandle[Worker[Queue, R]]],TaskBag)} when victim gives the workload
     * 
     * @param st PHL for Worker
     */
    public boolean steal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2$O(final x10.lang.PlaceLocalHandle st) {
        
        //#line 222 "x10/glb/Worker.x10"
        final long t$128355 = this.P;
        
        //#line 222 "x10/glb/Worker.x10"
        final boolean t$128356 = ((long) t$128355) == ((long) 1L);
        
        //#line 222 "x10/glb/Worker.x10"
        if (t$128356) {
            
            //#line 222 "x10/glb/Worker.x10"
            return false;
        }
        
        //#line 223 "x10/glb/Worker.x10"
        final long p = ((long)x10.x10rt.X10RT.hereId());
        
        //#line 224 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).empty = true;
        
        //#line 225 "x10/glb/Worker.x10"
        long i$128851 = 0L;
        
        //#line 225 "x10/glb/Worker.x10"
        for (;
             true;
             ) {
            
            //#line 225 "x10/glb/Worker.x10"
            final int t$128853 = this.w;
            
            //#line 225 "x10/glb/Worker.x10"
            final long t$128854 = ((long)(((int)(t$128853))));
            
            //#line 225 "x10/glb/Worker.x10"
            boolean t$128855 = ((i$128851) < (((long)(t$128854))));
            
            //#line 225 "x10/glb/Worker.x10"
            if (t$128855) {
                
                //#line 225 "x10/glb/Worker.x10"
                t$128855 = this.empty;
            }
            
            //#line 225 "x10/glb/Worker.x10"
            if (!(t$128855)) {
                
                //#line 225 "x10/glb/Worker.x10"
                break;
            }
            
            //#line 226 "x10/glb/Worker.x10"
            final x10.glb.Logger obj$128818 = ((x10.glb.Logger)(this.logger));
            
            //#line 226 "x10/glb/Worker.x10"
            final long t$128819 = obj$128818.stealsAttempted;
            
            //#line 226 "x10/glb/Worker.x10"
            final long t$128820 = ((t$128819) + (((long)(1L))));
            
            //#line 226 "x10/glb/Worker.x10"
            obj$128818.stealsAttempted = t$128820;
            
            //#line 227 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).waiting = true;
            
            //#line 228 "x10/glb/Worker.x10"
            final x10.glb.Logger t$128821 = ((x10.glb.Logger)(this.logger));
            
            //#line 228 "x10/glb/Worker.x10"
            t$128821.stopLive();
            
            //#line 229 "x10/glb/Worker.x10"
            final x10.core.Rail t$128822 = ((x10.core.Rail)(this.victims));
            
            //#line 229 "x10/glb/Worker.x10"
            final x10.util.Random t$128823 = ((x10.util.Random)(this.random));
            
            //#line 229 "x10/glb/Worker.x10"
            final int t$128824 = this.m;
            
            //#line 229 "x10/glb/Worker.x10"
            final int t$128825 = t$128823.nextInt$O((int)(t$128824));
            
            //#line 229 "x10/glb/Worker.x10"
            final long t$128826 = ((long)(((int)(t$128825))));
            
            //#line 229 "x10/glb/Worker.x10"
            final long v$128827 = ((long[])t$128822.value)[(int)t$128826];
            
            //#line 230 "x10/glb/Worker.x10"
            final x10.lang.Place alloc$128828 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 230 "x10/glb/Worker.x10"
            alloc$128828.x10$lang$Place$$init$S(((long)(v$128827)));
            
            //#line 230 "x10/glb/Worker.x10"
            x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128828)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$85<$Queue, $R>($Queue, $R, st, p, (x10.glb.Worker.$Closure$85.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$85$$Queue$3x10$glb$Worker$$Closure$85$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            
            //#line 231 "x10/glb/Worker.x10"
            while (true) {
                
                //#line 231 "x10/glb/Worker.x10"
                final boolean t$128830 = this.waiting;
                
                //#line 231 "x10/glb/Worker.x10"
                if (!(t$128830)) {
                    
                    //#line 231 "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 231 "x10/glb/Worker.x10"
                x10.xrx.Runtime.probe();
            }
            
            //#line 232 "x10/glb/Worker.x10"
            final x10.glb.Logger t$128831 = ((x10.glb.Logger)(this.logger));
            
            //#line 232 "x10/glb/Worker.x10"
            t$128831.startLive();
            
            //#line 225 "x10/glb/Worker.x10"
            final long t$128833 = ((i$128851) + (((long)(1L))));
            
            //#line 225 "x10/glb/Worker.x10"
            i$128851 = t$128833;
        }
        
        //#line 234 "x10/glb/Worker.x10"
        long i$128857 = 0L;
        
        //#line 234 "x10/glb/Worker.x10"
        for (;
             true;
             ) {
            
            //#line 234 "x10/glb/Worker.x10"
            final x10.core.Rail t$128859 = ((x10.core.Rail)(this.lifelines));
            
            //#line 234 "x10/glb/Worker.x10"
            final long t$128860 = ((x10.core.Rail<x10.core.Long>)t$128859).size;
            
            //#line 234 "x10/glb/Worker.x10"
            boolean t$128861 = ((i$128857) < (((long)(t$128860))));
            
            //#line 234 "x10/glb/Worker.x10"
            if (t$128861) {
                
                //#line 234 "x10/glb/Worker.x10"
                t$128861 = this.empty;
            }
            
            //#line 234 "x10/glb/Worker.x10"
            boolean t$128862 = t$128861;
            
            //#line 234 "x10/glb/Worker.x10"
            if (t$128861) {
                
                //#line 234 "x10/glb/Worker.x10"
                final x10.core.Rail t$128863 = ((x10.core.Rail)(this.lifelines));
                
                //#line 234 "x10/glb/Worker.x10"
                final long t$128865 = ((long[])t$128863.value)[(int)i$128857];
                
                //#line 234 "x10/glb/Worker.x10"
                t$128862 = ((0L) <= (((long)(t$128865))));
            }
            
            //#line 234 "x10/glb/Worker.x10"
            if (!(t$128862)) {
                
                //#line 234 "x10/glb/Worker.x10"
                break;
            }
            
            //#line 235 "x10/glb/Worker.x10"
            final x10.core.Rail t$128834 = ((x10.core.Rail)(this.lifelines));
            
            //#line 235 "x10/glb/Worker.x10"
            final long lifeline$128836 = ((long[])t$128834.value)[(int)i$128857];
            
            //#line 236 "x10/glb/Worker.x10"
            final x10.core.Rail t$128837 = ((x10.core.Rail)(this.lifelinesActivated));
            
            //#line 236 "x10/glb/Worker.x10"
            final boolean t$128838 = ((boolean[])t$128837.value)[(int)lifeline$128836];
            
            //#line 236 "x10/glb/Worker.x10"
            final boolean t$128839 = !(t$128838);
            
            //#line 236 "x10/glb/Worker.x10"
            if (t$128839) {
                
                //#line 237 "x10/glb/Worker.x10"
                final x10.glb.Logger obj$128840 = ((x10.glb.Logger)(this.logger));
                
                //#line 237 "x10/glb/Worker.x10"
                final long t$128841 = obj$128840.lifelineStealsAttempted;
                
                //#line 237 "x10/glb/Worker.x10"
                final long t$128842 = ((t$128841) + (((long)(1L))));
                
                //#line 237 "x10/glb/Worker.x10"
                obj$128840.lifelineStealsAttempted = t$128842;
                
                //#line 238 "x10/glb/Worker.x10"
                final x10.core.Rail t$128843 = ((x10.core.Rail)(this.lifelinesActivated));
                
                //#line 238 "x10/glb/Worker.x10"
                ((boolean[])t$128843.value)[(int)lifeline$128836] = true;
                
                //#line 239 "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)this).waiting = true;
                
                //#line 240 "x10/glb/Worker.x10"
                final x10.glb.Logger t$128844 = ((x10.glb.Logger)(this.logger));
                
                //#line 240 "x10/glb/Worker.x10"
                t$128844.stopLive();
                
                //#line 241 "x10/glb/Worker.x10"
                final x10.lang.Place alloc$128845 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 241 "x10/glb/Worker.x10"
                alloc$128845.x10$lang$Place$$init$S(((long)(lifeline$128836)));
                
                //#line 241 "x10/glb/Worker.x10"
                x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128845)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$86<$Queue, $R>($Queue, $R, st, p, (x10.glb.Worker.$Closure$86.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$86$$Queue$3x10$glb$Worker$$Closure$86$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                
                //#line 242 "x10/glb/Worker.x10"
                while (true) {
                    
                    //#line 242 "x10/glb/Worker.x10"
                    final boolean t$128847 = this.waiting;
                    
                    //#line 242 "x10/glb/Worker.x10"
                    if (!(t$128847)) {
                        
                        //#line 242 "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 242 "x10/glb/Worker.x10"
                    x10.xrx.Runtime.probe();
                }
                
                //#line 243 "x10/glb/Worker.x10"
                final x10.glb.Logger t$128848 = ((x10.glb.Logger)(this.logger));
                
                //#line 243 "x10/glb/Worker.x10"
                t$128848.startLive();
            }
            
            //#line 234 "x10/glb/Worker.x10"
            final long t$128850 = ((i$128857) + (((long)(1L))));
            
            //#line 234 "x10/glb/Worker.x10"
            i$128857 = t$128850;
        }
        
        //#line 246 "x10/glb/Worker.x10"
        final boolean t$128400 = this.empty;
        
        //#line 246 "x10/glb/Worker.x10"
        final boolean t$128401 = !(t$128400);
        
        //#line 246 "x10/glb/Worker.x10"
        return t$128401;
    }
    
    
    //#line 256 "x10/glb/Worker.x10"
    /**
     * Remote thief sending requests to local LJR. When empty or waiting for more work,
     * reject non-lifeline thief right away. Note, never reject lifeline thief.
     * @param st PLH for Woker
     * @param thief place id of thief
     * @param lifeline if I am the lifeline buddy of the remote thief
     */
    public void request__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st, final long thief, final boolean lifeline) {
        
        //#line 257 "x10/glb/Worker.x10"
        try {{
            
            //#line 258 "x10/glb/Worker.x10"
            if (lifeline) {
                
                //#line 258 "x10/glb/Worker.x10"
                final x10.glb.Logger obj$118427 = ((x10.glb.Logger)(this.logger));
                
                //#line 258 "x10/glb/Worker.x10"
                final long t$128402 = obj$118427.lifelineStealsReceived;
                
                //#line 258 "x10/glb/Worker.x10"
                final long t$128403 = ((t$128402) + (((long)(1L))));
                
                //#line 258 "x10/glb/Worker.x10"
                obj$118427.lifelineStealsReceived = t$128403;
            } else {
                
                //#line 258 "x10/glb/Worker.x10"
                final x10.glb.Logger obj$118435 = ((x10.glb.Logger)(this.logger));
                
                //#line 258 "x10/glb/Worker.x10"
                final long t$128404 = obj$118435.stealsReceived;
                
                //#line 258 "x10/glb/Worker.x10"
                final long t$128405 = ((t$128404) + (((long)(1L))));
                
                //#line 258 "x10/glb/Worker.x10"
                obj$118435.stealsReceived = t$128405;
            }
            
            //#line 259 "x10/glb/Worker.x10"
            boolean t$128406 = this.empty;
            
            //#line 259 "x10/glb/Worker.x10"
            if (!(t$128406)) {
                
                //#line 259 "x10/glb/Worker.x10"
                t$128406 = this.waiting;
            }
            
            //#line 259 "x10/glb/Worker.x10"
            if (t$128406) {
                
                //#line 260 "x10/glb/Worker.x10"
                if (lifeline) {
                    
                    //#line 260 "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128013 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$128867 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128013).data));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128868 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128013).size;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128869 = ((t$128868) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128870 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128013).size = t$128869;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128871 = ((t$128870) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    ((long[])t$128867.value)[(int)t$128871] = thief;
                }
                
                //#line 261 "x10/glb/Worker.x10"
                final x10.lang.Place alloc$118646 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 261 "x10/glb/Worker.x10"
                alloc$118646.x10$lang$Place$$init$S(((long)(thief)));
                
                //#line 261 "x10/glb/Worker.x10"
                x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$118646)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$87<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$87.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$87$$Queue$3x10$glb$Worker$$Closure$87$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            } else {
                
                //#line 263 "x10/glb/Worker.x10"
                if (lifeline) {
                    
                    //#line 263 "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128016 = ((x10.glb.FixedSizeStack)(this.thieves));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$128872 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128016).data));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128873 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128016).size;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128874 = ((t$128873) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128875 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128016).size = t$128874;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128876 = ((t$128875) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    ((long[])t$128872.value)[(int)t$128876] = thief;
                } else {
                    
                    //#line 263 "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128019 = ((x10.glb.FixedSizeStack)(this.thieves));
                    
                    //#line 263 "x10/glb/Worker.x10"
                    final long t$128418 = (-(thief));
                    
                    //#line 263 "x10/glb/Worker.x10"
                    final long t$128018 = ((t$128418) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$128877 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128019).data));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128878 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128019).size;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128879 = ((t$128878) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128880 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128019).size = t$128879;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$128881 = ((t$128880) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    ((long[])t$128877.value)[(int)t$128881] = t$128018;
                }
            }
        }}catch (final java.lang.Throwable v) {
            
            //#line 266 "x10/glb/Worker.x10"
            x10.glb.Worker.error(((java.lang.Throwable)(v)));
        }
    }
    
    
    //#line 275 "x10/glb/Worker.x10"
    /**
     * Merge current Worker's taskbag with incoming task bag.
     * @param loot task bag to merge
     * @param lifeline if it is from a lifeline buddy
     */
    final public void processLoot(final x10.glb.TaskBag loot, final boolean lifeline) {
        
        //#line 276 "x10/glb/Worker.x10"
        final long n = loot.size$O();
        
        //#line 277 "x10/glb/Worker.x10"
        if (lifeline) {
            
            //#line 278 "x10/glb/Worker.x10"
            final x10.glb.Logger obj$118457 = ((x10.glb.Logger)(this.logger));
            
            //#line 278 "x10/glb/Worker.x10"
            final long t$128425 = obj$118457.lifelineStealsPerpetrated;
            
            //#line 278 "x10/glb/Worker.x10"
            final long t$128426 = ((t$128425) + (((long)(1L))));
            
            //#line 278 "x10/glb/Worker.x10"
            obj$118457.lifelineStealsPerpetrated = t$128426;
            
            //#line 279 "x10/glb/Worker.x10"
            final x10.glb.Logger obj$118465 = ((x10.glb.Logger)(this.logger));
            
            //#line 279 "x10/glb/Worker.x10"
            final long t$128427 = obj$118465.lifelineNodesReceived;
            
            //#line 279 "x10/glb/Worker.x10"
            final long t$128428 = ((t$128427) + (((long)(n))));
            
            //#line 279 "x10/glb/Worker.x10"
            obj$118465.lifelineNodesReceived = t$128428;
        } else {
            
            //#line 281 "x10/glb/Worker.x10"
            final x10.glb.Logger obj$118473 = ((x10.glb.Logger)(this.logger));
            
            //#line 281 "x10/glb/Worker.x10"
            final long t$128429 = obj$118473.stealsPerpetrated;
            
            //#line 281 "x10/glb/Worker.x10"
            final long t$128430 = ((t$128429) + (((long)(1L))));
            
            //#line 281 "x10/glb/Worker.x10"
            obj$118473.stealsPerpetrated = t$128430;
            
            //#line 282 "x10/glb/Worker.x10"
            final x10.glb.Logger obj$118481 = ((x10.glb.Logger)(this.logger));
            
            //#line 282 "x10/glb/Worker.x10"
            final long t$128431 = obj$118481.nodesReceived;
            
            //#line 282 "x10/glb/Worker.x10"
            final long t$128432 = ((t$128431) + (((long)(n))));
            
            //#line 282 "x10/glb/Worker.x10"
            obj$118481.nodesReceived = t$128432;
        }
        
        //#line 284 "x10/glb/Worker.x10"
        final $Queue t$128433 = (($Queue)(this.queue));
        
        //#line 284 "x10/glb/Worker.x10"
        ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128433)).merge(((x10.glb.TaskBag)(loot)));
    }
    
    
    //#line 294 "x10/glb/Worker.x10"
    /**
     * Deal workload to the theif. If the thief is active already, simply merge the taskbag. If the thief is inactive,
     * the thief gets reactiveated again.
     * @param st: PLH for Worker
     * @param loot Task to share
     * @param source victim id
     */
    public void deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st, final x10.glb.TaskBag loot, final long source) {
        
        //#line 295 "x10/glb/Worker.x10"
        try {{
            
            //#line 296 "x10/glb/Worker.x10"
            final boolean lifeline = ((source) >= (((long)(0L))));
            
            //#line 297 "x10/glb/Worker.x10"
            if (lifeline) {
                
                //#line 297 "x10/glb/Worker.x10"
                final x10.core.Rail t$128434 = ((x10.core.Rail)(this.lifelinesActivated));
                
                //#line 297 "x10/glb/Worker.x10"
                ((boolean[])t$128434.value)[(int)source] = false;
            }
            
            //#line 298 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).empty = false;
            
            //#line 299 "x10/glb/Worker.x10"
            final boolean t$128458 = this.active;
            
            //#line 299 "x10/glb/Worker.x10"
            if (t$128458) {
                
                //#line 300 "x10/glb/Worker.x10"
                final x10.glb.Worker this$128028 = ((x10.glb.Worker)(this));
                
                //#line 276 . "x10/glb/Worker.x10"
                final long n$128882 = loot.size$O();
                
                //#line 277 . "x10/glb/Worker.x10"
                if (lifeline) {
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$128883 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128028).logger));
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    final long t$128884 = obj$128883.lifelineStealsPerpetrated;
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    final long t$128885 = ((t$128884) + (((long)(1L))));
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    obj$128883.lifelineStealsPerpetrated = t$128885;
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$128886 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128028).logger));
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    final long t$128887 = obj$128886.lifelineNodesReceived;
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    final long t$128888 = ((t$128887) + (((long)(n$128882))));
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    obj$128886.lifelineNodesReceived = t$128888;
                } else {
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$128889 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128028).logger));
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    final long t$128890 = obj$128889.stealsPerpetrated;
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    final long t$128891 = ((t$128890) + (((long)(1L))));
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    obj$128889.stealsPerpetrated = t$128891;
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$128892 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128028).logger));
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    final long t$128893 = obj$128892.nodesReceived;
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    final long t$128894 = ((t$128893) + (((long)(n$128882))));
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    obj$128892.nodesReceived = t$128894;
                }
                
                //#line 284 . "x10/glb/Worker.x10"
                final $Queue t$128895 = (($Queue)(((x10.glb.Worker<$Queue, $R>)this$128028).queue));
                
                //#line 284 . "x10/glb/Worker.x10"
                ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128895)).merge(((x10.glb.TaskBag)(loot)));
            } else {
                
                //#line 302 "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)this).active = true;
                
                //#line 303 "x10/glb/Worker.x10"
                final x10.glb.Logger t$128444 = ((x10.glb.Logger)(this.logger));
                
                //#line 303 "x10/glb/Worker.x10"
                t$128444.startLive();
                
                //#line 304 "x10/glb/Worker.x10"
                final x10.glb.Worker this$128037 = ((x10.glb.Worker)(this));
                
                //#line 276 . "x10/glb/Worker.x10"
                final long n$128896 = loot.size$O();
                
                //#line 277 . "x10/glb/Worker.x10"
                if (lifeline) {
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$128897 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128037).logger));
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    final long t$128898 = obj$128897.lifelineStealsPerpetrated;
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    final long t$128899 = ((t$128898) + (((long)(1L))));
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    obj$128897.lifelineStealsPerpetrated = t$128899;
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$128900 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128037).logger));
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    final long t$128901 = obj$128900.lifelineNodesReceived;
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    final long t$128902 = ((t$128901) + (((long)(n$128896))));
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    obj$128900.lifelineNodesReceived = t$128902;
                } else {
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$128903 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128037).logger));
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    final long t$128904 = obj$128903.stealsPerpetrated;
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    final long t$128905 = ((t$128904) + (((long)(1L))));
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    obj$128903.stealsPerpetrated = t$128905;
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$128906 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128037).logger));
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    final long t$128907 = obj$128906.nodesReceived;
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    final long t$128908 = ((t$128907) + (((long)(n$128896))));
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    obj$128906.nodesReceived = t$128908;
                }
                
                //#line 284 . "x10/glb/Worker.x10"
                final $Queue t$128909 = (($Queue)(((x10.glb.Worker<$Queue, $R>)this$128037).queue));
                
                //#line 284 . "x10/glb/Worker.x10"
                ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128909)).merge(((x10.glb.TaskBag)(loot)));
                
                //#line 306 "x10/glb/Worker.x10"
                this.processStack__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(st)));
                
                //#line 307 "x10/glb/Worker.x10"
                final x10.glb.Logger t$128454 = ((x10.glb.Logger)(this.logger));
                
                //#line 307 "x10/glb/Worker.x10"
                t$128454.stopLive();
                
                //#line 308 "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)this).active = false;
                
                //#line 309 "x10/glb/Worker.x10"
                final x10.glb.Logger t$128456 = ((x10.glb.Logger)(this.logger));
                
                //#line 309 "x10/glb/Worker.x10"
                final $Queue t$128455 = (($Queue)(this.queue));
                
                //#line 309 "x10/glb/Worker.x10"
                final long t$128457 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128455)).count$O();
                
                //#line 309 "x10/glb/Worker.x10"
                t$128456.nodesCount = t$128457;
            }
        }}catch (final java.lang.Throwable v) {
            
            //#line 312 "x10/glb/Worker.x10"
            x10.glb.Worker.error(((java.lang.Throwable)(v)));
        }
    }
    
    
    //#line 324 "x10/glb/Worker.x10"
    /**
     * Entry point when workload is only known dynamically . The workflow is terminated when 
     * (1) No one has work to do
     * (2) Lifeline steals are responded
     * @param place local handle for Worker
     * @param start init method used in {@link TaskQueue}, note the workload is not allocated, because
     * the workload can only be self-generated.
     */
    public void main__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st, final x10.core.fun.VoidFun_0_0 start) {
        {
            
            //#line 325 "x10/glb/Worker.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 325 "x10/glb/Worker.x10"
            final x10.xrx.FinishState fs$129096 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_DENSE));
            
            //#line 325 "x10/glb/Worker.x10"
            try {{
                {
                    
                    //#line 326 "x10/glb/Worker.x10"
                    try {{
                        
                        //#line 327 "x10/glb/Worker.x10"
                        ((x10.glb.Worker<$Queue, $R>)this).empty = false;
                        
                        //#line 328 "x10/glb/Worker.x10"
                        ((x10.glb.Worker<$Queue, $R>)this).active = true;
                        
                        //#line 329 "x10/glb/Worker.x10"
                        final x10.glb.Logger t$128459 = ((x10.glb.Logger)(this.logger));
                        
                        //#line 329 "x10/glb/Worker.x10"
                        t$128459.startLive();
                        
                        //#line 330 "x10/glb/Worker.x10"
                        ((x10.core.fun.VoidFun_0_0)start).$apply();
                        
                        //#line 331 "x10/glb/Worker.x10"
                        this.processStack__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(st)));
                        
                        //#line 332 "x10/glb/Worker.x10"
                        final x10.glb.Logger t$128460 = ((x10.glb.Logger)(this.logger));
                        
                        //#line 332 "x10/glb/Worker.x10"
                        t$128460.stopLive();
                        
                        //#line 333 "x10/glb/Worker.x10"
                        ((x10.glb.Worker<$Queue, $R>)this).active = false;
                        
                        //#line 334 "x10/glb/Worker.x10"
                        final x10.glb.Logger t$128462 = ((x10.glb.Logger)(this.logger));
                        
                        //#line 334 "x10/glb/Worker.x10"
                        final $Queue t$128461 = (($Queue)(this.queue));
                        
                        //#line 334 "x10/glb/Worker.x10"
                        final long t$128463 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128461)).count$O();
                        
                        //#line 334 "x10/glb/Worker.x10"
                        t$128462.nodesCount = t$128463;
                    }}catch (final java.lang.Throwable v) {
                        
                        //#line 336 "x10/glb/Worker.x10"
                        x10.glb.Worker.error(((java.lang.Throwable)(v)));
                    }
                }
            }}catch (java.lang.Throwable ct$129093) {
                
                //#line 325 "x10/glb/Worker.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$129093)));
                
                //#line 325 "x10/glb/Worker.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 325 "x10/glb/Worker.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$129096)));
             }}
            }
        }
    
    
    //#line 348 "x10/glb/Worker.x10"
    /**
     * Entry point when workload can be known statically. The workflow is terminated when 
     * (1) No one has work to do
     * (2) Lifeline steals are responded
     * @param place local handle for Worker. Note the workload is assumed to be allocated already in the {@link TaskQueue}
     * constructor.
     */
    public void main__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 349 "x10/glb/Worker.x10"
        try {{
            
            //#line 350 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).empty = false;
            
            //#line 351 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).active = true;
            
            //#line 352 "x10/glb/Worker.x10"
            final x10.glb.Logger t$128464 = ((x10.glb.Logger)(this.logger));
            
            //#line 352 "x10/glb/Worker.x10"
            t$128464.startLive();
            
            //#line 353 "x10/glb/Worker.x10"
            this.processStack__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(st)));
            
            //#line 354 "x10/glb/Worker.x10"
            final x10.glb.Logger t$128465 = ((x10.glb.Logger)(this.logger));
            
            //#line 354 "x10/glb/Worker.x10"
            t$128465.stopLive();
            
            //#line 355 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).active = false;
            
            //#line 356 "x10/glb/Worker.x10"
            final x10.glb.Logger t$128467 = ((x10.glb.Logger)(this.logger));
            
            //#line 356 "x10/glb/Worker.x10"
            final $Queue t$128466 = (($Queue)(this.queue));
            
            //#line 356 "x10/glb/Worker.x10"
            final long t$128468 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128466)).count$O();
            
            //#line 356 "x10/glb/Worker.x10"
            t$128467.nodesCount = t$128468;
        }}catch (final java.lang.Throwable v) {
            
            //#line 358 "x10/glb/Worker.x10"
            x10.glb.Worker.error(((java.lang.Throwable)(v)));
        }
    }
    
    
    //#line 366 "x10/glb/Worker.x10"
    /**
     * Print exceptions
     * @param v exeception
     */
    public static void error(final java.lang.Throwable v) {
        
        //#line 367 "x10/glb/Worker.x10"
        final java.lang.String t$128469 = (("Exception at ") + (x10.x10rt.X10RT.here()));
        
        //#line 367 "x10/glb/Worker.x10"
        java.lang.System.err.println(t$128469);
        
        //#line 368 "x10/glb/Worker.x10"
        v.printStackTrace();
    }
    
    
    //#line 374 "x10/glb/Worker.x10"
    /**
     * Min helper function
     */
    public static long min$O(final long i, final long j) {
        
        //#line 374 "x10/glb/Worker.x10"
        final boolean t$128470 = ((i) < (((long)(j))));
        
        //#line 374 "x10/glb/Worker.x10"
        long t$128471 =  0;
        
        //#line 374 "x10/glb/Worker.x10"
        if (t$128470) {
            
            //#line 374 "x10/glb/Worker.x10"
            t$128471 = i;
        } else {
            
            //#line 374 "x10/glb/Worker.x10"
            t$128471 = j;
        }
        
        //#line 374 "x10/glb/Worker.x10"
        return t$128471;
    }
    
    
    //#line 403 "x10/glb/Worker.x10"
    /**
     * Internal method used by {@link GLB} to start Worker at each place when the 
     * workload is known statically.
     * @param st PLH of Worker
     */
    public static <$Queue, $R>void broadcast__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st) {
        
        //#line 404 "x10/glb/Worker.x10"
        final long P = ((long)x10.x10rt.X10RT.numPlaces());
        {
            
            //#line 405 "x10/glb/Worker.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 405 "x10/glb/Worker.x10"
            final x10.xrx.FinishState fs$129113 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_DENSE));
            
            //#line 405 "x10/glb/Worker.x10"
            try {{
                {
                    
                    //#line 406 "x10/glb/Worker.x10"
                    final boolean t$128494 = ((P) < (((long)(256L))));
                    
                    //#line 406 "x10/glb/Worker.x10"
                    if (t$128494) {
                        
                        //#line 407 "x10/glb/Worker.x10"
                        long i = 0L;
                        
                        //#line 407 "x10/glb/Worker.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 407 "x10/glb/Worker.x10"
                            final boolean t$128479 = ((i) < (((long)(P))));
                            
                            //#line 407 "x10/glb/Worker.x10"
                            if (!(t$128479)) {
                                
                                //#line 407 "x10/glb/Worker.x10"
                                break;
                            }
                            
                            //#line 408 "x10/glb/Worker.x10"
                            final x10.lang.Place alloc$128911 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                            
                            //#line 408 "x10/glb/Worker.x10"
                            alloc$128911.x10$lang$Place$$init$S(i);
                            
                            //#line 408 "x10/glb/Worker.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$128911)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$88<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$88.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$88$$Queue$3x10$glb$Worker$$Closure$88$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                            
                            //#line 407 "x10/glb/Worker.x10"
                            final long t$128914 = ((i) + (((long)(1L))));
                            
                            //#line 407 "x10/glb/Worker.x10"
                            i = t$128914;
                        }
                    } else {
                        
                        //#line 411 "x10/glb/Worker.x10"
                        long i = ((P) - (((long)(1L))));
                        
                        //#line 411 "x10/glb/Worker.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 411 "x10/glb/Worker.x10"
                            final boolean t$128493 = ((i) >= (((long)(0L))));
                            
                            //#line 411 "x10/glb/Worker.x10"
                            if (!(t$128493)) {
                                
                                //#line 411 "x10/glb/Worker.x10"
                                break;
                            }
                            
                            //#line 412 "x10/glb/Worker.x10"
                            final x10.lang.Place alloc$128924 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                            
                            //#line 412 "x10/glb/Worker.x10"
                            alloc$128924.x10$lang$Place$$init$S(i);
                            
                            //#line 412 "x10/glb/Worker.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$128924)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$90<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$90.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$90$$Queue$3x10$glb$Worker$$Closure$90$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                            
                            //#line 411 "x10/glb/Worker.x10"
                            final long t$128929 = ((i) - (((long)(32L))));
                            
                            //#line 411 "x10/glb/Worker.x10"
                            i = t$128929;
                        }
                    }
                }
            }}catch (java.lang.Throwable ct$129110) {
                
                //#line 405 "x10/glb/Worker.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$129110)));
                
                //#line 405 "x10/glb/Worker.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 405 "x10/glb/Worker.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$129113)));
             }}
            }
        }
    
    
    //#line 427 "x10/glb/Worker.x10"
    /**
     * Initialize Context object at every place
     * @param st: PLH of Worker
     */
    public static <$Queue, $R>void initContexts__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st) {
        
        //#line 428 "x10/glb/Worker.x10"
        final long P = ((long)x10.x10rt.X10RT.numPlaces());
        {
            
            //#line 429 "x10/glb/Worker.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 429 "x10/glb/Worker.x10"
            final x10.xrx.FinishState fs$129130 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_DENSE));
            
            //#line 429 "x10/glb/Worker.x10"
            try {{
                {
                    
                    //#line 430 "x10/glb/Worker.x10"
                    final boolean t$128516 = ((P) < (((long)(256L))));
                    
                    //#line 430 "x10/glb/Worker.x10"
                    if (t$128516) {
                        
                        //#line 431 "x10/glb/Worker.x10"
                        long i = 0L;
                        
                        //#line 431 "x10/glb/Worker.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 431 "x10/glb/Worker.x10"
                            final boolean t$128501 = ((i) < (((long)(P))));
                            
                            //#line 431 "x10/glb/Worker.x10"
                            if (!(t$128501)) {
                                
                                //#line 431 "x10/glb/Worker.x10"
                                break;
                            }
                            
                            //#line 432 "x10/glb/Worker.x10"
                            final x10.lang.Place alloc$128934 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                            
                            //#line 432 "x10/glb/Worker.x10"
                            alloc$128934.x10$lang$Place$$init$S(i);
                            
                            //#line 432 "x10/glb/Worker.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$128934)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$91<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$91.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$91$$Queue$3x10$glb$Worker$$Closure$91$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                            
                            //#line 431 "x10/glb/Worker.x10"
                            final long t$128938 = ((i) + (((long)(1L))));
                            
                            //#line 431 "x10/glb/Worker.x10"
                            i = t$128938;
                        }
                    } else {
                        
                        //#line 435 "x10/glb/Worker.x10"
                        long i = ((P) - (((long)(1L))));
                        
                        //#line 435 "x10/glb/Worker.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 435 "x10/glb/Worker.x10"
                            final boolean t$128515 = ((i) >= (((long)(0L))));
                            
                            //#line 435 "x10/glb/Worker.x10"
                            if (!(t$128515)) {
                                
                                //#line 435 "x10/glb/Worker.x10"
                                break;
                            }
                            
                            //#line 436 "x10/glb/Worker.x10"
                            final x10.lang.Place alloc$128952 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                            
                            //#line 436 "x10/glb/Worker.x10"
                            alloc$128952.x10$lang$Place$$init$S(i);
                            
                            //#line 436 "x10/glb/Worker.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$128952)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$93<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$93.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$93$$Queue$3x10$glb$Worker$$Closure$93$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                            
                            //#line 435 "x10/glb/Worker.x10"
                            final long t$128957 = ((i) - (((long)(32L))));
                            
                            //#line 435 "x10/glb/Worker.x10"
                            i = t$128957;
                        }
                    }
                }
            }}catch (java.lang.Throwable ct$129127) {
                
                //#line 429 "x10/glb/Worker.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$129127)));
                
                //#line 429 "x10/glb/Worker.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 429 "x10/glb/Worker.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$129130)));
             }}
            }
        }
    
    
    //#line 451 "x10/glb/Worker.x10"
    /**
     * Returns yield point
     */
    public x10.core.fun.VoidFun_0_1 getYieldPoint() {
        
        //#line 452 "x10/glb/Worker.x10"
        final x10.core.fun.VoidFun_0_1 t$128568 = ((x10.core.fun.VoidFun_0_1)(new x10.glb.Worker.$Closure$99<$Queue, $R>($Queue, $R, ((x10.glb.Worker<$Queue, $R>)(this)), (x10.glb.Worker.$Closure$99.__0$1x10$glb$Worker$$Closure$99$$Queue$3x10$glb$Worker$$Closure$99$$R$2) null)));
        
        //#line 452 "x10/glb/Worker.x10"
        return t$128568;
    }
    
    
    //#line 459 "x10/glb/Worker.x10"
    /**
     * Set the context object
     * @param st PLH of Worker
     */
    public void setContext__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 461 "x10/glb/Worker.x10"
        final x10.glb.Context alloc$118653 = ((x10.glb.Context)(new x10.glb.Context<$Queue, $R>((java.lang.System[]) null, $Queue, $R)));
        
        //#line 25 .. "x10/glb/Context.x10"
        final x10.lang.PlaceLocalHandle t$129034 = (x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>) x10.rtt.Types.zeroValue(x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, $Queue, $R)));
        
        //#line 20 .. "x10/glb/Context.x10"
        ((x10.glb.Context<$Queue, $R>)alloc$118653).st = t$129034;
        
        //#line 31 . "x10/glb/Context.x10"
        ((x10.glb.Context<$Queue, $R>)alloc$118653).st = ((x10.lang.PlaceLocalHandle)(st));
        
        //#line 461 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).context = ((x10.glb.Context)(alloc$118653));
    }
    
    
    //#line 27 "x10/glb/Worker.x10"
    final public x10.glb.Worker x10$glb$Worker$$this$x10$glb$Worker() {
        
        //#line 27 "x10/glb/Worker.x10"
        return x10.glb.Worker.this;
    }
    
    
    //#line 27 "x10/glb/Worker.x10"
    final public void __fieldInitializers_x10_glb_Worker() {
        
        //#line 60 "x10/glb/Worker.x10"
        final x10.util.Random alloc$118654 = ((x10.util.Random)(new x10.util.Random((java.lang.System[]) null)));
        
        //#line 60 "x10/glb/Worker.x10"
        final int t$128570 = x10.x10rt.X10RT.hereId();
        
        //#line 60 "x10/glb/Worker.x10"
        final long seed$128096 = ((long)(((int)(t$128570))));
        
        //#line 24 ... "x10/util/Random.x10"
        alloc$118654.seed = 0L;
        
        //#line 24 ... "x10/util/Random.x10"
        alloc$118654.storedGaussian = 0.0;
        
        //#line 24 ... "x10/util/Random.x10"
        alloc$118654.haveStoredGaussian = false;
        
        //#line 36 .. "x10/util/Random.x10"
        alloc$118654.seed = seed$128096;
        
        //#line 37 .. "x10/util/Random.x10"
        alloc$118654.gamma = -7046029254386353131L;
        
        //#line 27 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).random = ((x10.util.Random)(alloc$118654));
        
        //#line 27 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).active = false;
        
        //#line 27 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).empty = true;
        
        //#line 27 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).waiting = false;
        
        //#line 75 "x10/glb/Worker.x10"
        final long t$128571 = ((long)x10.x10rt.X10RT.numPlaces());
        
        //#line 27 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).P = t$128571;
        
        //#line 27 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).context = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$70<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$70> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$70> make($Closure$70.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$70<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$128684 = $deserializer.readObject();
            $_obj.st$128683 = $deserializer.readObject();
            $_obj.victim$128645 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$70 $_obj = new x10.glb.Worker.$Closure$70((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$128684);
            $serializer.write(this.st$128683);
            $serializer.write(this.victim$128645);
            
        }
        
        // constructor just for allocation
        public $Closure$70(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$70.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$70 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$70$$Queue$3x10$glb$Worker$$Closure$70$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 168 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$128664 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128683).$apply$G();
            
            //#line 168 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128664).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$128683)), ((x10.glb.TaskBag)(this.loot$128684)), (long)(this.victim$128645));
            
            //#line 168 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$128665 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128683).$apply$G();
            
            //#line 168 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128665).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128683;
        public x10.glb.TaskBag loot$128684;
        public long victim$128645;
        
        public $Closure$70(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128683, final x10.glb.TaskBag loot$128684, final long victim$128645, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$70$$Queue$3x10$glb$Worker$$Closure$70$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$70.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$70<$Queue, $R>)this).st$128683 = ((x10.lang.PlaceLocalHandle)(st$128683));
                ((x10.glb.Worker.$Closure$70<$Queue, $R>)this).loot$128684 = ((x10.glb.TaskBag)(loot$128684));
                ((x10.glb.Worker.$Closure$70<$Queue, $R>)this).victim$128645 = victim$128645;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$71<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$71> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$71> make($Closure$71.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$71<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$128684 = $deserializer.readObject();
            $_obj.st$128683 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$71 $_obj = new x10.glb.Worker.$Closure$71((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$128684);
            $serializer.write(this.st$128683);
            
        }
        
        // constructor just for allocation
        public $Closure$71(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$71.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$71 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$71$$Queue$3x10$glb$Worker$$Closure$71$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 171 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$128670 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128683).$apply$G();
            
            //#line 171 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128670).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$128683)), ((x10.glb.TaskBag)(this.loot$128684)), (long)(-1L));
            
            //#line 171 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$128671 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128683).$apply$G();
            
            //#line 171 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128671).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128683;
        public x10.glb.TaskBag loot$128684;
        
        public $Closure$71(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128683, final x10.glb.TaskBag loot$128684, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$71$$Queue$3x10$glb$Worker$$Closure$71$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$71.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$71<$Queue, $R>)this).st$128683 = ((x10.lang.PlaceLocalHandle)(st$128683));
                ((x10.glb.Worker.$Closure$71<$Queue, $R>)this).loot$128684 = ((x10.glb.TaskBag)(loot$128684));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$72<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$72> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$72> make($Closure$72.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$72<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$128684 = $deserializer.readObject();
            $_obj.st$128683 = $deserializer.readObject();
            $_obj.victim$128645 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$72 $_obj = new x10.glb.Worker.$Closure$72((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$128684);
            $serializer.write(this.st$128683);
            $serializer.write(this.victim$128645);
            
        }
        
        // constructor just for allocation
        public $Closure$72(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$72.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$72 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$72$$Queue$3x10$glb$Worker$$Closure$72$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 176 .. "x10/glb/Worker.x10"
            try {{
                
                //#line 176 .. "x10/glb/Worker.x10"
                final x10.glb.Worker t$128682 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128683).$apply$G();
                
                //#line 176 .. "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$128682).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$128683)), ((x10.glb.TaskBag)(this.loot$128684)), (long)(this.victim$128645));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 176 .. "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 176 .. "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128683;
        public x10.glb.TaskBag loot$128684;
        public long victim$128645;
        
        public $Closure$72(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128683, final x10.glb.TaskBag loot$128684, final long victim$128645, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$72$$Queue$3x10$glb$Worker$$Closure$72$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$72.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$72<$Queue, $R>)this).st$128683 = ((x10.lang.PlaceLocalHandle)(st$128683));
                ((x10.glb.Worker.$Closure$72<$Queue, $R>)this).loot$128684 = ((x10.glb.TaskBag)(loot$128684));
                ((x10.glb.Worker.$Closure$72<$Queue, $R>)this).victim$128645 = victim$128645;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$73<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$73> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$73> make($Closure$73.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$73<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$128722 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$73 $_obj = new x10.glb.Worker.$Closure$73((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$128722);
            
        }
        
        // constructor just for allocation
        public $Closure$73(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$73.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$73 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$73$$Queue$3x10$glb$Worker$$Closure$73$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 202 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$128702 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128722).$apply$G();
            
            //#line 202 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128702).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128722;
        
        public $Closure$73(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128722, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$73$$Queue$3x10$glb$Worker$$Closure$73$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$73.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$73<$Queue, $R>)this).st$128722 = ((x10.lang.PlaceLocalHandle)(st$128722));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$74<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$74> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$74> make($Closure$74.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$74<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$128722 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$74 $_obj = new x10.glb.Worker.$Closure$74((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$128722);
            
        }
        
        // constructor just for allocation
        public $Closure$74(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$74.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$74 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$74$$Queue$3x10$glb$Worker$$Closure$74$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 204 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$128704 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128722).$apply$G();
            
            //#line 204 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128704).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128722;
        
        public $Closure$74(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128722, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$74$$Queue$3x10$glb$Worker$$Closure$74$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$74.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$74<$Queue, $R>)this).st$128722 = ((x10.lang.PlaceLocalHandle)(st$128722));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$75<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$75> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$75> make($Closure$75.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$75<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$128752 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$75 $_obj = new x10.glb.Worker.$Closure$75((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$128752);
            
        }
        
        // constructor just for allocation
        public $Closure$75(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$75.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$75 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$75$$Queue$3x10$glb$Worker$$Closure$75$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 202 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$128740 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128752).$apply$G();
            
            //#line 202 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128740).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128752;
        
        public $Closure$75(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128752, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$75$$Queue$3x10$glb$Worker$$Closure$75$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$75.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$75<$Queue, $R>)this).st$128752 = ((x10.lang.PlaceLocalHandle)(st$128752));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$76<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$76> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$76> make($Closure$76.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$76<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$128752 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$76 $_obj = new x10.glb.Worker.$Closure$76((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$128752);
            
        }
        
        // constructor just for allocation
        public $Closure$76(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$76.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$76 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$76$$Queue$3x10$glb$Worker$$Closure$76$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 204 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$128742 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128752).$apply$G();
            
            //#line 204 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128742).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128752;
        
        public $Closure$76(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128752, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$76$$Queue$3x10$glb$Worker$$Closure$76$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$76.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$76<$Queue, $R>)this).st$128752 = ((x10.lang.PlaceLocalHandle)(st$128752));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$77<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$77> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$77> make($Closure$77.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$77<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            $_obj.victim = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$77 $_obj = new x10.glb.Worker.$Closure$77((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot);
            $serializer.write(this.st);
            $serializer.write(this.victim);
            
        }
        
        // constructor just for allocation
        public $Closure$77(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$77.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$77 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$77$$Queue$3x10$glb$Worker$$Closure$77$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 168 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128287 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 168 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128287).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)), ((x10.glb.TaskBag)(this.loot)), (long)(this.victim));
            
            //#line 168 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128288 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 168 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128288).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        public x10.glb.TaskBag loot;
        public long victim;
        
        public $Closure$77(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final x10.glb.TaskBag loot, final long victim, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$77$$Queue$3x10$glb$Worker$$Closure$77$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$77.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$77<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
                ((x10.glb.Worker.$Closure$77<$Queue, $R>)this).loot = ((x10.glb.TaskBag)(loot));
                ((x10.glb.Worker.$Closure$77<$Queue, $R>)this).victim = victim;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$78<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$78> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$78> make($Closure$78.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$78<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$78 $_obj = new x10.glb.Worker.$Closure$78((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$78(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$78.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$78 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$78$$Queue$3x10$glb$Worker$$Closure$78$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 171 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128293 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 171 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128293).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)), ((x10.glb.TaskBag)(this.loot)), (long)(-1L));
            
            //#line 171 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128294 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 171 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128294).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        public x10.glb.TaskBag loot;
        
        public $Closure$78(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final x10.glb.TaskBag loot, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$78$$Queue$3x10$glb$Worker$$Closure$78$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$78.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$78<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
                ((x10.glb.Worker.$Closure$78<$Queue, $R>)this).loot = ((x10.glb.TaskBag)(loot));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$79<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$79> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$79> make($Closure$79.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$79<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            $_obj.victim = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$79 $_obj = new x10.glb.Worker.$Closure$79((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot);
            $serializer.write(this.st);
            $serializer.write(this.victim);
            
        }
        
        // constructor just for allocation
        public $Closure$79(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$79.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$79 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$79$$Queue$3x10$glb$Worker$$Closure$79$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 176 "x10/glb/Worker.x10"
            try {{
                
                //#line 176 "x10/glb/Worker.x10"
                final x10.glb.Worker t$128302 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 176 "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$128302).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)), ((x10.glb.TaskBag)(this.loot)), (long)(this.victim));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 176 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 176 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        public x10.glb.TaskBag loot;
        public long victim;
        
        public $Closure$79(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final x10.glb.TaskBag loot, final long victim, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$79$$Queue$3x10$glb$Worker$$Closure$79$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$79.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$79<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
                ((x10.glb.Worker.$Closure$79<$Queue, $R>)this).loot = ((x10.glb.TaskBag)(loot));
                ((x10.glb.Worker.$Closure$79<$Queue, $R>)this).victim = victim;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$80<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$80> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$80> make($Closure$80.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$80<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$128797 = $deserializer.readObject();
            $_obj.st$128796 = $deserializer.readObject();
            $_obj.victim$128757 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$80 $_obj = new x10.glb.Worker.$Closure$80((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$128797);
            $serializer.write(this.st$128796);
            $serializer.write(this.victim$128757);
            
        }
        
        // constructor just for allocation
        public $Closure$80(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$80.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$80 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$80$$Queue$3x10$glb$Worker$$Closure$80$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 168 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$128776 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128796).$apply$G();
            
            //#line 168 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128776).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$128796)), ((x10.glb.TaskBag)(this.loot$128797)), (long)(this.victim$128757));
            
            //#line 168 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$128777 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128796).$apply$G();
            
            //#line 168 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128777).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128796;
        public x10.glb.TaskBag loot$128797;
        public long victim$128757;
        
        public $Closure$80(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128796, final x10.glb.TaskBag loot$128797, final long victim$128757, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$80$$Queue$3x10$glb$Worker$$Closure$80$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$80.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$80<$Queue, $R>)this).st$128796 = ((x10.lang.PlaceLocalHandle)(st$128796));
                ((x10.glb.Worker.$Closure$80<$Queue, $R>)this).loot$128797 = ((x10.glb.TaskBag)(loot$128797));
                ((x10.glb.Worker.$Closure$80<$Queue, $R>)this).victim$128757 = victim$128757;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$81<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$81> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$81> make($Closure$81.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$81<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$128797 = $deserializer.readObject();
            $_obj.st$128796 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$81 $_obj = new x10.glb.Worker.$Closure$81((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$128797);
            $serializer.write(this.st$128796);
            
        }
        
        // constructor just for allocation
        public $Closure$81(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$81.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$81 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$81$$Queue$3x10$glb$Worker$$Closure$81$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 171 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$128782 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128796).$apply$G();
            
            //#line 171 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128782).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$128796)), ((x10.glb.TaskBag)(this.loot$128797)), (long)(-1L));
            
            //#line 171 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$128783 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128796).$apply$G();
            
            //#line 171 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128783).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128796;
        public x10.glb.TaskBag loot$128797;
        
        public $Closure$81(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128796, final x10.glb.TaskBag loot$128797, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$81$$Queue$3x10$glb$Worker$$Closure$81$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$81.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$81<$Queue, $R>)this).st$128796 = ((x10.lang.PlaceLocalHandle)(st$128796));
                ((x10.glb.Worker.$Closure$81<$Queue, $R>)this).loot$128797 = ((x10.glb.TaskBag)(loot$128797));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$82<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$82> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$82> make($Closure$82.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$82<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$128797 = $deserializer.readObject();
            $_obj.st$128796 = $deserializer.readObject();
            $_obj.victim$128757 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$82 $_obj = new x10.glb.Worker.$Closure$82((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$128797);
            $serializer.write(this.st$128796);
            $serializer.write(this.victim$128757);
            
        }
        
        // constructor just for allocation
        public $Closure$82(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$82.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$82 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$82$$Queue$3x10$glb$Worker$$Closure$82$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 176 . "x10/glb/Worker.x10"
            try {{
                
                //#line 176 . "x10/glb/Worker.x10"
                final x10.glb.Worker t$128794 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128796).$apply$G();
                
                //#line 176 . "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$128794).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$128796)), ((x10.glb.TaskBag)(this.loot$128797)), (long)(this.victim$128757));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 176 . "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 176 . "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128796;
        public x10.glb.TaskBag loot$128797;
        public long victim$128757;
        
        public $Closure$82(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128796, final x10.glb.TaskBag loot$128797, final long victim$128757, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$82$$Queue$3x10$glb$Worker$$Closure$82$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$82.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$82<$Queue, $R>)this).st$128796 = ((x10.lang.PlaceLocalHandle)(st$128796));
                ((x10.glb.Worker.$Closure$82<$Queue, $R>)this).loot$128797 = ((x10.glb.TaskBag)(loot$128797));
                ((x10.glb.Worker.$Closure$82<$Queue, $R>)this).victim$128757 = victim$128757;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$83<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$83> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$83> make($Closure$83.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$83<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$83 $_obj = new x10.glb.Worker.$Closure$83((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$83(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$83.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$83 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$83$$Queue$3x10$glb$Worker$$Closure$83$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 202 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128815 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 202 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128815).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$83(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$83$$Queue$3x10$glb$Worker$$Closure$83$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$83.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$83<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$84<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$84> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$84> make($Closure$84.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$84<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$84 $_obj = new x10.glb.Worker.$Closure$84((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$84(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$84.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$84 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$84$$Queue$3x10$glb$Worker$$Closure$84$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 204 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128817 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 204 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128817).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$84(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$84$$Queue$3x10$glb$Worker$$Closure$84$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$84.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$84<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$85<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$85> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$85> make($Closure$85.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$85<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.p = $deserializer.readLong();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$85 $_obj = new x10.glb.Worker.$Closure$85((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.p);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$85(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$85.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$85 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$85$$Queue$3x10$glb$Worker$$Closure$85$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 230 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128829 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 230 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128829).request__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)), (long)(this.p), (boolean)(false));
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        public long p;
        
        public $Closure$85(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final long p, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$85$$Queue$3x10$glb$Worker$$Closure$85$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$85.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$85<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
                ((x10.glb.Worker.$Closure$85<$Queue, $R>)this).p = p;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$86<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$86> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$86> make($Closure$86.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$86<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.p = $deserializer.readLong();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$86 $_obj = new x10.glb.Worker.$Closure$86((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.p);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$86(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$86.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$86 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$86$$Queue$3x10$glb$Worker$$Closure$86$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 241 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128846 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 241 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128846).request__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)), (long)(this.p), (boolean)(true));
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        public long p;
        
        public $Closure$86(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final long p, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$86$$Queue$3x10$glb$Worker$$Closure$86$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$86.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$86<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
                ((x10.glb.Worker.$Closure$86<$Queue, $R>)this).p = p;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$87<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$87> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$87> make($Closure$87.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$87<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$87 $_obj = new x10.glb.Worker.$Closure$87((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$87(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$87.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$87 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$87$$Queue$3x10$glb$Worker$$Closure$87$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 261 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128412 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 261 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128412).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$87(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$87$$Queue$3x10$glb$Worker$$Closure$87$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$87.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$87<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$88<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$88> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$88> make($Closure$88.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$88<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$88 $_obj = new x10.glb.Worker.$Closure$88((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$88(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$88.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$88 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$88$$Queue$3x10$glb$Worker$$Closure$88$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 408 "x10/glb/Worker.x10"
            try {{
                
                //#line 408 "x10/glb/Worker.x10"
                final x10.glb.Worker t$128912 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 408 "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$128912).main__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 408 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 408 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$88(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$88$$Queue$3x10$glb$Worker$$Closure$88$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$88.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$88<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$89<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$89> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$89> make($Closure$89.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$89<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$89 $_obj = new x10.glb.Worker.$Closure$89((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$89(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$89.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$89 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$89$$Queue$3x10$glb$Worker$$Closure$89$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 416 "x10/glb/Worker.x10"
            try {{
                
                //#line 416 "x10/glb/Worker.x10"
                final x10.glb.Worker t$128917 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 416 "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$128917).main__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 416 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 416 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$89(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$89$$Queue$3x10$glb$Worker$$Closure$89$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$89.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$89<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$90<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$90> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$90> make($Closure$90.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$90<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$90 $_obj = new x10.glb.Worker.$Closure$90((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$90(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$90.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$90 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$90$$Queue$3x10$glb$Worker$$Closure$90$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 412 "x10/glb/Worker.x10"
            try {{
                
                //#line 413 "x10/glb/Worker.x10"
                final long max$128925 = ((long)x10.x10rt.X10RT.hereId());
                
                //#line 414 "x10/glb/Worker.x10"
                final long t$128926 = ((max$128925) - (((long)(31L))));
                
                //#line 414 "x10/glb/Worker.x10"
                final long min$128927 = java.lang.Math.max(((long)(t$128926)),((long)(0L)));
                
                //#line 415 "x10/glb/Worker.x10"
                long j$128920 = min$128927;
                
                //#line 415 "x10/glb/Worker.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 415 "x10/glb/Worker.x10"
                    final boolean t$128922 = ((j$128920) <= (((long)(max$128925))));
                    
                    //#line 415 "x10/glb/Worker.x10"
                    if (!(t$128922)) {
                        
                        //#line 415 "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 416 "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$128916 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 416 "x10/glb/Worker.x10"
                    alloc$128916.x10$lang$Place$$init$S(j$128920);
                    
                    //#line 416 "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$128916)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$89<$Queue, $R>($Queue, $R, ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)(this.st)), (x10.glb.Worker.$Closure$89.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$89$$Queue$3x10$glb$Worker$$Closure$89$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    
                    //#line 415 "x10/glb/Worker.x10"
                    final long t$128919 = ((j$128920) + (((long)(1L))));
                    
                    //#line 415 "x10/glb/Worker.x10"
                    j$128920 = t$128919;
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 412 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 412 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$90(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$90$$Queue$3x10$glb$Worker$$Closure$90$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$90.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$90<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$91<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$91> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$91> make($Closure$91.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$91<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$91 $_obj = new x10.glb.Worker.$Closure$91((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$91(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$91.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$91 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$91$$Queue$3x10$glb$Worker$$Closure$91$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 432 "x10/glb/Worker.x10"
            try {{
                
                //#line 432 "x10/glb/Worker.x10"
                final x10.glb.Worker this$128935 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 461 . "x10/glb/Worker.x10"
                final x10.glb.Context alloc$128931 = ((x10.glb.Context)(new x10.glb.Context<$Queue, $R>((java.lang.System[]) null, $Queue, $R)));
                
                //#line 25 ... "x10/glb/Context.x10"
                final x10.lang.PlaceLocalHandle t$128930 = (x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>) x10.rtt.Types.zeroValue(x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, $Queue, $R)));
                
                //#line 20 ... "x10/glb/Context.x10"
                ((x10.glb.Context<$Queue, $R>)alloc$128931).st = t$128930;
                
                //#line 31 .. "x10/glb/Context.x10"
                ((x10.glb.Context<$Queue, $R>)alloc$128931).st = ((x10.lang.PlaceLocalHandle)(this.st));
                
                //#line 461 . "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)this$128935).context = ((x10.glb.Context)(alloc$128931));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 432 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 432 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$91(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$91$$Queue$3x10$glb$Worker$$Closure$91$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$91.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$91<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$92<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$92> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$92> make($Closure$92.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$92<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$92 $_obj = new x10.glb.Worker.$Closure$92((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$92(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$92.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$92 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$92$$Queue$3x10$glb$Worker$$Closure$92$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 440 "x10/glb/Worker.x10"
            try {{
                
                //#line 440 "x10/glb/Worker.x10"
                final x10.glb.Worker this$128944 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 461 . "x10/glb/Worker.x10"
                final x10.glb.Context alloc$128940 = ((x10.glb.Context)(new x10.glb.Context<$Queue, $R>((java.lang.System[]) null, $Queue, $R)));
                
                //#line 25 ... "x10/glb/Context.x10"
                final x10.lang.PlaceLocalHandle t$128939 = (x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>) x10.rtt.Types.zeroValue(x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, $Queue, $R)));
                
                //#line 20 ... "x10/glb/Context.x10"
                ((x10.glb.Context<$Queue, $R>)alloc$128940).st = t$128939;
                
                //#line 31 .. "x10/glb/Context.x10"
                ((x10.glb.Context<$Queue, $R>)alloc$128940).st = ((x10.lang.PlaceLocalHandle)(this.st));
                
                //#line 461 . "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)this$128944).context = ((x10.glb.Context)(alloc$128940));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 440 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 440 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$92(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$92$$Queue$3x10$glb$Worker$$Closure$92$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$92.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$92<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$93<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$93> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$93> make($Closure$93.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$93<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$93 $_obj = new x10.glb.Worker.$Closure$93((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$93(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$93.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$93 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$93$$Queue$3x10$glb$Worker$$Closure$93$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 436 "x10/glb/Worker.x10"
            try {{
                
                //#line 437 "x10/glb/Worker.x10"
                final long max$128953 = ((long)x10.x10rt.X10RT.hereId());
                
                //#line 438 "x10/glb/Worker.x10"
                final long t$128954 = ((max$128953) - (((long)(31L))));
                
                //#line 438 "x10/glb/Worker.x10"
                final long min$128955 = java.lang.Math.max(((long)(t$128954)),((long)(0L)));
                
                //#line 439 "x10/glb/Worker.x10"
                long j$128948 = min$128955;
                
                //#line 439 "x10/glb/Worker.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 439 "x10/glb/Worker.x10"
                    final boolean t$128950 = ((j$128948) <= (((long)(max$128953))));
                    
                    //#line 439 "x10/glb/Worker.x10"
                    if (!(t$128950)) {
                        
                        //#line 439 "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 440 "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$128943 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 440 "x10/glb/Worker.x10"
                    alloc$128943.x10$lang$Place$$init$S(j$128948);
                    
                    //#line 440 "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$128943)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$92<$Queue, $R>($Queue, $R, ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)(this.st)), (x10.glb.Worker.$Closure$92.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$92$$Queue$3x10$glb$Worker$$Closure$92$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    
                    //#line 439 "x10/glb/Worker.x10"
                    final long t$128947 = ((j$128948) + (((long)(1L))));
                    
                    //#line 439 "x10/glb/Worker.x10"
                    j$128948 = t$128947;
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 436 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 436 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$93(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$93$$Queue$3x10$glb$Worker$$Closure$93$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$93.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$93<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$94<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$94> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$94> make($Closure$94.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$94<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$128999 = $deserializer.readObject();
            $_obj.st$128998 = $deserializer.readObject();
            $_obj.victim$128960 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$94 $_obj = new x10.glb.Worker.$Closure$94((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$128999);
            $serializer.write(this.st$128998);
            $serializer.write(this.victim$128960);
            
        }
        
        // constructor just for allocation
        public $Closure$94(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$94.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$94 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$94$$Queue$3x10$glb$Worker$$Closure$94$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 168 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$128979 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128998).$apply$G();
            
            //#line 168 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128979).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$128998)), ((x10.glb.TaskBag)(this.loot$128999)), (long)(this.victim$128960));
            
            //#line 168 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$128980 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128998).$apply$G();
            
            //#line 168 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128980).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128998;
        public x10.glb.TaskBag loot$128999;
        public long victim$128960;
        
        public $Closure$94(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128998, final x10.glb.TaskBag loot$128999, final long victim$128960, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$94$$Queue$3x10$glb$Worker$$Closure$94$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$94.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$94<$Queue, $R>)this).st$128998 = ((x10.lang.PlaceLocalHandle)(st$128998));
                ((x10.glb.Worker.$Closure$94<$Queue, $R>)this).loot$128999 = ((x10.glb.TaskBag)(loot$128999));
                ((x10.glb.Worker.$Closure$94<$Queue, $R>)this).victim$128960 = victim$128960;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$95<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$95> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$95> make($Closure$95.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$95<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$128999 = $deserializer.readObject();
            $_obj.st$128998 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$95 $_obj = new x10.glb.Worker.$Closure$95((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$128999);
            $serializer.write(this.st$128998);
            
        }
        
        // constructor just for allocation
        public $Closure$95(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$95.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$95 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$95$$Queue$3x10$glb$Worker$$Closure$95$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 171 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$128985 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128998).$apply$G();
            
            //#line 171 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128985).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$128998)), ((x10.glb.TaskBag)(this.loot$128999)), (long)(-1L));
            
            //#line 171 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$128986 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128998).$apply$G();
            
            //#line 171 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128986).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128998;
        public x10.glb.TaskBag loot$128999;
        
        public $Closure$95(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128998, final x10.glb.TaskBag loot$128999, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$95$$Queue$3x10$glb$Worker$$Closure$95$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$95.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$95<$Queue, $R>)this).st$128998 = ((x10.lang.PlaceLocalHandle)(st$128998));
                ((x10.glb.Worker.$Closure$95<$Queue, $R>)this).loot$128999 = ((x10.glb.TaskBag)(loot$128999));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$96<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$96> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$96> make($Closure$96.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$96<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$128999 = $deserializer.readObject();
            $_obj.st$128998 = $deserializer.readObject();
            $_obj.victim$128960 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$96 $_obj = new x10.glb.Worker.$Closure$96((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$128999);
            $serializer.write(this.st$128998);
            $serializer.write(this.victim$128960);
            
        }
        
        // constructor just for allocation
        public $Closure$96(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$96.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$96 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$96$$Queue$3x10$glb$Worker$$Closure$96$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 176 .. "x10/glb/Worker.x10"
            try {{
                
                //#line 176 .. "x10/glb/Worker.x10"
                final x10.glb.Worker t$128997 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128998).$apply$G();
                
                //#line 176 .. "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$128997).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$128998)), ((x10.glb.TaskBag)(this.loot$128999)), (long)(this.victim$128960));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 176 .. "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 176 .. "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128998;
        public x10.glb.TaskBag loot$128999;
        public long victim$128960;
        
        public $Closure$96(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128998, final x10.glb.TaskBag loot$128999, final long victim$128960, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$96$$Queue$3x10$glb$Worker$$Closure$96$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$96.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$96<$Queue, $R>)this).st$128998 = ((x10.lang.PlaceLocalHandle)(st$128998));
                ((x10.glb.Worker.$Closure$96<$Queue, $R>)this).loot$128999 = ((x10.glb.TaskBag)(loot$128999));
                ((x10.glb.Worker.$Closure$96<$Queue, $R>)this).victim$128960 = victim$128960;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$97<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$97> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$97> make($Closure$97.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$97<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$128080 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$97 $_obj = new x10.glb.Worker.$Closure$97((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$128080);
            
        }
        
        // constructor just for allocation
        public $Closure$97(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$97.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$97 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$97$$Queue$3x10$glb$Worker$$Closure$97$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 202 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$129017 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128080).$apply$G();
            
            //#line 202 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129017).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128080;
        
        public $Closure$97(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128080, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$97$$Queue$3x10$glb$Worker$$Closure$97$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$97.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$97<$Queue, $R>)this).st$128080 = ((x10.lang.PlaceLocalHandle)(st$128080));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$98<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$98> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$98> make($Closure$98.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$98<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$128080 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$98 $_obj = new x10.glb.Worker.$Closure$98((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$128080);
            
        }
        
        // constructor just for allocation
        public $Closure$98(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$98.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$98 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$98$$Queue$3x10$glb$Worker$$Closure$98$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 204 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$129019 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128080).$apply$G();
            
            //#line 204 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129019).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128080;
        
        public $Closure$98(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128080, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$98$$Queue$3x10$glb$Worker$$Closure$98$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$98.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$98<$Queue, $R>)this).st$128080 = ((x10.lang.PlaceLocalHandle)(st$128080));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$99<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$99> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$99> make($Closure$99.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_1.$RTT, x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1))))
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$99<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$99 $_obj = new x10.glb.Worker.$Closure$99((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$99(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$99.$initParams(this, $Queue, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$99$$Queue$3x10$glb$Worker$$Closure$99$$R$2$2((x10.lang.PlaceLocalHandle)a1); return null;
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$99$$Queue$3x10$glb$Worker$$Closure$99$$R$2$2((x10.lang.PlaceLocalHandle)a1);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$99 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$$Closure$99$$Queue$3x10$glb$Worker$$Closure$99$$R$2 {}
        
    
        
        public void $apply__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$99$$Queue$3x10$glb$Worker$$Closure$99$$R$2$2(final x10.lang.PlaceLocalHandle st) {
            
            //#line 452 "x10/glb/Worker.x10"
            x10.xrx.Runtime.probe();
            
            //#line 452 "x10/glb/Worker.x10"
            final x10.glb.Worker this$128055 = ((x10.glb.Worker)(this.out$$));
            
            //#line 452 "x10/glb/Worker.x10"
            final x10.lang.PlaceLocalHandle st$128053 = ((x10.lang.PlaceLocalHandle)(st));
            
            //#line 186 . "x10/glb/Worker.x10"
            x10.glb.TaskBag loot$129020 =  null;
            
            //#line 187 . "x10/glb/Worker.x10"
            while (true) {
                
                //#line 187 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$129021 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128055).thieves));
                
                //#line 55 .. "x10/glb/FixedSizeStack.x10"
                final long t$129022 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129021).size;
                
                //#line 187 . "x10/glb/Worker.x10"
                boolean t$129023 = ((t$129022) > (((long)(0L))));
                
                //#line 187 . "x10/glb/Worker.x10"
                if (!(t$129023)) {
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$129024 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128055).lifelineThieves));
                    
                    //#line 55 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129025 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129024).size;
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    t$129023 = ((t$129025) > (((long)(0L))));
                }
                
                //#line 187 . "x10/glb/Worker.x10"
                boolean t$129026 = t$129023;
                
                //#line 187 . "x10/glb/Worker.x10"
                if (t$129023) {
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    final $Queue t$129027 = (($Queue)(((x10.glb.Worker<$Queue, $R>)this$128055).queue));
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    final x10.glb.TaskBag t$129028 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$129027)).split();
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    final x10.glb.TaskBag t$129029 = loot$129020 = ((x10.glb.TaskBag)(t$129028));
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    t$129026 = ((t$129029) != (null));
                }
                
                //#line 187 . "x10/glb/Worker.x10"
                if (!(t$129026)) {
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 188 . "x10/glb/Worker.x10"
                final x10.lang.PlaceLocalHandle st$128998 = ((x10.lang.PlaceLocalHandle)(st$128053));
                
                //#line 188 . "x10/glb/Worker.x10"
                final x10.glb.TaskBag loot$128999 = ((x10.glb.TaskBag)(loot$129020));
                
                //#line 162 .. "x10/glb/Worker.x10"
                final long victim$128960 = ((long)x10.x10rt.X10RT.hereId());
                
                //#line 163 .. "x10/glb/Worker.x10"
                final x10.glb.Logger obj$128961 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128055).logger));
                
                //#line 163 .. "x10/glb/Worker.x10"
                final long t$128962 = obj$128961.nodesGiven;
                
                //#line 163 .. "x10/glb/Worker.x10"
                final long t$128963 = loot$129020.size$O();
                
                //#line 163 .. "x10/glb/Worker.x10"
                final long t$128964 = ((t$128962) + (((long)(t$128963))));
                
                //#line 163 .. "x10/glb/Worker.x10"
                obj$128961.nodesGiven = t$128964;
                
                //#line 164 .. "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$128965 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128055).thieves));
                
                //#line 55 ... "x10/glb/FixedSizeStack.x10"
                final long t$128966 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128965).size;
                
                //#line 164 .. "x10/glb/Worker.x10"
                final boolean t$128967 = ((t$128966) > (((long)(0L))));
                
                //#line 164 .. "x10/glb/Worker.x10"
                if (t$128967) {
                    
                    //#line 165 .. "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128968 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128055).thieves));
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$128969 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128968).data));
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final long t$128970 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128968).size;
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final long t$128971 = ((t$128970) - (((long)(1L))));
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final long t$128972 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128968).size = t$128971;
                    
                    //#line 165 .. "x10/glb/Worker.x10"
                    final long thief$128973 = ((long[])t$128969.value)[(int)t$128972];
                    
                    //#line 166 .. "x10/glb/Worker.x10"
                    final boolean t$128974 = ((thief$128973) >= (((long)(0L))));
                    
                    //#line 166 .. "x10/glb/Worker.x10"
                    if (t$128974) {
                        
                        //#line 167 .. "x10/glb/Worker.x10"
                        final x10.glb.Logger obj$128975 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128055).logger));
                        
                        //#line 167 .. "x10/glb/Worker.x10"
                        final long t$128976 = obj$128975.lifelineStealsSuffered;
                        
                        //#line 167 .. "x10/glb/Worker.x10"
                        final long t$128977 = ((t$128976) + (((long)(1L))));
                        
                        //#line 167 .. "x10/glb/Worker.x10"
                        obj$128975.lifelineStealsSuffered = t$128977;
                        
                        //#line 168 .. "x10/glb/Worker.x10"
                        final x10.lang.Place alloc$128978 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 168 .. "x10/glb/Worker.x10"
                        alloc$128978.x10$lang$Place$$init$S(((long)(thief$128973)));
                        
                        //#line 168 .. "x10/glb/Worker.x10"
                        x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128978)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$94<$Queue, $R>($Queue, $R, st$128998, loot$128999, victim$128960, (x10.glb.Worker.$Closure$94.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$94$$Queue$3x10$glb$Worker$$Closure$94$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    } else {
                        
                        //#line 170 .. "x10/glb/Worker.x10"
                        final x10.glb.Logger obj$128981 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128055).logger));
                        
                        //#line 170 .. "x10/glb/Worker.x10"
                        final long t$128982 = obj$128981.stealsSuffered;
                        
                        //#line 170 .. "x10/glb/Worker.x10"
                        final long t$128983 = ((t$128982) + (((long)(1L))));
                        
                        //#line 170 .. "x10/glb/Worker.x10"
                        obj$128981.stealsSuffered = t$128983;
                        
                        //#line 171 .. "x10/glb/Worker.x10"
                        final x10.lang.Place alloc$128984 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 171 .. "x10/glb/Worker.x10"
                        final long t$128958 = (-(thief$128973));
                        
                        //#line 171 .. "x10/glb/Worker.x10"
                        final long t$128959 = ((t$128958) - (((long)(1L))));
                        
                        //#line 171 .. "x10/glb/Worker.x10"
                        alloc$128984.x10$lang$Place$$init$S(t$128959);
                        
                        //#line 171 .. "x10/glb/Worker.x10"
                        x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$128984)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$95<$Queue, $R>($Queue, $R, st$128998, loot$128999, (x10.glb.Worker.$Closure$95.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$95$$Queue$3x10$glb$Worker$$Closure$95$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                } else {
                    
                    //#line 174 .. "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$128987 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128055).logger));
                    
                    //#line 174 .. "x10/glb/Worker.x10"
                    final long t$128988 = obj$128987.lifelineStealsSuffered;
                    
                    //#line 174 .. "x10/glb/Worker.x10"
                    final long t$128989 = ((t$128988) + (((long)(1L))));
                    
                    //#line 174 .. "x10/glb/Worker.x10"
                    obj$128987.lifelineStealsSuffered = t$128989;
                    
                    //#line 175 .. "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128990 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128055).lifelineThieves));
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$128991 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128990).data));
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final long t$128992 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128990).size;
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final long t$128993 = ((t$128992) - (((long)(1L))));
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final long t$128994 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128990).size = t$128993;
                    
                    //#line 175 .. "x10/glb/Worker.x10"
                    final long thief$128995 = ((long[])t$128991.value)[(int)t$128994];
                    
                    //#line 176 .. "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$128996 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 176 .. "x10/glb/Worker.x10"
                    alloc$128996.x10$lang$Place$$init$S(((long)(thief$128995)));
                    
                    //#line 176 .. "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$128996)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$96<$Queue, $R>($Queue, $R, st$128998, loot$128999, victim$128960, (x10.glb.Worker.$Closure$96.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$96$$Queue$3x10$glb$Worker$$Closure$96$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                }
            }
            
            //#line 452 "x10/glb/Worker.x10"
            final x10.glb.Worker this$128084 = ((x10.glb.Worker)(this.out$$));
            
            //#line 452 "x10/glb/Worker.x10"
            final x10.lang.PlaceLocalHandle st$128080 = ((x10.lang.PlaceLocalHandle)(st));
            
            //#line 198 . "x10/glb/Worker.x10"
            while (true) {
                
                //#line 198 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$129031 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128084).thieves));
                
                //#line 55 .. "x10/glb/FixedSizeStack.x10"
                final long t$129032 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129031).size;
                
                //#line 198 . "x10/glb/Worker.x10"
                final boolean t$129033 = ((t$129032) > (((long)(0L))));
                
                //#line 198 . "x10/glb/Worker.x10"
                if (!(t$129033)) {
                    
                    //#line 198 . "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 199 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$129007 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128084).thieves));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final x10.core.Rail t$129008 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129007).data));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129009 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129007).size;
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129010 = ((t$129009) - (((long)(1L))));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129011 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129007).size = t$129010;
                
                //#line 199 . "x10/glb/Worker.x10"
                final long thief$129012 = ((long[])t$129008.value)[(int)t$129011];
                
                //#line 200 . "x10/glb/Worker.x10"
                final boolean t$129013 = ((thief$129012) >= (((long)(0L))));
                
                //#line 200 . "x10/glb/Worker.x10"
                if (t$129013) {
                    
                    //#line 201 . "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$129014 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128084).lifelineThieves));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$129000 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129014).data));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129001 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129014).size;
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129002 = ((t$129001) + (((long)(1L))));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129003 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129014).size = t$129002;
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129004 = ((t$129003) - (((long)(1L))));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    ((long[])t$129000.value)[(int)t$129004] = thief$129012;
                    
                    //#line 202 . "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$129016 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 202 . "x10/glb/Worker.x10"
                    alloc$129016.x10$lang$Place$$init$S(((long)(thief$129012)));
                    
                    //#line 202 . "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129016)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$97<$Queue, $R>($Queue, $R, st$128080, (x10.glb.Worker.$Closure$97.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$97$$Queue$3x10$glb$Worker$$Closure$97$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                } else {
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$129018 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    final long t$129005 = (-(thief$129012));
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    final long t$129006 = ((t$129005) - (((long)(1L))));
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    alloc$129018.x10$lang$Place$$init$S(t$129006);
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129018)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$98<$Queue, $R>($Queue, $R, st$128080, (x10.glb.Worker.$Closure$98.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$98$$Queue$3x10$glb$Worker$$Closure$98$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                }
            }
        }
        
        public x10.glb.Worker<$Queue, $R> out$$;
        
        public $Closure$99(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.Worker<$Queue, $R> out$$, __0$1x10$glb$Worker$$Closure$99$$Queue$3x10$glb$Worker$$Closure$99$$R$2 $dummy) {
            x10.glb.Worker.$Closure$99.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$99<$Queue, $R>)this).out$$ = out$$;
            }
        }
        
    }
    
    }
    
    