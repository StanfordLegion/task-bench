package x10.glb;


/**
 * <p>The top level class of the Global Load Balancing (GLB) framework.
 * </p>
 */
@x10.runtime.impl.java.X10Generated
final public class GLB<$Queue, $R> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<GLB> $RTT = 
        x10.rtt.NamedType.<GLB> make("x10.glb.GLB",
                                     GLB.class,
                                     2);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
        $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
        $_obj.P = $deserializer.readLong();
        $_obj.collectResultTime = $deserializer.readLong();
        $_obj.crunchNumberTime = $deserializer.readLong();
        $_obj.glbParams = $deserializer.readObject();
        $_obj.plh = $deserializer.readObject();
        $_obj.rootGlbR = $deserializer.readObject();
        $_obj.setupTime = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.glb.GLB $_obj = new x10.glb.GLB((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$Queue);
        $serializer.write(this.$R);
        $serializer.write(this.P);
        $serializer.write(this.collectResultTime);
        $serializer.write(this.crunchNumberTime);
        $serializer.write(this.glbParams);
        $serializer.write(this.plh);
        $serializer.write(this.rootGlbR);
        $serializer.write(this.setupTime);
        
    }
    
    // constructor just for allocation
    public GLB(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
        x10.glb.GLB.$initParams(this, $Queue, $R);
        
    }
    
    private x10.rtt.Type $Queue;
    private x10.rtt.Type $R;
    
    // initializer of type parameters
    public static void $initParams(final GLB $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
        $this.$Queue = $Queue;
        $this.$R = $R;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$glb$GLB$$Queue$2 {}
    

    
    //#line 25 "x10/glb/GLB.x10"
    /**
     * Number of places.
     */
    public long P;
    
    //#line 29 "x10/glb/GLB.x10"
    /**
     * Home PlaceLocalHandle of {@link Worker}
     */
    public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> plh;
    
    //#line 34 "x10/glb/GLB.x10"
    /**
     * Workload initialization time.
     */
    public long setupTime;
    
    //#line 38 "x10/glb/GLB.x10"
    /**
     * Computation time.
     */
    public long crunchNumberTime;
    
    //#line 42 "x10/glb/GLB.x10"
    /**
     * Result collection time.
     */
    public long collectResultTime;
    
    //#line 47 "x10/glb/GLB.x10"
    /**
     * {@link GLBResult at root. Used as a vehicle to collect results.}
     */
    public x10.glb.GLBResult<$R> rootGlbR;
    
    
    //#line 52 "x10/glb/GLB.x10"
    /**
     * Min helper method.
     */
    public static long min$O(final long i, final long j) {
        
        //#line 52 "x10/glb/GLB.x10"
        final boolean t$127085 = ((i) < (((long)(j))));
        
        //#line 52 "x10/glb/GLB.x10"
        long t$127086 =  0;
        
        //#line 52 "x10/glb/GLB.x10"
        if (t$127085) {
            
            //#line 52 "x10/glb/GLB.x10"
            t$127086 = i;
        } else {
            
            //#line 52 "x10/glb/GLB.x10"
            t$127086 = j;
        }
        
        //#line 52 "x10/glb/GLB.x10"
        return t$127086;
    }
    
    
    //#line 57 "x10/glb/GLB.x10"
    /**
     * GLB Parameters. {@link GLBParameters}
     */
    public x10.glb.GLBParameters glbParams;
    
    
    //#line 65 "x10/glb/GLB.x10"
    /**
     * Constructor
     * @param init function closure that can initialize {@link TaskQueue}
     * @param glbParams GLB parameters
     * @tree true if workload is dynamically generated, false if workload can be known upfront. 
     */
    // creation method for java code (1-phase java constructor)
    public GLB(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.core.fun.Fun_0_0<$Queue> init, final x10.glb.GLBParameters glbParams, final boolean tree, __0$1x10$glb$GLB$$Queue$2 $dummy) {
        this((java.lang.System[]) null, $Queue, $R);
        x10$glb$GLB$$init$S(init, glbParams, tree, (x10.glb.GLB.__0$1x10$glb$GLB$$Queue$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.glb.GLB<$Queue, $R> x10$glb$GLB$$init$S(final x10.core.fun.Fun_0_0<$Queue> init, final x10.glb.GLBParameters glbParams, final boolean tree, __0$1x10$glb$GLB$$Queue$2 $dummy) {
         {
            
            //#line 65 "x10/glb/GLB.x10"
            
            
            //#line 21 "x10/glb/GLB.x10"
            this.__fieldInitializers_x10_glb_GLB();
            
            //#line 66 "x10/glb/GLB.x10"
            ((x10.glb.GLB<$Queue, $R>)this).glbParams = ((x10.glb.GLBParameters)(glbParams));
            
            //#line 40 . "x10/lang/System.x10"
            final long t$127088 = java.lang.System.nanoTime();
            
            //#line 67 "x10/glb/GLB.x10"
            ((x10.glb.GLB<$Queue, $R>)this).setupTime = t$127088;
            
            //#line 68 "x10/glb/GLB.x10"
            final x10.lang.PlaceGroup t$127094 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 69 "x10/glb/GLB.x10"
            final x10.core.fun.Fun_0_0 t$127095 = ((x10.core.fun.Fun_0_0)(new x10.glb.GLB.$Closure$61<$Queue, $R>($Queue, $R, glbParams, init, tree, (x10.glb.GLB.$Closure$61.__1$1x10$glb$GLB$$Closure$61$$Queue$2) null)));
            
            //#line 68 "x10/glb/GLB.x10"
            final x10.lang.PlaceLocalHandle t$127096 = x10.lang.PlaceLocalHandle.<x10.glb.Worker<$Queue, $R>> makeFlat__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, $Queue, $R), ((x10.lang.PlaceGroup)(t$127094)), ((x10.core.fun.Fun_0_0)(t$127095)));
            
            //#line 68 "x10/glb/GLB.x10"
            ((x10.glb.GLB<$Queue, $R>)this).plh = ((x10.lang.PlaceLocalHandle)(t$127096));
            
            //#line 70 "x10/glb/GLB.x10"
            final x10.lang.PlaceLocalHandle t$127097 = ((x10.lang.PlaceLocalHandle)(this.plh));
            
            //#line 70 "x10/glb/GLB.x10"
            x10.glb.Worker.<$Queue, $R> initContexts__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2($Queue, $R, ((x10.lang.PlaceLocalHandle)(t$127097)));
            
            //#line 40 . "x10/lang/System.x10"
            final long t$127098 = java.lang.System.nanoTime();
            
            //#line 71 "x10/glb/GLB.x10"
            final long t$127099 = this.setupTime;
            
            //#line 71 "x10/glb/GLB.x10"
            final long t$127100 = ((t$127098) - (((long)(t$127099))));
            
            //#line 71 "x10/glb/GLB.x10"
            ((x10.glb.GLB<$Queue, $R>)this).setupTime = t$127100;
        }
        return this;
    }
    
    
    
    //#line 77 "x10/glb/GLB.x10"
    /**
     * Returns Home {@link TaskQueue}
     */
    public $Queue taskQueue$G() {
        
        //#line 77 "x10/glb/GLB.x10"
        final x10.lang.PlaceLocalHandle t$127101 = ((x10.lang.PlaceLocalHandle)(this.plh));
        
        //#line 77 "x10/glb/GLB.x10"
        final x10.glb.Worker t$127102 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)t$127101).$apply$G();
        
        //#line 77 "x10/glb/GLB.x10"
        final $Queue t$127103 = (($Queue)(((x10.glb.Worker<$Queue, $R>)t$127102).queue));
        
        //#line 77 "x10/glb/GLB.x10"
        return t$127103;
    }
    
    
    //#line 84 "x10/glb/GLB.x10"
    /**
     * Run method. This method is called when users does not know the workload upfront.
     * @param start The method that (Root) initializes the workload that can start computation.
     * Other places first get their workload by stealing.
     */
    public x10.core.Rail run(final x10.core.fun.VoidFun_0_0 start) {
        
        //#line 40 . "x10/lang/System.x10"
        final long t$127104 = java.lang.System.nanoTime();
        
        //#line 85 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).crunchNumberTime = t$127104;
        
        //#line 86 "x10/glb/GLB.x10"
        final x10.lang.PlaceLocalHandle t$127105 = ((x10.lang.PlaceLocalHandle)(this.plh));
        
        //#line 86 "x10/glb/GLB.x10"
        final x10.glb.Worker t$127106 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)t$127105).$apply$G();
        
        //#line 86 "x10/glb/GLB.x10"
        final x10.lang.PlaceLocalHandle t$127107 = ((x10.lang.PlaceLocalHandle)(this.plh));
        
        //#line 86 "x10/glb/GLB.x10"
        ((x10.glb.Worker<$Queue, $R>)t$127106).main__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(t$127107)), ((x10.core.fun.VoidFun_0_0)(start)));
        
        //#line 40 . "x10/lang/System.x10"
        final long t$127108 = java.lang.System.nanoTime();
        
        //#line 87 "x10/glb/GLB.x10"
        final long t$127109 = this.crunchNumberTime;
        
        //#line 87 "x10/glb/GLB.x10"
        final long t$127110 = ((t$127108) - (((long)(t$127109))));
        
        //#line 87 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).crunchNumberTime = t$127110;
        
        //#line 88 "x10/glb/GLB.x10"
        final x10.core.Rail r = ((x10.core.Rail<$R>)
                                  this.collectResults());
        
        //#line 90 "x10/glb/GLB.x10"
        this.end__0$1x10$glb$GLB$$R$2(((x10.core.Rail)(r)));
        
        //#line 91 "x10/glb/GLB.x10"
        return r;
    }
    
    
    //#line 98 "x10/glb/GLB.x10"
    /**
     * Run method. This method is called when users can know the workload upfront and initialize the
     * workload in {@link TaskQueue}
     */
    public x10.core.Rail runParallel() {
        
        //#line 40 . "x10/lang/System.x10"
        final long t$127111 = java.lang.System.nanoTime();
        
        //#line 99 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).crunchNumberTime = t$127111;
        
        //#line 100 "x10/glb/GLB.x10"
        final x10.lang.PlaceLocalHandle t$127112 = ((x10.lang.PlaceLocalHandle)(this.plh));
        
        //#line 100 "x10/glb/GLB.x10"
        x10.glb.Worker.<$Queue, $R> broadcast__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2($Queue, $R, ((x10.lang.PlaceLocalHandle)(t$127112)));
        
        //#line 40 . "x10/lang/System.x10"
        final long t$127113 = java.lang.System.nanoTime();
        
        //#line 101 "x10/glb/GLB.x10"
        final long t$127114 = this.crunchNumberTime;
        
        //#line 101 "x10/glb/GLB.x10"
        final long t$127115 = ((t$127113) - (((long)(t$127114))));
        
        //#line 101 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).crunchNumberTime = t$127115;
        
        //#line 102 "x10/glb/GLB.x10"
        final x10.core.Rail r = ((x10.core.Rail<$R>)
                                  this.collectResults());
        
        //#line 103 "x10/glb/GLB.x10"
        this.end__0$1x10$glb$GLB$$R$2(((x10.core.Rail)(r)));
        
        //#line 104 "x10/glb/GLB.x10"
        return r;
    }
    
    
    //#line 113 "x10/glb/GLB.x10"
    /**
     * Print various GLB-related information, including result; time spent in initialization, computation 
     * and result collection; any user specified log information (per place); and GLB statistics.
     * @param r result to print
     */
    private void end__0$1x10$glb$GLB$$R$2(final x10.core.Rail r) {
        
        //#line 114 "x10/glb/GLB.x10"
        final x10.glb.GLBParameters t$127116 = ((x10.glb.GLBParameters)(this.glbParams));
        
        //#line 114 "x10/glb/GLB.x10"
        final int t$127117 = t$127116.v;
        
        //#line 114 "x10/glb/GLB.x10"
        final int t$127118 = ((t$127117) & (((int)(1))));
        
        //#line 114 "x10/glb/GLB.x10"
        final boolean t$127120 = ((int) t$127118) != ((int) 0);
        
        //#line 114 "x10/glb/GLB.x10"
        if (t$127120) {
            
            //#line 115 "x10/glb/GLB.x10"
            final x10.glb.GLBResult t$127119 = ((x10.glb.GLBResult)(this.rootGlbR));
            
            //#line 115 "x10/glb/GLB.x10"
            ((x10.glb.GLBResult<$R>)t$127119).display__0$1x10$glb$GLBResult$$R$2(((x10.core.Rail)(r)));
        }
        
        //#line 117 "x10/glb/GLB.x10"
        final x10.glb.GLBParameters t$127121 = ((x10.glb.GLBParameters)(this.glbParams));
        
        //#line 117 "x10/glb/GLB.x10"
        final int t$127122 = t$127121.v;
        
        //#line 117 "x10/glb/GLB.x10"
        final int t$127123 = ((t$127122) & (((int)(2))));
        
        //#line 117 "x10/glb/GLB.x10"
        final boolean t$127139 = ((int) t$127123) != ((int) 0);
        
        //#line 117 "x10/glb/GLB.x10"
        if (t$127139) {
            
            //#line 118 "x10/glb/GLB.x10"
            final x10.io.Printer t$127127 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
            
            //#line 118 "x10/glb/GLB.x10"
            final long t$127124 = this.setupTime;
            
            //#line 118 "x10/glb/GLB.x10"
            final double t$127125 = ((double)(long)(((long)(t$127124))));
            
            //#line 118 "x10/glb/GLB.x10"
            final double t$127126 = ((t$127125) / (((double)(1.0E9))));
            
            //#line 118 "x10/glb/GLB.x10"
            final java.lang.String t$127128 = (("Setup time(s):") + ((x10.core.Double.$box(t$127126))));
            
            //#line 118 "x10/glb/GLB.x10"
            t$127127.println(((java.lang.Object)(t$127128)));
            
            //#line 119 "x10/glb/GLB.x10"
            final x10.io.Printer t$127132 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
            
            //#line 119 "x10/glb/GLB.x10"
            final long t$127129 = this.crunchNumberTime;
            
            //#line 119 "x10/glb/GLB.x10"
            final double t$127130 = ((double)(long)(((long)(t$127129))));
            
            //#line 119 "x10/glb/GLB.x10"
            final double t$127131 = ((t$127130) / (((double)(1.0E9))));
            
            //#line 119 "x10/glb/GLB.x10"
            final java.lang.String t$127133 = (("Process time(s):") + ((x10.core.Double.$box(t$127131))));
            
            //#line 119 "x10/glb/GLB.x10"
            t$127132.println(((java.lang.Object)(t$127133)));
            
            //#line 120 "x10/glb/GLB.x10"
            final x10.io.Printer t$127137 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
            
            //#line 120 "x10/glb/GLB.x10"
            final long t$127134 = this.collectResultTime;
            
            //#line 120 "x10/glb/GLB.x10"
            final double t$127135 = ((double)(long)(((long)(t$127134))));
            
            //#line 120 "x10/glb/GLB.x10"
            final double t$127136 = ((t$127135) / (((double)(1.0E9))));
            
            //#line 120 "x10/glb/GLB.x10"
            final java.lang.String t$127138 = (("Result reduce time(s):") + ((x10.core.Double.$box(t$127136))));
            
            //#line 120 "x10/glb/GLB.x10"
            t$127137.println(((java.lang.Object)(t$127138)));
        }
        
        //#line 126 "x10/glb/GLB.x10"
        final x10.glb.GLBParameters t$127140 = ((x10.glb.GLBParameters)(this.glbParams));
        
        //#line 126 "x10/glb/GLB.x10"
        final int t$127141 = t$127140.v;
        
        //#line 126 "x10/glb/GLB.x10"
        final int t$127142 = ((t$127141) & (((int)(4))));
        
        //#line 126 "x10/glb/GLB.x10"
        final boolean t$127144 = ((int) t$127142) != ((int) 0);
        
        //#line 126 "x10/glb/GLB.x10"
        if (t$127144) {
            
            //#line 127 "x10/glb/GLB.x10"
            final x10.lang.PlaceLocalHandle t$127143 = ((x10.lang.PlaceLocalHandle)(this.plh));
            
            //#line 127 "x10/glb/GLB.x10"
            this.printLog__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2(((x10.lang.PlaceLocalHandle)(t$127143)));
        }
        
        //#line 129 "x10/glb/GLB.x10"
        final x10.glb.GLBParameters t$127145 = ((x10.glb.GLBParameters)(this.glbParams));
        
        //#line 129 "x10/glb/GLB.x10"
        final int t$127146 = t$127145.v;
        
        //#line 129 "x10/glb/GLB.x10"
        final int t$127147 = ((t$127146) & (((int)(8))));
        
        //#line 129 "x10/glb/GLB.x10"
        final boolean t$127149 = ((int) t$127147) != ((int) 0);
        
        //#line 129 "x10/glb/GLB.x10"
        if (t$127149) {
            
            //#line 130 "x10/glb/GLB.x10"
            final x10.lang.PlaceLocalHandle t$127148 = ((x10.lang.PlaceLocalHandle)(this.plh));
            
            //#line 130 "x10/glb/GLB.x10"
            this.collectLifelineStatus__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2(((x10.lang.PlaceLocalHandle)(t$127148)));
        }
    }
    
    public static <$Queue, $R>void end$P__0$1x10$glb$GLB$$R$2__1$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.core.Rail<$R> r, final x10.glb.GLB<$Queue, $R> GLB) {
        ((x10.glb.GLB<$Queue, $R>)GLB).end__0$1x10$glb$GLB$$R$2(((x10.core.Rail)(r)));
    }
    
    
    //#line 138 "x10/glb/GLB.x10"
    /**
     * Collect GLB statistics
     * @param st PlaceLocalHandle for {@link Worker}
     */
    private void collectLifelineStatus__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 139 "x10/glb/GLB.x10"
        final x10.core.Rail logs;
        
        //#line 141 "x10/glb/GLB.x10"
        final long t$127150 = this.P;
        
        //#line 141 "x10/glb/GLB.x10"
        final boolean t$127161 = ((t$127150) >= (((long)(1024L))));
        
        //#line 141 "x10/glb/GLB.x10"
        if (t$127161) {
            
            //#line 142 "x10/glb/GLB.x10"
            final long t$127151 = this.P;
            
            //#line 142 "x10/glb/GLB.x10"
            final long t$127155 = ((t$127151) / (((long)(32L))));
            
            //#line 142 "x10/glb/GLB.x10"
            final x10.core.fun.Fun_0_1 t$127156 = ((x10.core.fun.Fun_0_1)(new x10.glb.GLB.$Closure$65<$Queue, $R>($Queue, $R, ((x10.glb.GLB<$Queue, $R>)(this)), this.P, st, (x10.glb.GLB.$Closure$65.__0$1x10$glb$GLB$$Closure$65$$Queue$3x10$glb$GLB$$Closure$65$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$65$$Queue$3x10$glb$GLB$$Closure$65$$R$2$2) null)));
            
            //#line 142 "x10/glb/GLB.x10"
            final x10.core.Rail t$127157 = ((x10.core.Rail)(new x10.core.Rail<x10.glb.Logger>(x10.glb.Logger.$RTT, t$127155, ((x10.core.fun.Fun_0_1)(t$127156)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 142 "x10/glb/GLB.x10"
            logs = ((x10.core.Rail)(t$127157));
        } else {
            
            //#line 151 "x10/glb/GLB.x10"
            final long t$127158 = this.P;
            
            //#line 151 "x10/glb/GLB.x10"
            final x10.core.fun.Fun_0_1 t$127159 = ((x10.core.fun.Fun_0_1)(new x10.glb.GLB.$Closure$67<$Queue, $R>($Queue, $R, ((x10.glb.GLB<$Queue, $R>)(this)), st, (x10.glb.GLB.$Closure$67.__0$1x10$glb$GLB$$Closure$67$$Queue$3x10$glb$GLB$$Closure$67$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$67$$Queue$3x10$glb$GLB$$Closure$67$$R$2$2) null)));
            
            //#line 151 "x10/glb/GLB.x10"
            final x10.core.Rail t$127160 = ((x10.core.Rail)(new x10.core.Rail<x10.glb.Logger>(x10.glb.Logger.$RTT, ((long)(t$127158)), ((x10.core.fun.Fun_0_1)(t$127159)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 151 "x10/glb/GLB.x10"
            logs = ((x10.core.Rail)(t$127160));
        }
        
        //#line 153 "x10/glb/GLB.x10"
        final x10.glb.Logger log = ((x10.glb.Logger)(new x10.glb.Logger((java.lang.System[]) null)));
        
        //#line 153 "x10/glb/GLB.x10"
        log.x10$glb$Logger$$init$S(((boolean)(false)));
        
        //#line 154 "x10/glb/GLB.x10"
        log.collect__0$1x10$glb$Logger$2(((x10.core.Rail)(logs)));
        
        //#line 155 "x10/glb/GLB.x10"
        log.stats();
    }
    
    public static <$Queue, $R>void collectLifelineStatus$P__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2__1$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final x10.glb.GLB<$Queue, $R> GLB) {
        ((x10.glb.GLB<$Queue, $R>)GLB).collectLifelineStatus__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2(((x10.lang.PlaceLocalHandle)(st)));
    }
    
    
    //#line 162 "x10/glb/GLB.x10"
    /**
     * Collect results from all places and reduce them to the final result.
     * @return Final result.
     */
    public x10.core.Rail collectResults() {
        
        //#line 40 . "x10/lang/System.x10"
        final long t$127162 = java.lang.System.nanoTime();
        
        //#line 163 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).collectResultTime = t$127162;
        
        //#line 166 "x10/glb/GLB.x10"
        final x10.lang.PlaceLocalHandle t$127163 = ((x10.lang.PlaceLocalHandle)(this.plh));
        
        //#line 166 "x10/glb/GLB.x10"
        final x10.glb.Worker t$127164 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)t$127163).$apply$G();
        
        //#line 166 "x10/glb/GLB.x10"
        final $Queue t$127165 = (($Queue)(((x10.glb.Worker<$Queue, $R>)t$127164).queue));
        
        //#line 166 "x10/glb/GLB.x10"
        final x10.glb.GLBResult t$127166 = ((x10.glb.GLBResult<$R>)
                                             ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$127165)).getResult());
        
        //#line 166 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).rootGlbR = ((x10.glb.GLBResult)(t$127166));
        
        //#line 167 "x10/glb/GLB.x10"
        final x10.glb.GLBResult t$127167 = ((x10.glb.GLBResult)(this.rootGlbR));
        
        //#line 167 "x10/glb/GLB.x10"
        final x10.core.GlobalRef resultGlobal = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.glb.GLBResult<$R>>(x10.rtt.ParameterizedType.make(x10.glb.GLBResult.$RTT, $R), t$127167, (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
        
        //#line 168 "x10/glb/GLB.x10"
        final x10.glb.GLBResult t$127168 = ((x10.glb.GLBResult)(this.rootGlbR));
        
        //#line 168 "x10/glb/GLB.x10"
        final x10.core.Rail tmpRail = ((x10.core.Rail<$R>)
                                        ((x10.glb.GLBResult<$R>)t$127168).submitResult());
        
        //#line 169 "x10/glb/GLB.x10"
        final x10.lang.PlaceLocalHandle tmpPlh = ((x10.lang.PlaceLocalHandle)(this.plh));
        
        //#line 172 "x10/glb/GLB.x10"
        final x10.lang.PlaceGroup t$127193 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 172 "x10/glb/GLB.x10"
        final x10.core.fun.VoidFun_0_0 t$127194 = ((x10.core.fun.VoidFun_0_0)(new x10.glb.GLB.$Closure$68<$Queue, $R>($Queue, $R, resultGlobal, tmpPlh, (x10.glb.GLB.$Closure$68.__0$1x10$glb$GLBResult$1x10$glb$GLB$$Closure$68$$R$2$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$68$$Queue$3x10$glb$GLB$$Closure$68$$R$2$2) null)));
        
        //#line 172 "x10/glb/GLB.x10"
        t$127193.broadcastFlat(((x10.core.fun.VoidFun_0_0)(t$127194)));
        
        //#line 40 . "x10/lang/System.x10"
        final long t$127195 = java.lang.System.nanoTime();
        
        //#line 192 "x10/glb/GLB.x10"
        final long t$127196 = this.collectResultTime;
        
        //#line 192 "x10/glb/GLB.x10"
        final long t$127197 = ((t$127195) - (((long)(t$127196))));
        
        //#line 192 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).collectResultTime = t$127197;
        
        //#line 194 "x10/glb/GLB.x10"
        return tmpRail;
    }
    
    
    //#line 203 "x10/glb/GLB.x10"
    /**
     * Print logging information on each place if user is interested in collecting per place
     * information, i.e., statistics instrumented.
     * @param st PLH for {@link Worker}
     */
    private void printLog__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 204 "x10/glb/GLB.x10"
        final long P = ((long)x10.x10rt.X10RT.numPlaces());
        
        //#line 205 "x10/glb/GLB.x10"
        long i$127219 = 0L;
        
        //#line 205 "x10/glb/GLB.x10"
        for (;
             true;
             ) {
            
            //#line 205 "x10/glb/GLB.x10"
            final boolean t$127221 = ((i$127219) < (((long)(P))));
            
            //#line 205 "x10/glb/GLB.x10"
            if (!(t$127221)) {
                
                //#line 205 "x10/glb/GLB.x10"
                break;
            }
            
            //#line 206 "x10/glb/GLB.x10"
            final x10.lang.Place alloc$127214 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 206 "x10/glb/GLB.x10"
            alloc$127214.x10$lang$Place$$init$S(i$127219);
            {
                
                //#line 206 "x10/glb/GLB.x10"
                x10.xrx.Runtime.runAt(((x10.lang.Place)(alloc$127214)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.GLB.$Closure$69<$Queue, $R>($Queue, $R, st, (x10.glb.GLB.$Closure$69.__0$1x10$glb$Worker$1x10$glb$GLB$$Closure$69$$Queue$3x10$glb$GLB$$Closure$69$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            }
            
            //#line 205 "x10/glb/GLB.x10"
            final long t$127218 = ((i$127219) + (((long)(1L))));
            
            //#line 205 "x10/glb/GLB.x10"
            i$127219 = t$127218;
        }
    }
    
    public static <$Queue, $R>void printLog$P__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2__1$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final x10.glb.GLB<$Queue, $R> GLB) {
        ((x10.glb.GLB<$Queue, $R>)GLB).printLog__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2(((x10.lang.PlaceLocalHandle)(st)));
    }
    
    
    //#line 21 "x10/glb/GLB.x10"
    final public x10.glb.GLB x10$glb$GLB$$this$x10$glb$GLB() {
        
        //#line 21 "x10/glb/GLB.x10"
        return x10.glb.GLB.this;
    }
    
    
    //#line 21 "x10/glb/GLB.x10"
    final public void __fieldInitializers_x10_glb_GLB() {
        
        //#line 25 "x10/glb/GLB.x10"
        final long t$127206 = ((long)x10.x10rt.X10RT.numPlaces());
        
        //#line 21 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).P = t$127206;
        
        //#line 21 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).setupTime = 0L;
        
        //#line 21 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).crunchNumberTime = 0L;
        
        //#line 21 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).collectResultTime = 0L;
        
        //#line 21 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).rootGlbR = null;
        
        //#line 57 "x10/glb/GLB.x10"
        final x10.glb.GLBParameters t$127207 = (x10.glb.GLBParameters) x10.rtt.Types.zeroValue(x10.glb.GLBParameters.$RTT);
        
        //#line 21 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).glbParams = t$127207;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$61<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$61> $RTT = 
            x10.rtt.StaticFunType.<$Closure$61> make($Closure$61.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1)))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$61<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.glbParams = $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.tree = $deserializer.readBoolean();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$61 $_obj = new x10.glb.GLB.$Closure$61((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.glbParams);
            $serializer.write(this.init);
            $serializer.write(this.tree);
            
        }
        
        // constructor just for allocation
        public $Closure$61(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$61.$initParams(this, $Queue, $R);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.glb.Worker $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$61 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __1$1x10$glb$GLB$$Closure$61$$Queue$2 {}
        
    
        
        public x10.glb.Worker $apply() {
            
            //#line 69 "x10/glb/GLB.x10"
            final x10.glb.Worker alloc$119073 = ((x10.glb.Worker)(new x10.glb.Worker<$Queue, $R>((java.lang.System[]) null, $Queue, $R)));
            
            //#line 69 "x10/glb/GLB.x10"
            final int t$127208 = this.glbParams.n;
            
            //#line 69 "x10/glb/GLB.x10"
            final int t$127209 = this.glbParams.w;
            
            //#line 69 "x10/glb/GLB.x10"
            final int t$127210 = this.glbParams.l;
            
            //#line 69 "x10/glb/GLB.x10"
            final int t$127211 = this.glbParams.z;
            
            //#line 69 "x10/glb/GLB.x10"
            final int t$127212 = this.glbParams.m;
            
            //#line 69 "x10/glb/GLB.x10"
            alloc$119073.x10$glb$Worker$$init$S(this.init, ((int)(t$127208)), ((int)(t$127209)), ((int)(t$127210)), ((int)(t$127211)), ((int)(t$127212)), this.tree, (x10.glb.Worker.__0$1x10$glb$Worker$$Queue$2) null);
            
            //#line 69 "x10/glb/GLB.x10"
            return alloc$119073;
        }
        
        public x10.glb.GLBParameters glbParams;
        public x10.core.fun.Fun_0_0<$Queue> init;
        public boolean tree;
        
        public $Closure$61(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLBParameters glbParams, final x10.core.fun.Fun_0_0<$Queue> init, final boolean tree, __1$1x10$glb$GLB$$Closure$61$$Queue$2 $dummy) {
            x10.glb.GLB.$Closure$61.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$61<$Queue, $R>)this).glbParams = ((x10.glb.GLBParameters)(glbParams));
                ((x10.glb.GLB.$Closure$61<$Queue, $R>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.glb.GLB.$Closure$61<$Queue, $R>)this).tree = tree;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$62<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$62> $RTT = 
            x10.rtt.StaticFunType.<$Closure$62> make($Closure$62.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.glb.Logger.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$62<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$62 $_obj = new x10.glb.GLB.$Closure$62((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.out$$);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$62(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$62.$initParams(this, $Queue, $R);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.glb.Logger $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$62 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLB$$Closure$62$$Queue$3x10$glb$GLB$$Closure$62$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$62$$Queue$3x10$glb$GLB$$Closure$62$$R$2$2 {}
        
    
        
        public x10.glb.Logger $apply() {
            
            //#line 145 "x10/glb/GLB.x10"
            try {{
                
                //#line 145 "x10/glb/GLB.x10"
                final x10.glb.Worker t$118883 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 145 "x10/glb/GLB.x10"
                final x10.glb.Logger t$118888 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)t$118883).logger));
                
                //#line 145 "x10/glb/GLB.x10"
                final x10.glb.GLBParameters t$118884 = ((x10.glb.GLBParameters)(((x10.glb.GLB<$Queue, $R>)this.out$$).glbParams));
                
                //#line 145 "x10/glb/GLB.x10"
                final int t$118885 = t$118884.v;
                
                //#line 145 "x10/glb/GLB.x10"
                final int t$118887 = ((t$118885) & (((int)(8))));
                
                //#line 145 "x10/glb/GLB.x10"
                final boolean t$118889 = ((int) t$118887) != ((int) 0);
                
                //#line 145 "x10/glb/GLB.x10"
                final x10.glb.Logger t$118890 = ((x10.glb.Logger)(t$118888.get((boolean)(t$118889))));
                
                //#line 145 "x10/glb/GLB.x10"
                return t$118890;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 145 "x10/glb/GLB.x10"
                x10.glb.Logger __lowerer__var__1__ = ((x10.glb.Logger)(x10.xrx.Runtime.<x10.glb.Logger> wrapAtChecked$G(x10.glb.Logger.$RTT, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 145 "x10/glb/GLB.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.glb.GLB<$Queue, $R> out$$;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$62(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLB<$Queue, $R> out$$, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$GLB$$Closure$62$$Queue$3x10$glb$GLB$$Closure$62$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$62$$Queue$3x10$glb$GLB$$Closure$62$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$62.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$62<$Queue, $R>)this).out$$ = out$$;
                ((x10.glb.GLB.$Closure$62<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$63<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$63> $RTT = 
            x10.rtt.StaticFunType.<$Closure$63> make($Closure$63.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.glb.Logger.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$63<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.h = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$63 $_obj = new x10.glb.GLB.$Closure$63((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.h);
            $serializer.write(this.out$$);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$63(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$63.$initParams(this, $Queue, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$63 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLB$$Closure$63$$Queue$3x10$glb$GLB$$Closure$63$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$63$$Queue$3x10$glb$GLB$$Closure$63$$R$2$2 {}
        
    
        
        public x10.glb.Logger $apply(final long i) {
            
            //#line 145 "x10/glb/GLB.x10"
            final long t$118882 = ((this.h) + (((long)(i))));
            
            //#line 145 "x10/glb/GLB.x10"
            final x10.lang.Place t$118891 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 145 "x10/glb/GLB.x10"
            t$118891.x10$lang$Place$$init$S(t$118882);
            
            //#line 145 "x10/glb/GLB.x10"
            final x10.glb.Logger t$118892 = ((x10.glb.Logger)(x10.xrx.Runtime.<x10.glb.Logger> evalAt__1$1x10$xrx$Runtime$$T$2$G(x10.glb.Logger.$RTT, ((x10.lang.Place)(t$118891)), ((x10.core.fun.Fun_0_0)(new x10.glb.GLB.$Closure$62<$Queue, $R>($Queue, $R, ((x10.glb.GLB<$Queue, $R>)(this.out$$)), ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)(this.st)), (x10.glb.GLB.$Closure$62.__0$1x10$glb$GLB$$Closure$62$$Queue$3x10$glb$GLB$$Closure$62$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$62$$Queue$3x10$glb$GLB$$Closure$62$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)))));
            
            //#line 145 "x10/glb/GLB.x10"
            return t$118892;
        }
        
        public x10.glb.GLB<$Queue, $R> out$$;
        public long h;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$63(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLB<$Queue, $R> out$$, final long h, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$GLB$$Closure$63$$Queue$3x10$glb$GLB$$Closure$63$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$63$$Queue$3x10$glb$GLB$$Closure$63$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$63.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$63<$Queue, $R>)this).out$$ = ((x10.glb.GLB)(out$$));
                ((x10.glb.GLB.$Closure$63<$Queue, $R>)this).h = h;
                ((x10.glb.GLB.$Closure$63<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$64<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$64> $RTT = 
            x10.rtt.StaticFunType.<$Closure$64> make($Closure$64.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.glb.Logger.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$64<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.P = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$64 $_obj = new x10.glb.GLB.$Closure$64((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.P);
            $serializer.write(this.out$$);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$64(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$64.$initParams(this, $Queue, $R);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.glb.Logger $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$64 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLB$$Closure$64$$Queue$3x10$glb$GLB$$Closure$64$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$64$$Queue$3x10$glb$GLB$$Closure$64$$R$2$2 {}
        
    
        
        public x10.glb.Logger $apply() {
            
            //#line 142 "x10/glb/GLB.x10"
            try {{
                
                //#line 143 "x10/glb/GLB.x10"
                final long h = x10.x10rt.X10RT.here().id;
                
                //#line 144 "x10/glb/GLB.x10"
                final long t$118894 = this.P;
                
                //#line 144 "x10/glb/GLB.x10"
                final long t$118895 = ((t$118894) - (((long)(h))));
                
                //#line 52 . "x10/glb/GLB.x10"
                final boolean t$127152 = ((32L) < (((long)(t$118895))));
                
                //#line 52 . "x10/glb/GLB.x10"
                long t$127153 =  0;
                
                //#line 52 . "x10/glb/GLB.x10"
                if (t$127152) {
                    
                    //#line 52 . "x10/glb/GLB.x10"
                    t$127153 = 32L;
                } else {
                    
                    //#line 52 . "x10/glb/GLB.x10"
                    t$127153 = t$118895;
                }
                
                //#line 144 "x10/glb/GLB.x10"
                final long n = t$127153;
                
                //#line 145 "x10/glb/GLB.x10"
                final x10.core.fun.Fun_0_1 t$127154 = ((x10.core.fun.Fun_0_1)(new x10.glb.GLB.$Closure$63<$Queue, $R>($Queue, $R, ((x10.glb.GLB<$Queue, $R>)(this.out$$)), h, ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)(this.st)), (x10.glb.GLB.$Closure$63.__0$1x10$glb$GLB$$Closure$63$$Queue$3x10$glb$GLB$$Closure$63$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$63$$Queue$3x10$glb$GLB$$Closure$63$$R$2$2) null)));
                
                //#line 145 "x10/glb/GLB.x10"
                final x10.core.Rail logs = ((x10.core.Rail)(new x10.core.Rail<x10.glb.Logger>(x10.glb.Logger.$RTT, ((long)(n)), ((x10.core.fun.Fun_0_1)(t$127154)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                
                //#line 146 "x10/glb/GLB.x10"
                final x10.glb.Logger log = ((x10.glb.Logger)(new x10.glb.Logger((java.lang.System[]) null)));
                
                //#line 146 "x10/glb/GLB.x10"
                log.x10$glb$Logger$$init$S(((boolean)(false)));
                
                //#line 147 "x10/glb/GLB.x10"
                log.collect__0$1x10$glb$Logger$2(((x10.core.Rail)(logs)));
                
                //#line 148 "x10/glb/GLB.x10"
                return log;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 142 "x10/glb/GLB.x10"
                x10.glb.Logger __lowerer__var__1__ = ((x10.glb.Logger)(x10.xrx.Runtime.<x10.glb.Logger> wrapAtChecked$G(x10.glb.Logger.$RTT, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 142 "x10/glb/GLB.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.glb.GLB<$Queue, $R> out$$;
        public long P;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$64(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLB<$Queue, $R> out$$, final long P, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$GLB$$Closure$64$$Queue$3x10$glb$GLB$$Closure$64$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$64$$Queue$3x10$glb$GLB$$Closure$64$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$64.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$64<$Queue, $R>)this).out$$ = out$$;
                ((x10.glb.GLB.$Closure$64<$Queue, $R>)this).P = P;
                ((x10.glb.GLB.$Closure$64<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$65<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$65> $RTT = 
            x10.rtt.StaticFunType.<$Closure$65> make($Closure$65.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.glb.Logger.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$65<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.P = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$65 $_obj = new x10.glb.GLB.$Closure$65((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.P);
            $serializer.write(this.out$$);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$65(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$65.$initParams(this, $Queue, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$65 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLB$$Closure$65$$Queue$3x10$glb$GLB$$Closure$65$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$65$$Queue$3x10$glb$GLB$$Closure$65$$R$2$2 {}
        
    
        
        public x10.glb.Logger $apply(final long i) {
            
            //#line 142 "x10/glb/GLB.x10"
            final long t$118893 = ((i) * (((long)(32L))));
            
            //#line 142 "x10/glb/GLB.x10"
            final x10.lang.Place t$118897 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 142 "x10/glb/GLB.x10"
            t$118897.x10$lang$Place$$init$S(t$118893);
            
            //#line 142 "x10/glb/GLB.x10"
            final x10.glb.Logger t$118898 = ((x10.glb.Logger)(x10.xrx.Runtime.<x10.glb.Logger> evalAt__1$1x10$xrx$Runtime$$T$2$G(x10.glb.Logger.$RTT, ((x10.lang.Place)(t$118897)), ((x10.core.fun.Fun_0_0)(new x10.glb.GLB.$Closure$64<$Queue, $R>($Queue, $R, ((x10.glb.GLB<$Queue, $R>)(this.out$$)), ((long)(this.P)), ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)(this.st)), (x10.glb.GLB.$Closure$64.__0$1x10$glb$GLB$$Closure$64$$Queue$3x10$glb$GLB$$Closure$64$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$64$$Queue$3x10$glb$GLB$$Closure$64$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)))));
            
            //#line 142 "x10/glb/GLB.x10"
            return t$118898;
        }
        
        public x10.glb.GLB<$Queue, $R> out$$;
        public long P;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$65(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLB<$Queue, $R> out$$, final long P, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$GLB$$Closure$65$$Queue$3x10$glb$GLB$$Closure$65$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$65$$Queue$3x10$glb$GLB$$Closure$65$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$65.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$65<$Queue, $R>)this).out$$ = ((x10.glb.GLB)(out$$));
                ((x10.glb.GLB.$Closure$65<$Queue, $R>)this).P = P;
                ((x10.glb.GLB.$Closure$65<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$66<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$66> $RTT = 
            x10.rtt.StaticFunType.<$Closure$66> make($Closure$66.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.glb.Logger.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$66<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$66 $_obj = new x10.glb.GLB.$Closure$66((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.out$$);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$66(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$66.$initParams(this, $Queue, $R);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.glb.Logger $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$66 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLB$$Closure$66$$Queue$3x10$glb$GLB$$Closure$66$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$66$$Queue$3x10$glb$GLB$$Closure$66$$R$2$2 {}
        
    
        
        public x10.glb.Logger $apply() {
            
            //#line 151 "x10/glb/GLB.x10"
            try {{
                
                //#line 151 "x10/glb/GLB.x10"
                final x10.glb.Worker t$118899 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 151 "x10/glb/GLB.x10"
                final x10.glb.Logger t$118904 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)t$118899).logger));
                
                //#line 151 "x10/glb/GLB.x10"
                final x10.glb.GLBParameters t$118900 = ((x10.glb.GLBParameters)(((x10.glb.GLB<$Queue, $R>)this.out$$).glbParams));
                
                //#line 151 "x10/glb/GLB.x10"
                final int t$118901 = t$118900.v;
                
                //#line 151 "x10/glb/GLB.x10"
                final int t$118903 = ((t$118901) & (((int)(8))));
                
                //#line 151 "x10/glb/GLB.x10"
                final boolean t$118905 = ((int) t$118903) != ((int) 0);
                
                //#line 151 "x10/glb/GLB.x10"
                final x10.glb.Logger t$118906 = ((x10.glb.Logger)(t$118904.get((boolean)(t$118905))));
                
                //#line 151 "x10/glb/GLB.x10"
                return t$118906;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 151 "x10/glb/GLB.x10"
                x10.glb.Logger __lowerer__var__1__ = ((x10.glb.Logger)(x10.xrx.Runtime.<x10.glb.Logger> wrapAtChecked$G(x10.glb.Logger.$RTT, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 151 "x10/glb/GLB.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.glb.GLB<$Queue, $R> out$$;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$66(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLB<$Queue, $R> out$$, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$GLB$$Closure$66$$Queue$3x10$glb$GLB$$Closure$66$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$66$$Queue$3x10$glb$GLB$$Closure$66$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$66.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$66<$Queue, $R>)this).out$$ = out$$;
                ((x10.glb.GLB.$Closure$66<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$67<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$67> $RTT = 
            x10.rtt.StaticFunType.<$Closure$67> make($Closure$67.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.glb.Logger.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$67<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$67 $_obj = new x10.glb.GLB.$Closure$67((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.out$$);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$67(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$67.$initParams(this, $Queue, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$67 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLB$$Closure$67$$Queue$3x10$glb$GLB$$Closure$67$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$67$$Queue$3x10$glb$GLB$$Closure$67$$R$2$2 {}
        
    
        
        public x10.glb.Logger $apply(final long i) {
            
            //#line 151 "x10/glb/GLB.x10"
            final x10.lang.Place t$118907 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 151 "x10/glb/GLB.x10"
            t$118907.x10$lang$Place$$init$S(((long)(i)));
            
            //#line 151 "x10/glb/GLB.x10"
            final x10.glb.Logger t$118908 = ((x10.glb.Logger)(x10.xrx.Runtime.<x10.glb.Logger> evalAt__1$1x10$xrx$Runtime$$T$2$G(x10.glb.Logger.$RTT, ((x10.lang.Place)(t$118907)), ((x10.core.fun.Fun_0_0)(new x10.glb.GLB.$Closure$66<$Queue, $R>($Queue, $R, ((x10.glb.GLB<$Queue, $R>)(this.out$$)), ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)(this.st)), (x10.glb.GLB.$Closure$66.__0$1x10$glb$GLB$$Closure$66$$Queue$3x10$glb$GLB$$Closure$66$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$66$$Queue$3x10$glb$GLB$$Closure$66$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)))));
            
            //#line 151 "x10/glb/GLB.x10"
            return t$118908;
        }
        
        public x10.glb.GLB<$Queue, $R> out$$;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$67(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLB<$Queue, $R> out$$, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$GLB$$Closure$67$$Queue$3x10$glb$GLB$$Closure$67$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$67$$Queue$3x10$glb$GLB$$Closure$67$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$67.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$67<$Queue, $R>)this).out$$ = ((x10.glb.GLB)(out$$));
                ((x10.glb.GLB.$Closure$67<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$68<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$68> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$68> make($Closure$68.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$68<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.resultGlobal = $deserializer.readObject();
            $_obj.tmpPlh = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$68 $_obj = new x10.glb.GLB.$Closure$68((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.resultGlobal);
            $serializer.write(this.tmpPlh);
            
        }
        
        // constructor just for allocation
        public $Closure$68(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$68.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$68 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLBResult$1x10$glb$GLB$$Closure$68$$R$2$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$68$$Queue$3x10$glb$GLB$$Closure$68$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 173 "x10/glb/GLB.x10"
            final x10.lang.Place t$127169 = ((x10.lang.Place)((this.resultGlobal).home));
            
            //#line 173 "x10/glb/GLB.x10"
            final boolean t$127192 = x10.rtt.Equality.equalsequals((x10.x10rt.X10RT.here()),(t$127169));
            
            //#line 173 "x10/glb/GLB.x10"
            if (t$127192) {
                
                //#line 174 "x10/glb/GLB.x10"
                final x10.core.GlobalRef t$119050 = ((x10.core.GlobalRef)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.core.GlobalRef.$RTT, x10.rtt.ParameterizedType.make(x10.glb.GLBResult.$RTT, $R)),this.resultGlobal));
                
                //#line 174 "x10/glb/GLB.x10"
                final x10.lang.Place t$127170 = ((x10.lang.Place)((t$119050).home));
                
                //#line 174 "x10/glb/GLB.x10"
                final boolean t$127171 = x10.rtt.Equality.equalsequals((t$127170),(x10.x10rt.X10RT.here()));
                
                //#line 174 "x10/glb/GLB.x10"
                final boolean t$127173 = !(t$127171);
                
                //#line 174 "x10/glb/GLB.x10"
                if (t$127173) {
                    
                    //#line 174 "x10/glb/GLB.x10"
                    final x10.lang.FailedDynamicCheckException t$127172 = new x10.lang.FailedDynamicCheckException("x10.lang.GlobalRef[x10.glb.GLBResult[R]]{self.home==here}");
                    
                    //#line 174 "x10/glb/GLB.x10"
                    throw t$127172;
                }
                
                //#line 175 "x10/glb/GLB.x10"
                final x10.util.Team t$127179 = ((x10.util.Team)(x10.util.Team.get$WORLD()));
                
                //#line 175 "x10/glb/GLB.x10"
                final x10.glb.GLBResult t$127174 = (((x10.core.GlobalRef<x10.glb.GLBResult<$R>>)(t$119050))).$apply$G();
                
                //#line 175 "x10/glb/GLB.x10"
                final x10.core.Rail t$127180 = ((x10.core.Rail<$R>)
                                                 ((x10.glb.GLBResult<$R>)t$127174).submitResult());
                
                //#line 177 "x10/glb/GLB.x10"
                final x10.glb.GLBResult t$127175 = (((x10.core.GlobalRef<x10.glb.GLBResult<$R>>)(t$119050))).$apply$G();
                
                //#line 177 "x10/glb/GLB.x10"
                final x10.core.Rail t$127181 = ((x10.core.Rail<$R>)
                                                 ((x10.glb.GLBResult<$R>)t$127175).submitResult());
                
                //#line 179 "x10/glb/GLB.x10"
                final x10.glb.GLBResult t$127176 = (((x10.core.GlobalRef<x10.glb.GLBResult<$R>>)(t$119050))).$apply$G();
                
                //#line 179 "x10/glb/GLB.x10"
                final x10.core.Rail t$127177 = ((x10.core.Rail<$R>)
                                                 ((x10.glb.GLBResult<$R>)t$127176).submitResult());
                
                //#line 179 "x10/glb/GLB.x10"
                final long t$127182 = ((x10.core.Rail<$R>)t$127177).size;
                
                //#line 180 "x10/glb/GLB.x10"
                final x10.glb.GLBResult t$127178 = (((x10.core.GlobalRef<x10.glb.GLBResult<$R>>)(t$119050))).$apply$G();
                
                //#line 180 "x10/glb/GLB.x10"
                final int t$127183 = ((x10.glb.GLBResult<$R>)t$127178).getReduceOperator$O();
                
                //#line 175 "x10/glb/GLB.x10"
                ((x10.util.Team)t$127179).<$R> allreduce__0$1x10$util$Team$$T$2__2$1x10$util$Team$$T$2($R, ((x10.core.Rail)(t$127180)), (long)(0L), ((x10.core.Rail)(t$127181)), (long)(0L), (long)(t$127182), (int)(t$127183));
            } else {
                
                //#line 182 "x10/glb/GLB.x10"
                final x10.glb.Worker t$127184 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.tmpPlh).$apply$G();
                
                //#line 182 "x10/glb/GLB.x10"
                final $Queue t$127185 = (($Queue)(((x10.glb.Worker<$Queue, $R>)t$127184).queue));
                
                //#line 182 "x10/glb/GLB.x10"
                final x10.glb.GLBResult glbR = ((x10.glb.GLBResult<$R>)
                                                 ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$127185)).getResult());
                
                //#line 183 "x10/glb/GLB.x10"
                final x10.util.Team t$127187 = ((x10.util.Team)(x10.util.Team.get$WORLD()));
                
                //#line 183 "x10/glb/GLB.x10"
                final x10.core.Rail t$127188 = ((x10.core.Rail<$R>)
                                                 ((x10.glb.GLBResult<$R>)glbR).submitResult());
                
                //#line 185 "x10/glb/GLB.x10"
                final x10.core.Rail t$127189 = ((x10.core.Rail<$R>)
                                                 ((x10.glb.GLBResult<$R>)glbR).submitResult());
                
                //#line 187 "x10/glb/GLB.x10"
                final x10.core.Rail t$127186 = ((x10.core.Rail<$R>)
                                                 ((x10.glb.GLBResult<$R>)glbR).submitResult());
                
                //#line 187 "x10/glb/GLB.x10"
                final long t$127190 = ((x10.core.Rail<$R>)t$127186).size;
                
                //#line 188 "x10/glb/GLB.x10"
                final int t$127191 = ((x10.glb.GLBResult<$R>)glbR).getReduceOperator$O();
                
                //#line 183 "x10/glb/GLB.x10"
                ((x10.util.Team)t$127187).<$R> allreduce__0$1x10$util$Team$$T$2__2$1x10$util$Team$$T$2($R, ((x10.core.Rail)(t$127188)), (long)(0L), ((x10.core.Rail)(t$127189)), (long)(0L), (long)(t$127190), (int)(t$127191));
            }
        }
        
        public x10.core.GlobalRef<x10.glb.GLBResult<$R>> resultGlobal;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> tmpPlh;
        
        public $Closure$68(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.core.GlobalRef<x10.glb.GLBResult<$R>> resultGlobal, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> tmpPlh, __0$1x10$glb$GLBResult$1x10$glb$GLB$$Closure$68$$R$2$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$68$$Queue$3x10$glb$GLB$$Closure$68$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$68.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$68<$Queue, $R>)this).resultGlobal = ((x10.core.GlobalRef)(resultGlobal));
                ((x10.glb.GLB.$Closure$68<$Queue, $R>)this).tmpPlh = ((x10.lang.PlaceLocalHandle)(tmpPlh));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$69<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$69> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$69> make($Closure$69.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$69<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$69 $_obj = new x10.glb.GLB.$Closure$69((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$69(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$69.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$69 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$GLB$$Closure$69$$Queue$3x10$glb$GLB$$Closure$69$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 206 "x10/glb/GLB.x10"
            try {{
                
                //#line 207 "x10/glb/GLB.x10"
                final x10.glb.Worker t$127215 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 207 "x10/glb/GLB.x10"
                final $Queue t$127216 = (($Queue)(((x10.glb.Worker<$Queue, $R>)t$127215).queue));
                
                //#line 207 "x10/glb/GLB.x10"
                ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$127216)).printLog();
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 206 "x10/glb/GLB.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$69(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$GLB$$Closure$69$$Queue$3x10$glb$GLB$$Closure$69$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$69.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$69<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
}

