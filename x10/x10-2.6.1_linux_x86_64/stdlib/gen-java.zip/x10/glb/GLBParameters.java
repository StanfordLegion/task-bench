package x10.glb;

/**
 * A structure that captures the essence of lifeline graph structure
 */
@x10.runtime.impl.java.X10Generated
public class GLBParameters extends x10.core.Struct implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<GLBParameters> $RTT = 
        x10.rtt.NamedStructType.<GLBParameters> make("x10.glb.GLBParameters",
                                                     GLBParameters.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.STRUCT
                                                     });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLBParameters $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.l = $deserializer.readInt();
        $_obj.m = $deserializer.readInt();
        $_obj.n = $deserializer.readInt();
        $_obj.v = $deserializer.readInt();
        $_obj.w = $deserializer.readInt();
        $_obj.z = $deserializer.readInt();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.glb.GLBParameters $_obj = new x10.glb.GLBParameters((java.lang.System[]) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.l);
        $serializer.write(this.m);
        $serializer.write(this.n);
        $serializer.write(this.v);
        $serializer.write(this.w);
        $serializer.write(this.z);
        
    }
    
    // zero value constructor
    public GLBParameters(final java.lang.System $dummy) { this.n = 0; this.w = 0; this.l = 0; this.z = 0; this.m = 0; this.v = 0; }
    
    // constructor just for allocation
    public GLBParameters(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 17 "x10/glb/GLBParameters.x10"
    public int n;
    
    //#line 18 "x10/glb/GLBParameters.x10"
    public int w;
    
    //#line 19 "x10/glb/GLBParameters.x10"
    public int l;
    
    //#line 20 "x10/glb/GLBParameters.x10"
    public int z;
    
    //#line 21 "x10/glb/GLBParameters.x10"
    public int m;
    
    //#line 22 "x10/glb/GLBParameters.x10"
    public int v;
    

    
    
    //#line 30 "x10/glb/GLBParameters.x10"
    /**
     * Calculate power of lineline given the base and the total number of places
     * @param p total number of places in the system
     * @param l base of lifeline
     * @return power of lifeline
     */
    final public static int computeZ$O(final long p, final int l) {
        
        //#line 31 "x10/glb/GLBParameters.x10"
        int z0 = 1;
        
        //#line 32 "x10/glb/GLBParameters.x10"
        int zz = l;
        
        //#line 33 "x10/glb/GLBParameters.x10"
        while (true) {
            
            //#line 33 "x10/glb/GLBParameters.x10"
            final long t$127622 = ((long)(((int)(zz))));
            
            //#line 33 "x10/glb/GLBParameters.x10"
            final boolean t$127627 = ((t$127622) < (((long)(p))));
            
            //#line 33 "x10/glb/GLBParameters.x10"
            if (!(t$127627)) {
                
                //#line 33 "x10/glb/GLBParameters.x10"
                break;
            }
            
            //#line 34 "x10/glb/GLBParameters.x10"
            final int t$127739 = ((z0) + (((int)(1))));
            
            //#line 34 "x10/glb/GLBParameters.x10"
            z0 = t$127739;
            
            //#line 35 "x10/glb/GLBParameters.x10"
            final int t$127741 = ((zz) * (((int)(l))));
            
            //#line 35 "x10/glb/GLBParameters.x10"
            zz = t$127741;
        }
        
        //#line 37 "x10/glb/GLBParameters.x10"
        return z0;
    }
    
    
    //#line 42 "x10/glb/GLBParameters.x10"
    private static x10.glb.GLBParameters Default;
    
    //#line 47 "x10/glb/GLBParameters.x10"
    /**
     * Show computation result.
     */
    final public static int SHOW_RESULT_FLAG = 1;
    
    //#line 51 "x10/glb/GLBParameters.x10"
    /**
     * Show work initialization, computation, result collection 
     */
    final public static int SHOW_TIMING_FLAG = 2;
    
    //#line 57 "x10/glb/GLBParameters.x10"
    /**
     * Show logs produced by each task frame, i.e., each
     * task frame's computation time, yield time etc
     */
    final public static int SHOW_TASKFRAME_LOG_FLAG = 4;
    
    //#line 62 "x10/glb/GLBParameters.x10"
    /**
     * Show GLB statistics 
     */
    final public static int SHOW_GLB_FLAG = 8;
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$205534) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205534);
        }
        
    }
    
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public java.lang.String toString() {
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$127629 = "struct x10.glb.GLBParameters: n=";
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127630 = this.n;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$127631 = ((t$127629) + ((x10.core.Int.$box(t$127630))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$127632 = ((t$127631) + (" w="));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127633 = this.w;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$127634 = ((t$127632) + ((x10.core.Int.$box(t$127633))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$127635 = ((t$127634) + (" l="));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127636 = this.l;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$127637 = ((t$127635) + ((x10.core.Int.$box(t$127636))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$127638 = ((t$127637) + (" z="));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127639 = this.z;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$127640 = ((t$127638) + ((x10.core.Int.$box(t$127639))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$127641 = ((t$127640) + (" m="));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127642 = this.m;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$127643 = ((t$127641) + ((x10.core.Int.$box(t$127642))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$127644 = ((t$127643) + (" v="));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127645 = this.v;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$127646 = ((t$127644) + ((x10.core.Int.$box(t$127645))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        return t$127646;
    }
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public int hashCode() {
        
        //#line 23 "x10/glb/GLBParameters.x10"
        int result = 1;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127649 = ((8191) * (((int)(result))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127648 = this.n;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127650 = x10.rtt.Types.hashCode(t$127648);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127651 = ((t$127649) + (((int)(t$127650))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        result = t$127651;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127654 = ((8191) * (((int)(result))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127653 = this.w;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127655 = x10.rtt.Types.hashCode(t$127653);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127656 = ((t$127654) + (((int)(t$127655))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        result = t$127656;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127659 = ((8191) * (((int)(result))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127658 = this.l;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127660 = x10.rtt.Types.hashCode(t$127658);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127661 = ((t$127659) + (((int)(t$127660))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        result = t$127661;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127664 = ((8191) * (((int)(result))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127663 = this.z;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127665 = x10.rtt.Types.hashCode(t$127663);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127666 = ((t$127664) + (((int)(t$127665))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        result = t$127666;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127669 = ((8191) * (((int)(result))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127668 = this.m;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127670 = x10.rtt.Types.hashCode(t$127668);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127671 = ((t$127669) + (((int)(t$127670))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        result = t$127671;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127674 = ((8191) * (((int)(result))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127673 = this.v;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127675 = x10.rtt.Types.hashCode(t$127673);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127676 = ((t$127674) + (((int)(t$127675))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        result = t$127676;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        return result;
    }
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public boolean equals(java.lang.Object other) {
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final boolean t$127679 = x10.glb.GLBParameters.$RTT.isInstance(other);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final boolean t$127680 = !(t$127679);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$127680) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            return false;
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final x10.glb.GLBParameters t$127682 = ((x10.glb.GLBParameters)x10.rtt.Types.asStruct(x10.glb.GLBParameters.$RTT,other));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final boolean t$127683 = this.equals$O(((x10.glb.GLBParameters)(t$127682)));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        return t$127683;
    }
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public boolean equals$O(x10.glb.GLBParameters other) {
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127685 = this.n;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127686 = other.n;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$127690 = ((int) t$127685) == ((int) t$127686);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$127690) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127688 = this.w;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127689 = other.w;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$127690 = ((int) t$127688) == ((int) t$127689);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$127694 = t$127690;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$127690) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127692 = this.l;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127693 = other.l;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$127694 = ((int) t$127692) == ((int) t$127693);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$127698 = t$127694;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$127694) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127696 = this.z;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127697 = other.z;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$127698 = ((int) t$127696) == ((int) t$127697);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$127702 = t$127698;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$127698) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127700 = this.m;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127701 = other.m;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$127702 = ((int) t$127700) == ((int) t$127701);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$127706 = t$127702;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$127702) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127704 = this.v;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127705 = other.v;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$127706 = ((int) t$127704) == ((int) t$127705);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        return t$127706;
    }
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final boolean t$127709 = x10.glb.GLBParameters.$RTT.isInstance(other);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final boolean t$127710 = !(t$127709);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$127710) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            return false;
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final x10.glb.GLBParameters t$127712 = ((x10.glb.GLBParameters)x10.rtt.Types.asStruct(x10.glb.GLBParameters.$RTT,other));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final boolean t$127713 = this._struct_equals$O(((x10.glb.GLBParameters)(t$127712)));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        return t$127713;
    }
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public boolean _struct_equals$O(x10.glb.GLBParameters other) {
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127715 = this.n;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$127716 = other.n;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$127720 = ((int) t$127715) == ((int) t$127716);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$127720) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127718 = this.w;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127719 = other.w;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$127720 = ((int) t$127718) == ((int) t$127719);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$127724 = t$127720;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$127720) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127722 = this.l;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127723 = other.l;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$127724 = ((int) t$127722) == ((int) t$127723);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$127728 = t$127724;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$127724) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127726 = this.z;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127727 = other.z;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$127728 = ((int) t$127726) == ((int) t$127727);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$127732 = t$127728;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$127728) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127730 = this.m;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127731 = other.m;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$127732 = ((int) t$127730) == ((int) t$127731);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$127736 = t$127732;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$127732) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127734 = this.v;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$127735 = other.v;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$127736 = ((int) t$127734) == ((int) t$127735);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        return t$127736;
    }
    
    
    //#line 16 "x10/glb/GLBParameters.x10"
    final public x10.glb.GLBParameters x10$glb$GLBParameters$$this$x10$glb$GLBParameters() {
        
        //#line 16 "x10/glb/GLBParameters.x10"
        return x10.glb.GLBParameters.this;
    }
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    // creation method for java code (1-phase java constructor)
    public GLBParameters(final int n, final int w, final int l, final int z, final int m, final int v) {
        this((java.lang.System[]) null);
        x10$glb$GLBParameters$$init$S(n, w, l, z, m, v);
    }
    
    // constructor for non-virtual call
    final public x10.glb.GLBParameters x10$glb$GLBParameters$$init$S(final int n, final int w, final int l, final int z, final int m, final int v) {
         {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            this.n = n;
            this.w = w;
            this.l = l;
            this.z = z;
            this.m = m;
            this.v = v;
            
        }
        return this;
    }
    
    
    
    //#line 16 "x10/glb/GLBParameters.x10"
    final public void __fieldInitializers_x10_glb_GLBParameters() {
        
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$Default = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$Default;
    
    public static x10.glb.GLBParameters get$Default() {
        if (((int) x10.glb.GLBParameters.initStatus$Default.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.glb.GLBParameters.Default;
        }
        if (((int) x10.glb.GLBParameters.initStatus$Default.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.glb.GLBParameters.exception$Default;
        }
        if (x10.glb.GLBParameters.initStatus$Default.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.glb.GLBParameters.Default = ((x10.glb.GLBParameters)(new x10.glb.GLBParameters((java.lang.System[]) null).x10$glb$GLBParameters$$init$S(((int)(100)), ((int)(4)), ((int)(4)), x10.glb.GLBParameters.computeZ$O((long)(((long)x10.x10rt.X10RT.numPlaces())), (int)(4)), ((int)(1024)), ((int)(15)))));
            }}catch (java.lang.Throwable exc$127742) {
                x10.glb.GLBParameters.exception$Default = new x10.lang.ExceptionInInitializer(exc$127742);
                x10.glb.GLBParameters.initStatus$Default.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.glb.GLBParameters.exception$Default;
            }
            x10.glb.GLBParameters.initStatus$Default.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.glb.GLBParameters.initStatus$Default.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.glb.GLBParameters.initStatus$Default.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.glb.GLBParameters.initStatus$Default.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.glb.GLBParameters.exception$Default;
                }
            }
        }
        return x10.glb.GLBParameters.Default;
    }
    
    public static int get$SHOW_RESULT_FLAG() {
        return x10.glb.GLBParameters.SHOW_RESULT_FLAG;
    }
    
    public static int get$SHOW_TIMING_FLAG() {
        return x10.glb.GLBParameters.SHOW_TIMING_FLAG;
    }
    
    public static int get$SHOW_TASKFRAME_LOG_FLAG() {
        return x10.glb.GLBParameters.SHOW_TASKFRAME_LOG_FLAG;
    }
    
    public static int get$SHOW_GLB_FLAG() {
        return x10.glb.GLBParameters.SHOW_GLB_FLAG;
    }
}

