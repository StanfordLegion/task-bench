package x10.glb;


/**
 * <p>A TaskBag[T] implemented with a backing ArrayList.
 * </p>
 */
@x10.runtime.impl.java.X10Generated
public class ArrayListTaskBag<$T> extends x10.core.Ref implements x10.glb.TaskBag, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<ArrayListTaskBag> $RTT = 
        x10.rtt.NamedType.<ArrayListTaskBag> make("x10.glb.ArrayListTaskBag",
                                                  ArrayListTaskBag.class,
                                                  1,
                                                  new x10.rtt.Type[] {
                                                      x10.glb.TaskBag.$RTT
                                                  });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.ArrayListTaskBag<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.bag = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.glb.ArrayListTaskBag $_obj = new x10.glb.ArrayListTaskBag((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.bag);
        
    }
    
    // constructor just for allocation
    public ArrayListTaskBag(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.glb.ArrayListTaskBag.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final ArrayListTaskBag $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    

    
    //#line 21 "x10/glb/ArrayListTaskBag.x10"
    public x10.util.ArrayList<$T> bag;
    
    
    //#line 23 "x10/glb/ArrayListTaskBag.x10"
    public long size$O() {
        
        //#line 23 "x10/glb/ArrayListTaskBag.x10"
        final x10.util.ArrayList t$117980 = ((x10.util.ArrayList)(this.bag));
        
        //#line 23 "x10/glb/ArrayListTaskBag.x10"
        final long t$117981 = ((x10.util.ArrayList<$T>)t$117980).size$O();
        
        //#line 23 "x10/glb/ArrayListTaskBag.x10"
        return t$117981;
    }
    
    
    //#line 29 "x10/glb/ArrayListTaskBag.x10"
    /**
     * Merge incoming taskbag with local bag.
     * @param tb0 incoming taskbag
     */
    public void merge(final x10.glb.TaskBag tb0) {
        
        //#line 30 "x10/glb/ArrayListTaskBag.x10"
        assert x10.glb.ArrayListTaskBag.$RTT.isInstance(tb0, $T);
        
        //#line 31 "x10/glb/ArrayListTaskBag.x10"
        final x10.glb.ArrayListTaskBag tb = ((x10.glb.ArrayListTaskBag)(x10.rtt.Types.<x10.glb.ArrayListTaskBag<$T>> cast(tb0,x10.rtt.ParameterizedType.make(x10.glb.ArrayListTaskBag.$RTT, $T))));
        
        //#line 32 "x10/glb/ArrayListTaskBag.x10"
        final x10.util.ArrayList t$117982 = ((x10.util.ArrayList)(this.bag));
        
        //#line 32 "x10/glb/ArrayListTaskBag.x10"
        final x10.util.ArrayList t$117983 = ((x10.util.ArrayList)(((x10.glb.ArrayListTaskBag<$T>)tb).bag));
        
        //#line 32 "x10/glb/ArrayListTaskBag.x10"
        ((x10.util.AbstractCollection<$T>)t$117982).addAll__0$1x10$util$AbstractCollection$$T$2$O(((x10.util.Container)(t$117983)));
    }
    
    
    //#line 40 "x10/glb/ArrayListTaskBag.x10"
    /**
     * Split local bag into two and return half of it
     * @return null if bag size is less than (or equal to) 1
     *         half of the local bag
     */
    public x10.glb.ArrayListTaskBag split() {
        
        //#line 41 "x10/glb/ArrayListTaskBag.x10"
        final x10.util.ArrayList t$117984 = ((x10.util.ArrayList)(this.bag));
        
        //#line 41 "x10/glb/ArrayListTaskBag.x10"
        final long t$117985 = ((x10.util.ArrayList<$T>)t$117984).size$O();
        
        //#line 41 "x10/glb/ArrayListTaskBag.x10"
        final boolean t$117986 = ((t$117985) <= (((long)(1L))));
        
        //#line 41 "x10/glb/ArrayListTaskBag.x10"
        if (t$117986) {
            
            //#line 41 "x10/glb/ArrayListTaskBag.x10"
            return null;
        }
        
        //#line 42 "x10/glb/ArrayListTaskBag.x10"
        final x10.util.ArrayList t$117987 = ((x10.util.ArrayList)(this.bag));
        
        //#line 42 "x10/glb/ArrayListTaskBag.x10"
        final long t$117988 = ((x10.util.ArrayList<$T>)t$117987).size$O();
        
        //#line 42 "x10/glb/ArrayListTaskBag.x10"
        final long size = ((t$117988) / (((long)(2L))));
        
        //#line 43 "x10/glb/ArrayListTaskBag.x10"
        final x10.glb.ArrayListTaskBag o = ((x10.glb.ArrayListTaskBag)(new x10.glb.ArrayListTaskBag<$T>((java.lang.System[]) null, $T)));
        
        //#line 21 .. "x10/glb/ArrayListTaskBag.x10"
        final x10.util.ArrayList alloc$117998 = ((x10.util.ArrayList)(new x10.util.ArrayList<$T>((java.lang.System[]) null, $T)));
        
        //#line 21 .. "x10/glb/ArrayListTaskBag.x10"
        alloc$117998.x10$util$ArrayList$$init$S();
        
        //#line 19 .. "x10/glb/ArrayListTaskBag.x10"
        ((x10.glb.ArrayListTaskBag<$T>)o).bag = ((x10.util.ArrayList)(alloc$117998));
        
        //#line 44 "x10/glb/ArrayListTaskBag.x10"
        long i$118005 = 1L;
        
        //#line 44 "x10/glb/ArrayListTaskBag.x10"
        for (;
             true;
             ) {
            
            //#line 44 "x10/glb/ArrayListTaskBag.x10"
            final boolean t$118007 = ((i$118005) <= (((long)(size))));
            
            //#line 44 "x10/glb/ArrayListTaskBag.x10"
            if (!(t$118007)) {
                
                //#line 44 "x10/glb/ArrayListTaskBag.x10"
                break;
            }
            
            //#line 44 "x10/glb/ArrayListTaskBag.x10"
            final x10.util.ArrayList t$117999 = ((x10.util.ArrayList)(((x10.glb.ArrayListTaskBag<$T>)o).bag));
            
            //#line 44 "x10/glb/ArrayListTaskBag.x10"
            final x10.util.ArrayList t$118000 = ((x10.util.ArrayList)(this.bag));
            
            //#line 44 "x10/glb/ArrayListTaskBag.x10"
            final $T t$118001 = (($T)(((x10.util.ArrayList<$T>)t$118000).removeLast$G()));
            
            //#line 44 "x10/glb/ArrayListTaskBag.x10"
            ((x10.util.ArrayList<$T>)t$117999).add__0x10$util$ArrayList$$T$O((($T)(t$118001)));
            
            //#line 44 "x10/glb/ArrayListTaskBag.x10"
            final long t$118004 = ((i$118005) + (((long)(1L))));
            
            //#line 44 "x10/glb/ArrayListTaskBag.x10"
            i$118005 = t$118004;
        }
        
        //#line 45 "x10/glb/ArrayListTaskBag.x10"
        return o;
    }
    
    
    //#line 52 "x10/glb/ArrayListTaskBag.x10"
    /**
     * Return local bag.
     * @return local bag.
     */
    public x10.util.ArrayList bag() {
        
        //#line 52 "x10/glb/ArrayListTaskBag.x10"
        final x10.util.ArrayList t$117997 = ((x10.util.ArrayList)(this.bag));
        
        //#line 52 "x10/glb/ArrayListTaskBag.x10"
        return t$117997;
    }
    
    
    //#line 19 "x10/glb/ArrayListTaskBag.x10"
    final public x10.glb.ArrayListTaskBag x10$glb$ArrayListTaskBag$$this$x10$glb$ArrayListTaskBag() {
        
        //#line 19 "x10/glb/ArrayListTaskBag.x10"
        return x10.glb.ArrayListTaskBag.this;
    }
    
    
    //#line 19 "x10/glb/ArrayListTaskBag.x10"
    // creation method for java code (1-phase java constructor)
    public ArrayListTaskBag(final x10.rtt.Type $T) {
        this((java.lang.System[]) null, $T);
        x10$glb$ArrayListTaskBag$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.glb.ArrayListTaskBag<$T> x10$glb$ArrayListTaskBag$$init$S() {
         {
            
            //#line 19 "x10/glb/ArrayListTaskBag.x10"
            
            
            //#line 19 "x10/glb/ArrayListTaskBag.x10"
            final x10.glb.ArrayListTaskBag this$117978 = this;
            
            //#line 21 . "x10/glb/ArrayListTaskBag.x10"
            final x10.util.ArrayList alloc$118009 = ((x10.util.ArrayList)(new x10.util.ArrayList<$T>((java.lang.System[]) null, $T)));
            
            //#line 21 . "x10/glb/ArrayListTaskBag.x10"
            alloc$118009.x10$util$ArrayList$$init$S();
            
            //#line 19 "x10/glb/ArrayListTaskBag.x10"
            ((x10.glb.ArrayListTaskBag<$T>)this$117978).bag = ((x10.util.ArrayList)(alloc$118009));
        }
        return this;
    }
    
    
    
    //#line 19 "x10/glb/ArrayListTaskBag.x10"
    final public void __fieldInitializers_x10_glb_ArrayListTaskBag() {
        
        //#line 21 "x10/glb/ArrayListTaskBag.x10"
        final x10.util.ArrayList alloc$117513 = ((x10.util.ArrayList)(new x10.util.ArrayList<$T>((java.lang.System[]) null, $T)));
        
        //#line 21 "x10/glb/ArrayListTaskBag.x10"
        alloc$117513.x10$util$ArrayList$$init$S();
        
        //#line 19 "x10/glb/ArrayListTaskBag.x10"
        ((x10.glb.ArrayListTaskBag<$T>)this).bag = ((x10.util.ArrayList)(alloc$117513));
    }
}

