package x10.lang;


@x10.runtime.impl.java.X10Generated
public interface Settable<$I, $V> extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<Settable> $RTT = 
        x10.rtt.NamedType.<Settable> make("x10.lang.Settable",
                                          Settable.class,
                                          2);
    
    

    
    
    //#line 18 "x10/lang/Settable.x10"
    java.lang.Object $set(final java.lang.Object i, x10.rtt.Type t1, final java.lang.Object v, x10.rtt.Type t2);
}

