package x10.lang;


/**
 * The naive implementation of an accumulator (without any piggybacking on finish or clocks).
 */
@x10.runtime.impl.java.X10Generated
public class Accumulator<$T> extends x10.lang.Acc implements x10.io.CustomSerialization
{
    public static final x10.rtt.RuntimeType<Accumulator> $RTT = 
        x10.rtt.NamedType.<Accumulator> make("x10.lang.Accumulator",
                                             Accumulator.class,
                                             1,
                                             new x10.rtt.Type[] {
                                                 x10.io.CustomSerialization.$RTT,
                                                 x10.lang.Acc.$RTT
                                             });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    // custom serialization support
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Accumulator<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.Deserializer $ds = new x10.io.Deserializer($deserializer);
        $_obj.x10$lang$Accumulator$$init$S($ds);
        short $marker = $deserializer.readSerializationId();
        if ($marker != x10.serialization.SerializationConstants.CUSTOM_SERIALIZATION_END) { x10.serialization.X10JavaDeserializer.raiseSerializationProtocolError(); }
        return $_obj;
        
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        int $obj_id = $deserializer.record_reference(null); /* Get id eagerly so that ordering in object map is stable (needed for repeated reference mechanism) */
        x10.rtt.Type $T = (x10.rtt.Type) $deserializer.readObject();
        Accumulator $_obj = new Accumulator((java.lang.System[]) null, (x10.rtt.Type) $T);
        $deserializer.update_reference($obj_id, $_obj); /* Update entry in object map with the actual object before deserializing body */
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
    
        $serializer.write($T);
        serialize(new x10.io.Serializer($serializer)); 
        $serializer.writeSerializationId(x10.serialization.SerializationConstants.CUSTOM_SERIALIZATION_END);
        
    }
    
    // constructor just for allocation
    public Accumulator(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy);
        x10.lang.Accumulator.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final Accumulator $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$Accumulator$$T$2 {}
    

    
    //#line 25 "x10/lang/Accumulator.x10"
    public x10.core.GlobalRef<x10.lang.Acc> root;
    
    //#line 26 "x10/lang/Accumulator.x10"
    public $T curr;
    
    //#line 27 "x10/lang/Accumulator.x10"
    public x10.lang.Reducible<$T> red;
    
    
    //#line 29 "x10/lang/Accumulator.x10"
    public static void MYPRINT(final java.lang.String msg) {
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.core.Thread t$130705 = x10.core.Thread.currentThread();
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.xrx.Worker t$130706 = x10.rtt.Types.<x10.xrx.Worker> cast(t$130705,x10.xrx.Worker.$RTT);
        
        //#line 336 . "x10/xrx/Runtime.x10"
        final int t$130707 = t$130706.workerId;
        
        //#line 30 "x10/lang/Accumulator.x10"
        final java.lang.String t$130708 = (("Worker=") + ((x10.core.Int.$box(t$130707))));
        
        //#line 30 "x10/lang/Accumulator.x10"
        final java.lang.String t$130709 = ((t$130708) + (" "));
        
        //#line 30 "x10/lang/Accumulator.x10"
        final java.lang.String t$130710 = ((t$130709) + (msg));
        
        //#line 30 "x10/lang/Accumulator.x10"
        java.lang.System.err.println(t$130710);
    }
    
    
    //#line 33 "x10/lang/Accumulator.x10"
    // creation method for java code (1-phase java constructor)
    public Accumulator(final x10.rtt.Type $T, final x10.lang.Reducible<$T> red, __0$1x10$lang$Accumulator$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$lang$Accumulator$$init$S(red, (x10.lang.Accumulator.__0$1x10$lang$Accumulator$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Accumulator<$T> x10$lang$Accumulator$$init$S(final x10.lang.Reducible<$T> red, __0$1x10$lang$Accumulator$$T$2 $dummy) {
         {
            
            //#line 33 "x10/lang/Accumulator.x10"
            
            
            //#line 35 "x10/lang/Accumulator.x10"
            ((x10.lang.Accumulator<$T>)this).red = ((x10.lang.Reducible)(red));
            
            //#line 36 "x10/lang/Accumulator.x10"
            final x10.core.GlobalRef t$130711 = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.lang.Acc>(x10.lang.Acc.$RTT, ((x10.lang.Acc)(this)), (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
            
            //#line 36 "x10/lang/Accumulator.x10"
            ((x10.lang.Accumulator<$T>)this).root = ((x10.core.GlobalRef)(t$130711));
            
            //#line 37 "x10/lang/Accumulator.x10"
            final $T t$130712 = (($T)(((x10.lang.Reducible<$T>)red).zero$G()));
            
            //#line 37 "x10/lang/Accumulator.x10"
            ((x10.lang.Accumulator<$T>)this).curr = (($T)(t$130712));
        }
        return this;
    }
    
    
    
    //#line 39 "x10/lang/Accumulator.x10"
    // creation method for java code (1-phase java constructor)
    public Accumulator(final x10.rtt.Type $T, final x10.io.Deserializer ds) {
        this((java.lang.System[]) null, $T);
        x10$lang$Accumulator$$init$S(ds);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Accumulator<$T> x10$lang$Accumulator$$init$S(final x10.io.Deserializer ds) {
        x10$lang$Accumulator$$initForReflection(ds);
        
        return this;
    }
    
    public void x10$lang$Accumulator$$initForReflection(x10.io.Deserializer ds) {
         {
            
            //#line 39 "x10/lang/Accumulator.x10"
            
            
            //#line 41 "x10/lang/Accumulator.x10"
            final java.lang.Object t$130713 = ds.readAny();
            
            //#line 41 "x10/lang/Accumulator.x10"
            final x10.lang.Reducible t$130714 = x10.rtt.Types.<x10.lang.Reducible<$T>> cast(t$130713,x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, $T));
            
            //#line 41 "x10/lang/Accumulator.x10"
            ((x10.lang.Accumulator<$T>)this).red = ((x10.lang.Reducible)(t$130714));
            
            //#line 42 "x10/lang/Accumulator.x10"
            final java.lang.Object t$130715 = ds.readAny();
            
            //#line 42 "x10/lang/Accumulator.x10"
            final x10.core.GlobalRef t$130716 = ((x10.core.GlobalRef)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.core.GlobalRef.$RTT, x10.lang.Acc.$RTT),t$130715));
            
            //#line 42 "x10/lang/Accumulator.x10"
            ((x10.lang.Accumulator<$T>)this).root = ((x10.core.GlobalRef)(t$130716));
            
            //#line 43 "x10/lang/Accumulator.x10"
            final x10.lang.Reducible t$130717 = ((x10.lang.Reducible)(this.red));
            
            //#line 43 "x10/lang/Accumulator.x10"
            final $T t$130718 = (($T)(((x10.lang.Reducible<$T>)t$130717).zero$G()));
            
            //#line 43 "x10/lang/Accumulator.x10"
            ((x10.lang.Accumulator<$T>)this).curr = (($T)(t$130718));
        }
    }
    
    
    
    //#line 45 "x10/lang/Accumulator.x10"
    public void serialize(final x10.io.Serializer s) {
        
        //#line 46 "x10/lang/Accumulator.x10"
        final x10.lang.Reducible t$130719 = ((x10.lang.Reducible)(this.red));
        
        //#line 46 "x10/lang/Accumulator.x10"
        s.writeAny(((java.lang.Object)(t$130719)));
        
        //#line 47 "x10/lang/Accumulator.x10"
        final x10.core.GlobalRef t$130720 = ((x10.core.GlobalRef)(this.root));
        
        //#line 47 "x10/lang/Accumulator.x10"
        s.writeAny(((java.lang.Object)(t$130720)));
    }
    
    
    //#line 64 "x10/lang/Accumulator.x10"
    public x10.lang.Accumulator me() {
        
        //#line 64 "x10/lang/Accumulator.x10"
        final x10.core.GlobalRef t$130721 = ((x10.core.GlobalRef)(this.root));
        
        //#line 64 "x10/lang/Accumulator.x10"
        final x10.core.GlobalRef t$130689 = ((x10.core.GlobalRef)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.core.GlobalRef.$RTT, x10.lang.Acc.$RTT),t$130721));
        
        //#line 64 "x10/lang/Accumulator.x10"
        final x10.lang.Place t$130722 = ((x10.lang.Place)((t$130689).home));
        
        //#line 64 "x10/lang/Accumulator.x10"
        final boolean t$130723 = x10.rtt.Equality.equalsequals((t$130722),(x10.x10rt.X10RT.here()));
        
        //#line 64 "x10/lang/Accumulator.x10"
        final boolean t$130725 = !(t$130723);
        
        //#line 64 "x10/lang/Accumulator.x10"
        if (t$130725) {
            
            //#line 64 "x10/lang/Accumulator.x10"
            final x10.lang.FailedDynamicCheckException t$130724 = new x10.lang.FailedDynamicCheckException("x10.lang.GlobalRef[x10.lang.Acc]{self.home==here}");
            
            //#line 64 "x10/lang/Accumulator.x10"
            throw t$130724;
        }
        
        //#line 64 "x10/lang/Accumulator.x10"
        final x10.lang.Acc t$130726 = (((x10.core.GlobalRef<x10.lang.Acc>)(t$130689))).$apply$G();
        
        //#line 64 "x10/lang/Accumulator.x10"
        final x10.lang.Accumulator t$130727 = x10.rtt.Types.<x10.lang.Accumulator<$T>> cast(t$130726,x10.rtt.ParameterizedType.make(x10.lang.Accumulator.$RTT, $T));
        
        //#line 64 "x10/lang/Accumulator.x10"
        return t$130727;
    }
    
    
    //#line 68 "x10/lang/Accumulator.x10"
    /**
     * This method supplies/offers a value to the accumulator.
     */
    public void $larrow__0x10$lang$Accumulator$$T(final $T t) {
        
        //#line 69 "x10/lang/Accumulator.x10"
        final x10.core.GlobalRef t$130728 = ((x10.core.GlobalRef)(this.root));
        
        //#line 69 "x10/lang/Accumulator.x10"
        final x10.lang.Place t$130732 = ((x10.lang.Place)((t$130728).home));
        {
            
            //#line 69 "x10/lang/Accumulator.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$130732)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.Accumulator.$Closure$100<$T>($T, ((x10.lang.Accumulator<$T>)(this)), t, (x10.lang.Accumulator.$Closure$100.__0$1x10$lang$Accumulator$$Closure$100$$T$2__1x10$lang$Accumulator$$Closure$100$$T) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 80 "x10/lang/Accumulator.x10"
    /**
     * This method resets the accumulator.
     */
    public void $set__0x10$lang$Accumulator$$T(final $T t) {
        
        //#line 81 "x10/lang/Accumulator.x10"
        final x10.core.GlobalRef t$130733 = ((x10.core.GlobalRef)(this.root));
        
        //#line 81 "x10/lang/Accumulator.x10"
        final x10.lang.Place t$130734 = ((x10.lang.Place)((t$130733).home));
        {
            
            //#line 81 "x10/lang/Accumulator.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$130734)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.Accumulator.$Closure$101<$T>($T, ((x10.lang.Accumulator<$T>)(this)), t, (x10.lang.Accumulator.$Closure$101.__0$1x10$lang$Accumulator$$Closure$101$$T$2__1x10$lang$Accumulator$$Closure$101$$T) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 90 "x10/lang/Accumulator.x10"
    private $T localGetResult$G() {
        
        //#line 92 "x10/lang/Accumulator.x10"
        final $T t$130735 = (($T)(this.curr));
        
        //#line 92 "x10/lang/Accumulator.x10"
        return t$130735;
    }
    
    public static <$T>$T localGetResult$P__0$1x10$lang$Accumulator$$T$2$G(final x10.rtt.Type $T, final x10.lang.Accumulator<$T> Accumulator) {
        return ((x10.lang.Accumulator<$T>)Accumulator).localGetResult$G();
    }
    
    
    //#line 94 "x10/lang/Accumulator.x10"
    public $T $apply$G() {
        
        //#line 95 "x10/lang/Accumulator.x10"
        final x10.core.GlobalRef t$130597 = ((x10.core.GlobalRef)(this.root));
        
        //#line 95 "x10/lang/Accumulator.x10"
        final x10.lang.Place t$130600 = ((x10.lang.Place)((t$130597).home));
        
        //#line 95 "x10/lang/Accumulator.x10"
        final $T t$130601 = (($T)(x10.xrx.Runtime.<$T> evalAt__1$1x10$xrx$Runtime$$T$2$G($T, ((x10.lang.Place)(t$130600)), ((x10.core.fun.Fun_0_0)(new x10.lang.Accumulator.$Closure$102<$T>($T, ((x10.lang.Accumulator<$T>)(this)), (x10.lang.Accumulator.$Closure$102.__0$1x10$lang$Accumulator$$Closure$102$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)))));
        
        //#line 95 "x10/lang/Accumulator.x10"
        return t$130601;
    }
    
    
    //#line 99 "x10/lang/Accumulator.x10"
    public void supply(final java.lang.Object t) {
        
        //#line 100 "x10/lang/Accumulator.x10"
        final $T t$130736 = (($T)(x10.rtt.Types.<$T> cast(t,$T)));
        
        //#line 100 "x10/lang/Accumulator.x10"
        this.$larrow__0x10$lang$Accumulator$$T((($T)(t$130736)));
    }
    
    
    //#line 102 "x10/lang/Accumulator.x10"
    public void reset(final java.lang.Object t) {
        
        //#line 103 "x10/lang/Accumulator.x10"
        final $T t$130737 = (($T)(x10.rtt.Types.<$T> cast(t,$T)));
        
        //#line 103 "x10/lang/Accumulator.x10"
        this.$set__0x10$lang$Accumulator$$T((($T)(t$130737)));
    }
    
    
    //#line 105 "x10/lang/Accumulator.x10"
    public java.lang.Object result() {
        
        //#line 106 "x10/lang/Accumulator.x10"
        final $T t$130738 = (($T)(this.$apply$G()));
        
        //#line 106 "x10/lang/Accumulator.x10"
        return ((java.lang.Object)
                 t$130738);
    }
    
    
    //#line 110 "x10/lang/Accumulator.x10"
    public java.lang.Object calcResult() {
        
        //#line 110 "x10/lang/Accumulator.x10"
        final x10.lang.IllegalOperationException t$130739 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException()));
        
        //#line 110 "x10/lang/Accumulator.x10"
        throw t$130739;
    }
    
    
    //#line 111 "x10/lang/Accumulator.x10"
    public void acceptResult(final java.lang.Object a) {
        
        //#line 111 "x10/lang/Accumulator.x10"
        final x10.lang.IllegalOperationException t$130740 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException()));
        
        //#line 111 "x10/lang/Accumulator.x10"
        throw t$130740;
    }
    
    
    //#line 112 "x10/lang/Accumulator.x10"
    public x10.core.GlobalRef getRoot() {
        
        //#line 112 "x10/lang/Accumulator.x10"
        final x10.core.GlobalRef t$130741 = ((x10.core.GlobalRef)(this.root));
        
        //#line 112 "x10/lang/Accumulator.x10"
        return t$130741;
    }
    
    
    //#line 113 "x10/lang/Accumulator.x10"
    public x10.lang.Place home() {
        
        //#line 113 "x10/lang/Accumulator.x10"
        final x10.core.GlobalRef t$130742 = ((x10.core.GlobalRef)(this.root));
        
        //#line 113 "x10/lang/Accumulator.x10"
        final x10.lang.Place t$130743 = ((x10.lang.Place)((t$130742).home));
        
        //#line 113 "x10/lang/Accumulator.x10"
        return t$130743;
    }
    
    
    //#line 23 "x10/lang/Accumulator.x10"
    final public x10.lang.Accumulator x10$lang$Accumulator$$this$x10$lang$Accumulator() {
        
        //#line 23 "x10/lang/Accumulator.x10"
        return x10.lang.Accumulator.this;
    }
    
    
    //#line 23 "x10/lang/Accumulator.x10"
    final public void __fieldInitializers_x10_lang_Accumulator() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$100<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$100> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$100> make($Closure$100.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Accumulator.$Closure$100<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.t = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Accumulator.$Closure$100 $_obj = new x10.lang.Accumulator.$Closure$100((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$$);
            $serializer.write(this.t);
            
        }
        
        // constructor just for allocation
        public $Closure$100(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.Accumulator.$Closure$100.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$100 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Accumulator$$Closure$100$$T$2__1x10$lang$Accumulator$$Closure$100$$T {}
        
    
        
        public void $apply() {
            
            //#line 69 "x10/lang/Accumulator.x10"
            try {{
                
                //#line 70 "x10/lang/Accumulator.x10"
                final x10.lang.Accumulator me = ((x10.lang.Accumulator<$T>)
                                                  ((x10.lang.Accumulator<$T>)this.out$$).me());
                
                //#line 72 "x10/lang/Accumulator.x10"
                try {{
                    
                    //#line 72 "x10/lang/Accumulator.x10"
                    x10.xrx.Runtime.enterAtomic();
                    {
                        
                        //#line 73 "x10/lang/Accumulator.x10"
                        final x10.lang.Reducible t$130729 = ((x10.lang.Reducible)(((x10.lang.Accumulator<$T>)me).red));
                        
                        //#line 73 "x10/lang/Accumulator.x10"
                        final $T t$130730 = (($T)(((x10.lang.Accumulator<$T>)me).curr));
                        
                        //#line 73 "x10/lang/Accumulator.x10"
                        final $T t$130731 = (($T)((($T)
                                                    ((x10.lang.Reducible<$T>)t$130729).$apply((($T)(t$130730)), $T, (($T)(this.t)), $T))));
                        
                        //#line 73 "x10/lang/Accumulator.x10"
                        ((x10.lang.Accumulator<$T>)me).curr = (($T)(t$130731));
                    }
                }}finally {{
                      
                      //#line 72 "x10/lang/Accumulator.x10"
                      x10.xrx.Runtime.exitAtomic();
                  }}
                }}catch (java.lang.Throwable __lowerer__var__0__) {
                    
                    //#line 69 "x10/lang/Accumulator.x10"
                    int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
                }
            }
        
        public x10.lang.Accumulator<$T> out$$;
        public $T t;
        
        public $Closure$100(final x10.rtt.Type $T, final x10.lang.Accumulator<$T> out$$, final $T t, __0$1x10$lang$Accumulator$$Closure$100$$T$2__1x10$lang$Accumulator$$Closure$100$$T $dummy) {
            x10.lang.Accumulator.$Closure$100.$initParams(this, $T);
             {
                ((x10.lang.Accumulator.$Closure$100<$T>)this).out$$ = out$$;
                ((x10.lang.Accumulator.$Closure$100<$T>)this).t = (($T)(t));
            }
        }
        
        }
        
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$101<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$101> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$101> make($Closure$101.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Accumulator.$Closure$101<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.t = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Accumulator.$Closure$101 $_obj = new x10.lang.Accumulator.$Closure$101((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$$);
            $serializer.write(this.t);
            
        }
        
        // constructor just for allocation
        public $Closure$101(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.Accumulator.$Closure$101.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$101 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Accumulator$$Closure$101$$T$2__1x10$lang$Accumulator$$Closure$101$$T {}
        
    
        
        public void $apply() {
            
            //#line 81 "x10/lang/Accumulator.x10"
            try {{
                
                //#line 82 "x10/lang/Accumulator.x10"
                final x10.lang.Accumulator me = ((x10.lang.Accumulator<$T>)
                                                  ((x10.lang.Accumulator<$T>)this.out$$).me());
                
                //#line 84 "x10/lang/Accumulator.x10"
                try {{
                    
                    //#line 84 "x10/lang/Accumulator.x10"
                    x10.xrx.Runtime.enterAtomic();
                    {
                        
                        //#line 85 "x10/lang/Accumulator.x10"
                        ((x10.lang.Accumulator<$T>)me).curr = (($T)(this.t));
                    }
                }}finally {{
                      
                      //#line 84 "x10/lang/Accumulator.x10"
                      x10.xrx.Runtime.exitAtomic();
                  }}
                }}catch (java.lang.Throwable __lowerer__var__0__) {
                    
                    //#line 81 "x10/lang/Accumulator.x10"
                    int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
                }
            }
        
        public x10.lang.Accumulator<$T> out$$;
        public $T t;
        
        public $Closure$101(final x10.rtt.Type $T, final x10.lang.Accumulator<$T> out$$, final $T t, __0$1x10$lang$Accumulator$$Closure$101$$T$2__1x10$lang$Accumulator$$Closure$101$$T $dummy) {
            x10.lang.Accumulator.$Closure$101.$initParams(this, $T);
             {
                ((x10.lang.Accumulator.$Closure$101<$T>)this).out$$ = out$$;
                ((x10.lang.Accumulator.$Closure$101<$T>)this).t = (($T)(t));
            }
        }
        
        }
        
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$102<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$102> $RTT = 
            x10.rtt.StaticFunType.<$Closure$102> make($Closure$102.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Accumulator.$Closure$102<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Accumulator.$Closure$102 $_obj = new x10.lang.Accumulator.$Closure$102((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$102(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.Accumulator.$Closure$102.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$102 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Accumulator$$Closure$102$$T$2 {}
        
    
        
        public $T $apply$G() {
            
            //#line 95 "x10/lang/Accumulator.x10"
            try {{
                
                //#line 95 "x10/lang/Accumulator.x10"
                final x10.lang.Accumulator t$130598 = ((x10.lang.Accumulator<$T>)
                                                        ((x10.lang.Accumulator<$T>)this.out$$).me());
                
                //#line 95 "x10/lang/Accumulator.x10"
                final $T t$130599 = (($T)(((x10.lang.Accumulator<$T>)t$130598).curr));
                
                //#line 95 "x10/lang/Accumulator.x10"
                return t$130599;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 95 "x10/lang/Accumulator.x10"
                $T __lowerer__var__1__ = (($T)(x10.xrx.Runtime.<$T> wrapAtChecked$G($T, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 95 "x10/lang/Accumulator.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.lang.Accumulator<$T> out$$;
        
        public $Closure$102(final x10.rtt.Type $T, final x10.lang.Accumulator<$T> out$$, __0$1x10$lang$Accumulator$$Closure$102$$T$2 $dummy) {
            x10.lang.Accumulator.$Closure$102.$initParams(this, $T);
             {
                ((x10.lang.Accumulator.$Closure$102<$T>)this).out$$ = out$$;
            }
        }
        
    }
    
    }
    
    