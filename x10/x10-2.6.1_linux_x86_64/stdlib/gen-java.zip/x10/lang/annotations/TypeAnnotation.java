package x10.lang.annotations;

@x10.runtime.impl.java.X10Generated
public interface TypeAnnotation extends x10.lang.annotations.Annotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<TypeAnnotation> $RTT = 
        x10.rtt.NamedType.<TypeAnnotation> make("x10.lang.annotations.TypeAnnotation",
                                                TypeAnnotation.class,
                                                new x10.rtt.Type[] {
                                                    x10.lang.annotations.Annotation.$RTT
                                                });
    
    
}

