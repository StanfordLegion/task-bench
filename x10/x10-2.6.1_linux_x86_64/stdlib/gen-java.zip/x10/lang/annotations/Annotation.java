package x10.lang.annotations;

@x10.runtime.impl.java.X10Generated
public interface Annotation extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<Annotation> $RTT = 
        x10.rtt.NamedType.<Annotation> make("x10.lang.annotations.Annotation",
                                            Annotation.class);
    
    
}

