package x10.lang;


/** A read-only view on a rail in memory.  On the CPU, this class has no effect
 * on behavior or performance.  On the GPU, it denotes memory that should back
 * the GPU constant cache.  Behaviour is therefore undefined if the backing rail
 * is modified while the CUDAConstantRail view is being used.
 */
@x10.runtime.impl.java.X10Generated
public class CUDAConstantRail<$T> extends x10.core.Struct implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<CUDAConstantRail> $RTT = 
        x10.rtt.NamedStructType.<CUDAConstantRail> make("x10.lang.CUDAConstantRail",
                                                        CUDAConstantRail.class,
                                                        1,
                                                        new x10.rtt.Type[] {
                                                            x10.rtt.Types.STRUCT
                                                        });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.CUDAConstantRail<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.backing = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.CUDAConstantRail $_obj = new x10.lang.CUDAConstantRail((java.lang.System[]) null, (x10.rtt.Type) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.backing);
        
    }
    
    // zero value constructor
    public CUDAConstantRail(final x10.rtt.Type $T, final java.lang.System $dummy) { this.$T = $T; this.backing = null; }
    
    // constructor just for allocation
    public CUDAConstantRail(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.lang.CUDAConstantRail.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final CUDAConstantRail $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$CUDAConstantRail$$T$2 {}
    

    
    //#line 24 "x10/lang/CUDAConstantRail.x10"
    /** Backing rail. */
    public x10.core.Rail<$T> backing;
    
    
    //#line 27 "x10/lang/CUDAConstantRail.x10"
    /** Create a view on given a backing rail. */
    // creation method for java code (1-phase java constructor)
    public CUDAConstantRail(final x10.rtt.Type $T, final x10.core.Rail<$T> backing, __0$1x10$lang$CUDAConstantRail$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$lang$CUDAConstantRail$$init$S(backing, (x10.lang.CUDAConstantRail.__0$1x10$lang$CUDAConstantRail$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.CUDAConstantRail<$T> x10$lang$CUDAConstantRail$$init$S(final x10.core.Rail<$T> backing, __0$1x10$lang$CUDAConstantRail$$T$2 $dummy) {
         {
            
            //#line 27 "x10/lang/CUDAConstantRail.x10"
            
            
            //#line 28 "x10/lang/CUDAConstantRail.x10"
            ((x10.lang.CUDAConstantRail<$T>)this).backing = ((x10.core.Rail)(backing));
        }
        return this;
    }
    
    
    
    //#line 33 "x10/lang/CUDAConstantRail.x10"
    /** On the CPU, delegate accesses to the backing rail. */
    final public $T $apply$G(final long i) {
        
        //#line 34 "x10/lang/CUDAConstantRail.x10"
        final x10.core.Rail t$130845 = ((x10.core.Rail)(this.backing));
        
        //#line 34 "x10/lang/CUDAConstantRail.x10"
        final $T t$130846 = (($T)(((x10.core.Rail<$T>)t$130845).$apply$G((long)(i))));
        
        //#line 34 "x10/lang/CUDAConstantRail.x10"
        return t$130846;
    }
    
    
    //#line 21 "x10/lang/CUDAConstantRail.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$205575) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205575);
        }
        
    }
    
    
    
    //#line 21 "x10/lang/CUDAConstantRail.x10"
    final public java.lang.String toString() {
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final java.lang.String t$130847 = "struct x10.lang.CUDAConstantRail: backing=";
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final x10.core.Rail t$130848 = ((x10.core.Rail)(this.backing));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final java.lang.String t$130849 = ((t$130847) + (t$130848));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        return t$130849;
    }
    
    
    //#line 21 "x10/lang/CUDAConstantRail.x10"
    final public int hashCode() {
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        int result = 1;
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final int t$130852 = ((8191) * (((int)(result))));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final x10.core.Rail t$130851 = ((x10.core.Rail)(this.backing));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final int t$130853 = x10.rtt.Types.hashCode(((java.lang.Object)(t$130851)));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final int t$130854 = ((t$130852) + (((int)(t$130853))));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        result = t$130854;
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        return result;
    }
    
    
    //#line 21 "x10/lang/CUDAConstantRail.x10"
    final public boolean equals(java.lang.Object other) {
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final boolean t$130857 = x10.lang.CUDAConstantRail.$RTT.isInstance(other, $T);
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final boolean t$130858 = !(t$130857);
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        if (t$130858) {
            
            //#line 21 "x10/lang/CUDAConstantRail.x10"
            return false;
        }
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final x10.lang.CUDAConstantRail this$130840 = ((x10.lang.CUDAConstantRail)(this));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        x10.lang.CUDAConstantRail other$130839 = ((x10.lang.CUDAConstantRail)(((x10.lang.CUDAConstantRail)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.CUDAConstantRail.$RTT, $T),other))));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final x10.core.Rail t$130861 = ((x10.core.Rail)(((x10.lang.CUDAConstantRail<$T>)this$130840).backing));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final x10.core.Rail t$130862 = ((x10.core.Rail)(((x10.lang.CUDAConstantRail<$T>)other$130839).backing));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final boolean t$130863 = x10.rtt.Equality.equalsequals((t$130861),(t$130862));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        return t$130863;
    }
    
    
    //#line 21 "x10/lang/CUDAConstantRail.x10"
    final public boolean equals__0$1x10$lang$CUDAConstantRail$$T$2$O(x10.lang.CUDAConstantRail other) {
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final x10.core.Rail t$130865 = ((x10.core.Rail)(this.backing));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final x10.core.Rail t$130866 = ((x10.core.Rail)(((x10.lang.CUDAConstantRail<$T>)other).backing));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final boolean t$130867 = x10.rtt.Equality.equalsequals((t$130865),(t$130866));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        return t$130867;
    }
    
    
    //#line 21 "x10/lang/CUDAConstantRail.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final boolean t$130869 = x10.lang.CUDAConstantRail.$RTT.isInstance(other, $T);
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final boolean t$130870 = !(t$130869);
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        if (t$130870) {
            
            //#line 21 "x10/lang/CUDAConstantRail.x10"
            return false;
        }
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final x10.lang.CUDAConstantRail this$130843 = ((x10.lang.CUDAConstantRail)(this));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        x10.lang.CUDAConstantRail other$130842 = ((x10.lang.CUDAConstantRail)(((x10.lang.CUDAConstantRail)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.CUDAConstantRail.$RTT, $T),other))));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final x10.core.Rail t$130873 = ((x10.core.Rail)(((x10.lang.CUDAConstantRail<$T>)this$130843).backing));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final x10.core.Rail t$130874 = ((x10.core.Rail)(((x10.lang.CUDAConstantRail<$T>)other$130842).backing));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final boolean t$130875 = x10.rtt.Equality.equalsequals((t$130873),(t$130874));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        return t$130875;
    }
    
    
    //#line 21 "x10/lang/CUDAConstantRail.x10"
    final public boolean _struct_equals__0$1x10$lang$CUDAConstantRail$$T$2$O(x10.lang.CUDAConstantRail other) {
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final x10.core.Rail t$130877 = ((x10.core.Rail)(this.backing));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final x10.core.Rail t$130878 = ((x10.core.Rail)(((x10.lang.CUDAConstantRail<$T>)other).backing));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        final boolean t$130879 = x10.rtt.Equality.equalsequals((t$130877),(t$130878));
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        return t$130879;
    }
    
    
    //#line 21 "x10/lang/CUDAConstantRail.x10"
    final public x10.lang.CUDAConstantRail x10$lang$CUDAConstantRail$$this$x10$lang$CUDAConstantRail() {
        
        //#line 21 "x10/lang/CUDAConstantRail.x10"
        return x10.lang.CUDAConstantRail.this;
    }
    
    
    //#line 21 "x10/lang/CUDAConstantRail.x10"
    final public void __fieldInitializers_x10_lang_CUDAConstantRail() {
        
    }
}

