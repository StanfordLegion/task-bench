package x10.lang;


@x10.runtime.impl.java.X10Generated
final public class Math extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Math> $RTT = 
        x10.rtt.NamedType.<Math> make("x10.lang.Math",
                                      Math.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Math $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.Math $_obj = new x10.lang.Math((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public Math(final java.lang.System[] $dummy) {
        
    }
    
    

    
    //#line 20 "x10/lang/Math.x10"
    final public static double E = 2.718281828459045;
    
    //#line 21 "x10/lang/Math.x10"
    final public static double PI = 3.141592653589793;
    
    
    //#line 23 "x10/lang/Math.x10"
    public static int abs$O(final int a) {
        try {
            return java.lang.Math.abs(a);
        }
        catch (java.lang.Throwable exc$205582) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205582);
        }
        
    }
    
    
    
    //#line 27 "x10/lang/Math.x10"
    public static long abs$O(final long a) {
        try {
            return java.lang.Math.abs(a);
        }
        catch (java.lang.Throwable exc$205583) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205583);
        }
        
    }
    
    
    
    //#line 31 "x10/lang/Math.x10"
    public static float abs$O(final float a) {
        try {
            return java.lang.Math.abs(a);
        }
        catch (java.lang.Throwable exc$205584) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205584);
        }
        
    }
    
    
    
    //#line 36 "x10/lang/Math.x10"
    public static double abs$O(final double a) {
        try {
            return java.lang.Math.abs(a);
        }
        catch (java.lang.Throwable exc$205585) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205585);
        }
        
    }
    
    
    
    //#line 41 "x10/lang/Math.x10"
    public static double ceil$O(final double a) {
        try {
            return java.lang.Math.ceil(a);
        }
        catch (java.lang.Throwable exc$205586) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205586);
        }
        
    }
    
    
    
    //#line 46 "x10/lang/Math.x10"
    public static double floor$O(final double a) {
        try {
            return java.lang.Math.floor(a);
        }
        catch (java.lang.Throwable exc$205587) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205587);
        }
        
    }
    
    
    
    //#line 51 "x10/lang/Math.x10"
    public static double rint$O(final double a) {
        try {
            return java.lang.Math.rint(a);
        }
        catch (java.lang.Throwable exc$205588) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205588);
        }
        
    }
    
    
    
    //#line 56 "x10/lang/Math.x10"
    public static double round$O(final double a) {
        try {
            return (double)java.lang.Math.round(a);
        }
        catch (java.lang.Throwable exc$205589) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205589);
        }
        
    }
    
    
    
    //#line 61 "x10/lang/Math.x10"
    public static float round$O(final float a) {
        try {
            return (float)java.lang.Math.round(a);
        }
        catch (java.lang.Throwable exc$205590) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205590);
        }
        
    }
    
    
    
    //#line 66 "x10/lang/Math.x10"
    public static int getExponent$O(final float a) {
        try {
            return java.lang.Math.getExponent(a);
        }
        catch (java.lang.Throwable exc$205591) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205591);
        }
        
    }
    
    
    
    //#line 71 "x10/lang/Math.x10"
    public static int getExponent$O(final double a) {
        try {
            return java.lang.Math.getExponent(a);
        }
        catch (java.lang.Throwable exc$205592) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205592);
        }
        
    }
    
    
    
    //#line 76 "x10/lang/Math.x10"
    public static double scalb$O(final double a, final int b) {
        try {
            return java.lang.Math.scalb(a,b);
        }
        catch (java.lang.Throwable exc$205593) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205593);
        }
        
    }
    
    
    
    //#line 81 "x10/lang/Math.x10"
    public static float scalb$O(final float a, final int b) {
        try {
            return java.lang.Math.scalb(a,b);
        }
        catch (java.lang.Throwable exc$205594) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205594);
        }
        
    }
    
    
    
    //#line 86 "x10/lang/Math.x10"
    public static double pow$O(final double a, final double b) {
        try {
            return java.lang.Math.pow(a,b);
        }
        catch (java.lang.Throwable exc$205595) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205595);
        }
        
    }
    
    
    
    //#line 91 "x10/lang/Math.x10"
    public static float pow$O(final float a, final float b) {
        try {
            return (float)java.lang.Math.pow(a,b);
        }
        catch (java.lang.Throwable exc$205596) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205596);
        }
        
    }
    
    
    
    //#line 96 "x10/lang/Math.x10"
    public static double pow$O(final int a, final double b) {
        
        //#line 96 "x10/lang/Math.x10"
        final double t$133346 = ((double)(int)(((int)(a))));
        
        //#line 96 "x10/lang/Math.x10"
        final double t$133347 = java.lang.Math.pow(((double)(t$133346)),((double)(b)));
        
        //#line 96 "x10/lang/Math.x10"
        return t$133347;
    }
    
    
    //#line 97 "x10/lang/Math.x10"
    public static double pow$O(final double a, final int b) {
        
        //#line 97 "x10/lang/Math.x10"
        final double t$133348 = ((double)(int)(((int)(b))));
        
        //#line 97 "x10/lang/Math.x10"
        final double t$133349 = java.lang.Math.pow(((double)(a)),((double)(t$133348)));
        
        //#line 97 "x10/lang/Math.x10"
        return t$133349;
    }
    
    
    //#line 98 "x10/lang/Math.x10"
    public static double pow$O(final int a, final int b) {
        
        //#line 98 "x10/lang/Math.x10"
        final double t$133350 = ((double)(int)(((int)(a))));
        
        //#line 98 "x10/lang/Math.x10"
        final double t$133351 = ((double)(int)(((int)(b))));
        
        //#line 98 "x10/lang/Math.x10"
        final double t$133352 = java.lang.Math.pow(((double)(t$133350)),((double)(t$133351)));
        
        //#line 98 "x10/lang/Math.x10"
        return t$133352;
    }
    
    
    //#line 99 "x10/lang/Math.x10"
    public static double pow$O(final long a, final double b) {
        
        //#line 99 "x10/lang/Math.x10"
        final double t$133353 = ((double)(long)(((long)(a))));
        
        //#line 99 "x10/lang/Math.x10"
        final double t$133354 = java.lang.Math.pow(((double)(t$133353)),((double)(b)));
        
        //#line 99 "x10/lang/Math.x10"
        return t$133354;
    }
    
    
    //#line 100 "x10/lang/Math.x10"
    public static double pow$O(final double a, final long b) {
        
        //#line 100 "x10/lang/Math.x10"
        final double t$133355 = ((double)(long)(((long)(b))));
        
        //#line 100 "x10/lang/Math.x10"
        final double t$133356 = java.lang.Math.pow(((double)(a)),((double)(t$133355)));
        
        //#line 100 "x10/lang/Math.x10"
        return t$133356;
    }
    
    
    //#line 101 "x10/lang/Math.x10"
    public static double pow$O(final long a, final long b) {
        
        //#line 101 "x10/lang/Math.x10"
        final double t$133357 = ((double)(long)(((long)(a))));
        
        //#line 101 "x10/lang/Math.x10"
        final double t$133358 = ((double)(long)(((long)(b))));
        
        //#line 101 "x10/lang/Math.x10"
        final double t$133359 = java.lang.Math.pow(((double)(t$133357)),((double)(t$133358)));
        
        //#line 101 "x10/lang/Math.x10"
        return t$133359;
    }
    
    
    //#line 106 "x10/lang/Math.x10"
    /**
     * @deprecated use {@link #pow(Float,Float)} instead
     */
    public static float powf$O(final float a, final float b) {
        try {
            return (float)java.lang.Math.pow(a,b);
        }
        catch (java.lang.Throwable exc$205597) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205597);
        }
        
    }
    
    
    
    //#line 118 "x10/lang/Math.x10"
    /**
     * Returns the principal value of the complex power <code>a^b</code>.
     * The branch cuts are on the real line at (-inf, 0) for real(b) <= 0,
     * and (-inf, 0] for real(b) > 0.   pow(0,0) is not defined.
     * @return a raised to the power <code>b</code>
     * @see http://mathworld.wolfram.com/Power.html
     */
    public static x10.lang.Complex pow(final x10.lang.Complex a, final x10.lang.Complex b) {
        
        //#line 119 "x10/lang/Math.x10"
        final x10.lang.Complex t$133360 = x10.lang.Math.log(((x10.lang.Complex)(a)));
        
        //#line 119 "x10/lang/Math.x10"
        final x10.lang.Complex t$133361 = t$133360.$times(((x10.lang.Complex)(b)));
        
        //#line 119 "x10/lang/Math.x10"
        final x10.lang.Complex t$133362 = x10.lang.Math.exp(((x10.lang.Complex)(t$133361)));
        
        //#line 119 "x10/lang/Math.x10"
        return t$133362;
    }
    
    
    //#line 121 "x10/lang/Math.x10"
    public static double exp$O(final double a) {
        try {
            return java.lang.Math.exp(a);
        }
        catch (java.lang.Throwable exc$205598) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205598);
        }
        
    }
    
    
    
    //#line 126 "x10/lang/Math.x10"
    public static float exp$O(final float a) {
        try {
            return (float)java.lang.Math.exp(a);
        }
        catch (java.lang.Throwable exc$205599) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205599);
        }
        
    }
    
    
    
    //#line 131 "x10/lang/Math.x10"
    public static double exp$O(final int a) {
        
        //#line 131 "x10/lang/Math.x10"
        final double t$133363 = ((double)(int)(((int)(a))));
        
        //#line 131 "x10/lang/Math.x10"
        final double t$133364 = java.lang.Math.exp(((double)(t$133363)));
        
        //#line 131 "x10/lang/Math.x10"
        return t$133364;
    }
    
    
    //#line 132 "x10/lang/Math.x10"
    public static double exp$O(final long a) {
        
        //#line 132 "x10/lang/Math.x10"
        final double t$133365 = ((double)(long)(((long)(a))));
        
        //#line 132 "x10/lang/Math.x10"
        final double t$133366 = java.lang.Math.exp(((double)(t$133365)));
        
        //#line 132 "x10/lang/Math.x10"
        return t$133366;
    }
    
    
    //#line 137 "x10/lang/Math.x10"
    /**
     * @deprecated use {@link #exp(Float)} instead
     */
    public static float expf$O(final float a) {
        try {
            return (float)java.lang.Math.exp(a);
        }
        catch (java.lang.Throwable exc$205600) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205600);
        }
        
    }
    
    
    
    //#line 146 "x10/lang/Math.x10"
    /**
     * @return the exponential function <code>e^a</code>
     * @see http://mathworld.wolfram.com/ExponentialFunction.html
     */
    public static x10.lang.Complex exp(final x10.lang.Complex a) {
        
        //#line 148 "x10/lang/Math.x10"
        final boolean t$133368 = a.isNaN$O();
        
        //#line 148 "x10/lang/Math.x10"
        if (t$133368) {
            
            //#line 149 "x10/lang/Math.x10"
            final x10.lang.Complex t$133367 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 149 "x10/lang/Math.x10"
            return t$133367;
        }
        
        //#line 151 "x10/lang/Math.x10"
        final double t$133369 = a.re;
        
        //#line 151 "x10/lang/Math.x10"
        final double expRe = java.lang.Math.exp(((double)(t$133369)));
        
        //#line 152 "x10/lang/Math.x10"
        final double t$133370 = a.im;
        
        //#line 152 "x10/lang/Math.x10"
        final double t$133371 = java.lang.Math.cos(((double)(t$133370)));
        
        //#line 152 "x10/lang/Math.x10"
        final double t$133374 = ((expRe) * (((double)(t$133371))));
        
        //#line 152 "x10/lang/Math.x10"
        final double t$133372 = a.im;
        
        //#line 152 "x10/lang/Math.x10"
        final double t$133373 = java.lang.Math.sin(((double)(t$133372)));
        
        //#line 152 "x10/lang/Math.x10"
        final double t$133375 = ((expRe) * (((double)(t$133373))));
        
        //#line 152 "x10/lang/Math.x10"
        final x10.lang.Complex t$133376 = new x10.lang.Complex(t$133374, t$133375);
        
        //#line 152 "x10/lang/Math.x10"
        return t$133376;
    }
    
    
    //#line 155 "x10/lang/Math.x10"
    public static double expm1$O(final double a) {
        try {
            return java.lang.Math.expm1(a);
        }
        catch (java.lang.Throwable exc$205601) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205601);
        }
        
    }
    
    
    
    //#line 160 "x10/lang/Math.x10"
    public static double cos$O(final double a) {
        try {
            return java.lang.Math.cos(a);
        }
        catch (java.lang.Throwable exc$205602) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205602);
        }
        
    }
    
    
    
    //#line 169 "x10/lang/Math.x10"
    /**
     * @return the cosine of <code>z</code>
     * @see http://mathworld.wolfram.com/Cosine.html
     */
    public static x10.lang.Complex cos(final x10.lang.Complex z) {
        
        //#line 171 "x10/lang/Math.x10"
        final double t$133377 = z.im;
        
        //#line 171 "x10/lang/Math.x10"
        final boolean t$133393 = ((double) t$133377) == ((double) 0.0);
        
        //#line 171 "x10/lang/Math.x10"
        if (t$133393) {
            
            //#line 172 "x10/lang/Math.x10"
            final double t$133378 = z.re;
            
            //#line 172 "x10/lang/Math.x10"
            final double t$133379 = java.lang.Math.cos(((double)(t$133378)));
            
            //#line 172 "x10/lang/Math.x10"
            final x10.lang.Complex t$133380 = new x10.lang.Complex(t$133379, ((double)(0.0)));
            
            //#line 172 "x10/lang/Math.x10"
            return t$133380;
        } else {
            
            //#line 174 "x10/lang/Math.x10"
            final double t$133381 = z.re;
            
            //#line 174 "x10/lang/Math.x10"
            final double t$133383 = java.lang.Math.cos(((double)(t$133381)));
            
            //#line 174 "x10/lang/Math.x10"
            final double t$133382 = z.im;
            
            //#line 174 "x10/lang/Math.x10"
            final double t$133384 = java.lang.Math.cosh(((double)(t$133382)));
            
            //#line 174 "x10/lang/Math.x10"
            final double t$133390 = ((t$133383) * (((double)(t$133384))));
            
            //#line 174 "x10/lang/Math.x10"
            final double t$133385 = z.re;
            
            //#line 174 "x10/lang/Math.x10"
            final double t$133388 = java.lang.Math.sin(((double)(t$133385)));
            
            //#line 174 "x10/lang/Math.x10"
            final double t$133386 = z.im;
            
            //#line 174 "x10/lang/Math.x10"
            final double t$133387 = (-(t$133386));
            
            //#line 174 "x10/lang/Math.x10"
            final double t$133389 = java.lang.Math.sinh(((double)(t$133387)));
            
            //#line 174 "x10/lang/Math.x10"
            final double t$133391 = ((t$133388) * (((double)(t$133389))));
            
            //#line 174 "x10/lang/Math.x10"
            final x10.lang.Complex t$133392 = new x10.lang.Complex(t$133390, t$133391);
            
            //#line 174 "x10/lang/Math.x10"
            return t$133392;
        }
    }
    
    
    //#line 178 "x10/lang/Math.x10"
    public static double sin$O(final double a) {
        try {
            return java.lang.Math.sin(a);
        }
        catch (java.lang.Throwable exc$205603) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205603);
        }
        
    }
    
    
    
    //#line 187 "x10/lang/Math.x10"
    /**
     * @return the sine of <code>z</code>
     * @see http://mathworld.wolfram.com/Sine.html
     */
    public static x10.lang.Complex sin(final x10.lang.Complex z) {
        
        //#line 189 "x10/lang/Math.x10"
        final double t$133394 = z.im;
        
        //#line 189 "x10/lang/Math.x10"
        final boolean t$133409 = ((double) t$133394) == ((double) 0.0);
        
        //#line 189 "x10/lang/Math.x10"
        if (t$133409) {
            
            //#line 190 "x10/lang/Math.x10"
            final double t$133395 = z.re;
            
            //#line 190 "x10/lang/Math.x10"
            final double t$133396 = java.lang.Math.sin(((double)(t$133395)));
            
            //#line 190 "x10/lang/Math.x10"
            final x10.lang.Complex t$133397 = new x10.lang.Complex(t$133396, ((double)(0.0)));
            
            //#line 190 "x10/lang/Math.x10"
            return t$133397;
        } else {
            
            //#line 192 "x10/lang/Math.x10"
            final double t$133398 = z.re;
            
            //#line 192 "x10/lang/Math.x10"
            final double t$133400 = java.lang.Math.sin(((double)(t$133398)));
            
            //#line 192 "x10/lang/Math.x10"
            final double t$133399 = z.im;
            
            //#line 192 "x10/lang/Math.x10"
            final double t$133401 = java.lang.Math.cosh(((double)(t$133399)));
            
            //#line 192 "x10/lang/Math.x10"
            final double t$133406 = ((t$133400) * (((double)(t$133401))));
            
            //#line 192 "x10/lang/Math.x10"
            final double t$133402 = z.re;
            
            //#line 192 "x10/lang/Math.x10"
            final double t$133404 = java.lang.Math.cos(((double)(t$133402)));
            
            //#line 192 "x10/lang/Math.x10"
            final double t$133403 = z.im;
            
            //#line 192 "x10/lang/Math.x10"
            final double t$133405 = java.lang.Math.sinh(((double)(t$133403)));
            
            //#line 192 "x10/lang/Math.x10"
            final double t$133407 = ((t$133404) * (((double)(t$133405))));
            
            //#line 192 "x10/lang/Math.x10"
            final x10.lang.Complex t$133408 = new x10.lang.Complex(t$133406, t$133407);
            
            //#line 192 "x10/lang/Math.x10"
            return t$133408;
        }
    }
    
    
    //#line 196 "x10/lang/Math.x10"
    public static double tan$O(final double a) {
        try {
            return java.lang.Math.tan(a);
        }
        catch (java.lang.Throwable exc$205604) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205604);
        }
        
    }
    
    
    
    //#line 205 "x10/lang/Math.x10"
    /**
     * @return the tangent of <code>z</code>
     * @see http://mathworld.wolfram.com/Tangent.html
     */
    public static x10.lang.Complex tan(final x10.lang.Complex z) {
        
        //#line 207 "x10/lang/Math.x10"
        final double t$133410 = z.im;
        
        //#line 207 "x10/lang/Math.x10"
        final boolean t$133422 = ((double) t$133410) == ((double) 0.0);
        
        //#line 207 "x10/lang/Math.x10"
        if (t$133422) {
            
            //#line 208 "x10/lang/Math.x10"
            final double t$133411 = z.re;
            
            //#line 208 "x10/lang/Math.x10"
            final double t$133412 = java.lang.Math.tan(((double)(t$133411)));
            
            //#line 208 "x10/lang/Math.x10"
            final x10.lang.Complex t$133413 = new x10.lang.Complex(t$133412, ((double)(0.0)));
            
            //#line 208 "x10/lang/Math.x10"
            return t$133413;
        } else {
            
            //#line 211 "x10/lang/Math.x10"
            final x10.lang.Complex t$133414 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 211 "x10/lang/Math.x10"
            final x10.lang.Complex t$133415 = x10.lang.Complex.$times((double)(2.0), ((x10.lang.Complex)(t$133414)));
            
            //#line 211 "x10/lang/Math.x10"
            final x10.lang.Complex t$133416 = t$133415.$times(((x10.lang.Complex)(z)));
            
            //#line 211 "x10/lang/Math.x10"
            final x10.lang.Complex e2IZ = x10.lang.Math.exp(((x10.lang.Complex)(t$133416)));
            
            //#line 212 "x10/lang/Math.x10"
            final x10.lang.Complex t$133419 = e2IZ.$minus((double)(1.0));
            
            //#line 212 "x10/lang/Math.x10"
            final x10.lang.Complex t$133417 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 212 "x10/lang/Math.x10"
            final x10.lang.Complex t$133418 = e2IZ.$plus((double)(1.0));
            
            //#line 212 "x10/lang/Math.x10"
            final x10.lang.Complex t$133420 = t$133417.$times(((x10.lang.Complex)(t$133418)));
            
            //#line 212 "x10/lang/Math.x10"
            final x10.lang.Complex t$133421 = t$133419.$over(((x10.lang.Complex)(t$133420)));
            
            //#line 212 "x10/lang/Math.x10"
            return t$133421;
        }
    }
    
    
    //#line 216 "x10/lang/Math.x10"
    public static double acos$O(final double a) {
        try {
            return java.lang.Math.acos(a);
        }
        catch (java.lang.Throwable exc$205605) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205605);
        }
        
    }
    
    
    
    //#line 229 "x10/lang/Math.x10"
    /**
     * Returns the principal value of the inverse cosine of <code>z</code>.
     * The branch cuts are on the real line at (-inf, -1) and (1, +inf)
     * The real part of the inverse cosine ranges from 0 to PI.
     * @return the inverse cosine of <code>z</code>
     * @see http://mathworld.wolfram.com/InverseCosine.html
     */
    public static x10.lang.Complex acos(final x10.lang.Complex z) {
        
        //#line 230 "x10/lang/Math.x10"
        final double t$133423 = z.im;
        
        //#line 230 "x10/lang/Math.x10"
        boolean t$133426 = ((double) t$133423) == ((double) 0.0);
        
        //#line 230 "x10/lang/Math.x10"
        if (t$133426) {
            
            //#line 230 "x10/lang/Math.x10"
            final double t$133424 = z.re;
            
            //#line 230 "x10/lang/Math.x10"
            final double t$133425 = java.lang.Math.abs(((double)(t$133424)));
            
            //#line 230 "x10/lang/Math.x10"
            t$133426 = ((t$133425) <= (((double)(1.0))));
        }
        
        //#line 230 "x10/lang/Math.x10"
        if (t$133426) {
            
            //#line 231 "x10/lang/Math.x10"
            final double t$133427 = z.re;
            
            //#line 231 "x10/lang/Math.x10"
            final double t$133428 = java.lang.Math.acos(((double)(t$133427)));
            
            //#line 231 "x10/lang/Math.x10"
            final x10.lang.Complex t$133429 = new x10.lang.Complex(t$133428, ((double)(0.0)));
            
            //#line 231 "x10/lang/Math.x10"
            return t$133429;
        } else {
            
            //#line 234 "x10/lang/Math.x10"
            final double t$133438 = ((3.141592653589793) / (((double)(2.0))));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$133436 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$133430 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$133433 = t$133430.$times(((x10.lang.Complex)(z)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$133431 = z.$times(((x10.lang.Complex)(z)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$133432 = x10.lang.Complex.$minus((double)(1.0), ((x10.lang.Complex)(t$133431)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$133434 = x10.lang.Math.sqrt(((x10.lang.Complex)(t$133432)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$133435 = t$133433.$plus(((x10.lang.Complex)(t$133434)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$133437 = x10.lang.Math.log(((x10.lang.Complex)(t$133435)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$133439 = t$133436.$times(((x10.lang.Complex)(t$133437)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$133440 = x10.lang.Complex.$plus((double)(t$133438), ((x10.lang.Complex)(t$133439)));
            
            //#line 234 "x10/lang/Math.x10"
            return t$133440;
        }
    }
    
    
    //#line 238 "x10/lang/Math.x10"
    public static double asin$O(final double a) {
        try {
            return java.lang.Math.asin(a);
        }
        catch (java.lang.Throwable exc$205606) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205606);
        }
        
    }
    
    
    
    //#line 251 "x10/lang/Math.x10"
    /**
     * Returns the principal value of the inverse sine of <code>z</code>.
     * The branch cuts are on the real line at (-inf, -1) and (1, +inf)
     * The real part of the inverse sine ranges from -PI/2 to +PI/2.
     * @return the inverse sine of <code>z</code>
     * @see http://mathworld.wolfram.com/InverseSine.html
     */
    public static x10.lang.Complex asin(final x10.lang.Complex z) {
        
        //#line 252 "x10/lang/Math.x10"
        final double t$133442 = z.im;
        
        //#line 252 "x10/lang/Math.x10"
        boolean t$133445 = ((double) t$133442) == ((double) 0.0);
        
        //#line 252 "x10/lang/Math.x10"
        if (t$133445) {
            
            //#line 252 "x10/lang/Math.x10"
            final double t$133443 = z.re;
            
            //#line 252 "x10/lang/Math.x10"
            final double t$133444 = java.lang.Math.abs(((double)(t$133443)));
            
            //#line 252 "x10/lang/Math.x10"
            t$133445 = ((t$133444) <= (((double)(1.0))));
        }
        
        //#line 252 "x10/lang/Math.x10"
        if (t$133445) {
            
            //#line 253 "x10/lang/Math.x10"
            final double t$133446 = z.re;
            
            //#line 253 "x10/lang/Math.x10"
            final double t$133447 = java.lang.Math.asin(((double)(t$133446)));
            
            //#line 253 "x10/lang/Math.x10"
            final x10.lang.Complex t$133448 = new x10.lang.Complex(t$133447, ((double)(0.0)));
            
            //#line 253 "x10/lang/Math.x10"
            return t$133448;
        } else {
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$133449 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$133456 = t$133449.$minus();
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$133450 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$133453 = t$133450.$times(((x10.lang.Complex)(z)));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$133451 = z.$times(((x10.lang.Complex)(z)));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$133452 = x10.lang.Complex.$minus((double)(1.0), ((x10.lang.Complex)(t$133451)));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$133454 = x10.lang.Math.sqrt(((x10.lang.Complex)(t$133452)));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$133455 = t$133453.$plus(((x10.lang.Complex)(t$133454)));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$133457 = x10.lang.Math.log(((x10.lang.Complex)(t$133455)));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$133458 = t$133456.$times(((x10.lang.Complex)(t$133457)));
            
            //#line 256 "x10/lang/Math.x10"
            return t$133458;
        }
    }
    
    
    //#line 260 "x10/lang/Math.x10"
    public static double atan$O(final double a) {
        try {
            return java.lang.Math.atan(a);
        }
        catch (java.lang.Throwable exc$205607) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205607);
        }
        
    }
    
    
    
    //#line 273 "x10/lang/Math.x10"
    /**
     * Returns the principal value of the inverse tangent of <code>z</code>.
     * The branch cuts are on the imaginary line at (-i*inf, -i] and [i, i*inf)
     * The real part of the inverse tangent ranges from -PI/2 to +PI/2.
     * @return the principal value of the inverse tangent of <code>z</code>
     * @see http://mathworld.wolfram.com/InverseTangent.html
     */
    public static x10.lang.Complex atan(final x10.lang.Complex z) {
        
        //#line 274 "x10/lang/Math.x10"
        final double t$133460 = z.im;
        
        //#line 274 "x10/lang/Math.x10"
        final boolean t$133485 = ((double) t$133460) == ((double) 0.0);
        
        //#line 274 "x10/lang/Math.x10"
        if (t$133485) {
            
            //#line 275 "x10/lang/Math.x10"
            final double t$133461 = z.re;
            
            //#line 275 "x10/lang/Math.x10"
            final double t$133462 = java.lang.Math.atan(((double)(t$133461)));
            
            //#line 275 "x10/lang/Math.x10"
            final x10.lang.Complex t$133463 = new x10.lang.Complex(t$133462, ((double)(0.0)));
            
            //#line 275 "x10/lang/Math.x10"
            return t$133463;
        } else {
            
            //#line 276 "x10/lang/Math.x10"
            final x10.lang.Complex t$133464 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 276 "x10/lang/Math.x10"
            final boolean t$133484 = x10.rtt.Equality.equalsequals((z),(t$133464));
            
            //#line 276 "x10/lang/Math.x10"
            if (t$133484) {
                
                //#line 277 "x10/lang/Math.x10"
                final double t$133465 = java.lang.Double.POSITIVE_INFINITY;
                
                //#line 277 "x10/lang/Math.x10"
                final x10.lang.Complex t$133466 = new x10.lang.Complex(((double)(0.0)), ((double)(t$133465)));
                
                //#line 277 "x10/lang/Math.x10"
                return t$133466;
            } else {
                
                //#line 278 "x10/lang/Math.x10"
                final x10.lang.Complex t$133467 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
                
                //#line 278 "x10/lang/Math.x10"
                final x10.lang.Complex t$133468 = t$133467.$minus();
                
                //#line 278 "x10/lang/Math.x10"
                final boolean t$133483 = x10.rtt.Equality.equalsequals((z),(t$133468));
                
                //#line 278 "x10/lang/Math.x10"
                if (t$133483) {
                    
                    //#line 279 "x10/lang/Math.x10"
                    final double t$133469 = java.lang.Double.NEGATIVE_INFINITY;
                    
                    //#line 279 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133470 = new x10.lang.Complex(((double)(0.0)), ((double)(t$133469)));
                    
                    //#line 279 "x10/lang/Math.x10"
                    return t$133470;
                } else {
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133471 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133480 = t$133471.$over((double)(2.0));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133472 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133473 = t$133472.$times(((x10.lang.Complex)(z)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133474 = x10.lang.Complex.$minus((double)(1.0), ((x10.lang.Complex)(t$133473)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133478 = x10.lang.Math.log(((x10.lang.Complex)(t$133474)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133475 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133476 = t$133475.$times(((x10.lang.Complex)(z)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133477 = x10.lang.Complex.$plus((double)(1.0), ((x10.lang.Complex)(t$133476)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133479 = x10.lang.Math.log(((x10.lang.Complex)(t$133477)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133481 = t$133478.$minus(((x10.lang.Complex)(t$133479)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133482 = t$133480.$times(((x10.lang.Complex)(t$133481)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    return t$133482;
                }
            }
        }
    }
    
    
    //#line 286 "x10/lang/Math.x10"
    public static double atan2$O(final double a, final double b) {
        try {
            return java.lang.Math.atan2(a,b);
        }
        catch (java.lang.Throwable exc$205608) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205608);
        }
        
    }
    
    
    
    //#line 291 "x10/lang/Math.x10"
    public static double cosh$O(final double a) {
        try {
            return java.lang.Math.cosh(a);
        }
        catch (java.lang.Throwable exc$205609) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205609);
        }
        
    }
    
    
    
    //#line 300 "x10/lang/Math.x10"
    /**
     * @return the hyperbolic cosine of <code>z</code>
     * @see http://mathworld.wolfram.com/HyperbolicCosine.html
     */
    public static x10.lang.Complex cosh(final x10.lang.Complex z) {
        
        //#line 302 "x10/lang/Math.x10"
        final boolean t$133503 = z.isNaN$O();
        
        //#line 302 "x10/lang/Math.x10"
        if (t$133503) {
            
            //#line 303 "x10/lang/Math.x10"
            final x10.lang.Complex t$133486 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 303 "x10/lang/Math.x10"
            return t$133486;
        } else {
            
            //#line 304 "x10/lang/Math.x10"
            final double t$133487 = z.im;
            
            //#line 304 "x10/lang/Math.x10"
            final boolean t$133502 = ((double) t$133487) == ((double) 0.0);
            
            //#line 304 "x10/lang/Math.x10"
            if (t$133502) {
                
                //#line 305 "x10/lang/Math.x10"
                final double t$133488 = z.re;
                
                //#line 305 "x10/lang/Math.x10"
                final double t$133489 = java.lang.Math.cosh(((double)(t$133488)));
                
                //#line 305 "x10/lang/Math.x10"
                final x10.lang.Complex t$133490 = new x10.lang.Complex(t$133489, ((double)(0.0)));
                
                //#line 305 "x10/lang/Math.x10"
                return t$133490;
            } else {
                
                //#line 307 "x10/lang/Math.x10"
                final double t$133491 = z.re;
                
                //#line 307 "x10/lang/Math.x10"
                final double t$133493 = java.lang.Math.cosh(((double)(t$133491)));
                
                //#line 307 "x10/lang/Math.x10"
                final double t$133492 = z.im;
                
                //#line 307 "x10/lang/Math.x10"
                final double t$133494 = java.lang.Math.cos(((double)(t$133492)));
                
                //#line 307 "x10/lang/Math.x10"
                final double t$133499 = ((t$133493) * (((double)(t$133494))));
                
                //#line 307 "x10/lang/Math.x10"
                final double t$133495 = z.re;
                
                //#line 307 "x10/lang/Math.x10"
                final double t$133497 = java.lang.Math.sinh(((double)(t$133495)));
                
                //#line 307 "x10/lang/Math.x10"
                final double t$133496 = z.im;
                
                //#line 307 "x10/lang/Math.x10"
                final double t$133498 = java.lang.Math.sin(((double)(t$133496)));
                
                //#line 307 "x10/lang/Math.x10"
                final double t$133500 = ((t$133497) * (((double)(t$133498))));
                
                //#line 307 "x10/lang/Math.x10"
                final x10.lang.Complex t$133501 = new x10.lang.Complex(t$133499, t$133500);
                
                //#line 307 "x10/lang/Math.x10"
                return t$133501;
            }
        }
    }
    
    
    //#line 311 "x10/lang/Math.x10"
    public static double sinh$O(final double a) {
        try {
            return java.lang.Math.sinh(a);
        }
        catch (java.lang.Throwable exc$205610) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205610);
        }
        
    }
    
    
    
    //#line 320 "x10/lang/Math.x10"
    /**
     * @return the hyperbolic sine of <code>z</code>
     * @see http://mathworld.wolfram.com/HyperbolicSine.html
     */
    public static x10.lang.Complex sinh(final x10.lang.Complex z) {
        
        //#line 322 "x10/lang/Math.x10"
        final boolean t$133521 = z.isNaN$O();
        
        //#line 322 "x10/lang/Math.x10"
        if (t$133521) {
            
            //#line 323 "x10/lang/Math.x10"
            final x10.lang.Complex t$133504 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 323 "x10/lang/Math.x10"
            return t$133504;
        } else {
            
            //#line 324 "x10/lang/Math.x10"
            final double t$133505 = z.im;
            
            //#line 324 "x10/lang/Math.x10"
            final boolean t$133520 = ((double) t$133505) == ((double) 0.0);
            
            //#line 324 "x10/lang/Math.x10"
            if (t$133520) {
                
                //#line 325 "x10/lang/Math.x10"
                final double t$133506 = z.re;
                
                //#line 325 "x10/lang/Math.x10"
                final double t$133507 = java.lang.Math.sinh(((double)(t$133506)));
                
                //#line 325 "x10/lang/Math.x10"
                final x10.lang.Complex t$133508 = new x10.lang.Complex(t$133507, ((double)(0.0)));
                
                //#line 325 "x10/lang/Math.x10"
                return t$133508;
            } else {
                
                //#line 327 "x10/lang/Math.x10"
                final double t$133509 = z.re;
                
                //#line 327 "x10/lang/Math.x10"
                final double t$133511 = java.lang.Math.sinh(((double)(t$133509)));
                
                //#line 327 "x10/lang/Math.x10"
                final double t$133510 = z.im;
                
                //#line 327 "x10/lang/Math.x10"
                final double t$133512 = java.lang.Math.cos(((double)(t$133510)));
                
                //#line 327 "x10/lang/Math.x10"
                final double t$133517 = ((t$133511) * (((double)(t$133512))));
                
                //#line 327 "x10/lang/Math.x10"
                final double t$133513 = z.re;
                
                //#line 327 "x10/lang/Math.x10"
                final double t$133515 = java.lang.Math.cosh(((double)(t$133513)));
                
                //#line 327 "x10/lang/Math.x10"
                final double t$133514 = z.im;
                
                //#line 327 "x10/lang/Math.x10"
                final double t$133516 = java.lang.Math.sin(((double)(t$133514)));
                
                //#line 327 "x10/lang/Math.x10"
                final double t$133518 = ((t$133515) * (((double)(t$133516))));
                
                //#line 327 "x10/lang/Math.x10"
                final x10.lang.Complex t$133519 = new x10.lang.Complex(t$133517, t$133518);
                
                //#line 327 "x10/lang/Math.x10"
                return t$133519;
            }
        }
    }
    
    
    //#line 331 "x10/lang/Math.x10"
    public static double tanh$O(final double a) {
        try {
            return java.lang.Math.tanh(a);
        }
        catch (java.lang.Throwable exc$205611) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205611);
        }
        
    }
    
    
    
    //#line 340 "x10/lang/Math.x10"
    /**
     * @return the hyperbolic tangent of <code>z</code>
     * @see http://mathworld.wolfram.com/HyperbolicTangent.html
     */
    public static x10.lang.Complex tanh(final x10.lang.Complex z) {
        
        //#line 342 "x10/lang/Math.x10"
        final boolean t$133523 = z.isNaN$O();
        
        //#line 342 "x10/lang/Math.x10"
        if (t$133523) {
            
            //#line 343 "x10/lang/Math.x10"
            final x10.lang.Complex t$133522 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 343 "x10/lang/Math.x10"
            return t$133522;
        }
        
        //#line 345 "x10/lang/Math.x10"
        final double t$133524 = z.re;
        
        //#line 345 "x10/lang/Math.x10"
        final double t$133525 = ((2.0) * (((double)(t$133524))));
        
        //#line 345 "x10/lang/Math.x10"
        final double t$133528 = java.lang.Math.cosh(((double)(t$133525)));
        
        //#line 345 "x10/lang/Math.x10"
        final double t$133526 = z.im;
        
        //#line 345 "x10/lang/Math.x10"
        final double t$133527 = ((2.0) * (((double)(t$133526))));
        
        //#line 345 "x10/lang/Math.x10"
        final double t$133529 = java.lang.Math.cos(((double)(t$133527)));
        
        //#line 345 "x10/lang/Math.x10"
        final double d = ((t$133528) + (((double)(t$133529))));
        
        //#line 346 "x10/lang/Math.x10"
        final double t$133530 = z.re;
        
        //#line 346 "x10/lang/Math.x10"
        final double t$133531 = ((2.0) * (((double)(t$133530))));
        
        //#line 346 "x10/lang/Math.x10"
        final double t$133532 = java.lang.Math.sinh(((double)(t$133531)));
        
        //#line 346 "x10/lang/Math.x10"
        final double t$133536 = ((t$133532) / (((double)(d))));
        
        //#line 346 "x10/lang/Math.x10"
        final double t$133533 = z.im;
        
        //#line 346 "x10/lang/Math.x10"
        final double t$133534 = ((2.0) * (((double)(t$133533))));
        
        //#line 346 "x10/lang/Math.x10"
        final double t$133535 = java.lang.Math.sin(((double)(t$133534)));
        
        //#line 346 "x10/lang/Math.x10"
        final double t$133537 = ((t$133535) / (((double)(d))));
        
        //#line 346 "x10/lang/Math.x10"
        final x10.lang.Complex t$133538 = new x10.lang.Complex(t$133536, t$133537);
        
        //#line 346 "x10/lang/Math.x10"
        return t$133538;
    }
    
    
    //#line 349 "x10/lang/Math.x10"
    public static double sqrt$O(final double a) {
        try {
            return java.lang.Math.sqrt(a);
        }
        catch (java.lang.Throwable exc$205612) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205612);
        }
        
    }
    
    
    
    //#line 354 "x10/lang/Math.x10"
    public static float sqrt$O(final float a) {
        try {
            return (float)java.lang.Math.sqrt(a);
        }
        catch (java.lang.Throwable exc$205613) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205613);
        }
        
    }
    
    
    
    //#line 359 "x10/lang/Math.x10"
    public static double sqrt$O(final int a) {
        
        //#line 359 "x10/lang/Math.x10"
        final double t$133539 = ((double)(int)(((int)(a))));
        
        //#line 359 "x10/lang/Math.x10"
        final double t$133540 = java.lang.Math.sqrt(((double)(t$133539)));
        
        //#line 359 "x10/lang/Math.x10"
        return t$133540;
    }
    
    
    //#line 360 "x10/lang/Math.x10"
    public static double sqrt$O(final long a) {
        
        //#line 360 "x10/lang/Math.x10"
        final double t$133541 = ((double)(long)(((long)(a))));
        
        //#line 360 "x10/lang/Math.x10"
        final double t$133542 = java.lang.Math.sqrt(((double)(t$133541)));
        
        //#line 360 "x10/lang/Math.x10"
        return t$133542;
    }
    
    
    //#line 365 "x10/lang/Math.x10"
    /**
     * @deprecated use {@link #sqrt(Float)} instead
     */
    public static float sqrtf$O(final float a) {
        try {
            return (float)java.lang.Math.sqrt(a);
        }
        catch (java.lang.Throwable exc$205614) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205614);
        }
        
    }
    
    
    
    //#line 376 "x10/lang/Math.x10"
    /**
     * Returns the principal value of the square root of <code>z</code>.
     * The branch cut is on the real line at (-inf, 0)
     * @return the principal square root of <code>z</code>
     * @see http://mathworld.wolfram.com/SquareRoot.html
     */
    public static x10.lang.Complex sqrt(final x10.lang.Complex z) {
        
        //#line 377 "x10/lang/Math.x10"
        final boolean t$133565 = z.isNaN$O();
        
        //#line 377 "x10/lang/Math.x10"
        if (t$133565) {
            
            //#line 378 "x10/lang/Math.x10"
            final x10.lang.Complex t$133543 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 378 "x10/lang/Math.x10"
            return t$133543;
        } else {
            
            //#line 379 "x10/lang/Math.x10"
            final x10.lang.Complex t$133544 = ((x10.lang.Complex)(x10.lang.Complex.get$ZERO()));
            
            //#line 379 "x10/lang/Math.x10"
            final boolean t$133564 = x10.rtt.Equality.equalsequals((z),(t$133544));
            
            //#line 379 "x10/lang/Math.x10"
            if (t$133564) {
                
                //#line 380 "x10/lang/Math.x10"
                final x10.lang.Complex t$133545 = ((x10.lang.Complex)(x10.lang.Complex.get$ZERO()));
                
                //#line 380 "x10/lang/Math.x10"
                return t$133545;
            } else {
                
                //#line 382 "x10/lang/Math.x10"
                final double t$133546 = z.re;
                
                //#line 382 "x10/lang/Math.x10"
                final double t$133547 = java.lang.Math.abs(((double)(t$133546)));
                
                //#line 382 "x10/lang/Math.x10"
                final double t$133548 = z.abs$O();
                
                //#line 382 "x10/lang/Math.x10"
                final double t$133549 = ((t$133547) + (((double)(t$133548))));
                
                //#line 382 "x10/lang/Math.x10"
                final double t$133550 = ((t$133549) / (((double)(2.0))));
                
                //#line 382 "x10/lang/Math.x10"
                final double t = java.lang.Math.sqrt(((double)(t$133550)));
                
                //#line 383 "x10/lang/Math.x10"
                final double t$133551 = z.re;
                
                //#line 383 "x10/lang/Math.x10"
                final boolean t$133563 = ((t$133551) >= (((double)(0.0))));
                
                //#line 383 "x10/lang/Math.x10"
                if (t$133563) {
                    
                    //#line 384 "x10/lang/Math.x10"
                    final double t$133552 = z.im;
                    
                    //#line 384 "x10/lang/Math.x10"
                    final double t$133553 = ((2.0) * (((double)(t))));
                    
                    //#line 384 "x10/lang/Math.x10"
                    final double t$133554 = ((t$133552) / (((double)(t$133553))));
                    
                    //#line 384 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133555 = new x10.lang.Complex(((double)(t)), t$133554);
                    
                    //#line 384 "x10/lang/Math.x10"
                    return t$133555;
                } else {
                    
                    //#line 386 "x10/lang/Math.x10"
                    final double t$133556 = z.im;
                    
                    //#line 386 "x10/lang/Math.x10"
                    final double t$133557 = java.lang.Math.abs(((double)(t$133556)));
                    
                    //#line 386 "x10/lang/Math.x10"
                    final double t$133558 = ((2.0) * (((double)(t))));
                    
                    //#line 386 "x10/lang/Math.x10"
                    final double t$133560 = ((t$133557) / (((double)(t$133558))));
                    
                    //#line 386 "x10/lang/Math.x10"
                    final double t$133559 = z.im;
                    
                    //#line 386 "x10/lang/Math.x10"
                    final double t$133561 = java.lang.Math.copySign(((double)(t)),((double)(t$133559)));
                    
                    //#line 386 "x10/lang/Math.x10"
                    final x10.lang.Complex t$133562 = new x10.lang.Complex(t$133560, t$133561);
                    
                    //#line 386 "x10/lang/Math.x10"
                    return t$133562;
                }
            }
        }
    }
    
    
    //#line 391 "x10/lang/Math.x10"
    public static double cbrt$O(final double a) {
        try {
            return java.lang.Math.cbrt(a);
        }
        catch (java.lang.Throwable exc$205615) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205615);
        }
        
    }
    
    
    
    //#line 396 "x10/lang/Math.x10"
    public static double erf$O(final double a) {
        try {
            return org.apache.commons.math3.special.Erf.erf(a);
        }
        catch (java.lang.Throwable exc$205616) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205616);
        }
        
    }
    
    
    
    //#line 401 "x10/lang/Math.x10"
    public static double erfc$O(final double a) {
        try {
            return org.apache.commons.math3.special.Erf.erfc(a);
        }
        catch (java.lang.Throwable exc$205617) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205617);
        }
        
    }
    
    
    
    //#line 406 "x10/lang/Math.x10"
    public static double hypot$O(final double a, final double b) {
        try {
            return java.lang.Math.hypot(a,b);
        }
        catch (java.lang.Throwable exc$205618) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205618);
        }
        
    }
    
    
    
    //#line 411 "x10/lang/Math.x10"
    public static double IEEEremainder$O(final double a, final double b) {
        try {
            return java.lang.Math.IEEEremainder(a,b);
        }
        catch (java.lang.Throwable exc$205619) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205619);
        }
        
    }
    
    
    
    //#line 416 "x10/lang/Math.x10"
    public static double log$O(final double a) {
        try {
            return java.lang.Math.log(a);
        }
        catch (java.lang.Throwable exc$205620) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205620);
        }
        
    }
    
    
    
    //#line 421 "x10/lang/Math.x10"
    public static float log$O(final float a) {
        try {
            return (float)java.lang.Math.log(a);
        }
        catch (java.lang.Throwable exc$205621) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205621);
        }
        
    }
    
    
    
    //#line 426 "x10/lang/Math.x10"
    public static double log$O(final int a) {
        
        //#line 426 "x10/lang/Math.x10"
        final double t$133566 = ((double)(int)(((int)(a))));
        
        //#line 426 "x10/lang/Math.x10"
        final double t$133567 = java.lang.Math.log(((double)(t$133566)));
        
        //#line 426 "x10/lang/Math.x10"
        return t$133567;
    }
    
    
    //#line 427 "x10/lang/Math.x10"
    public static double log$O(final long a) {
        
        //#line 427 "x10/lang/Math.x10"
        final double t$133568 = ((double)(long)(((long)(a))));
        
        //#line 427 "x10/lang/Math.x10"
        final double t$133569 = java.lang.Math.log(((double)(t$133568)));
        
        //#line 427 "x10/lang/Math.x10"
        return t$133569;
    }
    
    
    //#line 432 "x10/lang/Math.x10"
    /**
     * @deprecated use {@link #log(Float)} instead
     */
    public static float logf$O(final float a) {
        try {
            return (float)java.lang.Math.log(a);
        }
        catch (java.lang.Throwable exc$205622) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205622);
        }
        
    }
    
    
    
    //#line 443 "x10/lang/Math.x10"
    /**
     * Returns the principal value of the natural logarithm of <code>z</code>.
     * The branch cut is on the real line at (-inf, 0]
     * @return the natural logarithm of <code>a</code>
     * @see http://mathworld.wolfram.com/NaturalLogarithm.html
     */
    public static x10.lang.Complex log(final x10.lang.Complex a) {
        
        //#line 445 "x10/lang/Math.x10"
        final boolean t$133571 = a.isNaN$O();
        
        //#line 445 "x10/lang/Math.x10"
        if (t$133571) {
            
            //#line 446 "x10/lang/Math.x10"
            final x10.lang.Complex t$133570 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 446 "x10/lang/Math.x10"
            return t$133570;
        }
        
        //#line 448 "x10/lang/Math.x10"
        final double t$133572 = a.abs$O();
        
        //#line 448 "x10/lang/Math.x10"
        final double t$133575 = java.lang.Math.log(((double)(t$133572)));
        
        //#line 448 "x10/lang/Math.x10"
        final double t$133573 = a.im;
        
        //#line 448 "x10/lang/Math.x10"
        final double t$133574 = a.re;
        
        //#line 448 "x10/lang/Math.x10"
        final double t$133576 = java.lang.Math.atan2(((double)(t$133573)),((double)(t$133574)));
        
        //#line 448 "x10/lang/Math.x10"
        final x10.lang.Complex t$133577 = new x10.lang.Complex(t$133575, t$133576);
        
        //#line 448 "x10/lang/Math.x10"
        return t$133577;
    }
    
    
    //#line 451 "x10/lang/Math.x10"
    public static double log10$O(final double a) {
        try {
            return java.lang.Math.log10(a);
        }
        catch (java.lang.Throwable exc$205623) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205623);
        }
        
    }
    
    
    
    //#line 456 "x10/lang/Math.x10"
    public static double log1p$O(final double a) {
        try {
            return java.lang.Math.log1p(a);
        }
        catch (java.lang.Throwable exc$205624) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205624);
        }
        
    }
    
    
    
    //#line 461 "x10/lang/Math.x10"
    public static int max$O(final int a, final int b) {
        try {
            return java.lang.Math.max(a,b);
        }
        catch (java.lang.Throwable exc$205625) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205625);
        }
        
    }
    
    
    
    //#line 465 "x10/lang/Math.x10"
    public static int min$O(final int a, final int b) {
        try {
            return java.lang.Math.min(a,b);
        }
        catch (java.lang.Throwable exc$205626) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205626);
        }
        
    }
    
    
    
    //#line 469 "x10/lang/Math.x10"
    public static int max__0$u__1$u$O(final int a, final int b) {
        
        //#line 470 "x10/lang/Math.x10"
        final boolean t$133584 = x10.runtime.impl.java.UIntUtils.lt(a, ((int)(b)));
        
        //#line 470 "x10/lang/Math.x10"
        int t$133585 =  0;
        
        //#line 470 "x10/lang/Math.x10"
        if (t$133584) {
            
            //#line 470 "x10/lang/Math.x10"
            t$133585 = b;
        } else {
            
            //#line 470 "x10/lang/Math.x10"
            t$133585 = a;
        }
        
        //#line 470 "x10/lang/Math.x10"
        return t$133585;
    }
    
    
    //#line 472 "x10/lang/Math.x10"
    public static int min__0$u__1$u$O(final int a, final int b) {
        
        //#line 473 "x10/lang/Math.x10"
        final boolean t$133587 = x10.runtime.impl.java.UIntUtils.lt(a, ((int)(b)));
        
        //#line 473 "x10/lang/Math.x10"
        int t$133588 =  0;
        
        //#line 473 "x10/lang/Math.x10"
        if (t$133587) {
            
            //#line 473 "x10/lang/Math.x10"
            t$133588 = a;
        } else {
            
            //#line 473 "x10/lang/Math.x10"
            t$133588 = b;
        }
        
        //#line 473 "x10/lang/Math.x10"
        return t$133588;
    }
    
    
    //#line 475 "x10/lang/Math.x10"
    public static long max$O(final long a, final long b) {
        try {
            return java.lang.Math.max(a,b);
        }
        catch (java.lang.Throwable exc$205627) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205627);
        }
        
    }
    
    
    
    //#line 479 "x10/lang/Math.x10"
    public static long min$O(final long a, final long b) {
        try {
            return java.lang.Math.min(a,b);
        }
        catch (java.lang.Throwable exc$205628) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205628);
        }
        
    }
    
    
    
    //#line 483 "x10/lang/Math.x10"
    public static long max__0$u__1$u$O(final long a, final long b) {
        
        //#line 484 "x10/lang/Math.x10"
        final boolean t$133596 = x10.runtime.impl.java.ULongUtils.lt(a, ((long)(b)));
        
        //#line 484 "x10/lang/Math.x10"
        long t$133597 =  0;
        
        //#line 484 "x10/lang/Math.x10"
        if (t$133596) {
            
            //#line 484 "x10/lang/Math.x10"
            t$133597 = b;
        } else {
            
            //#line 484 "x10/lang/Math.x10"
            t$133597 = a;
        }
        
        //#line 484 "x10/lang/Math.x10"
        return t$133597;
    }
    
    
    //#line 486 "x10/lang/Math.x10"
    public static long min__0$u__1$u$O(final long a, final long b) {
        
        //#line 487 "x10/lang/Math.x10"
        final boolean t$133599 = x10.runtime.impl.java.ULongUtils.lt(a, ((long)(b)));
        
        //#line 487 "x10/lang/Math.x10"
        long t$133600 =  0;
        
        //#line 487 "x10/lang/Math.x10"
        if (t$133599) {
            
            //#line 487 "x10/lang/Math.x10"
            t$133600 = a;
        } else {
            
            //#line 487 "x10/lang/Math.x10"
            t$133600 = b;
        }
        
        //#line 487 "x10/lang/Math.x10"
        return t$133600;
    }
    
    
    //#line 489 "x10/lang/Math.x10"
    public static float max$O(final float a, final float b) {
        try {
            return java.lang.Math.max(a,b);
        }
        catch (java.lang.Throwable exc$205629) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205629);
        }
        
    }
    
    
    
    //#line 494 "x10/lang/Math.x10"
    public static float min$O(final float a, final float b) {
        try {
            return java.lang.Math.min(a,b);
        }
        catch (java.lang.Throwable exc$205630) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205630);
        }
        
    }
    
    
    
    //#line 499 "x10/lang/Math.x10"
    public static double max$O(final double a, final double b) {
        try {
            return java.lang.Math.max(a,b);
        }
        catch (java.lang.Throwable exc$205631) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205631);
        }
        
    }
    
    
    
    //#line 504 "x10/lang/Math.x10"
    public static double min$O(final double a, final double b) {
        try {
            return java.lang.Math.min(a,b);
        }
        catch (java.lang.Throwable exc$205632) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205632);
        }
        
    }
    
    
    
    //#line 509 "x10/lang/Math.x10"
    public static int signum$O(final int a) {
        
        //#line 509 "x10/lang/Math.x10"
        final boolean t$133604 = ((int) a) == ((int) 0);
        
        //#line 509 "x10/lang/Math.x10"
        int t$133605 =  0;
        
        //#line 509 "x10/lang/Math.x10"
        if (t$133604) {
            
            //#line 509 "x10/lang/Math.x10"
            t$133605 = 0;
        } else {
            
            //#line 509 "x10/lang/Math.x10"
            final boolean t$133602 = ((a) > (((int)(0))));
            
            //#line 509 "x10/lang/Math.x10"
            int t$133603 =  0;
            
            //#line 509 "x10/lang/Math.x10"
            if (t$133602) {
                
                //#line 509 "x10/lang/Math.x10"
                t$133603 = 1;
            } else {
                
                //#line 509 "x10/lang/Math.x10"
                t$133603 = -1;
            }
            
            //#line 509 "x10/lang/Math.x10"
            t$133605 = t$133603;
        }
        
        //#line 509 "x10/lang/Math.x10"
        return t$133605;
    }
    
    
    //#line 510 "x10/lang/Math.x10"
    public static long signum$O(final long a) {
        
        //#line 510 "x10/lang/Math.x10"
        final boolean t$133609 = ((long) a) == ((long) 0L);
        
        //#line 510 "x10/lang/Math.x10"
        long t$133610 =  0;
        
        //#line 510 "x10/lang/Math.x10"
        if (t$133609) {
            
            //#line 510 "x10/lang/Math.x10"
            t$133610 = 0L;
        } else {
            
            //#line 510 "x10/lang/Math.x10"
            final boolean t$133607 = ((a) > (((long)(0L))));
            
            //#line 510 "x10/lang/Math.x10"
            long t$133608 =  0;
            
            //#line 510 "x10/lang/Math.x10"
            if (t$133607) {
                
                //#line 510 "x10/lang/Math.x10"
                t$133608 = 1L;
            } else {
                
                //#line 510 "x10/lang/Math.x10"
                t$133608 = -1L;
            }
            
            //#line 510 "x10/lang/Math.x10"
            t$133610 = t$133608;
        }
        
        //#line 510 "x10/lang/Math.x10"
        return t$133610;
    }
    
    
    //#line 512 "x10/lang/Math.x10"
    public static float signum$O(final float a) {
        try {
            return java.lang.Math.signum(a);
        }
        catch (java.lang.Throwable exc$205633) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205633);
        }
        
    }
    
    
    
    //#line 515 "x10/lang/Math.x10"
    public static double signum$O(final double a) {
        try {
            return java.lang.Math.signum(a);
        }
        catch (java.lang.Throwable exc$205634) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205634);
        }
        
    }
    
    
    
    //#line 521 "x10/lang/Math.x10"
    /**
     * @return the value of a with the sign of b
     */
    public static double copySign$O(final double a, final double b) {
        try {
            return java.lang.Math.copySign(a,b);
        }
        catch (java.lang.Throwable exc$205635) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205635);
        }
        
    }
    
    
    
    //#line 529 "x10/lang/Math.x10"
    /**
     * @return the value of a with the sign of b
     */
    public static float copySign$O(final float a, final float b) {
        try {
            return java.lang.Math.copySign(a,b);
        }
        catch (java.lang.Throwable exc$205636) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205636);
        }
        
    }
    
    
    
    //#line 534 "x10/lang/Math.x10"
    public static double nextAfter$O(final double a, final double b) {
        try {
            return java.lang.Math.nextAfter(a,b);
        }
        catch (java.lang.Throwable exc$205637) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205637);
        }
        
    }
    
    
    
    //#line 539 "x10/lang/Math.x10"
    public static float nextAfter$O(final float a, final float b) {
        try {
            return java.lang.Math.nextAfter(a,b);
        }
        catch (java.lang.Throwable exc$205638) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205638);
        }
        
    }
    
    
    
    //#line 544 "x10/lang/Math.x10"
    public static int nextPowerOf2$O(final int p) {
        
        //#line 545 "x10/lang/Math.x10"
        final boolean t$133622 = ((int) p) == ((int) 0);
        
        //#line 545 "x10/lang/Math.x10"
        if (t$133622) {
            
            //#line 545 "x10/lang/Math.x10"
            return 0;
        }
        
        //#line 546 "x10/lang/Math.x10"
        int pow2 = 1;
        
        //#line 547 "x10/lang/Math.x10"
        while (true) {
            
            //#line 547 "x10/lang/Math.x10"
            final boolean t$133627 = ((pow2) < (((int)(p))));
            
            //#line 547 "x10/lang/Math.x10"
            if (!(t$133627)) {
                
                //#line 547 "x10/lang/Math.x10"
                break;
            }
            
            //#line 548 "x10/lang/Math.x10"
            final long t$133662 = ((long)(((int)(1))));
            
            //#line 548 "x10/lang/Math.x10"
            final int t$133663 = ((pow2) << (int)(((long)(t$133662))));
            
            //#line 548 "x10/lang/Math.x10"
            pow2 = t$133663;
        }
        
        //#line 549 "x10/lang/Math.x10"
        return pow2;
    }
    
    
    //#line 552 "x10/lang/Math.x10"
    public static long nextPowerOf2$O(final long p) {
        
        //#line 553 "x10/lang/Math.x10"
        final boolean t$133629 = ((long) p) == ((long) 0L);
        
        //#line 553 "x10/lang/Math.x10"
        if (t$133629) {
            
            //#line 553 "x10/lang/Math.x10"
            return 0L;
        }
        
        //#line 554 "x10/lang/Math.x10"
        long pow2 = 1L;
        
        //#line 555 "x10/lang/Math.x10"
        while (true) {
            
            //#line 555 "x10/lang/Math.x10"
            final boolean t$133634 = ((pow2) < (((long)(p))));
            
            //#line 555 "x10/lang/Math.x10"
            if (!(t$133634)) {
                
                //#line 555 "x10/lang/Math.x10"
                break;
            }
            
            //#line 556 "x10/lang/Math.x10"
            final long t$133665 = ((long)(((int)(1))));
            
            //#line 556 "x10/lang/Math.x10"
            final long t$133666 = ((pow2) << (int)(((long)(t$133665))));
            
            //#line 556 "x10/lang/Math.x10"
            pow2 = t$133666;
        }
        
        //#line 557 "x10/lang/Math.x10"
        return pow2;
    }
    
    
    //#line 560 "x10/lang/Math.x10"
    public static boolean powerOf2$O(final int p) {
        
        //#line 560 "x10/lang/Math.x10"
        final int t$133636 = (-(p));
        
        //#line 560 "x10/lang/Math.x10"
        final int t$133637 = ((p) & (((int)(t$133636))));
        
        //#line 560 "x10/lang/Math.x10"
        final boolean t$133638 = ((int) t$133637) == ((int) p);
        
        //#line 560 "x10/lang/Math.x10"
        return t$133638;
    }
    
    
    //#line 561 "x10/lang/Math.x10"
    public static boolean powerOf2$O(final long p) {
        
        //#line 561 "x10/lang/Math.x10"
        final long t$133639 = (-(p));
        
        //#line 561 "x10/lang/Math.x10"
        final long t$133640 = ((p) & (((long)(t$133639))));
        
        //#line 561 "x10/lang/Math.x10"
        final boolean t$133641 = ((long) t$133640) == ((long) p);
        
        //#line 561 "x10/lang/Math.x10"
        return t$133641;
    }
    
    
    //#line 563 "x10/lang/Math.x10"
    public static int log2$O(int p) {
        
        //#line 564 "x10/lang/Math.x10"
        assert x10.lang.Math.powerOf2$O((int)(p));
        
        //#line 565 "x10/lang/Math.x10"
        int i = 0;
        
        //#line 566 "x10/lang/Math.x10"
        while (true) {
            
            //#line 566 "x10/lang/Math.x10"
            final boolean t$133647 = ((p) > (((int)(1))));
            
            //#line 566 "x10/lang/Math.x10"
            if (!(t$133647)) {
                
                //#line 566 "x10/lang/Math.x10"
                break;
            }
            
            //#line 566 "x10/lang/Math.x10"
            final int t$133668 = ((p) / (((int)(2))));
            
            //#line 566 "x10/lang/Math.x10"
            p = t$133668;
            
            //#line 566 "x10/lang/Math.x10"
            final int t$133670 = ((i) + (((int)(1))));
            
            //#line 566 "x10/lang/Math.x10"
            i = t$133670;
        }
        
        //#line 567 "x10/lang/Math.x10"
        return i;
    }
    
    
    //#line 570 "x10/lang/Math.x10"
    public static long log2$O(long p) {
        
        //#line 571 "x10/lang/Math.x10"
        assert x10.lang.Math.powerOf2$O((long)(p));
        
        //#line 572 "x10/lang/Math.x10"
        long i = 0L;
        
        //#line 573 "x10/lang/Math.x10"
        while (true) {
            
            //#line 573 "x10/lang/Math.x10"
            final boolean t$133654 = ((p) > (((long)(1L))));
            
            //#line 573 "x10/lang/Math.x10"
            if (!(t$133654)) {
                
                //#line 573 "x10/lang/Math.x10"
                break;
            }
            
            //#line 573 "x10/lang/Math.x10"
            final long t$133672 = ((p) / (((long)(2L))));
            
            //#line 573 "x10/lang/Math.x10"
            p = t$133672;
            
            //#line 573 "x10/lang/Math.x10"
            final long t$133674 = ((i) + (((long)(1L))));
            
            //#line 573 "x10/lang/Math.x10"
            i = t$133674;
        }
        
        //#line 574 "x10/lang/Math.x10"
        return i;
    }
    
    
    //#line 578 "x10/lang/Math.x10"
    public static int pow2$O(final int i) {
        
        //#line 579 "x10/lang/Math.x10"
        final long t$133656 = ((long)(((int)(i))));
        
        //#line 579 "x10/lang/Math.x10"
        final int t$133657 = ((1) << (int)(((long)(t$133656))));
        
        //#line 579 "x10/lang/Math.x10"
        return t$133657;
    }
    
    
    //#line 583 "x10/lang/Math.x10"
    public static long pow2$O(final long i) {
        
        //#line 584 "x10/lang/Math.x10"
        final int t$133658 = ((int)(long)(((long)(i))));
        
        //#line 584 "x10/lang/Math.x10"
        final long t$133659 = ((long)(((int)(t$133658))));
        
        //#line 584 "x10/lang/Math.x10"
        final long t$133660 = ((1L) << (int)(((long)(t$133659))));
        
        //#line 584 "x10/lang/Math.x10"
        return t$133660;
    }
    
    
    //#line 18 "x10/lang/Math.x10"
    final public x10.lang.Math x10$lang$Math$$this$x10$lang$Math() {
        
        //#line 18 "x10/lang/Math.x10"
        return x10.lang.Math.this;
    }
    
    
    //#line 19 "x10/lang/Math.x10"
    // creation method for java code (1-phase java constructor)
    public Math() {
        this((java.lang.System[]) null);
        x10$lang$Math$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.lang.Math x10$lang$Math$$init$S() {
         {
            
            //#line 19 "x10/lang/Math.x10"
            
        }
        return this;
    }
    
    
    
    //#line 18 "x10/lang/Math.x10"
    final public void __fieldInitializers_x10_lang_Math() {
        
    }
    
    public static double get$E() {
        return x10.lang.Math.E;
    }
    
    public static double get$PI() {
        return x10.lang.Math.PI;
    }
}

