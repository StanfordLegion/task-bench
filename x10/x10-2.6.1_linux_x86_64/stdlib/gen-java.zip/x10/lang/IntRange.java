package x10.lang;


/**
 * A representation of the range of integers [min..max].
 */
@x10.runtime.impl.java.X10Generated
public class IntRange extends x10.core.Struct implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<IntRange> $RTT = 
        x10.rtt.NamedStructType.<IntRange> make("x10.lang.IntRange",
                                                IntRange.class,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.rtt.Types.INT),
                                                    x10.rtt.Types.STRUCT
                                                });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.IntRange $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.max = $deserializer.readInt();
        $_obj.min = $deserializer.readInt();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.IntRange $_obj = new x10.lang.IntRange((java.lang.System[]) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.max);
        $serializer.write(this.min);
        
    }
    
    // zero value constructor
    public IntRange(final java.lang.System $dummy) { this.min = 0; this.max = 0; }
    
    // constructor just for allocation
    public IntRange(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 23 "x10/lang/IntRange.x10"
    /**
                * The minimum value included in the range
                */
    public int min;
    
    //#line 28 "x10/lang/IntRange.x10"
    /**
                * The maximum value included in the range
                */
    public int max;
    

    
    
    //#line 36 "x10/lang/IntRange.x10"
    /**
     * Construct a IntRange from min..max
     * @param min the minimum value of the range
     * @param max the maximum value of the range
     */
    // creation method for java code (1-phase java constructor)
    public IntRange(final int min, final int max) {
        this((java.lang.System[]) null);
        x10$lang$IntRange$$init$S(min, max);
    }
    
    // constructor for non-virtual call
    final public x10.lang.IntRange x10$lang$IntRange$$init$S(final int min, final int max) {
         {
            
            //#line 37 "x10/lang/IntRange.x10"
            this.min = min;
            this.max = max;
            
        }
        return this;
    }
    
    
    
    //#line 45 "x10/lang/IntRange.x10"
    /**
     * Convert a given LongRange to an IntRange.
     * @param x the given LongRange
     * @return the given LongRange converted to an IntRange.
     */
    final public static x10.lang.IntRange $convert(final x10.lang.LongRange x) {
        
        //#line 45 "x10/lang/IntRange.x10"
        final x10.lang.IntRange alloc$133033 = ((x10.lang.IntRange)(new x10.lang.IntRange((java.lang.System[]) null)));
        
        //#line 45 "x10/lang/IntRange.x10"
        final long t$133053 = x.min;
        
        //#line 45 "x10/lang/IntRange.x10"
        final int min$133039 = ((int)(long)(((long)(t$133053))));
        
        //#line 45 "x10/lang/IntRange.x10"
        final long t$133054 = x.max;
        
        //#line 45 "x10/lang/IntRange.x10"
        final int max$133040 = ((int)(long)(((long)(t$133054))));
        
        //#line 37 . "x10/lang/IntRange.x10"
        alloc$133033.min = min$133039;
        
        //#line 37 . "x10/lang/IntRange.x10"
        alloc$133033.max = max$133040;
        
        //#line 45 "x10/lang/IntRange.x10"
        return alloc$133033;
    }
    
    
    //#line 52 "x10/lang/IntRange.x10"
    /**
     * Split the IntRange into N IntRanges that
     * collectively represent the same set of Ints as this.
     * @see x10.array.BlockUtils.partitionBlock
     */
    final public x10.core.Rail split(final int n) {
        
        //#line 53 "x10/lang/IntRange.x10"
        final int t$133055 = this.max;
        
        //#line 53 "x10/lang/IntRange.x10"
        final int t$133056 = this.min;
        
        //#line 53 "x10/lang/IntRange.x10"
        final int t$133057 = ((t$133055) - (((int)(t$133056))));
        
        //#line 53 "x10/lang/IntRange.x10"
        final int numElems = ((t$133057) + (((int)(1))));
        
        //#line 54 "x10/lang/IntRange.x10"
        final int blockSize = ((numElems) / (((int)(n))));
        
        //#line 55 "x10/lang/IntRange.x10"
        final int t$133058 = ((n) * (((int)(blockSize))));
        
        //#line 55 "x10/lang/IntRange.x10"
        final int leftOver = ((numElems) - (((int)(t$133058))));
        
        //#line 56 "x10/lang/IntRange.x10"
        final long t$133069 = ((long)(((int)(n))));
        
        //#line 56 "x10/lang/IntRange.x10"
        final x10.core.fun.Fun_0_1 t$133070 = ((x10.core.fun.Fun_0_1)(new x10.lang.IntRange.$Closure$121(this, this.min, blockSize, leftOver)));
        
        //#line 56 "x10/lang/IntRange.x10"
        final x10.core.Rail t$133071 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.IntRange>(x10.lang.IntRange.$RTT, t$133069, ((x10.core.fun.Fun_0_1)(t$133070)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 56 "x10/lang/IntRange.x10"
        return t$133071;
    }
    
    
    //#line 68 "x10/lang/IntRange.x10"
    /**
     * Define the product of two IntRanges to be a rank-2 IterationSpace
     * containing all the points defined by the cartesian product of the ranges.
     */
    final public x10.array.DenseIterationSpace_2 $times(final x10.lang.IntRange that) {
        
        //#line 69 "x10/lang/IntRange.x10"
        final x10.array.DenseIterationSpace_2 alloc$133035 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 69 "x10/lang/IntRange.x10"
        final int t$133116 = this.min;
        
        //#line 69 "x10/lang/IntRange.x10"
        final long t$133117 = ((long)(((int)(t$133116))));
        
        //#line 69 "x10/lang/IntRange.x10"
        final int t$133118 = that.min;
        
        //#line 69 "x10/lang/IntRange.x10"
        final long t$133119 = ((long)(((int)(t$133118))));
        
        //#line 69 "x10/lang/IntRange.x10"
        final int t$133120 = this.max;
        
        //#line 69 "x10/lang/IntRange.x10"
        final long t$133121 = ((long)(((int)(t$133120))));
        
        //#line 69 "x10/lang/IntRange.x10"
        final int t$133122 = that.max;
        
        //#line 69 "x10/lang/IntRange.x10"
        final long t$133123 = ((long)(((int)(t$133122))));
        
        //#line 69 "x10/lang/IntRange.x10"
        alloc$133035.x10$array$DenseIterationSpace_2$$init$S(t$133117, t$133119, t$133121, t$133123);
        
        //#line 69 "x10/lang/IntRange.x10"
        return alloc$133035;
    }
    
    
    //#line 72 "x10/lang/IntRange.x10"
    final public java.lang.String toString() {
        
        //#line 72 "x10/lang/IntRange.x10"
        final int t$133080 = this.min;
        
        //#line 72 "x10/lang/IntRange.x10"
        final java.lang.String t$133081 = (((x10.core.Int.$box(t$133080))) + (".."));
        
        //#line 72 "x10/lang/IntRange.x10"
        final int t$133082 = this.max;
        
        //#line 72 "x10/lang/IntRange.x10"
        final java.lang.String t$133083 = ((t$133081) + ((x10.core.Int.$box(t$133082))));
        
        //#line 72 "x10/lang/IntRange.x10"
        return t$133083;
    }
    
    
    //#line 74 "x10/lang/IntRange.x10"
    final public boolean equals(final java.lang.Object that) {
        
        //#line 75 "x10/lang/IntRange.x10"
        final boolean t$133090 = x10.lang.IntRange.$RTT.isInstance(that);
        
        //#line 75 "x10/lang/IntRange.x10"
        if (t$133090) {
            
            //#line 76 "x10/lang/IntRange.x10"
            final x10.lang.IntRange other = ((x10.lang.IntRange)(((x10.lang.IntRange)x10.rtt.Types.asStruct(x10.lang.IntRange.$RTT,that))));
            
            //#line 77 "x10/lang/IntRange.x10"
            final int t$133084 = this.min;
            
            //#line 77 "x10/lang/IntRange.x10"
            final int t$133085 = other.min;
            
            //#line 77 "x10/lang/IntRange.x10"
            boolean t$133088 = ((int) t$133084) == ((int) t$133085);
            
            //#line 77 "x10/lang/IntRange.x10"
            if (t$133088) {
                
                //#line 77 "x10/lang/IntRange.x10"
                final int t$133086 = this.max;
                
                //#line 77 "x10/lang/IntRange.x10"
                final int t$133087 = other.max;
                
                //#line 77 "x10/lang/IntRange.x10"
                t$133088 = ((int) t$133086) == ((int) t$133087);
            }
            
            //#line 77 "x10/lang/IntRange.x10"
            return t$133088;
        }
        
        //#line 79 "x10/lang/IntRange.x10"
        return false;
    }
    
    
    //#line 82 "x10/lang/IntRange.x10"
    final public int hashCode() {
        
        //#line 82 "x10/lang/IntRange.x10"
        final int t$133091 = this.max;
        
        //#line 82 "x10/lang/IntRange.x10"
        final int t$133092 = this.min;
        
        //#line 82 "x10/lang/IntRange.x10"
        final int t$133093 = ((t$133091) - (((int)(t$133092))));
        
        //#line 82 "x10/lang/IntRange.x10"
        final int t$133094 = x10.rtt.Types.hashCode(t$133093);
        
        //#line 82 "x10/lang/IntRange.x10"
        return t$133094;
    }
    
    
    //#line 84 "x10/lang/IntRange.x10"
    final public x10.lang.Iterator iterator() {
        
        //#line 85 "x10/lang/IntRange.x10"
        final x10.lang.IntRange.IntRangeIt alloc$133036 = ((x10.lang.IntRange.IntRangeIt)(new x10.lang.IntRange.IntRangeIt((java.lang.System[]) null)));
        
        //#line 85 "x10/lang/IntRange.x10"
        final int min$133047 = this.min;
        
        //#line 85 "x10/lang/IntRange.x10"
        final int max$133048 = this.max;
        
        //#line 88 .. "x10/lang/IntRange.x10"
        alloc$133036.cur = 0;
        
        //#line 92 . "x10/lang/IntRange.x10"
        alloc$133036.cur = min$133047;
        
        //#line 93 . "x10/lang/IntRange.x10"
        alloc$133036.max = max$133048;
        
        //#line 85 "x10/lang/IntRange.x10"
        return alloc$133036;
    }
    
    
    //#line 88 "x10/lang/IntRange.x10"
    @x10.runtime.impl.java.X10Generated
    public static class IntRangeIt extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<IntRangeIt> $RTT = 
            x10.rtt.NamedType.<IntRangeIt> make("x10.lang.IntRange.IntRangeIt",
                                                IntRangeIt.class,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.rtt.Types.INT)
                                                });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.IntRange.IntRangeIt $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur = $deserializer.readInt();
            $_obj.max = $deserializer.readInt();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.IntRange.IntRangeIt $_obj = new x10.lang.IntRange.IntRangeIt((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur);
            $serializer.write(this.max);
            
        }
        
        // constructor just for allocation
        public IntRangeIt(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.core.Int next$G() {
            return x10.core.Int.$box(next$O());
        }
        
        
    
        
        //#line 89 "x10/lang/IntRange.x10"
        public int cur;
        
        //#line 90 "x10/lang/IntRange.x10"
        public int max;
        
        
        //#line 91 "x10/lang/IntRange.x10"
        // creation method for java code (1-phase java constructor)
        public IntRangeIt(final int min, final int max) {
            this((java.lang.System[]) null);
            x10$lang$IntRange$IntRangeIt$$init$S(min, max);
        }
        
        // constructor for non-virtual call
        final public x10.lang.IntRange.IntRangeIt x10$lang$IntRange$IntRangeIt$$init$S(final int min, final int max) {
             {
                
                //#line 91 "x10/lang/IntRange.x10"
                
                
                //#line 88 "x10/lang/IntRange.x10"
                final x10.lang.IntRange.IntRangeIt this$133124 = this;
                
                //#line 88 "x10/lang/IntRange.x10"
                this$133124.cur = 0;
                
                //#line 92 "x10/lang/IntRange.x10"
                this.cur = min;
                
                //#line 93 "x10/lang/IntRange.x10"
                this.max = max;
            }
            return this;
        }
        
        
        
        //#line 95 "x10/lang/IntRange.x10"
        public boolean hasNext$O() {
            
            //#line 95 "x10/lang/IntRange.x10"
            final int t$133095 = this.cur;
            
            //#line 95 "x10/lang/IntRange.x10"
            final int t$133096 = this.max;
            
            //#line 95 "x10/lang/IntRange.x10"
            final boolean t$133097 = ((t$133095) <= (((int)(t$133096))));
            
            //#line 95 "x10/lang/IntRange.x10"
            return t$133097;
        }
        
        
        //#line 96 "x10/lang/IntRange.x10"
        public int next$O() {
            
            //#line 96 "x10/lang/IntRange.x10"
            final int t$133098 = this.cur;
            
            //#line 96 "x10/lang/IntRange.x10"
            final int t$133099 = ((t$133098) + (((int)(1))));
            
            //#line 96 "x10/lang/IntRange.x10"
            final int t$133100 = this.cur = t$133099;
            
            //#line 96 "x10/lang/IntRange.x10"
            final int t$133101 = ((t$133100) - (((int)(1))));
            
            //#line 96 "x10/lang/IntRange.x10"
            return t$133101;
        }
        
        
        //#line 88 "x10/lang/IntRange.x10"
        final public x10.lang.IntRange.IntRangeIt x10$lang$IntRange$IntRangeIt$$this$x10$lang$IntRange$IntRangeIt() {
            
            //#line 88 "x10/lang/IntRange.x10"
            return x10.lang.IntRange.IntRangeIt.this;
        }
        
        
        //#line 88 "x10/lang/IntRange.x10"
        final public void __fieldInitializers_x10_lang_IntRange_IntRangeIt() {
            
            //#line 88 "x10/lang/IntRange.x10"
            this.cur = 0;
        }
    }
    
    
    
    //#line 29 "x10/lang/IntRange.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$205580) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205580);
        }
        
    }
    
    
    
    //#line 29 "x10/lang/IntRange.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 29 "x10/lang/IntRange.x10"
        final boolean t$133103 = x10.lang.IntRange.$RTT.isInstance(other);
        
        //#line 29 "x10/lang/IntRange.x10"
        final boolean t$133104 = !(t$133103);
        
        //#line 29 "x10/lang/IntRange.x10"
        if (t$133104) {
            
            //#line 29 "x10/lang/IntRange.x10"
            return false;
        }
        
        //#line 29 "x10/lang/IntRange.x10"
        final x10.lang.IntRange t$133106 = ((x10.lang.IntRange)x10.rtt.Types.asStruct(x10.lang.IntRange.$RTT,other));
        
        //#line 29 "x10/lang/IntRange.x10"
        final boolean t$133107 = this._struct_equals$O(((x10.lang.IntRange)(t$133106)));
        
        //#line 29 "x10/lang/IntRange.x10"
        return t$133107;
    }
    
    
    //#line 29 "x10/lang/IntRange.x10"
    final public boolean _struct_equals$O(x10.lang.IntRange other) {
        
        //#line 29 "x10/lang/IntRange.x10"
        final int t$133109 = this.min;
        
        //#line 29 "x10/lang/IntRange.x10"
        final int t$133110 = other.min;
        
        //#line 29 "x10/lang/IntRange.x10"
        boolean t$133114 = ((int) t$133109) == ((int) t$133110);
        
        //#line 29 "x10/lang/IntRange.x10"
        if (t$133114) {
            
            //#line 29 "x10/lang/IntRange.x10"
            final int t$133112 = this.max;
            
            //#line 29 "x10/lang/IntRange.x10"
            final int t$133113 = other.max;
            
            //#line 29 "x10/lang/IntRange.x10"
            t$133114 = ((int) t$133112) == ((int) t$133113);
        }
        
        //#line 29 "x10/lang/IntRange.x10"
        return t$133114;
    }
    
    
    //#line 19 "x10/lang/IntRange.x10"
    final public x10.lang.IntRange x10$lang$IntRange$$this$x10$lang$IntRange() {
        
        //#line 19 "x10/lang/IntRange.x10"
        return x10.lang.IntRange.this;
    }
    
    
    //#line 19 "x10/lang/IntRange.x10"
    final public void __fieldInitializers_x10_lang_IntRange() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$121 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$121> $RTT = 
            x10.rtt.StaticFunType.<$Closure$121> make($Closure$121.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.lang.IntRange.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.IntRange.$Closure$121 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.blockSize = $deserializer.readInt();
            $_obj.leftOver = $deserializer.readInt();
            $_obj.min = $deserializer.readInt();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.IntRange.$Closure$121 $_obj = new x10.lang.IntRange.$Closure$121((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.blockSize);
            $serializer.write(this.leftOver);
            $serializer.write(this.min);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$121(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.lang.IntRange $apply(final long iLong) {
            
            //#line 57 "x10/lang/IntRange.x10"
            final int i = ((int)(long)(((long)(iLong))));
            
            //#line 58 "x10/lang/IntRange.x10"
            final int t$133059 = this.min;
            
            //#line 58 "x10/lang/IntRange.x10"
            final int t$133060 = ((this.blockSize) * (((int)(i))));
            
            //#line 58 "x10/lang/IntRange.x10"
            final int t$133063 = ((t$133059) + (((int)(t$133060))));
            
            //#line 58 "x10/lang/IntRange.x10"
            final boolean t$133061 = ((i) < (((int)(this.leftOver))));
            
            //#line 58 "x10/lang/IntRange.x10"
            int t$133062 =  0;
            
            //#line 58 "x10/lang/IntRange.x10"
            if (t$133061) {
                
                //#line 58 "x10/lang/IntRange.x10"
                t$133062 = i;
            } else {
                
                //#line 58 "x10/lang/IntRange.x10"
                t$133062 = this.leftOver;
            }
            
            //#line 58 "x10/lang/IntRange.x10"
            final int low = ((t$133063) + (((int)(t$133062))));
            
            //#line 59 "x10/lang/IntRange.x10"
            final int t$133067 = ((low) + (((int)(this.blockSize))));
            
            //#line 59 "x10/lang/IntRange.x10"
            final boolean t$133065 = ((i) < (((int)(this.leftOver))));
            
            //#line 59 "x10/lang/IntRange.x10"
            int t$133066 =  0;
            
            //#line 59 "x10/lang/IntRange.x10"
            if (t$133065) {
                
                //#line 59 "x10/lang/IntRange.x10"
                t$133066 = 0;
            } else {
                
                //#line 59 "x10/lang/IntRange.x10"
                t$133066 = -1;
            }
            
            //#line 59 "x10/lang/IntRange.x10"
            final int hi = ((t$133067) + (((int)(t$133066))));
            
            //#line 60 "x10/lang/IntRange.x10"
            final x10.lang.IntRange alloc$133034 = ((x10.lang.IntRange)(new x10.lang.IntRange((java.lang.System[]) null)));
            
            //#line 37 . "x10/lang/IntRange.x10"
            alloc$133034.min = low;
            
            //#line 37 . "x10/lang/IntRange.x10"
            alloc$133034.max = hi;
            
            //#line 60 "x10/lang/IntRange.x10"
            return alloc$133034;
        }
        
        public x10.lang.IntRange out$$;
        public int min;
        public int blockSize;
        public int leftOver;
        
        public $Closure$121(final x10.lang.IntRange out$$, final int min, final int blockSize, final int leftOver) {
             {
                this.out$$ = out$$;
                this.min = min;
                this.blockSize = blockSize;
                this.leftOver = leftOver;
            }
        }
        
    }
    
}

