package x10.lang;


/**
 * Char is a data type representing a Unicode character.  It is not
 * an integral data type.  The "arithmetic" operations defined on
 * Char are in fact character manipulation operations.  There are
 * also static methods that define conversions from other data types,
 * including String, as well as some Char constants.
 */
;


