package x10.lang;


/**
 * <p> The Rail class provides a basic abstraction of fixed-sized 
 * indexed storage, ie a dense zero-indexed array. 
 * A <code>Rail<T></code> contains <code>size</code> elements 
 * of type <code>T</code>.</p>
 * 
 * <p> Rails are intended both for direct use in programs,
 * where basic C or Java style one dimensional arrays are needed
 * and as fundamental building block from which more complex data
 * structures can be constructed.</p>
 * 
 * <p> Although the API of the Rail class is specified at the X10 level,
 * the implementation is provided via a combination of native classes defined
 * in the Managed X10 and Native X10 runtime libraries and by direct compiler
 * support for Rail literals and compiler intrinsic implementation of a subset
 * of the Rail API methods.</p>
 * 
 * <p> Although Rails are long-indexed, Managed X10 implements the Rail class 
 * using Java's arrays as a backing storage.  Therefore rails larger than 2^31
 * may not be created on Managed X10.</p>
 *
 * <p> The class x10.util.RailUtils provides static methods with additional
 * useful Rail functions such as sorting, binary search, map, and reduce.</p>
 *
 * @see x10.util.RailUtils
 */
;

