package x10.lang;


/**
 * Complex is a struct representing a complex number (a + b*i).
 * The real and imaginary components are represented as Doubles.
 */
@x10.runtime.impl.java.X10Generated
public class Complex extends x10.core.Struct implements x10.lang.Arithmetic, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Complex> $RTT = 
        x10.rtt.NamedStructType.<Complex> make("x10.lang.Complex",
                                               Complex.class,
                                               new x10.rtt.Type[] {
                                                   x10.rtt.ParameterizedType.make(x10.lang.Arithmetic.$RTT, x10.rtt.UnresolvedType.THIS),
                                                   x10.rtt.Types.STRUCT
                                               });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Complex $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.im = $deserializer.readDouble();
        $_obj.re = $deserializer.readDouble();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.Complex $_obj = new x10.lang.Complex((java.lang.System[]) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.im);
        $serializer.write(this.re);
        
    }
    
    // zero value constructor
    public Complex(final java.lang.System $dummy) { this.re = 0.0; this.im = 0.0; }
    
    // constructor just for allocation
    public Complex(final java.lang.System[] $dummy) {
        
    }
    
    // dispatcher for method abstract public x10.lang.Arithmetic[T].operator+(that:T){}:T
    public java.lang.Object $plus(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $plus((x10.lang.Complex)a1);
        
    }
    
    // dispatcher for method abstract public x10.lang.Arithmetic[T].operator-(that:T){}:T
    public java.lang.Object $minus(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $minus((x10.lang.Complex)a1);
        
    }
    
    // dispatcher for method abstract public x10.lang.Arithmetic[T].operator*(that:T){}:T
    public java.lang.Object $times(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $times((x10.lang.Complex)a1);
        
    }
    
    // dispatcher for method abstract public x10.lang.Arithmetic[T].operator/(that:T){}:T
    public java.lang.Object $over(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $over((x10.lang.Complex)a1);
        
    }
    
    // bridge for method abstract public x10.lang.Arithmetic[T].operator+(){}:T
    final public x10.lang.Complex $plus$G() {
        return $plus();
    }
    
    // bridge for method abstract public x10.lang.Arithmetic[T].operator-(){}:T
    final public x10.lang.Complex $minus$G() {
        return $minus();
    }
    
    

    
    //#line 29 "x10/lang/Complex.x10"
    /** The real component of this complex number. */
    public double re;
    
    //#line 32 "x10/lang/Complex.x10"
    /** The imaginary component of this complex number. */
    public double im;
    
    //#line 36 "x10/lang/Complex.x10"
    private static x10.lang.Complex ZERO;
    
    //#line 39 "x10/lang/Complex.x10"
    private static x10.lang.Complex ONE;
    
    //#line 42 "x10/lang/Complex.x10"
    private static x10.lang.Complex I;
    
    //#line 45 "x10/lang/Complex.x10"
    private static x10.lang.Complex INF;
    
    //#line 48 "x10/lang/Complex.x10"
    private static x10.lang.Complex NaN;
    
    
    //#line 57 "x10/lang/Complex.x10"
    /**
     * Construct a complex number with the specified real and imaginary components.
     *
     * @real the real component of the Complex number
     * @imaginary the imaginary component of the Complex number
     * @return the Complex number representing (real + imaginary*i)
     */
    public Complex(final double real, final double imaginary) {
         {
            
            //#line 57 "x10/lang/Complex.x10"
            
            
            //#line 24 "x10/lang/Complex.x10"
            this.__fieldInitializers_x10_lang_Complex();
            
            //#line 59 "x10/lang/Complex.x10"
            this.re = real;
            
            //#line 60 "x10/lang/Complex.x10"
            this.im = imaginary;
        }
    }
    
    
    
    //#line 66 "x10/lang/Complex.x10"
    /**
     * @return the sum of this complex number and the given complex number.
     */
    final public x10.lang.Complex $plus(final x10.lang.Complex that) {
        
        //#line 68 "x10/lang/Complex.x10"
        final double t$132260 = this.re;
        
        //#line 68 "x10/lang/Complex.x10"
        final double t$132261 = that.re;
        
        //#line 68 "x10/lang/Complex.x10"
        final double t$132264 = ((t$132260) + (((double)(t$132261))));
        
        //#line 68 "x10/lang/Complex.x10"
        final double t$132262 = this.im;
        
        //#line 68 "x10/lang/Complex.x10"
        final double t$132263 = that.im;
        
        //#line 68 "x10/lang/Complex.x10"
        final double t$132265 = ((t$132262) + (((double)(t$132263))));
        
        //#line 68 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132266 = new x10.lang.Complex(t$132264, t$132265);
        
        //#line 68 "x10/lang/Complex.x10"
        return t$132266;
    }
    
    
    //#line 74 "x10/lang/Complex.x10"
    /**
     * @return the sum of the given double and the given complex number.
     */
    final public static x10.lang.Complex $plus(final double x, final x10.lang.Complex y) {
        
        //#line 75 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132267 = y.$plus((double)(x));
        
        //#line 75 "x10/lang/Complex.x10"
        return t$132267;
    }
    
    
    //#line 80 "x10/lang/Complex.x10"
    /**
     * @return the sum of this complex number and the given double.
     */
    final public x10.lang.Complex $plus(final double that) {
        
        //#line 82 "x10/lang/Complex.x10"
        final double t$132268 = this.re;
        
        //#line 82 "x10/lang/Complex.x10"
        final double t$132269 = ((t$132268) + (((double)(that))));
        
        //#line 82 "x10/lang/Complex.x10"
        final double t$132270 = this.im;
        
        //#line 82 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132271 = new x10.lang.Complex(t$132269, ((double)(t$132270)));
        
        //#line 82 "x10/lang/Complex.x10"
        return t$132271;
    }
    
    
    //#line 88 "x10/lang/Complex.x10"
    /**
     * @return the difference between this complex number and the given complex number.
     */
    final public x10.lang.Complex $minus(final x10.lang.Complex that) {
        
        //#line 90 "x10/lang/Complex.x10"
        final double t$132272 = this.re;
        
        //#line 90 "x10/lang/Complex.x10"
        final double t$132273 = that.re;
        
        //#line 90 "x10/lang/Complex.x10"
        final double t$132276 = ((t$132272) - (((double)(t$132273))));
        
        //#line 90 "x10/lang/Complex.x10"
        final double t$132274 = this.im;
        
        //#line 90 "x10/lang/Complex.x10"
        final double t$132275 = that.im;
        
        //#line 90 "x10/lang/Complex.x10"
        final double t$132277 = ((t$132274) - (((double)(t$132275))));
        
        //#line 90 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132278 = new x10.lang.Complex(t$132276, t$132277);
        
        //#line 90 "x10/lang/Complex.x10"
        return t$132278;
    }
    
    
    //#line 96 "x10/lang/Complex.x10"
    /**
     * @return the difference between the given double and this complex number.
     */
    final public static x10.lang.Complex $minus(final double x, final x10.lang.Complex y) {
        
        //#line 97 "x10/lang/Complex.x10"
        final double t$132279 = y.re;
        
        //#line 97 "x10/lang/Complex.x10"
        final double t$132281 = ((x) - (((double)(t$132279))));
        
        //#line 97 "x10/lang/Complex.x10"
        final double t$132280 = y.im;
        
        //#line 97 "x10/lang/Complex.x10"
        final double t$132282 = (-(t$132280));
        
        //#line 97 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132283 = new x10.lang.Complex(t$132281, t$132282);
        
        //#line 97 "x10/lang/Complex.x10"
        return t$132283;
    }
    
    
    //#line 102 "x10/lang/Complex.x10"
    /**
     * @return the difference between this complex number and the given double.
     */
    final public x10.lang.Complex $minus(final double that) {
        
        //#line 104 "x10/lang/Complex.x10"
        final double t$132284 = this.re;
        
        //#line 104 "x10/lang/Complex.x10"
        final double t$132285 = ((t$132284) - (((double)(that))));
        
        //#line 104 "x10/lang/Complex.x10"
        final double t$132286 = this.im;
        
        //#line 104 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132287 = new x10.lang.Complex(t$132285, ((double)(t$132286)));
        
        //#line 104 "x10/lang/Complex.x10"
        return t$132287;
    }
    
    
    //#line 110 "x10/lang/Complex.x10"
    /**
     * @return the product of this complex number and the given complex number.
     */
    final public x10.lang.Complex $times(final x10.lang.Complex that) {
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132288 = this.re;
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132289 = that.re;
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132292 = ((t$132288) * (((double)(t$132289))));
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132290 = this.im;
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132291 = that.im;
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132293 = ((t$132290) * (((double)(t$132291))));
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132300 = ((t$132292) - (((double)(t$132293))));
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132294 = this.re;
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132295 = that.im;
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132298 = ((t$132294) * (((double)(t$132295))));
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132296 = this.im;
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132297 = that.re;
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132299 = ((t$132296) * (((double)(t$132297))));
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132301 = ((t$132298) + (((double)(t$132299))));
        
        //#line 112 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132302 = new x10.lang.Complex(t$132300, t$132301);
        
        //#line 112 "x10/lang/Complex.x10"
        return t$132302;
    }
    
    
    //#line 119 "x10/lang/Complex.x10"
    /**
     * @return the product of the given double and this complex number.
     */
    final public static x10.lang.Complex $times(final double x, final x10.lang.Complex y) {
        
        //#line 120 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132303 = y.$times((double)(x));
        
        //#line 120 "x10/lang/Complex.x10"
        return t$132303;
    }
    
    
    //#line 125 "x10/lang/Complex.x10"
    /**
     * @return the product of this complex number and the given double.
     */
    final public x10.lang.Complex $times(final double that) {
        
        //#line 127 "x10/lang/Complex.x10"
        final double t$132304 = this.re;
        
        //#line 127 "x10/lang/Complex.x10"
        final double t$132306 = ((t$132304) * (((double)(that))));
        
        //#line 127 "x10/lang/Complex.x10"
        final double t$132305 = this.im;
        
        //#line 127 "x10/lang/Complex.x10"
        final double t$132307 = ((t$132305) * (((double)(that))));
        
        //#line 127 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132308 = new x10.lang.Complex(t$132306, t$132307);
        
        //#line 127 "x10/lang/Complex.x10"
        return t$132308;
    }
    
    
    //#line 136 "x10/lang/Complex.x10"
    /**
     * Return the quotient of this complex number and the given complex number.
     * Uses Smith's algorithm {@link http://doi.acm.org/10.1145/368637.368661}.
     * TODO: consider using Priest's algorithm {@link http://doi.acm.org/10.1145/1039813.1039814}.
     * @return the quotient of this complex number and the given complex number.
     */
    final public x10.lang.Complex $over(final x10.lang.Complex that) {
        
        //#line 138 "x10/lang/Complex.x10"
        boolean t$132309 = this.isNaN$O();
        
        //#line 138 "x10/lang/Complex.x10"
        if (!(t$132309)) {
            
            //#line 138 "x10/lang/Complex.x10"
            t$132309 = that.isNaN$O();
        }
        
        //#line 138 "x10/lang/Complex.x10"
        if (t$132309) {
            
            //#line 139 "x10/lang/Complex.x10"
            final x10.lang.Complex t$132310 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 139 "x10/lang/Complex.x10"
            return t$132310;
        }
        
        //#line 142 "x10/lang/Complex.x10"
        final double c = that.re;
        
        //#line 143 "x10/lang/Complex.x10"
        final double d = that.im;
        
        //#line 144 "x10/lang/Complex.x10"
        boolean t$132312 = ((double) c) == ((double) 0.0);
        
        //#line 144 "x10/lang/Complex.x10"
        if (t$132312) {
            
            //#line 144 "x10/lang/Complex.x10"
            t$132312 = ((double) d) == ((double) 0.0);
        }
        
        //#line 144 "x10/lang/Complex.x10"
        if (t$132312) {
            
            //#line 145 "x10/lang/Complex.x10"
            final double t$132313 = this.re;
            
            //#line 145 "x10/lang/Complex.x10"
            boolean t$132315 = ((double) t$132313) == ((double) 0.0);
            
            //#line 145 "x10/lang/Complex.x10"
            if (t$132315) {
                
                //#line 145 "x10/lang/Complex.x10"
                final double t$132314 = this.im;
                
                //#line 145 "x10/lang/Complex.x10"
                t$132315 = ((double) t$132314) == ((double) 0.0);
            }
            
            //#line 145 "x10/lang/Complex.x10"
            if (t$132315) {
                
                //#line 146 "x10/lang/Complex.x10"
                final x10.lang.Complex t$132316 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
                
                //#line 146 "x10/lang/Complex.x10"
                return t$132316;
            } else {
                
                //#line 148 "x10/lang/Complex.x10"
                final x10.lang.Complex t$132317 = ((x10.lang.Complex)(x10.lang.Complex.get$INF()));
                
                //#line 148 "x10/lang/Complex.x10"
                return t$132317;
            }
        }
        
        //#line 152 "x10/lang/Complex.x10"
        boolean t$132321 = that.isInfinite$O();
        
        //#line 152 "x10/lang/Complex.x10"
        if (t$132321) {
            
            //#line 152 "x10/lang/Complex.x10"
            final boolean t$132320 = this.isInfinite$O();
            
            //#line 152 "x10/lang/Complex.x10"
            t$132321 = !(t$132320);
        }
        
        //#line 152 "x10/lang/Complex.x10"
        if (t$132321) {
            
            //#line 153 "x10/lang/Complex.x10"
            final x10.lang.Complex t$132322 = ((x10.lang.Complex)(x10.lang.Complex.get$ZERO()));
            
            //#line 153 "x10/lang/Complex.x10"
            return t$132322;
        }
        
        //#line 156 "x10/lang/Complex.x10"
        final double t$132324 = java.lang.Math.abs(((double)(d)));
        
        //#line 156 "x10/lang/Complex.x10"
        final double t$132325 = java.lang.Math.abs(((double)(c)));
        
        //#line 156 "x10/lang/Complex.x10"
        final boolean t$132363 = ((t$132324) <= (((double)(t$132325))));
        
        //#line 156 "x10/lang/Complex.x10"
        if (t$132363) {
            
            //#line 157 "x10/lang/Complex.x10"
            final boolean t$132332 = ((double) c) == ((double) 0.0);
            
            //#line 157 "x10/lang/Complex.x10"
            if (t$132332) {
                
                //#line 158 "x10/lang/Complex.x10"
                final double t$132326 = this.im;
                
                //#line 158 "x10/lang/Complex.x10"
                final double t$132329 = ((t$132326) / (((double)(d))));
                
                //#line 158 "x10/lang/Complex.x10"
                final double t$132327 = this.re;
                
                //#line 158 "x10/lang/Complex.x10"
                final double t$132328 = (-(t$132327));
                
                //#line 158 "x10/lang/Complex.x10"
                final double t$132330 = ((t$132328) / (((double)(c))));
                
                //#line 158 "x10/lang/Complex.x10"
                final x10.lang.Complex t$132331 = new x10.lang.Complex(t$132329, t$132330);
                
                //#line 158 "x10/lang/Complex.x10"
                return t$132331;
            }
            
            //#line 160 "x10/lang/Complex.x10"
            final double r = ((d) / (((double)(c))));
            
            //#line 161 "x10/lang/Complex.x10"
            final double t$132333 = ((d) * (((double)(r))));
            
            //#line 161 "x10/lang/Complex.x10"
            final double denominator = ((c) + (((double)(t$132333))));
            
            //#line 162 "x10/lang/Complex.x10"
            final double t$132335 = this.re;
            
            //#line 162 "x10/lang/Complex.x10"
            final double t$132334 = this.im;
            
            //#line 162 "x10/lang/Complex.x10"
            final double t$132336 = ((t$132334) * (((double)(r))));
            
            //#line 162 "x10/lang/Complex.x10"
            final double t$132337 = ((t$132335) + (((double)(t$132336))));
            
            //#line 162 "x10/lang/Complex.x10"
            final double t$132342 = ((t$132337) / (((double)(denominator))));
            
            //#line 163 "x10/lang/Complex.x10"
            final double t$132339 = this.im;
            
            //#line 163 "x10/lang/Complex.x10"
            final double t$132338 = this.re;
            
            //#line 163 "x10/lang/Complex.x10"
            final double t$132340 = ((t$132338) * (((double)(r))));
            
            //#line 163 "x10/lang/Complex.x10"
            final double t$132341 = ((t$132339) - (((double)(t$132340))));
            
            //#line 163 "x10/lang/Complex.x10"
            final double t$132343 = ((t$132341) / (((double)(denominator))));
            
            //#line 162 "x10/lang/Complex.x10"
            final x10.lang.Complex t$132344 = new x10.lang.Complex(t$132342, t$132343);
            
            //#line 162 "x10/lang/Complex.x10"
            return t$132344;
        } else {
            
            //#line 165 "x10/lang/Complex.x10"
            final boolean t$132350 = ((double) d) == ((double) 0.0);
            
            //#line 165 "x10/lang/Complex.x10"
            if (t$132350) {
                
                //#line 166 "x10/lang/Complex.x10"
                final double t$132345 = this.re;
                
                //#line 166 "x10/lang/Complex.x10"
                final double t$132347 = ((t$132345) / (((double)(c))));
                
                //#line 166 "x10/lang/Complex.x10"
                final double t$132346 = this.im;
                
                //#line 166 "x10/lang/Complex.x10"
                final double t$132348 = ((t$132346) / (((double)(c))));
                
                //#line 166 "x10/lang/Complex.x10"
                final x10.lang.Complex t$132349 = new x10.lang.Complex(t$132347, t$132348);
                
                //#line 166 "x10/lang/Complex.x10"
                return t$132349;
            }
            
            //#line 168 "x10/lang/Complex.x10"
            final double r = ((c) / (((double)(d))));
            
            //#line 169 "x10/lang/Complex.x10"
            final double t$132351 = ((c) * (((double)(r))));
            
            //#line 169 "x10/lang/Complex.x10"
            final double denominator = ((t$132351) + (((double)(d))));
            
            //#line 170 "x10/lang/Complex.x10"
            final double t$132352 = this.re;
            
            //#line 170 "x10/lang/Complex.x10"
            final double t$132353 = ((t$132352) * (((double)(r))));
            
            //#line 170 "x10/lang/Complex.x10"
            final double t$132354 = this.im;
            
            //#line 170 "x10/lang/Complex.x10"
            final double t$132355 = ((t$132353) + (((double)(t$132354))));
            
            //#line 170 "x10/lang/Complex.x10"
            final double t$132360 = ((t$132355) / (((double)(denominator))));
            
            //#line 171 "x10/lang/Complex.x10"
            final double t$132356 = this.im;
            
            //#line 171 "x10/lang/Complex.x10"
            final double t$132357 = ((t$132356) * (((double)(r))));
            
            //#line 171 "x10/lang/Complex.x10"
            final double t$132358 = this.re;
            
            //#line 171 "x10/lang/Complex.x10"
            final double t$132359 = ((t$132357) - (((double)(t$132358))));
            
            //#line 171 "x10/lang/Complex.x10"
            final double t$132361 = ((t$132359) / (((double)(denominator))));
            
            //#line 170 "x10/lang/Complex.x10"
            final x10.lang.Complex t$132362 = new x10.lang.Complex(t$132360, t$132361);
            
            //#line 170 "x10/lang/Complex.x10"
            return t$132362;
        }
    }
    
    
    //#line 178 "x10/lang/Complex.x10"
    /**
     * @return the quotient of the given double and this complex number.
     */
    final public static x10.lang.Complex $over(final double x, final x10.lang.Complex y) {
        
        //#line 179 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132364 = new x10.lang.Complex(((double)(x)), ((double)(0.0)));
        
        //#line 179 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132365 = t$132364.$over(((x10.lang.Complex)(y)));
        
        //#line 179 "x10/lang/Complex.x10"
        return t$132365;
    }
    
    
    //#line 184 "x10/lang/Complex.x10"
    /**
     * @return the quotient of this complex number and the given double.
     */
    final public x10.lang.Complex $over(final double that) {
        
        //#line 186 "x10/lang/Complex.x10"
        final double t$132366 = this.re;
        
        //#line 186 "x10/lang/Complex.x10"
        final double t$132368 = ((t$132366) / (((double)(that))));
        
        //#line 186 "x10/lang/Complex.x10"
        final double t$132367 = this.im;
        
        //#line 186 "x10/lang/Complex.x10"
        final double t$132369 = ((t$132367) / (((double)(that))));
        
        //#line 186 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132370 = new x10.lang.Complex(t$132368, t$132369);
        
        //#line 186 "x10/lang/Complex.x10"
        return t$132370;
    }
    
    
    //#line 192 "x10/lang/Complex.x10"
    /**
     * @return the conjugate of this complex number.
     */
    final public x10.lang.Complex conjugate() {
        
        //#line 193 "x10/lang/Complex.x10"
        final double t$132372 = this.re;
        
        //#line 193 "x10/lang/Complex.x10"
        final double t$132371 = this.im;
        
        //#line 193 "x10/lang/Complex.x10"
        final double t$132373 = (-(t$132371));
        
        //#line 193 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132374 = new x10.lang.Complex(((double)(t$132372)), t$132373);
        
        //#line 193 "x10/lang/Complex.x10"
        return t$132374;
    }
    
    
    //#line 198 "x10/lang/Complex.x10"
    /**
     * @return this complex number.
     */
    final public x10.lang.Complex $plus() {
        
        //#line 199 "x10/lang/Complex.x10"
        return this;
    }
    
    
    //#line 204 "x10/lang/Complex.x10"
    /**
     * @return the negation of this complex number.
     */
    final public x10.lang.Complex $minus() {
        
        //#line 205 "x10/lang/Complex.x10"
        final boolean t$132379 = this.isNaN$O();
        
        //#line 205 "x10/lang/Complex.x10"
        x10.lang.Complex t$132380 =  null;
        
        //#line 205 "x10/lang/Complex.x10"
        if (t$132379) {
            
            //#line 205 "x10/lang/Complex.x10"
            t$132380 = x10.lang.Complex.get$NaN();
        } else {
            
            //#line 205 "x10/lang/Complex.x10"
            final double t$132375 = this.re;
            
            //#line 205 "x10/lang/Complex.x10"
            final double t$132377 = (-(t$132375));
            
            //#line 205 "x10/lang/Complex.x10"
            final double t$132376 = this.im;
            
            //#line 205 "x10/lang/Complex.x10"
            final double t$132378 = (-(t$132376));
            
            //#line 205 "x10/lang/Complex.x10"
            t$132380 = new x10.lang.Complex(t$132377, t$132378);
        }
        
        //#line 205 "x10/lang/Complex.x10"
        return t$132380;
    }
    
    
    //#line 217 "x10/lang/Complex.x10"
    /**
     * Return the absolute value of this complex number.
     * <p>
     * Returns <code>NaN</code> if either the real or imaginary part is
     * <code>NaN</code> and <code>Double.POSITIVE_INFINITY</code> if
     * neither part is <code>NaN</code>, but at least one part takes an infinite
     * value.
     *
     * @return the absolute value of this complex number.
     */
    final public double abs$O() {
        
        //#line 219 "x10/lang/Complex.x10"
        final boolean t$132383 = this.isNaN$O();
        
        //#line 219 "x10/lang/Complex.x10"
        if (t$132383) {
            
            //#line 220 "x10/lang/Complex.x10"
            final double t$132382 = java.lang.Double.NaN;
            
            //#line 220 "x10/lang/Complex.x10"
            return t$132382;
        }
        
        //#line 223 "x10/lang/Complex.x10"
        final boolean t$132385 = this.isInfinite$O();
        
        //#line 223 "x10/lang/Complex.x10"
        if (t$132385) {
            
            //#line 224 "x10/lang/Complex.x10"
            final double t$132384 = java.lang.Double.POSITIVE_INFINITY;
            
            //#line 224 "x10/lang/Complex.x10"
            return t$132384;
        }
        
        //#line 227 "x10/lang/Complex.x10"
        final double t$132386 = this.im;
        
        //#line 227 "x10/lang/Complex.x10"
        final boolean t$132396 = ((double) t$132386) == ((double) 0.0);
        
        //#line 227 "x10/lang/Complex.x10"
        if (t$132396) {
            
            //#line 228 "x10/lang/Complex.x10"
            final double t$132387 = this.re;
            
            //#line 228 "x10/lang/Complex.x10"
            final double t$132388 = java.lang.Math.abs(((double)(t$132387)));
            
            //#line 228 "x10/lang/Complex.x10"
            return t$132388;
        } else {
            
            //#line 229 "x10/lang/Complex.x10"
            final double t$132389 = this.re;
            
            //#line 229 "x10/lang/Complex.x10"
            final boolean t$132395 = ((double) t$132389) == ((double) 0.0);
            
            //#line 229 "x10/lang/Complex.x10"
            if (t$132395) {
                
                //#line 230 "x10/lang/Complex.x10"
                final double t$132390 = this.im;
                
                //#line 230 "x10/lang/Complex.x10"
                final double t$132391 = java.lang.Math.abs(((double)(t$132390)));
                
                //#line 230 "x10/lang/Complex.x10"
                return t$132391;
            } else {
                
                //#line 233 "x10/lang/Complex.x10"
                final double t$132392 = this.re;
                
                //#line 233 "x10/lang/Complex.x10"
                final double t$132393 = this.im;
                
                //#line 233 "x10/lang/Complex.x10"
                final double t$132394 = java.lang.Math.hypot(((double)(t$132392)),((double)(t$132393)));
                
                //#line 233 "x10/lang/Complex.x10"
                return t$132394;
            }
        }
    }
    
    
    //#line 240 "x10/lang/Complex.x10"
    /**
     * @return true if either part of this complex number is <code>NaN</code>.
     */
    final public boolean isNaN$O() {
        
        //#line 242 "x10/lang/Complex.x10"
        final double t$132397 = this.re;
        
        //#line 242 "x10/lang/Complex.x10"
        boolean t$132399 = java.lang.Double.isNaN(t$132397);
        
        //#line 242 "x10/lang/Complex.x10"
        if (!(t$132399)) {
            
            //#line 242 "x10/lang/Complex.x10"
            final double t$132398 = this.im;
            
            //#line 242 "x10/lang/Complex.x10"
            t$132399 = java.lang.Double.isNaN(t$132398);
        }
        
        //#line 242 "x10/lang/Complex.x10"
        return t$132399;
    }
    
    
    //#line 249 "x10/lang/Complex.x10"
    /**
     * @return true if either part of this complex number is infinite
     * and neither part is <code>NaN</code>.
     */
    final public boolean isInfinite$O() {
        
        //#line 251 "x10/lang/Complex.x10"
        final boolean t$132401 = this.isNaN$O();
        
        //#line 251 "x10/lang/Complex.x10"
        boolean t$132405 = !(t$132401);
        
        //#line 251 "x10/lang/Complex.x10"
        if (t$132405) {
            
            //#line 252 "x10/lang/Complex.x10"
            final double t$132402 = this.re;
            
            //#line 252 "x10/lang/Complex.x10"
            boolean t$132404 = java.lang.Double.isInfinite(t$132402);
            
            //#line 252 "x10/lang/Complex.x10"
            if (!(t$132404)) {
                
                //#line 252 "x10/lang/Complex.x10"
                final double t$132403 = this.im;
                
                //#line 252 "x10/lang/Complex.x10"
                t$132404 = java.lang.Double.isInfinite(t$132403);
            }
            
            //#line 251 "x10/lang/Complex.x10"
            t$132405 = t$132404;
        }
        
        //#line 251 "x10/lang/Complex.x10"
        return t$132405;
    }
    
    
    //#line 258 "x10/lang/Complex.x10"
    /**
     * @return the string representation of this complex number.
     */
    final public java.lang.String toString() {
        
        //#line 260 "x10/lang/Complex.x10"
        final double t$132407 = this.re;
        
        //#line 260 "x10/lang/Complex.x10"
        final java.lang.String t$132408 = (("") + ((x10.core.Double.$box(t$132407))));
        
        //#line 260 "x10/lang/Complex.x10"
        final java.lang.String t$132409 = ((t$132408) + (" + "));
        
        //#line 260 "x10/lang/Complex.x10"
        final double t$132410 = this.im;
        
        //#line 260 "x10/lang/Complex.x10"
        final java.lang.String t$132411 = ((t$132409) + ((x10.core.Double.$box(t$132410))));
        
        //#line 260 "x10/lang/Complex.x10"
        final java.lang.String t$132412 = ((t$132411) + ("i"));
        
        //#line 260 "x10/lang/Complex.x10"
        return t$132412;
    }
    
    
    //#line 263 "x10/lang/Complex.x10"
    final public int hashCode() {
        
        //#line 265 "x10/lang/Complex.x10"
        final double t$132413 = this.re;
        
        //#line 265 "x10/lang/Complex.x10"
        final int t$132415 = x10.rtt.Types.hashCode(t$132413);
        
        //#line 265 "x10/lang/Complex.x10"
        final double t$132414 = this.im;
        
        //#line 265 "x10/lang/Complex.x10"
        final int t$132416 = x10.rtt.Types.hashCode(t$132414);
        
        //#line 265 "x10/lang/Complex.x10"
        final int t$132417 = ((t$132415) * (((int)(t$132416))));
        
        //#line 265 "x10/lang/Complex.x10"
        return t$132417;
    }
    
    
    //#line 25 "x10/lang/Complex.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$205577) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205577);
        }
        
    }
    
    
    
    //#line 25 "x10/lang/Complex.x10"
    final public boolean equals(java.lang.Object other) {
        
        //#line 25 "x10/lang/Complex.x10"
        final boolean t$132419 = x10.lang.Complex.$RTT.isInstance(other);
        
        //#line 25 "x10/lang/Complex.x10"
        final boolean t$132420 = !(t$132419);
        
        //#line 25 "x10/lang/Complex.x10"
        if (t$132420) {
            
            //#line 25 "x10/lang/Complex.x10"
            return false;
        }
        
        //#line 25 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132422 = ((x10.lang.Complex)x10.rtt.Types.asStruct(x10.lang.Complex.$RTT,other));
        
        //#line 25 "x10/lang/Complex.x10"
        final boolean t$132423 = this.equals$O(((x10.lang.Complex)(t$132422)));
        
        //#line 25 "x10/lang/Complex.x10"
        return t$132423;
    }
    
    
    //#line 25 "x10/lang/Complex.x10"
    final public boolean equals$O(x10.lang.Complex other) {
        
        //#line 25 "x10/lang/Complex.x10"
        final double t$132425 = this.re;
        
        //#line 25 "x10/lang/Complex.x10"
        final double t$132426 = other.re;
        
        //#line 25 "x10/lang/Complex.x10"
        boolean t$132430 = ((double) t$132425) == ((double) t$132426);
        
        //#line 25 "x10/lang/Complex.x10"
        if (t$132430) {
            
            //#line 25 "x10/lang/Complex.x10"
            final double t$132428 = this.im;
            
            //#line 25 "x10/lang/Complex.x10"
            final double t$132429 = other.im;
            
            //#line 25 "x10/lang/Complex.x10"
            t$132430 = ((double) t$132428) == ((double) t$132429);
        }
        
        //#line 25 "x10/lang/Complex.x10"
        return t$132430;
    }
    
    
    //#line 25 "x10/lang/Complex.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 25 "x10/lang/Complex.x10"
        final boolean t$132433 = x10.lang.Complex.$RTT.isInstance(other);
        
        //#line 25 "x10/lang/Complex.x10"
        final boolean t$132434 = !(t$132433);
        
        //#line 25 "x10/lang/Complex.x10"
        if (t$132434) {
            
            //#line 25 "x10/lang/Complex.x10"
            return false;
        }
        
        //#line 25 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132436 = ((x10.lang.Complex)x10.rtt.Types.asStruct(x10.lang.Complex.$RTT,other));
        
        //#line 25 "x10/lang/Complex.x10"
        final boolean t$132437 = this._struct_equals$O(((x10.lang.Complex)(t$132436)));
        
        //#line 25 "x10/lang/Complex.x10"
        return t$132437;
    }
    
    
    //#line 25 "x10/lang/Complex.x10"
    final public boolean _struct_equals$O(x10.lang.Complex other) {
        
        //#line 25 "x10/lang/Complex.x10"
        final double t$132439 = this.re;
        
        //#line 25 "x10/lang/Complex.x10"
        final double t$132440 = other.re;
        
        //#line 25 "x10/lang/Complex.x10"
        boolean t$132444 = ((double) t$132439) == ((double) t$132440);
        
        //#line 25 "x10/lang/Complex.x10"
        if (t$132444) {
            
            //#line 25 "x10/lang/Complex.x10"
            final double t$132442 = this.im;
            
            //#line 25 "x10/lang/Complex.x10"
            final double t$132443 = other.im;
            
            //#line 25 "x10/lang/Complex.x10"
            t$132444 = ((double) t$132442) == ((double) t$132443);
        }
        
        //#line 25 "x10/lang/Complex.x10"
        return t$132444;
    }
    
    
    //#line 24 "x10/lang/Complex.x10"
    final public x10.lang.Complex x10$lang$Complex$$this$x10$lang$Complex() {
        
        //#line 24 "x10/lang/Complex.x10"
        return x10.lang.Complex.this;
    }
    
    
    //#line 24 "x10/lang/Complex.x10"
    final public void __fieldInitializers_x10_lang_Complex() {
        
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$NaN = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$NaN;
    final private static x10.core.concurrent.AtomicInteger initStatus$INF = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$INF;
    final private static x10.core.concurrent.AtomicInteger initStatus$I = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$I;
    final private static x10.core.concurrent.AtomicInteger initStatus$ONE = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$ONE;
    final private static x10.core.concurrent.AtomicInteger initStatus$ZERO = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$ZERO;
    
    public static x10.lang.Complex get$ZERO() {
        if (((int) x10.lang.Complex.initStatus$ZERO.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Complex.ZERO;
        }
        if (((int) x10.lang.Complex.initStatus$ZERO.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Complex.exception$ZERO;
        }
        if (x10.lang.Complex.initStatus$ZERO.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Complex.ZERO = new x10.lang.Complex(((double)(0.0)), ((double)(0.0)));
            }}catch (java.lang.Throwable exc$132446) {
                x10.lang.Complex.exception$ZERO = new x10.lang.ExceptionInInitializer(exc$132446);
                x10.lang.Complex.initStatus$ZERO.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Complex.exception$ZERO;
            }
            x10.lang.Complex.initStatus$ZERO.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Complex.initStatus$ZERO.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Complex.initStatus$ZERO.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Complex.initStatus$ZERO.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Complex.exception$ZERO;
                }
            }
        }
        return x10.lang.Complex.ZERO;
    }
    
    public static x10.lang.Complex get$ONE() {
        if (((int) x10.lang.Complex.initStatus$ONE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Complex.ONE;
        }
        if (((int) x10.lang.Complex.initStatus$ONE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Complex.exception$ONE;
        }
        if (x10.lang.Complex.initStatus$ONE.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Complex.ONE = new x10.lang.Complex(((double)(1.0)), ((double)(0.0)));
            }}catch (java.lang.Throwable exc$132447) {
                x10.lang.Complex.exception$ONE = new x10.lang.ExceptionInInitializer(exc$132447);
                x10.lang.Complex.initStatus$ONE.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Complex.exception$ONE;
            }
            x10.lang.Complex.initStatus$ONE.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Complex.initStatus$ONE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Complex.initStatus$ONE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Complex.initStatus$ONE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Complex.exception$ONE;
                }
            }
        }
        return x10.lang.Complex.ONE;
    }
    
    public static x10.lang.Complex get$I() {
        if (((int) x10.lang.Complex.initStatus$I.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Complex.I;
        }
        if (((int) x10.lang.Complex.initStatus$I.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Complex.exception$I;
        }
        if (x10.lang.Complex.initStatus$I.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Complex.I = new x10.lang.Complex(((double)(0.0)), ((double)(1.0)));
            }}catch (java.lang.Throwable exc$132448) {
                x10.lang.Complex.exception$I = new x10.lang.ExceptionInInitializer(exc$132448);
                x10.lang.Complex.initStatus$I.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Complex.exception$I;
            }
            x10.lang.Complex.initStatus$I.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Complex.initStatus$I.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Complex.initStatus$I.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Complex.initStatus$I.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Complex.exception$I;
                }
            }
        }
        return x10.lang.Complex.I;
    }
    
    public static x10.lang.Complex get$INF() {
        if (((int) x10.lang.Complex.initStatus$INF.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Complex.INF;
        }
        if (((int) x10.lang.Complex.initStatus$INF.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Complex.exception$INF;
        }
        if (x10.lang.Complex.initStatus$INF.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Complex.INF = new x10.lang.Complex(((double)(java.lang.Double.POSITIVE_INFINITY)), ((double)(java.lang.Double.POSITIVE_INFINITY)));
            }}catch (java.lang.Throwable exc$132449) {
                x10.lang.Complex.exception$INF = new x10.lang.ExceptionInInitializer(exc$132449);
                x10.lang.Complex.initStatus$INF.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Complex.exception$INF;
            }
            x10.lang.Complex.initStatus$INF.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Complex.initStatus$INF.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Complex.initStatus$INF.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Complex.initStatus$INF.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Complex.exception$INF;
                }
            }
        }
        return x10.lang.Complex.INF;
    }
    
    public static x10.lang.Complex get$NaN() {
        if (((int) x10.lang.Complex.initStatus$NaN.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Complex.NaN;
        }
        if (((int) x10.lang.Complex.initStatus$NaN.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Complex.exception$NaN;
        }
        if (x10.lang.Complex.initStatus$NaN.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Complex.NaN = new x10.lang.Complex(((double)(java.lang.Double.NaN)), ((double)(java.lang.Double.NaN)));
            }}catch (java.lang.Throwable exc$132450) {
                x10.lang.Complex.exception$NaN = new x10.lang.ExceptionInInitializer(exc$132450);
                x10.lang.Complex.initStatus$NaN.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Complex.exception$NaN;
            }
            x10.lang.Complex.initStatus$NaN.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Complex.initStatus$NaN.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Complex.initStatus$NaN.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Complex.initStatus$NaN.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Complex.exception$NaN;
                }
            }
        }
        return x10.lang.Complex.NaN;
    }
}

