package x10.lang;

/**
 * Thrown to indicate that a Place has died.
 * Place death lasts until the end of execution.  All state at the place is lost.
 */
@x10.runtime.impl.java.X10Generated
public class DeadPlaceException extends java.lang.RuntimeException implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DeadPlaceException> $RTT = 
        x10.rtt.NamedType.<DeadPlaceException> make("x10.lang.DeadPlaceException",
                                                    DeadPlaceException.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.EXCEPTION
                                                    });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.DeadPlaceException $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $deserializer.deserializeFieldsStartingFromClass(java.lang.RuntimeException.class, $_obj, 0);
        $_obj.place = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.DeadPlaceException $_obj = new x10.lang.DeadPlaceException((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.serializeFieldsStartingFromClass(this, java.lang.RuntimeException.class);
        $serializer.write(this.place);
        
    }
    
    // constructor just for allocation
    public DeadPlaceException(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 18 "x10/lang/DeadPlaceException.x10"
    public x10.lang.Place place;
    

    
    
    //#line 23 "x10/lang/DeadPlaceException.x10"
    /**
     * Construct a DeadPlaceException with the default detail message.
     */
    public DeadPlaceException() {
        super((("DeadPlaceException at ") + (x10.x10rt.X10RT.here())));
         {
            
            //#line 25 "x10/lang/DeadPlaceException.x10"
            this.place = x10.x10rt.X10RT.here();
            
            
            //#line 18 "x10/lang/DeadPlaceException.x10"
            this.__fieldInitializers_x10_lang_DeadPlaceException();
        }
    }
    
    
    
    //#line 33 "x10/lang/DeadPlaceException.x10"
    /**
     * Construct a DeadPlaceException with the specified detail message.
     *
     * @param message the detail message
     */
    public DeadPlaceException(final java.lang.String message) {
        super(((java.lang.String)(message)));
         {
            
            //#line 35 "x10/lang/DeadPlaceException.x10"
            this.place = x10.x10rt.X10RT.here();
            
            
            //#line 18 "x10/lang/DeadPlaceException.x10"
            this.__fieldInitializers_x10_lang_DeadPlaceException();
        }
    }
    
    
    
    //#line 43 "x10/lang/DeadPlaceException.x10"
    /**
     * Construct a DeadPlaceException with the default detail message.
     *
     * @param p The place that has died.
     */
    public DeadPlaceException(final x10.lang.Place p) {
        super((("DeadPlaceException at ") + (p)));
         {
            
            //#line 45 "x10/lang/DeadPlaceException.x10"
            this.place = p;
            
            
            //#line 18 "x10/lang/DeadPlaceException.x10"
            this.__fieldInitializers_x10_lang_DeadPlaceException();
        }
    }
    
    
    
    //#line 54 "x10/lang/DeadPlaceException.x10"
    /**
     * Construct a DeadPlaceException with the specified detail message.
     *
     * @param p The place that has died.
     * @param message the detail message
     */
    public DeadPlaceException(final x10.lang.Place p, final java.lang.String message) {
        super(((java.lang.String)(message)));
         {
            
            //#line 56 "x10/lang/DeadPlaceException.x10"
            this.place = p;
            
            
            //#line 18 "x10/lang/DeadPlaceException.x10"
            this.__fieldInitializers_x10_lang_DeadPlaceException();
        }
    }
    
    
    
    //#line 18 "x10/lang/DeadPlaceException.x10"
    final public x10.lang.DeadPlaceException x10$lang$DeadPlaceException$$this$x10$lang$DeadPlaceException() {
        
        //#line 18 "x10/lang/DeadPlaceException.x10"
        return x10.lang.DeadPlaceException.this;
    }
    
    
    //#line 18 "x10/lang/DeadPlaceException.x10"
    final public void __fieldInitializers_x10_lang_DeadPlaceException() {
        
    }
}

