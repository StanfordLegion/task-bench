package x10.lang;


/**
 * Thrown to indicate that an attempt has been made to 
 * create a Rail or Array with a negative size.
 */
;

