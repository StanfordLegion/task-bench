package x10.lang;


/**
 * Long is a 64-bit signed two's complement integral data type, with
 * values ranging from -9223372036854775808 to 9223372036854775807, inclusive.  All of the normal
 * arithmetic and bitwise operations are defined on Long, and Long
 * is closed under those operations.  There are also static methods
 * that define conversions from other data types, including String,
 * as well as some Long constants.
 */
;


