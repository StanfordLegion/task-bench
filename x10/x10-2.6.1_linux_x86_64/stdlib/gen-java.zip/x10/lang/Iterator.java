package x10.lang;


@x10.runtime.impl.java.X10Generated
public interface Iterator<$T> extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<Iterator> $RTT = 
        x10.rtt.NamedType.<Iterator> make("x10.lang.Iterator", Iterator.class,
                                          1);
    
    

    
    
    //#line 18 "x10/lang/Iterator.x10"
    boolean hasNext$O();
    
    
    //#line 19 "x10/lang/Iterator.x10"
    $T next$G();
}

