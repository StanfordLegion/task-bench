package x10.lang;


/**
 * This interface imposes a total ordering on the entities of each type that implements it.
 *
 * Lists of objects that implement this interface can be sorted automatically by the sort()
 * method of the List class.  Objects that implement this interface can be used as keys in
 * a sorted map or as elements in a sorted set, without the need to specify a comparator.
 *
 * @param T the type of entities that this entity may be compared to
 */
;

