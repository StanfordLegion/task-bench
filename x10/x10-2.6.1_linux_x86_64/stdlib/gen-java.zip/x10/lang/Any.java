package x10.lang;


/**
 * The top of the type hierarchy.
 * Implemented by all classes and structs.
 */
;


