package x10.lang;


/**
 * Ported from 2.0 to 2.1 via naive simulation of 
 *       2.0 style global object by injecting a root field
 *       that is a GlobalRef(this) and always accessing fields 
 *       as this.root().f instead of this.f.
 * TODO: Port to Dual Class implementation of global objects.
 */
@x10.runtime.impl.java.X10Generated
final public class Clock extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Clock> $RTT = 
        x10.rtt.NamedType.<Clock> make("x10.lang.Clock",
                                       Clock.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.name = $deserializer.readObject();
        $_obj.root = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.Clock $_obj = new x10.lang.Clock((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.name);
        $serializer.write(this.root);
        
    }
    
    // constructor just for allocation
    public Clock(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 32 "x10/lang/Clock.x10"
    public java.lang.String name;
    

    
    //#line 33 "x10/lang/Clock.x10"
    public x10.core.GlobalRef<x10.lang.Clock> root;
    
    
    //#line 34 "x10/lang/Clock.x10"
    public boolean equals(final java.lang.Object a) {
        
        //#line 35 "x10/lang/Clock.x10"
        boolean t$131657 = ((a) == (null));
        
        //#line 35 "x10/lang/Clock.x10"
        if (!(t$131657)) {
            
            //#line 35 "x10/lang/Clock.x10"
            final boolean t$131656 = x10.lang.Clock.$RTT.isInstance(a);
            
            //#line 35 "x10/lang/Clock.x10"
            t$131657 = !(t$131656);
        }
        
        //#line 35 "x10/lang/Clock.x10"
        if (t$131657) {
            
            //#line 36 "x10/lang/Clock.x10"
            return false;
        }
        
        //#line 38 "x10/lang/Clock.x10"
        final x10.lang.Clock t$131659 = ((x10.lang.Clock)(x10.rtt.Types.<x10.lang.Clock> cast(a,x10.lang.Clock.$RTT)));
        
        //#line 38 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$131660 = ((x10.core.GlobalRef)(t$131659.root));
        
        //#line 38 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$131661 = ((x10.core.GlobalRef)(this.root));
        
        //#line 38 "x10/lang/Clock.x10"
        final boolean t$131662 = x10.rtt.Equality.equalsequals((t$131660),(t$131661));
        
        //#line 38 "x10/lang/Clock.x10"
        return t$131662;
    }
    
    
    //#line 40 "x10/lang/Clock.x10"
    public int hashCode() {
        
        //#line 40 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$131663 = ((x10.core.GlobalRef)(this.root));
        
        //#line 40 "x10/lang/Clock.x10"
        final int t$131664 = (((x10.core.GlobalRef<x10.lang.Clock>)(t$131663))).hashCode();
        
        //#line 40 "x10/lang/Clock.x10"
        return t$131664;
    }
    
    
    //#line 42 "x10/lang/Clock.x10"
    public static x10.lang.Clock make() {
        
        //#line 42 "x10/lang/Clock.x10"
        final x10.lang.Clock t$131665 = x10.lang.Clock.make(((java.lang.String)("")));
        
        //#line 42 "x10/lang/Clock.x10"
        return t$131665;
    }
    
    
    //#line 43 "x10/lang/Clock.x10"
    public static x10.lang.Clock make(final java.lang.String name) {
        
        //#line 44 "x10/lang/Clock.x10"
        final boolean t$131667 = x10.xrx.Runtime.get$STATIC_THREADS();
        
        //#line 44 "x10/lang/Clock.x10"
        if (t$131667) {
            
            //#line 44 "x10/lang/Clock.x10"
            final x10.lang.ClockUseException t$131666 = ((x10.lang.ClockUseException)(new x10.lang.ClockUseException(((java.lang.String)("Clocks are not compatible with static threads.")))));
            
            //#line 44 "x10/lang/Clock.x10"
            throw t$131666;
        }
        
        //#line 45 "x10/lang/Clock.x10"
        final x10.lang.Clock clock = ((x10.lang.Clock)(new x10.lang.Clock((java.lang.System[]) null)));
        
        //#line 58 . "x10/lang/Clock.x10"
        clock.name = name;
        
        //#line 32 . "x10/lang/Clock.x10"
        clock.__fieldInitializers_x10_lang_Clock();
        
        //#line 46 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$131668 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 46 "x10/lang/Clock.x10"
        ((x10.util.HashMap<x10.lang.Clock, x10.core.Int>)t$131668).put__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G(((x10.lang.Clock)(clock)), x10.core.Int.$box(1));
        
        //#line 47 "x10/lang/Clock.x10"
        return clock;
    }
    
    
    //#line 50 "x10/lang/Clock.x10"
    final public static int FIRST_PHASE = 1;
    
    //#line 53 "x10/lang/Clock.x10"
    public transient int count;
    
    //#line 54 "x10/lang/Clock.x10"
    public transient int alive;
    
    //#line 55 "x10/lang/Clock.x10"
    public transient int phase;
    
    
    //#line 57 "x10/lang/Clock.x10"
    // creation method for java code (1-phase java constructor)
    public Clock(final java.lang.String name) {
        this((java.lang.System[]) null);
        x10$lang$Clock$$init$S(name);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Clock x10$lang$Clock$$init$S(final java.lang.String name) {
         {
            
            //#line 58 "x10/lang/Clock.x10"
            this.name = name;
            
            
            //#line 32 "x10/lang/Clock.x10"
            this.__fieldInitializers_x10_lang_Clock();
        }
        return this;
    }
    
    
    
    //#line 62 "x10/lang/Clock.x10"
    private void resumeLocal() {
        
        //#line 63 "x10/lang/Clock.x10"
        try {{
            
            //#line 63 "x10/lang/Clock.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 64 "x10/lang/Clock.x10"
                final int t$131669 = this.alive;
                
                //#line 64 "x10/lang/Clock.x10"
                final int t$131670 = ((t$131669) - (((int)(1))));
                
                //#line 64 "x10/lang/Clock.x10"
                final int t$131671 = this.alive = t$131670;
                
                //#line 64 "x10/lang/Clock.x10"
                final boolean t$131675 = ((int) t$131671) == ((int) 0);
                
                //#line 64 "x10/lang/Clock.x10"
                if (t$131675) {
                    
                    //#line 65 "x10/lang/Clock.x10"
                    final int t$131672 = this.count;
                    
                    //#line 65 "x10/lang/Clock.x10"
                    this.alive = t$131672;
                    
                    //#line 66 "x10/lang/Clock.x10"
                    final int t$131673 = this.phase;
                    
                    //#line 66 "x10/lang/Clock.x10"
                    final int t$131674 = ((t$131673) + (((int)(1))));
                    
                    //#line 66 "x10/lang/Clock.x10"
                    this.phase = t$131674;
                }
            }
        }}finally {{
              
              //#line 63 "x10/lang/Clock.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    public static void resumeLocal$P(final x10.lang.Clock Clock) {
        Clock.resumeLocal();
    }
    
    
    //#line 70 "x10/lang/Clock.x10"
    private void dropLocal(final int ph) {
        
        //#line 71 "x10/lang/Clock.x10"
        try {{
            
            //#line 71 "x10/lang/Clock.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 72 "x10/lang/Clock.x10"
                final int t$131676 = this.count;
                
                //#line 72 "x10/lang/Clock.x10"
                final int t$131677 = ((t$131676) - (((int)(1))));
                
                //#line 72 "x10/lang/Clock.x10"
                this.count = t$131677;
                
                //#line 73 "x10/lang/Clock.x10"
                final int t$131678 = (-(ph));
                
                //#line 73 "x10/lang/Clock.x10"
                final int t$131679 = this.phase;
                
                //#line 73 "x10/lang/Clock.x10"
                final boolean t$131687 = ((int) t$131678) != ((int) t$131679);
                
                //#line 73 "x10/lang/Clock.x10"
                if (t$131687) {
                    
                    //#line 74 "x10/lang/Clock.x10"
                    final int t$131680 = this.alive;
                    
                    //#line 74 "x10/lang/Clock.x10"
                    final int t$131681 = ((t$131680) - (((int)(1))));
                    
                    //#line 74 "x10/lang/Clock.x10"
                    final int t$131682 = this.alive = t$131681;
                    
                    //#line 74 "x10/lang/Clock.x10"
                    final boolean t$131686 = ((int) t$131682) == ((int) 0);
                    
                    //#line 74 "x10/lang/Clock.x10"
                    if (t$131686) {
                        
                        //#line 75 "x10/lang/Clock.x10"
                        final int t$131683 = this.count;
                        
                        //#line 75 "x10/lang/Clock.x10"
                        this.alive = t$131683;
                        
                        //#line 76 "x10/lang/Clock.x10"
                        final int t$131684 = this.phase;
                        
                        //#line 76 "x10/lang/Clock.x10"
                        final int t$131685 = ((t$131684) + (((int)(1))));
                        
                        //#line 76 "x10/lang/Clock.x10"
                        this.phase = t$131685;
                    }
                }
            }
        }}finally {{
              
              //#line 71 "x10/lang/Clock.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    public static void dropLocal$P(final int ph, final x10.lang.Clock Clock) {
        Clock.dropLocal((int)(ph));
    }
    
    
    //#line 82 "x10/lang/Clock.x10"
    private int get$O() {
        
        //#line 82 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$131688 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 82 "x10/lang/Clock.x10"
        final int t$131689 = x10.core.Int.$unbox(((x10.util.HashMap<x10.lang.Clock, x10.core.Int>)t$131688).get__0x10$util$HashMap$$K$G(((x10.lang.Clock)(this))));
        
        //#line 82 "x10/lang/Clock.x10"
        return t$131689;
    }
    
    public static int get$P(final x10.lang.Clock Clock) {
        return Clock.get$O();
    }
    
    
    //#line 83 "x10/lang/Clock.x10"
    private int put$O(final int ph) {
        
        //#line 83 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$131690 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 83 "x10/lang/Clock.x10"
        final int t$131691 = x10.core.Int.$unbox(((x10.util.HashMap<x10.lang.Clock, x10.core.Int>)t$131690).put__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G(((x10.lang.Clock)(this)), x10.core.Int.$box(ph)));
        
        //#line 83 "x10/lang/Clock.x10"
        return t$131691;
    }
    
    public static int put$P$O(final int ph, final x10.lang.Clock Clock) {
        return Clock.put$O((int)(ph));
    }
    
    
    //#line 84 "x10/lang/Clock.x10"
    private int remove$O() {
        
        //#line 84 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$131692 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 84 "x10/lang/Clock.x10"
        final int t$131693 = x10.core.Int.$unbox(((x10.util.HashMap<x10.lang.Clock, x10.core.Int>)t$131692).remove__0x10$util$HashMap$$K$G(((x10.lang.Clock)(this))));
        
        //#line 84 "x10/lang/Clock.x10"
        return t$131693;
    }
    
    public static int remove$P$O(final x10.lang.Clock Clock) {
        return Clock.remove$O();
    }
    
    
    //#line 85 "x10/lang/Clock.x10"
    public int register$O() {
        
        //#line 86 "x10/lang/Clock.x10"
        final x10.lang.Clock this$131640 = ((x10.lang.Clock)(this));
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$131694 = this$131640.registered$O();
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$131695 = !(t$131694);
        
        //#line 86 "x10/lang/Clock.x10"
        if (t$131695) {
            
            //#line 86 "x10/lang/Clock.x10"
            this.clockUseException(((java.lang.String)("async clocked")));
        }
        
        //#line 87 "x10/lang/Clock.x10"
        final int ph = this.get$O();
        
        //#line 88 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$131696 = ((x10.core.GlobalRef)(this.root));
        
        //#line 88 "x10/lang/Clock.x10"
        final x10.lang.Place t$131705 = ((x10.lang.Place)((t$131696).home));
        {
            
            //#line 88 "x10/lang/Clock.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$131705)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.Clock.$Closure$103(this, this.root, ph, (x10.lang.Clock.$Closure$103.__1$1x10$lang$Clock$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
        
        //#line 96 "x10/lang/Clock.x10"
        return ph;
    }
    
    
    //#line 98 "x10/lang/Clock.x10"
    public void resumeUnsafe() {
        
        //#line 99 "x10/lang/Clock.x10"
        x10.xrx.Runtime.ensureNotInAtomic();
        
        //#line 100 "x10/lang/Clock.x10"
        final int ph = this.get$O();
        
        //#line 101 "x10/lang/Clock.x10"
        final long t$131706 = ((long)(((int)(ph))));
        
        //#line 101 "x10/lang/Clock.x10"
        final boolean t$131707 = ((t$131706) < (((long)(0L))));
        
        //#line 101 "x10/lang/Clock.x10"
        if (t$131707) {
            
            //#line 101 "x10/lang/Clock.x10"
            return;
        }
        
        //#line 102 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$131708 = ((x10.core.GlobalRef)(this.root));
        
        //#line 102 "x10/lang/Clock.x10"
        final x10.lang.Place t$131710 = ((x10.lang.Place)((t$131708).home));
        {
            
            //#line 102 "x10/lang/Clock.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$131710)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.Clock.$Closure$104(this, this.root, (x10.lang.Clock.$Closure$104.__1$1x10$lang$Clock$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
        
        //#line 106 "x10/lang/Clock.x10"
        final int t$131711 = (-(ph));
        
        //#line 106 "x10/lang/Clock.x10"
        this.put$O((int)(t$131711));
    }
    
    
    //#line 108 "x10/lang/Clock.x10"
    public void advanceUnsafe() {
        
        //#line 109 "x10/lang/Clock.x10"
        x10.xrx.Runtime.ensureNotInAtomic();
        
        //#line 110 "x10/lang/Clock.x10"
        final int ph = this.get$O();
        
        //#line 111 "x10/lang/Clock.x10"
        final int abs = java.lang.Math.abs(((int)(ph)));
        
        //#line 112 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$131712 = ((x10.core.GlobalRef)(this.root));
        
        //#line 112 "x10/lang/Clock.x10"
        final x10.lang.Place t$131716 = ((x10.lang.Place)((t$131712).home));
        {
            
            //#line 112 "x10/lang/Clock.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$131716)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.Clock.$Closure$105(this, this.root, ph, abs, (x10.lang.Clock.$Closure$105.__1$1x10$lang$Clock$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
        
        //#line 117 "x10/lang/Clock.x10"
        final int t$131717 = ((abs) + (((int)(1))));
        
        //#line 117 "x10/lang/Clock.x10"
        this.put$O((int)(t$131717));
    }
    
    
    //#line 119 "x10/lang/Clock.x10"
    public void dropUnsafe() {
        
        //#line 120 "x10/lang/Clock.x10"
        final int ph = this.remove$O();
        
        //#line 121 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$131718 = ((x10.core.GlobalRef)(this.root));
        
        //#line 121 "x10/lang/Clock.x10"
        final x10.lang.Place t$131720 = ((x10.lang.Place)((t$131718).home));
        {
            
            //#line 121 "x10/lang/Clock.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$131720)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.Clock.$Closure$106(this, this.root, ph, (x10.lang.Clock.$Closure$106.__1$1x10$lang$Clock$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 126 "x10/lang/Clock.x10"
    public void dropInternal() {
        
        //#line 127 "x10/lang/Clock.x10"
        final int ph = this.get$O();
        
        //#line 128 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$131721 = ((x10.core.GlobalRef)(this.root));
        
        //#line 128 "x10/lang/Clock.x10"
        final x10.lang.Place t$131723 = ((x10.lang.Place)((t$131721).home));
        {
            
            //#line 128 "x10/lang/Clock.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$131723)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.Clock.$Closure$107(this, this.root, ph, (x10.lang.Clock.$Closure$107.__1$1x10$lang$Clock$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 133 "x10/lang/Clock.x10"
    public boolean registered$O() {
        
        //#line 133 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$131724 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 133 "x10/lang/Clock.x10"
        final boolean t$131725 = ((x10.util.HashMap<x10.lang.Clock, x10.core.Int>)t$131724).containsKey__0x10$util$HashMap$$K$O(((x10.lang.Clock)(this)));
        
        //#line 133 "x10/lang/Clock.x10"
        return t$131725;
    }
    
    
    //#line 134 "x10/lang/Clock.x10"
    public boolean dropped$O() {
        
        //#line 134 "x10/lang/Clock.x10"
        final boolean t$131726 = this.registered$O();
        
        //#line 134 "x10/lang/Clock.x10"
        final boolean t$131727 = !(t$131726);
        
        //#line 134 "x10/lang/Clock.x10"
        return t$131727;
    }
    
    
    //#line 135 "x10/lang/Clock.x10"
    public int phase$O() {
        
        //#line 136 "x10/lang/Clock.x10"
        final x10.lang.Clock this$131642 = ((x10.lang.Clock)(this));
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$131728 = this$131642.registered$O();
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$131729 = !(t$131728);
        
        //#line 136 "x10/lang/Clock.x10"
        if (t$131729) {
            
            //#line 136 "x10/lang/Clock.x10"
            this.clockUseException(((java.lang.String)("phase")));
        }
        
        //#line 137 "x10/lang/Clock.x10"
        final int t$131730 = this.get$O();
        
        //#line 137 "x10/lang/Clock.x10"
        final int t$131731 = java.lang.Math.abs(((int)(t$131730)));
        
        //#line 137 "x10/lang/Clock.x10"
        return t$131731;
    }
    
    
    //#line 139 "x10/lang/Clock.x10"
    public void resume() {
        
        //#line 140 "x10/lang/Clock.x10"
        final x10.lang.Clock this$131644 = ((x10.lang.Clock)(this));
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$131732 = this$131644.registered$O();
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$131733 = !(t$131732);
        
        //#line 140 "x10/lang/Clock.x10"
        if (t$131733) {
            
            //#line 140 "x10/lang/Clock.x10"
            this.clockUseException(((java.lang.String)("resume")));
        }
        
        //#line 141 "x10/lang/Clock.x10"
        this.resumeUnsafe();
    }
    
    
    //#line 143 "x10/lang/Clock.x10"
    public void advance() {
        
        //#line 144 "x10/lang/Clock.x10"
        final x10.lang.Clock this$131646 = ((x10.lang.Clock)(this));
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$131734 = this$131646.registered$O();
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$131735 = !(t$131734);
        
        //#line 144 "x10/lang/Clock.x10"
        if (t$131735) {
            
            //#line 144 "x10/lang/Clock.x10"
            this.clockUseException(((java.lang.String)("advance")));
        }
        
        //#line 145 "x10/lang/Clock.x10"
        this.advanceUnsafe();
    }
    
    
    //#line 147 "x10/lang/Clock.x10"
    public void drop() {
        
        //#line 148 "x10/lang/Clock.x10"
        final x10.lang.Clock this$131648 = ((x10.lang.Clock)(this));
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$131736 = this$131648.registered$O();
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$131737 = !(t$131736);
        
        //#line 148 "x10/lang/Clock.x10"
        if (t$131737) {
            
            //#line 148 "x10/lang/Clock.x10"
            this.clockUseException(((java.lang.String)("drop")));
        }
        
        //#line 149 "x10/lang/Clock.x10"
        this.dropUnsafe();
    }
    
    
    //#line 152 "x10/lang/Clock.x10"
    public java.lang.String toString() {
        
        //#line 152 "x10/lang/Clock.x10"
        final java.lang.String t$131738 = ((java.lang.String)(this.name));
        
        //#line 152 "x10/lang/Clock.x10"
        final boolean t$131739 = (t$131738).equals("");
        
        //#line 152 "x10/lang/Clock.x10"
        java.lang.String t$131740 =  null;
        
        //#line 152 "x10/lang/Clock.x10"
        if (t$131739) {
            
            //#line 152 "x10/lang/Clock.x10"
            t$131740 = x10.lang.System.identityToString(((java.lang.Object)(this)));
        } else {
            
            //#line 152 "x10/lang/Clock.x10"
            t$131740 = this.name;
        }
        
        //#line 152 "x10/lang/Clock.x10"
        return t$131740;
    }
    
    
    //#line 154 "x10/lang/Clock.x10"
    private void clockUseException(final java.lang.String method) {
        
        //#line 155 "x10/lang/Clock.x10"
        final x10.lang.Clock this$131650 = ((x10.lang.Clock)(this));
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$131742 = this$131650.registered$O();
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$131749 = !(t$131742);
        
        //#line 155 "x10/lang/Clock.x10"
        if (t$131749) {
            
            //#line 155 "x10/lang/Clock.x10"
            final java.lang.String t$131743 = (("invalid invocation of ") + (method));
            
            //#line 155 "x10/lang/Clock.x10"
            final java.lang.String t$131744 = ((t$131743) + ("() on clock "));
            
            //#line 155 "x10/lang/Clock.x10"
            final java.lang.String t$131745 = this.toString();
            
            //#line 155 "x10/lang/Clock.x10"
            final java.lang.String t$131746 = ((t$131744) + (t$131745));
            
            //#line 155 "x10/lang/Clock.x10"
            final java.lang.String t$131747 = ((t$131746) + ("; calling activity is not clocked on this clock"));
            
            //#line 155 "x10/lang/Clock.x10"
            final x10.lang.ClockUseException t$131748 = ((x10.lang.ClockUseException)(new x10.lang.ClockUseException(t$131747)));
            
            //#line 155 "x10/lang/Clock.x10"
            throw t$131748;
        }
    }
    
    public static void clockUseException$P(final java.lang.String method, final x10.lang.Clock Clock) {
        Clock.clockUseException(((java.lang.String)(method)));
    }
    
    
    //#line 158 "x10/lang/Clock.x10"
    public static void advanceAll() {
        
        //#line 160 "x10/lang/Clock.x10"
        x10.xrx.Runtime.ensureNotInAtomic();
        
        //#line 161 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$131750 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 161 "x10/lang/Clock.x10"
        t$131750.advanceAll();
    }
    
    
    //#line 164 "x10/lang/Clock.x10"
    public static void resumeAll() {
        
        //#line 164 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$131751 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 164 "x10/lang/Clock.x10"
        t$131751.resumeAll();
    }
    
    
    //#line 166 "x10/lang/Clock.x10"
    private static x10.lang.Clock.ClockPhases getClockPhases() {
        try {
            return x10.xrx.Runtime.activity().clockPhases();
        }
        catch (java.lang.Throwable exc$205576) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205576);
        }
        
    }
    
    
    public static x10.lang.Clock.ClockPhases getClockPhases$P() {
        return x10.xrx.Runtime.activity().clockPhases();
    }
    
    
    //#line 178 "x10/lang/Clock.x10"
    /**
     * Specialization of HashMap to maintain the set of Clocks that
     * an Activity is currently registered on.
     * This type is public and many of its methods are public so it can be 
     * manipulated from the XRX runtime, but there is intentionally no accessible 
     * API that allows user-code to actually get the active instance 
     * of a ClockPhase for an Activity
     */
    @x10.runtime.impl.java.X10Generated
    public static class ClockPhases extends x10.util.HashMap<x10.lang.Clock, x10.core.Int> implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<ClockPhases> $RTT = 
            x10.rtt.NamedType.<ClockPhases> make("x10.lang.Clock.ClockPhases",
                                                 ClockPhases.class,
                                                 new x10.rtt.Type[] {
                                                     x10.rtt.ParameterizedType.make(x10.util.HashMap.$RTT, x10.lang.Clock.$RTT, x10.rtt.Types.INT)
                                                 });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        // custom serialization support
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock.ClockPhases $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Deserializer $ds = new x10.io.Deserializer($deserializer);
            $_obj.x10$lang$Clock$ClockPhases$$init$S($ds);
            short $marker = $deserializer.readSerializationId();
            if ($marker != x10.serialization.SerializationConstants.CUSTOM_SERIALIZATION_END) { x10.serialization.X10JavaDeserializer.raiseSerializationProtocolError(); }
            return $_obj;
            
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            int $obj_id = $deserializer.record_reference(null); /* Get id eagerly so that ordering in object map is stable (needed for repeated reference mechanism) */
            ClockPhases $_obj = new ClockPhases((java.lang.System[]) null);
            $deserializer.update_reference($obj_id, $_obj); /* Update entry in object map with the actual object before deserializing body */
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
            serialize(new x10.io.Serializer($serializer)); 
            $serializer.writeSerializationId(x10.serialization.SerializationConstants.CUSTOM_SERIALIZATION_END);
            
        }
        
        // constructor just for allocation
        public ClockPhases(final java.lang.System[] $dummy) {
            super($dummy, x10.lang.Clock.$RTT, x10.rtt.Types.INT);
            
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].operator()(k:K){}:V
        public int $apply$O(x10.lang.Clock a1){
            return x10.core.Int.$unbox(super.$apply__0x10$util$HashMap$$K$G((a1)));
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].get(k:K){}:V
        public int get$O(x10.lang.Clock a1){
            return x10.core.Int.$unbox(super.get__0x10$util$HashMap$$K$G((a1)));
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].getOrElse(k:K, orelse:V){}:V
        public int getOrElse$O(x10.lang.Clock a1, int a2){
            return x10.core.Int.$unbox(super.getOrElse__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G((a1), x10.core.Int.$box(a2)));
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].getOrThrow(k:K){}:V
        public int getOrThrow$O(x10.lang.Clock a1){
            return x10.core.Int.$unbox(super.getOrThrow__0x10$util$HashMap$$K$G((a1)));
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].operator()=(k:K, v:V){}:V
        public int $set$O(x10.lang.Clock a1, int a2){
            return x10.core.Int.$unbox(super.$set__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G((a1), x10.core.Int.$box(a2)));
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].put(k:K, v:V){}:V
        public int put$O(x10.lang.Clock a1, int a2){
            return x10.core.Int.$unbox(super.put__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G((a1), x10.core.Int.$box(a2)));
        }
        
        // bridge for inherited method final protected x10.util.HashMap[K, V].putInternal(k:K, v:V, mayRehash:x10.lang.Boolean){}:V
        final protected int putInternal$O(x10.lang.Clock a1, int a2, boolean a3){
            return x10.core.Int.$unbox(super.putInternal__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G((a1), x10.core.Int.$box(a2), (a3)));
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].remove(k:K){}:V
        public int remove$O(x10.lang.Clock a1){
            return x10.core.Int.$unbox(super.remove__0x10$util$HashMap$$K$G((a1)));
        }
        
        
    
        
        
        //#line 181 "x10/lang/Clock.x10"
        public static x10.lang.Clock.ClockPhases make__0$1x10$lang$Clock$2(final x10.core.Rail<x10.lang.Clock> clocks) {
            
            //#line 182 "x10/lang/Clock.x10"
            final x10.lang.Clock.ClockPhases clockPhases = ((x10.lang.Clock.ClockPhases)(new x10.lang.Clock.ClockPhases((java.lang.System[]) null)));
            
            //#line 182 "x10/lang/Clock.x10"
            clockPhases.x10$lang$Clock$ClockPhases$$init$S();
            
            //#line 183 "x10/lang/Clock.x10"
            long i$131787 = 0L;
            {
                
                //#line 183 "x10/lang/Clock.x10"
                final x10.lang.Clock[] clocks$value$131830 = ((x10.lang.Clock[])clocks.value);
                
                //#line 183 "x10/lang/Clock.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 183 "x10/lang/Clock.x10"
                    final long t$131789 = ((x10.core.Rail<x10.lang.Clock>)clocks).size;
                    
                    //#line 183 "x10/lang/Clock.x10"
                    final boolean t$131790 = ((i$131787) < (((long)(t$131789))));
                    
                    //#line 183 "x10/lang/Clock.x10"
                    if (!(t$131790)) {
                        
                        //#line 183 "x10/lang/Clock.x10"
                        break;
                    }
                    
                    //#line 184 "x10/lang/Clock.x10"
                    final x10.lang.Clock t$131781 = ((x10.lang.Clock)clocks$value$131830[(int)i$131787]);
                    
                    //#line 184 "x10/lang/Clock.x10"
                    final x10.lang.Clock t$131783 = ((x10.lang.Clock)clocks$value$131830[(int)i$131787]);
                    
                    //#line 184 "x10/lang/Clock.x10"
                    final int t$131784 = t$131783.register$O();
                    
                    //#line 184 "x10/lang/Clock.x10"
                    ((x10.util.HashMap<x10.lang.Clock, x10.core.Int>)clockPhases).put__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G(((x10.lang.Clock)(t$131781)), x10.core.Int.$box(t$131784));
                    
                    //#line 183 "x10/lang/Clock.x10"
                    final long t$131786 = ((i$131787) + (((long)(1L))));
                    
                    //#line 183 "x10/lang/Clock.x10"
                    i$131787 = t$131786;
                }
            }
            
            //#line 185 "x10/lang/Clock.x10"
            return clockPhases;
        }
        
        
        //#line 188 "x10/lang/Clock.x10"
        public static x10.lang.Clock.ClockPhases make() {
            
            //#line 188 "x10/lang/Clock.x10"
            final x10.lang.Clock.ClockPhases alloc$131276 = ((x10.lang.Clock.ClockPhases)(new x10.lang.Clock.ClockPhases((java.lang.System[]) null)));
            
            //#line 188 "x10/lang/Clock.x10"
            alloc$131276.x10$lang$Clock$ClockPhases$$init$S();
            
            //#line 188 "x10/lang/Clock.x10"
            return alloc$131276;
        }
        
        
        //#line 191 "x10/lang/Clock.x10"
        public void advanceAll() {
            
            //#line 192 "x10/lang/Clock.x10"
            final x10.util.Set t$131795 = this.entries();
            
            //#line 192 "x10/lang/Clock.x10"
            final x10.lang.Iterator entry$131796 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)
                                                     ((x10.lang.Iterable<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)t$131795).iterator());
            
            //#line 192 "x10/lang/Clock.x10"
            for (;
                 true;
                 ) {
                
                //#line 192 "x10/lang/Clock.x10"
                final boolean t$131797 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$131796).hasNext$O();
                
                //#line 192 "x10/lang/Clock.x10"
                if (!(t$131797)) {
                    
                    //#line 192 "x10/lang/Clock.x10"
                    break;
                }
                
                //#line 192 "x10/lang/Clock.x10"
                final x10.util.Map.Entry entry$131791 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$131796).next$G();
                
                //#line 192 "x10/lang/Clock.x10"
                final x10.lang.Clock t$131792 = ((x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>)entry$131791).getKey$G();
                
                //#line 192 "x10/lang/Clock.x10"
                t$131792.resumeUnsafe();
            }
            
            //#line 193 "x10/lang/Clock.x10"
            final x10.util.Set t$131798 = this.entries();
            
            //#line 193 "x10/lang/Clock.x10"
            final x10.lang.Iterator entry$131799 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)
                                                     ((x10.lang.Iterable<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)t$131798).iterator());
            
            //#line 193 "x10/lang/Clock.x10"
            for (;
                 true;
                 ) {
                
                //#line 193 "x10/lang/Clock.x10"
                final boolean t$131800 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$131799).hasNext$O();
                
                //#line 193 "x10/lang/Clock.x10"
                if (!(t$131800)) {
                    
                    //#line 193 "x10/lang/Clock.x10"
                    break;
                }
                
                //#line 193 "x10/lang/Clock.x10"
                final x10.util.Map.Entry entry$131793 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$131799).next$G();
                
                //#line 193 "x10/lang/Clock.x10"
                final x10.lang.Clock t$131794 = ((x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>)entry$131793).getKey$G();
                
                //#line 193 "x10/lang/Clock.x10"
                t$131794.advanceUnsafe();
            }
        }
        
        
        //#line 197 "x10/lang/Clock.x10"
        public void resumeAll() {
            
            //#line 198 "x10/lang/Clock.x10"
            final x10.util.Set t$131772 = this.entries();
            
            //#line 198 "x10/lang/Clock.x10"
            final x10.lang.Iterator entry$131282 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)
                                                     ((x10.lang.Iterable<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)t$131772).iterator());
            
            //#line 198 "x10/lang/Clock.x10"
            for (;
                 true;
                 ) {
                
                //#line 198 "x10/lang/Clock.x10"
                final boolean t$131774 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$131282).hasNext$O();
                
                //#line 198 "x10/lang/Clock.x10"
                if (!(t$131774)) {
                    
                    //#line 198 "x10/lang/Clock.x10"
                    break;
                }
                
                //#line 198 "x10/lang/Clock.x10"
                final x10.util.Map.Entry entry$131801 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$131282).next$G();
                
                //#line 198 "x10/lang/Clock.x10"
                final x10.lang.Clock t$131802 = ((x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>)entry$131801).getKey$G();
                
                //#line 198 "x10/lang/Clock.x10"
                t$131802.resumeUnsafe();
            }
        }
        
        
        //#line 202 "x10/lang/Clock.x10"
        public void drop() {
            
            //#line 203 "x10/lang/Clock.x10"
            final x10.util.Set t$131805 = this.entries();
            
            //#line 203 "x10/lang/Clock.x10"
            final x10.lang.Iterator entry$131806 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)
                                                     ((x10.lang.Iterable<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)t$131805).iterator());
            
            //#line 203 "x10/lang/Clock.x10"
            for (;
                 true;
                 ) {
                
                //#line 203 "x10/lang/Clock.x10"
                final boolean t$131807 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$131806).hasNext$O();
                
                //#line 203 "x10/lang/Clock.x10"
                if (!(t$131807)) {
                    
                    //#line 203 "x10/lang/Clock.x10"
                    break;
                }
                
                //#line 203 "x10/lang/Clock.x10"
                final x10.util.Map.Entry entry$131803 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$131806).next$G();
                
                //#line 203 "x10/lang/Clock.x10"
                final x10.lang.Clock t$131804 = ((x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>)entry$131803).getKey$G();
                
                //#line 203 "x10/lang/Clock.x10"
                t$131804.dropInternal();
            }
            
            //#line 204 "x10/lang/Clock.x10"
            this.clear();
        }
        
        
        //#line 208 "x10/lang/Clock.x10"
        public void serialize(final x10.io.Serializer s) {
            
            //#line 209 "x10/lang/Clock.x10"
            super.serialize(((x10.io.Serializer)(s)));
        }
        
        
        //#line 211 "x10/lang/Clock.x10"
        // creation method for java code (1-phase java constructor)
        public ClockPhases() {
            this((java.lang.System[]) null);
            x10$lang$Clock$ClockPhases$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.lang.Clock.ClockPhases x10$lang$Clock$ClockPhases$$init$S() {
             {
                
                //#line 211 "x10/lang/Clock.x10"
                /*super.*/x10$util$HashMap$$init$S();
                
                //#line 211 "x10/lang/Clock.x10"
                
            }
            return this;
        }
        
        
        
        //#line 212 "x10/lang/Clock.x10"
        // creation method for java code (1-phase java constructor)
        public ClockPhases(final x10.io.Deserializer ds) {
            this((java.lang.System[]) null);
            x10$lang$Clock$ClockPhases$$init$S(ds);
        }
        
        // constructor for non-virtual call
        final public x10.lang.Clock.ClockPhases x10$lang$Clock$ClockPhases$$init$S(final x10.io.Deserializer ds) {
            x10$lang$Clock$ClockPhases$$initForReflection(ds);
            
            return this;
        }
        
        public void x10$lang$Clock$ClockPhases$$initForReflection(x10.io.Deserializer ds) {
             {
                
                //#line 213 "x10/lang/Clock.x10"
                /*super.*/x10$util$HashMap$$init$S(((x10.io.Deserializer)(ds)));
                
                //#line 212 "x10/lang/Clock.x10"
                
            }
        }
        
        
        
        //#line 178 "x10/lang/Clock.x10"
        final public x10.lang.Clock.ClockPhases x10$lang$Clock$ClockPhases$$this$x10$lang$Clock$ClockPhases() {
            
            //#line 178 "x10/lang/Clock.x10"
            return x10.lang.Clock.ClockPhases.this;
        }
        
        
        //#line 178 "x10/lang/Clock.x10"
        final public void __fieldInitializers_x10_lang_Clock_ClockPhases() {
            
        }
        
        public void x10$util$HashMap$serialize$S(final x10.io.Serializer a0) {
            super.serialize(((x10.io.Serializer)(a0)));
        }
    }
    
    
    
    //#line 32 "x10/lang/Clock.x10"
    final public x10.lang.Clock x10$lang$Clock$$this$x10$lang$Clock() {
        
        //#line 32 "x10/lang/Clock.x10"
        return x10.lang.Clock.this;
    }
    
    
    //#line 32 "x10/lang/Clock.x10"
    final public void __fieldInitializers_x10_lang_Clock() {
        
        //#line 33 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$131779 = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.lang.Clock>(x10.lang.Clock.$RTT, ((x10.lang.Clock)(this)), (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
        
        //#line 32 "x10/lang/Clock.x10"
        this.root = ((x10.core.GlobalRef)(t$131779));
        
        //#line 32 "x10/lang/Clock.x10"
        this.count = 1;
        
        //#line 32 "x10/lang/Clock.x10"
        this.alive = 1;
        
        //#line 32 "x10/lang/Clock.x10"
        this.phase = 1;
    }
    
    public static int get$FIRST_PHASE() {
        return x10.lang.Clock.FIRST_PHASE;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$103 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$103> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$103> make($Closure$103.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock.$Closure$103 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.ph = $deserializer.readInt();
            $_obj.root = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Clock.$Closure$103 $_obj = new x10.lang.Clock.$Closure$103((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.ph);
            $serializer.write(this.root);
            
        }
        
        // constructor just for allocation
        public $Closure$103(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Clock$2 {}
        
    
        
        public void $apply() {
            
            //#line 88 "x10/lang/Clock.x10"
            try {{
                
                //#line 89 "x10/lang/Clock.x10"
                final x10.core.GlobalRef t$131697 = ((x10.core.GlobalRef)(this.root));
                
                //#line 89 "x10/lang/Clock.x10"
                final x10.lang.Clock me = (((x10.core.GlobalRef<x10.lang.Clock>)(t$131697))).$apply$G();
                
                //#line 90 "x10/lang/Clock.x10"
                try {{
                    
                    //#line 90 "x10/lang/Clock.x10"
                    x10.xrx.Runtime.enterAtomic();
                    {
                        
                        //#line 91 "x10/lang/Clock.x10"
                        final int t$131698 = me.count;
                        
                        //#line 91 "x10/lang/Clock.x10"
                        final int t$131699 = ((t$131698) + (((int)(1))));
                        
                        //#line 91 "x10/lang/Clock.x10"
                        me.count = t$131699;
                        
                        //#line 92 "x10/lang/Clock.x10"
                        final int t$131700 = (-(this.ph));
                        
                        //#line 92 "x10/lang/Clock.x10"
                        final int t$131701 = me.phase;
                        
                        //#line 92 "x10/lang/Clock.x10"
                        final boolean t$131704 = ((int) t$131700) != ((int) t$131701);
                        
                        //#line 92 "x10/lang/Clock.x10"
                        if (t$131704) {
                            
                            //#line 93 "x10/lang/Clock.x10"
                            final int t$131702 = me.alive;
                            
                            //#line 93 "x10/lang/Clock.x10"
                            final int t$131703 = ((t$131702) + (((int)(1))));
                            
                            //#line 93 "x10/lang/Clock.x10"
                            me.alive = t$131703;
                        }
                    }
                }}finally {{
                      
                      //#line 90 "x10/lang/Clock.x10"
                      x10.xrx.Runtime.exitAtomic();
                  }}
                }}catch (java.lang.Throwable __lowerer__var__0__) {
                    
                    //#line 88 "x10/lang/Clock.x10"
                    int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
                }
            }
        
        public x10.lang.Clock out$$;
        public x10.core.GlobalRef<x10.lang.Clock> root;
        public int ph;
        
        public $Closure$103(final x10.lang.Clock out$$, final x10.core.GlobalRef<x10.lang.Clock> root, final int ph, __1$1x10$lang$Clock$2 $dummy) {
             {
                this.out$$ = out$$;
                this.root = ((x10.core.GlobalRef)(root));
                this.ph = ph;
            }
        }
        
        }
        
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$104 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$104> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$104> make($Closure$104.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock.$Closure$104 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.root = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Clock.$Closure$104 $_obj = new x10.lang.Clock.$Closure$104((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.root);
            
        }
        
        // constructor just for allocation
        public $Closure$104(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Clock$2 {}
        
    
        
        public void $apply() {
            
            //#line 102 "x10/lang/Clock.x10"
            try {{
                
                //#line 103 "x10/lang/Clock.x10"
                final x10.core.GlobalRef t$131709 = ((x10.core.GlobalRef)(this.root));
                
                //#line 103 "x10/lang/Clock.x10"
                final x10.lang.Clock me = (((x10.core.GlobalRef<x10.lang.Clock>)(t$131709))).$apply$G();
                
                //#line 104 "x10/lang/Clock.x10"
                me.resumeLocal();
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 102 "x10/lang/Clock.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.Clock out$$;
        public x10.core.GlobalRef<x10.lang.Clock> root;
        
        public $Closure$104(final x10.lang.Clock out$$, final x10.core.GlobalRef<x10.lang.Clock> root, __1$1x10$lang$Clock$2 $dummy) {
             {
                this.out$$ = out$$;
                this.root = ((x10.core.GlobalRef)(root));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$105 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$105> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$105> make($Closure$105.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock.$Closure$105 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.abs = $deserializer.readInt();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.ph = $deserializer.readInt();
            $_obj.root = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Clock.$Closure$105 $_obj = new x10.lang.Clock.$Closure$105((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.abs);
            $serializer.write(this.out$$);
            $serializer.write(this.ph);
            $serializer.write(this.root);
            
        }
        
        // constructor just for allocation
        public $Closure$105(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Clock$2 {}
        
    
        
        public void $apply() {
            
            //#line 112 "x10/lang/Clock.x10"
            try {{
                
                //#line 113 "x10/lang/Clock.x10"
                final x10.core.GlobalRef t$131713 = ((x10.core.GlobalRef)(this.root));
                
                //#line 113 "x10/lang/Clock.x10"
                final x10.lang.Clock me = (((x10.core.GlobalRef<x10.lang.Clock>)(t$131713))).$apply$G();
                
                //#line 114 "x10/lang/Clock.x10"
                final long t$131714 = ((long)(((int)(this.ph))));
                
                //#line 114 "x10/lang/Clock.x10"
                final boolean t$131715 = ((t$131714) > (((long)(0L))));
                
                //#line 114 "x10/lang/Clock.x10"
                if (t$131715) {
                    
                    //#line 114 "x10/lang/Clock.x10"
                    me.resumeLocal();
                }
                {
                    
                    //#line 115 "x10/lang/Clock.x10"
                    x10.xrx.Runtime.ensureNotInAtomic();
                    
                    //#line 115 "x10/lang/Clock.x10"
                    try {{
                        
                        //#line 115 "x10/lang/Clock.x10"
                        x10.xrx.Runtime.enterAtomic();
                        
                        //#line 115 "x10/lang/Clock.x10"
                        while (true) {
                            
                            //#line 115 "x10/lang/Clock.x10"
                            if (((this.abs) < (((int)(me.phase))))) {
                                {
                                    
                                }
                                
                                //#line 115 "x10/lang/Clock.x10"
                                break;
                            }
                            
                            //#line 115 "x10/lang/Clock.x10"
                            x10.xrx.Runtime.awaitAtomic();
                        }
                    }}finally {{
                          
                          //#line 115 "x10/lang/Clock.x10"
                          x10.xrx.Runtime.exitAtomic();
                      }}
                    }
                }}catch (java.lang.Throwable __lowerer__var__0__) {
                    
                    //#line 112 "x10/lang/Clock.x10"
                    int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
                }
            }
        
        public x10.lang.Clock out$$;
        public x10.core.GlobalRef<x10.lang.Clock> root;
        public int ph;
        public int abs;
        
        public $Closure$105(final x10.lang.Clock out$$, final x10.core.GlobalRef<x10.lang.Clock> root, final int ph, final int abs, __1$1x10$lang$Clock$2 $dummy) {
             {
                this.out$$ = out$$;
                this.root = ((x10.core.GlobalRef)(root));
                this.ph = ph;
                this.abs = abs;
            }
        }
        
        }
        
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$106 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$106> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$106> make($Closure$106.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock.$Closure$106 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.ph = $deserializer.readInt();
            $_obj.root = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Clock.$Closure$106 $_obj = new x10.lang.Clock.$Closure$106((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.ph);
            $serializer.write(this.root);
            
        }
        
        // constructor just for allocation
        public $Closure$106(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Clock$2 {}
        
    
        
        public void $apply() {
            
            //#line 121 "x10/lang/Clock.x10"
            try {{
                
                //#line 122 "x10/lang/Clock.x10"
                final x10.core.GlobalRef t$131719 = ((x10.core.GlobalRef)(this.root));
                
                //#line 122 "x10/lang/Clock.x10"
                final x10.lang.Clock me = (((x10.core.GlobalRef<x10.lang.Clock>)(t$131719))).$apply$G();
                
                //#line 123 "x10/lang/Clock.x10"
                me.dropLocal((int)(this.ph));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 121 "x10/lang/Clock.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.Clock out$$;
        public x10.core.GlobalRef<x10.lang.Clock> root;
        public int ph;
        
        public $Closure$106(final x10.lang.Clock out$$, final x10.core.GlobalRef<x10.lang.Clock> root, final int ph, __1$1x10$lang$Clock$2 $dummy) {
             {
                this.out$$ = out$$;
                this.root = ((x10.core.GlobalRef)(root));
                this.ph = ph;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$107 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$107> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$107> make($Closure$107.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock.$Closure$107 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.ph = $deserializer.readInt();
            $_obj.root = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Clock.$Closure$107 $_obj = new x10.lang.Clock.$Closure$107((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.ph);
            $serializer.write(this.root);
            
        }
        
        // constructor just for allocation
        public $Closure$107(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Clock$2 {}
        
    
        
        public void $apply() {
            
            //#line 128 "x10/lang/Clock.x10"
            try {{
                
                //#line 129 "x10/lang/Clock.x10"
                final x10.core.GlobalRef t$131722 = ((x10.core.GlobalRef)(this.root));
                
                //#line 129 "x10/lang/Clock.x10"
                final x10.lang.Clock me = (((x10.core.GlobalRef<x10.lang.Clock>)(t$131722))).$apply$G();
                
                //#line 130 "x10/lang/Clock.x10"
                me.dropLocal((int)(this.ph));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 128 "x10/lang/Clock.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.Clock out$$;
        public x10.core.GlobalRef<x10.lang.Clock> root;
        public int ph;
        
        public $Closure$107(final x10.lang.Clock out$$, final x10.core.GlobalRef<x10.lang.Clock> root, final int ph, __1$1x10$lang$Clock$2 $dummy) {
             {
                this.out$$ = out$$;
                this.root = ((x10.core.GlobalRef)(root));
                this.ph = ph;
            }
        }
        
    }
    
    }
    
    