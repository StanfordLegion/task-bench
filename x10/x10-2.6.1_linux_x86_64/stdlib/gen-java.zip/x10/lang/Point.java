package x10.lang;


/**
 * The type <code>Point(rank)</code> represents a point in a
 * rank-dimensional space. The coordinates of a point <code>p</code>
 * may be accessed individually (with zero-based indexing) using
 * <code>p(i)</code> because <code>Point</code> implements
 * <code>(Long)=>Long</code>.
 * Point arithmetic is supported.
 */
@x10.runtime.impl.java.X10Generated
final public class Point extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.util.Ordered, java.lang.Comparable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Point> $RTT = 
        x10.rtt.NamedType.<Point> make("x10.lang.Point",
                                       Point.class,
                                       new x10.rtt.Type[] {
                                           x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG),
                                           x10.rtt.ParameterizedType.make(x10.util.Ordered.$RTT, x10.rtt.UnresolvedType.THIS),
                                           x10.rtt.ParameterizedType.make(x10.rtt.Types.COMPARABLE, x10.rtt.UnresolvedType.THIS)
                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.c0 = $deserializer.readLong();
        $_obj.c1 = $deserializer.readLong();
        $_obj.c2 = $deserializer.readLong();
        $_obj.c3 = $deserializer.readLong();
        $_obj.cs = $deserializer.readObject();
        $_obj.rank = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.Point $_obj = new x10.lang.Point((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.c0);
        $serializer.write(this.c1);
        $serializer.write(this.c2);
        $serializer.write(this.c3);
        $serializer.write(this.cs);
        $serializer.write(this.rank);
        
    }
    
    // constructor just for allocation
    public Point(final java.lang.System[] $dummy) {
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $apply$O(x10.core.Long.$unbox(a1));
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator<(that:T){}:x10.lang.Boolean
    public java.lang.Object $lt(final java.lang.Object a1, final x10.rtt.Type t1) {
        return x10.core.Boolean.$box($lt$O((x10.lang.Point)a1));
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator<(that:T){}:x10.lang.Boolean
    public boolean $lt$Z(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $lt$O((x10.lang.Point)a1);
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator>(that:T){}:x10.lang.Boolean
    public java.lang.Object $gt(final java.lang.Object a1, final x10.rtt.Type t1) {
        return x10.core.Boolean.$box($gt$O((x10.lang.Point)a1));
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator>(that:T){}:x10.lang.Boolean
    public boolean $gt$Z(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $gt$O((x10.lang.Point)a1);
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator<=(that:T){}:x10.lang.Boolean
    public java.lang.Object $le(final java.lang.Object a1, final x10.rtt.Type t1) {
        return x10.core.Boolean.$box($le$O((x10.lang.Point)a1));
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator<=(that:T){}:x10.lang.Boolean
    public boolean $le$Z(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $le$O((x10.lang.Point)a1);
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator>=(that:T){}:x10.lang.Boolean
    public java.lang.Object $ge(final java.lang.Object a1, final x10.rtt.Type t1) {
        return x10.core.Boolean.$box($ge$O((x10.lang.Point)a1));
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator>=(that:T){}:x10.lang.Boolean
    public boolean $ge$Z(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $ge$O((x10.lang.Point)a1);
        
    }
    
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$Long$2 {}
    
    // properties
    
    //#line 24 "x10/lang/Point.x10"
    public long rank;
    

    
    //#line 27 "x10/lang/Point.x10"
    public long c0;
    
    //#line 28 "x10/lang/Point.x10"
    public long c1;
    
    //#line 29 "x10/lang/Point.x10"
    public long c2;
    
    //#line 30 "x10/lang/Point.x10"
    public long c3;
    
    //#line 31 "x10/lang/Point.x10"
    public x10.core.Rail<x10.core.Long> cs;
    
    
    //#line 33 "x10/lang/Point.x10"
    // creation method for java code (1-phase java constructor)
    public Point(final x10.core.Rail<x10.core.Long> coords, __0$1x10$lang$Long$2 $dummy) {
        this((java.lang.System[]) null);
        x10$lang$Point$$init$S(coords, (x10.lang.Point.__0$1x10$lang$Long$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Point x10$lang$Point$$init$S(final x10.core.Rail<x10.core.Long> coords, __0$1x10$lang$Long$2 $dummy) {
         {
            
            //#line 34 "x10/lang/Point.x10"
            final long t$135374 = ((x10.core.Rail<x10.core.Long>)coords).size;
            
            //#line 34 "x10/lang/Point.x10"
            this.rank = t$135374;
            
            
            //#line 36 "x10/lang/Point.x10"
            final long t$135014 = ((long[])coords.value)[(int)0L];
            
            //#line 36 "x10/lang/Point.x10"
            this.c0 = t$135014;
            
            //#line 37 "x10/lang/Point.x10"
            final long t$135015 = this.rank;
            
            //#line 37 "x10/lang/Point.x10"
            final boolean t$135016 = ((t$135015) > (((long)(1L))));
            
            //#line 37 "x10/lang/Point.x10"
            long t$135017 =  0;
            
            //#line 37 "x10/lang/Point.x10"
            if (t$135016) {
                
                //#line 37 "x10/lang/Point.x10"
                t$135017 = ((long[])coords.value)[(int)1L];
            } else {
                
                //#line 37 "x10/lang/Point.x10"
                t$135017 = 0L;
            }
            
            //#line 37 "x10/lang/Point.x10"
            this.c1 = t$135017;
            
            //#line 38 "x10/lang/Point.x10"
            final long t$135019 = this.rank;
            
            //#line 38 "x10/lang/Point.x10"
            final boolean t$135020 = ((t$135019) > (((long)(2L))));
            
            //#line 38 "x10/lang/Point.x10"
            long t$135021 =  0;
            
            //#line 38 "x10/lang/Point.x10"
            if (t$135020) {
                
                //#line 38 "x10/lang/Point.x10"
                t$135021 = ((long[])coords.value)[(int)2L];
            } else {
                
                //#line 38 "x10/lang/Point.x10"
                t$135021 = 0L;
            }
            
            //#line 38 "x10/lang/Point.x10"
            this.c2 = t$135021;
            
            //#line 39 "x10/lang/Point.x10"
            final long t$135023 = this.rank;
            
            //#line 39 "x10/lang/Point.x10"
            final boolean t$135024 = ((t$135023) > (((long)(3L))));
            
            //#line 39 "x10/lang/Point.x10"
            long t$135025 =  0;
            
            //#line 39 "x10/lang/Point.x10"
            if (t$135024) {
                
                //#line 39 "x10/lang/Point.x10"
                t$135025 = ((long[])coords.value)[(int)3L];
            } else {
                
                //#line 39 "x10/lang/Point.x10"
                t$135025 = 0L;
            }
            
            //#line 39 "x10/lang/Point.x10"
            this.c3 = t$135025;
            
            //#line 40 "x10/lang/Point.x10"
            final long t$135027 = this.rank;
            
            //#line 40 "x10/lang/Point.x10"
            final boolean t$135028 = ((t$135027) > (((long)(4L))));
            
            //#line 40 "x10/lang/Point.x10"
            x10.core.Rail t$135029 =  null;
            
            //#line 40 "x10/lang/Point.x10"
            if (t$135028) {
                
                //#line 40 "x10/lang/Point.x10"
                t$135029 = ((x10.core.Rail)(coords));
            } else {
                
                //#line 40 "x10/lang/Point.x10"
                t$135029 = null;
            }
            
            //#line 40 "x10/lang/Point.x10"
            this.cs = ((x10.core.Rail)(t$135029));
        }
        return this;
    }
    
    
    
    //#line 43 "x10/lang/Point.x10"
    // creation method for java code (1-phase java constructor)
    public Point(final long i0) {
        this((java.lang.System[]) null);
        x10$lang$Point$$init$S(i0);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Point x10$lang$Point$$init$S(final long i0) {
         {
            
            //#line 44 "x10/lang/Point.x10"
            this.rank = 1L;
            
            
            //#line 45 "x10/lang/Point.x10"
            this.c0 = i0;
            
            //#line 46 "x10/lang/Point.x10"
            final long t$135031 = this.c3 = 0L;
            
            //#line 46 "x10/lang/Point.x10"
            final long t$135032 = this.c2 = t$135031;
            
            //#line 46 "x10/lang/Point.x10"
            this.c1 = t$135032;
            
            //#line 47 "x10/lang/Point.x10"
            this.cs = null;
        }
        return this;
    }
    
    
    
    //#line 50 "x10/lang/Point.x10"
    // creation method for java code (1-phase java constructor)
    public Point(final long i0, final long i1) {
        this((java.lang.System[]) null);
        x10$lang$Point$$init$S(i0, i1);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Point x10$lang$Point$$init$S(final long i0, final long i1) {
         {
            
            //#line 51 "x10/lang/Point.x10"
            this.rank = 2L;
            
            
            //#line 52 "x10/lang/Point.x10"
            this.c0 = i0;
            
            //#line 53 "x10/lang/Point.x10"
            this.c1 = i1;
            
            //#line 54 "x10/lang/Point.x10"
            final long t$135033 = this.c3 = 0L;
            
            //#line 54 "x10/lang/Point.x10"
            this.c2 = t$135033;
            
            //#line 55 "x10/lang/Point.x10"
            this.cs = null;
        }
        return this;
    }
    
    
    
    //#line 58 "x10/lang/Point.x10"
    // creation method for java code (1-phase java constructor)
    public Point(final long i0, final long i1, final long i2) {
        this((java.lang.System[]) null);
        x10$lang$Point$$init$S(i0, i1, i2);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Point x10$lang$Point$$init$S(final long i0, final long i1, final long i2) {
         {
            
            //#line 59 "x10/lang/Point.x10"
            this.rank = 3L;
            
            
            //#line 60 "x10/lang/Point.x10"
            this.c0 = i0;
            
            //#line 61 "x10/lang/Point.x10"
            this.c1 = i1;
            
            //#line 62 "x10/lang/Point.x10"
            this.c2 = i2;
            
            //#line 63 "x10/lang/Point.x10"
            this.c3 = 0L;
            
            //#line 64 "x10/lang/Point.x10"
            this.cs = null;
        }
        return this;
    }
    
    
    
    //#line 67 "x10/lang/Point.x10"
    // creation method for java code (1-phase java constructor)
    public Point(final long i0, final long i1, final long i2, final long i3) {
        this((java.lang.System[]) null);
        x10$lang$Point$$init$S(i0, i1, i2, i3);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Point x10$lang$Point$$init$S(final long i0, final long i1, final long i2, final long i3) {
         {
            
            //#line 68 "x10/lang/Point.x10"
            this.rank = 4L;
            
            
            //#line 69 "x10/lang/Point.x10"
            this.c0 = i0;
            
            //#line 70 "x10/lang/Point.x10"
            this.c1 = i1;
            
            //#line 71 "x10/lang/Point.x10"
            this.c2 = i2;
            
            //#line 72 "x10/lang/Point.x10"
            this.c3 = i3;
            
            //#line 73 "x10/lang/Point.x10"
            this.cs = null;
        }
        return this;
    }
    
    
    
    //#line 80 "x10/lang/Point.x10"
    /**
     * Returns the value of the ith coordinate.
     */
    public long $apply$O(final long i) {
        
        //#line 81 "x10/lang/Point.x10"
        boolean t$135035 = ((i) < (((long)(0L))));
        
        //#line 81 "x10/lang/Point.x10"
        if (!(t$135035)) {
            
            //#line 81 "x10/lang/Point.x10"
            final long t$135034 = this.rank;
            
            //#line 81 "x10/lang/Point.x10"
            t$135035 = ((i) >= (((long)(t$135034))));
        }
        
        //#line 81 "x10/lang/Point.x10"
        if (t$135035) {
            
            //#line 81 "x10/lang/Point.x10"
            final java.lang.String t$135036 = (("index ") + ((x10.core.Long.$box(i))));
            
            //#line 81 "x10/lang/Point.x10"
            final java.lang.String t$135037 = ((t$135036) + (" not contained in "));
            
            //#line 81 "x10/lang/Point.x10"
            final java.lang.String t$135038 = ((t$135037) + (this));
            
            //#line 81 "x10/lang/Point.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$135039 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$135038)));
            
            //#line 81 "x10/lang/Point.x10"
            throw t$135039;
        }
        
        //#line 82 "x10/lang/Point.x10"
        final boolean t$135042 = ((long) i) == ((long) 0L);
        
        //#line 82 "x10/lang/Point.x10"
        if (t$135042) {
            
            //#line 82 "x10/lang/Point.x10"
            final long t$135041 = this.c0;
            
            //#line 82 "x10/lang/Point.x10"
            return t$135041;
        }
        
        //#line 83 "x10/lang/Point.x10"
        final boolean t$135044 = ((long) i) == ((long) 1L);
        
        //#line 83 "x10/lang/Point.x10"
        if (t$135044) {
            
            //#line 83 "x10/lang/Point.x10"
            final long t$135043 = this.c1;
            
            //#line 83 "x10/lang/Point.x10"
            return t$135043;
        }
        
        //#line 84 "x10/lang/Point.x10"
        final boolean t$135046 = ((long) i) == ((long) 2L);
        
        //#line 84 "x10/lang/Point.x10"
        if (t$135046) {
            
            //#line 84 "x10/lang/Point.x10"
            final long t$135045 = this.c2;
            
            //#line 84 "x10/lang/Point.x10"
            return t$135045;
        }
        
        //#line 85 "x10/lang/Point.x10"
        final boolean t$135048 = ((long) i) == ((long) 3L);
        
        //#line 85 "x10/lang/Point.x10"
        if (t$135048) {
            
            //#line 85 "x10/lang/Point.x10"
            final long t$135047 = this.c3;
            
            //#line 85 "x10/lang/Point.x10"
            return t$135047;
        }
        
        //#line 86 "x10/lang/Point.x10"
        final x10.core.Rail t$135049 = ((x10.core.Rail)(this.cs));
        
        //#line 86 "x10/lang/Point.x10"
        final long t$135050 = ((long[])t$135049.value)[(int)i];
        
        //#line 86 "x10/lang/Point.x10"
        return t$135050;
    }
    
    
    //#line 92 "x10/lang/Point.x10"
    /**
     * Returns the coordinates as a <code>(Long)=>Long</code>.
     */
    public x10.core.fun.Fun_0_1 coords() {
        
        //#line 92 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135052 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$139(this)));
        
        //#line 92 "x10/lang/Point.x10"
        return t$135052;
    }
    
    
    //#line 97 "x10/lang/Point.x10"
    /**
     * Constructs a Point from a Rail[Int]
     */
    public static x10.lang.Point make__0$1x10$lang$Int$2(final x10.core.Rail<x10.core.Int> r) {
        
        //#line 98 "x10/lang/Point.x10"
        final long t$135053 = ((x10.core.Rail<x10.core.Int>)r).size;
        
        //#line 98 "x10/lang/Point.x10"
        final boolean t$135105 = ((long) t$135053) == ((long) 1L);
        
        //#line 98 "x10/lang/Point.x10"
        if (t$135105) {
            
            //#line 99 "x10/lang/Point.x10"
            final x10.lang.Point alloc$98055 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 99 "x10/lang/Point.x10"
            final int t$135380 = ((int[])r.value)[(int)0L];
            
            //#line 99 "x10/lang/Point.x10"
            final long t$135381 = ((long)(((int)(t$135380))));
            
            //#line 99 "x10/lang/Point.x10"
            alloc$98055.x10$lang$Point$$init$S(t$135381);
            
            //#line 99 "x10/lang/Point.x10"
            final x10.lang.Point t$97615 = ((x10.lang.Point)
                                             alloc$98055);
            
            //#line 99 "x10/lang/Point.x10"
            final long t$135056 = t$97615.rank;
            
            //#line 99 "x10/lang/Point.x10"
            final long t$135057 = ((x10.core.Rail<x10.core.Int>)r).size;
            
            //#line 99 "x10/lang/Point.x10"
            final boolean t$135058 = ((long) t$135056) == ((long) t$135057);
            
            //#line 99 "x10/lang/Point.x10"
            final boolean t$135060 = !(t$135058);
            
            //#line 99 "x10/lang/Point.x10"
            if (t$135060) {
                
                //#line 99 "x10/lang/Point.x10"
                final x10.lang.FailedDynamicCheckException t$135059 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                
                //#line 99 "x10/lang/Point.x10"
                throw t$135059;
            }
            
            //#line 99 "x10/lang/Point.x10"
            return t$97615;
        } else {
            
            //#line 100 "x10/lang/Point.x10"
            final long t$135061 = ((x10.core.Rail<x10.core.Int>)r).size;
            
            //#line 100 "x10/lang/Point.x10"
            final boolean t$135104 = ((long) t$135061) == ((long) 2L);
            
            //#line 100 "x10/lang/Point.x10"
            if (t$135104) {
                
                //#line 101 "x10/lang/Point.x10"
                final x10.lang.Point alloc$98056 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                
                //#line 101 "x10/lang/Point.x10"
                final int t$135382 = ((int[])r.value)[(int)0L];
                
                //#line 101 "x10/lang/Point.x10"
                final long t$135383 = ((long)(((int)(t$135382))));
                
                //#line 101 "x10/lang/Point.x10"
                final int t$135384 = ((int[])r.value)[(int)1L];
                
                //#line 101 "x10/lang/Point.x10"
                final long t$135385 = ((long)(((int)(t$135384))));
                
                //#line 101 "x10/lang/Point.x10"
                alloc$98056.x10$lang$Point$$init$S(t$135383, t$135385);
                
                //#line 101 "x10/lang/Point.x10"
                final x10.lang.Point t$97617 = ((x10.lang.Point)
                                                 alloc$98056);
                
                //#line 101 "x10/lang/Point.x10"
                final long t$135066 = t$97617.rank;
                
                //#line 101 "x10/lang/Point.x10"
                final long t$135067 = ((x10.core.Rail<x10.core.Int>)r).size;
                
                //#line 101 "x10/lang/Point.x10"
                final boolean t$135068 = ((long) t$135066) == ((long) t$135067);
                
                //#line 101 "x10/lang/Point.x10"
                final boolean t$135070 = !(t$135068);
                
                //#line 101 "x10/lang/Point.x10"
                if (t$135070) {
                    
                    //#line 101 "x10/lang/Point.x10"
                    final x10.lang.FailedDynamicCheckException t$135069 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                    
                    //#line 101 "x10/lang/Point.x10"
                    throw t$135069;
                }
                
                //#line 101 "x10/lang/Point.x10"
                return t$97617;
            } else {
                
                //#line 102 "x10/lang/Point.x10"
                final long t$135071 = ((x10.core.Rail<x10.core.Int>)r).size;
                
                //#line 102 "x10/lang/Point.x10"
                final boolean t$135103 = ((long) t$135071) == ((long) 3L);
                
                //#line 102 "x10/lang/Point.x10"
                if (t$135103) {
                    
                    //#line 103 "x10/lang/Point.x10"
                    final x10.lang.Point alloc$98057 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                    
                    //#line 103 "x10/lang/Point.x10"
                    final int t$135386 = ((int[])r.value)[(int)0L];
                    
                    //#line 103 "x10/lang/Point.x10"
                    final long t$135387 = ((long)(((int)(t$135386))));
                    
                    //#line 103 "x10/lang/Point.x10"
                    final int t$135388 = ((int[])r.value)[(int)1L];
                    
                    //#line 103 "x10/lang/Point.x10"
                    final long t$135389 = ((long)(((int)(t$135388))));
                    
                    //#line 103 "x10/lang/Point.x10"
                    final int t$135390 = ((int[])r.value)[(int)2L];
                    
                    //#line 103 "x10/lang/Point.x10"
                    final long t$135391 = ((long)(((int)(t$135390))));
                    
                    //#line 103 "x10/lang/Point.x10"
                    alloc$98057.x10$lang$Point$$init$S(t$135387, t$135389, t$135391);
                    
                    //#line 103 "x10/lang/Point.x10"
                    final x10.lang.Point t$97619 = ((x10.lang.Point)
                                                     alloc$98057);
                    
                    //#line 103 "x10/lang/Point.x10"
                    final long t$135078 = t$97619.rank;
                    
                    //#line 103 "x10/lang/Point.x10"
                    final long t$135079 = ((x10.core.Rail<x10.core.Int>)r).size;
                    
                    //#line 103 "x10/lang/Point.x10"
                    final boolean t$135080 = ((long) t$135078) == ((long) t$135079);
                    
                    //#line 103 "x10/lang/Point.x10"
                    final boolean t$135082 = !(t$135080);
                    
                    //#line 103 "x10/lang/Point.x10"
                    if (t$135082) {
                        
                        //#line 103 "x10/lang/Point.x10"
                        final x10.lang.FailedDynamicCheckException t$135081 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                        
                        //#line 103 "x10/lang/Point.x10"
                        throw t$135081;
                    }
                    
                    //#line 103 "x10/lang/Point.x10"
                    return t$97619;
                } else {
                    
                    //#line 104 "x10/lang/Point.x10"
                    final long t$135083 = ((x10.core.Rail<x10.core.Int>)r).size;
                    
                    //#line 104 "x10/lang/Point.x10"
                    final boolean t$135102 = ((long) t$135083) == ((long) 4L);
                    
                    //#line 104 "x10/lang/Point.x10"
                    if (t$135102) {
                        
                        //#line 105 "x10/lang/Point.x10"
                        final x10.lang.Point alloc$98058 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                        
                        //#line 105 "x10/lang/Point.x10"
                        final int t$135392 = ((int[])r.value)[(int)0L];
                        
                        //#line 105 "x10/lang/Point.x10"
                        final long t$135393 = ((long)(((int)(t$135392))));
                        
                        //#line 105 "x10/lang/Point.x10"
                        final int t$135394 = ((int[])r.value)[(int)1L];
                        
                        //#line 105 "x10/lang/Point.x10"
                        final long t$135395 = ((long)(((int)(t$135394))));
                        
                        //#line 105 "x10/lang/Point.x10"
                        final int t$135396 = ((int[])r.value)[(int)2L];
                        
                        //#line 105 "x10/lang/Point.x10"
                        final long t$135397 = ((long)(((int)(t$135396))));
                        
                        //#line 105 "x10/lang/Point.x10"
                        final int t$135398 = ((int[])r.value)[(int)3L];
                        
                        //#line 105 "x10/lang/Point.x10"
                        final long t$135399 = ((long)(((int)(t$135398))));
                        
                        //#line 105 "x10/lang/Point.x10"
                        alloc$98058.x10$lang$Point$$init$S(t$135393, t$135395, t$135397, t$135399);
                        
                        //#line 105 "x10/lang/Point.x10"
                        final x10.lang.Point t$97621 = ((x10.lang.Point)
                                                         alloc$98058);
                        
                        //#line 105 "x10/lang/Point.x10"
                        final long t$135092 = t$97621.rank;
                        
                        //#line 105 "x10/lang/Point.x10"
                        final long t$135093 = ((x10.core.Rail<x10.core.Int>)r).size;
                        
                        //#line 105 "x10/lang/Point.x10"
                        final boolean t$135094 = ((long) t$135092) == ((long) t$135093);
                        
                        //#line 105 "x10/lang/Point.x10"
                        final boolean t$135096 = !(t$135094);
                        
                        //#line 105 "x10/lang/Point.x10"
                        if (t$135096) {
                            
                            //#line 105 "x10/lang/Point.x10"
                            final x10.lang.FailedDynamicCheckException t$135095 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                            
                            //#line 105 "x10/lang/Point.x10"
                            throw t$135095;
                        }
                        
                        //#line 105 "x10/lang/Point.x10"
                        return t$97621;
                    } else {
                        
                        //#line 107 "x10/lang/Point.x10"
                        final x10.lang.Point alloc$98059 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                        
                        //#line 107 "x10/lang/Point.x10"
                        final long t$135400 = ((x10.core.Rail<x10.core.Int>)r).size;
                        
                        //#line 107 "x10/lang/Point.x10"
                        final x10.core.fun.Fun_0_1 t$135401 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$140(r, (x10.lang.Point.$Closure$140.__0$1x10$lang$Int$2) null)));
                        
                        //#line 107 "x10/lang/Point.x10"
                        final x10.core.Rail t$135405 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$135400)), ((x10.core.fun.Fun_0_1)(t$135401)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                        
                        //#line 107 "x10/lang/Point.x10"
                        alloc$98059.x10$lang$Point$$init$S(((x10.core.Rail)(t$135405)), (x10.lang.Point.__0$1x10$lang$Long$2) null);
                        
                        //#line 107 "x10/lang/Point.x10"
                        return alloc$98059;
                    }
                }
            }
        }
    }
    
    
    //#line 114 "x10/lang/Point.x10"
    /**
     * Constructs a Point from a Rail[Long]
     */
    public static x10.lang.Point make__0$1x10$lang$Long$2(final x10.core.Rail<x10.core.Long> r) {
        
        //#line 115 "x10/lang/Point.x10"
        final long t$135106 = ((x10.core.Rail<x10.core.Long>)r).size;
        
        //#line 115 "x10/lang/Point.x10"
        final boolean t$135145 = ((long) t$135106) == ((long) 1L);
        
        //#line 115 "x10/lang/Point.x10"
        if (t$135145) {
            
            //#line 116 "x10/lang/Point.x10"
            final x10.lang.Point alloc$98060 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 116 "x10/lang/Point.x10"
            final long t$135406 = ((long[])r.value)[(int)0L];
            
            //#line 116 "x10/lang/Point.x10"
            alloc$98060.x10$lang$Point$$init$S(t$135406);
            
            //#line 116 "x10/lang/Point.x10"
            final x10.lang.Point t$97623 = ((x10.lang.Point)
                                             alloc$98060);
            
            //#line 116 "x10/lang/Point.x10"
            final long t$135108 = t$97623.rank;
            
            //#line 116 "x10/lang/Point.x10"
            final long t$135109 = ((x10.core.Rail<x10.core.Long>)r).size;
            
            //#line 116 "x10/lang/Point.x10"
            final boolean t$135110 = ((long) t$135108) == ((long) t$135109);
            
            //#line 116 "x10/lang/Point.x10"
            final boolean t$135112 = !(t$135110);
            
            //#line 116 "x10/lang/Point.x10"
            if (t$135112) {
                
                //#line 116 "x10/lang/Point.x10"
                final x10.lang.FailedDynamicCheckException t$135111 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                
                //#line 116 "x10/lang/Point.x10"
                throw t$135111;
            }
            
            //#line 116 "x10/lang/Point.x10"
            return t$97623;
        } else {
            
            //#line 117 "x10/lang/Point.x10"
            final long t$135113 = ((x10.core.Rail<x10.core.Long>)r).size;
            
            //#line 117 "x10/lang/Point.x10"
            final boolean t$135144 = ((long) t$135113) == ((long) 2L);
            
            //#line 117 "x10/lang/Point.x10"
            if (t$135144) {
                
                //#line 118 "x10/lang/Point.x10"
                final x10.lang.Point alloc$98061 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                
                //#line 118 "x10/lang/Point.x10"
                final long t$135407 = ((long[])r.value)[(int)0L];
                
                //#line 118 "x10/lang/Point.x10"
                final long t$135408 = ((long[])r.value)[(int)1L];
                
                //#line 118 "x10/lang/Point.x10"
                alloc$98061.x10$lang$Point$$init$S(t$135407, t$135408);
                
                //#line 118 "x10/lang/Point.x10"
                final x10.lang.Point t$97625 = ((x10.lang.Point)
                                                 alloc$98061);
                
                //#line 118 "x10/lang/Point.x10"
                final long t$135116 = t$97625.rank;
                
                //#line 118 "x10/lang/Point.x10"
                final long t$135117 = ((x10.core.Rail<x10.core.Long>)r).size;
                
                //#line 118 "x10/lang/Point.x10"
                final boolean t$135118 = ((long) t$135116) == ((long) t$135117);
                
                //#line 118 "x10/lang/Point.x10"
                final boolean t$135120 = !(t$135118);
                
                //#line 118 "x10/lang/Point.x10"
                if (t$135120) {
                    
                    //#line 118 "x10/lang/Point.x10"
                    final x10.lang.FailedDynamicCheckException t$135119 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                    
                    //#line 118 "x10/lang/Point.x10"
                    throw t$135119;
                }
                
                //#line 118 "x10/lang/Point.x10"
                return t$97625;
            } else {
                
                //#line 119 "x10/lang/Point.x10"
                final long t$135121 = ((x10.core.Rail<x10.core.Long>)r).size;
                
                //#line 119 "x10/lang/Point.x10"
                final boolean t$135143 = ((long) t$135121) == ((long) 3L);
                
                //#line 119 "x10/lang/Point.x10"
                if (t$135143) {
                    
                    //#line 120 "x10/lang/Point.x10"
                    final x10.lang.Point alloc$98062 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                    
                    //#line 120 "x10/lang/Point.x10"
                    final long t$135409 = ((long[])r.value)[(int)0L];
                    
                    //#line 120 "x10/lang/Point.x10"
                    final long t$135410 = ((long[])r.value)[(int)1L];
                    
                    //#line 120 "x10/lang/Point.x10"
                    final long t$135411 = ((long[])r.value)[(int)2L];
                    
                    //#line 120 "x10/lang/Point.x10"
                    alloc$98062.x10$lang$Point$$init$S(t$135409, t$135410, t$135411);
                    
                    //#line 120 "x10/lang/Point.x10"
                    final x10.lang.Point t$97627 = ((x10.lang.Point)
                                                     alloc$98062);
                    
                    //#line 120 "x10/lang/Point.x10"
                    final long t$135125 = t$97627.rank;
                    
                    //#line 120 "x10/lang/Point.x10"
                    final long t$135126 = ((x10.core.Rail<x10.core.Long>)r).size;
                    
                    //#line 120 "x10/lang/Point.x10"
                    final boolean t$135127 = ((long) t$135125) == ((long) t$135126);
                    
                    //#line 120 "x10/lang/Point.x10"
                    final boolean t$135129 = !(t$135127);
                    
                    //#line 120 "x10/lang/Point.x10"
                    if (t$135129) {
                        
                        //#line 120 "x10/lang/Point.x10"
                        final x10.lang.FailedDynamicCheckException t$135128 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                        
                        //#line 120 "x10/lang/Point.x10"
                        throw t$135128;
                    }
                    
                    //#line 120 "x10/lang/Point.x10"
                    return t$97627;
                } else {
                    
                    //#line 121 "x10/lang/Point.x10"
                    final long t$135130 = ((x10.core.Rail<x10.core.Long>)r).size;
                    
                    //#line 121 "x10/lang/Point.x10"
                    final boolean t$135142 = ((long) t$135130) == ((long) 4L);
                    
                    //#line 121 "x10/lang/Point.x10"
                    if (t$135142) {
                        
                        //#line 122 "x10/lang/Point.x10"
                        final x10.lang.Point alloc$98063 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                        
                        //#line 122 "x10/lang/Point.x10"
                        final long t$135412 = ((long[])r.value)[(int)0L];
                        
                        //#line 122 "x10/lang/Point.x10"
                        final long t$135413 = ((long[])r.value)[(int)1L];
                        
                        //#line 122 "x10/lang/Point.x10"
                        final long t$135414 = ((long[])r.value)[(int)2L];
                        
                        //#line 122 "x10/lang/Point.x10"
                        final long t$135415 = ((long[])r.value)[(int)3L];
                        
                        //#line 122 "x10/lang/Point.x10"
                        alloc$98063.x10$lang$Point$$init$S(t$135412, t$135413, t$135414, t$135415);
                        
                        //#line 122 "x10/lang/Point.x10"
                        final x10.lang.Point t$97629 = ((x10.lang.Point)
                                                         alloc$98063);
                        
                        //#line 122 "x10/lang/Point.x10"
                        final long t$135135 = t$97629.rank;
                        
                        //#line 122 "x10/lang/Point.x10"
                        final long t$135136 = ((x10.core.Rail<x10.core.Long>)r).size;
                        
                        //#line 122 "x10/lang/Point.x10"
                        final boolean t$135137 = ((long) t$135135) == ((long) t$135136);
                        
                        //#line 122 "x10/lang/Point.x10"
                        final boolean t$135139 = !(t$135137);
                        
                        //#line 122 "x10/lang/Point.x10"
                        if (t$135139) {
                            
                            //#line 122 "x10/lang/Point.x10"
                            final x10.lang.FailedDynamicCheckException t$135138 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                            
                            //#line 122 "x10/lang/Point.x10"
                            throw t$135138;
                        }
                        
                        //#line 122 "x10/lang/Point.x10"
                        return t$97629;
                    } else {
                        
                        //#line 124 "x10/lang/Point.x10"
                        final x10.lang.Point alloc$98064 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                        
                        //#line 124 "x10/lang/Point.x10"
                        final long t$135416 = ((x10.core.Rail<x10.core.Long>)r).size;
                        
                        //#line 124 "x10/lang/Point.x10"
                        final x10.core.Rail t$135417 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$135416)), ((x10.core.fun.Fun_0_1)(r)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                        
                        //#line 124 "x10/lang/Point.x10"
                        alloc$98064.x10$lang$Point$$init$S(((x10.core.Rail)(t$135417)), (x10.lang.Point.__0$1x10$lang$Long$2) null);
                        
                        //#line 124 "x10/lang/Point.x10"
                        return alloc$98064;
                    }
                }
            }
        }
    }
    
    
    //#line 131 "x10/lang/Point.x10"
    /**
     * Returns a <code>Point p</code> of rank <code>rank</code> with <code>p(i)=init(i)</code>.
     */
    public static x10.lang.Point make__1$1x10$lang$Long$3x10$lang$Long$2(final long rank, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> init) {
        
        //#line 132 "x10/lang/Point.x10"
        final boolean t$135182 = ((long) rank) == ((long) 1L);
        
        //#line 132 "x10/lang/Point.x10"
        if (t$135182) {
            
            //#line 133 "x10/lang/Point.x10"
            final x10.lang.Point alloc$98065 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 133 "x10/lang/Point.x10"
            final long t$135418 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
            
            //#line 133 "x10/lang/Point.x10"
            alloc$98065.x10$lang$Point$$init$S(t$135418);
            
            //#line 133 "x10/lang/Point.x10"
            final x10.lang.Point t$97631 = ((x10.lang.Point)
                                             alloc$98065);
            
            //#line 133 "x10/lang/Point.x10"
            final long t$135147 = t$97631.rank;
            
            //#line 133 "x10/lang/Point.x10"
            final boolean t$135148 = ((long) t$135147) == ((long) rank);
            
            //#line 133 "x10/lang/Point.x10"
            final boolean t$135150 = !(t$135148);
            
            //#line 133 "x10/lang/Point.x10"
            if (t$135150) {
                
                //#line 133 "x10/lang/Point.x10"
                final x10.lang.FailedDynamicCheckException t$135149 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==rank}");
                
                //#line 133 "x10/lang/Point.x10"
                throw t$135149;
            }
            
            //#line 133 "x10/lang/Point.x10"
            return t$97631;
        } else {
            
            //#line 134 "x10/lang/Point.x10"
            final boolean t$135181 = ((long) rank) == ((long) 2L);
            
            //#line 134 "x10/lang/Point.x10"
            if (t$135181) {
                
                //#line 135 "x10/lang/Point.x10"
                final x10.lang.Point alloc$98066 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                
                //#line 135 "x10/lang/Point.x10"
                final long t$135419 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                
                //#line 135 "x10/lang/Point.x10"
                final long t$135420 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(1L), x10.rtt.Types.LONG));
                
                //#line 135 "x10/lang/Point.x10"
                alloc$98066.x10$lang$Point$$init$S(t$135419, t$135420);
                
                //#line 135 "x10/lang/Point.x10"
                final x10.lang.Point t$97633 = ((x10.lang.Point)
                                                 alloc$98066);
                
                //#line 135 "x10/lang/Point.x10"
                final long t$135153 = t$97633.rank;
                
                //#line 135 "x10/lang/Point.x10"
                final boolean t$135154 = ((long) t$135153) == ((long) rank);
                
                //#line 135 "x10/lang/Point.x10"
                final boolean t$135156 = !(t$135154);
                
                //#line 135 "x10/lang/Point.x10"
                if (t$135156) {
                    
                    //#line 135 "x10/lang/Point.x10"
                    final x10.lang.FailedDynamicCheckException t$135155 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==rank}");
                    
                    //#line 135 "x10/lang/Point.x10"
                    throw t$135155;
                }
                
                //#line 135 "x10/lang/Point.x10"
                return t$97633;
            } else {
                
                //#line 136 "x10/lang/Point.x10"
                final boolean t$135180 = ((long) rank) == ((long) 3L);
                
                //#line 136 "x10/lang/Point.x10"
                if (t$135180) {
                    
                    //#line 137 "x10/lang/Point.x10"
                    final x10.lang.Point alloc$98067 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                    
                    //#line 137 "x10/lang/Point.x10"
                    final long t$135421 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                    
                    //#line 137 "x10/lang/Point.x10"
                    final long t$135422 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(1L), x10.rtt.Types.LONG));
                    
                    //#line 137 "x10/lang/Point.x10"
                    final long t$135423 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(2L), x10.rtt.Types.LONG));
                    
                    //#line 137 "x10/lang/Point.x10"
                    alloc$98067.x10$lang$Point$$init$S(t$135421, t$135422, t$135423);
                    
                    //#line 137 "x10/lang/Point.x10"
                    final x10.lang.Point t$97635 = ((x10.lang.Point)
                                                     alloc$98067);
                    
                    //#line 137 "x10/lang/Point.x10"
                    final long t$135160 = t$97635.rank;
                    
                    //#line 137 "x10/lang/Point.x10"
                    final boolean t$135161 = ((long) t$135160) == ((long) rank);
                    
                    //#line 137 "x10/lang/Point.x10"
                    final boolean t$135163 = !(t$135161);
                    
                    //#line 137 "x10/lang/Point.x10"
                    if (t$135163) {
                        
                        //#line 137 "x10/lang/Point.x10"
                        final x10.lang.FailedDynamicCheckException t$135162 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==rank}");
                        
                        //#line 137 "x10/lang/Point.x10"
                        throw t$135162;
                    }
                    
                    //#line 137 "x10/lang/Point.x10"
                    return t$97635;
                } else {
                    
                    //#line 138 "x10/lang/Point.x10"
                    final boolean t$135179 = ((long) rank) == ((long) 4L);
                    
                    //#line 138 "x10/lang/Point.x10"
                    if (t$135179) {
                        
                        //#line 139 "x10/lang/Point.x10"
                        final x10.lang.Point alloc$98068 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                        
                        //#line 139 "x10/lang/Point.x10"
                        final long t$135424 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                        
                        //#line 139 "x10/lang/Point.x10"
                        final long t$135425 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(1L), x10.rtt.Types.LONG));
                        
                        //#line 139 "x10/lang/Point.x10"
                        final long t$135426 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(2L), x10.rtt.Types.LONG));
                        
                        //#line 139 "x10/lang/Point.x10"
                        final long t$135427 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(3L), x10.rtt.Types.LONG));
                        
                        //#line 139 "x10/lang/Point.x10"
                        alloc$98068.x10$lang$Point$$init$S(t$135424, t$135425, t$135426, t$135427);
                        
                        //#line 139 "x10/lang/Point.x10"
                        final x10.lang.Point t$97637 = ((x10.lang.Point)
                                                         alloc$98068);
                        
                        //#line 139 "x10/lang/Point.x10"
                        final long t$135168 = t$97637.rank;
                        
                        //#line 139 "x10/lang/Point.x10"
                        final boolean t$135169 = ((long) t$135168) == ((long) rank);
                        
                        //#line 139 "x10/lang/Point.x10"
                        final boolean t$135171 = !(t$135169);
                        
                        //#line 139 "x10/lang/Point.x10"
                        if (t$135171) {
                            
                            //#line 139 "x10/lang/Point.x10"
                            final x10.lang.FailedDynamicCheckException t$135170 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==rank}");
                            
                            //#line 139 "x10/lang/Point.x10"
                            throw t$135170;
                        }
                        
                        //#line 139 "x10/lang/Point.x10"
                        return t$97637;
                    } else {
                        
                        //#line 141 "x10/lang/Point.x10"
                        final x10.lang.Point alloc$98069 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                        
                        //#line 141 "x10/lang/Point.x10"
                        final x10.core.fun.Fun_0_1 t$135428 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$141(init, (x10.lang.Point.$Closure$141.__0$1x10$lang$Long$3x10$lang$Long$2) null)));
                        
                        //#line 141 "x10/lang/Point.x10"
                        final x10.core.Rail t$135431 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(rank)), ((x10.core.fun.Fun_0_1)(t$135428)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                        
                        //#line 141 "x10/lang/Point.x10"
                        alloc$98069.x10$lang$Point$$init$S(((x10.core.Rail)(t$135431)), (x10.lang.Point.__0$1x10$lang$Long$2) null);
                        
                        //#line 141 "x10/lang/Point.x10"
                        final x10.lang.Point t$97639 = ((x10.lang.Point)
                                                         alloc$98069);
                        
                        //#line 141 "x10/lang/Point.x10"
                        final long t$135175 = t$97639.rank;
                        
                        //#line 141 "x10/lang/Point.x10"
                        final boolean t$135176 = ((long) t$135175) == ((long) rank);
                        
                        //#line 141 "x10/lang/Point.x10"
                        final boolean t$135178 = !(t$135176);
                        
                        //#line 141 "x10/lang/Point.x10"
                        if (t$135178) {
                            
                            //#line 141 "x10/lang/Point.x10"
                            final x10.lang.FailedDynamicCheckException t$135177 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==rank}");
                            
                            //#line 141 "x10/lang/Point.x10"
                            throw t$135177;
                        }
                        
                        //#line 141 "x10/lang/Point.x10"
                        return t$97639;
                    }
                }
            }
        }
    }
    
    
    //#line 146 "x10/lang/Point.x10"
    public static x10.lang.Point make(final int i0) {
        
        //#line 146 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98070 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 146 "x10/lang/Point.x10"
        final long t$135432 = ((long)(((int)(i0))));
        
        //#line 146 "x10/lang/Point.x10"
        alloc$98070.x10$lang$Point$$init$S(t$135432);
        
        //#line 146 "x10/lang/Point.x10"
        return alloc$98070;
    }
    
    
    //#line 147 "x10/lang/Point.x10"
    public static x10.lang.Point make(final int i0, final int i1) {
        
        //#line 147 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98071 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 147 "x10/lang/Point.x10"
        final long t$135433 = ((long)(((int)(i0))));
        
        //#line 147 "x10/lang/Point.x10"
        final long t$135434 = ((long)(((int)(i1))));
        
        //#line 147 "x10/lang/Point.x10"
        alloc$98071.x10$lang$Point$$init$S(t$135433, t$135434);
        
        //#line 147 "x10/lang/Point.x10"
        return alloc$98071;
    }
    
    
    //#line 148 "x10/lang/Point.x10"
    public static x10.lang.Point make(final int i0, final int i1, final int i2) {
        
        //#line 148 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98072 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 148 "x10/lang/Point.x10"
        final long t$135435 = ((long)(((int)(i0))));
        
        //#line 148 "x10/lang/Point.x10"
        final long t$135436 = ((long)(((int)(i1))));
        
        //#line 148 "x10/lang/Point.x10"
        final long t$135437 = ((long)(((int)(i2))));
        
        //#line 148 "x10/lang/Point.x10"
        alloc$98072.x10$lang$Point$$init$S(t$135435, t$135436, t$135437);
        
        //#line 148 "x10/lang/Point.x10"
        return alloc$98072;
    }
    
    
    //#line 149 "x10/lang/Point.x10"
    public static x10.lang.Point make(final int i0, final int i1, final int i2, final int i3) {
        
        //#line 149 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98073 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 149 "x10/lang/Point.x10"
        final long t$135438 = ((long)(((int)(i0))));
        
        //#line 149 "x10/lang/Point.x10"
        final long t$135439 = ((long)(((int)(i1))));
        
        //#line 149 "x10/lang/Point.x10"
        final long t$135440 = ((long)(((int)(i2))));
        
        //#line 149 "x10/lang/Point.x10"
        final long t$135441 = ((long)(((int)(i3))));
        
        //#line 149 "x10/lang/Point.x10"
        alloc$98073.x10$lang$Point$$init$S(t$135438, t$135439, t$135440, t$135441);
        
        //#line 149 "x10/lang/Point.x10"
        return alloc$98073;
    }
    
    
    //#line 151 "x10/lang/Point.x10"
    public static x10.lang.Point make(final long i0) {
        
        //#line 151 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98074 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 151 "x10/lang/Point.x10"
        alloc$98074.x10$lang$Point$$init$S(((long)(i0)));
        
        //#line 151 "x10/lang/Point.x10"
        return alloc$98074;
    }
    
    
    //#line 152 "x10/lang/Point.x10"
    public static x10.lang.Point make(final long i0, final long i1) {
        
        //#line 152 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98075 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 152 "x10/lang/Point.x10"
        alloc$98075.x10$lang$Point$$init$S(((long)(i0)), ((long)(i1)));
        
        //#line 152 "x10/lang/Point.x10"
        return alloc$98075;
    }
    
    
    //#line 153 "x10/lang/Point.x10"
    public static x10.lang.Point make(final long i0, final long i1, final long i2) {
        
        //#line 153 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98076 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 153 "x10/lang/Point.x10"
        alloc$98076.x10$lang$Point$$init$S(((long)(i0)), ((long)(i1)), ((long)(i2)));
        
        //#line 153 "x10/lang/Point.x10"
        return alloc$98076;
    }
    
    
    //#line 154 "x10/lang/Point.x10"
    public static x10.lang.Point make(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 154 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98077 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 154 "x10/lang/Point.x10"
        alloc$98077.x10$lang$Point$$init$S(((long)(i0)), ((long)(i1)), ((long)(i2)), ((long)(i3)));
        
        //#line 154 "x10/lang/Point.x10"
        return alloc$98077;
    }
    
    
    //#line 162 "x10/lang/Point.x10"
    /** 
     * A <code>Rail</code> <code>r</code> of length <code>k</code> can be converted to a point <code>p</code>
     * of rank <code>k</code> with <code>p(i)=r(i)</code>.
     * LONG_RAIL: unsafe int cast
     */
    public static x10.lang.Point $implicit_convert__0$1x10$lang$Long$2(final x10.core.Rail<x10.core.Long> r) {
        
        //#line 162 "x10/lang/Point.x10"
        final x10.lang.Point t$135193 = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(r)))));
        
        //#line 162 "x10/lang/Point.x10"
        return t$135193;
    }
    
    
    //#line 168 "x10/lang/Point.x10"
    /** 
     * A <code>Rail</code> <code>r</code> of length <code>k</code> can be converted to a point <code>p</code>
     * of rank <code>k</code> with <code>p(i)=r(i)</code>.
     */
    public static x10.lang.Point $implicit_convert__0$1x10$lang$Int$2(final x10.core.Rail<x10.core.Int> r) {
        
        //#line 168 "x10/lang/Point.x10"
        final x10.lang.Point t$135194 = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Int$2(((x10.core.Rail)(r)))));
        
        //#line 168 "x10/lang/Point.x10"
        return t$135194;
    }
    
    
    //#line 173 "x10/lang/Point.x10"
    /**
     * The point <code>+p</code> is the same as <code>p</code>.
     */
    public x10.lang.Point $plus() {
        
        //#line 173 "x10/lang/Point.x10"
        return this;
    }
    
    
    //#line 178 "x10/lang/Point.x10"
    /**  
     * The point <code>-p</code> is the same as <code>p</code> with each index negated.
     */
    public x10.lang.Point $minus() {
        
        //#line 179 "x10/lang/Point.x10"
        final long t$135197 = this.rank;
        
        //#line 179 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135198 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$142(this)));
        
        //#line 179 "x10/lang/Point.x10"
        final x10.lang.Point t$135199 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135197), ((x10.core.fun.Fun_0_1)(t$135198)))));
        
        //#line 179 "x10/lang/Point.x10"
        return t$135199;
    }
    
    
    //#line 184 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>p+q</code> is <code>p(i)+q(i)</code>.
     */
    public x10.lang.Point $plus(final x10.lang.Point that) {
        
        //#line 185 "x10/lang/Point.x10"
        final long t$135203 = this.rank;
        
        //#line 185 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135204 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$143(this, that)));
        
        //#line 185 "x10/lang/Point.x10"
        final x10.lang.Point t$135205 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135203), ((x10.core.fun.Fun_0_1)(t$135204)))));
        
        //#line 185 "x10/lang/Point.x10"
        return t$135205;
    }
    
    
    //#line 191 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>p-q</code> is <code>p(i)-q(i)</code>.
     */
    public x10.lang.Point $minus(final x10.lang.Point that) {
        
        //#line 192 "x10/lang/Point.x10"
        final long t$135209 = this.rank;
        
        //#line 192 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135210 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$144(this, that)));
        
        //#line 192 "x10/lang/Point.x10"
        final x10.lang.Point t$135211 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135209), ((x10.core.fun.Fun_0_1)(t$135210)))));
        
        //#line 192 "x10/lang/Point.x10"
        return t$135211;
    }
    
    
    //#line 197 "x10/lang/Point.x10"
    /** 
     * The ith coordinate of point <code>p*q</code> is <code>p(i)*q(i)</code>.
     */
    public x10.lang.Point $times(final x10.lang.Point that) {
        
        //#line 198 "x10/lang/Point.x10"
        final long t$135215 = this.rank;
        
        //#line 198 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135216 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$145(this, that)));
        
        //#line 198 "x10/lang/Point.x10"
        final x10.lang.Point t$135217 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135215), ((x10.core.fun.Fun_0_1)(t$135216)))));
        
        //#line 198 "x10/lang/Point.x10"
        return t$135217;
    }
    
    
    //#line 203 "x10/lang/Point.x10"
    /**  
     * The ith coordinate of point <code>p/q</code> is <code>p(i)/q(i)</code>.
     */
    public x10.lang.Point $over(final x10.lang.Point that) {
        
        //#line 204 "x10/lang/Point.x10"
        final long t$135221 = this.rank;
        
        //#line 204 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135222 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$146(this, that)));
        
        //#line 204 "x10/lang/Point.x10"
        final x10.lang.Point t$135223 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135221), ((x10.core.fun.Fun_0_1)(t$135222)))));
        
        //#line 204 "x10/lang/Point.x10"
        return t$135223;
    }
    
    
    //#line 209 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>p+c</code> is <code>p(i)+c</code>.
     */
    public x10.lang.Point $plus(final long c) {
        
        //#line 210 "x10/lang/Point.x10"
        final long t$135226 = this.rank;
        
        //#line 210 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135227 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$147(this, c)));
        
        //#line 210 "x10/lang/Point.x10"
        final x10.lang.Point t$135228 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135226), ((x10.core.fun.Fun_0_1)(t$135227)))));
        
        //#line 210 "x10/lang/Point.x10"
        return t$135228;
    }
    
    
    //#line 215 "x10/lang/Point.x10"
    /** 
     * The ith coordinate of point <code>p-c</code> is <code>p(i)-c</code>.
     */
    public x10.lang.Point $minus(final long c) {
        
        //#line 216 "x10/lang/Point.x10"
        final long t$135231 = this.rank;
        
        //#line 216 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135232 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$148(this, c)));
        
        //#line 216 "x10/lang/Point.x10"
        final x10.lang.Point t$135233 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135231), ((x10.core.fun.Fun_0_1)(t$135232)))));
        
        //#line 216 "x10/lang/Point.x10"
        return t$135233;
    }
    
    
    //#line 221 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>p*c</code> is <code>p(i)*c</code>.
     */
    public x10.lang.Point $times(final long c) {
        
        //#line 222 "x10/lang/Point.x10"
        final long t$135236 = this.rank;
        
        //#line 222 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135237 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$149(this, c)));
        
        //#line 222 "x10/lang/Point.x10"
        final x10.lang.Point t$135238 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135236), ((x10.core.fun.Fun_0_1)(t$135237)))));
        
        //#line 222 "x10/lang/Point.x10"
        return t$135238;
    }
    
    
    //#line 227 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>p/c</code> is <code>p(i)/c</code>.
     */
    public x10.lang.Point $over(final long c) {
        
        //#line 228 "x10/lang/Point.x10"
        final long t$135241 = this.rank;
        
        //#line 228 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135242 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$150(this, c)));
        
        //#line 228 "x10/lang/Point.x10"
        final x10.lang.Point t$135243 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135241), ((x10.core.fun.Fun_0_1)(t$135242)))));
        
        //#line 228 "x10/lang/Point.x10"
        return t$135243;
    }
    
    
    //#line 233 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>c+p</code> is <code>c+p(i)</code>.
     */
    public x10.lang.Point $inv_plus(final long c) {
        
        //#line 234 "x10/lang/Point.x10"
        final long t$135246 = this.rank;
        
        //#line 234 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135247 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$151(this, c)));
        
        //#line 234 "x10/lang/Point.x10"
        final x10.lang.Point t$135248 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135246), ((x10.core.fun.Fun_0_1)(t$135247)))));
        
        //#line 234 "x10/lang/Point.x10"
        return t$135248;
    }
    
    
    //#line 239 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>c-p</code> is <code>c-p(i)</code>.
     */
    public x10.lang.Point $inv_minus(final long c) {
        
        //#line 240 "x10/lang/Point.x10"
        final long t$135251 = this.rank;
        
        //#line 240 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135252 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$152(this, c)));
        
        //#line 240 "x10/lang/Point.x10"
        final x10.lang.Point t$135253 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135251), ((x10.core.fun.Fun_0_1)(t$135252)))));
        
        //#line 240 "x10/lang/Point.x10"
        return t$135253;
    }
    
    
    //#line 245 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>c*p</code> is <code>c*p(i)</code>.
     */
    public x10.lang.Point $inv_times(final long c) {
        
        //#line 246 "x10/lang/Point.x10"
        final long t$135256 = this.rank;
        
        //#line 246 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135257 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$153(this, c)));
        
        //#line 246 "x10/lang/Point.x10"
        final x10.lang.Point t$135258 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135256), ((x10.core.fun.Fun_0_1)(t$135257)))));
        
        //#line 246 "x10/lang/Point.x10"
        return t$135258;
    }
    
    
    //#line 251 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>c/p</code> is <code>c/p(i)</code>.
     */
    public x10.lang.Point $inv_over(final long c) {
        
        //#line 252 "x10/lang/Point.x10"
        final long t$135261 = this.rank;
        
        //#line 252 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135262 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$154(this, c)));
        
        //#line 252 "x10/lang/Point.x10"
        final x10.lang.Point t$135263 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135261), ((x10.core.fun.Fun_0_1)(t$135262)))));
        
        //#line 252 "x10/lang/Point.x10"
        return t$135263;
    }
    
    
    //#line 257 "x10/lang/Point.x10"
    /**
     * {@link Comparable#compareTo}
     */
    public int compareTo(final java.lang.Object that) {
        
        //#line 258 "x10/lang/Point.x10"
        final boolean t$135266 = this.equals(((java.lang.Object)(that)));
        
        //#line 258 "x10/lang/Point.x10"
        int t$135267 =  0;
        
        //#line 258 "x10/lang/Point.x10"
        if (t$135266) {
            
            //#line 258 "x10/lang/Point.x10"
            t$135267 = 0;
        } else {
            
            //#line 258 "x10/lang/Point.x10"
            final boolean t$135264 = this.$lt$O(((x10.lang.Point)(that)));
            
            //#line 258 "x10/lang/Point.x10"
            int t$135265 =  0;
            
            //#line 258 "x10/lang/Point.x10"
            if (t$135264) {
                
                //#line 258 "x10/lang/Point.x10"
                t$135265 = -1;
            } else {
                
                //#line 258 "x10/lang/Point.x10"
                t$135265 = 1;
            }
            
            //#line 258 "x10/lang/Point.x10"
            t$135267 = t$135265;
        }
        
        //#line 258 "x10/lang/Point.x10"
        return t$135267;
    }
    
    
    //#line 268 "x10/lang/Point.x10"
    /**
     * Compute the hashCode of a point by combining the
     * the coordinates in a multiple/xor chain.  This
     * should increase the randomness and overcomes the
     * fact that coordinates are biased to be small
     * positive numbers.
     */
    public int hashCode() {
        
        //#line 269 "x10/lang/Point.x10"
        long hc = this.$apply$O((long)(0L));
        
        //#line 270 "x10/lang/Point.x10"
        final long t$135452 = this.rank;
        
        //#line 270 "x10/lang/Point.x10"
        final long i$98079max$135453 = ((t$135452) - (((long)(1L))));
        
        //#line 270 "x10/lang/Point.x10"
        long i$135449 = 1L;
        
        //#line 270 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 270 "x10/lang/Point.x10"
            final boolean t$135451 = ((i$135449) <= (((long)(i$98079max$135453))));
            
            //#line 270 "x10/lang/Point.x10"
            if (!(t$135451)) {
                
                //#line 270 "x10/lang/Point.x10"
                break;
            }
            
            //#line 271 "x10/lang/Point.x10"
            final long t$135443 = ((hc) * (((long)(17L))));
            
            //#line 271 "x10/lang/Point.x10"
            final long t$135444 = this.$apply$O((long)(i$135449));
            
            //#line 271 "x10/lang/Point.x10"
            final long t$135445 = ((t$135443) ^ (((long)(t$135444))));
            
            //#line 271 "x10/lang/Point.x10"
            hc = t$135445;
            
            //#line 270 "x10/lang/Point.x10"
            final long t$135448 = ((i$135449) + (((long)(1L))));
            
            //#line 270 "x10/lang/Point.x10"
            i$135449 = t$135448;
        }
        
        //#line 273 "x10/lang/Point.x10"
        final int t$135280 = ((int)(long)(((long)(hc))));
        
        //#line 273 "x10/lang/Point.x10"
        return t$135280;
    }
    
    
    //#line 280 "x10/lang/Point.x10"
    /** 
     * Two points of the same rank are equal if and only if their
     * corresponding indices are equal.
     */
    public boolean equals(final java.lang.Object other) {
        
        //#line 281 "x10/lang/Point.x10"
        final boolean t$135281 = x10.lang.Point.$RTT.isInstance(other);
        
        //#line 281 "x10/lang/Point.x10"
        final boolean t$135282 = !(t$135281);
        
        //#line 281 "x10/lang/Point.x10"
        if (t$135282) {
            
            //#line 281 "x10/lang/Point.x10"
            return false;
        }
        
        //#line 282 "x10/lang/Point.x10"
        final x10.lang.Point otherPoint = ((x10.lang.Point)(x10.rtt.Types.<x10.lang.Point> cast(other,x10.lang.Point.$RTT)));
        
        //#line 283 "x10/lang/Point.x10"
        final long t$135283 = this.rank;
        
        //#line 283 "x10/lang/Point.x10"
        final long t$135284 = otherPoint.rank;
        
        //#line 283 "x10/lang/Point.x10"
        final boolean t$135285 = ((long) t$135283) != ((long) t$135284);
        
        //#line 283 "x10/lang/Point.x10"
        if (t$135285) {
            
            //#line 283 "x10/lang/Point.x10"
            return false;
        }
        
        //#line 284 "x10/lang/Point.x10"
        final long t$135464 = this.rank;
        
        //#line 284 "x10/lang/Point.x10"
        final long i$98097max$135465 = ((t$135464) - (((long)(1L))));
        
        //#line 284 "x10/lang/Point.x10"
        long i$135461 = 0L;
        
        //#line 284 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 284 "x10/lang/Point.x10"
            final boolean t$135463 = ((i$135461) <= (((long)(i$98097max$135465))));
            
            //#line 284 "x10/lang/Point.x10"
            if (!(t$135463)) {
                
                //#line 284 "x10/lang/Point.x10"
                break;
            }
            
            //#line 285 "x10/lang/Point.x10"
            final long t$135454 = this.$apply$O((long)(i$135461));
            
            //#line 285 "x10/lang/Point.x10"
            final long t$135455 = otherPoint.$apply$O((long)(i$135461));
            
            //#line 285 "x10/lang/Point.x10"
            final boolean t$135456 = ((long) t$135454) == ((long) t$135455);
            
            //#line 285 "x10/lang/Point.x10"
            final boolean t$135457 = !(t$135456);
            
            //#line 285 "x10/lang/Point.x10"
            if (t$135457) {
                
                //#line 286 "x10/lang/Point.x10"
                return false;
            }
            
            //#line 284 "x10/lang/Point.x10"
            final long t$135460 = ((i$135461) + (((long)(1L))));
            
            //#line 284 "x10/lang/Point.x10"
            i$135461 = t$135460;
        }
        
        //#line 288 "x10/lang/Point.x10"
        return true;
    }
    
    
    //#line 294 "x10/lang/Point.x10"
    /**
     * For points a, b, <code> a &lt; b</code> if <code>a</code> is lexicographically smaller than <code>b</code>.
     */
    public boolean $lt$O(final x10.lang.Point that) {
        
        //#line 295 "x10/lang/Point.x10"
        final long t$135476 = this.rank;
        
        //#line 295 "x10/lang/Point.x10"
        final long i$98115max$135477 = ((t$135476) - (((long)(2L))));
        
        //#line 295 "x10/lang/Point.x10"
        long i$135473 = 0L;
        
        //#line 295 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 295 "x10/lang/Point.x10"
            final boolean t$135475 = ((i$135473) <= (((long)(i$98115max$135477))));
            
            //#line 295 "x10/lang/Point.x10"
            if (!(t$135475)) {
                
                //#line 295 "x10/lang/Point.x10"
                break;
            }
            
            //#line 296 "x10/lang/Point.x10"
            final long a$135466 = this.$apply$O((long)(i$135473));
            
            //#line 297 "x10/lang/Point.x10"
            final long b$135467 = that.$apply$O((long)(i$135473));
            
            //#line 298 "x10/lang/Point.x10"
            final boolean t$135468 = ((a$135466) > (((long)(b$135467))));
            
            //#line 298 "x10/lang/Point.x10"
            if (t$135468) {
                
                //#line 298 "x10/lang/Point.x10"
                return false;
            }
            
            //#line 299 "x10/lang/Point.x10"
            final boolean t$135469 = ((a$135466) < (((long)(b$135467))));
            
            //#line 299 "x10/lang/Point.x10"
            if (t$135469) {
                
                //#line 299 "x10/lang/Point.x10"
                return true;
            }
            
            //#line 295 "x10/lang/Point.x10"
            final long t$135472 = ((i$135473) + (((long)(1L))));
            
            //#line 295 "x10/lang/Point.x10"
            i$135473 = t$135472;
        }
        
        //#line 301 "x10/lang/Point.x10"
        final long t$135304 = this.rank;
        
        //#line 301 "x10/lang/Point.x10"
        final long t$135305 = ((t$135304) - (((long)(1L))));
        
        //#line 301 "x10/lang/Point.x10"
        final long t$135308 = this.$apply$O((long)(t$135305));
        
        //#line 301 "x10/lang/Point.x10"
        final long t$135306 = this.rank;
        
        //#line 301 "x10/lang/Point.x10"
        final long t$135307 = ((t$135306) - (((long)(1L))));
        
        //#line 301 "x10/lang/Point.x10"
        final long t$135309 = that.$apply$O((long)(t$135307));
        
        //#line 301 "x10/lang/Point.x10"
        final boolean t$135310 = ((t$135308) < (((long)(t$135309))));
        
        //#line 301 "x10/lang/Point.x10"
        return t$135310;
    }
    
    
    //#line 308 "x10/lang/Point.x10"
    /** 
     * For points <code>a, b</code>, <code> a &gt; b</code> if <code>a</code> 
     * is lexicographically bigger than <code> b</code>.
     */
    public boolean $gt$O(final x10.lang.Point that) {
        
        //#line 309 "x10/lang/Point.x10"
        final long t$135488 = this.rank;
        
        //#line 309 "x10/lang/Point.x10"
        final long i$98133max$135489 = ((t$135488) - (((long)(2L))));
        
        //#line 309 "x10/lang/Point.x10"
        long i$135485 = 0L;
        
        //#line 309 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 309 "x10/lang/Point.x10"
            final boolean t$135487 = ((i$135485) <= (((long)(i$98133max$135489))));
            
            //#line 309 "x10/lang/Point.x10"
            if (!(t$135487)) {
                
                //#line 309 "x10/lang/Point.x10"
                break;
            }
            
            //#line 310 "x10/lang/Point.x10"
            final long a$135478 = this.$apply$O((long)(i$135485));
            
            //#line 311 "x10/lang/Point.x10"
            final long b$135479 = that.$apply$O((long)(i$135485));
            
            //#line 312 "x10/lang/Point.x10"
            final boolean t$135480 = ((a$135478) < (((long)(b$135479))));
            
            //#line 312 "x10/lang/Point.x10"
            if (t$135480) {
                
                //#line 312 "x10/lang/Point.x10"
                return false;
            }
            
            //#line 313 "x10/lang/Point.x10"
            final boolean t$135481 = ((a$135478) > (((long)(b$135479))));
            
            //#line 313 "x10/lang/Point.x10"
            if (t$135481) {
                
                //#line 313 "x10/lang/Point.x10"
                return true;
            }
            
            //#line 309 "x10/lang/Point.x10"
            final long t$135484 = ((i$135485) + (((long)(1L))));
            
            //#line 309 "x10/lang/Point.x10"
            i$135485 = t$135484;
        }
        
        //#line 315 "x10/lang/Point.x10"
        final long t$135319 = this.rank;
        
        //#line 315 "x10/lang/Point.x10"
        final long t$135320 = ((t$135319) - (((long)(1L))));
        
        //#line 315 "x10/lang/Point.x10"
        final long t$135323 = this.$apply$O((long)(t$135320));
        
        //#line 315 "x10/lang/Point.x10"
        final long t$135321 = this.rank;
        
        //#line 315 "x10/lang/Point.x10"
        final long t$135322 = ((t$135321) - (((long)(1L))));
        
        //#line 315 "x10/lang/Point.x10"
        final long t$135324 = that.$apply$O((long)(t$135322));
        
        //#line 315 "x10/lang/Point.x10"
        final boolean t$135325 = ((t$135323) > (((long)(t$135324))));
        
        //#line 315 "x10/lang/Point.x10"
        return t$135325;
    }
    
    
    //#line 322 "x10/lang/Point.x10"
    /**
     * For points <code>a, b</code>, <code> a &le; b</code> if <code>a</code> is 
     * lexicographically less than <code> b</code> or the same as <code>b</code>.
     */
    public boolean $le$O(final x10.lang.Point that) {
        
        //#line 323 "x10/lang/Point.x10"
        final long t$135500 = this.rank;
        
        //#line 323 "x10/lang/Point.x10"
        final long i$98151max$135501 = ((t$135500) - (((long)(2L))));
        
        //#line 323 "x10/lang/Point.x10"
        long i$135497 = 0L;
        
        //#line 323 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 323 "x10/lang/Point.x10"
            final boolean t$135499 = ((i$135497) <= (((long)(i$98151max$135501))));
            
            //#line 323 "x10/lang/Point.x10"
            if (!(t$135499)) {
                
                //#line 323 "x10/lang/Point.x10"
                break;
            }
            
            //#line 324 "x10/lang/Point.x10"
            final long a$135490 = this.$apply$O((long)(i$135497));
            
            //#line 325 "x10/lang/Point.x10"
            final long b$135491 = that.$apply$O((long)(i$135497));
            
            //#line 326 "x10/lang/Point.x10"
            final boolean t$135492 = ((a$135490) > (((long)(b$135491))));
            
            //#line 326 "x10/lang/Point.x10"
            if (t$135492) {
                
                //#line 326 "x10/lang/Point.x10"
                return false;
            }
            
            //#line 327 "x10/lang/Point.x10"
            final boolean t$135493 = ((a$135490) < (((long)(b$135491))));
            
            //#line 327 "x10/lang/Point.x10"
            if (t$135493) {
                
                //#line 327 "x10/lang/Point.x10"
                return true;
            }
            
            //#line 323 "x10/lang/Point.x10"
            final long t$135496 = ((i$135497) + (((long)(1L))));
            
            //#line 323 "x10/lang/Point.x10"
            i$135497 = t$135496;
        }
        
        //#line 329 "x10/lang/Point.x10"
        final long t$135334 = this.rank;
        
        //#line 329 "x10/lang/Point.x10"
        final long t$135335 = ((t$135334) - (((long)(1L))));
        
        //#line 329 "x10/lang/Point.x10"
        final long t$135338 = this.$apply$O((long)(t$135335));
        
        //#line 329 "x10/lang/Point.x10"
        final long t$135336 = this.rank;
        
        //#line 329 "x10/lang/Point.x10"
        final long t$135337 = ((t$135336) - (((long)(1L))));
        
        //#line 329 "x10/lang/Point.x10"
        final long t$135339 = that.$apply$O((long)(t$135337));
        
        //#line 329 "x10/lang/Point.x10"
        final boolean t$135340 = ((t$135338) <= (((long)(t$135339))));
        
        //#line 329 "x10/lang/Point.x10"
        return t$135340;
    }
    
    
    //#line 336 "x10/lang/Point.x10"
    /**
     * For points <code>a, b</code>, <code> a &ge; b</code> if <code>a</code> is 
     * lexicographically greater than <code> b</code> or the same as <code>b</code>.
     */
    public boolean $ge$O(final x10.lang.Point that) {
        
        //#line 337 "x10/lang/Point.x10"
        final long t$135512 = this.rank;
        
        //#line 337 "x10/lang/Point.x10"
        final long i$98169max$135513 = ((t$135512) - (((long)(2L))));
        
        //#line 337 "x10/lang/Point.x10"
        long i$135509 = 0L;
        
        //#line 337 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 337 "x10/lang/Point.x10"
            final boolean t$135511 = ((i$135509) <= (((long)(i$98169max$135513))));
            
            //#line 337 "x10/lang/Point.x10"
            if (!(t$135511)) {
                
                //#line 337 "x10/lang/Point.x10"
                break;
            }
            
            //#line 338 "x10/lang/Point.x10"
            final long a$135502 = this.$apply$O((long)(i$135509));
            
            //#line 339 "x10/lang/Point.x10"
            final long b$135503 = that.$apply$O((long)(i$135509));
            
            //#line 340 "x10/lang/Point.x10"
            final boolean t$135504 = ((a$135502) < (((long)(b$135503))));
            
            //#line 340 "x10/lang/Point.x10"
            if (t$135504) {
                
                //#line 340 "x10/lang/Point.x10"
                return false;
            }
            
            //#line 341 "x10/lang/Point.x10"
            final boolean t$135505 = ((a$135502) > (((long)(b$135503))));
            
            //#line 341 "x10/lang/Point.x10"
            if (t$135505) {
                
                //#line 341 "x10/lang/Point.x10"
                return true;
            }
            
            //#line 337 "x10/lang/Point.x10"
            final long t$135508 = ((i$135509) + (((long)(1L))));
            
            //#line 337 "x10/lang/Point.x10"
            i$135509 = t$135508;
        }
        
        //#line 343 "x10/lang/Point.x10"
        final long t$135349 = this.rank;
        
        //#line 343 "x10/lang/Point.x10"
        final long t$135350 = ((t$135349) - (((long)(1L))));
        
        //#line 343 "x10/lang/Point.x10"
        final long t$135353 = this.$apply$O((long)(t$135350));
        
        //#line 343 "x10/lang/Point.x10"
        final long t$135351 = this.rank;
        
        //#line 343 "x10/lang/Point.x10"
        final long t$135352 = ((t$135351) - (((long)(1L))));
        
        //#line 343 "x10/lang/Point.x10"
        final long t$135354 = that.$apply$O((long)(t$135352));
        
        //#line 343 "x10/lang/Point.x10"
        final boolean t$135355 = ((t$135353) >= (((long)(t$135354))));
        
        //#line 343 "x10/lang/Point.x10"
        return t$135355;
    }
    
    
    //#line 349 "x10/lang/Point.x10"
    /**
     * A point with coordinates <code>i1,..., ik</code> is printed as <code>[i1,.., ik]</code>.
     */
    public java.lang.String toString() {
        
        //#line 350 "x10/lang/Point.x10"
        java.lang.String s = "[";
        
        //#line 351 "x10/lang/Point.x10"
        final long t$135356 = this.rank;
        
        //#line 351 "x10/lang/Point.x10"
        final boolean t$135360 = ((t$135356) > (((long)(0L))));
        
        //#line 351 "x10/lang/Point.x10"
        if (t$135360) {
            
            //#line 351 "x10/lang/Point.x10"
            final long t$135358 = this.$apply$O((long)(0L));
            
            //#line 351 "x10/lang/Point.x10"
            final java.lang.String t$135359 = ((s) + ((x10.core.Long.$box(t$135358))));
            
            //#line 351 "x10/lang/Point.x10"
            s = ((java.lang.String)(t$135359));
        }
        
        //#line 352 "x10/lang/Point.x10"
        final long t$135524 = this.rank;
        
        //#line 352 "x10/lang/Point.x10"
        final long i$98187max$135525 = ((t$135524) - (((long)(1L))));
        
        //#line 352 "x10/lang/Point.x10"
        long i$135521 = 1L;
        
        //#line 352 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 352 "x10/lang/Point.x10"
            final boolean t$135523 = ((i$135521) <= (((long)(i$98187max$135525))));
            
            //#line 352 "x10/lang/Point.x10"
            if (!(t$135523)) {
                
                //#line 352 "x10/lang/Point.x10"
                break;
            }
            
            //#line 353 "x10/lang/Point.x10"
            final long t$135515 = this.$apply$O((long)(i$135521));
            
            //#line 353 "x10/lang/Point.x10"
            final java.lang.String t$135516 = ((",") + ((x10.core.Long.$box(t$135515))));
            
            //#line 353 "x10/lang/Point.x10"
            final java.lang.String t$135517 = ((s) + (t$135516));
            
            //#line 353 "x10/lang/Point.x10"
            s = ((java.lang.String)(t$135517));
            
            //#line 352 "x10/lang/Point.x10"
            final long t$135520 = ((i$135521) + (((long)(1L))));
            
            //#line 352 "x10/lang/Point.x10"
            i$135521 = t$135520;
        }
        
        //#line 355 "x10/lang/Point.x10"
        final java.lang.String t$135372 = ((s) + ("]"));
        
        //#line 355 "x10/lang/Point.x10"
        s = ((java.lang.String)(t$135372));
        
        //#line 356 "x10/lang/Point.x10"
        return s;
    }
    
    
    //#line 24 "x10/lang/Point.x10"
    final public x10.lang.Point x10$lang$Point$$this$x10$lang$Point() {
        
        //#line 24 "x10/lang/Point.x10"
        return x10.lang.Point.this;
    }
    
    
    //#line 24 "x10/lang/Point.x10"
    final public void __fieldInitializers_x10_lang_Point() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$139 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$139> $RTT = 
            x10.rtt.StaticFunType.<$Closure$139> make($Closure$139.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$139 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$139 $_obj = new x10.lang.Point.$Closure$139((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$139(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 92 "x10/lang/Point.x10"
            final long t$135051 = this.out$$.$apply$O((long)(i));
            
            //#line 92 "x10/lang/Point.x10"
            return t$135051;
        }
        
        public x10.lang.Point out$$;
        
        public $Closure$139(final x10.lang.Point out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$140 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$140> $RTT = 
            x10.rtt.StaticFunType.<$Closure$140> make($Closure$140.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$140 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$140 $_obj = new x10.lang.Point.$Closure$140((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$140(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$2 {}
        
    
        
        public long $apply$O(final long i$135402) {
            
            //#line 107 "x10/lang/Point.x10"
            final int t$135403 = ((int[])this.r.value)[(int)i$135402];
            
            //#line 107 "x10/lang/Point.x10"
            final long t$135404 = ((long)(((int)(t$135403))));
            
            //#line 107 "x10/lang/Point.x10"
            return t$135404;
        }
        
        public x10.core.Rail<x10.core.Int> r;
        
        public $Closure$140(final x10.core.Rail<x10.core.Int> r, __0$1x10$lang$Int$2 $dummy) {
             {
                this.r = ((x10.core.Rail)(r));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$141 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$141> $RTT = 
            x10.rtt.StaticFunType.<$Closure$141> make($Closure$141.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$141 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$141 $_obj = new x10.lang.Point.$Closure$141((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$141(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long l$135429) {
            
            //#line 141 "x10/lang/Point.x10"
            final long t$135430 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.init).$apply(x10.core.Long.$box(l$135429), x10.rtt.Types.LONG));
            
            //#line 141 "x10/lang/Point.x10"
            return t$135430;
        }
        
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> init;
        
        public $Closure$141(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> init, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.init = ((x10.core.fun.Fun_0_1)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$142 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$142> $RTT = 
            x10.rtt.StaticFunType.<$Closure$142> make($Closure$142.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$142 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$142 $_obj = new x10.lang.Point.$Closure$142((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$142(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 179 "x10/lang/Point.x10"
            final long t$135195 = this.out$$.$apply$O((long)(i));
            
            //#line 179 "x10/lang/Point.x10"
            final long t$135196 = (-(t$135195));
            
            //#line 179 "x10/lang/Point.x10"
            return t$135196;
        }
        
        public x10.lang.Point out$$;
        
        public $Closure$142(final x10.lang.Point out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$143 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$143> $RTT = 
            x10.rtt.StaticFunType.<$Closure$143> make($Closure$143.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$143 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.that = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$143 $_obj = new x10.lang.Point.$Closure$143((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.that);
            
        }
        
        // constructor just for allocation
        public $Closure$143(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 185 "x10/lang/Point.x10"
            final long t$135200 = this.out$$.$apply$O((long)(i));
            
            //#line 185 "x10/lang/Point.x10"
            final long t$135201 = this.that.$apply$O((long)(i));
            
            //#line 185 "x10/lang/Point.x10"
            final long t$135202 = ((t$135200) + (((long)(t$135201))));
            
            //#line 185 "x10/lang/Point.x10"
            return t$135202;
        }
        
        public x10.lang.Point out$$;
        public x10.lang.Point that;
        
        public $Closure$143(final x10.lang.Point out$$, final x10.lang.Point that) {
             {
                this.out$$ = out$$;
                this.that = ((x10.lang.Point)(that));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$144 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$144> $RTT = 
            x10.rtt.StaticFunType.<$Closure$144> make($Closure$144.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$144 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.that = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$144 $_obj = new x10.lang.Point.$Closure$144((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.that);
            
        }
        
        // constructor just for allocation
        public $Closure$144(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 192 "x10/lang/Point.x10"
            final long t$135206 = this.out$$.$apply$O((long)(i));
            
            //#line 192 "x10/lang/Point.x10"
            final long t$135207 = this.that.$apply$O((long)(i));
            
            //#line 192 "x10/lang/Point.x10"
            final long t$135208 = ((t$135206) - (((long)(t$135207))));
            
            //#line 192 "x10/lang/Point.x10"
            return t$135208;
        }
        
        public x10.lang.Point out$$;
        public x10.lang.Point that;
        
        public $Closure$144(final x10.lang.Point out$$, final x10.lang.Point that) {
             {
                this.out$$ = out$$;
                this.that = ((x10.lang.Point)(that));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$145 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$145> $RTT = 
            x10.rtt.StaticFunType.<$Closure$145> make($Closure$145.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$145 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.that = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$145 $_obj = new x10.lang.Point.$Closure$145((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.that);
            
        }
        
        // constructor just for allocation
        public $Closure$145(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 198 "x10/lang/Point.x10"
            final long t$135212 = this.out$$.$apply$O((long)(i));
            
            //#line 198 "x10/lang/Point.x10"
            final long t$135213 = this.that.$apply$O((long)(i));
            
            //#line 198 "x10/lang/Point.x10"
            final long t$135214 = ((t$135212) * (((long)(t$135213))));
            
            //#line 198 "x10/lang/Point.x10"
            return t$135214;
        }
        
        public x10.lang.Point out$$;
        public x10.lang.Point that;
        
        public $Closure$145(final x10.lang.Point out$$, final x10.lang.Point that) {
             {
                this.out$$ = out$$;
                this.that = ((x10.lang.Point)(that));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$146 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$146> $RTT = 
            x10.rtt.StaticFunType.<$Closure$146> make($Closure$146.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$146 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.that = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$146 $_obj = new x10.lang.Point.$Closure$146((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.that);
            
        }
        
        // constructor just for allocation
        public $Closure$146(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 204 "x10/lang/Point.x10"
            final long t$135218 = this.out$$.$apply$O((long)(i));
            
            //#line 204 "x10/lang/Point.x10"
            final long t$135219 = this.that.$apply$O((long)(i));
            
            //#line 204 "x10/lang/Point.x10"
            final long t$135220 = ((t$135218) / (((long)(t$135219))));
            
            //#line 204 "x10/lang/Point.x10"
            return t$135220;
        }
        
        public x10.lang.Point out$$;
        public x10.lang.Point that;
        
        public $Closure$146(final x10.lang.Point out$$, final x10.lang.Point that) {
             {
                this.out$$ = out$$;
                this.that = ((x10.lang.Point)(that));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$147 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$147> $RTT = 
            x10.rtt.StaticFunType.<$Closure$147> make($Closure$147.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$147 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$147 $_obj = new x10.lang.Point.$Closure$147((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$147(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 210 "x10/lang/Point.x10"
            final long t$135224 = this.out$$.$apply$O((long)(i));
            
            //#line 210 "x10/lang/Point.x10"
            final long t$135225 = ((t$135224) + (((long)(this.c))));
            
            //#line 210 "x10/lang/Point.x10"
            return t$135225;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$147(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$148 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$148> $RTT = 
            x10.rtt.StaticFunType.<$Closure$148> make($Closure$148.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$148 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$148 $_obj = new x10.lang.Point.$Closure$148((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$148(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 216 "x10/lang/Point.x10"
            final long t$135229 = this.out$$.$apply$O((long)(i));
            
            //#line 216 "x10/lang/Point.x10"
            final long t$135230 = ((t$135229) - (((long)(this.c))));
            
            //#line 216 "x10/lang/Point.x10"
            return t$135230;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$148(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$149 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$149> $RTT = 
            x10.rtt.StaticFunType.<$Closure$149> make($Closure$149.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$149 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$149 $_obj = new x10.lang.Point.$Closure$149((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$149(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 222 "x10/lang/Point.x10"
            final long t$135234 = this.out$$.$apply$O((long)(i));
            
            //#line 222 "x10/lang/Point.x10"
            final long t$135235 = ((t$135234) * (((long)(this.c))));
            
            //#line 222 "x10/lang/Point.x10"
            return t$135235;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$149(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$150 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$150> $RTT = 
            x10.rtt.StaticFunType.<$Closure$150> make($Closure$150.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$150 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$150 $_obj = new x10.lang.Point.$Closure$150((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$150(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 228 "x10/lang/Point.x10"
            final long t$135239 = this.out$$.$apply$O((long)(i));
            
            //#line 228 "x10/lang/Point.x10"
            final long t$135240 = ((t$135239) / (((long)(this.c))));
            
            //#line 228 "x10/lang/Point.x10"
            return t$135240;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$150(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$151 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$151> $RTT = 
            x10.rtt.StaticFunType.<$Closure$151> make($Closure$151.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$151 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$151 $_obj = new x10.lang.Point.$Closure$151((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$151(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 234 "x10/lang/Point.x10"
            final long t$135244 = this.out$$.$apply$O((long)(i));
            
            //#line 234 "x10/lang/Point.x10"
            final long t$135245 = ((this.c) + (((long)(t$135244))));
            
            //#line 234 "x10/lang/Point.x10"
            return t$135245;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$151(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$152 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$152> $RTT = 
            x10.rtt.StaticFunType.<$Closure$152> make($Closure$152.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$152 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$152 $_obj = new x10.lang.Point.$Closure$152((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$152(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 240 "x10/lang/Point.x10"
            final long t$135249 = this.out$$.$apply$O((long)(i));
            
            //#line 240 "x10/lang/Point.x10"
            final long t$135250 = ((this.c) - (((long)(t$135249))));
            
            //#line 240 "x10/lang/Point.x10"
            return t$135250;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$152(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$153 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$153> $RTT = 
            x10.rtt.StaticFunType.<$Closure$153> make($Closure$153.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$153 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$153 $_obj = new x10.lang.Point.$Closure$153((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$153(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 246 "x10/lang/Point.x10"
            final long t$135254 = this.out$$.$apply$O((long)(i));
            
            //#line 246 "x10/lang/Point.x10"
            final long t$135255 = ((this.c) * (((long)(t$135254))));
            
            //#line 246 "x10/lang/Point.x10"
            return t$135255;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$153(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$154 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$154> $RTT = 
            x10.rtt.StaticFunType.<$Closure$154> make($Closure$154.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$154 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$154 $_obj = new x10.lang.Point.$Closure$154((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$154(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 252 "x10/lang/Point.x10"
            final long t$135259 = this.out$$.$apply$O((long)(i));
            
            //#line 252 "x10/lang/Point.x10"
            final long t$135260 = ((this.c) / (((long)(t$135259))));
            
            //#line 252 "x10/lang/Point.x10"
            return t$135260;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$154(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
}


