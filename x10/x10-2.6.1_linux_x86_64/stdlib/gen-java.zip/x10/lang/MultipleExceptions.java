package x10.lang;


/**
 * MultipleExceptions is used to to summarize all uncaught exceptions
 * raised during the execution of a <code>finish</code> and rethrow
 * them as a single exception when all activities controlled by the 
 * <code>finish</code> have terminated.
 */
@x10.runtime.impl.java.X10Generated
public class MultipleExceptions extends java.lang.RuntimeException implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<MultipleExceptions> $RTT = 
        x10.rtt.NamedType.<MultipleExceptions> make("x10.lang.MultipleExceptions",
                                                    MultipleExceptions.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.EXCEPTION
                                                    });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.MultipleExceptions $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $deserializer.deserializeFieldsStartingFromClass(java.lang.RuntimeException.class, $_obj, 0);
        $_obj.exceptions = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.MultipleExceptions $_obj = new x10.lang.MultipleExceptions((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.serializeFieldsStartingFromClass(this, java.lang.RuntimeException.class);
        $serializer.write(this.exceptions);
        
    }
    
    // constructor just for allocation
    public MultipleExceptions(final java.lang.System[] $dummy) {
        
    }
    
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$CheckedThrowable$2 {}
    
    // properties
    
    //#line 23 "x10/lang/MultipleExceptions.x10"
    public x10.core.Rail<java.lang.Throwable> exceptions;
    

    
    
    //#line 24 "x10/lang/MultipleExceptions.x10"
    final public x10.core.Rail exceptions() {
        
        //#line 24 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail t$133855 = ((x10.core.Rail)(this.exceptions));
        
        //#line 24 "x10/lang/MultipleExceptions.x10"
        return t$133855;
    }
    
    
    //#line 26 "x10/lang/MultipleExceptions.x10"
    public MultipleExceptions(final x10.util.GrowableRail<java.lang.Throwable> es, __0$1x10$lang$CheckedThrowable$2 $dummy) {
        super();
         {
            
            //#line 27 "x10/lang/MultipleExceptions.x10"
            this.exceptions = ((x10.core.Rail<java.lang.Throwable>)
                                ((x10.util.GrowableRail<java.lang.Throwable>)es).toRail());
            
            
            //#line 23 "x10/lang/MultipleExceptions.x10"
            this.__fieldInitializers_x10_lang_MultipleExceptions();
        }
    }
    
    
    
    //#line 30 "x10/lang/MultipleExceptions.x10"
    public MultipleExceptions() {
        super();
         {
            
            //#line 31 "x10/lang/MultipleExceptions.x10"
            this.exceptions = null;
            
            
            //#line 23 "x10/lang/MultipleExceptions.x10"
            this.__fieldInitializers_x10_lang_MultipleExceptions();
        }
    }
    
    
    
    //#line 34 "x10/lang/MultipleExceptions.x10"
    public MultipleExceptions(final java.lang.Throwable t) {
        super();
         {
            
            //#line 35 "x10/lang/MultipleExceptions.x10"
            this.exceptions = new x10.core.Rail<java.lang.Throwable>(x10.rtt.Types.CHECKED_THROWABLE, ((long)(1L)), ((java.lang.Throwable)(t)), (x10.core.Rail.__1x10$lang$Rail$$T) null);
            
            
            //#line 23 "x10/lang/MultipleExceptions.x10"
            this.__fieldInitializers_x10_lang_MultipleExceptions();
        }
    }
    
    
    
    //#line 38 "x10/lang/MultipleExceptions.x10"
    public void printStackTrace() {
        
        //#line 39 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail rail$115623 = ((x10.core.Rail)(this.exceptions));
        
        //#line 39 "x10/lang/MultipleExceptions.x10"
        final long size$115624 = ((x10.core.Rail<java.lang.Throwable>)rail$115623).size;
        
        //#line 39 "x10/lang/MultipleExceptions.x10"
        long idx$134095 = 0L;
        {
            
            //#line 39 "x10/lang/MultipleExceptions.x10"
            final java.lang.Throwable[] rail$115623$value$134353 = ((java.lang.Throwable[])rail$115623.value);
            
            //#line 39 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 39 "x10/lang/MultipleExceptions.x10"
                final boolean t$134097 = ((idx$134095) < (((long)(size$115624))));
                
                //#line 39 "x10/lang/MultipleExceptions.x10"
                if (!(t$134097)) {
                    
                    //#line 39 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 39 "x10/lang/MultipleExceptions.x10"
                final java.lang.Throwable t$134092 = ((java.lang.Throwable)(((java.lang.Throwable)rail$115623$value$134353[(int)idx$134095])));
                
                //#line 40 "x10/lang/MultipleExceptions.x10"
                t$134092.printStackTrace();
                
                //#line 39 "x10/lang/MultipleExceptions.x10"
                final long t$134094 = ((idx$134095) + (((long)(1L))));
                
                //#line 39 "x10/lang/MultipleExceptions.x10"
                idx$134095 = t$134094;
            }
        }
    }
    
    
    //#line 44 "x10/lang/MultipleExceptions.x10"
    public static x10.lang.MultipleExceptions make__0$1x10$lang$CheckedThrowable$2(final x10.util.GrowableRail<java.lang.Throwable> es) {
        
        //#line 45 "x10/lang/MultipleExceptions.x10"
        boolean t$133863 = ((null) == (es));
        
        //#line 45 "x10/lang/MultipleExceptions.x10"
        if (!(t$133863)) {
            
            //#line 160 . "x10/util/GrowableRail.x10"
            final long t$133862 = ((x10.util.GrowableRail<java.lang.Throwable>)es).size;
            
            //#line 45 "x10/lang/MultipleExceptions.x10"
            t$133863 = ((long) t$133862) == ((long) 0L);
        }
        
        //#line 45 "x10/lang/MultipleExceptions.x10"
        if (t$133863) {
            
            //#line 45 "x10/lang/MultipleExceptions.x10"
            return null;
        }
        
        //#line 46 "x10/lang/MultipleExceptions.x10"
        final x10.lang.MultipleExceptions t$133865 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(es)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
        
        //#line 46 "x10/lang/MultipleExceptions.x10"
        return t$133865;
    }
    
    
    //#line 49 "x10/lang/MultipleExceptions.x10"
    public static x10.lang.MultipleExceptions make(final java.lang.Throwable t) {
        
        //#line 50 "x10/lang/MultipleExceptions.x10"
        final boolean t$133866 = ((null) == (t));
        
        //#line 50 "x10/lang/MultipleExceptions.x10"
        if (t$133866) {
            
            //#line 50 "x10/lang/MultipleExceptions.x10"
            return null;
        }
        
        //#line 51 "x10/lang/MultipleExceptions.x10"
        final x10.lang.MultipleExceptions t$133867 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((java.lang.Throwable)(t)))));
        
        //#line 51 "x10/lang/MultipleExceptions.x10"
        return t$133867;
    }
    
    
    //#line 61 "x10/lang/MultipleExceptions.x10"
    /** 
     * Gets exceptions of the given type that are nested within this
     * instance of MultipleExceptions.
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     *   associated with nested finish constructs
     * @return a rail containing only the exceptions of the given type 
     */
    final public <$T>x10.core.Rail getExceptionsOfType(final x10.rtt.Type $T, final boolean deep) {
        
        //#line 62 "x10/lang/MultipleExceptions.x10"
        final x10.util.GrowableRail es = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$T>((java.lang.System[]) null, $T)));
        
        //#line 50 . "x10/util/GrowableRail.x10"
        es.x10$util$GrowableRail$$init$S(((long)(0L)));
        
        //#line 63 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail rail$134120 = ((x10.core.Rail)(this.exceptions));
        
        //#line 63 "x10/lang/MultipleExceptions.x10"
        final long size$134121 = ((x10.core.Rail<java.lang.Throwable>)rail$134120).size;
        
        //#line 63 "x10/lang/MultipleExceptions.x10"
        long idx$134117 = 0L;
        {
            
            //#line 63 "x10/lang/MultipleExceptions.x10"
            final java.lang.Throwable[] rail$134120$value$134354 = ((java.lang.Throwable[])rail$134120.value);
            
            //#line 63 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 63 "x10/lang/MultipleExceptions.x10"
                final boolean t$134119 = ((idx$134117) < (((long)(size$134121))));
                
                //#line 63 "x10/lang/MultipleExceptions.x10"
                if (!(t$134119)) {
                    
                    //#line 63 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 63 "x10/lang/MultipleExceptions.x10"
                final java.lang.Throwable e$134114 = ((java.lang.Throwable)(((java.lang.Throwable)rail$134120$value$134354[(int)idx$134117])));
                
                //#line 64 "x10/lang/MultipleExceptions.x10"
                final boolean t$134107 = $T.isInstance(e$134114);
                
                //#line 64 "x10/lang/MultipleExceptions.x10"
                if (t$134107) {
                    
                    //#line 65 "x10/lang/MultipleExceptions.x10"
                    final $T t$134108 = (($T)(x10.rtt.Types.<$T> castConversion(e$134114,$T)));
                    
                    //#line 65 "x10/lang/MultipleExceptions.x10"
                    ((x10.util.GrowableRail<$T>)es).add__0x10$util$GrowableRail$$T((($T)(t$134108)));
                } else {
                    
                    //#line 66 "x10/lang/MultipleExceptions.x10"
                    boolean t$134109 = deep;
                    
                    //#line 66 "x10/lang/MultipleExceptions.x10"
                    if (deep) {
                        
                        //#line 66 "x10/lang/MultipleExceptions.x10"
                        t$134109 = x10.lang.MultipleExceptions.$RTT.isInstance(e$134114);
                    }
                    
                    //#line 66 "x10/lang/MultipleExceptions.x10"
                    if (t$134109) {
                        
                        //#line 67 "x10/lang/MultipleExceptions.x10"
                        final x10.lang.MultipleExceptions this$134111 = ((x10.lang.MultipleExceptions)(x10.rtt.Types.<x10.lang.MultipleExceptions> cast(e$134114,x10.lang.MultipleExceptions.$RTT)));
                        
                        //#line 67 "x10/lang/MultipleExceptions.x10"
                        final x10.core.Rail es$134112 = ((x10.lang.MultipleExceptions)this$134111).<$T> getExceptionsOfType($T, (boolean)(true));
                        
                        //#line 68 "x10/lang/MultipleExceptions.x10"
                        final long size$134106 = ((x10.core.Rail<$T>)es$134112).size;
                        
                        //#line 68 "x10/lang/MultipleExceptions.x10"
                        long idx$134102 = 0L;
                        
                        //#line 68 "x10/lang/MultipleExceptions.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 68 "x10/lang/MultipleExceptions.x10"
                            final boolean t$134104 = ((idx$134102) < (((long)(size$134106))));
                            
                            //#line 68 "x10/lang/MultipleExceptions.x10"
                            if (!(t$134104)) {
                                
                                //#line 68 "x10/lang/MultipleExceptions.x10"
                                break;
                            }
                            
                            //#line 68 "x10/lang/MultipleExceptions.x10"
                            final $T e$134099 = (($T)(((x10.core.Rail<$T>)es$134112).$apply$G((long)(idx$134102))));
                            
                            //#line 68 "x10/lang/MultipleExceptions.x10"
                            ((x10.util.GrowableRail<$T>)es).add__0x10$util$GrowableRail$$T((($T)(e$134099)));
                            
                            //#line 68 "x10/lang/MultipleExceptions.x10"
                            final long t$134101 = ((idx$134102) + (((long)(1L))));
                            
                            //#line 68 "x10/lang/MultipleExceptions.x10"
                            idx$134102 = t$134101;
                        }
                    }
                }
                
                //#line 63 "x10/lang/MultipleExceptions.x10"
                final long t$134116 = ((idx$134117) + (((long)(1L))));
                
                //#line 63 "x10/lang/MultipleExceptions.x10"
                idx$134117 = t$134116;
            }
        }
        
        //#line 72 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail t$133884 = ((x10.core.Rail<$T>)
                                         ((x10.util.GrowableRail<$T>)es).toRail());
        
        //#line 72 "x10/lang/MultipleExceptions.x10"
        return t$133884;
    }
    
    
    //#line 75 "x10/lang/MultipleExceptions.x10"
    final public <$T>x10.core.Rail getExceptionsOfType(final x10.rtt.Type $T) {
        
        //#line 75 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail t$133885 = this.<$T> getExceptionsOfType($T, (boolean)(true));
        
        //#line 75 "x10/lang/MultipleExceptions.x10"
        return t$133885;
    }
    
    
    //#line 86 "x10/lang/MultipleExceptions.x10"
    /** 
     * Gets a copy of this MultipleExceptions instance, with all nested
     * exceptions of the given type removed.
     * This method may be used for example is to filter all DeadPlaceExceptions
     * so that exceptions of other types can be handled separately.
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     *   associated with nested finish constructs
     * @return a new MultipleExceptions, filtering out all exceptions of the given type 
     */
    final public <$T>x10.lang.MultipleExceptions filterExceptionsOfType(final x10.rtt.Type $T, final boolean deep) {
        
        //#line 87 "x10/lang/MultipleExceptions.x10"
        final x10.util.GrowableRail es = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
        
        //#line 50 . "x10/util/GrowableRail.x10"
        es.x10$util$GrowableRail$$init$S(((long)(0L)));
        
        //#line 88 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail rail$134136 = ((x10.core.Rail)(this.exceptions));
        
        //#line 88 "x10/lang/MultipleExceptions.x10"
        final long size$134137 = ((x10.core.Rail<java.lang.Throwable>)rail$134136).size;
        
        //#line 88 "x10/lang/MultipleExceptions.x10"
        long idx$134133 = 0L;
        {
            
            //#line 88 "x10/lang/MultipleExceptions.x10"
            final java.lang.Throwable[] rail$134136$value$134355 = ((java.lang.Throwable[])rail$134136.value);
            
            //#line 88 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 88 "x10/lang/MultipleExceptions.x10"
                final boolean t$134135 = ((idx$134133) < (((long)(size$134137))));
                
                //#line 88 "x10/lang/MultipleExceptions.x10"
                if (!(t$134135)) {
                    
                    //#line 88 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 88 "x10/lang/MultipleExceptions.x10"
                final java.lang.Throwable e$134130 = ((java.lang.Throwable)(((java.lang.Throwable)rail$134136$value$134355[(int)idx$134133])));
                
                //#line 89 "x10/lang/MultipleExceptions.x10"
                boolean t$134122 = deep;
                
                //#line 89 "x10/lang/MultipleExceptions.x10"
                if (deep) {
                    
                    //#line 89 "x10/lang/MultipleExceptions.x10"
                    t$134122 = x10.lang.MultipleExceptions.$RTT.isInstance(e$134130);
                }
                
                //#line 89 "x10/lang/MultipleExceptions.x10"
                if (t$134122) {
                    
                    //#line 90 "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions this$134124 = ((x10.lang.MultipleExceptions)(x10.rtt.Types.<x10.lang.MultipleExceptions> cast(e$134130,x10.lang.MultipleExceptions.$RTT)));
                    
                    //#line 90 "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions me$134125 = ((x10.lang.MultipleExceptions)this$134124).<$T> filterExceptionsOfType($T, (boolean)(true));
                    
                    //#line 91 "x10/lang/MultipleExceptions.x10"
                    final boolean t$134126 = ((me$134125) != (null));
                    
                    //#line 91 "x10/lang/MultipleExceptions.x10"
                    if (t$134126) {
                        
                        //#line 91 "x10/lang/MultipleExceptions.x10"
                        ((x10.util.GrowableRail<java.lang.Throwable>)es).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(me$134125)));
                    }
                } else {
                    
                    //#line 92 "x10/lang/MultipleExceptions.x10"
                    final boolean t$134127 = $T.isInstance(e$134130);
                    
                    //#line 92 "x10/lang/MultipleExceptions.x10"
                    final boolean t$134128 = !(t$134127);
                    
                    //#line 92 "x10/lang/MultipleExceptions.x10"
                    if (t$134128) {
                        
                        //#line 93 "x10/lang/MultipleExceptions.x10"
                        ((x10.util.GrowableRail<java.lang.Throwable>)es).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(e$134130)));
                    }
                }
                
                //#line 88 "x10/lang/MultipleExceptions.x10"
                final long t$134132 = ((idx$134133) + (((long)(1L))));
                
                //#line 88 "x10/lang/MultipleExceptions.x10"
                idx$134133 = t$134132;
            }
        }
        
        //#line 97 "x10/lang/MultipleExceptions.x10"
        final x10.lang.MultipleExceptions t$133897 = x10.lang.MultipleExceptions.make__0$1x10$lang$CheckedThrowable$2(((x10.util.GrowableRail)(es)));
        
        //#line 97 "x10/lang/MultipleExceptions.x10"
        return t$133897;
    }
    
    
    //#line 100 "x10/lang/MultipleExceptions.x10"
    final public <$T>x10.lang.MultipleExceptions filterExceptionsOfType(final x10.rtt.Type $T) {
        
        //#line 100 "x10/lang/MultipleExceptions.x10"
        final x10.lang.MultipleExceptions t$133898 = this.<$T> filterExceptionsOfType($T, (boolean)(true));
        
        //#line 100 "x10/lang/MultipleExceptions.x10"
        return t$133898;
    }
    
    
    //#line 113 "x10/lang/MultipleExceptions.x10"
    /**
     * Gets a copy of this MultipleExceptions instance where the
     * nesting of MultipleExceptions is flatten. It means that
     * exceptions that was included inside a nested MultipleExceptions
     * are now in the toplevel MultipleExceptions dans that the
     * toplevel MultipleExceptions do not contains other
     * MultipleExceptions.
     * @param me the MultipleExceptions to flatten
     * @return a new MultipleExceptions without neted MultipleExceptions
     */
    final public x10.lang.MultipleExceptions flatten() {
        
        //#line 114 "x10/lang/MultipleExceptions.x10"
        final x10.util.GrowableRail exns = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
        
        //#line 50 . "x10/util/GrowableRail.x10"
        exns.x10$util$GrowableRail$$init$S(((long)(0L)));
        
        //#line 115 "x10/lang/MultipleExceptions.x10"
        x10.lang.MultipleExceptions.flattenAux__1$1x10$lang$CheckedThrowable$2(((x10.lang.MultipleExceptions)(this)), ((x10.util.GrowableRail)(exns)));
        
        //#line 116 "x10/lang/MultipleExceptions.x10"
        final x10.lang.MultipleExceptions t$133899 = x10.lang.MultipleExceptions.make__0$1x10$lang$CheckedThrowable$2(((x10.util.GrowableRail)(exns)));
        
        //#line 116 "x10/lang/MultipleExceptions.x10"
        return t$133899;
    }
    
    
    //#line 119 "x10/lang/MultipleExceptions.x10"
    private static void flattenAux__1$1x10$lang$CheckedThrowable$2(final x10.lang.MultipleExceptions me, final x10.util.GrowableRail<java.lang.Throwable> acc) {
        
        //#line 120 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail rail$115723 = ((x10.core.Rail)(me.exceptions));
        
        //#line 120 "x10/lang/MultipleExceptions.x10"
        final long size$115724 = ((x10.core.Rail<java.lang.Throwable>)rail$115723).size;
        
        //#line 120 "x10/lang/MultipleExceptions.x10"
        long idx$134144 = 0L;
        {
            
            //#line 120 "x10/lang/MultipleExceptions.x10"
            final java.lang.Throwable[] rail$115723$value$134356 = ((java.lang.Throwable[])rail$115723.value);
            
            //#line 120 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 120 "x10/lang/MultipleExceptions.x10"
                final boolean t$134146 = ((idx$134144) < (((long)(size$115724))));
                
                //#line 120 "x10/lang/MultipleExceptions.x10"
                if (!(t$134146)) {
                    
                    //#line 120 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 120 "x10/lang/MultipleExceptions.x10"
                final java.lang.Throwable e$134141 = ((java.lang.Throwable)(((java.lang.Throwable)rail$115723$value$134356[(int)idx$134144])));
                
                //#line 121 "x10/lang/MultipleExceptions.x10"
                final boolean t$134138 = x10.lang.MultipleExceptions.$RTT.isInstance(e$134141);
                
                //#line 121 "x10/lang/MultipleExceptions.x10"
                if (t$134138) {
                    
                    //#line 122 "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134139 = ((x10.lang.MultipleExceptions)(x10.rtt.Types.<x10.lang.MultipleExceptions> cast(e$134141,x10.lang.MultipleExceptions.$RTT)));
                    
                    //#line 122 "x10/lang/MultipleExceptions.x10"
                    x10.lang.MultipleExceptions.flattenAux__1$1x10$lang$CheckedThrowable$2(((x10.lang.MultipleExceptions)(t$134139)), ((x10.util.GrowableRail)(acc)));
                } else {
                    
                    //#line 124 "x10/lang/MultipleExceptions.x10"
                    ((x10.util.GrowableRail<java.lang.Throwable>)acc).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(e$134141)));
                }
                
                //#line 120 "x10/lang/MultipleExceptions.x10"
                final long t$134143 = ((idx$134144) + (((long)(1L))));
                
                //#line 120 "x10/lang/MultipleExceptions.x10"
                idx$134144 = t$134143;
            }
        }
    }
    
    public static void flattenAux$P__1$1x10$lang$CheckedThrowable$2(final x10.lang.MultipleExceptions me, final x10.util.GrowableRail<java.lang.Throwable> acc) {
        x10.lang.MultipleExceptions.flattenAux__1$1x10$lang$CheckedThrowable$2(((x10.lang.MultipleExceptions)(me)), ((x10.util.GrowableRail)(acc)));
    }
    
    
    //#line 130 "x10/lang/MultipleExceptions.x10"
    final private <$T>void splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2(final x10.rtt.Type $T, final boolean deep, final x10.util.GrowableRail accT, final x10.util.GrowableRail accNotT) {
        
        //#line 132 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail rail$115748 = ((x10.core.Rail)(this.exceptions));
        
        //#line 132 "x10/lang/MultipleExceptions.x10"
        final long size$115749 = ((x10.core.Rail<java.lang.Throwable>)rail$115748).size;
        
        //#line 132 "x10/lang/MultipleExceptions.x10"
        long idx$134156 = 0L;
        {
            
            //#line 132 "x10/lang/MultipleExceptions.x10"
            final java.lang.Throwable[] rail$115748$value$134357 = ((java.lang.Throwable[])rail$115748.value);
            
            //#line 132 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 132 "x10/lang/MultipleExceptions.x10"
                final boolean t$134158 = ((idx$134156) < (((long)(size$115749))));
                
                //#line 132 "x10/lang/MultipleExceptions.x10"
                if (!(t$134158)) {
                    
                    //#line 132 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 132 "x10/lang/MultipleExceptions.x10"
                final java.lang.Throwable e$134153 = ((java.lang.Throwable)(((java.lang.Throwable)rail$115748$value$134357[(int)idx$134156])));
                
                //#line 133 "x10/lang/MultipleExceptions.x10"
                boolean t$134147 = deep;
                
                //#line 133 "x10/lang/MultipleExceptions.x10"
                if (deep) {
                    
                    //#line 133 "x10/lang/MultipleExceptions.x10"
                    t$134147 = x10.lang.MultipleExceptions.$RTT.isInstance(e$134153);
                }
                
                //#line 133 "x10/lang/MultipleExceptions.x10"
                if (t$134147) {
                    
                    //#line 134 "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134149 = ((x10.lang.MultipleExceptions)(x10.rtt.Types.<x10.lang.MultipleExceptions> cast(e$134153,x10.lang.MultipleExceptions.$RTT)));
                    
                    //#line 134 "x10/lang/MultipleExceptions.x10"
                    ((x10.lang.MultipleExceptions)t$134149).<$T> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($T, (boolean)(deep), ((x10.util.GrowableRail)(accT)), ((x10.util.GrowableRail)(accNotT)));
                } else {
                    
                    //#line 135 "x10/lang/MultipleExceptions.x10"
                    final boolean t$134150 = $T.isInstance(e$134153);
                    
                    //#line 135 "x10/lang/MultipleExceptions.x10"
                    if (t$134150) {
                        
                        //#line 136 "x10/lang/MultipleExceptions.x10"
                        final $T t$134151 = (($T)(x10.rtt.Types.<$T> castConversion(e$134153,$T)));
                        
                        //#line 136 "x10/lang/MultipleExceptions.x10"
                        ((x10.util.GrowableRail<$T>)accT).add__0x10$util$GrowableRail$$T((($T)(t$134151)));
                    } else {
                        
                        //#line 138 "x10/lang/MultipleExceptions.x10"
                        ((x10.util.GrowableRail<java.lang.Throwable>)accNotT).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(e$134153)));
                    }
                }
                
                //#line 132 "x10/lang/MultipleExceptions.x10"
                final long t$134155 = ((idx$134156) + (((long)(1L))));
                
                //#line 132 "x10/lang/MultipleExceptions.x10"
                idx$134156 = t$134155;
            }
        }
    }
    
    final public static <$T>void splitExceptionsOfType$P__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2(final x10.rtt.Type $T, final boolean deep, final x10.util.GrowableRail<$T> accT, final x10.util.GrowableRail<java.lang.Throwable> accNotT, final x10.lang.MultipleExceptions MultipleExceptions) {
        ((x10.lang.MultipleExceptions)MultipleExceptions).<$T> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($T, (boolean)(deep), ((x10.util.GrowableRail)(accT)), ((x10.util.GrowableRail)(accNotT)));
    }
    
    
    //#line 220 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the handler on the rail containing all the exceptions
     * of type E that was in the MultipleExceptions. The remaining
     * exceptions are re-thrown in a MultipleExceptions. For example,
     * the following code prints the number of exceptions of type
     * UnsupportedOperationException. Here, the value 2 is printed and
     * the exception of type IllegalOperationException is re-thrown in
     * a MultipleExceptions.
     *
     *    MultipleExceptions.try(true) {
     *      finish {
     *        async { throw new UnsupportedOperationException(); }
     *        finish {
     *          async { throw new UnsupportedOperationException(); }
     *          async { throw new IllegalOperationException(); }
     *        }
     *      }
     *    } catch (t: Rail[UnsupportedOperationException]) {
     *        Console.OUT.println(t.size);
     *    }
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler the body of the exception handler
     *
     */
    public static <$E>void kwd_try__2$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E$2$2(final x10.rtt.Type $E, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>> handler) {
        
        //#line 223 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 223 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 225 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 226 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 227 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(deep), ((x10.util.GrowableRail)(exns)), ((x10.util.GrowableRail)(others)));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$133919 = ((x10.util.GrowableRail<$E>)exns).size;
            
            //#line 228 "x10/lang/MultipleExceptions.x10"
            final boolean t$133921 = ((t$133919) > (((long)(0L))));
            
            //#line 228 "x10/lang/MultipleExceptions.x10"
            if (t$133921) {
                
                //#line 228 "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$133920 = ((x10.core.Rail<$E>)
                                                 ((x10.util.GrowableRail<$E>)exns).toRail());
                
                //#line 228 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>>)handler).$apply(t$133920, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E));
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$133922 = ((x10.util.GrowableRail<java.lang.Throwable>)others).size;
            
            //#line 229 "x10/lang/MultipleExceptions.x10"
            final boolean t$133924 = ((t$133922) > (((long)(0L))));
            
            //#line 229 "x10/lang/MultipleExceptions.x10"
            if (t$133924) {
                
                //#line 229 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$133923 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 229 "x10/lang/MultipleExceptions.x10"
                throw t$133923;
            }
        }
    }
    
    
    //#line 246 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the handler on the rail
     * containing all the exceptions of type E that was in the
     * MultipleExceptions. The remaining exceptions are re-thrown
     * in a MultipleExceptions.
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler the body of the exception handler
     * @param finallyBlock the body of finally block
     *
     */
    public static <$E>void kwd_try__2$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E$2$2(final x10.rtt.Type $E, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>> handler, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 250 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 250 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 252 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 253 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 254 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(deep), ((x10.util.GrowableRail)(exns)), ((x10.util.GrowableRail)(others)));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$133925 = ((x10.util.GrowableRail<$E>)exns).size;
            
            //#line 255 "x10/lang/MultipleExceptions.x10"
            final boolean t$133927 = ((t$133925) > (((long)(0L))));
            
            //#line 255 "x10/lang/MultipleExceptions.x10"
            if (t$133927) {
                
                //#line 255 "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$133926 = ((x10.core.Rail<$E>)
                                                 ((x10.util.GrowableRail<$E>)exns).toRail());
                
                //#line 255 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>>)handler).$apply(t$133926, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E));
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$133928 = ((x10.util.GrowableRail<java.lang.Throwable>)others).size;
            
            //#line 256 "x10/lang/MultipleExceptions.x10"
            final boolean t$133930 = ((t$133928) > (((long)(0L))));
            
            //#line 256 "x10/lang/MultipleExceptions.x10"
            if (t$133930) {
                
                //#line 256 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$133929 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 256 "x10/lang/MultipleExceptions.x10"
                throw t$133929;
            }
        }finally {{
             
             //#line 258 "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 272 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the handler on the rail containing all the exceptions
     * of type E that was in the MultipleExceptions and the nested
     * nested ones. The remaining exceptions are re-thrown in a
     * MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler the body of the exception handler
     *
     */
    public static <$E>void kwd_try__1$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E$2$2(final x10.rtt.Type $E, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>> handler) {
        
        //#line 223 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 223 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134159) {
            
            //#line 225 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134160 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134160.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 226 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134161 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134161.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 227 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134159).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(true), ((x10.util.GrowableRail)(exns$134160)), ((x10.util.GrowableRail)(others$134161)));
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134162 = ((x10.util.GrowableRail<$E>)exns$134160).size;
            
            //#line 228 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134163 = ((t$134162) > (((long)(0L))));
            
            //#line 228 . "x10/lang/MultipleExceptions.x10"
            if (t$134163) {
                
                //#line 228 . "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134164 = ((x10.core.Rail<$E>)
                                                 ((x10.util.GrowableRail<$E>)exns$134160).toRail());
                
                //#line 228 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>>)handler).$apply(t$134164, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E));
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134165 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134161).size;
            
            //#line 229 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134166 = ((t$134165) > (((long)(0L))));
            
            //#line 229 . "x10/lang/MultipleExceptions.x10"
            if (t$134166) {
                
                //#line 229 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134167 = true;
                
                //#line 229 . "x10/lang/MultipleExceptions.x10"
                if (t$134167) {
                    
                    //#line 229 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134168 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134161)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 229 . "x10/lang/MultipleExceptions.x10"
                    throw t$134168;
                }
            }
        }
    }
    
    
    //#line 289 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the handler on the rail
     * containing all the exceptions of type E that was in the
     * MultipleExceptions and the nested nested ones. The remaining
     * exceptions are re-thrown in a MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler the body of the exception handler
     * @param finallyBlock the body of finally block
     *
     */
    public static <$E>void kwd_try__1$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E$2$2(final x10.rtt.Type $E, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>> handler, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 250 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 250 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134169) {
            
            //#line 252 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134170 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134170.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 253 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134171 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134171.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 254 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134169).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(true), ((x10.util.GrowableRail)(exns$134170)), ((x10.util.GrowableRail)(others$134171)));
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134172 = ((x10.util.GrowableRail<$E>)exns$134170).size;
            
            //#line 255 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134173 = ((t$134172) > (((long)(0L))));
            
            //#line 255 . "x10/lang/MultipleExceptions.x10"
            if (t$134173) {
                
                //#line 255 . "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134174 = ((x10.core.Rail<$E>)
                                                 ((x10.util.GrowableRail<$E>)exns$134170).toRail());
                
                //#line 255 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>>)handler).$apply(t$134174, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E));
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134175 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134171).size;
            
            //#line 256 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134176 = ((t$134175) > (((long)(0L))));
            
            //#line 256 . "x10/lang/MultipleExceptions.x10"
            if (t$134176) {
                
                //#line 256 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134177 = true;
                
                //#line 256 . "x10/lang/MultipleExceptions.x10"
                if (t$134177) {
                    
                    //#line 256 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134178 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134171)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 256 . "x10/lang/MultipleExceptions.x10"
                    throw t$134178;
                }
            }
        }finally {{
             
             //#line 258 . "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 310 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the first handler on the rail containing all the
     * exceptions of type E1 and the second handler on the rail
     * containing all the exceptions of type E2 that was in the
     * MultipleExceptions. The remaining exceptions are re-thrown in a
     * MultipleExceptions.
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__2$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E1$2$2__3$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E2$2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>> handler1, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>> handler2) {
        
        //#line 314 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 314 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 316 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 317 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 318 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(deep), ((x10.util.GrowableRail)(exns1)), ((x10.util.GrowableRail)(others1)));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$133945 = ((x10.util.GrowableRail<$E1>)exns1).size;
            
            //#line 319 "x10/lang/MultipleExceptions.x10"
            final boolean t$133947 = ((t$133945) > (((long)(0L))));
            
            //#line 319 "x10/lang/MultipleExceptions.x10"
            if (t$133947) {
                
                //#line 319 "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$133946 = ((x10.core.Rail<$E1>)
                                                 ((x10.util.GrowableRail<$E1>)exns1).toRail());
                
                //#line 319 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>>)handler1).$apply(t$133946, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E1));
            }
            
            //#line 320 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 321 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 322 "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$133948 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others1)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 322 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$133948).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(deep), ((x10.util.GrowableRail)(exns2)), ((x10.util.GrowableRail)(others2)));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$133949 = ((x10.util.GrowableRail<$E2>)exns2).size;
            
            //#line 323 "x10/lang/MultipleExceptions.x10"
            final boolean t$133951 = ((t$133949) > (((long)(0L))));
            
            //#line 323 "x10/lang/MultipleExceptions.x10"
            if (t$133951) {
                
                //#line 323 "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$133950 = ((x10.core.Rail<$E2>)
                                                 ((x10.util.GrowableRail<$E2>)exns2).toRail());
                
                //#line 323 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>>)handler2).$apply(t$133950, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E2));
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$133952 = ((x10.util.GrowableRail<java.lang.Throwable>)others2).size;
            
            //#line 324 "x10/lang/MultipleExceptions.x10"
            final boolean t$133954 = ((t$133952) > (((long)(0L))));
            
            //#line 324 "x10/lang/MultipleExceptions.x10"
            if (t$133954) {
                
                //#line 324 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$133953 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others2)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 324 "x10/lang/MultipleExceptions.x10"
                throw t$133953;
            }
        }
    }
    
    
    //#line 343 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the first handler on the rail
     * containing all the exceptions of type E1 and the second handler
     * on the rail containing all the exceptions of type E2 that was
     * in the MultipleExceptions. The remaining exceptions are
     * re-thrown in a MultipleExceptions.
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__2$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E1$2$2__3$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E2$2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>> handler1, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>> handler2, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 348 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 348 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 350 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 351 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 352 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(deep), ((x10.util.GrowableRail)(exns1)), ((x10.util.GrowableRail)(others1)));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$133955 = ((x10.util.GrowableRail<$E1>)exns1).size;
            
            //#line 353 "x10/lang/MultipleExceptions.x10"
            final boolean t$133957 = ((t$133955) > (((long)(0L))));
            
            //#line 353 "x10/lang/MultipleExceptions.x10"
            if (t$133957) {
                
                //#line 353 "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$133956 = ((x10.core.Rail<$E1>)
                                                 ((x10.util.GrowableRail<$E1>)exns1).toRail());
                
                //#line 353 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>>)handler1).$apply(t$133956, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E1));
            }
            
            //#line 354 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 355 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 356 "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$133958 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others1)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 356 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$133958).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(deep), ((x10.util.GrowableRail)(exns2)), ((x10.util.GrowableRail)(others2)));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$133959 = ((x10.util.GrowableRail<$E2>)exns2).size;
            
            //#line 357 "x10/lang/MultipleExceptions.x10"
            final boolean t$133961 = ((t$133959) > (((long)(0L))));
            
            //#line 357 "x10/lang/MultipleExceptions.x10"
            if (t$133961) {
                
                //#line 357 "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$133960 = ((x10.core.Rail<$E2>)
                                                 ((x10.util.GrowableRail<$E2>)exns2).toRail());
                
                //#line 357 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>>)handler2).$apply(t$133960, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E2));
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$133962 = ((x10.util.GrowableRail<java.lang.Throwable>)others2).size;
            
            //#line 358 "x10/lang/MultipleExceptions.x10"
            final boolean t$133964 = ((t$133962) > (((long)(0L))));
            
            //#line 358 "x10/lang/MultipleExceptions.x10"
            if (t$133964) {
                
                //#line 358 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$133963 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others2)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 358 "x10/lang/MultipleExceptions.x10"
                throw t$133963;
            }
        }finally {{
             
             //#line 359 "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 375 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the first handler on the rail containing all the
     * exceptions of type E1 and the second handler on the rail
     * containing all the exceptions of type E2 that was in the
     * MultipleExceptions and the nested nested ones. The remaining
     * exceptions are re-thrown in a MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__1$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E1$2$2__2$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E2$2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>> handler1, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>> handler2) {
        
        //#line 314 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 314 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134179) {
            
            //#line 316 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134180 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134180.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 317 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134181 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134181.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 318 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134179).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(true), ((x10.util.GrowableRail)(exns$134180)), ((x10.util.GrowableRail)(others$134181)));
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134182 = ((x10.util.GrowableRail<$E1>)exns$134180).size;
            
            //#line 319 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134183 = ((t$134182) > (((long)(0L))));
            
            //#line 319 . "x10/lang/MultipleExceptions.x10"
            if (t$134183) {
                
                //#line 319 . "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134184 = ((x10.core.Rail<$E1>)
                                                 ((x10.util.GrowableRail<$E1>)exns$134180).toRail());
                
                //#line 319 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>>)handler1).$apply(t$134184, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E1));
            }
            
            //#line 320 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134185 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134185.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 321 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134186 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134186.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 322 . "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$134187 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134181)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 322 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$134187).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(true), ((x10.util.GrowableRail)(exns$134185)), ((x10.util.GrowableRail)(others$134186)));
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134188 = ((x10.util.GrowableRail<$E2>)exns$134185).size;
            
            //#line 323 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134189 = ((t$134188) > (((long)(0L))));
            
            //#line 323 . "x10/lang/MultipleExceptions.x10"
            if (t$134189) {
                
                //#line 323 . "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134190 = ((x10.core.Rail<$E2>)
                                                 ((x10.util.GrowableRail<$E2>)exns$134185).toRail());
                
                //#line 323 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>>)handler2).$apply(t$134190, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E2));
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134191 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134186).size;
            
            //#line 324 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134192 = ((t$134191) > (((long)(0L))));
            
            //#line 324 . "x10/lang/MultipleExceptions.x10"
            if (t$134192) {
                
                //#line 324 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134193 = true;
                
                //#line 324 . "x10/lang/MultipleExceptions.x10"
                if (t$134193) {
                    
                    //#line 324 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134194 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134186)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 324 . "x10/lang/MultipleExceptions.x10"
                    throw t$134194;
                }
            }
        }
    }
    
    
    //#line 394 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the first handler on the rail
     * containing all the exceptions of type E1 and the second handler
     * on the rail containing all the exceptions of type E2 that was
     * in the MultipleExceptions and the nested nested ones. The
     * remaining exceptions are re-thrown in a MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__1$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E1$2$2__2$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E2$2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>> handler1, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>> handler2, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 348 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 348 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134195) {
            
            //#line 350 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134196 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134196.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 351 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134197 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134197.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 352 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134195).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(true), ((x10.util.GrowableRail)(exns$134196)), ((x10.util.GrowableRail)(others$134197)));
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134198 = ((x10.util.GrowableRail<$E1>)exns$134196).size;
            
            //#line 353 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134199 = ((t$134198) > (((long)(0L))));
            
            //#line 353 . "x10/lang/MultipleExceptions.x10"
            if (t$134199) {
                
                //#line 353 . "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134200 = ((x10.core.Rail<$E1>)
                                                 ((x10.util.GrowableRail<$E1>)exns$134196).toRail());
                
                //#line 353 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>>)handler1).$apply(t$134200, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E1));
            }
            
            //#line 354 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134201 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134201.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 355 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134202 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134202.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 356 . "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$134203 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134197)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 356 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$134203).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(true), ((x10.util.GrowableRail)(exns$134201)), ((x10.util.GrowableRail)(others$134202)));
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134204 = ((x10.util.GrowableRail<$E2>)exns$134201).size;
            
            //#line 357 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134205 = ((t$134204) > (((long)(0L))));
            
            //#line 357 . "x10/lang/MultipleExceptions.x10"
            if (t$134205) {
                
                //#line 357 . "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134206 = ((x10.core.Rail<$E2>)
                                                 ((x10.util.GrowableRail<$E2>)exns$134201).toRail());
                
                //#line 357 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>>)handler2).$apply(t$134206, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E2));
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134207 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134202).size;
            
            //#line 358 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134208 = ((t$134207) > (((long)(0L))));
            
            //#line 358 . "x10/lang/MultipleExceptions.x10"
            if (t$134208) {
                
                //#line 358 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134209 = true;
                
                //#line 358 . "x10/lang/MultipleExceptions.x10"
                if (t$134209) {
                    
                    //#line 358 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134210 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134202)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 358 . "x10/lang/MultipleExceptions.x10"
                    throw t$134210;
                }
            }
        }finally {{
             
             //#line 359 . "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 428 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the handler on each exception of type E that was in
     * the MultipleExceptions. The remaining exceptions are re-thrown
     * in a MultipleExceptions. For example, the following code prints
     * twice the message "UnsupportedOperationException catched" and
     * the exception of type IllegalOperationException is re-thrown in
     * a MultipleExceptions.
     *
     *    MultipleExceptions.try(true) {
     *      finish {
     *        async { throw new UnsupportedOperationException(); }
     *        finish {
     *          async { throw new UnsupportedOperationException(); }
     *          async { throw new IllegalOperationException(); }
     *        }
     *      }
     *    } catch (UnsupportedOperationException) {
     *        Console.OUT.println("UnsupportedOperationException catched");
     *    }
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler the body of the exception handler
     *
     */
    public static <$E>void kwd_try__2$1x10$lang$MultipleExceptions$$E$2(final x10.rtt.Type $E, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E> handler) {
        
        //#line 431 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 431 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 433 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 434 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 435 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(deep), ((x10.util.GrowableRail)(exns)), ((x10.util.GrowableRail)(others)));
            
            //#line 436 "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134218 = ((x10.core.Rail<$E>)
                                                ((x10.util.GrowableRail<$E>)exns).toRail());
            
            //#line 436 "x10/lang/MultipleExceptions.x10"
            final long size$134219 = ((x10.core.Rail<$E>)rail$134218).size;
            
            //#line 436 "x10/lang/MultipleExceptions.x10"
            long idx$134215 = 0L;
            
            //#line 436 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 436 "x10/lang/MultipleExceptions.x10"
                final boolean t$134217 = ((idx$134215) < (((long)(size$134219))));
                
                //#line 436 "x10/lang/MultipleExceptions.x10"
                if (!(t$134217)) {
                    
                    //#line 436 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 436 "x10/lang/MultipleExceptions.x10"
                final $E e$134212 = (($E)(((x10.core.Rail<$E>)rail$134218).$apply$G((long)(idx$134215))));
                
                //#line 437 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E>)handler).$apply(e$134212, $E);
                
                //#line 436 "x10/lang/MultipleExceptions.x10"
                final long t$134214 = ((idx$134215) + (((long)(1L))));
                
                //#line 436 "x10/lang/MultipleExceptions.x10"
                idx$134215 = t$134214;
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$133993 = ((x10.util.GrowableRail<java.lang.Throwable>)others).size;
            
            //#line 439 "x10/lang/MultipleExceptions.x10"
            final boolean t$133995 = ((t$133993) > (((long)(0L))));
            
            //#line 439 "x10/lang/MultipleExceptions.x10"
            if (t$133995) {
                
                //#line 439 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$133994 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 439 "x10/lang/MultipleExceptions.x10"
                throw t$133994;
            }
        }
    }
    
    
    //#line 455 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the handler on each exception
     * of type E that was in the MultipleExceptions. The remaining
     * exceptions are re-thrown in a MultipleExceptions.
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler the body of the exception handler
     * @param finallyBlock the body of finally block
     *
     */
    public static <$E>void kwd_try__2$1x10$lang$MultipleExceptions$$E$2(final x10.rtt.Type $E, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E> handler, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 459 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 459 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 461 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 462 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 463 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(deep), ((x10.util.GrowableRail)(exns)), ((x10.util.GrowableRail)(others)));
            
            //#line 464 "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134227 = ((x10.core.Rail<$E>)
                                                ((x10.util.GrowableRail<$E>)exns).toRail());
            
            //#line 464 "x10/lang/MultipleExceptions.x10"
            final long size$134228 = ((x10.core.Rail<$E>)rail$134227).size;
            
            //#line 464 "x10/lang/MultipleExceptions.x10"
            long idx$134224 = 0L;
            
            //#line 464 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 464 "x10/lang/MultipleExceptions.x10"
                final boolean t$134226 = ((idx$134224) < (((long)(size$134228))));
                
                //#line 464 "x10/lang/MultipleExceptions.x10"
                if (!(t$134226)) {
                    
                    //#line 464 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 464 "x10/lang/MultipleExceptions.x10"
                final $E e$134221 = (($E)(((x10.core.Rail<$E>)rail$134227).$apply$G((long)(idx$134224))));
                
                //#line 465 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E>)handler).$apply(e$134221, $E);
                
                //#line 464 "x10/lang/MultipleExceptions.x10"
                final long t$134223 = ((idx$134224) + (((long)(1L))));
                
                //#line 464 "x10/lang/MultipleExceptions.x10"
                idx$134224 = t$134223;
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134002 = ((x10.util.GrowableRail<java.lang.Throwable>)others).size;
            
            //#line 467 "x10/lang/MultipleExceptions.x10"
            final boolean t$134004 = ((t$134002) > (((long)(0L))));
            
            //#line 467 "x10/lang/MultipleExceptions.x10"
            if (t$134004) {
                
                //#line 467 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$134003 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 467 "x10/lang/MultipleExceptions.x10"
                throw t$134003;
            }
        }finally {{
             
             //#line 469 "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 483 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the handler on each exception of type E that was in
     * the MultipleExceptions and the nested nested ones. The
     * remaining exceptions are re-thrown in a MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler the body of the exception handler
     *
     */
    public static <$E>void kwd_try__1$1x10$lang$MultipleExceptions$$E$2(final x10.rtt.Type $E, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E> handler) {
        
        //#line 431 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 431 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134238) {
            
            //#line 433 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134239 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134239.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 434 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134240 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134240.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 435 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134238).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(true), ((x10.util.GrowableRail)(exns$134239)), ((x10.util.GrowableRail)(others$134240)));
            
            //#line 436 . "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134236 = ((x10.core.Rail<$E>)
                                                ((x10.util.GrowableRail<$E>)exns$134239).toRail());
            
            //#line 436 . "x10/lang/MultipleExceptions.x10"
            final long size$134237 = ((x10.core.Rail<$E>)rail$134236).size;
            
            //#line 436 . "x10/lang/MultipleExceptions.x10"
            long idx$134233 = 0L;
            
            //#line 436 . "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 436 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134235 = ((idx$134233) < (((long)(size$134237))));
                
                //#line 436 . "x10/lang/MultipleExceptions.x10"
                if (!(t$134235)) {
                    
                    //#line 436 . "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 436 . "x10/lang/MultipleExceptions.x10"
                final $E e$134230 = (($E)(((x10.core.Rail<$E>)rail$134236).$apply$G((long)(idx$134233))));
                
                //#line 437 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E>)handler).$apply(e$134230, $E);
                
                //#line 436 . "x10/lang/MultipleExceptions.x10"
                final long t$134232 = ((idx$134233) + (((long)(1L))));
                
                //#line 436 . "x10/lang/MultipleExceptions.x10"
                idx$134233 = t$134232;
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134241 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134240).size;
            
            //#line 439 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134242 = ((t$134241) > (((long)(0L))));
            
            //#line 439 . "x10/lang/MultipleExceptions.x10"
            if (t$134242) {
                
                //#line 439 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134243 = true;
                
                //#line 439 . "x10/lang/MultipleExceptions.x10"
                if (t$134243) {
                    
                    //#line 439 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134244 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134240)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 439 . "x10/lang/MultipleExceptions.x10"
                    throw t$134244;
                }
            }
        }
    }
    
    
    //#line 500 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the handler on each exception
     * of type E that was in the MultipleExceptions and the nested
     * nested ones. The remaining exceptions are re-thrown in a
     * MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler the body of the exception handler
     * @param finallyBlock the body of finally block
     *
     */
    public static <$E>void kwd_try__1$1x10$lang$MultipleExceptions$$E$2(final x10.rtt.Type $E, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E> handler, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 459 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 459 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134254) {
            
            //#line 461 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134255 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134255.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 462 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134256 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134256.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 463 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134254).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(true), ((x10.util.GrowableRail)(exns$134255)), ((x10.util.GrowableRail)(others$134256)));
            
            //#line 464 . "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134252 = ((x10.core.Rail<$E>)
                                                ((x10.util.GrowableRail<$E>)exns$134255).toRail());
            
            //#line 464 . "x10/lang/MultipleExceptions.x10"
            final long size$134253 = ((x10.core.Rail<$E>)rail$134252).size;
            
            //#line 464 . "x10/lang/MultipleExceptions.x10"
            long idx$134249 = 0L;
            
            //#line 464 . "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 464 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134251 = ((idx$134249) < (((long)(size$134253))));
                
                //#line 464 . "x10/lang/MultipleExceptions.x10"
                if (!(t$134251)) {
                    
                    //#line 464 . "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 464 . "x10/lang/MultipleExceptions.x10"
                final $E e$134246 = (($E)(((x10.core.Rail<$E>)rail$134252).$apply$G((long)(idx$134249))));
                
                //#line 465 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E>)handler).$apply(e$134246, $E);
                
                //#line 464 . "x10/lang/MultipleExceptions.x10"
                final long t$134248 = ((idx$134249) + (((long)(1L))));
                
                //#line 464 . "x10/lang/MultipleExceptions.x10"
                idx$134249 = t$134248;
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134257 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134256).size;
            
            //#line 467 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134258 = ((t$134257) > (((long)(0L))));
            
            //#line 467 . "x10/lang/MultipleExceptions.x10"
            if (t$134258) {
                
                //#line 467 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134259 = true;
                
                //#line 467 . "x10/lang/MultipleExceptions.x10"
                if (t$134259) {
                    
                    //#line 467 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134260 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134256)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 467 . "x10/lang/MultipleExceptions.x10"
                    throw t$134260;
                }
            }
        }finally {{
             
             //#line 469 . "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 520 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the first handler on each exception of type E1 and the
     * second handler on on each exception of type E2 that was in the
     * MultipleExceptions. The remaining exceptions are re-thrown in a
     * MultipleExceptions.
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__2$1x10$lang$MultipleExceptions$$E1$2__3$1x10$lang$MultipleExceptions$$E2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E1> handler1, final x10.core.fun.VoidFun_0_1<$E2> handler2) {
        
        //#line 524 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 524 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 526 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 527 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 528 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(deep), ((x10.util.GrowableRail)(exns1)), ((x10.util.GrowableRail)(others1)));
            
            //#line 529 "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134275 = ((x10.core.Rail<$E1>)
                                                ((x10.util.GrowableRail<$E1>)exns1).toRail());
            
            //#line 529 "x10/lang/MultipleExceptions.x10"
            final long size$134276 = ((x10.core.Rail<$E1>)rail$134275).size;
            
            //#line 529 "x10/lang/MultipleExceptions.x10"
            long idx$134265 = 0L;
            
            //#line 529 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 529 "x10/lang/MultipleExceptions.x10"
                final boolean t$134267 = ((idx$134265) < (((long)(size$134276))));
                
                //#line 529 "x10/lang/MultipleExceptions.x10"
                if (!(t$134267)) {
                    
                    //#line 529 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 529 "x10/lang/MultipleExceptions.x10"
                final $E1 e$134262 = (($E1)(((x10.core.Rail<$E1>)rail$134275).$apply$G((long)(idx$134265))));
                
                //#line 530 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E1>)handler1).$apply(e$134262, $E1);
                
                //#line 529 "x10/lang/MultipleExceptions.x10"
                final long t$134264 = ((idx$134265) + (((long)(1L))));
                
                //#line 529 "x10/lang/MultipleExceptions.x10"
                idx$134265 = t$134264;
            }
            
            //#line 532 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 533 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 534 "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$134031 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others1)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 534 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$134031).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(deep), ((x10.util.GrowableRail)(exns2)), ((x10.util.GrowableRail)(others2)));
            
            //#line 535 "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134277 = ((x10.core.Rail<$E2>)
                                                ((x10.util.GrowableRail<$E2>)exns2).toRail());
            
            //#line 535 "x10/lang/MultipleExceptions.x10"
            final long size$134278 = ((x10.core.Rail<$E2>)rail$134277).size;
            
            //#line 535 "x10/lang/MultipleExceptions.x10"
            long idx$134272 = 0L;
            
            //#line 535 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 535 "x10/lang/MultipleExceptions.x10"
                final boolean t$134274 = ((idx$134272) < (((long)(size$134278))));
                
                //#line 535 "x10/lang/MultipleExceptions.x10"
                if (!(t$134274)) {
                    
                    //#line 535 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 535 "x10/lang/MultipleExceptions.x10"
                final $E2 e$134269 = (($E2)(((x10.core.Rail<$E2>)rail$134277).$apply$G((long)(idx$134272))));
                
                //#line 536 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E2>)handler2).$apply(e$134269, $E2);
                
                //#line 535 "x10/lang/MultipleExceptions.x10"
                final long t$134271 = ((idx$134272) + (((long)(1L))));
                
                //#line 535 "x10/lang/MultipleExceptions.x10"
                idx$134272 = t$134271;
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134038 = ((x10.util.GrowableRail<java.lang.Throwable>)others2).size;
            
            //#line 538 "x10/lang/MultipleExceptions.x10"
            final boolean t$134040 = ((t$134038) > (((long)(0L))));
            
            //#line 538 "x10/lang/MultipleExceptions.x10"
            if (t$134040) {
                
                //#line 538 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$134039 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others2)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 538 "x10/lang/MultipleExceptions.x10"
                throw t$134039;
            }
        }
    }
    
    
    //#line 556 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the first handler on each
     * exception of type E1 and the second handler on each exception
     * of type E2 that was in the MultipleExceptions. The remaining
     * exceptions are re-thrown in a MultipleExceptions.
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__2$1x10$lang$MultipleExceptions$$E1$2__3$1x10$lang$MultipleExceptions$$E2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E1> handler1, final x10.core.fun.VoidFun_0_1<$E2> handler2, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 561 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 561 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 563 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 564 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 565 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(deep), ((x10.util.GrowableRail)(exns1)), ((x10.util.GrowableRail)(others1)));
            
            //#line 566 "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134293 = ((x10.core.Rail<$E1>)
                                                ((x10.util.GrowableRail<$E1>)exns1).toRail());
            
            //#line 566 "x10/lang/MultipleExceptions.x10"
            final long size$134294 = ((x10.core.Rail<$E1>)rail$134293).size;
            
            //#line 566 "x10/lang/MultipleExceptions.x10"
            long idx$134283 = 0L;
            
            //#line 566 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 566 "x10/lang/MultipleExceptions.x10"
                final boolean t$134285 = ((idx$134283) < (((long)(size$134294))));
                
                //#line 566 "x10/lang/MultipleExceptions.x10"
                if (!(t$134285)) {
                    
                    //#line 566 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 566 "x10/lang/MultipleExceptions.x10"
                final $E1 e$134280 = (($E1)(((x10.core.Rail<$E1>)rail$134293).$apply$G((long)(idx$134283))));
                
                //#line 567 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E1>)handler1).$apply(e$134280, $E1);
                
                //#line 566 "x10/lang/MultipleExceptions.x10"
                final long t$134282 = ((idx$134283) + (((long)(1L))));
                
                //#line 566 "x10/lang/MultipleExceptions.x10"
                idx$134283 = t$134282;
            }
            
            //#line 569 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 570 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 571 "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$134047 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others1)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 571 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$134047).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(deep), ((x10.util.GrowableRail)(exns2)), ((x10.util.GrowableRail)(others2)));
            
            //#line 572 "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134295 = ((x10.core.Rail<$E2>)
                                                ((x10.util.GrowableRail<$E2>)exns2).toRail());
            
            //#line 572 "x10/lang/MultipleExceptions.x10"
            final long size$134296 = ((x10.core.Rail<$E2>)rail$134295).size;
            
            //#line 572 "x10/lang/MultipleExceptions.x10"
            long idx$134290 = 0L;
            
            //#line 572 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 572 "x10/lang/MultipleExceptions.x10"
                final boolean t$134292 = ((idx$134290) < (((long)(size$134296))));
                
                //#line 572 "x10/lang/MultipleExceptions.x10"
                if (!(t$134292)) {
                    
                    //#line 572 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 572 "x10/lang/MultipleExceptions.x10"
                final $E2 e$134287 = (($E2)(((x10.core.Rail<$E2>)rail$134295).$apply$G((long)(idx$134290))));
                
                //#line 573 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E2>)handler2).$apply(e$134287, $E2);
                
                //#line 572 "x10/lang/MultipleExceptions.x10"
                final long t$134289 = ((idx$134290) + (((long)(1L))));
                
                //#line 572 "x10/lang/MultipleExceptions.x10"
                idx$134290 = t$134289;
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134054 = ((x10.util.GrowableRail<java.lang.Throwable>)others2).size;
            
            //#line 575 "x10/lang/MultipleExceptions.x10"
            final boolean t$134056 = ((t$134054) > (((long)(0L))));
            
            //#line 575 "x10/lang/MultipleExceptions.x10"
            if (t$134056) {
                
                //#line 575 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$134055 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others2)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 575 "x10/lang/MultipleExceptions.x10"
                throw t$134055;
            }
        }finally {{
             
             //#line 576 "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 591 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the first handler on each exception of type E1 and the
     * second handler on each exception of type E2 that was in the
     * MultipleExceptions and the nested nested ones. The remaining
     * exceptions are re-thrown in a MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__1$1x10$lang$MultipleExceptions$$E1$2__2$1x10$lang$MultipleExceptions$$E2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E1> handler1, final x10.core.fun.VoidFun_0_1<$E2> handler2) {
        
        //#line 524 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 524 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134315) {
            
            //#line 526 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134316 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134316.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 527 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134317 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134317.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 528 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134315).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(true), ((x10.util.GrowableRail)(exns$134316)), ((x10.util.GrowableRail)(others$134317)));
            
            //#line 529 . "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134311 = ((x10.core.Rail<$E1>)
                                                ((x10.util.GrowableRail<$E1>)exns$134316).toRail());
            
            //#line 529 . "x10/lang/MultipleExceptions.x10"
            final long size$134312 = ((x10.core.Rail<$E1>)rail$134311).size;
            
            //#line 529 . "x10/lang/MultipleExceptions.x10"
            long idx$134301 = 0L;
            
            //#line 529 . "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 529 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134303 = ((idx$134301) < (((long)(size$134312))));
                
                //#line 529 . "x10/lang/MultipleExceptions.x10"
                if (!(t$134303)) {
                    
                    //#line 529 . "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 529 . "x10/lang/MultipleExceptions.x10"
                final $E1 e$134298 = (($E1)(((x10.core.Rail<$E1>)rail$134311).$apply$G((long)(idx$134301))));
                
                //#line 530 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E1>)handler1).$apply(e$134298, $E1);
                
                //#line 529 . "x10/lang/MultipleExceptions.x10"
                final long t$134300 = ((idx$134301) + (((long)(1L))));
                
                //#line 529 . "x10/lang/MultipleExceptions.x10"
                idx$134301 = t$134300;
            }
            
            //#line 532 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134318 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134318.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 533 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134319 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134319.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 534 . "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$134320 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134317)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 534 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$134320).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(true), ((x10.util.GrowableRail)(exns$134318)), ((x10.util.GrowableRail)(others$134319)));
            
            //#line 535 . "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134313 = ((x10.core.Rail<$E2>)
                                                ((x10.util.GrowableRail<$E2>)exns$134318).toRail());
            
            //#line 535 . "x10/lang/MultipleExceptions.x10"
            final long size$134314 = ((x10.core.Rail<$E2>)rail$134313).size;
            
            //#line 535 . "x10/lang/MultipleExceptions.x10"
            long idx$134308 = 0L;
            
            //#line 535 . "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 535 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134310 = ((idx$134308) < (((long)(size$134314))));
                
                //#line 535 . "x10/lang/MultipleExceptions.x10"
                if (!(t$134310)) {
                    
                    //#line 535 . "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 535 . "x10/lang/MultipleExceptions.x10"
                final $E2 e$134305 = (($E2)(((x10.core.Rail<$E2>)rail$134313).$apply$G((long)(idx$134308))));
                
                //#line 536 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E2>)handler2).$apply(e$134305, $E2);
                
                //#line 535 . "x10/lang/MultipleExceptions.x10"
                final long t$134307 = ((idx$134308) + (((long)(1L))));
                
                //#line 535 . "x10/lang/MultipleExceptions.x10"
                idx$134308 = t$134307;
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134321 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134319).size;
            
            //#line 538 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134322 = ((t$134321) > (((long)(0L))));
            
            //#line 538 . "x10/lang/MultipleExceptions.x10"
            if (t$134322) {
                
                //#line 538 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134323 = true;
                
                //#line 538 . "x10/lang/MultipleExceptions.x10"
                if (t$134323) {
                    
                    //#line 538 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134324 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134319)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 538 . "x10/lang/MultipleExceptions.x10"
                    throw t$134324;
                }
            }
        }
    }
    
    
    //#line 610 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the first handler on each
     * exception of type E1 and the second handler on each exception
     * of type E2 that was in the MultipleExceptions and the nested
     * nested ones. The remaining exceptions are re-thrown in a
     * MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__1$1x10$lang$MultipleExceptions$$E1$2__2$1x10$lang$MultipleExceptions$$E2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E1> handler1, final x10.core.fun.VoidFun_0_1<$E2> handler2, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 561 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 561 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134343) {
            
            //#line 563 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134344 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134344.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 564 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134345 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134345.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 565 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134343).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(true), ((x10.util.GrowableRail)(exns$134344)), ((x10.util.GrowableRail)(others$134345)));
            
            //#line 566 . "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134339 = ((x10.core.Rail<$E1>)
                                                ((x10.util.GrowableRail<$E1>)exns$134344).toRail());
            
            //#line 566 . "x10/lang/MultipleExceptions.x10"
            final long size$134340 = ((x10.core.Rail<$E1>)rail$134339).size;
            
            //#line 566 . "x10/lang/MultipleExceptions.x10"
            long idx$134329 = 0L;
            
            //#line 566 . "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 566 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134331 = ((idx$134329) < (((long)(size$134340))));
                
                //#line 566 . "x10/lang/MultipleExceptions.x10"
                if (!(t$134331)) {
                    
                    //#line 566 . "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 566 . "x10/lang/MultipleExceptions.x10"
                final $E1 e$134326 = (($E1)(((x10.core.Rail<$E1>)rail$134339).$apply$G((long)(idx$134329))));
                
                //#line 567 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E1>)handler1).$apply(e$134326, $E1);
                
                //#line 566 . "x10/lang/MultipleExceptions.x10"
                final long t$134328 = ((idx$134329) + (((long)(1L))));
                
                //#line 566 . "x10/lang/MultipleExceptions.x10"
                idx$134329 = t$134328;
            }
            
            //#line 569 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134346 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134346.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 570 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134347 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134347.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 571 . "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$134348 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134345)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 571 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$134348).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(true), ((x10.util.GrowableRail)(exns$134346)), ((x10.util.GrowableRail)(others$134347)));
            
            //#line 572 . "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134341 = ((x10.core.Rail<$E2>)
                                                ((x10.util.GrowableRail<$E2>)exns$134346).toRail());
            
            //#line 572 . "x10/lang/MultipleExceptions.x10"
            final long size$134342 = ((x10.core.Rail<$E2>)rail$134341).size;
            
            //#line 572 . "x10/lang/MultipleExceptions.x10"
            long idx$134336 = 0L;
            
            //#line 572 . "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 572 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134338 = ((idx$134336) < (((long)(size$134342))));
                
                //#line 572 . "x10/lang/MultipleExceptions.x10"
                if (!(t$134338)) {
                    
                    //#line 572 . "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 572 . "x10/lang/MultipleExceptions.x10"
                final $E2 e$134333 = (($E2)(((x10.core.Rail<$E2>)rail$134341).$apply$G((long)(idx$134336))));
                
                //#line 573 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E2>)handler2).$apply(e$134333, $E2);
                
                //#line 572 . "x10/lang/MultipleExceptions.x10"
                final long t$134335 = ((idx$134336) + (((long)(1L))));
                
                //#line 572 . "x10/lang/MultipleExceptions.x10"
                idx$134336 = t$134335;
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134349 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134347).size;
            
            //#line 575 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134350 = ((t$134349) > (((long)(0L))));
            
            //#line 575 . "x10/lang/MultipleExceptions.x10"
            if (t$134350) {
                
                //#line 575 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134351 = true;
                
                //#line 575 . "x10/lang/MultipleExceptions.x10"
                if (t$134351) {
                    
                    //#line 575 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134352 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134347)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 575 . "x10/lang/MultipleExceptions.x10"
                    throw t$134352;
                }
            }
        }finally {{
             
             //#line 576 . "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 23 "x10/lang/MultipleExceptions.x10"
    final public x10.lang.MultipleExceptions x10$lang$MultipleExceptions$$this$x10$lang$MultipleExceptions() {
        
        //#line 23 "x10/lang/MultipleExceptions.x10"
        return x10.lang.MultipleExceptions.this;
    }
    
    
    //#line 23 "x10/lang/MultipleExceptions.x10"
    final public void __fieldInitializers_x10_lang_MultipleExceptions() {
        
    }
    }
    
    