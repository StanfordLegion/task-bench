package x10.lang;


/**
 * A struct that adds size information to a GlobalRef[Rail[T]]
 * in order to enable safe DMA operations via Rail.asyncCopy.
 * 
 * The following relationship will always be true, but is not expressible
 * due to limitations of the current implementations of constrained types in X10.
 * <pre>
 * this.size == this.rail().size
 * </pre>
 */
@x10.runtime.impl.java.X10Generated
final public class GlobalRail<$T> extends x10.core.Struct implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<GlobalRail> $RTT = 
        x10.rtt.NamedStructType.<GlobalRail> make("x10.lang.GlobalRail",
                                                  GlobalRail.class,
                                                  1,
                                                  new x10.rtt.Type[] {
                                                      x10.rtt.Types.STRUCT
                                                  });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.rail = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.GlobalRail $_obj = new x10.lang.GlobalRail((java.lang.System[]) null, (x10.rtt.Type) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.rail);
        $serializer.write(this.size);
        
    }
    
    // zero value constructor
    public GlobalRail(final x10.rtt.Type $T, final java.lang.System $dummy) { this.$T = $T; this.size = 0L; this.rail = new x10.core.GlobalRef<x10.core.Rail<$T>>(x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $T), $dummy); }
    
    // constructor just for allocation
    public GlobalRail(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.lang.GlobalRail.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final GlobalRail $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$GlobalRail$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Rail$1x10$lang$GlobalRail$$T$2$2 {}
    
    // properties
    
    //#line 33 "x10/lang/GlobalRail.x10"
    /**
         * The size of the remote rail.
         */
    public long size;
    
    //#line 37 "x10/lang/GlobalRail.x10"
    /**
         * The GlobalRef to the remote rail.
         */
    public x10.core.GlobalRef<x10.core.Rail<$T>> rail;
    

    
    
    //#line 43 "x10/lang/GlobalRail.x10"
    /**
     * The home location of the GlobalRail is equal to rail.home
     */
    final public x10.lang.Place home() {
        
        //#line 43 "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132748 = ((x10.core.GlobalRef)(this.rail));
        
        //#line 43 "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$132749 = ((x10.lang.Place)((t$132748).home));
        
        //#line 43 "x10/lang/GlobalRail.x10"
        return t$132749;
    }
    
    
    //#line 49 "x10/lang/GlobalRail.x10"
    /**
     * Create a GlobalRail wrapping the local Rail argument.
     * @param a The rail object to make accessible remotely.
     */
    // creation method for java code (1-phase java constructor)
    public GlobalRail(final x10.rtt.Type $T, final x10.core.Rail<$T> a, __0$1x10$lang$GlobalRail$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$lang$GlobalRail$$init$S(a, (x10.lang.GlobalRail.__0$1x10$lang$GlobalRail$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.GlobalRail<$T> x10$lang$GlobalRail$$init$S(final x10.core.Rail<$T> a, __0$1x10$lang$GlobalRail$$T$2 $dummy) {
         {
            
            //#line 50 "x10/lang/GlobalRail.x10"
            final long t$132836 = ((x10.core.Rail<$T>)a).size;
            
            //#line 50 "x10/lang/GlobalRail.x10"
            final x10.core.GlobalRef t$132837 = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.core.Rail<$T>>(x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $T), ((x10.core.Rail)(a)), (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
            
            //#line 50 "x10/lang/GlobalRail.x10"
            this.size = t$132836;
            this.rail = t$132837;
            
            {
                
            }
        }
        return this;
    }
    
    
    
    //#line 62 "x10/lang/GlobalRail.x10"
    /** 
     * Called when the Rail referred to by the GlobalRail is no 
     * longer accesible from other places and therefore can
     * be removed from the data sturctures that keep objects
     * alive even when they are not live locally. 
     * Can only be invoked at the place at which the value was
     * created. 
     */
    final public void forget() {
        
        //#line 63 "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132754 = ((x10.core.GlobalRef)(this.rail));
        
        //#line 63 "x10/lang/GlobalRail.x10"
        (((x10.core.GlobalRef<x10.core.Rail<$T>>)(t$132754))).forget();
    }
    
    
    //#line 73 "x10/lang/GlobalRail.x10"
    /**
     * Create a GlobalRail using a raw size and remote rail.  This is unsafe
     * since it may be used to violate the (unenforced) constraint that
     * self.size == self.rail().size.  However it is required internally
     * by the CUDA runtime, where it is accesed directly from C++ to
     * bypass the 'private' and is also used by Unsafe.
     */
    // creation method for java code (1-phase java constructor)
    public GlobalRail(final x10.rtt.Type $T, final long size, final x10.core.GlobalRef<x10.core.Rail<$T>> raw, __1$1x10$lang$Rail$1x10$lang$GlobalRail$$T$2$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$lang$GlobalRail$$init$S(size, raw, (x10.lang.GlobalRail.__1$1x10$lang$Rail$1x10$lang$GlobalRail$$T$2$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.GlobalRail<$T> x10$lang$GlobalRail$$init$S(final long size, final x10.core.GlobalRef<x10.core.Rail<$T>> raw, __1$1x10$lang$Rail$1x10$lang$GlobalRail$$T$2$2 $dummy) {
         {
            
            //#line 74 "x10/lang/GlobalRail.x10"
            this.size = size;
            this.rail = raw;
            
            {
                
            }
        }
        return this;
    }
    
    
    
    //#line 85 "x10/lang/GlobalRail.x10"
    /**
     * Return the element of this rail corresponding to the given index.
     * Can only be called where <code>here == rail.home</code>. 
     * 
     * @param index the given index
     * @return the element of this rail corresponding to the given index.
     */
    final public $T $apply$G(final long index) {
        
        //#line 86 "x10/lang/GlobalRail.x10"
        final x10.core.Rail t$132757 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                          this.$apply())));
        
        //#line 86 "x10/lang/GlobalRail.x10"
        final $T t$132758 = (($T)(((x10.core.Rail<$T>)t$132757).$apply$G((long)(index))));
        
        //#line 86 "x10/lang/GlobalRail.x10"
        return t$132758;
    }
    
    
    //#line 97 "x10/lang/GlobalRail.x10"
    /**
     * Set the element of this rail corresponding to the given index to the given value.
     * Return the new value of the element.
     * Can only  be called where <code>here == rail.home</code>. 
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @return the new value of the element of this rail corresponding to the given index.
     */
    final public $T $set__1x10$lang$GlobalRail$$T$G(final long index, final $T v) {
        
        //#line 98 "x10/lang/GlobalRail.x10"
        final x10.core.Rail t$132761 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                          this.$apply())));
        
        //#line 98 "x10/lang/GlobalRail.x10"
        final $T t$132762 = (($T)(((x10.core.Rail<$T>)t$132761).$set__1x10$lang$Rail$$T$G((long)(index), (($T)(v)))));
        
        //#line 98 "x10/lang/GlobalRail.x10"
        return t$132762;
    }
    
    
    //#line 104 "x10/lang/GlobalRail.x10"
    /**
     * Access the Rail that is encapsulated by this GlobalRail. 
     * Can only  be called where <code>here == rail.home</code>. 
     */
    final public x10.core.Rail $apply() {
        
        //#line 105 "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132765 = ((x10.core.GlobalRef)(this.rail));
        
        //#line 105 "x10/lang/GlobalRail.x10"
        final x10.core.Rail t$132766 = ((x10.core.Rail)((((x10.core.GlobalRef<x10.core.Rail<$T>>)(t$132765))).$apply$G()));
        
        //#line 105 "x10/lang/GlobalRail.x10"
        return t$132766;
    }
    
    
    //#line 119 "x10/lang/GlobalRail.x10"
    final public static void remoteAdd__0$1x10$lang$ULong$2__2$u(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132767 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.ULong>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$132769 = ((x10.lang.Place)((t$132767).home));
        {
            
            //#line 121 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132769)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$111(target, idx, v, (x10.lang.GlobalRail.$Closure$111.__0$1x10$lang$ULong$2__2$u) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 125 "x10/lang/GlobalRail.x10"
    final public static void remoteAdd__0$1x10$lang$Long$2(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132770 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.Long>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$132772 = ((x10.lang.Place)((t$132770).home));
        {
            
            //#line 127 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132772)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$112(target, idx, v, (x10.lang.GlobalRail.$Closure$112.__0$1x10$lang$Long$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 131 "x10/lang/GlobalRail.x10"
    final public static void remoteAnd__0$1x10$lang$ULong$2__2$u(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132773 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.ULong>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$132775 = ((x10.lang.Place)((t$132773).home));
        {
            
            //#line 133 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132775)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$113(target, idx, v, (x10.lang.GlobalRail.$Closure$113.__0$1x10$lang$ULong$2__2$u) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 137 "x10/lang/GlobalRail.x10"
    final public static void remoteAnd__0$1x10$lang$Long$2(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132776 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.Long>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$132778 = ((x10.lang.Place)((t$132776).home));
        {
            
            //#line 139 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132778)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$114(target, idx, v, (x10.lang.GlobalRail.$Closure$114.__0$1x10$lang$Long$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 143 "x10/lang/GlobalRail.x10"
    final public static void remoteOr__0$1x10$lang$ULong$2__2$u(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132779 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.ULong>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$132781 = ((x10.lang.Place)((t$132779).home));
        {
            
            //#line 145 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132781)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$115(target, idx, v, (x10.lang.GlobalRail.$Closure$115.__0$1x10$lang$ULong$2__2$u) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 149 "x10/lang/GlobalRail.x10"
    final public static void remoteOr__0$1x10$lang$Long$2(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132782 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.Long>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$132784 = ((x10.lang.Place)((t$132782).home));
        {
            
            //#line 151 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132784)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$116(target, idx, v, (x10.lang.GlobalRail.$Closure$116.__0$1x10$lang$Long$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 155 "x10/lang/GlobalRail.x10"
    final public static void remoteXor__0$1x10$lang$ULong$2__2$u(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132785 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.ULong>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$132787 = ((x10.lang.Place)((t$132785).home));
        {
            
            //#line 157 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132787)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$117(target, idx, v, (x10.lang.GlobalRail.$Closure$117.__0$1x10$lang$ULong$2__2$u) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 161 "x10/lang/GlobalRail.x10"
    final public static void remoteXor__0$1x10$lang$Long$2(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132788 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.Long>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$132790 = ((x10.lang.Place)((t$132788).home));
        {
            
            //#line 163 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132790)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$118(target, idx, v, (x10.lang.GlobalRail.$Closure$118.__0$1x10$lang$Long$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 166 "x10/lang/GlobalRail.x10"
    final public static void flushRemoteOps() {
        try {
            ;
        }
        catch (java.lang.Throwable exc$205578) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205578);
        }
        
    }
    
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$205579) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205579);
        }
        
    }
    
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public java.lang.String toString() {
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final java.lang.String t$132791 = "struct x10.lang.GlobalRail: size=";
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final long t$132792 = this.size;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final java.lang.String t$132793 = ((t$132791) + ((x10.core.Long.$box(t$132792))));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final java.lang.String t$132794 = ((t$132793) + (" rail="));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132795 = ((x10.core.GlobalRef)(this.rail));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final java.lang.String t$132796 = ((t$132794) + (t$132795));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        return t$132796;
    }
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public int hashCode() {
        
        //#line 38 "x10/lang/GlobalRail.x10"
        int result = 1;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final int t$132799 = ((8191) * (((int)(result))));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final long t$132798 = this.size;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final int t$132800 = x10.rtt.Types.hashCode(t$132798);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final int t$132801 = ((t$132799) + (((int)(t$132800))));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        result = t$132801;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final int t$132804 = ((8191) * (((int)(result))));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$132803 = ((x10.core.GlobalRef)(this.rail));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final int t$132805 = (((x10.core.GlobalRef<x10.core.Rail<$T>>)(t$132803))).hashCode();
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final int t$132806 = ((t$132804) + (((int)(t$132805))));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        result = t$132806;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        return result;
    }
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public boolean equals(java.lang.Object other) {
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final boolean t$132809 = x10.lang.GlobalRail.$RTT.isInstance(other, $T);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final boolean t$132810 = !(t$132809);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        if (t$132810) {
            
            //#line 38 "x10/lang/GlobalRail.x10"
            return false;
        }
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final x10.lang.GlobalRail t$132812 = ((x10.lang.GlobalRail)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.GlobalRail.$RTT, $T),other));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final boolean t$132813 = this.equals__0$1x10$lang$GlobalRail$$T$2$O(((x10.lang.GlobalRail)(t$132812)));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        return t$132813;
    }
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public boolean equals__0$1x10$lang$GlobalRail$$T$2$O(x10.lang.GlobalRail other) {
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final long t$132815 = this.size;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final long t$132816 = ((x10.lang.GlobalRail<$T>)other).size;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        boolean t$132820 = ((long) t$132815) == ((long) t$132816);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        if (t$132820) {
            
            //#line 38 "x10/lang/GlobalRail.x10"
            final x10.core.GlobalRef t$132818 = ((x10.core.GlobalRef)(this.rail));
            
            //#line 38 "x10/lang/GlobalRail.x10"
            final x10.core.GlobalRef t$132819 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<$T>)other).rail));
            
            //#line 38 "x10/lang/GlobalRail.x10"
            t$132820 = x10.rtt.Equality.equalsequals((t$132818),(t$132819));
        }
        
        //#line 38 "x10/lang/GlobalRail.x10"
        return t$132820;
    }
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final boolean t$132823 = x10.lang.GlobalRail.$RTT.isInstance(other, $T);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final boolean t$132824 = !(t$132823);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        if (t$132824) {
            
            //#line 38 "x10/lang/GlobalRail.x10"
            return false;
        }
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final x10.lang.GlobalRail t$132826 = ((x10.lang.GlobalRail)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.GlobalRail.$RTT, $T),other));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final boolean t$132827 = this._struct_equals__0$1x10$lang$GlobalRail$$T$2$O(((x10.lang.GlobalRail)(t$132826)));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        return t$132827;
    }
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public boolean _struct_equals__0$1x10$lang$GlobalRail$$T$2$O(x10.lang.GlobalRail other) {
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final long t$132829 = this.size;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final long t$132830 = ((x10.lang.GlobalRail<$T>)other).size;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        boolean t$132834 = ((long) t$132829) == ((long) t$132830);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        if (t$132834) {
            
            //#line 38 "x10/lang/GlobalRail.x10"
            final x10.core.GlobalRef t$132832 = ((x10.core.GlobalRef)(this.rail));
            
            //#line 38 "x10/lang/GlobalRail.x10"
            final x10.core.GlobalRef t$132833 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<$T>)other).rail));
            
            //#line 38 "x10/lang/GlobalRail.x10"
            t$132834 = x10.rtt.Equality.equalsequals((t$132832),(t$132833));
        }
        
        //#line 38 "x10/lang/GlobalRail.x10"
        return t$132834;
    }
    
    
    //#line 28 "x10/lang/GlobalRail.x10"
    final public x10.lang.GlobalRail x10$lang$GlobalRail$$this$x10$lang$GlobalRail() {
        
        //#line 28 "x10/lang/GlobalRail.x10"
        return x10.lang.GlobalRail.this;
    }
    
    
    //#line 28 "x10/lang/GlobalRail.x10"
    final public void __fieldInitializers_x10_lang_GlobalRail() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$111 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$111> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$111> make($Closure$111.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$111 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$111 $_obj = new x10.lang.GlobalRail.$Closure$111((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$111(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$ULong$2__2$u {}
        
    
        
        public void $apply() {
            
            //#line 121 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 121 "x10/lang/GlobalRail.x10"
                final long t$132768 = x10.core.ULong.$unbox(((x10.lang.GlobalRail<x10.core.ULong>)this.target).$apply$G((long)(this.idx)));
                
                //#line 121 "x10/lang/GlobalRail.x10"
                final long r$132542 = ((t$132768) + (((long)(this.v))));
                
                //#line 121 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.ULong>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.ULong.$box(r$132542));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 121 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.ULong> target;
        public long idx;
        public long v;
        
        public $Closure$111(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v, __0$1x10$lang$ULong$2__2$u $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$112 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$112> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$112> make($Closure$112.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$112 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$112 $_obj = new x10.lang.GlobalRail.$Closure$112((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$112(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$2 {}
        
    
        
        public void $apply() {
            
            //#line 127 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 127 "x10/lang/GlobalRail.x10"
                final long t$132771 = x10.core.Long.$unbox(((x10.lang.GlobalRail<x10.core.Long>)this.target).$apply$G((long)(this.idx)));
                
                //#line 127 "x10/lang/GlobalRail.x10"
                final long r$132552 = ((t$132771) + (((long)(this.v))));
                
                //#line 127 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.Long>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.Long.$box(r$132552));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 127 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.Long> target;
        public long idx;
        public long v;
        
        public $Closure$112(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v, __0$1x10$lang$Long$2 $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$113 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$113> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$113> make($Closure$113.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$113 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$113 $_obj = new x10.lang.GlobalRail.$Closure$113((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$113(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$ULong$2__2$u {}
        
    
        
        public void $apply() {
            
            //#line 133 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 133 "x10/lang/GlobalRail.x10"
                final long t$132774 = x10.core.ULong.$unbox(((x10.lang.GlobalRail<x10.core.ULong>)this.target).$apply$G((long)(this.idx)));
                
                //#line 133 "x10/lang/GlobalRail.x10"
                final long r$132563 = ((t$132774) & (((long)(this.v))));
                
                //#line 133 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.ULong>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.ULong.$box(r$132563));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 133 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.ULong> target;
        public long idx;
        public long v;
        
        public $Closure$113(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v, __0$1x10$lang$ULong$2__2$u $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$114 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$114> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$114> make($Closure$114.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$114 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$114 $_obj = new x10.lang.GlobalRail.$Closure$114((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$114(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$2 {}
        
    
        
        public void $apply() {
            
            //#line 139 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 139 "x10/lang/GlobalRail.x10"
                final long t$132777 = x10.core.Long.$unbox(((x10.lang.GlobalRail<x10.core.Long>)this.target).$apply$G((long)(this.idx)));
                
                //#line 139 "x10/lang/GlobalRail.x10"
                final long r$132573 = ((t$132777) & (((long)(this.v))));
                
                //#line 139 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.Long>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.Long.$box(r$132573));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 139 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.Long> target;
        public long idx;
        public long v;
        
        public $Closure$114(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v, __0$1x10$lang$Long$2 $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$115 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$115> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$115> make($Closure$115.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$115 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$115 $_obj = new x10.lang.GlobalRail.$Closure$115((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$115(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$ULong$2__2$u {}
        
    
        
        public void $apply() {
            
            //#line 145 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 145 "x10/lang/GlobalRail.x10"
                final long t$132780 = x10.core.ULong.$unbox(((x10.lang.GlobalRail<x10.core.ULong>)this.target).$apply$G((long)(this.idx)));
                
                //#line 145 "x10/lang/GlobalRail.x10"
                final long r$132584 = ((t$132780) | (((long)(this.v))));
                
                //#line 145 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.ULong>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.ULong.$box(r$132584));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 145 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.ULong> target;
        public long idx;
        public long v;
        
        public $Closure$115(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v, __0$1x10$lang$ULong$2__2$u $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$116 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$116> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$116> make($Closure$116.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$116 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$116 $_obj = new x10.lang.GlobalRail.$Closure$116((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$116(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$2 {}
        
    
        
        public void $apply() {
            
            //#line 151 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 151 "x10/lang/GlobalRail.x10"
                final long t$132783 = x10.core.Long.$unbox(((x10.lang.GlobalRail<x10.core.Long>)this.target).$apply$G((long)(this.idx)));
                
                //#line 151 "x10/lang/GlobalRail.x10"
                final long r$132594 = ((t$132783) | (((long)(this.v))));
                
                //#line 151 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.Long>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.Long.$box(r$132594));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 151 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.Long> target;
        public long idx;
        public long v;
        
        public $Closure$116(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v, __0$1x10$lang$Long$2 $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$117 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$117> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$117> make($Closure$117.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$117 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$117 $_obj = new x10.lang.GlobalRail.$Closure$117((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$117(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$ULong$2__2$u {}
        
    
        
        public void $apply() {
            
            //#line 157 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 157 "x10/lang/GlobalRail.x10"
                final long t$132786 = x10.core.ULong.$unbox(((x10.lang.GlobalRail<x10.core.ULong>)this.target).$apply$G((long)(this.idx)));
                
                //#line 157 "x10/lang/GlobalRail.x10"
                final long r$132605 = ((t$132786) ^ (((long)(this.v))));
                
                //#line 157 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.ULong>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.ULong.$box(r$132605));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 157 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.ULong> target;
        public long idx;
        public long v;
        
        public $Closure$117(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v, __0$1x10$lang$ULong$2__2$u $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$118 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$118> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$118> make($Closure$118.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$118 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$118 $_obj = new x10.lang.GlobalRail.$Closure$118((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$118(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$2 {}
        
    
        
        public void $apply() {
            
            //#line 163 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 163 "x10/lang/GlobalRail.x10"
                final long t$132789 = x10.core.Long.$unbox(((x10.lang.GlobalRail<x10.core.Long>)this.target).$apply$G((long)(this.idx)));
                
                //#line 163 "x10/lang/GlobalRail.x10"
                final long r$132615 = ((t$132789) ^ (((long)(this.v))));
                
                //#line 163 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.Long>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.Long.$box(r$132615));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 163 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.Long> target;
        public long idx;
        public long v;
        
        public $Closure$118(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v, __0$1x10$lang$Long$2 $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
}

