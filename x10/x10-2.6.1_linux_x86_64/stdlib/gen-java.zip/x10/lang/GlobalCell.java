package x10.lang;

@x10.runtime.impl.java.X10Generated
public class GlobalCell<$T> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<GlobalCell> $RTT = 
        x10.rtt.NamedType.<GlobalCell> make("x10.lang.GlobalCell",
                                            GlobalCell.class,
                                            1);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalCell<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.root = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.GlobalCell $_obj = new x10.lang.GlobalCell((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.root);
        
    }
    
    // constructor just for allocation
    public GlobalCell(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.lang.GlobalCell.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final GlobalCell $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0x10$lang$GlobalCell$$T {}
    

    
    //#line 16 "x10/lang/GlobalCell.x10"
    public x10.core.GlobalRef<x10.lang.Cell<$T>> root;
    
    
    //#line 17 "x10/lang/GlobalCell.x10"
    // creation method for java code (1-phase java constructor)
    public GlobalCell(final x10.rtt.Type $T, final $T v, __0x10$lang$GlobalCell$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$lang$GlobalCell$$init$S(v, (x10.lang.GlobalCell.__0x10$lang$GlobalCell$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.GlobalCell<$T> x10$lang$GlobalCell$$init$S(final $T v, __0x10$lang$GlobalCell$$T $dummy) {
         {
            
            //#line 17 "x10/lang/GlobalCell.x10"
            
            
            //#line 18 "x10/lang/GlobalCell.x10"
            final x10.lang.Cell alloc$132502 = ((x10.lang.Cell)(new x10.lang.Cell<$T>((java.lang.System[]) null, $T)));
            
            //#line 33 . "x10/lang/Cell.x10"
            ((x10.lang.Cell<$T>)alloc$132502).value = (($T)(v));
            
            //#line 18 "x10/lang/GlobalCell.x10"
            final x10.core.GlobalRef t$132509 = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.lang.Cell<$T>>(x10.rtt.ParameterizedType.make(x10.lang.Cell.$RTT, $T), ((x10.lang.Cell<$T>)(alloc$132502)), (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
            
            //#line 18 "x10/lang/GlobalCell.x10"
            ((x10.lang.GlobalCell<$T>)this).root = ((x10.core.GlobalRef)(t$132509));
        }
        return this;
    }
    
    
    
    //#line 26 "x10/lang/GlobalCell.x10"
    /**
     * Return a string representation of the GlobalCell.
     * 
     */
    public java.lang.String toString() {
        
        //#line 26 "x10/lang/GlobalCell.x10"
        final x10.core.GlobalRef t$132510 = ((x10.core.GlobalRef)(this.root));
        
        //#line 26 "x10/lang/GlobalCell.x10"
        final java.lang.String t$132511 = (((x10.core.GlobalRef<x10.lang.Cell<$T>>)(t$132510))).toString();
        
        //#line 26 "x10/lang/GlobalCell.x10"
        return t$132511;
    }
    
    
    //#line 35 "x10/lang/GlobalCell.x10"
    /**
     * Return the value stored in the Cell.
     * Will work even if the Cell reference is remote.
     *
     * @return the current value stored in the Cell.
     */
    public $T $apply$G() {
        
        //#line 35 "x10/lang/GlobalCell.x10"
        final x10.core.GlobalRef t$132496 = ((x10.core.GlobalRef)(this.root));
        
        //#line 35 "x10/lang/GlobalCell.x10"
        final x10.lang.Place t$132500 = ((x10.lang.Place)((t$132496).home));
        
        //#line 35 "x10/lang/GlobalCell.x10"
        final $T t$132501 = (($T)(x10.xrx.Runtime.<$T> evalAt__1$1x10$xrx$Runtime$$T$2$G($T, ((x10.lang.Place)(t$132500)), ((x10.core.fun.Fun_0_0)(new x10.lang.GlobalCell.$Closure$108<$T>($T, ((x10.lang.GlobalCell<$T>)(this)), this.root, (x10.lang.GlobalCell.$Closure$108.__0$1x10$lang$GlobalCell$$Closure$108$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$108$$T$2$2) null))), ((x10.xrx.Runtime.Profile)(null)))));
        
        //#line 35 "x10/lang/GlobalCell.x10"
        return t$132501;
    }
    
    
    //#line 43 "x10/lang/GlobalCell.x10"
    /**
     * Set the value stored in the Cell to the new value.
     * Will work even if the Cell reference is remote.
     *
     * @param x the new value
     */
    public void $apply__0x10$lang$GlobalCell$$T(final $T x) {
        
        //#line 43 "x10/lang/GlobalCell.x10"
        final x10.core.GlobalRef t$132512 = ((x10.core.GlobalRef)(this.root));
        
        //#line 43 "x10/lang/GlobalCell.x10"
        final x10.lang.Place t$132515 = ((x10.lang.Place)((t$132512).home));
        {
            
            //#line 43 "x10/lang/GlobalCell.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132515)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalCell.$Closure$109<$T>($T, ((x10.lang.GlobalCell<$T>)(this)), this.root, x, (x10.lang.GlobalCell.$Closure$109.__0$1x10$lang$GlobalCell$$Closure$109$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$109$$T$2$2__2x10$lang$GlobalCell$$Closure$109$$T) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 52 "x10/lang/GlobalCell.x10"
    /**
     * Set the value stored in the Cell to the new value.
     * Will work even if the Cell reference is remote.
     *
     * @param x the new value
     * @return the new value stored in the Cell.
     */
    public void $set__0x10$lang$GlobalCell$$T(final $T x) {
        
        //#line 52 "x10/lang/GlobalCell.x10"
        this.set__0x10$lang$GlobalCell$$T$G((($T)(x)));
    }
    
    
    //#line 53 "x10/lang/GlobalCell.x10"
    public $T set__0x10$lang$GlobalCell$$T$G(final $T x) {
        
        //#line 54 "x10/lang/GlobalCell.x10"
        final x10.core.GlobalRef t$132516 = ((x10.core.GlobalRef)(this.root));
        
        //#line 54 "x10/lang/GlobalCell.x10"
        final x10.lang.Place t$132519 = ((x10.lang.Place)((t$132516).home));
        {
            
            //#line 54 "x10/lang/GlobalCell.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132519)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalCell.$Closure$110<$T>($T, ((x10.lang.GlobalCell<$T>)(this)), this.root, x, (x10.lang.GlobalCell.$Closure$110.__0$1x10$lang$GlobalCell$$Closure$110$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$110$$T$2$2__2x10$lang$GlobalCell$$Closure$110$$T) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
        
        //#line 57 "x10/lang/GlobalCell.x10"
        return x;
    }
    
    
    //#line 67 "x10/lang/GlobalCell.x10"
    /**
     * Create a new Cell with the given value stored in it.
     *
     * @param T the value type of the Cell
     * @param x the given value
     * @return a new Cell with the given value stored in it.
     */
    public static <$T>x10.lang.GlobalCell make__0x10$lang$GlobalCell$$T(final x10.rtt.Type $T, final $T x) {
        
        //#line 67 "x10/lang/GlobalCell.x10"
        final x10.lang.GlobalCell alloc$132503 = ((x10.lang.GlobalCell)(new x10.lang.GlobalCell<$T>((java.lang.System[]) null, $T)));
        
        //#line 67 "x10/lang/GlobalCell.x10"
        alloc$132503.x10$lang$GlobalCell$$init$S((($T)(x)), (x10.lang.GlobalCell.__0x10$lang$GlobalCell$$T) null);
        
        //#line 67 "x10/lang/GlobalCell.x10"
        return alloc$132503;
    }
    
    
    //#line 14 "x10/lang/GlobalCell.x10"
    final public x10.lang.GlobalCell x10$lang$GlobalCell$$this$x10$lang$GlobalCell() {
        
        //#line 14 "x10/lang/GlobalCell.x10"
        return x10.lang.GlobalCell.this;
    }
    
    
    //#line 14 "x10/lang/GlobalCell.x10"
    final public void __fieldInitializers_x10_lang_GlobalCell() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$108<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$108> $RTT = 
            x10.rtt.StaticFunType.<$Closure$108> make($Closure$108.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalCell.$Closure$108<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.root = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalCell.$Closure$108 $_obj = new x10.lang.GlobalCell.$Closure$108((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$$);
            $serializer.write(this.root);
            
        }
        
        // constructor just for allocation
        public $Closure$108(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.GlobalCell.$Closure$108.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$108 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$GlobalCell$$Closure$108$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$108$$T$2$2 {}
        
    
        
        public $T $apply$G() {
            
            //#line 35 "x10/lang/GlobalCell.x10"
            try {{
                
                //#line 35 "x10/lang/GlobalCell.x10"
                final x10.core.GlobalRef t$132497 = ((x10.core.GlobalRef)(this.root));
                
                //#line 35 "x10/lang/GlobalCell.x10"
                final x10.lang.Cell t$132498 = (((x10.core.GlobalRef<x10.lang.Cell<$T>>)(t$132497))).$apply$G();
                
                //#line 35 "x10/lang/GlobalCell.x10"
                final $T t$132499 = (($T)(((x10.lang.Cell<$T>)t$132498).value));
                
                //#line 35 "x10/lang/GlobalCell.x10"
                return t$132499;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 35 "x10/lang/GlobalCell.x10"
                $T __lowerer__var__1__ = (($T)(x10.xrx.Runtime.<$T> wrapAtChecked$G($T, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 35 "x10/lang/GlobalCell.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.lang.GlobalCell<$T> out$$;
        public x10.core.GlobalRef<x10.lang.Cell<$T>> root;
        
        public $Closure$108(final x10.rtt.Type $T, final x10.lang.GlobalCell<$T> out$$, final x10.core.GlobalRef<x10.lang.Cell<$T>> root, __0$1x10$lang$GlobalCell$$Closure$108$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$108$$T$2$2 $dummy) {
            x10.lang.GlobalCell.$Closure$108.$initParams(this, $T);
             {
                ((x10.lang.GlobalCell.$Closure$108<$T>)this).out$$ = out$$;
                ((x10.lang.GlobalCell.$Closure$108<$T>)this).root = ((x10.core.GlobalRef)(root));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$109<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$109> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$109> make($Closure$109.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalCell.$Closure$109<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.root = $deserializer.readObject();
            $_obj.x = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalCell.$Closure$109 $_obj = new x10.lang.GlobalCell.$Closure$109((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$$);
            $serializer.write(this.root);
            $serializer.write(this.x);
            
        }
        
        // constructor just for allocation
        public $Closure$109(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.GlobalCell.$Closure$109.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$109 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$GlobalCell$$Closure$109$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$109$$T$2$2__2x10$lang$GlobalCell$$Closure$109$$T {}
        
    
        
        public void $apply() {
            
            //#line 43 "x10/lang/GlobalCell.x10"
            try {{
                
                //#line 43 "x10/lang/GlobalCell.x10"
                final x10.core.GlobalRef t$132513 = ((x10.core.GlobalRef)(this.root));
                
                //#line 43 "x10/lang/GlobalCell.x10"
                final x10.lang.Cell t$132514 = (((x10.core.GlobalRef<x10.lang.Cell<$T>>)(t$132513))).$apply$G();
                
                //#line 43 "x10/lang/GlobalCell.x10"
                ((x10.lang.Cell<$T>)t$132514).value = (($T)(this.x));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 43 "x10/lang/GlobalCell.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalCell<$T> out$$;
        public x10.core.GlobalRef<x10.lang.Cell<$T>> root;
        public $T x;
        
        public $Closure$109(final x10.rtt.Type $T, final x10.lang.GlobalCell<$T> out$$, final x10.core.GlobalRef<x10.lang.Cell<$T>> root, final $T x, __0$1x10$lang$GlobalCell$$Closure$109$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$109$$T$2$2__2x10$lang$GlobalCell$$Closure$109$$T $dummy) {
            x10.lang.GlobalCell.$Closure$109.$initParams(this, $T);
             {
                ((x10.lang.GlobalCell.$Closure$109<$T>)this).out$$ = out$$;
                ((x10.lang.GlobalCell.$Closure$109<$T>)this).root = ((x10.core.GlobalRef)(root));
                ((x10.lang.GlobalCell.$Closure$109<$T>)this).x = (($T)(x));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$110<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$110> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$110> make($Closure$110.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalCell.$Closure$110<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.root = $deserializer.readObject();
            $_obj.x = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalCell.$Closure$110 $_obj = new x10.lang.GlobalCell.$Closure$110((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$$);
            $serializer.write(this.root);
            $serializer.write(this.x);
            
        }
        
        // constructor just for allocation
        public $Closure$110(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.GlobalCell.$Closure$110.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$110 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$GlobalCell$$Closure$110$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$110$$T$2$2__2x10$lang$GlobalCell$$Closure$110$$T {}
        
    
        
        public void $apply() {
            
            //#line 54 "x10/lang/GlobalCell.x10"
            try {{
                
                //#line 55 "x10/lang/GlobalCell.x10"
                final x10.core.GlobalRef t$132517 = ((x10.core.GlobalRef)(this.root));
                
                //#line 55 "x10/lang/GlobalCell.x10"
                final x10.lang.Cell t$132518 = (((x10.core.GlobalRef<x10.lang.Cell<$T>>)(t$132517))).$apply$G();
                
                //#line 55 "x10/lang/GlobalCell.x10"
                ((x10.lang.Cell<$T>)t$132518).value = (($T)(this.x));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 54 "x10/lang/GlobalCell.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalCell<$T> out$$;
        public x10.core.GlobalRef<x10.lang.Cell<$T>> root;
        public $T x;
        
        public $Closure$110(final x10.rtt.Type $T, final x10.lang.GlobalCell<$T> out$$, final x10.core.GlobalRef<x10.lang.Cell<$T>> root, final $T x, __0$1x10$lang$GlobalCell$$Closure$110$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$110$$T$2$2__2x10$lang$GlobalCell$$Closure$110$$T $dummy) {
            x10.lang.GlobalCell.$Closure$110.$initParams(this, $T);
             {
                ((x10.lang.GlobalCell.$Closure$110<$T>)this).out$$ = out$$;
                ((x10.lang.GlobalCell.$Closure$110<$T>)this).root = ((x10.core.GlobalRef)(root));
                ((x10.lang.GlobalCell.$Closure$110<$T>)this).x = (($T)(x));
            }
        }
        
    }
    
}

