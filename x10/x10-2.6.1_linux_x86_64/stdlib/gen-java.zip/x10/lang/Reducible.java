package x10.lang;


/**
 * The interface that must be implemented by reduction operations.
 * 
 * Implementations of Reducible[T] must ensure that the operator(T,T) method is associative
 * and commutative and stateless, and that zero() is an identity.
 */
@x10.runtime.impl.java.X10Generated
public interface Reducible<$T> extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<Reducible> $RTT = 
        x10.rtt.NamedType.<Reducible> make("x10.lang.Reducible",
                                           Reducible.class,
                                           1);
    
    

    
    
    //#line 28 "x10/lang/Reducible.x10"
    /**
    * The identity for this reducer operation. It must be the case
    * that operator(zero(),f)=f.
    */
    $T zero$G();
    
    
    //#line 30 "x10/lang/Reducible.x10"
    java.lang.Object $apply(final java.lang.Object a, x10.rtt.Type t1, final java.lang.Object b, x10.rtt.Type t2);
    
    
    //#line 32 "x10/lang/Reducible.x10"
    @x10.runtime.impl.java.X10Generated
    public static class AndReducer extends x10.core.Struct implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<AndReducer> $RTT = 
            x10.rtt.NamedStructType.<AndReducer> make("x10.lang.Reducible.AndReducer",
                                                      AndReducer.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.Types.BOOLEAN),
                                                          x10.rtt.Types.STRUCT
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Reducible.AndReducer $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Reducible.AndReducer $_obj = new x10.lang.Reducible.AndReducer((java.lang.System[]) null);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // zero value constructor
        public AndReducer(final java.lang.System $dummy) { }
        
        // constructor just for allocation
        public AndReducer(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return x10.core.Boolean.$box($apply$O(x10.core.Boolean.$unbox(a1), x10.core.Boolean.$unbox(a2)));
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public boolean $apply$Z(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$O(x10.core.Boolean.$unbox(a1), x10.core.Boolean.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.lang.Reducible[T].zero(){}:T
        final public x10.core.Boolean zero$G() {
            return x10.core.Boolean.$box(zero$O());
        }
        
        
    
        
        
        //#line 33 "x10/lang/Reducible.x10"
        final public boolean zero$O() {
            
            //#line 33 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 34 "x10/lang/Reducible.x10"
        final public boolean $apply$O(final boolean a, final boolean b) {
            
            //#line 34 "x10/lang/Reducible.x10"
            boolean t$135602 = a;
            
            //#line 34 "x10/lang/Reducible.x10"
            if (a) {
                
                //#line 34 "x10/lang/Reducible.x10"
                t$135602 = b;
            }
            
            //#line 34 "x10/lang/Reducible.x10"
            return t$135602;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public java.lang.String typeName() {
            try {
                return x10.rtt.Types.typeName(this);
            }
            catch (java.lang.Throwable exc$205648) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205648);
            }
            
        }
        
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public java.lang.String toString() {
            
            //#line 32 "x10/lang/Reducible.x10"
            return "struct x10.lang.Reducible.AndReducer";
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public int hashCode() {
            
            //#line 32 "x10/lang/Reducible.x10"
            int result = 1;
            
            //#line 32 "x10/lang/Reducible.x10"
            return result;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public boolean equals(java.lang.Object other) {
            
            //#line 32 "x10/lang/Reducible.x10"
            final boolean t$135606 = x10.lang.Reducible.AndReducer.$RTT.isInstance(other);
            
            //#line 32 "x10/lang/Reducible.x10"
            final boolean t$135607 = !(t$135606);
            
            //#line 32 "x10/lang/Reducible.x10"
            if (t$135607) {
                
                //#line 32 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 32 "x10/lang/Reducible.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Reducible.AndReducer)x10.rtt.Types.asStruct(x10.lang.Reducible.AndReducer.$RTT,other)));
            
            //#line 32 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public boolean equals$O(x10.lang.Reducible.AndReducer other) {
            
            //#line 32 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(java.lang.Object other) {
            
            //#line 32 "x10/lang/Reducible.x10"
            final boolean t$135610 = x10.lang.Reducible.AndReducer.$RTT.isInstance(other);
            
            //#line 32 "x10/lang/Reducible.x10"
            final boolean t$135611 = !(t$135610);
            
            //#line 32 "x10/lang/Reducible.x10"
            if (t$135611) {
                
                //#line 32 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 32 "x10/lang/Reducible.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Reducible.AndReducer)x10.rtt.Types.asStruct(x10.lang.Reducible.AndReducer.$RTT,other)));
            
            //#line 32 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(x10.lang.Reducible.AndReducer other) {
            
            //#line 32 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public x10.lang.Reducible.AndReducer x10$lang$Reducible$AndReducer$$this$x10$lang$Reducible$AndReducer() {
            
            //#line 32 "x10/lang/Reducible.x10"
            return x10.lang.Reducible.AndReducer.this;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        // creation method for java code (1-phase java constructor)
        public AndReducer() {
            this((java.lang.System[]) null);
            x10$lang$Reducible$AndReducer$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.lang.Reducible.AndReducer x10$lang$Reducible$AndReducer$$init$S() {
             {
                
                //#line 32 "x10/lang/Reducible.x10"
                
            }
            return this;
        }
        
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public void __fieldInitializers_x10_lang_Reducible_AndReducer() {
            
        }
    }
    
    
    //#line 37 "x10/lang/Reducible.x10"
    @x10.runtime.impl.java.X10Generated
    public static class OrReducer extends x10.core.Struct implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<OrReducer> $RTT = 
            x10.rtt.NamedStructType.<OrReducer> make("x10.lang.Reducible.OrReducer",
                                                     OrReducer.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.Types.BOOLEAN),
                                                         x10.rtt.Types.STRUCT
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Reducible.OrReducer $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Reducible.OrReducer $_obj = new x10.lang.Reducible.OrReducer((java.lang.System[]) null);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // zero value constructor
        public OrReducer(final java.lang.System $dummy) { }
        
        // constructor just for allocation
        public OrReducer(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return x10.core.Boolean.$box($apply$O(x10.core.Boolean.$unbox(a1), x10.core.Boolean.$unbox(a2)));
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public boolean $apply$Z(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$O(x10.core.Boolean.$unbox(a1), x10.core.Boolean.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.lang.Reducible[T].zero(){}:T
        final public x10.core.Boolean zero$G() {
            return x10.core.Boolean.$box(zero$O());
        }
        
        
    
        
        
        //#line 38 "x10/lang/Reducible.x10"
        final public boolean zero$O() {
            
            //#line 38 "x10/lang/Reducible.x10"
            return false;
        }
        
        
        //#line 39 "x10/lang/Reducible.x10"
        final public boolean $apply$O(final boolean a, final boolean b) {
            
            //#line 39 "x10/lang/Reducible.x10"
            boolean t$135613 = a;
            
            //#line 39 "x10/lang/Reducible.x10"
            if (!(a)) {
                
                //#line 39 "x10/lang/Reducible.x10"
                t$135613 = b;
            }
            
            //#line 39 "x10/lang/Reducible.x10"
            return t$135613;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public java.lang.String typeName() {
            try {
                return x10.rtt.Types.typeName(this);
            }
            catch (java.lang.Throwable exc$205649) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205649);
            }
            
        }
        
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public java.lang.String toString() {
            
            //#line 37 "x10/lang/Reducible.x10"
            return "struct x10.lang.Reducible.OrReducer";
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public int hashCode() {
            
            //#line 37 "x10/lang/Reducible.x10"
            int result = 1;
            
            //#line 37 "x10/lang/Reducible.x10"
            return result;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public boolean equals(java.lang.Object other) {
            
            //#line 37 "x10/lang/Reducible.x10"
            final boolean t$135617 = x10.lang.Reducible.OrReducer.$RTT.isInstance(other);
            
            //#line 37 "x10/lang/Reducible.x10"
            final boolean t$135618 = !(t$135617);
            
            //#line 37 "x10/lang/Reducible.x10"
            if (t$135618) {
                
                //#line 37 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 37 "x10/lang/Reducible.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Reducible.OrReducer)x10.rtt.Types.asStruct(x10.lang.Reducible.OrReducer.$RTT,other)));
            
            //#line 37 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public boolean equals$O(x10.lang.Reducible.OrReducer other) {
            
            //#line 37 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(java.lang.Object other) {
            
            //#line 37 "x10/lang/Reducible.x10"
            final boolean t$135621 = x10.lang.Reducible.OrReducer.$RTT.isInstance(other);
            
            //#line 37 "x10/lang/Reducible.x10"
            final boolean t$135622 = !(t$135621);
            
            //#line 37 "x10/lang/Reducible.x10"
            if (t$135622) {
                
                //#line 37 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 37 "x10/lang/Reducible.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Reducible.OrReducer)x10.rtt.Types.asStruct(x10.lang.Reducible.OrReducer.$RTT,other)));
            
            //#line 37 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(x10.lang.Reducible.OrReducer other) {
            
            //#line 37 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public x10.lang.Reducible.OrReducer x10$lang$Reducible$OrReducer$$this$x10$lang$Reducible$OrReducer() {
            
            //#line 37 "x10/lang/Reducible.x10"
            return x10.lang.Reducible.OrReducer.this;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        // creation method for java code (1-phase java constructor)
        public OrReducer() {
            this((java.lang.System[]) null);
            x10$lang$Reducible$OrReducer$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.lang.Reducible.OrReducer x10$lang$Reducible$OrReducer$$init$S() {
             {
                
                //#line 37 "x10/lang/Reducible.x10"
                
            }
            return this;
        }
        
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public void __fieldInitializers_x10_lang_Reducible_OrReducer() {
            
        }
    }
    
    
    //#line 42 "x10/lang/Reducible.x10"
    @x10.runtime.impl.java.X10Generated
    public static class SumReducer<$T> extends x10.core.Struct implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<SumReducer> $RTT = 
            x10.rtt.NamedStructType.<SumReducer> make("x10.lang.Reducible.SumReducer",
                                                      SumReducer.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                                          x10.rtt.Types.STRUCT
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Reducible.SumReducer<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Reducible.SumReducer $_obj = new x10.lang.Reducible.SumReducer((java.lang.System[]) null, (x10.rtt.Type) null);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // zero value constructor
        public SumReducer(final x10.rtt.Type $T, final java.lang.System $dummy) { this.$T = $T; }
        
        // constructor just for allocation
        public SumReducer(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.Reducible.SumReducer.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$lang$Reducible$SumReducer$$T__1x10$lang$Reducible$SumReducer$$T$G(($T)a1, ($T)a2);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final SumReducer $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        
        //#line 43 "x10/lang/Reducible.x10"
        final public $T zero$G() {
            
            //#line 43 "x10/lang/Reducible.x10"
            final $T t$135624 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 43 "x10/lang/Reducible.x10"
            return t$135624;
        }
        
        
        //#line 44 "x10/lang/Reducible.x10"
        final public $T $apply__0x10$lang$Reducible$SumReducer$$T__1x10$lang$Reducible$SumReducer$$T$G(final $T a, final $T b) {
            
            //#line 44 "x10/lang/Reducible.x10"
            final $T t$135625 = (($T)((($T)
                                        ((x10.lang.Arithmetic<$T>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.lang.Arithmetic.$RTT, $T),a)).$plus((($T)(b)), $T))));
            
            //#line 44 "x10/lang/Reducible.x10"
            return t$135625;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public java.lang.String typeName() {
            try {
                return x10.rtt.Types.typeName(this);
            }
            catch (java.lang.Throwable exc$205650) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205650);
            }
            
        }
        
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public java.lang.String toString() {
            
            //#line 42 "x10/lang/Reducible.x10"
            return "struct x10.lang.Reducible.SumReducer";
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public int hashCode() {
            
            //#line 42 "x10/lang/Reducible.x10"
            int result = 1;
            
            //#line 42 "x10/lang/Reducible.x10"
            return result;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public boolean equals(java.lang.Object other) {
            
            //#line 42 "x10/lang/Reducible.x10"
            final boolean t$135628 = x10.lang.Reducible.SumReducer.$RTT.isInstance(other, $T);
            
            //#line 42 "x10/lang/Reducible.x10"
            final boolean t$135629 = !(t$135628);
            
            //#line 42 "x10/lang/Reducible.x10"
            if (t$135629) {
                
                //#line 42 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 42 "x10/lang/Reducible.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Reducible.SumReducer)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.Reducible.SumReducer.$RTT, $T),other)));
            
            //#line 42 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public boolean equals__0$1x10$lang$Reducible$SumReducer$$T$2$O(x10.lang.Reducible.SumReducer other) {
            
            //#line 42 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(java.lang.Object other) {
            
            //#line 42 "x10/lang/Reducible.x10"
            final boolean t$135632 = x10.lang.Reducible.SumReducer.$RTT.isInstance(other, $T);
            
            //#line 42 "x10/lang/Reducible.x10"
            final boolean t$135633 = !(t$135632);
            
            //#line 42 "x10/lang/Reducible.x10"
            if (t$135633) {
                
                //#line 42 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 42 "x10/lang/Reducible.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Reducible.SumReducer)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.Reducible.SumReducer.$RTT, $T),other)));
            
            //#line 42 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public boolean _struct_equals__0$1x10$lang$Reducible$SumReducer$$T$2$O(x10.lang.Reducible.SumReducer other) {
            
            //#line 42 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public x10.lang.Reducible.SumReducer x10$lang$Reducible$SumReducer$$this$x10$lang$Reducible$SumReducer() {
            
            //#line 42 "x10/lang/Reducible.x10"
            return x10.lang.Reducible.SumReducer.this;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        // creation method for java code (1-phase java constructor)
        public SumReducer(final x10.rtt.Type $T) {
            this((java.lang.System[]) null, $T);
            x10$lang$Reducible$SumReducer$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.lang.Reducible.SumReducer<$T> x10$lang$Reducible$SumReducer$$init$S() {
             {
                
                //#line 42 "x10/lang/Reducible.x10"
                
            }
            return this;
        }
        
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public void __fieldInitializers_x10_lang_Reducible_SumReducer() {
            
        }
    }
    
    
    //#line 47 "x10/lang/Reducible.x10"
    @x10.runtime.impl.java.X10Generated
    public static class MinReducer<$T> extends x10.core.Struct implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<MinReducer> $RTT = 
            x10.rtt.NamedStructType.<MinReducer> make("x10.lang.Reducible.MinReducer",
                                                      MinReducer.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                                          x10.rtt.Types.STRUCT
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Reducible.MinReducer<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.zeroVal = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Reducible.MinReducer $_obj = new x10.lang.Reducible.MinReducer((java.lang.System[]) null, (x10.rtt.Type) null);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.zeroVal);
            
        }
        
        // zero value constructor
        public MinReducer(final x10.rtt.Type $T, final java.lang.System $dummy) { this.$T = $T; this.zeroVal = ($T) x10.rtt.Types.zeroValue($T); }
        
        // constructor just for allocation
        public MinReducer(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.Reducible.MinReducer.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$lang$Reducible$MinReducer$$T__1x10$lang$Reducible$MinReducer$$T$G(($T)a1, ($T)a2);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final MinReducer $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0x10$lang$Reducible$MinReducer$$T {}
        
    
        
        //#line 48 "x10/lang/Reducible.x10"
        public $T zeroVal;
        
        
        //#line 49 "x10/lang/Reducible.x10"
        // creation method for java code (1-phase java constructor)
        public MinReducer(final x10.rtt.Type $T, final $T maxValue, __0x10$lang$Reducible$MinReducer$$T $dummy) {
            this((java.lang.System[]) null, $T);
            x10$lang$Reducible$MinReducer$$init$S(maxValue, (x10.lang.Reducible.MinReducer.__0x10$lang$Reducible$MinReducer$$T) null);
        }
        
        // constructor for non-virtual call
        final public x10.lang.Reducible.MinReducer<$T> x10$lang$Reducible$MinReducer$$init$S(final $T maxValue, __0x10$lang$Reducible$MinReducer$$T $dummy) {
             {
                
                //#line 49 "x10/lang/Reducible.x10"
                
                
                //#line 49 "x10/lang/Reducible.x10"
                ((x10.lang.Reducible.MinReducer<$T>)this).zeroVal = (($T)(maxValue));
            }
            return this;
        }
        
        
        
        //#line 50 "x10/lang/Reducible.x10"
        final public $T zero$G() {
            
            //#line 50 "x10/lang/Reducible.x10"
            final $T t$135635 = (($T)(this.zeroVal));
            
            //#line 50 "x10/lang/Reducible.x10"
            return t$135635;
        }
        
        
        //#line 51 "x10/lang/Reducible.x10"
        final public $T $apply__0x10$lang$Reducible$MinReducer$$T__1x10$lang$Reducible$MinReducer$$T$G(final $T a, final $T b) {
            
            //#line 51 "x10/lang/Reducible.x10"
            final boolean t$135636 = x10.core.Boolean.$unbox(((x10.util.Ordered<$T>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.util.Ordered.$RTT, $T),a)).$lt$Z((($T)(b)), $T));
            
            //#line 51 "x10/lang/Reducible.x10"
            $T t$135637 =  null;
            
            //#line 51 "x10/lang/Reducible.x10"
            if (t$135636) {
                
                //#line 51 "x10/lang/Reducible.x10"
                t$135637 = (($T)(a));
            } else {
                
                //#line 51 "x10/lang/Reducible.x10"
                t$135637 = (($T)(b));
            }
            
            //#line 51 "x10/lang/Reducible.x10"
            return t$135637;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public java.lang.String typeName() {
            try {
                return x10.rtt.Types.typeName(this);
            }
            catch (java.lang.Throwable exc$205651) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205651);
            }
            
        }
        
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public java.lang.String toString() {
            
            //#line 47 "x10/lang/Reducible.x10"
            final java.lang.String t$135639 = "struct x10.lang.Reducible.MinReducer: zeroVal=";
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$135640 = (($T)(this.zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final java.lang.String t$135641 = ((t$135639) + (t$135640));
            
            //#line 47 "x10/lang/Reducible.x10"
            return t$135641;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public int hashCode() {
            
            //#line 47 "x10/lang/Reducible.x10"
            int result = 1;
            
            //#line 47 "x10/lang/Reducible.x10"
            final int t$135644 = ((8191) * (((int)(result))));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$135643 = (($T)(this.zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final int t$135645 = x10.rtt.Types.hashCode(((java.lang.Object)(t$135643)));
            
            //#line 47 "x10/lang/Reducible.x10"
            final int t$135646 = ((t$135644) + (((int)(t$135645))));
            
            //#line 47 "x10/lang/Reducible.x10"
            result = t$135646;
            
            //#line 47 "x10/lang/Reducible.x10"
            return result;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public boolean equals(java.lang.Object other) {
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$135649 = x10.lang.Reducible.MinReducer.$RTT.isInstance(other, $T);
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$135650 = !(t$135649);
            
            //#line 47 "x10/lang/Reducible.x10"
            if (t$135650) {
                
                //#line 47 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 47 "x10/lang/Reducible.x10"
            final x10.lang.Reducible.MinReducer this$135589 = ((x10.lang.Reducible.MinReducer)(this));
            
            //#line 47 "x10/lang/Reducible.x10"
            x10.lang.Reducible.MinReducer other$135588 = ((x10.lang.Reducible.MinReducer)(((x10.lang.Reducible.MinReducer)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.Reducible.MinReducer.$RTT, $T),other))));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$135653 = (($T)(((x10.lang.Reducible.MinReducer<$T>)this$135589).zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$135654 = (($T)(((x10.lang.Reducible.MinReducer<$T>)other$135588).zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$135655 = x10.rtt.Equality.equalsequals((t$135653),(t$135654));
            
            //#line 47 "x10/lang/Reducible.x10"
            return t$135655;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public boolean equals__0$1x10$lang$Reducible$MinReducer$$T$2$O(x10.lang.Reducible.MinReducer other) {
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$135657 = (($T)(this.zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$135658 = (($T)(((x10.lang.Reducible.MinReducer<$T>)other).zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$135659 = x10.rtt.Equality.equalsequals((t$135657),(t$135658));
            
            //#line 47 "x10/lang/Reducible.x10"
            return t$135659;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(java.lang.Object other) {
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$135661 = x10.lang.Reducible.MinReducer.$RTT.isInstance(other, $T);
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$135662 = !(t$135661);
            
            //#line 47 "x10/lang/Reducible.x10"
            if (t$135662) {
                
                //#line 47 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 47 "x10/lang/Reducible.x10"
            final x10.lang.Reducible.MinReducer this$135592 = ((x10.lang.Reducible.MinReducer)(this));
            
            //#line 47 "x10/lang/Reducible.x10"
            x10.lang.Reducible.MinReducer other$135591 = ((x10.lang.Reducible.MinReducer)(((x10.lang.Reducible.MinReducer)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.Reducible.MinReducer.$RTT, $T),other))));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$135665 = (($T)(((x10.lang.Reducible.MinReducer<$T>)this$135592).zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$135666 = (($T)(((x10.lang.Reducible.MinReducer<$T>)other$135591).zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$135667 = x10.rtt.Equality.equalsequals((t$135665),(t$135666));
            
            //#line 47 "x10/lang/Reducible.x10"
            return t$135667;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public boolean _struct_equals__0$1x10$lang$Reducible$MinReducer$$T$2$O(x10.lang.Reducible.MinReducer other) {
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$135669 = (($T)(this.zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$135670 = (($T)(((x10.lang.Reducible.MinReducer<$T>)other).zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$135671 = x10.rtt.Equality.equalsequals((t$135669),(t$135670));
            
            //#line 47 "x10/lang/Reducible.x10"
            return t$135671;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public x10.lang.Reducible.MinReducer x10$lang$Reducible$MinReducer$$this$x10$lang$Reducible$MinReducer() {
            
            //#line 47 "x10/lang/Reducible.x10"
            return x10.lang.Reducible.MinReducer.this;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public void __fieldInitializers_x10_lang_Reducible_MinReducer() {
            
        }
    }
    
    
    //#line 54 "x10/lang/Reducible.x10"
    @x10.runtime.impl.java.X10Generated
    public static class MaxReducer<$T> extends x10.core.Struct implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<MaxReducer> $RTT = 
            x10.rtt.NamedStructType.<MaxReducer> make("x10.lang.Reducible.MaxReducer",
                                                      MaxReducer.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                                          x10.rtt.Types.STRUCT
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Reducible.MaxReducer<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.zeroVal = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Reducible.MaxReducer $_obj = new x10.lang.Reducible.MaxReducer((java.lang.System[]) null, (x10.rtt.Type) null);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.zeroVal);
            
        }
        
        // zero value constructor
        public MaxReducer(final x10.rtt.Type $T, final java.lang.System $dummy) { this.$T = $T; this.zeroVal = ($T) x10.rtt.Types.zeroValue($T); }
        
        // constructor just for allocation
        public MaxReducer(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.Reducible.MaxReducer.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$lang$Reducible$MaxReducer$$T__1x10$lang$Reducible$MaxReducer$$T$G(($T)a1, ($T)a2);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final MaxReducer $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0x10$lang$Reducible$MaxReducer$$T {}
        
    
        
        //#line 55 "x10/lang/Reducible.x10"
        public $T zeroVal;
        
        
        //#line 56 "x10/lang/Reducible.x10"
        // creation method for java code (1-phase java constructor)
        public MaxReducer(final x10.rtt.Type $T, final $T minValue, __0x10$lang$Reducible$MaxReducer$$T $dummy) {
            this((java.lang.System[]) null, $T);
            x10$lang$Reducible$MaxReducer$$init$S(minValue, (x10.lang.Reducible.MaxReducer.__0x10$lang$Reducible$MaxReducer$$T) null);
        }
        
        // constructor for non-virtual call
        final public x10.lang.Reducible.MaxReducer<$T> x10$lang$Reducible$MaxReducer$$init$S(final $T minValue, __0x10$lang$Reducible$MaxReducer$$T $dummy) {
             {
                
                //#line 56 "x10/lang/Reducible.x10"
                
                
                //#line 56 "x10/lang/Reducible.x10"
                ((x10.lang.Reducible.MaxReducer<$T>)this).zeroVal = (($T)(minValue));
            }
            return this;
        }
        
        
        
        //#line 57 "x10/lang/Reducible.x10"
        final public $T zero$G() {
            
            //#line 57 "x10/lang/Reducible.x10"
            final $T t$135672 = (($T)(this.zeroVal));
            
            //#line 57 "x10/lang/Reducible.x10"
            return t$135672;
        }
        
        
        //#line 58 "x10/lang/Reducible.x10"
        final public $T $apply__0x10$lang$Reducible$MaxReducer$$T__1x10$lang$Reducible$MaxReducer$$T$G(final $T a, final $T b) {
            
            //#line 58 "x10/lang/Reducible.x10"
            final boolean t$135673 = x10.core.Boolean.$unbox(((x10.util.Ordered<$T>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.util.Ordered.$RTT, $T),a)).$ge$Z((($T)(b)), $T));
            
            //#line 58 "x10/lang/Reducible.x10"
            $T t$135674 =  null;
            
            //#line 58 "x10/lang/Reducible.x10"
            if (t$135673) {
                
                //#line 58 "x10/lang/Reducible.x10"
                t$135674 = (($T)(a));
            } else {
                
                //#line 58 "x10/lang/Reducible.x10"
                t$135674 = (($T)(b));
            }
            
            //#line 58 "x10/lang/Reducible.x10"
            return t$135674;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public java.lang.String typeName() {
            try {
                return x10.rtt.Types.typeName(this);
            }
            catch (java.lang.Throwable exc$205652) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205652);
            }
            
        }
        
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public java.lang.String toString() {
            
            //#line 54 "x10/lang/Reducible.x10"
            final java.lang.String t$135676 = "struct x10.lang.Reducible.MaxReducer: zeroVal=";
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$135677 = (($T)(this.zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final java.lang.String t$135678 = ((t$135676) + (t$135677));
            
            //#line 54 "x10/lang/Reducible.x10"
            return t$135678;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public int hashCode() {
            
            //#line 54 "x10/lang/Reducible.x10"
            int result = 1;
            
            //#line 54 "x10/lang/Reducible.x10"
            final int t$135681 = ((8191) * (((int)(result))));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$135680 = (($T)(this.zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final int t$135682 = x10.rtt.Types.hashCode(((java.lang.Object)(t$135680)));
            
            //#line 54 "x10/lang/Reducible.x10"
            final int t$135683 = ((t$135681) + (((int)(t$135682))));
            
            //#line 54 "x10/lang/Reducible.x10"
            result = t$135683;
            
            //#line 54 "x10/lang/Reducible.x10"
            return result;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public boolean equals(java.lang.Object other) {
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$135686 = x10.lang.Reducible.MaxReducer.$RTT.isInstance(other, $T);
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$135687 = !(t$135686);
            
            //#line 54 "x10/lang/Reducible.x10"
            if (t$135687) {
                
                //#line 54 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 54 "x10/lang/Reducible.x10"
            final x10.lang.Reducible.MaxReducer this$135597 = ((x10.lang.Reducible.MaxReducer)(this));
            
            //#line 54 "x10/lang/Reducible.x10"
            x10.lang.Reducible.MaxReducer other$135596 = ((x10.lang.Reducible.MaxReducer)(((x10.lang.Reducible.MaxReducer)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.Reducible.MaxReducer.$RTT, $T),other))));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$135690 = (($T)(((x10.lang.Reducible.MaxReducer<$T>)this$135597).zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$135691 = (($T)(((x10.lang.Reducible.MaxReducer<$T>)other$135596).zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$135692 = x10.rtt.Equality.equalsequals((t$135690),(t$135691));
            
            //#line 54 "x10/lang/Reducible.x10"
            return t$135692;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public boolean equals__0$1x10$lang$Reducible$MaxReducer$$T$2$O(x10.lang.Reducible.MaxReducer other) {
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$135694 = (($T)(this.zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$135695 = (($T)(((x10.lang.Reducible.MaxReducer<$T>)other).zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$135696 = x10.rtt.Equality.equalsequals((t$135694),(t$135695));
            
            //#line 54 "x10/lang/Reducible.x10"
            return t$135696;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(java.lang.Object other) {
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$135698 = x10.lang.Reducible.MaxReducer.$RTT.isInstance(other, $T);
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$135699 = !(t$135698);
            
            //#line 54 "x10/lang/Reducible.x10"
            if (t$135699) {
                
                //#line 54 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 54 "x10/lang/Reducible.x10"
            final x10.lang.Reducible.MaxReducer this$135600 = ((x10.lang.Reducible.MaxReducer)(this));
            
            //#line 54 "x10/lang/Reducible.x10"
            x10.lang.Reducible.MaxReducer other$135599 = ((x10.lang.Reducible.MaxReducer)(((x10.lang.Reducible.MaxReducer)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.Reducible.MaxReducer.$RTT, $T),other))));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$135702 = (($T)(((x10.lang.Reducible.MaxReducer<$T>)this$135600).zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$135703 = (($T)(((x10.lang.Reducible.MaxReducer<$T>)other$135599).zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$135704 = x10.rtt.Equality.equalsequals((t$135702),(t$135703));
            
            //#line 54 "x10/lang/Reducible.x10"
            return t$135704;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public boolean _struct_equals__0$1x10$lang$Reducible$MaxReducer$$T$2$O(x10.lang.Reducible.MaxReducer other) {
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$135706 = (($T)(this.zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$135707 = (($T)(((x10.lang.Reducible.MaxReducer<$T>)other).zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$135708 = x10.rtt.Equality.equalsequals((t$135706),(t$135707));
            
            //#line 54 "x10/lang/Reducible.x10"
            return t$135708;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public x10.lang.Reducible.MaxReducer x10$lang$Reducible$MaxReducer$$this$x10$lang$Reducible$MaxReducer() {
            
            //#line 54 "x10/lang/Reducible.x10"
            return x10.lang.Reducible.MaxReducer.this;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public void __fieldInitializers_x10_lang_Reducible_MaxReducer() {
            
        }
    }
    
}

