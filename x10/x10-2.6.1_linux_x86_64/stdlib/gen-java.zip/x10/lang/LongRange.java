package x10.lang;


/**
 * A representation of the range of longs [min..max].
 */
@x10.runtime.impl.java.X10Generated
public class LongRange extends x10.core.Struct implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<LongRange> $RTT = 
        x10.rtt.NamedStructType.<LongRange> make("x10.lang.LongRange",
                                                 LongRange.class,
                                                 new x10.rtt.Type[] {
                                                     x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.rtt.Types.LONG),
                                                     x10.rtt.Types.STRUCT
                                                 });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.LongRange $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.max = $deserializer.readLong();
        $_obj.min = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.LongRange $_obj = new x10.lang.LongRange((java.lang.System[]) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.max);
        $serializer.write(this.min);
        
    }
    
    // zero value constructor
    public LongRange(final java.lang.System $dummy) { this.min = 0L; this.max = 0L; }
    
    // constructor just for allocation
    public LongRange(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 23 "x10/lang/LongRange.x10"
    /**
                * The minimum value included in the range
                */
    public long min;
    
    //#line 28 "x10/lang/LongRange.x10"
    /**
                * The maximum value included in the range
                */
    public long max;
    

    
    
    //#line 36 "x10/lang/LongRange.x10"
    /**
     * Construct a LongRange from min..max
     * @param min the minimum value of the range
     * @param max the maximum value of the range
     */
    // creation method for java code (1-phase java constructor)
    public LongRange(final long min, final long max) {
        this((java.lang.System[]) null);
        x10$lang$LongRange$$init$S(min, max);
    }
    
    // constructor for non-virtual call
    final public x10.lang.LongRange x10$lang$LongRange$$init$S(final long min, final long max) {
         {
            
            //#line 37 "x10/lang/LongRange.x10"
            this.min = min;
            this.max = max;
            
        }
        return this;
    }
    
    
    
    //#line 45 "x10/lang/LongRange.x10"
    /**
     * Coerce a given IntRange to a LongRange.
     * @param x the given IntRange
     * @return the given IntRange converted to a LongRange.
     */
    final public static x10.lang.LongRange $implicit_convert(final x10.lang.IntRange x) {
        
        //#line 45 "x10/lang/LongRange.x10"
        final x10.lang.LongRange alloc$133255 = ((x10.lang.LongRange)(new x10.lang.LongRange((java.lang.System[]) null)));
        
        //#line 45 "x10/lang/LongRange.x10"
        final int t$133275 = x.min;
        
        //#line 45 "x10/lang/LongRange.x10"
        final long min$133261 = ((long)(((int)(t$133275))));
        
        //#line 45 "x10/lang/LongRange.x10"
        final int t$133276 = x.max;
        
        //#line 45 "x10/lang/LongRange.x10"
        final long max$133262 = ((long)(((int)(t$133276))));
        
        //#line 37 . "x10/lang/LongRange.x10"
        alloc$133255.min = min$133261;
        
        //#line 37 . "x10/lang/LongRange.x10"
        alloc$133255.max = max$133262;
        
        //#line 45 "x10/lang/LongRange.x10"
        return alloc$133255;
    }
    
    
    //#line 52 "x10/lang/LongRange.x10"
    /**
     * Split the LongRange into N LongRanges that
     * collectively represent the same set of Longs as this.
     * @see x10.array.BlockUtils.partitionBlock
     */
    final public x10.core.Rail split(final long n) {
        
        //#line 53 "x10/lang/LongRange.x10"
        final long t$133277 = this.max;
        
        //#line 53 "x10/lang/LongRange.x10"
        final long t$133278 = this.min;
        
        //#line 53 "x10/lang/LongRange.x10"
        final long t$133279 = ((t$133277) - (((long)(t$133278))));
        
        //#line 53 "x10/lang/LongRange.x10"
        final long numElems = ((t$133279) + (((long)(1L))));
        
        //#line 54 "x10/lang/LongRange.x10"
        final long blockSize = ((numElems) / (((long)(n))));
        
        //#line 55 "x10/lang/LongRange.x10"
        final long t$133280 = ((n) * (((long)(blockSize))));
        
        //#line 55 "x10/lang/LongRange.x10"
        final long leftOver = ((numElems) - (((long)(t$133280))));
        
        //#line 56 "x10/lang/LongRange.x10"
        final x10.core.fun.Fun_0_1 t$133291 = ((x10.core.fun.Fun_0_1)(new x10.lang.LongRange.$Closure$122(this, this.min, blockSize, leftOver)));
        
        //#line 56 "x10/lang/LongRange.x10"
        final x10.core.Rail t$133292 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.LongRange>(x10.lang.LongRange.$RTT, ((long)(n)), ((x10.core.fun.Fun_0_1)(t$133291)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 56 "x10/lang/LongRange.x10"
        return t$133292;
    }
    
    
    //#line 67 "x10/lang/LongRange.x10"
    /**
     * Define the product of two LongRanges to be a rank-2 IterationSpace
     * containing all the points defined by the cartesian product of the ranges.
     */
    final public x10.array.DenseIterationSpace_2 $times(final x10.lang.LongRange that) {
        
        //#line 68 "x10/lang/LongRange.x10"
        final x10.array.DenseIterationSpace_2 alloc$133257 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 68 "x10/lang/LongRange.x10"
        final long t$133333 = this.min;
        
        //#line 68 "x10/lang/LongRange.x10"
        final long t$133334 = that.min;
        
        //#line 68 "x10/lang/LongRange.x10"
        final long t$133335 = this.max;
        
        //#line 68 "x10/lang/LongRange.x10"
        final long t$133336 = that.max;
        
        //#line 68 "x10/lang/LongRange.x10"
        alloc$133257.x10$array$DenseIterationSpace_2$$init$S(((long)(t$133333)), ((long)(t$133334)), ((long)(t$133335)), ((long)(t$133336)));
        
        //#line 68 "x10/lang/LongRange.x10"
        return alloc$133257;
    }
    
    
    //#line 71 "x10/lang/LongRange.x10"
    final public java.lang.String toString() {
        
        //#line 71 "x10/lang/LongRange.x10"
        final long t$133297 = this.min;
        
        //#line 71 "x10/lang/LongRange.x10"
        final java.lang.String t$133298 = (((x10.core.Long.$box(t$133297))) + (".."));
        
        //#line 71 "x10/lang/LongRange.x10"
        final long t$133299 = this.max;
        
        //#line 71 "x10/lang/LongRange.x10"
        final java.lang.String t$133300 = ((t$133298) + ((x10.core.Long.$box(t$133299))));
        
        //#line 71 "x10/lang/LongRange.x10"
        return t$133300;
    }
    
    
    //#line 73 "x10/lang/LongRange.x10"
    final public boolean equals(final java.lang.Object that) {
        
        //#line 74 "x10/lang/LongRange.x10"
        final boolean t$133307 = x10.lang.LongRange.$RTT.isInstance(that);
        
        //#line 74 "x10/lang/LongRange.x10"
        if (t$133307) {
            
            //#line 75 "x10/lang/LongRange.x10"
            final x10.lang.LongRange other = ((x10.lang.LongRange)(((x10.lang.LongRange)x10.rtt.Types.asStruct(x10.lang.LongRange.$RTT,that))));
            
            //#line 76 "x10/lang/LongRange.x10"
            final long t$133301 = this.min;
            
            //#line 76 "x10/lang/LongRange.x10"
            final long t$133302 = other.min;
            
            //#line 76 "x10/lang/LongRange.x10"
            boolean t$133305 = ((long) t$133301) == ((long) t$133302);
            
            //#line 76 "x10/lang/LongRange.x10"
            if (t$133305) {
                
                //#line 76 "x10/lang/LongRange.x10"
                final long t$133303 = this.max;
                
                //#line 76 "x10/lang/LongRange.x10"
                final long t$133304 = other.max;
                
                //#line 76 "x10/lang/LongRange.x10"
                t$133305 = ((long) t$133303) == ((long) t$133304);
            }
            
            //#line 76 "x10/lang/LongRange.x10"
            return t$133305;
        }
        
        //#line 78 "x10/lang/LongRange.x10"
        return false;
    }
    
    
    //#line 81 "x10/lang/LongRange.x10"
    final public int hashCode() {
        
        //#line 81 "x10/lang/LongRange.x10"
        final long t$133308 = this.max;
        
        //#line 81 "x10/lang/LongRange.x10"
        final long t$133309 = this.min;
        
        //#line 81 "x10/lang/LongRange.x10"
        final long t$133310 = ((t$133308) - (((long)(t$133309))));
        
        //#line 81 "x10/lang/LongRange.x10"
        final int t$133311 = x10.rtt.Types.hashCode(t$133310);
        
        //#line 81 "x10/lang/LongRange.x10"
        return t$133311;
    }
    
    
    //#line 83 "x10/lang/LongRange.x10"
    final public x10.lang.Iterator iterator() {
        
        //#line 84 "x10/lang/LongRange.x10"
        final x10.lang.LongRange.LongRangeIt alloc$133258 = ((x10.lang.LongRange.LongRangeIt)(new x10.lang.LongRange.LongRangeIt((java.lang.System[]) null)));
        
        //#line 84 "x10/lang/LongRange.x10"
        final long min$133269 = this.min;
        
        //#line 84 "x10/lang/LongRange.x10"
        final long max$133270 = this.max;
        
        //#line 87 .. "x10/lang/LongRange.x10"
        alloc$133258.cur = 0L;
        
        //#line 91 . "x10/lang/LongRange.x10"
        alloc$133258.cur = min$133269;
        
        //#line 92 . "x10/lang/LongRange.x10"
        alloc$133258.max = max$133270;
        
        //#line 84 "x10/lang/LongRange.x10"
        return alloc$133258;
    }
    
    
    //#line 87 "x10/lang/LongRange.x10"
    @x10.runtime.impl.java.X10Generated
    public static class LongRangeIt extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<LongRangeIt> $RTT = 
            x10.rtt.NamedType.<LongRangeIt> make("x10.lang.LongRange.LongRangeIt",
                                                 LongRangeIt.class,
                                                 new x10.rtt.Type[] {
                                                     x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.rtt.Types.LONG)
                                                 });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.LongRange.LongRangeIt $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur = $deserializer.readLong();
            $_obj.max = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.LongRange.LongRangeIt $_obj = new x10.lang.LongRange.LongRangeIt((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur);
            $serializer.write(this.max);
            
        }
        
        // constructor just for allocation
        public LongRangeIt(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.core.Long next$G() {
            return x10.core.Long.$box(next$O());
        }
        
        
    
        
        //#line 88 "x10/lang/LongRange.x10"
        public long cur;
        
        //#line 89 "x10/lang/LongRange.x10"
        public long max;
        
        
        //#line 90 "x10/lang/LongRange.x10"
        // creation method for java code (1-phase java constructor)
        public LongRangeIt(final long min, final long max) {
            this((java.lang.System[]) null);
            x10$lang$LongRange$LongRangeIt$$init$S(min, max);
        }
        
        // constructor for non-virtual call
        final public x10.lang.LongRange.LongRangeIt x10$lang$LongRange$LongRangeIt$$init$S(final long min, final long max) {
             {
                
                //#line 90 "x10/lang/LongRange.x10"
                
                
                //#line 87 "x10/lang/LongRange.x10"
                final x10.lang.LongRange.LongRangeIt this$133337 = this;
                
                //#line 87 "x10/lang/LongRange.x10"
                this$133337.cur = 0L;
                
                //#line 91 "x10/lang/LongRange.x10"
                this.cur = min;
                
                //#line 92 "x10/lang/LongRange.x10"
                this.max = max;
            }
            return this;
        }
        
        
        
        //#line 94 "x10/lang/LongRange.x10"
        public boolean hasNext$O() {
            
            //#line 94 "x10/lang/LongRange.x10"
            final long t$133312 = this.cur;
            
            //#line 94 "x10/lang/LongRange.x10"
            final long t$133313 = this.max;
            
            //#line 94 "x10/lang/LongRange.x10"
            final boolean t$133314 = ((t$133312) <= (((long)(t$133313))));
            
            //#line 94 "x10/lang/LongRange.x10"
            return t$133314;
        }
        
        
        //#line 95 "x10/lang/LongRange.x10"
        public long next$O() {
            
            //#line 95 "x10/lang/LongRange.x10"
            final long t$133315 = this.cur;
            
            //#line 95 "x10/lang/LongRange.x10"
            final long t$133316 = ((t$133315) + (((long)(1L))));
            
            //#line 95 "x10/lang/LongRange.x10"
            final long t$133317 = this.cur = t$133316;
            
            //#line 95 "x10/lang/LongRange.x10"
            final long t$133318 = ((t$133317) - (((long)(1L))));
            
            //#line 95 "x10/lang/LongRange.x10"
            return t$133318;
        }
        
        
        //#line 87 "x10/lang/LongRange.x10"
        final public x10.lang.LongRange.LongRangeIt x10$lang$LongRange$LongRangeIt$$this$x10$lang$LongRange$LongRangeIt() {
            
            //#line 87 "x10/lang/LongRange.x10"
            return x10.lang.LongRange.LongRangeIt.this;
        }
        
        
        //#line 87 "x10/lang/LongRange.x10"
        final public void __fieldInitializers_x10_lang_LongRange_LongRangeIt() {
            
            //#line 87 "x10/lang/LongRange.x10"
            this.cur = 0L;
        }
    }
    
    
    
    //#line 29 "x10/lang/LongRange.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$205581) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205581);
        }
        
    }
    
    
    
    //#line 29 "x10/lang/LongRange.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 29 "x10/lang/LongRange.x10"
        final boolean t$133320 = x10.lang.LongRange.$RTT.isInstance(other);
        
        //#line 29 "x10/lang/LongRange.x10"
        final boolean t$133321 = !(t$133320);
        
        //#line 29 "x10/lang/LongRange.x10"
        if (t$133321) {
            
            //#line 29 "x10/lang/LongRange.x10"
            return false;
        }
        
        //#line 29 "x10/lang/LongRange.x10"
        final x10.lang.LongRange t$133323 = ((x10.lang.LongRange)x10.rtt.Types.asStruct(x10.lang.LongRange.$RTT,other));
        
        //#line 29 "x10/lang/LongRange.x10"
        final boolean t$133324 = this._struct_equals$O(((x10.lang.LongRange)(t$133323)));
        
        //#line 29 "x10/lang/LongRange.x10"
        return t$133324;
    }
    
    
    //#line 29 "x10/lang/LongRange.x10"
    final public boolean _struct_equals$O(x10.lang.LongRange other) {
        
        //#line 29 "x10/lang/LongRange.x10"
        final long t$133326 = this.min;
        
        //#line 29 "x10/lang/LongRange.x10"
        final long t$133327 = other.min;
        
        //#line 29 "x10/lang/LongRange.x10"
        boolean t$133331 = ((long) t$133326) == ((long) t$133327);
        
        //#line 29 "x10/lang/LongRange.x10"
        if (t$133331) {
            
            //#line 29 "x10/lang/LongRange.x10"
            final long t$133329 = this.max;
            
            //#line 29 "x10/lang/LongRange.x10"
            final long t$133330 = other.max;
            
            //#line 29 "x10/lang/LongRange.x10"
            t$133331 = ((long) t$133329) == ((long) t$133330);
        }
        
        //#line 29 "x10/lang/LongRange.x10"
        return t$133331;
    }
    
    
    //#line 19 "x10/lang/LongRange.x10"
    final public x10.lang.LongRange x10$lang$LongRange$$this$x10$lang$LongRange() {
        
        //#line 19 "x10/lang/LongRange.x10"
        return x10.lang.LongRange.this;
    }
    
    
    //#line 19 "x10/lang/LongRange.x10"
    final public void __fieldInitializers_x10_lang_LongRange() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$122 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$122> $RTT = 
            x10.rtt.StaticFunType.<$Closure$122> make($Closure$122.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.lang.LongRange.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.LongRange.$Closure$122 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.blockSize = $deserializer.readLong();
            $_obj.leftOver = $deserializer.readLong();
            $_obj.min = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.LongRange.$Closure$122 $_obj = new x10.lang.LongRange.$Closure$122((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.blockSize);
            $serializer.write(this.leftOver);
            $serializer.write(this.min);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$122(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.lang.LongRange $apply(final long i) {
            
            //#line 57 "x10/lang/LongRange.x10"
            final long t$133281 = this.min;
            
            //#line 57 "x10/lang/LongRange.x10"
            final long t$133282 = ((this.blockSize) * (((long)(i))));
            
            //#line 57 "x10/lang/LongRange.x10"
            final long t$133285 = ((t$133281) + (((long)(t$133282))));
            
            //#line 57 "x10/lang/LongRange.x10"
            final boolean t$133283 = ((i) < (((long)(this.leftOver))));
            
            //#line 57 "x10/lang/LongRange.x10"
            long t$133284 =  0;
            
            //#line 57 "x10/lang/LongRange.x10"
            if (t$133283) {
                
                //#line 57 "x10/lang/LongRange.x10"
                t$133284 = i;
            } else {
                
                //#line 57 "x10/lang/LongRange.x10"
                t$133284 = this.leftOver;
            }
            
            //#line 57 "x10/lang/LongRange.x10"
            final long low = ((t$133285) + (((long)(t$133284))));
            
            //#line 58 "x10/lang/LongRange.x10"
            final long t$133289 = ((low) + (((long)(this.blockSize))));
            
            //#line 58 "x10/lang/LongRange.x10"
            final boolean t$133287 = ((i) < (((long)(this.leftOver))));
            
            //#line 58 "x10/lang/LongRange.x10"
            long t$133288 =  0;
            
            //#line 58 "x10/lang/LongRange.x10"
            if (t$133287) {
                
                //#line 58 "x10/lang/LongRange.x10"
                t$133288 = 0L;
            } else {
                
                //#line 58 "x10/lang/LongRange.x10"
                t$133288 = -1L;
            }
            
            //#line 58 "x10/lang/LongRange.x10"
            final long hi = ((t$133289) + (((long)(t$133288))));
            
            //#line 59 "x10/lang/LongRange.x10"
            final x10.lang.LongRange alloc$133256 = ((x10.lang.LongRange)(new x10.lang.LongRange((java.lang.System[]) null)));
            
            //#line 37 . "x10/lang/LongRange.x10"
            alloc$133256.min = low;
            
            //#line 37 . "x10/lang/LongRange.x10"
            alloc$133256.max = hi;
            
            //#line 59 "x10/lang/LongRange.x10"
            return alloc$133256;
        }
        
        public x10.lang.LongRange out$$;
        public long min;
        public long blockSize;
        public long leftOver;
        
        public $Closure$122(final x10.lang.LongRange out$$, final long min, final long blockSize, final long leftOver) {
             {
                this.out$$ = out$$;
                this.min = min;
                this.blockSize = blockSize;
                this.leftOver = leftOver;
            }
        }
        
    }
    
}

