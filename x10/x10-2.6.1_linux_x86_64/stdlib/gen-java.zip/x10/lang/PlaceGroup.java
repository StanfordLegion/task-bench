package x10.lang;


/**
 * <p> A PlaceGroup represents an ordered set of Places.
 * PlaceGroups are represented by a specialized set of classes (instead of using
 * arbitrary collection types) because it is necessary for performance/scalability
 * to have optimized representations of specific special cases.  The API is also 
 * designed to efficiently support the operations needed by Team and DistArray.
 *
 * @see Place
 * @see x10.util.Team
 */
@x10.runtime.impl.java.X10Generated
abstract public class PlaceGroup extends x10.core.Ref implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PlaceGroup> $RTT = 
        x10.rtt.NamedType.<PlaceGroup> make("x10.lang.PlaceGroup",
                                            PlaceGroup.class,
                                            new x10.rtt.Type[] {
                                                x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.lang.Place.$RTT)
                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public PlaceGroup(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 35 "x10/lang/PlaceGroup.x10"
    /**
   * The size of the PlaceGroup is equal to the value returned by numPlaces()
   */
    final public long size$O() {
        
        //#line 35 "x10/lang/PlaceGroup.x10"
        final long t$134577 = this.numPlaces$O();
        
        //#line 35 "x10/lang/PlaceGroup.x10"
        return t$134577;
    }
    
    
    //#line 40 "x10/lang/PlaceGroup.x10"
    /**
   * @return the number of Places in the PlaceGroup
   */
    abstract public long numPlaces$O();
    
    
    //#line 45 "x10/lang/PlaceGroup.x10"
    /**
   * @return true if the PlaceGroup contains place, false otherwise
   */
    public boolean contains$O(final x10.lang.Place place) {
        
        //#line 45 "x10/lang/PlaceGroup.x10"
        final long t$134578 = place.id;
        
        //#line 45 "x10/lang/PlaceGroup.x10"
        final boolean t$134579 = this.contains$O((long)(t$134578));
        
        //#line 45 "x10/lang/PlaceGroup.x10"
        return t$134579;
    }
    
    
    //#line 51 "x10/lang/PlaceGroup.x10"
    /**
   * @return true if the PlaceGroup contains the place with
   *  the given id, false otherwise
   */
    abstract public boolean contains$O(final long id);
    
    
    //#line 65 "x10/lang/PlaceGroup.x10"
    /**
   * <p>If the argument place is contained in the PlaceGroup
   * return a long between 0 and numPlaces()-1 that is the
   * ordinal number of the Place in the PlaceGroup. 
   * If the argument place is not contained in the PlaceGroup,
   * then return -1.</p>
   *
   * <p>If the PlaceGroup pg contains place, then the invariant
   * <code>pg(indexOf(place)).equals(place) == true</code> holds.</p>
   * 
   * @return the index of place
   */
    public long indexOf$O(final x10.lang.Place place) {
        
        //#line 65 "x10/lang/PlaceGroup.x10"
        final long t$134580 = place.id;
        
        //#line 65 "x10/lang/PlaceGroup.x10"
        final long t$134581 = this.indexOf$O((long)(t$134580));
        
        //#line 65 "x10/lang/PlaceGroup.x10"
        return t$134581;
    }
    
    
    //#line 80 "x10/lang/PlaceGroup.x10"
    /**
   * <p>If the Place with id equal to id is contained in the PlaceGroup
   * return a long between 0 and numPlaces()-1 that is the
   * ordinal number of said Place in the PlaceGroup. 
   * If the argument place is not contained in the PlaceGroup,
   * then return -1.</p>
   *
   * <p>If the PlaceGroup pg contains the argument Place, 
   * then the invariant
   * <code>pg(indexOf(id)).equals(Place(id)) == true</code> holds.</p>
   * 
   * @return the index of the Place encoded by id
   */
    abstract public long indexOf$O(final long id);
    
    
    //#line 88 "x10/lang/PlaceGroup.x10"
    /**
   * Return the Place with ordinal number <code>i</code> in the place group
   *
   * @param i the ordinal number of the desired place
   * @return the ith place in the place group
   */
    abstract public x10.lang.Place $apply(final long i);
    
    
    //#line 96 "x10/lang/PlaceGroup.x10"
    /**
   * Return the next Place in iteration order from
   * the argument Place, with a wrap around to the 
   * first Place in iteration order if the argument 
   * Place is the last Place in iteration order.
   */
    public x10.lang.Place next(final x10.lang.Place p) {
        
        //#line 97 "x10/lang/PlaceGroup.x10"
        final long idx = this.indexOf$O(((x10.lang.Place)(p)));
        
        //#line 98 "x10/lang/PlaceGroup.x10"
        final boolean t$134583 = ((long) idx) == ((long) -1L);
        
        //#line 98 "x10/lang/PlaceGroup.x10"
        if (t$134583) {
            
            //#line 98 "x10/lang/PlaceGroup.x10"
            final x10.lang.Place t$134582 = ((x10.lang.Place)(x10.lang.Place.get$INVALID_PLACE()));
            
            //#line 98 "x10/lang/PlaceGroup.x10"
            return t$134582;
        }
        
        //#line 99 "x10/lang/PlaceGroup.x10"
        final long t$134584 = ((idx) + (((long)(1L))));
        
        //#line 99 "x10/lang/PlaceGroup.x10"
        final long t$134585 = this.numPlaces$O();
        
        //#line 99 "x10/lang/PlaceGroup.x10"
        final boolean t$134586 = ((long) t$134584) == ((long) t$134585);
        
        //#line 99 "x10/lang/PlaceGroup.x10"
        long t$134587 =  0;
        
        //#line 99 "x10/lang/PlaceGroup.x10"
        if (t$134586) {
            
            //#line 99 "x10/lang/PlaceGroup.x10"
            t$134587 = 0L;
        } else {
            
            //#line 99 "x10/lang/PlaceGroup.x10"
            t$134587 = ((idx) + (((long)(1L))));
        }
        
        //#line 100 "x10/lang/PlaceGroup.x10"
        final x10.lang.Place t$134588 = this.$apply((long)(t$134587));
        
        //#line 100 "x10/lang/PlaceGroup.x10"
        return t$134588;
    }
    
    
    //#line 109 "x10/lang/PlaceGroup.x10"
    /**
   * Return the previous Place in iteration order from
   * the argument Place, with a wrap around to the 
   * last Place in iteration order if the argument 
   * Place is the first Place in iteration order.
   */
    public x10.lang.Place prev(final x10.lang.Place p) {
        
        //#line 110 "x10/lang/PlaceGroup.x10"
        final long idx = this.indexOf$O(((x10.lang.Place)(p)));
        
        //#line 111 "x10/lang/PlaceGroup.x10"
        final boolean t$134590 = ((long) idx) == ((long) -1L);
        
        //#line 111 "x10/lang/PlaceGroup.x10"
        if (t$134590) {
            
            //#line 111 "x10/lang/PlaceGroup.x10"
            final x10.lang.Place t$134589 = ((x10.lang.Place)(x10.lang.Place.get$INVALID_PLACE()));
            
            //#line 111 "x10/lang/PlaceGroup.x10"
            return t$134589;
        }
        
        //#line 112 "x10/lang/PlaceGroup.x10"
        final boolean t$134592 = ((long) idx) == ((long) 0L);
        
        //#line 112 "x10/lang/PlaceGroup.x10"
        long t$134593 =  0;
        
        //#line 112 "x10/lang/PlaceGroup.x10"
        if (t$134592) {
            
            //#line 112 "x10/lang/PlaceGroup.x10"
            final long t$134591 = this.numPlaces$O();
            
            //#line 112 "x10/lang/PlaceGroup.x10"
            t$134593 = ((t$134591) - (((long)(1L))));
        } else {
            
            //#line 112 "x10/lang/PlaceGroup.x10"
            t$134593 = ((idx) - (((long)(1L))));
        }
        
        //#line 113 "x10/lang/PlaceGroup.x10"
        final x10.lang.Place t$134594 = this.$apply((long)(t$134593));
        
        //#line 113 "x10/lang/PlaceGroup.x10"
        return t$134594;
    }
    
    
    //#line 119 "x10/lang/PlaceGroup.x10"
    /**
   * Two place groups are equal iff they contain the same places
   */
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 120 "x10/lang/PlaceGroup.x10"
        final boolean t$134595 = x10.rtt.Equality.equalsequals((this),(thatObj));
        
        //#line 120 "x10/lang/PlaceGroup.x10"
        if (t$134595) {
            
            //#line 120 "x10/lang/PlaceGroup.x10"
            return true;
        }
        
        //#line 121 "x10/lang/PlaceGroup.x10"
        final boolean t$134596 = x10.lang.PlaceGroup.$RTT.isInstance(thatObj);
        
        //#line 121 "x10/lang/PlaceGroup.x10"
        final boolean t$134597 = !(t$134596);
        
        //#line 121 "x10/lang/PlaceGroup.x10"
        if (t$134597) {
            
            //#line 121 "x10/lang/PlaceGroup.x10"
            return false;
        }
        
        //#line 122 "x10/lang/PlaceGroup.x10"
        final x10.lang.PlaceGroup that = ((x10.lang.PlaceGroup)(x10.rtt.Types.<x10.lang.PlaceGroup> cast(thatObj,x10.lang.PlaceGroup.$RTT)));
        
        //#line 123 "x10/lang/PlaceGroup.x10"
        final long t$134598 = this.numPlaces$O();
        
        //#line 123 "x10/lang/PlaceGroup.x10"
        final long t$134599 = that.numPlaces$O();
        
        //#line 123 "x10/lang/PlaceGroup.x10"
        final boolean t$134600 = ((long) t$134598) != ((long) t$134599);
        
        //#line 123 "x10/lang/PlaceGroup.x10"
        if (t$134600) {
            
            //#line 123 "x10/lang/PlaceGroup.x10"
            return false;
        }
        
        //#line 124 "x10/lang/PlaceGroup.x10"
        long i$134696 = 0L;
        
        //#line 124 "x10/lang/PlaceGroup.x10"
        for (;
             true;
             ) {
            
            //#line 124 "x10/lang/PlaceGroup.x10"
            final long t$134698 = this.numPlaces$O();
            
            //#line 124 "x10/lang/PlaceGroup.x10"
            final boolean t$134699 = ((i$134696) < (((long)(t$134698))));
            
            //#line 124 "x10/lang/PlaceGroup.x10"
            if (!(t$134699)) {
                
                //#line 124 "x10/lang/PlaceGroup.x10"
                break;
            }
            
            //#line 125 "x10/lang/PlaceGroup.x10"
            final x10.lang.Place this$134687 = this.$apply((long)(i$134696));
            
            //#line 125 "x10/lang/PlaceGroup.x10"
            final x10.lang.Place p$134689 = ((x10.lang.Place)(that.$apply((long)(i$134696))));
            
            //#line 139 . "x10/lang/Place.x10"
            final long t$134690 = p$134689.id;
            
            //#line 139 . "x10/lang/Place.x10"
            final long t$134691 = this$134687.id;
            
            //#line 139 . "x10/lang/Place.x10"
            final boolean t$134692 = ((long) t$134690) == ((long) t$134691);
            
            //#line 125 "x10/lang/PlaceGroup.x10"
            final boolean t$134693 = !(t$134692);
            
            //#line 125 "x10/lang/PlaceGroup.x10"
            if (t$134693) {
                
                //#line 125 "x10/lang/PlaceGroup.x10"
                return false;
            }
            
            //#line 124 "x10/lang/PlaceGroup.x10"
            final long t$134695 = ((i$134696) + (((long)(1L))));
            
            //#line 124 "x10/lang/PlaceGroup.x10"
            i$134696 = t$134695;
        }
        
        //#line 127 "x10/lang/PlaceGroup.x10"
        return true;
    }
    
    
    //#line 135 "x10/lang/PlaceGroup.x10"
    /**
   * Execute the closure cl at every place in the PlaceGroup.
   * Note: cl must not have any exposed at/async constructs
   *    (any async/at must be nested inside of a finish).
   */
    public void broadcastFlat(final x10.core.fun.VoidFun_0_0 cl) {
        
        //#line 136 "x10/lang/PlaceGroup.x10"
        final x10.io.Serializer ser = ((x10.io.Serializer)(new x10.io.Serializer()));
        
        //#line 137 "x10/lang/PlaceGroup.x10"
        ser.writeAny(((java.lang.Object)(cl)));
        
        //#line 138 "x10/lang/PlaceGroup.x10"
        final x10.lang.PlaceGroup this$134560 = ((x10.lang.PlaceGroup)(this));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$134613 = this$134560.numPlaces$O();
        
        //#line 138 "x10/lang/PlaceGroup.x10"
        final long t$134614 = ((t$134613) - (((long)(1L))));
        
        //#line 138 "x10/lang/PlaceGroup.x10"
        ser.addDeserializeCount((long)(t$134614));
        
        //#line 139 "x10/lang/PlaceGroup.x10"
        final x10.core.Rail message = ser.toRail();
        {
            
            //#line 140 "x10/lang/PlaceGroup.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 140 "x10/lang/PlaceGroup.x10"
            final x10.xrx.FinishState fs$134759 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_SPMD));
            
            //#line 140 "x10/lang/PlaceGroup.x10"
            try {{
                {
                    
                    //#line 140 "x10/lang/PlaceGroup.x10"
                    final x10.lang.Iterator p$105309 = this.iterator();
                    
                    //#line 140 "x10/lang/PlaceGroup.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 140 "x10/lang/PlaceGroup.x10"
                        final boolean t$134617 = ((x10.lang.Iterator<x10.lang.Place>)p$105309).hasNext$O();
                        
                        //#line 140 "x10/lang/PlaceGroup.x10"
                        if (!(t$134617)) {
                            
                            //#line 140 "x10/lang/PlaceGroup.x10"
                            break;
                        }
                        
                        //#line 140 "x10/lang/PlaceGroup.x10"
                        final x10.lang.Place p$134700 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105309).next$G()));
                        
                        //#line 141 "x10/lang/PlaceGroup.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$134700)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceGroup.$Closure$125(message, (x10.lang.PlaceGroup.$Closure$125.__0$1x10$lang$Byte$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$134756) {
                
                //#line 140 "x10/lang/PlaceGroup.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$134756)));
                
                //#line 140 "x10/lang/PlaceGroup.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 140 "x10/lang/PlaceGroup.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$134759)));
             }}
            }
        }
    
    
    //#line 154 "x10/lang/PlaceGroup.x10"
    /**
   * Execute the closure cl at every live place in the PlaceGroup.
   * Note: cl must not have any exposed at/async constructs
   *    (any async/at must be nested inside of a finish).
   */
    public void broadcastFlat__1$1x10$lang$Place$3x10$lang$Boolean$2(final x10.core.fun.VoidFun_0_0 cl, final x10.core.fun.Fun_0_1 ignoreIfDead) {
        
        //#line 155 "x10/lang/PlaceGroup.x10"
        final x10.io.Serializer ser = ((x10.io.Serializer)(new x10.io.Serializer()));
        
        //#line 156 "x10/lang/PlaceGroup.x10"
        ser.writeAny(((java.lang.Object)(cl)));
        
        //#line 157 "x10/lang/PlaceGroup.x10"
        final x10.lang.PlaceGroup this$134562 = ((x10.lang.PlaceGroup)(this));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$134618 = this$134562.numPlaces$O();
        
        //#line 157 "x10/lang/PlaceGroup.x10"
        final long t$134619 = ((t$134618) - (((long)(1L))));
        
        //#line 157 "x10/lang/PlaceGroup.x10"
        ser.addDeserializeCount((long)(t$134619));
        
        //#line 158 "x10/lang/PlaceGroup.x10"
        final x10.core.Rail message = ser.toRail();
        
        //#line 159 "x10/lang/PlaceGroup.x10"
        long numSkipped = 0L;
        {
            
            //#line 160 "x10/lang/PlaceGroup.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 160 "x10/lang/PlaceGroup.x10"
            final x10.xrx.FinishState fs$134768 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_SPMD));
            
            //#line 160 "x10/lang/PlaceGroup.x10"
            try {{
                {
                    
                    //#line 160 "x10/lang/PlaceGroup.x10"
                    final x10.lang.Iterator p$105311 = this.iterator();
                    
                    //#line 160 "x10/lang/PlaceGroup.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 160 "x10/lang/PlaceGroup.x10"
                        final boolean t$134629 = ((x10.lang.Iterator<x10.lang.Place>)p$105311).hasNext$O();
                        
                        //#line 160 "x10/lang/PlaceGroup.x10"
                        if (!(t$134629)) {
                            
                            //#line 160 "x10/lang/PlaceGroup.x10"
                            break;
                        }
                        
                        //#line 160 "x10/lang/PlaceGroup.x10"
                        final x10.lang.Place p$134704 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105311).next$G()));
                        
                        //#line 128 . "x10/lang/Place.x10"
                        final long t$134705 = p$134704.id;
                        
                        //#line 128 . "x10/lang/Place.x10"
                        final boolean t$134706 = x10.x10rt.X10RT.isPlaceDead((int)((long)(t$134705)));
                        
                        //#line 161 "x10/lang/PlaceGroup.x10"
                        boolean t$134707 = !(t$134706);
                        
                        //#line 161 "x10/lang/PlaceGroup.x10"
                        if (!(t$134707)) {
                            
                            //#line 161 "x10/lang/PlaceGroup.x10"
                            final boolean t$134708 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean>)ignoreIfDead).$apply(p$134704, x10.lang.Place.$RTT));
                            
                            //#line 161 "x10/lang/PlaceGroup.x10"
                            t$134707 = !(t$134708);
                        }
                        
                        //#line 161 "x10/lang/PlaceGroup.x10"
                        if (t$134707) {
                            
                            //#line 162 "x10/lang/PlaceGroup.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$134704)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceGroup.$Closure$126(message, (x10.lang.PlaceGroup.$Closure$126.__0$1x10$lang$Byte$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                        } else {
                            
                            //#line 168 "x10/lang/PlaceGroup.x10"
                            final long t$134714 = ((numSkipped) + (((long)(1L))));
                            
                            //#line 168 "x10/lang/PlaceGroup.x10"
                            numSkipped = t$134714;
                        }
                    }
                }
            }}catch (java.lang.Throwable ct$134765) {
                
                //#line 160 "x10/lang/PlaceGroup.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$134765)));
                
                //#line 160 "x10/lang/PlaceGroup.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 160 "x10/lang/PlaceGroup.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$134768)));
             }}
            }
        
        //#line 171 "x10/lang/PlaceGroup.x10"
        final boolean t$134637 = ((numSkipped) > (((long)(0L))));
        
        //#line 171 "x10/lang/PlaceGroup.x10"
        if (t$134637) {
            
            //#line 172 "x10/lang/PlaceGroup.x10"
            long i$134720 = 1L;
            
            //#line 172 "x10/lang/PlaceGroup.x10"
            for (;
                 true;
                 ) {
                
                //#line 172 "x10/lang/PlaceGroup.x10"
                final boolean t$134722 = ((i$134720) <= (((long)(numSkipped))));
                
                //#line 172 "x10/lang/PlaceGroup.x10"
                if (!(t$134722)) {
                    
                    //#line 172 "x10/lang/PlaceGroup.x10"
                    break;
                }
                
                //#line 180 "x10/lang/PlaceGroup.x10"
                final x10.io.Deserializer dser$134715 = ((x10.io.Deserializer)(new x10.io.Deserializer(((x10.core.Rail)(message)), (x10.io.Deserializer.__0$1x10$lang$Byte$2) null)));
                
                //#line 181 "x10/lang/PlaceGroup.x10"
                final java.lang.Object t$134716 = dser$134715.readAny();
                
                //#line 181 "x10/lang/PlaceGroup.x10"
                x10.runtime.impl.java.EvalUtils.eval(x10.rtt.Types.<x10.core.fun.VoidFun_0_0> cast(t$134716,x10.core.fun.VoidFun_0_0.$RTT));
                
                //#line 172 "x10/lang/PlaceGroup.x10"
                final long t$134719 = ((i$134720) + (((long)(1L))));
                
                //#line 172 "x10/lang/PlaceGroup.x10"
                i$134720 = t$134719;
            }
        }
        }
    
    
    //#line 190 "x10/lang/PlaceGroup.x10"
    /** 
     * Return a new PlaceGroup which contains all places from this group
     * that are not dead places.
     */
    public x10.lang.PlaceGroup filterDeadPlaces() {
        
        //#line 191 "x10/lang/PlaceGroup.x10"
        final x10.util.ArrayList livePlaces = ((x10.util.ArrayList)(new x10.util.ArrayList<x10.lang.Place>((java.lang.System[]) null, x10.lang.Place.$RTT)));
        
        //#line 191 "x10/lang/PlaceGroup.x10"
        livePlaces.x10$util$ArrayList$$init$S();
        
        //#line 193 "x10/lang/PlaceGroup.x10"
        final x10.lang.Iterator pl$134727 = this.iterator();
        
        //#line 193 "x10/lang/PlaceGroup.x10"
        for (;
             true;
             ) {
            
            //#line 193 "x10/lang/PlaceGroup.x10"
            final boolean t$134728 = ((x10.lang.Iterator<x10.lang.Place>)pl$134727).hasNext$O();
            
            //#line 193 "x10/lang/PlaceGroup.x10"
            if (!(t$134728)) {
                
                //#line 193 "x10/lang/PlaceGroup.x10"
                break;
            }
            
            //#line 193 "x10/lang/PlaceGroup.x10"
            final x10.lang.Place pl$134723 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)pl$134727).next$G()));
            
            //#line 128 . "x10/lang/Place.x10"
            final long t$134724 = pl$134723.id;
            
            //#line 128 . "x10/lang/Place.x10"
            final boolean t$134725 = x10.x10rt.X10RT.isPlaceDead((int)((long)(t$134724)));
            
            //#line 194 "x10/lang/PlaceGroup.x10"
            final boolean t$134726 = !(t$134725);
            
            //#line 194 "x10/lang/PlaceGroup.x10"
            if (t$134726) {
                
                //#line 194 "x10/lang/PlaceGroup.x10"
                ((x10.util.ArrayList<x10.lang.Place>)livePlaces).add__0x10$util$ArrayList$$T$O(((x10.lang.Place)(pl$134723)));
            }
        }
        
        //#line 197 "x10/lang/PlaceGroup.x10"
        final x10.lang.SparsePlaceGroup alloc$105301 = ((x10.lang.SparsePlaceGroup)(new x10.lang.SparsePlaceGroup((java.lang.System[]) null)));
        
        //#line 197 "x10/lang/PlaceGroup.x10"
        final x10.core.Rail t$134729 = ((x10.core.Rail<x10.lang.Place>)
                                         ((x10.util.ArrayList<x10.lang.Place>)livePlaces).toRail());
        
        //#line 197 "x10/lang/PlaceGroup.x10"
        alloc$105301.x10$lang$SparsePlaceGroup$$init$S(t$134729, (x10.lang.SparsePlaceGroup.__0$1x10$lang$Place$2) null);
        
        //#line 197 "x10/lang/PlaceGroup.x10"
        return alloc$105301;
    }
    
    
    //#line 200 "x10/lang/PlaceGroup.x10"
    @x10.runtime.impl.java.X10Generated
    public static class SimplePlaceGroup extends x10.lang.PlaceGroup implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<SimplePlaceGroup> $RTT = 
            x10.rtt.NamedType.<SimplePlaceGroup> make("x10.lang.PlaceGroup.SimplePlaceGroup",
                                                      SimplePlaceGroup.class,
                                                      new x10.rtt.Type[] {
                                                          x10.lang.PlaceGroup.$RTT
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup.SimplePlaceGroup $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceGroup.$_deserialize_body($_obj, $deserializer);
            $_obj.numPlaces = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceGroup.SimplePlaceGroup $_obj = new x10.lang.PlaceGroup.SimplePlaceGroup((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            super.$_serialize($serializer);
            $serializer.write(this.numPlaces);
            
        }
        
        // constructor just for allocation
        public SimplePlaceGroup(final java.lang.System[] $dummy) {
            super($dummy);
            
        }
        
        
    
        
        //#line 201 "x10/lang/PlaceGroup.x10"
        public long numPlaces;
        
        
        //#line 202 "x10/lang/PlaceGroup.x10"
        // creation method for java code (1-phase java constructor)
        public SimplePlaceGroup(final long numPlaces) {
            this((java.lang.System[]) null);
            x10$lang$PlaceGroup$SimplePlaceGroup$$init$S(numPlaces);
        }
        
        // constructor for non-virtual call
        final public x10.lang.PlaceGroup.SimplePlaceGroup x10$lang$PlaceGroup$SimplePlaceGroup$$init$S(final long numPlaces) {
             {
                
                //#line 202 "x10/lang/PlaceGroup.x10"
                
                
                //#line 202 "x10/lang/PlaceGroup.x10"
                this.numPlaces = numPlaces;
            }
            return this;
        }
        
        
        
        //#line 203 "x10/lang/PlaceGroup.x10"
        public x10.lang.Place $apply(final long i) {
            
            //#line 203 "x10/lang/PlaceGroup.x10"
            final x10.lang.Place alloc$105302 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 203 "x10/lang/PlaceGroup.x10"
            alloc$105302.x10$lang$Place$$init$S(((long)(i)));
            
            //#line 203 "x10/lang/PlaceGroup.x10"
            return alloc$105302;
        }
        
        
        //#line 204 "x10/lang/PlaceGroup.x10"
        public long numPlaces$O() {
            
            //#line 204 "x10/lang/PlaceGroup.x10"
            final long t$134644 = this.numPlaces;
            
            //#line 204 "x10/lang/PlaceGroup.x10"
            return t$134644;
        }
        
        
        //#line 205 "x10/lang/PlaceGroup.x10"
        public boolean contains$O(final long id) {
            
            //#line 205 "x10/lang/PlaceGroup.x10"
            boolean t$134646 = ((id) >= (((long)(0L))));
            
            //#line 205 "x10/lang/PlaceGroup.x10"
            if (t$134646) {
                
                //#line 205 "x10/lang/PlaceGroup.x10"
                final long t$134645 = this.numPlaces;
                
                //#line 205 "x10/lang/PlaceGroup.x10"
                t$134646 = ((id) < (((long)(t$134645))));
            }
            
            //#line 205 "x10/lang/PlaceGroup.x10"
            return t$134646;
        }
        
        
        //#line 206 "x10/lang/PlaceGroup.x10"
        public long indexOf$O(final long id) {
            
            //#line 206 "x10/lang/PlaceGroup.x10"
            final boolean t$134648 = this.contains$O((long)(id));
            
            //#line 206 "x10/lang/PlaceGroup.x10"
            long t$134649 =  0;
            
            //#line 206 "x10/lang/PlaceGroup.x10"
            if (t$134648) {
                
                //#line 206 "x10/lang/PlaceGroup.x10"
                t$134649 = id;
            } else {
                
                //#line 206 "x10/lang/PlaceGroup.x10"
                t$134649 = -1L;
            }
            
            //#line 206 "x10/lang/PlaceGroup.x10"
            return t$134649;
        }
        
        
        //#line 207 "x10/lang/PlaceGroup.x10"
        public x10.lang.Iterator iterator() {
            
            //#line 207 "x10/lang/PlaceGroup.x10"
            final x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956 alloc$105303 = ((x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956)(new x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956((java.lang.System[]) null)));
            
            //#line 207 "x10/lang/PlaceGroup.x10"
            final x10.lang.PlaceGroup.SimplePlaceGroup out$134571 = ((x10.lang.PlaceGroup.SimplePlaceGroup)(this));
            
            //#line 200 . "x10/lang/PlaceGroup.x10"
            alloc$105303.out$ = out$134571;
            
            //#line 207 "x10/lang/PlaceGroup.x10"
            return alloc$105303;
        }
        
        
        //#line 212 "x10/lang/PlaceGroup.x10"
        public boolean equals(final java.lang.Object thatObj) {
            
            //#line 213 "x10/lang/PlaceGroup.x10"
            final boolean t$134656 = x10.lang.PlaceGroup.SimplePlaceGroup.$RTT.isInstance(thatObj);
            
            //#line 213 "x10/lang/PlaceGroup.x10"
            if (t$134656) {
                
                //#line 214 "x10/lang/PlaceGroup.x10"
                final long t$134652 = this.numPlaces$O();
                
                //#line 214 "x10/lang/PlaceGroup.x10"
                final x10.lang.PlaceGroup.SimplePlaceGroup t$134651 = ((x10.lang.PlaceGroup.SimplePlaceGroup)(x10.rtt.Types.<x10.lang.PlaceGroup.SimplePlaceGroup> cast(thatObj,x10.lang.PlaceGroup.SimplePlaceGroup.$RTT)));
                
                //#line 214 "x10/lang/PlaceGroup.x10"
                final long t$134653 = t$134651.numPlaces$O();
                
                //#line 214 "x10/lang/PlaceGroup.x10"
                final boolean t$134654 = ((long) t$134652) == ((long) t$134653);
                
                //#line 214 "x10/lang/PlaceGroup.x10"
                return t$134654;
            } else {
                
                //#line 216 "x10/lang/PlaceGroup.x10"
                final boolean t$134655 = super.equals(((java.lang.Object)(thatObj)));
                
                //#line 216 "x10/lang/PlaceGroup.x10"
                return t$134655;
            }
        }
        
        
        //#line 219 "x10/lang/PlaceGroup.x10"
        public int hashCode() {
            
            //#line 219 "x10/lang/PlaceGroup.x10"
            final long t$134657 = this.numPlaces;
            
            //#line 219 "x10/lang/PlaceGroup.x10"
            final int t$134658 = x10.rtt.Types.hashCode(t$134657);
            
            //#line 219 "x10/lang/PlaceGroup.x10"
            return t$134658;
        }
        
        
        //#line 220 "x10/lang/PlaceGroup.x10"
        public void broadcastFlat(final x10.core.fun.VoidFun_0_0 cl) {
            
            //#line 221 "x10/lang/PlaceGroup.x10"
            final long t$134659 = this.numPlaces$O();
            
            //#line 221 "x10/lang/PlaceGroup.x10"
            final boolean t$134677 = ((t$134659) >= (((long)(1024L))));
            
            //#line 221 "x10/lang/PlaceGroup.x10"
            if (t$134677) {
                
                //#line 222 "x10/lang/PlaceGroup.x10"
                final x10.io.Serializer ser = ((x10.io.Serializer)(new x10.io.Serializer()));
                
                //#line 223 "x10/lang/PlaceGroup.x10"
                ser.writeAny(((java.lang.Object)(cl)));
                
                //#line 224 "x10/lang/PlaceGroup.x10"
                final x10.lang.PlaceGroup this$134573 = ((x10.lang.PlaceGroup)
                                                          this);
                
                //#line 35 . "x10/lang/PlaceGroup.x10"
                final long t$134660 = this$134573.numPlaces$O();
                
                //#line 224 "x10/lang/PlaceGroup.x10"
                final long t$134661 = ((t$134660) - (((long)(1L))));
                
                //#line 224 "x10/lang/PlaceGroup.x10"
                ser.addDeserializeCount((long)(t$134661));
                
                //#line 225 "x10/lang/PlaceGroup.x10"
                final x10.core.Rail message = ser.toRail();
                {
                    
                    //#line 226 "x10/lang/PlaceGroup.x10"
                    x10.xrx.Runtime.ensureNotInAtomic();
                    
                    //#line 226 "x10/lang/PlaceGroup.x10"
                    final x10.xrx.FinishState fs$134786 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_SPMD));
                    
                    //#line 226 "x10/lang/PlaceGroup.x10"
                    try {{
                        {
                            
                            //#line 226 "x10/lang/PlaceGroup.x10"
                            final long t$134663 = this.numPlaces$O();
                            
                            //#line 226 "x10/lang/PlaceGroup.x10"
                            long i = ((t$134663) - (((long)(1L))));
                            
                            //#line 226 "x10/lang/PlaceGroup.x10"
                            for (;
                                 true;
                                 ) {
                                
                                //#line 226 "x10/lang/PlaceGroup.x10"
                                final boolean t$134676 = ((i) >= (((long)(0L))));
                                
                                //#line 226 "x10/lang/PlaceGroup.x10"
                                if (!(t$134676)) {
                                    
                                    //#line 226 "x10/lang/PlaceGroup.x10"
                                    break;
                                }
                                
                                //#line 227 "x10/lang/PlaceGroup.x10"
                                final x10.lang.Place alloc$134739 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                                
                                //#line 227 "x10/lang/PlaceGroup.x10"
                                alloc$134739.x10$lang$Place$$init$S(i);
                                
                                //#line 227 "x10/lang/PlaceGroup.x10"
                                x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$134739)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$124(message, (x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$124.__0$1x10$lang$Byte$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                                
                                //#line 226 "x10/lang/PlaceGroup.x10"
                                final long t$134747 = ((i) - (((long)(32L))));
                                
                                //#line 226 "x10/lang/PlaceGroup.x10"
                                i = t$134747;
                            }
                        }
                    }}catch (java.lang.Throwable ct$134783) {
                        
                        //#line 226 "x10/lang/PlaceGroup.x10"
                        x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$134783)));
                        
                        //#line 226 "x10/lang/PlaceGroup.x10"
                        throw new java.lang.RuntimeException();
                    }finally {{
                         
                         //#line 226 "x10/lang/PlaceGroup.x10"
                         x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$134786)));
                     }}
                    }
                } else {
                    
                    //#line 240 "x10/lang/PlaceGroup.x10"
                    super.broadcastFlat(((x10.core.fun.VoidFun_0_0)(cl)));
                }
            }
        
        
        //#line 200 "x10/lang/PlaceGroup.x10"
        final public x10.lang.PlaceGroup.SimplePlaceGroup x10$lang$PlaceGroup$SimplePlaceGroup$$this$x10$lang$PlaceGroup$SimplePlaceGroup() {
            
            //#line 200 "x10/lang/PlaceGroup.x10"
            return x10.lang.PlaceGroup.SimplePlaceGroup.this;
        }
        
        
        //#line 200 "x10/lang/PlaceGroup.x10"
        final public void __fieldInitializers_x10_lang_PlaceGroup_SimplePlaceGroup() {
            
        }
        
        
        //#line 207 "x10/lang/PlaceGroup.x10"
        @x10.runtime.impl.java.X10Generated
        final public static class Anonymous$6956 extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<Anonymous$6956> $RTT = 
                x10.rtt.NamedType.<Anonymous$6956> make("x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956",
                                                        Anonymous$6956.class,
                                                        new x10.rtt.Type[] {
                                                            x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Place.$RTT)
                                                        });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.i = $deserializer.readLong();
                $_obj.out$ = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956 $_obj = new x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.i);
                $serializer.write(this.out$);
                
            }
            
            // constructor just for allocation
            public Anonymous$6956(final java.lang.System[] $dummy) {
                
            }
            
            // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
            public x10.lang.Place next$G() {
                return next();
            }
            
            
        
            
            //#line 200 "x10/lang/PlaceGroup.x10"
            public x10.lang.PlaceGroup.SimplePlaceGroup out$;
            
            //#line 208 "x10/lang/PlaceGroup.x10"
            public long i = 0L;
            
            
            //#line 209 "x10/lang/PlaceGroup.x10"
            public boolean hasNext$O() {
                
                //#line 209 "x10/lang/PlaceGroup.x10"
                final long t$134679 = this.i;
                
                //#line 209 "x10/lang/PlaceGroup.x10"
                final x10.lang.PlaceGroup.SimplePlaceGroup t$134678 = this.out$;
                
                //#line 209 "x10/lang/PlaceGroup.x10"
                final long t$134680 = t$134678.numPlaces;
                
                //#line 209 "x10/lang/PlaceGroup.x10"
                final boolean t$134681 = ((t$134679) < (((long)(t$134680))));
                
                //#line 209 "x10/lang/PlaceGroup.x10"
                return t$134681;
            }
            
            
            //#line 210 "x10/lang/PlaceGroup.x10"
            public x10.lang.Place next() {
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                final x10.lang.Place alloc$105306 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                final long t$134748 = this.i;
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                final long t$134749 = ((t$134748) + (((long)(1L))));
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                final long t$134750 = this.i = t$134749;
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                final long t$134751 = ((t$134750) - (((long)(1L))));
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                alloc$105306.x10$lang$Place$$init$S(t$134751);
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                return alloc$105306;
            }
            
            
            //#line 207 "x10/lang/PlaceGroup.x10"
            // creation method for java code (1-phase java constructor)
            public Anonymous$6956(final x10.lang.PlaceGroup.SimplePlaceGroup out$) {
                this((java.lang.System[]) null);
                x10$lang$PlaceGroup$SimplePlaceGroup$Anonymous$6956$$init$S(out$);
            }
            
            // constructor for non-virtual call
            final public x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956 x10$lang$PlaceGroup$SimplePlaceGroup$Anonymous$6956$$init$S(final x10.lang.PlaceGroup.SimplePlaceGroup out$) {
                 {
                    
                    //#line 200 "x10/lang/PlaceGroup.x10"
                    this.out$ = out$;
                }
                return this;
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$123 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$123> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$123> make($Closure$123.class,
                                                              new x10.rtt.Type[] {
                                                                  x10.core.fun.VoidFun_0_0.$RTT
                                                              });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$123 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.message = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$123 $_obj = new x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$123((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.message);
                
            }
            
            // constructor just for allocation
            public $Closure$123(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Byte$2 {}
            
        
            
            public void $apply() {
                
                //#line 231 "x10/lang/PlaceGroup.x10"
                try {{
                    
                    //#line 232 "x10/lang/PlaceGroup.x10"
                    final x10.io.Deserializer dser$134733 = ((x10.io.Deserializer)(new x10.io.Deserializer(this.message, (x10.io.Deserializer.__0$1x10$lang$Byte$2) null)));
                    
                    //#line 233 "x10/lang/PlaceGroup.x10"
                    final java.lang.Object t$134734 = dser$134733.readAny();
                    
                    //#line 233 "x10/lang/PlaceGroup.x10"
                    final x10.core.fun.VoidFun_0_0 cls$134735 = x10.rtt.Types.<x10.core.fun.VoidFun_0_0> cast(t$134734,x10.core.fun.VoidFun_0_0.$RTT);
                    
                    //#line 234 "x10/lang/PlaceGroup.x10"
                    ((x10.core.fun.VoidFun_0_0)cls$134735).$apply();
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 231 "x10/lang/PlaceGroup.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 231 "x10/lang/PlaceGroup.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.core.Rail<x10.core.Byte> message;
            
            public $Closure$123(final x10.core.Rail<x10.core.Byte> message, __0$1x10$lang$Byte$2 $dummy) {
                 {
                    this.message = ((x10.core.Rail)(message));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$124 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$124> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$124> make($Closure$124.class,
                                                              new x10.rtt.Type[] {
                                                                  x10.core.fun.VoidFun_0_0.$RTT
                                                              });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$124 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.message = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$124 $_obj = new x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$124((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.message);
                
            }
            
            // constructor just for allocation
            public $Closure$124(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Byte$2 {}
            
        
            
            public void $apply() {
                
                //#line 227 "x10/lang/PlaceGroup.x10"
                try {{
                    
                    //#line 228 "x10/lang/PlaceGroup.x10"
                    final long max$134740 = x10.x10rt.X10RT.here().id;
                    
                    //#line 229 "x10/lang/PlaceGroup.x10"
                    final long t$134741 = ((max$134740) - (((long)(31L))));
                    
                    //#line 229 "x10/lang/PlaceGroup.x10"
                    final long min$134742 = java.lang.Math.max(((long)(t$134741)),((long)(0L)));
                    {
                        
                        //#line 230 "x10/lang/PlaceGroup.x10"
                        x10.xrx.Runtime.ensureNotInAtomic();
                        
                        //#line 230 "x10/lang/PlaceGroup.x10"
                        final x10.xrx.FinishState fs$134777 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_SPMD));
                        
                        //#line 230 "x10/lang/PlaceGroup.x10"
                        try {{
                            {
                                
                                //#line 230 "x10/lang/PlaceGroup.x10"
                                long j$134743 = min$134742;
                                
                                //#line 230 "x10/lang/PlaceGroup.x10"
                                for (;
                                     true;
                                     ) {
                                    
                                    //#line 230 "x10/lang/PlaceGroup.x10"
                                    final boolean t$134745 = ((j$134743) <= (((long)(max$134740))));
                                    
                                    //#line 230 "x10/lang/PlaceGroup.x10"
                                    if (!(t$134745)) {
                                        
                                        //#line 230 "x10/lang/PlaceGroup.x10"
                                        break;
                                    }
                                    
                                    //#line 231 "x10/lang/PlaceGroup.x10"
                                    final x10.lang.Place alloc$134732 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                                    
                                    //#line 231 "x10/lang/PlaceGroup.x10"
                                    alloc$134732.x10$lang$Place$$init$S(j$134743);
                                    
                                    //#line 231 "x10/lang/PlaceGroup.x10"
                                    x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$134732)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$123(((x10.core.Rail)(this.message)), (x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$123.__0$1x10$lang$Byte$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                                    
                                    //#line 230 "x10/lang/PlaceGroup.x10"
                                    final long t$134737 = ((j$134743) + (((long)(1L))));
                                    
                                    //#line 230 "x10/lang/PlaceGroup.x10"
                                    j$134743 = t$134737;
                                }
                            }
                        }}catch (java.lang.Throwable ct$134774) {
                            
                            //#line 230 "x10/lang/PlaceGroup.x10"
                            x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$134774)));
                            
                            //#line 230 "x10/lang/PlaceGroup.x10"
                            throw new java.lang.RuntimeException();
                        }finally {{
                             
                             //#line 230 "x10/lang/PlaceGroup.x10"
                             x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$134777)));
                         }}
                        }
                    }}catch (java.lang.Error __lowerer__var__0__) {
                        
                        //#line 227 "x10/lang/PlaceGroup.x10"
                        throw __lowerer__var__0__;
                    }catch (java.lang.Throwable __lowerer__var__1__) {
                        
                        //#line 227 "x10/lang/PlaceGroup.x10"
                        throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                    }
                }
            
            public x10.core.Rail<x10.core.Byte> message;
            
            public $Closure$124(final x10.core.Rail<x10.core.Byte> message, __0$1x10$lang$Byte$2 $dummy) {
                 {
                    this.message = ((x10.core.Rail)(message));
                }
            }
            
            }
            
        
        public boolean x10$lang$PlaceGroup$equals$S$O(final java.lang.Object a0) {
            return super.equals(((java.lang.Object)(a0)));
        }
        
        public void x10$lang$PlaceGroup$broadcastFlat$S(final x10.core.fun.VoidFun_0_0 a0) {
            super.broadcastFlat(((x10.core.fun.VoidFun_0_0)(a0)));
        }
        }
        
        
        
        //#line 245 "x10/lang/PlaceGroup.x10"
        public static x10.lang.PlaceGroup.SimplePlaceGroup make(final long numPlaces) {
            
            //#line 245 "x10/lang/PlaceGroup.x10"
            final x10.lang.PlaceGroup.SimplePlaceGroup alloc$105307 = ((x10.lang.PlaceGroup.SimplePlaceGroup)(new x10.lang.PlaceGroup.SimplePlaceGroup((java.lang.System[]) null)));
            
            //#line 245 "x10/lang/PlaceGroup.x10"
            alloc$105307.x10$lang$PlaceGroup$SimplePlaceGroup$$init$S(((long)(numPlaces)));
            
            //#line 245 "x10/lang/PlaceGroup.x10"
            return alloc$105307;
        }
        
        
        //#line 30 "x10/lang/PlaceGroup.x10"
        final public x10.lang.PlaceGroup x10$lang$PlaceGroup$$this$x10$lang$PlaceGroup() {
            
            //#line 30 "x10/lang/PlaceGroup.x10"
            return x10.lang.PlaceGroup.this;
        }
        
        
        //#line 30 "x10/lang/PlaceGroup.x10"
        
        // constructor for non-virtual call
        final public x10.lang.PlaceGroup x10$lang$PlaceGroup$$init$S() {
             {
                
                //#line 30 "x10/lang/PlaceGroup.x10"
                
            }
            return this;
        }
        
        
        
        //#line 30 "x10/lang/PlaceGroup.x10"
        abstract public x10.lang.Iterator iterator();
        
        
        //#line 30 "x10/lang/PlaceGroup.x10"
        final public void __fieldInitializers_x10_lang_PlaceGroup() {
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$125 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$125> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$125> make($Closure$125.class,
                                                              new x10.rtt.Type[] {
                                                                  x10.core.fun.VoidFun_0_0.$RTT
                                                              });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup.$Closure$125 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.message = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.lang.PlaceGroup.$Closure$125 $_obj = new x10.lang.PlaceGroup.$Closure$125((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.message);
                
            }
            
            // constructor just for allocation
            public $Closure$125(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Byte$2 {}
            
        
            
            public void $apply() {
                
                //#line 141 "x10/lang/PlaceGroup.x10"
                try {{
                    
                    //#line 142 "x10/lang/PlaceGroup.x10"
                    final x10.io.Deserializer dser$134701 = ((x10.io.Deserializer)(new x10.io.Deserializer(this.message, (x10.io.Deserializer.__0$1x10$lang$Byte$2) null)));
                    
                    //#line 143 "x10/lang/PlaceGroup.x10"
                    final java.lang.Object t$134702 = dser$134701.readAny();
                    
                    //#line 143 "x10/lang/PlaceGroup.x10"
                    final x10.core.fun.VoidFun_0_0 cls$134703 = x10.rtt.Types.<x10.core.fun.VoidFun_0_0> cast(t$134702,x10.core.fun.VoidFun_0_0.$RTT);
                    
                    //#line 144 "x10/lang/PlaceGroup.x10"
                    ((x10.core.fun.VoidFun_0_0)cls$134703).$apply();
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 141 "x10/lang/PlaceGroup.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 141 "x10/lang/PlaceGroup.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.core.Rail<x10.core.Byte> message;
            
            public $Closure$125(final x10.core.Rail<x10.core.Byte> message, __0$1x10$lang$Byte$2 $dummy) {
                 {
                    this.message = ((x10.core.Rail)(message));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$126 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$126> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$126> make($Closure$126.class,
                                                              new x10.rtt.Type[] {
                                                                  x10.core.fun.VoidFun_0_0.$RTT
                                                              });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup.$Closure$126 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.message = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.lang.PlaceGroup.$Closure$126 $_obj = new x10.lang.PlaceGroup.$Closure$126((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.message);
                
            }
            
            // constructor just for allocation
            public $Closure$126(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Byte$2 {}
            
        
            
            public void $apply() {
                
                //#line 162 "x10/lang/PlaceGroup.x10"
                try {{
                    
                    //#line 163 "x10/lang/PlaceGroup.x10"
                    final x10.io.Deserializer dser$134710 = ((x10.io.Deserializer)(new x10.io.Deserializer(this.message, (x10.io.Deserializer.__0$1x10$lang$Byte$2) null)));
                    
                    //#line 164 "x10/lang/PlaceGroup.x10"
                    final java.lang.Object t$134711 = dser$134710.readAny();
                    
                    //#line 164 "x10/lang/PlaceGroup.x10"
                    final x10.core.fun.VoidFun_0_0 cls$134712 = x10.rtt.Types.<x10.core.fun.VoidFun_0_0> cast(t$134711,x10.core.fun.VoidFun_0_0.$RTT);
                    
                    //#line 165 "x10/lang/PlaceGroup.x10"
                    ((x10.core.fun.VoidFun_0_0)cls$134712).$apply();
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 162 "x10/lang/PlaceGroup.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 162 "x10/lang/PlaceGroup.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.core.Rail<x10.core.Byte> message;
            
            public $Closure$126(final x10.core.Rail<x10.core.Byte> message, __0$1x10$lang$Byte$2 $dummy) {
                 {
                    this.message = ((x10.core.Rail)(message));
                }
            }
            
        }
        
    }
    
    