package x10.lang;


/**
 * This interface provides uniform, read-only access to different kinds of Char sequences.
 */
;

