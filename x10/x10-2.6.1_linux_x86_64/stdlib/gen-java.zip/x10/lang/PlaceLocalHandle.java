package x10.lang;


/**
 * The primary operation on a PlaceLocalHandle is to use it to access an object
 * on the current place.  If the current place is not part of the PlaceGroup
 * over which the PlaceLocalHandle is defined, a BadPlaceException will be thrown.</p>
 *
 * A key concept for correct usage of PlaceLocalHandles is that in different places,
 * the Handle may be mapped to distinct objects.  For example (assuming >1 Place):
 * <pre>
 *   val plh:PlaceLocalHandle[T] = ....;
 *   val obj:T = plh();
 *   at (here.next()) Console.out.println(plh() == obj);
 * </pre>
 * may print either true or false depending on how the application is
 * using the particular PlaceLocalHandle (mapping the same object at
 * multiple places or mapping distinct object at each place).</p>
 */
@x10.runtime.impl.java.X10Generated
final public class PlaceLocalHandle<$T> extends x10.core.Struct implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PlaceLocalHandle> $RTT = 
        x10.rtt.NamedStructType.<PlaceLocalHandle> make("x10.lang.PlaceLocalHandle",
                                                        PlaceLocalHandle.class,
                                                        1,
                                                        new x10.rtt.Type[] {
                                                            x10.rtt.Types.STRUCT
                                                        });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.__NATIVE_FIELD__ = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.PlaceLocalHandle $_obj = new x10.lang.PlaceLocalHandle(null, (java.lang.System) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.__NATIVE_FIELD__);
        
    }
    
    // zero value constructor
    public PlaceLocalHandle(final x10.rtt.Type $T, final java.lang.System $dummy) { this.$T = $T; this.__NATIVE_FIELD__ = new x10.core.PlaceLocalHandle<$T>($T, $dummy); }
    
    // constructor just for allocation
    public PlaceLocalHandle(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.lang.PlaceLocalHandle.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final PlaceLocalHandle $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    

    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    public x10.core.PlaceLocalHandle<$T> __NATIVE_FIELD__;
    
    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    public PlaceLocalHandle(final x10.rtt.Type $T, final x10.core.PlaceLocalHandle<$T> id0) {
        x10.lang.PlaceLocalHandle.$initParams(this, $T);
         {
            
            //#line 35 "x10/lang/PlaceLocalHandle.x10"
            ((x10.lang.PlaceLocalHandle<$T>)this).__NATIVE_FIELD__ = id0;
        }
    }
    
    
    
    //#line 38 "x10/lang/PlaceLocalHandle.x10"
    public PlaceLocalHandle(final x10.rtt.Type $T) {
        x10.lang.PlaceLocalHandle.$initParams(this, $T);
         {
            
            //#line 35 "x10/lang/PlaceLocalHandle.x10"
            ((x10.lang.PlaceLocalHandle<$T>)this).__NATIVE_FIELD__ = new x10.core.PlaceLocalHandle<$T>((java.lang.System[]) null, $T).x10$core$PlaceLocalHandle$$init$S();
        }
    }
    
    
    
    //#line 43 "x10/lang/PlaceLocalHandle.x10"
    /**
     * @return the object mapped to the handle at the current place
     */
    final public $T $apply$G() {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.PlaceLocalHandle t$134788 = this.__NATIVE_FIELD__;
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final $T t$134789 = (($T)(((x10.core.PlaceLocalHandle<$T>)t$134788).$apply$G()));
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return t$134789;
    }
    
    
    //#line 46 "x10/lang/PlaceLocalHandle.x10"
    final public void set__0x10$lang$PlaceLocalHandle$$T(final $T newVal) {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.PlaceLocalHandle t$134790 = this.__NATIVE_FIELD__;
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        ((x10.core.PlaceLocalHandle<$T>)t$134790).set__0x10$lang$PlaceLocalHandle$$T((($T)(newVal)));
    }
    
    
    //#line 48 "x10/lang/PlaceLocalHandle.x10"
    final public int hashCode() {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.PlaceLocalHandle t$134791 = this.__NATIVE_FIELD__;
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final int t$134792 = ((x10.core.PlaceLocalHandle<$T>)t$134791).hashCode();
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return t$134792;
    }
    
    
    //#line 50 "x10/lang/PlaceLocalHandle.x10"
    final public java.lang.String toString() {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.PlaceLocalHandle t$134793 = this.__NATIVE_FIELD__;
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final java.lang.String t$134794 = ((x10.core.PlaceLocalHandle<$T>)t$134793).toString();
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return t$134794;
    }
    
    
    //#line 63 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  The local object will be initialized
     * by evaluating init at each place.  When this method returns, the local objects
     * will be initialized and available via the returned PlaceLocalHandle instance
     * at every place in the PlaceGroup.
     *
     * @param pg a PlaceGroup specifiying the places where local objects should be created.
     * @param init the initialization closure used to create the local object.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T>x10.lang.PlaceLocalHandle make__1$1x10$lang$PlaceLocalHandle$$T$2(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<$T> init) {
        
        //#line 64 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        {
            
            //#line 65 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 65 "x10/lang/PlaceLocalHandle.x10"
            final x10.xrx.FinishState fs$134880 = x10.xrx.Runtime.startFinish();
            
            //#line 65 "x10/lang/PlaceLocalHandle.x10"
            try {{
                {
                    
                    //#line 65 "x10/lang/PlaceLocalHandle.x10"
                    final x10.lang.Iterator p$105120 = pg.iterator();
                    
                    //#line 65 "x10/lang/PlaceLocalHandle.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 65 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$134797 = ((x10.lang.Iterator<x10.lang.Place>)p$105120).hasNext$O();
                        
                        //#line 65 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$134797)) {
                            
                            //#line 65 "x10/lang/PlaceLocalHandle.x10"
                            break;
                        }
                        
                        //#line 65 "x10/lang/PlaceLocalHandle.x10"
                        final x10.lang.Place p$134846 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105120).next$G()));
                        
                        //#line 66 "x10/lang/PlaceLocalHandle.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$134846)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$127<$T>($T, init, handle, (x10.lang.PlaceLocalHandle.$Closure$127.__0$1x10$lang$PlaceLocalHandle$$Closure$127$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$127$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$134878) {
                
                //#line 65 "x10/lang/PlaceLocalHandle.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$134878)));
                
                //#line 65 "x10/lang/PlaceLocalHandle.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 65 "x10/lang/PlaceLocalHandle.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$134880)));
             }}
            }
        
        //#line 68 "x10/lang/PlaceLocalHandle.x10"
        return handle;
        }
    
    
    //#line 84 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  The local object will be initialized
     * by evaluating init at each place.  When this method returns, the local objects
     * will be initialized and available via the returned PlaceLocalHandle instance
     * at every place in the PlaceGroup.
     *
     * @param pg a PlaceGroup specifiying the places where local objects should be created.
     * @param init the initialization closure used to create the local object.
     * @param ignoreIfDead a filter to indicate if a place can be silently ignored if it is 
     *        already known to be dead at the time make first attempt to access it.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T>x10.lang.PlaceLocalHandle make__1$1x10$lang$PlaceLocalHandle$$T$2__2$1x10$lang$Place$3x10$lang$Boolean$2(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<$T> init, final x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean> ignoreIfDead) {
        
        //#line 86 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        {
            
            //#line 87 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 87 "x10/lang/PlaceLocalHandle.x10"
            final x10.xrx.FinishState fs$134888 = x10.xrx.Runtime.startFinish();
            
            //#line 87 "x10/lang/PlaceLocalHandle.x10"
            try {{
                {
                    
                    //#line 87 "x10/lang/PlaceLocalHandle.x10"
                    final x10.lang.Iterator p$105122 = pg.iterator();
                    
                    //#line 87 "x10/lang/PlaceLocalHandle.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 87 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$134804 = ((x10.lang.Iterator<x10.lang.Place>)p$105122).hasNext$O();
                        
                        //#line 87 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$134804)) {
                            
                            //#line 87 "x10/lang/PlaceLocalHandle.x10"
                            break;
                        }
                        
                        //#line 87 "x10/lang/PlaceLocalHandle.x10"
                        final x10.lang.Place p$134848 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105122).next$G()));
                        
                        //#line 88 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$134849 = p$134848.isDead$O();
                        
                        //#line 88 "x10/lang/PlaceLocalHandle.x10"
                        boolean t$134850 = !(t$134849);
                        
                        //#line 88 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$134850)) {
                            
                            //#line 88 "x10/lang/PlaceLocalHandle.x10"
                            final boolean t$134851 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean>)ignoreIfDead).$apply(p$134848, x10.lang.Place.$RTT));
                            
                            //#line 88 "x10/lang/PlaceLocalHandle.x10"
                            t$134850 = !(t$134851);
                        }
                        
                        //#line 88 "x10/lang/PlaceLocalHandle.x10"
                        if (t$134850) {
                            
                            //#line 89 "x10/lang/PlaceLocalHandle.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$134848)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$128<$T>($T, init, handle, (x10.lang.PlaceLocalHandle.$Closure$128.__0$1x10$lang$PlaceLocalHandle$$Closure$128$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$128$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                        }
                    }
                }
            }}catch (java.lang.Throwable ct$134886) {
                
                //#line 87 "x10/lang/PlaceLocalHandle.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$134886)));
                
                //#line 87 "x10/lang/PlaceLocalHandle.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 87 "x10/lang/PlaceLocalHandle.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$134888)));
             }}
            }
        
        //#line 92 "x10/lang/PlaceLocalHandle.x10"
        return handle;
        }
    
    
    //#line 109 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  For each place in the
     * argument PlaceGroup, the local_init closure will be evaluated in the 
     * current place to yield a value of type U.  This value will then be serialized 
     * to the target place and passed as an argument to the init closure. 
     * When this method returns, the local objects will be initialized and available 
     * via the returned PlaceLocalHandle instance at every place in the distribution.
     *
     * @param dist a distribution specifiying the places where local objects should be created.
     * @param init_here a closure to compute the local portion of the initialization (evaluated in the current place)
     * @param init_there a closure to be evaluated in each place to create the local objects.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T, $U>x10.lang.PlaceLocalHandle make__1$1x10$lang$Place$3x10$lang$PlaceLocalHandle$$U$2__2$1x10$lang$PlaceLocalHandle$$U$3x10$lang$PlaceLocalHandle$$T$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_1<x10.lang.Place,$U> init_here, final x10.core.fun.Fun_0_1<$U,$T> init_there) {
        
        //#line 110 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        {
            
            //#line 111 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 111 "x10/lang/PlaceLocalHandle.x10"
            final x10.xrx.FinishState fs$134896 = x10.xrx.Runtime.startFinish();
            
            //#line 111 "x10/lang/PlaceLocalHandle.x10"
            try {{
                {
                    
                    //#line 111 "x10/lang/PlaceLocalHandle.x10"
                    final x10.lang.Iterator p$105124 = pg.iterator();
                    
                    //#line 111 "x10/lang/PlaceLocalHandle.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 111 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$134807 = ((x10.lang.Iterator<x10.lang.Place>)p$105124).hasNext$O();
                        
                        //#line 111 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$134807)) {
                            
                            //#line 111 "x10/lang/PlaceLocalHandle.x10"
                            break;
                        }
                        
                        //#line 111 "x10/lang/PlaceLocalHandle.x10"
                        final x10.lang.Place p$134854 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105124).next$G()));
                        
                        //#line 112 "x10/lang/PlaceLocalHandle.x10"
                        final $U v$134855 = (($U)((($U)
                                                    ((x10.core.fun.Fun_0_1<x10.lang.Place,$U>)init_here).$apply(p$134854, x10.lang.Place.$RTT))));
                        
                        //#line 113 "x10/lang/PlaceLocalHandle.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$134854)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$129<$T, $U>($T, $U, init_there, v$134855, handle, (x10.lang.PlaceLocalHandle.$Closure$129.__0$1x10$lang$PlaceLocalHandle$$Closure$129$$U$3x10$lang$PlaceLocalHandle$$Closure$129$$T$2__1x10$lang$PlaceLocalHandle$$Closure$129$$U__2$1x10$lang$PlaceLocalHandle$$Closure$129$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$134894) {
                
                //#line 111 "x10/lang/PlaceLocalHandle.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$134894)));
                
                //#line 111 "x10/lang/PlaceLocalHandle.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 111 "x10/lang/PlaceLocalHandle.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$134896)));
             }}
            }
        
        //#line 115 "x10/lang/PlaceLocalHandle.x10"
        return handle;
        }
    
    
    //#line 134 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  For each place in the
     * argument PlaceGroup, the local_init closure will be evaluated in the 
     * current place to yield a value of type U.  This value will then be serialized 
     * to the target place and passed as an argument to the init closure. 
     * When this method returns, the local objects will be initialized and available 
     * via the returned PlaceLocalHandle instance at every place in the distribution.
     *
     * @param dist a distribution specifiying the places where local objects should be created.
     * @param init_here a closure to compute the local portion of the initialization (evaluated in the current place)
     * @param init_there a closure to be evaluated in each place to create the local objects.
     * @param ignoreIfDead a filter to indicate if a place can be silently ignored if it is 
     *        already known to be dead at the time make first attempt to access it.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T, $U>x10.lang.PlaceLocalHandle make__1$1x10$lang$Place$3x10$lang$PlaceLocalHandle$$U$2__2$1x10$lang$PlaceLocalHandle$$U$3x10$lang$PlaceLocalHandle$$T$2__3$1x10$lang$Place$3x10$lang$Boolean$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_1<x10.lang.Place,$U> init_here, final x10.core.fun.Fun_0_1<$U,$T> init_there, final x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean> ignoreIfDead) {
        
        //#line 136 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        {
            
            //#line 137 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 137 "x10/lang/PlaceLocalHandle.x10"
            final x10.xrx.FinishState fs$134904 = x10.xrx.Runtime.startFinish();
            
            //#line 137 "x10/lang/PlaceLocalHandle.x10"
            try {{
                {
                    
                    //#line 137 "x10/lang/PlaceLocalHandle.x10"
                    final x10.lang.Iterator p$105126 = pg.iterator();
                    
                    //#line 137 "x10/lang/PlaceLocalHandle.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 137 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$134814 = ((x10.lang.Iterator<x10.lang.Place>)p$105126).hasNext$O();
                        
                        //#line 137 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$134814)) {
                            
                            //#line 137 "x10/lang/PlaceLocalHandle.x10"
                            break;
                        }
                        
                        //#line 137 "x10/lang/PlaceLocalHandle.x10"
                        final x10.lang.Place p$134857 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105126).next$G()));
                        
                        //#line 138 "x10/lang/PlaceLocalHandle.x10"
                        final $U v$134858 = (($U)((($U)
                                                    ((x10.core.fun.Fun_0_1<x10.lang.Place,$U>)init_here).$apply(p$134857, x10.lang.Place.$RTT))));
                        
                        //#line 139 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$134859 = p$134857.isDead$O();
                        
                        //#line 139 "x10/lang/PlaceLocalHandle.x10"
                        boolean t$134860 = !(t$134859);
                        
                        //#line 139 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$134860)) {
                            
                            //#line 139 "x10/lang/PlaceLocalHandle.x10"
                            final boolean t$134861 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean>)ignoreIfDead).$apply(p$134857, x10.lang.Place.$RTT));
                            
                            //#line 139 "x10/lang/PlaceLocalHandle.x10"
                            t$134860 = !(t$134861);
                        }
                        
                        //#line 139 "x10/lang/PlaceLocalHandle.x10"
                        if (t$134860) {
                            
                            //#line 140 "x10/lang/PlaceLocalHandle.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$134857)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$130<$T, $U>($T, $U, init_there, v$134858, handle, (x10.lang.PlaceLocalHandle.$Closure$130.__0$1x10$lang$PlaceLocalHandle$$Closure$130$$U$3x10$lang$PlaceLocalHandle$$Closure$130$$T$2__1x10$lang$PlaceLocalHandle$$Closure$130$$U__2$1x10$lang$PlaceLocalHandle$$Closure$130$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                        }
                    }
                }
            }}catch (java.lang.Throwable ct$134902) {
                
                //#line 137 "x10/lang/PlaceLocalHandle.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$134902)));
                
                //#line 137 "x10/lang/PlaceLocalHandle.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 137 "x10/lang/PlaceLocalHandle.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$134904)));
             }}
            }
        
        //#line 143 "x10/lang/PlaceLocalHandle.x10"
        return handle;
        }
    
    
    //#line 164 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  The local object will be initialized
     * by evaluating init at each place.  When this method returns, the local objects
     * will be initialized and available via the returned PlaceLocalHandle instance
     * at every place in the PlaceGroup.
     *
     * Requires an initialization closure which has no exposed at/async constructs
     * (any async/at must be nested inside of a finish).
     *
     * @param pg a PlaceGroup specifiying the places where local objects should be created.
     * @param init the initialization closure used to create the local object.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T>x10.lang.PlaceLocalHandle makeFlat__1$1x10$lang$PlaceLocalHandle$$T$2(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<$T> init) {
        
        //#line 165 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        
        //#line 166 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.fun.VoidFun_0_0 t$134816 = ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$131<$T>($T, init, handle, (x10.lang.PlaceLocalHandle.$Closure$131.__0$1x10$lang$PlaceLocalHandle$$Closure$131$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$131$$T$2) null)));
        
        //#line 166 "x10/lang/PlaceLocalHandle.x10"
        pg.broadcastFlat(((x10.core.fun.VoidFun_0_0)(t$134816)));
        
        //#line 167 "x10/lang/PlaceLocalHandle.x10"
        return handle;
    }
    
    
    //#line 186 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  The local object will be initialized
     * by evaluating init at each place.  When this method returns, the local objects
     * will be initialized and available via the returned PlaceLocalHandle instance
     * at every place in the PlaceGroup.
     *
     * Requires an initialization closure which has no exposed at/async constructs
     * (any async/at must be nested inside of a finish).
     *
     * @param pg a PlaceGroup specifiying the places where local objects should be created.
     * @param init the initialization closure used to create the local object.
     * @param ignoreIfDead a filter to indicate if a place can be silently ignored if it is 
     *        already known to be dead at the time make first attempt to access it.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T>x10.lang.PlaceLocalHandle makeFlat__1$1x10$lang$PlaceLocalHandle$$T$2__2$1x10$lang$Place$3x10$lang$Boolean$2(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<$T> init, final x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean> ignoreIfDead) {
        
        //#line 188 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        
        //#line 189 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.fun.VoidFun_0_0 t$134818 = ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$132<$T>($T, init, handle, (x10.lang.PlaceLocalHandle.$Closure$132.__0$1x10$lang$PlaceLocalHandle$$Closure$132$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$132$$T$2) null)));
        
        //#line 189 "x10/lang/PlaceLocalHandle.x10"
        pg.broadcastFlat__1$1x10$lang$Place$3x10$lang$Boolean$2(((x10.core.fun.VoidFun_0_0)(t$134818)), ((x10.core.fun.Fun_0_1)(ignoreIfDead)));
        
        //#line 190 "x10/lang/PlaceLocalHandle.x10"
        return handle;
    }
    
    
    //#line 210 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  For each place in the
     * argument PlaceGroup, the local_init closure will be evaluated in the 
     * current place to yield a value of type U.  This value will then be serialized 
     * to the target place and passed as an argument to the init closure. 
     * When this method returns, the local objects will be initialized and available 
     * via the returned PlaceLocalHandle instance at every place in the distribution.
     *
     * Requires an init_there initialization closure which has no exposed at/async constructs
     * (any async/at must be nested inside of a finish).
     *
     * @param dist a distribution specifiying the places where local objects should be created.
     * @param init_here a closure to compute the local portion of the initialization (evaluated in the current place)
     * @param init_there a closure to be evaluated in each place to create the local objects.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T, $U>x10.lang.PlaceLocalHandle makeFlat__1$1x10$lang$Place$3x10$lang$PlaceLocalHandle$$U$2__2$1x10$lang$PlaceLocalHandle$$U$3x10$lang$PlaceLocalHandle$$T$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_1<x10.lang.Place,$U> init_here, final x10.core.fun.Fun_0_1<$U,$T> init_there) {
        
        //#line 211 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        {
            
            //#line 212 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 212 "x10/lang/PlaceLocalHandle.x10"
            final x10.xrx.FinishState fs$134913 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_SPMD));
            
            //#line 212 "x10/lang/PlaceLocalHandle.x10"
            try {{
                {
                    
                    //#line 212 "x10/lang/PlaceLocalHandle.x10"
                    final x10.lang.Iterator p$105128 = pg.iterator();
                    
                    //#line 212 "x10/lang/PlaceLocalHandle.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 212 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$134821 = ((x10.lang.Iterator<x10.lang.Place>)p$105128).hasNext$O();
                        
                        //#line 212 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$134821)) {
                            
                            //#line 212 "x10/lang/PlaceLocalHandle.x10"
                            break;
                        }
                        
                        //#line 212 "x10/lang/PlaceLocalHandle.x10"
                        final x10.lang.Place p$134864 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105128).next$G()));
                        
                        //#line 213 "x10/lang/PlaceLocalHandle.x10"
                        final $U v$134865 = (($U)((($U)
                                                    ((x10.core.fun.Fun_0_1<x10.lang.Place,$U>)init_here).$apply(p$134864, x10.lang.Place.$RTT))));
                        
                        //#line 214 "x10/lang/PlaceLocalHandle.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$134864)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$133<$T, $U>($T, $U, init_there, v$134865, handle, (x10.lang.PlaceLocalHandle.$Closure$133.__0$1x10$lang$PlaceLocalHandle$$Closure$133$$U$3x10$lang$PlaceLocalHandle$$Closure$133$$T$2__1x10$lang$PlaceLocalHandle$$Closure$133$$U__2$1x10$lang$PlaceLocalHandle$$Closure$133$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$134910) {
                
                //#line 212 "x10/lang/PlaceLocalHandle.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$134910)));
                
                //#line 212 "x10/lang/PlaceLocalHandle.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 212 "x10/lang/PlaceLocalHandle.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$134913)));
             }}
            }
        
        //#line 216 "x10/lang/PlaceLocalHandle.x10"
        return handle;
        }
    
    
    //#line 238 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  For each place in the
     * argument PlaceGroup, the local_init closure will be evaluated in the 
     * current place to yield a value of type U.  This value will then be serialized 
     * to the target place and passed as an argument to the init closure. 
     * When this method returns, the local objects will be initialized and available 
     * via the returned PlaceLocalHandle instance at every place in the distribution.
     *
     * Requires an init_there initialization closure which has no exposed at/async constructs
     * (any async/at must be nested inside of a finish).
     *
     * @param dist a distribution specifiying the places where local objects should be created.
     * @param init_here a closure to compute the local portion of the initialization (evaluated in the current place)
     * @param init_there a closure to be evaluated in each place to create the local objects.
     * @param ignoreIfDead a filter to indicate if a place can be silently ignored if it is 
     *        already known to be dead at the time make first attempt to access it.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T, $U>x10.lang.PlaceLocalHandle makeFlat__1$1x10$lang$Place$3x10$lang$PlaceLocalHandle$$U$2__2$1x10$lang$PlaceLocalHandle$$U$3x10$lang$PlaceLocalHandle$$T$2__3$1x10$lang$Place$3x10$lang$Boolean$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_1<x10.lang.Place,$U> init_here, final x10.core.fun.Fun_0_1<$U,$T> init_there, final x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean> ignoreIfDead) {
        
        //#line 240 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        {
            
            //#line 241 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 241 "x10/lang/PlaceLocalHandle.x10"
            final x10.xrx.FinishState fs$134922 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_SPMD));
            
            //#line 241 "x10/lang/PlaceLocalHandle.x10"
            try {{
                {
                    
                    //#line 241 "x10/lang/PlaceLocalHandle.x10"
                    final x10.lang.Iterator p$105130 = pg.iterator();
                    
                    //#line 241 "x10/lang/PlaceLocalHandle.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 241 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$134828 = ((x10.lang.Iterator<x10.lang.Place>)p$105130).hasNext$O();
                        
                        //#line 241 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$134828)) {
                            
                            //#line 241 "x10/lang/PlaceLocalHandle.x10"
                            break;
                        }
                        
                        //#line 241 "x10/lang/PlaceLocalHandle.x10"
                        final x10.lang.Place p$134867 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105130).next$G()));
                        
                        //#line 242 "x10/lang/PlaceLocalHandle.x10"
                        final $U v$134868 = (($U)((($U)
                                                    ((x10.core.fun.Fun_0_1<x10.lang.Place,$U>)init_here).$apply(p$134867, x10.lang.Place.$RTT))));
                        
                        //#line 243 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$134869 = p$134867.isDead$O();
                        
                        //#line 243 "x10/lang/PlaceLocalHandle.x10"
                        boolean t$134870 = !(t$134869);
                        
                        //#line 243 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$134870)) {
                            
                            //#line 243 "x10/lang/PlaceLocalHandle.x10"
                            final boolean t$134871 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean>)ignoreIfDead).$apply(p$134867, x10.lang.Place.$RTT));
                            
                            //#line 243 "x10/lang/PlaceLocalHandle.x10"
                            t$134870 = !(t$134871);
                        }
                        
                        //#line 243 "x10/lang/PlaceLocalHandle.x10"
                        if (t$134870) {
                            
                            //#line 244 "x10/lang/PlaceLocalHandle.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$134867)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$134<$T, $U>($T, $U, init_there, v$134868, handle, (x10.lang.PlaceLocalHandle.$Closure$134.__0$1x10$lang$PlaceLocalHandle$$Closure$134$$U$3x10$lang$PlaceLocalHandle$$Closure$134$$T$2__1x10$lang$PlaceLocalHandle$$Closure$134$$U__2$1x10$lang$PlaceLocalHandle$$Closure$134$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                        }
                    }
                }
            }}catch (java.lang.Throwable ct$134919) {
                
                //#line 241 "x10/lang/PlaceLocalHandle.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$134919)));
                
                //#line 241 "x10/lang/PlaceLocalHandle.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 241 "x10/lang/PlaceLocalHandle.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$134922)));
             }}
            }
        
        //#line 247 "x10/lang/PlaceLocalHandle.x10"
        return handle;
        }
    
    
    //#line 259 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Augment the PlaceGroup at which the argument PlaceLocalHandle has
     * a value with the given place by evaluating the argument initialization 
     * closure at that Place to and storing its result in the PlaceLocalHandle.
     *
     * @param plh a place local handle to extend with a new Place
     * @param place the Place at which to extend it
     * @param init a closure to be evaluated at place to create the value to be stored
     */
    final public static <$T>void addPlace__0$1x10$lang$PlaceLocalHandle$$T$2__2$1x10$lang$PlaceLocalHandle$$T$2(final x10.rtt.Type $T, final x10.lang.PlaceLocalHandle<$T> plh, final x10.lang.Place place, final x10.core.fun.Fun_0_0<$T> init) {
        {
            
            //#line 261 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(place)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$135<$T>($T, init, plh, (x10.lang.PlaceLocalHandle.$Closure$135.__0$1x10$lang$PlaceLocalHandle$$Closure$135$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$135$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 269 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Release the local state of the argument PlaceLocalHandle at
     * every place in the argument PlaceGroup (by storing null
     * as the value for the PlaceLocalHandle at that Place).
     */
    final public static <$T>void destroy__1$1x10$lang$PlaceLocalHandle$$T$2(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.lang.PlaceLocalHandle<$T> plh) {
        
        //#line 270 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.fun.VoidFun_0_0 t$134830 = ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$136<$T>($T, plh, (x10.lang.PlaceLocalHandle.$Closure$136.__0$1x10$lang$PlaceLocalHandle$$Closure$136$$T$2) null)));
        
        //#line 270 "x10/lang/PlaceLocalHandle.x10"
        pg.broadcastFlat(((x10.core.fun.VoidFun_0_0)(t$134830)));
    }
    
    
    //#line 278 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Release the local state of the argument PlaceLocalHandle at
     * every place in the argument PlaceGroup (by storing null
     * as the value for the PlaceLocalHandle at that Place).
     */
    final public static <$T>void destroy__1$1x10$lang$PlaceLocalHandle$$T$2__2$1x10$lang$Place$3x10$lang$Boolean$2(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.lang.PlaceLocalHandle<$T> plh, final x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean> ignoreIfDead) {
        
        //#line 280 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.fun.VoidFun_0_0 t$134831 = ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$137<$T>($T, plh, (x10.lang.PlaceLocalHandle.$Closure$137.__0$1x10$lang$PlaceLocalHandle$$Closure$137$$T$2) null)));
        
        //#line 280 "x10/lang/PlaceLocalHandle.x10"
        pg.broadcastFlat__1$1x10$lang$Place$3x10$lang$Boolean$2(((x10.core.fun.VoidFun_0_0)(t$134831)), ((x10.core.fun.Fun_0_1)(ignoreIfDead)));
    }
    
    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$205645) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205645);
        }
        
    }
    
    
    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    final public boolean equals(java.lang.Object other) {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final boolean t$134835 = x10.lang.PlaceLocalHandle.$RTT.isInstance(other, $T);
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final boolean t$134836 = !(t$134835);
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        if (t$134836) {
            
            //#line 35 "x10/lang/PlaceLocalHandle.x10"
            return false;
        }
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle t$134838 = ((x10.lang.PlaceLocalHandle)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, $T),other));
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final boolean t$134839 = this.equals__0$1x10$lang$PlaceLocalHandle$$T$2$O(((x10.lang.PlaceLocalHandle)(t$134838)));
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return t$134839;
    }
    
    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    final public boolean equals__0$1x10$lang$PlaceLocalHandle$$T$2$O(x10.lang.PlaceLocalHandle other) {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return true;
    }
    
    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final boolean t$134841 = x10.lang.PlaceLocalHandle.$RTT.isInstance(other, $T);
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final boolean t$134842 = !(t$134841);
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        if (t$134842) {
            
            //#line 35 "x10/lang/PlaceLocalHandle.x10"
            return false;
        }
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle t$134844 = ((x10.lang.PlaceLocalHandle)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, $T),other));
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final boolean t$134845 = this._struct_equals__0$1x10$lang$PlaceLocalHandle$$T$2$O(((x10.lang.PlaceLocalHandle)(t$134844)));
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return t$134845;
    }
    
    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    final public boolean _struct_equals__0$1x10$lang$PlaceLocalHandle$$T$2$O(x10.lang.PlaceLocalHandle other) {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return true;
    }
    
    
    //#line 33 "x10/lang/PlaceLocalHandle.x10"
    final public x10.lang.PlaceLocalHandle x10$lang$PlaceLocalHandle$$this$x10$lang$PlaceLocalHandle() {
        
        //#line 33 "x10/lang/PlaceLocalHandle.x10"
        return x10.lang.PlaceLocalHandle.this;
    }
    
    
    //#line 33 "x10/lang/PlaceLocalHandle.x10"
    final public void __fieldInitializers_x10_lang_PlaceLocalHandle() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$127<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$127> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$127> make($Closure$127.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$127<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$127 $_obj = new x10.lang.PlaceLocalHandle.$Closure$127((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.handle);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$127(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$127.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$127 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$127$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$127$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 66 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 66 "x10/lang/PlaceLocalHandle.x10"
                final $T t$134847 = (($T)(((x10.core.fun.Fun_0_0<$T>)this.init).$apply$G()));
                
                //#line 66 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$134847)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 66 "x10/lang/PlaceLocalHandle.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 66 "x10/lang/PlaceLocalHandle.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.Fun_0_0<$T> init;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$127(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$127$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$127$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$127.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$127<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.lang.PlaceLocalHandle.$Closure$127<$T>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$128<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$128> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$128> make($Closure$128.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$128<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$128 $_obj = new x10.lang.PlaceLocalHandle.$Closure$128((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.handle);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$128(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$128.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$128 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$128$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$128$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 89 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 89 "x10/lang/PlaceLocalHandle.x10"
                final $T t$134853 = (($T)(((x10.core.fun.Fun_0_0<$T>)this.init).$apply$G()));
                
                //#line 89 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$134853)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 89 "x10/lang/PlaceLocalHandle.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 89 "x10/lang/PlaceLocalHandle.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.Fun_0_0<$T> init;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$128(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$128$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$128$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$128.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$128<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.lang.PlaceLocalHandle.$Closure$128<$T>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$129<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$129> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$129> make($Closure$129.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$129<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init_there = $deserializer.readObject();
            $_obj.v$134855 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$129 $_obj = new x10.lang.PlaceLocalHandle.$Closure$129((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.handle);
            $serializer.write(this.init_there);
            $serializer.write(this.v$134855);
            
        }
        
        // constructor just for allocation
        public $Closure$129(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.lang.PlaceLocalHandle.$Closure$129.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$129 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$129$$U$3x10$lang$PlaceLocalHandle$$Closure$129$$T$2__1x10$lang$PlaceLocalHandle$$Closure$129$$U__2$1x10$lang$PlaceLocalHandle$$Closure$129$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 113 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 113 "x10/lang/PlaceLocalHandle.x10"
                final $T t$134856 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<$U,$T>)this.init_there).$apply(this.v$134855, $U))));
                
                //#line 113 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$134856)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 113 "x10/lang/PlaceLocalHandle.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 113 "x10/lang/PlaceLocalHandle.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.Fun_0_1<$U,$T> init_there;
        public $U v$134855;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$129(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_1<$U,$T> init_there, final $U v$134855, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$129$$U$3x10$lang$PlaceLocalHandle$$Closure$129$$T$2__1x10$lang$PlaceLocalHandle$$Closure$129$$U__2$1x10$lang$PlaceLocalHandle$$Closure$129$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$129.$initParams(this, $T, $U);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$129<$T, $U>)this).init_there = ((x10.core.fun.Fun_0_1)(init_there));
                ((x10.lang.PlaceLocalHandle.$Closure$129<$T, $U>)this).v$134855 = (($U)(v$134855));
                ((x10.lang.PlaceLocalHandle.$Closure$129<$T, $U>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$130<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$130> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$130> make($Closure$130.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$130<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init_there = $deserializer.readObject();
            $_obj.v$134858 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$130 $_obj = new x10.lang.PlaceLocalHandle.$Closure$130((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.handle);
            $serializer.write(this.init_there);
            $serializer.write(this.v$134858);
            
        }
        
        // constructor just for allocation
        public $Closure$130(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.lang.PlaceLocalHandle.$Closure$130.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$130 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$130$$U$3x10$lang$PlaceLocalHandle$$Closure$130$$T$2__1x10$lang$PlaceLocalHandle$$Closure$130$$U__2$1x10$lang$PlaceLocalHandle$$Closure$130$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 140 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 140 "x10/lang/PlaceLocalHandle.x10"
                final $T t$134863 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<$U,$T>)this.init_there).$apply(this.v$134858, $U))));
                
                //#line 140 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$134863)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 140 "x10/lang/PlaceLocalHandle.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 140 "x10/lang/PlaceLocalHandle.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.Fun_0_1<$U,$T> init_there;
        public $U v$134858;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$130(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_1<$U,$T> init_there, final $U v$134858, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$130$$U$3x10$lang$PlaceLocalHandle$$Closure$130$$T$2__1x10$lang$PlaceLocalHandle$$Closure$130$$U__2$1x10$lang$PlaceLocalHandle$$Closure$130$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$130.$initParams(this, $T, $U);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$130<$T, $U>)this).init_there = ((x10.core.fun.Fun_0_1)(init_there));
                ((x10.lang.PlaceLocalHandle.$Closure$130<$T, $U>)this).v$134858 = (($U)(v$134858));
                ((x10.lang.PlaceLocalHandle.$Closure$130<$T, $U>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$131<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$131> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$131> make($Closure$131.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$131<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$131 $_obj = new x10.lang.PlaceLocalHandle.$Closure$131((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.handle);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$131(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$131.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$131 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$131$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$131$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 166 "x10/lang/PlaceLocalHandle.x10"
            final $T t$134815 = (($T)(((x10.core.fun.Fun_0_0<$T>)this.init).$apply$G()));
            
            //#line 166 "x10/lang/PlaceLocalHandle.x10"
            ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$134815)));
        }
        
        public x10.core.fun.Fun_0_0<$T> init;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$131(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$131$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$131$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$131.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$131<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.lang.PlaceLocalHandle.$Closure$131<$T>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$132<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$132> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$132> make($Closure$132.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$132<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$132 $_obj = new x10.lang.PlaceLocalHandle.$Closure$132((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.handle);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$132(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$132.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$132 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$132$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$132$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 189 "x10/lang/PlaceLocalHandle.x10"
            final $T t$134817 = (($T)(((x10.core.fun.Fun_0_0<$T>)this.init).$apply$G()));
            
            //#line 189 "x10/lang/PlaceLocalHandle.x10"
            ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$134817)));
        }
        
        public x10.core.fun.Fun_0_0<$T> init;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$132(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$132$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$132$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$132.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$132<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.lang.PlaceLocalHandle.$Closure$132<$T>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$133<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$133> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$133> make($Closure$133.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$133<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init_there = $deserializer.readObject();
            $_obj.v$134865 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$133 $_obj = new x10.lang.PlaceLocalHandle.$Closure$133((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.handle);
            $serializer.write(this.init_there);
            $serializer.write(this.v$134865);
            
        }
        
        // constructor just for allocation
        public $Closure$133(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.lang.PlaceLocalHandle.$Closure$133.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$133 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$133$$U$3x10$lang$PlaceLocalHandle$$Closure$133$$T$2__1x10$lang$PlaceLocalHandle$$Closure$133$$U__2$1x10$lang$PlaceLocalHandle$$Closure$133$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 214 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 214 "x10/lang/PlaceLocalHandle.x10"
                final $T t$134866 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<$U,$T>)this.init_there).$apply(this.v$134865, $U))));
                
                //#line 214 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$134866)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 214 "x10/lang/PlaceLocalHandle.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 214 "x10/lang/PlaceLocalHandle.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.Fun_0_1<$U,$T> init_there;
        public $U v$134865;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$133(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_1<$U,$T> init_there, final $U v$134865, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$133$$U$3x10$lang$PlaceLocalHandle$$Closure$133$$T$2__1x10$lang$PlaceLocalHandle$$Closure$133$$U__2$1x10$lang$PlaceLocalHandle$$Closure$133$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$133.$initParams(this, $T, $U);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$133<$T, $U>)this).init_there = ((x10.core.fun.Fun_0_1)(init_there));
                ((x10.lang.PlaceLocalHandle.$Closure$133<$T, $U>)this).v$134865 = (($U)(v$134865));
                ((x10.lang.PlaceLocalHandle.$Closure$133<$T, $U>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$134<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$134> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$134> make($Closure$134.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$134<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init_there = $deserializer.readObject();
            $_obj.v$134868 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$134 $_obj = new x10.lang.PlaceLocalHandle.$Closure$134((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.handle);
            $serializer.write(this.init_there);
            $serializer.write(this.v$134868);
            
        }
        
        // constructor just for allocation
        public $Closure$134(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.lang.PlaceLocalHandle.$Closure$134.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$134 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$134$$U$3x10$lang$PlaceLocalHandle$$Closure$134$$T$2__1x10$lang$PlaceLocalHandle$$Closure$134$$U__2$1x10$lang$PlaceLocalHandle$$Closure$134$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 244 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 244 "x10/lang/PlaceLocalHandle.x10"
                final $T t$134873 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<$U,$T>)this.init_there).$apply(this.v$134868, $U))));
                
                //#line 244 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$134873)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 244 "x10/lang/PlaceLocalHandle.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 244 "x10/lang/PlaceLocalHandle.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.Fun_0_1<$U,$T> init_there;
        public $U v$134868;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$134(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_1<$U,$T> init_there, final $U v$134868, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$134$$U$3x10$lang$PlaceLocalHandle$$Closure$134$$T$2__1x10$lang$PlaceLocalHandle$$Closure$134$$U__2$1x10$lang$PlaceLocalHandle$$Closure$134$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$134.$initParams(this, $T, $U);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$134<$T, $U>)this).init_there = ((x10.core.fun.Fun_0_1)(init_there));
                ((x10.lang.PlaceLocalHandle.$Closure$134<$T, $U>)this).v$134868 = (($U)(v$134868));
                ((x10.lang.PlaceLocalHandle.$Closure$134<$T, $U>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$135<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$135> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$135> make($Closure$135.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$135<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.plh = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$135 $_obj = new x10.lang.PlaceLocalHandle.$Closure$135((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.plh);
            
        }
        
        // constructor just for allocation
        public $Closure$135(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$135.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$135 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$135$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$135$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 261 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 261 "x10/lang/PlaceLocalHandle.x10"
                final $T t$134829 = (($T)(((x10.core.fun.Fun_0_0<$T>)this.init).$apply$G()));
                
                //#line 261 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.plh).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$134829)));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 261 "x10/lang/PlaceLocalHandle.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.core.fun.Fun_0_0<$T> init;
        public x10.lang.PlaceLocalHandle<$T> plh;
        
        public $Closure$135(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, final x10.lang.PlaceLocalHandle<$T> plh, __0$1x10$lang$PlaceLocalHandle$$Closure$135$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$135$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$135.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$135<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.lang.PlaceLocalHandle.$Closure$135<$T>)this).plh = ((x10.lang.PlaceLocalHandle)(plh));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$136<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$136> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$136> make($Closure$136.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$136<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.plh = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$136 $_obj = new x10.lang.PlaceLocalHandle.$Closure$136((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.plh);
            
        }
        
        // constructor just for allocation
        public $Closure$136(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$136.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$136 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$136$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 270 "x10/lang/PlaceLocalHandle.x10"
            ((x10.lang.PlaceLocalHandle<$T>)this.plh).set__0x10$lang$PlaceLocalHandle$$T((($T)(null)));
        }
        
        public x10.lang.PlaceLocalHandle<$T> plh;
        
        public $Closure$136(final x10.rtt.Type $T, final x10.lang.PlaceLocalHandle<$T> plh, __0$1x10$lang$PlaceLocalHandle$$Closure$136$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$136.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$136<$T>)this).plh = ((x10.lang.PlaceLocalHandle)(plh));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$137<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$137> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$137> make($Closure$137.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$137<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.plh = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$137 $_obj = new x10.lang.PlaceLocalHandle.$Closure$137((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.plh);
            
        }
        
        // constructor just for allocation
        public $Closure$137(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$137.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$137 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$137$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 280 "x10/lang/PlaceLocalHandle.x10"
            ((x10.lang.PlaceLocalHandle<$T>)this.plh).set__0x10$lang$PlaceLocalHandle$$T((($T)(null)));
        }
        
        public x10.lang.PlaceLocalHandle<$T> plh;
        
        public $Closure$137(final x10.rtt.Type $T, final x10.lang.PlaceLocalHandle<$T> plh, __0$1x10$lang$PlaceLocalHandle$$Closure$137$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$137.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$137<$T>)this).plh = ((x10.lang.PlaceLocalHandle)(plh));
            }
        }
        
    }
    
    }
    
    