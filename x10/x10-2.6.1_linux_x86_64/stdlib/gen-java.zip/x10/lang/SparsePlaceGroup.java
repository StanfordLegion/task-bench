package x10.lang;


/**
 * <p>An implementation of PlaceGroup that simply uses a Rail[Place] to
 * represent the Places in the group.  This implementation is only suitable
 * when the PlaceGroup contains a fairly small number of places.
 * This can happen either becase the group is very sparse, or because the total 
 * number of places being used by the program is small.  In either case, 
 * this PlaceGroup should have acceptable performance.</p>
 *
 * <p>Although the basic operations (contains, indexOf) could be asymptotically
 * improved from O(N) to O(log(N)) by using binary search over a sorted Rail,
 * the expected performance of this class would still be poor due to
 * the space overhead of explictly representing all of the Places in the group,
 * which in turn would yield O(size()) serialization costs.  Therefore, we have
 * decided to go with the lower constants and ignore the asymptotic analysis.</p>
 */
@x10.runtime.impl.java.X10Generated
final public class SparsePlaceGroup extends x10.lang.PlaceGroup implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<SparsePlaceGroup> $RTT = 
        x10.rtt.NamedType.<SparsePlaceGroup> make("x10.lang.SparsePlaceGroup",
                                                  SparsePlaceGroup.class,
                                                  new x10.rtt.Type[] {
                                                      x10.lang.PlaceGroup.$RTT
                                                  });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.SparsePlaceGroup $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.PlaceGroup.$_deserialize_body($_obj, $deserializer);
        $_obj.places = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.SparsePlaceGroup $_obj = new x10.lang.SparsePlaceGroup((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.places);
        
    }
    
    // constructor just for allocation
    public SparsePlaceGroup(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$Place$2 {}
    

    
    //#line 37 "x10/lang/SparsePlaceGroup.x10"
    /**
   * The set of places.
   * Only places that are in the group are in the array.
   */
    public x10.core.Rail<x10.lang.Place> places;
    
    
    //#line 46 "x10/lang/SparsePlaceGroup.x10"
    /**
   * Construct a SparsePlaceGroup from a Rail[Place].
   * Places may appear in any order, but must represent a 
   * set of Places (no duplicate entries).
   * If the argument rail is not a set an IllegalArgumentException 
   * will be thrown (unless the X10 standaed library was compiled with NO_CHECKS).
   */
    // creation method for java code (1-phase java constructor)
    public SparsePlaceGroup(final x10.core.Rail<x10.lang.Place> ps, __0$1x10$lang$Place$2 $dummy) {
        this((java.lang.System[]) null);
        x10$lang$SparsePlaceGroup$$init$S(ps, (x10.lang.SparsePlaceGroup.__0$1x10$lang$Place$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.SparsePlaceGroup x10$lang$SparsePlaceGroup$$init$S(final x10.core.Rail<x10.lang.Place> ps, __0$1x10$lang$Place$2 $dummy) {
         {
            
            //#line 46 "x10/lang/SparsePlaceGroup.x10"
            
            
            //#line 47 "x10/lang/SparsePlaceGroup.x10"
            final x10.core.Rail t$135738 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.Place>(x10.lang.Place.$RTT, ((x10.core.Rail)(ps)), (x10.core.Rail.__0$1x10$lang$Rail$$T$2) null)));
            
            //#line 47 "x10/lang/SparsePlaceGroup.x10"
            this.places = ((x10.core.Rail)(t$135738));
            
            //#line 49 "x10/lang/SparsePlaceGroup.x10"
            boolean sorted$135821 = true;
            
            //#line 51 "x10/lang/SparsePlaceGroup.x10"
            final x10.core.Rail t$135817 = ((x10.core.Rail)(this.places));
            
            //#line 51 "x10/lang/SparsePlaceGroup.x10"
            final long t$135818 = ((x10.core.Rail<x10.lang.Place>)t$135817).size;
            
            //#line 51 "x10/lang/SparsePlaceGroup.x10"
            final long i$134383max$135819 = ((t$135818) - (((long)(1L))));
            
            //#line 51 "x10/lang/SparsePlaceGroup.x10"
            long i$135803 = 1L;
            
            //#line 51 "x10/lang/SparsePlaceGroup.x10"
            for (;
                 true;
                 ) {
                
                //#line 51 "x10/lang/SparsePlaceGroup.x10"
                final boolean t$135805 = ((i$135803) <= (((long)(i$134383max$135819))));
                
                //#line 51 "x10/lang/SparsePlaceGroup.x10"
                if (!(t$135805)) {
                    
                    //#line 51 "x10/lang/SparsePlaceGroup.x10"
                    break;
                }
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final x10.core.Rail t$135792 = ((x10.core.Rail)(this.places));
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final x10.lang.Place t$135793 = ((x10.lang.Place[])t$135792.value)[(int)i$135803];
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final long t$135794 = t$135793.id;
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final x10.core.Rail t$135795 = ((x10.core.Rail)(this.places));
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final long t$135796 = ((i$135803) - (((long)(1L))));
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final x10.lang.Place t$135797 = ((x10.lang.Place[])t$135795.value)[(int)t$135796];
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final long t$135798 = t$135797.id;
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final boolean t$135799 = ((t$135794) <= (((long)(t$135798))));
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                if (t$135799) {
                    
                    //#line 53 "x10/lang/SparsePlaceGroup.x10"
                    sorted$135821 = false;
                    
                    //#line 54 "x10/lang/SparsePlaceGroup.x10"
                    break;
                }
                
                //#line 51 "x10/lang/SparsePlaceGroup.x10"
                final long t$135802 = ((i$135803) + (((long)(1L))));
                
                //#line 51 "x10/lang/SparsePlaceGroup.x10"
                i$135803 = t$135802;
            }
            
            //#line 57 "x10/lang/SparsePlaceGroup.x10"
            final boolean t$135823 = !(sorted$135821);
            
            //#line 57 "x10/lang/SparsePlaceGroup.x10"
            if (t$135823) {
                
                //#line 58 "x10/lang/SparsePlaceGroup.x10"
                final x10.util.HashSet seen$135824 = new x10.util.HashSet<x10.lang.Place>((java.lang.System[]) null, x10.lang.Place.$RTT);
                
                //#line 58 "x10/lang/SparsePlaceGroup.x10"
                seen$135824.x10$util$HashSet$$init$S();
                
                //#line 59 "x10/lang/SparsePlaceGroup.x10"
                final x10.core.Rail rail$135815 = ((x10.core.Rail)(this.places));
                
                //#line 59 "x10/lang/SparsePlaceGroup.x10"
                final long size$135816 = ((x10.core.Rail<x10.lang.Place>)rail$135815).size;
                
                //#line 59 "x10/lang/SparsePlaceGroup.x10"
                long idx$135812 = 0L;
                {
                    
                    //#line 59 "x10/lang/SparsePlaceGroup.x10"
                    final x10.lang.Place[] rail$135815$value$135850 = ((x10.lang.Place[])rail$135815.value);
                    
                    //#line 59 "x10/lang/SparsePlaceGroup.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 59 "x10/lang/SparsePlaceGroup.x10"
                        final boolean t$135814 = ((idx$135812) < (((long)(size$135816))));
                        
                        //#line 59 "x10/lang/SparsePlaceGroup.x10"
                        if (!(t$135814)) {
                            
                            //#line 59 "x10/lang/SparsePlaceGroup.x10"
                            break;
                        }
                        
                        //#line 59 "x10/lang/SparsePlaceGroup.x10"
                        final x10.lang.Place p$135809 = ((x10.lang.Place)(((x10.lang.Place)rail$135815$value$135850[(int)idx$135812])));
                        
                        //#line 60 "x10/lang/SparsePlaceGroup.x10"
                        final boolean t$135806 = ((x10.util.MapSet<x10.lang.Place>)seen$135824).contains__0x10$util$MapSet$$T$O(((x10.lang.Place)(p$135809)));
                        
                        //#line 60 "x10/lang/SparsePlaceGroup.x10"
                        if (t$135806) {
                            
                            //#line 61 "x10/lang/SparsePlaceGroup.x10"
                            final java.lang.IllegalArgumentException t$135807 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("Argument rail was not sorted")));
                            
                            //#line 61 "x10/lang/SparsePlaceGroup.x10"
                            throw t$135807;
                        }
                        
                        //#line 63 "x10/lang/SparsePlaceGroup.x10"
                        ((x10.util.MapSet<x10.lang.Place>)seen$135824).add__0x10$util$MapSet$$T$O(((x10.lang.Place)(p$135809)));
                        
                        //#line 59 "x10/lang/SparsePlaceGroup.x10"
                        final long t$135811 = ((idx$135812) + (((long)(1L))));
                        
                        //#line 59 "x10/lang/SparsePlaceGroup.x10"
                        idx$135812 = t$135811;
                    }
                }
            }
        }
        return this;
    }
    
    
    
    //#line 72 "x10/lang/SparsePlaceGroup.x10"
    /**
   * Construct a SparsePlaceGroup from another PlaceGroup.
   */
    // creation method for java code (1-phase java constructor)
    public SparsePlaceGroup(final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null);
        x10$lang$SparsePlaceGroup$$init$S(pg);
    }
    
    // constructor for non-virtual call
    final public x10.lang.SparsePlaceGroup x10$lang$SparsePlaceGroup$$init$S(final x10.lang.PlaceGroup pg) {
         {
            
            //#line 72 "x10/lang/SparsePlaceGroup.x10"
            
            
            //#line 35 . "x10/lang/PlaceGroup.x10"
            final long t$135765 = pg.numPlaces$O();
            
            //#line 73 "x10/lang/SparsePlaceGroup.x10"
            final x10.core.fun.Fun_0_1 t$135766 = ((x10.core.fun.Fun_0_1)(new x10.lang.SparsePlaceGroup.$Closure$155(pg)));
            
            //#line 73 "x10/lang/SparsePlaceGroup.x10"
            final x10.core.Rail t$135767 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.Place>(x10.lang.Place.$RTT, t$135765, ((x10.core.fun.Fun_0_1)(t$135766)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 73 "x10/lang/SparsePlaceGroup.x10"
            this.places = ((x10.core.Rail)(t$135767));
        }
        return this;
    }
    
    
    
    //#line 80 "x10/lang/SparsePlaceGroup.x10"
    /**
   * Construct a SparsePlaceGroup that contains a single place, p.
   * @param p the place 
   */
    // creation method for java code (1-phase java constructor)
    public SparsePlaceGroup(final x10.lang.Place p) {
        this((java.lang.System[]) null);
        x10$lang$SparsePlaceGroup$$init$S(p);
    }
    
    // constructor for non-virtual call
    final public x10.lang.SparsePlaceGroup x10$lang$SparsePlaceGroup$$init$S(final x10.lang.Place p) {
         {
            
            //#line 80 "x10/lang/SparsePlaceGroup.x10"
            
            
            //#line 81 "x10/lang/SparsePlaceGroup.x10"
            final x10.core.Rail t$135768 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.Place>(x10.lang.Place.$RTT, ((long)(1L)), ((x10.lang.Place)(p)), (x10.core.Rail.__1x10$lang$Rail$$T) null)));
            
            //#line 81 "x10/lang/SparsePlaceGroup.x10"
            this.places = ((x10.core.Rail)(t$135768));
        }
        return this;
    }
    
    
    
    //#line 84 "x10/lang/SparsePlaceGroup.x10"
    public x10.lang.Place $apply(final long i) {
        
        //#line 84 "x10/lang/SparsePlaceGroup.x10"
        final x10.core.Rail t$135769 = ((x10.core.Rail)(this.places));
        
        //#line 84 "x10/lang/SparsePlaceGroup.x10"
        final x10.lang.Place t$135770 = ((x10.lang.Place[])t$135769.value)[(int)i];
        
        //#line 84 "x10/lang/SparsePlaceGroup.x10"
        return t$135770;
    }
    
    
    //#line 86 "x10/lang/SparsePlaceGroup.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 86 "x10/lang/SparsePlaceGroup.x10"
        final x10.core.Rail t$135771 = ((x10.core.Rail)(this.places));
        
        //#line 86 "x10/lang/SparsePlaceGroup.x10"
        final x10.lang.Iterator t$135772 = ((x10.lang.Iterator<x10.lang.Place>)
                                             ((x10.core.Rail<x10.lang.Place>)t$135771).iterator());
        
        //#line 86 "x10/lang/SparsePlaceGroup.x10"
        return t$135772;
    }
    
    
    //#line 88 "x10/lang/SparsePlaceGroup.x10"
    public long numPlaces$O() {
        
        //#line 88 "x10/lang/SparsePlaceGroup.x10"
        final x10.core.Rail t$135773 = ((x10.core.Rail)(this.places));
        
        //#line 88 "x10/lang/SparsePlaceGroup.x10"
        final long t$135774 = ((x10.core.Rail<x10.lang.Place>)t$135773).size;
        
        //#line 88 "x10/lang/SparsePlaceGroup.x10"
        return t$135774;
    }
    
    
    //#line 90 "x10/lang/SparsePlaceGroup.x10"
    public boolean contains$O(final long id) {
        
        //#line 91 "x10/lang/SparsePlaceGroup.x10"
        final x10.core.Rail rail$135836 = ((x10.core.Rail)(this.places));
        
        //#line 91 "x10/lang/SparsePlaceGroup.x10"
        final long size$135837 = ((x10.core.Rail<x10.lang.Place>)rail$135836).size;
        
        //#line 91 "x10/lang/SparsePlaceGroup.x10"
        long idx$135833 = 0L;
        {
            
            //#line 91 "x10/lang/SparsePlaceGroup.x10"
            final x10.lang.Place[] rail$135836$value$135851 = ((x10.lang.Place[])rail$135836.value);
            
            //#line 91 "x10/lang/SparsePlaceGroup.x10"
            for (;
                 true;
                 ) {
                
                //#line 91 "x10/lang/SparsePlaceGroup.x10"
                final boolean t$135835 = ((idx$135833) < (((long)(size$135837))));
                
                //#line 91 "x10/lang/SparsePlaceGroup.x10"
                if (!(t$135835)) {
                    
                    //#line 91 "x10/lang/SparsePlaceGroup.x10"
                    break;
                }
                
                //#line 91 "x10/lang/SparsePlaceGroup.x10"
                final x10.lang.Place p$135830 = ((x10.lang.Place)(((x10.lang.Place)rail$135836$value$135851[(int)idx$135833])));
                
                //#line 92 "x10/lang/SparsePlaceGroup.x10"
                final long t$135827 = p$135830.id;
                
                //#line 92 "x10/lang/SparsePlaceGroup.x10"
                final boolean t$135828 = ((long) t$135827) == ((long) id);
                
                //#line 92 "x10/lang/SparsePlaceGroup.x10"
                if (t$135828) {
                    
                    //#line 92 "x10/lang/SparsePlaceGroup.x10"
                    return true;
                }
                
                //#line 91 "x10/lang/SparsePlaceGroup.x10"
                final long t$135832 = ((idx$135833) + (((long)(1L))));
                
                //#line 91 "x10/lang/SparsePlaceGroup.x10"
                idx$135833 = t$135832;
            }
        }
        
        //#line 94 "x10/lang/SparsePlaceGroup.x10"
        return false;
    }
    
    
    //#line 97 "x10/lang/SparsePlaceGroup.x10"
    public long indexOf$O(final long id) {
        
        //#line 98 "x10/lang/SparsePlaceGroup.x10"
        final x10.core.Rail rail$135848 = ((x10.core.Rail)(this.places));
        
        //#line 98 "x10/lang/SparsePlaceGroup.x10"
        final long i$134451max$135849 = ((x10.core.Rail<x10.lang.Place>)rail$135848).size;
        
        //#line 98 "x10/lang/SparsePlaceGroup.x10"
        long i$135845 = 0L;
        
        //#line 98 "x10/lang/SparsePlaceGroup.x10"
        for (;
             true;
             ) {
            
            //#line 98 "x10/lang/SparsePlaceGroup.x10"
            final boolean t$135847 = ((i$135845) < (((long)(i$134451max$135849))));
            
            //#line 98 "x10/lang/SparsePlaceGroup.x10"
            if (!(t$135847)) {
                
                //#line 98 "x10/lang/SparsePlaceGroup.x10"
                break;
            }
            
            //#line 99 "x10/lang/SparsePlaceGroup.x10"
            final x10.core.Rail t$135838 = ((x10.core.Rail)(this.places));
            
            //#line 99 "x10/lang/SparsePlaceGroup.x10"
            final x10.lang.Place t$135839 = ((x10.lang.Place[])t$135838.value)[(int)i$135845];
            
            //#line 99 "x10/lang/SparsePlaceGroup.x10"
            final long t$135840 = t$135839.id;
            
            //#line 99 "x10/lang/SparsePlaceGroup.x10"
            final boolean t$135841 = ((long) t$135840) == ((long) id);
            
            //#line 99 "x10/lang/SparsePlaceGroup.x10"
            if (t$135841) {
                
                //#line 99 "x10/lang/SparsePlaceGroup.x10"
                return i$135845;
            }
            
            //#line 98 "x10/lang/SparsePlaceGroup.x10"
            final long t$135844 = ((i$135845) + (((long)(1L))));
            
            //#line 98 "x10/lang/SparsePlaceGroup.x10"
            i$135845 = t$135844;
        }
        
        //#line 101 "x10/lang/SparsePlaceGroup.x10"
        return -1L;
    }
    
    
    //#line 31 "x10/lang/SparsePlaceGroup.x10"
    final public x10.lang.SparsePlaceGroup x10$lang$SparsePlaceGroup$$this$x10$lang$SparsePlaceGroup() {
        
        //#line 31 "x10/lang/SparsePlaceGroup.x10"
        return x10.lang.SparsePlaceGroup.this;
    }
    
    
    //#line 31 "x10/lang/SparsePlaceGroup.x10"
    final public void __fieldInitializers_x10_lang_SparsePlaceGroup() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$155 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$155> $RTT = 
            x10.rtt.StaticFunType.<$Closure$155> make($Closure$155.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.lang.Place.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.SparsePlaceGroup.$Closure$155 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.SparsePlaceGroup.$Closure$155 $_obj = new x10.lang.SparsePlaceGroup.$Closure$155((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$155(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.lang.Place $apply(final long i) {
            
            //#line 73 "x10/lang/SparsePlaceGroup.x10"
            final x10.lang.Place t$135764 = this.pg.$apply((long)(i));
            
            //#line 73 "x10/lang/SparsePlaceGroup.x10"
            return t$135764;
        }
        
        public x10.lang.PlaceGroup pg;
        
        public $Closure$155(final x10.lang.PlaceGroup pg) {
             {
                this.pg = ((x10.lang.PlaceGroup)(pg));
            }
        }
        
    }
    
}

