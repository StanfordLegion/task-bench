package x10.io;


/**
 * Represents a file path.
 * Modeled after java.nio.file.Path.
 *
 * Usage:
 * <pre>
 * try {
 *    val input = new File(inputFileName);
 *    val output = new File(outputFileName);
 *    val p = output.printer();
 *    for (line in input.lines()) {
 *       p.println(line);
 *    }
 *    p.flush();
 * } catch (IOException) { }
 * </pre>
 */
@x10.runtime.impl.java.X10Generated
public class File extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<File> $RTT = 
        x10.rtt.NamedType.<File> make("x10.io.File",
                                      File.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.File $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.absolute = $deserializer.readBoolean();
        $_obj.name = $deserializer.readObject();
        $_obj.parent = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.File $_obj = new x10.io.File((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.absolute);
        $serializer.write(this.name);
        $serializer.write(this.parent);
        
    }
    
    // constructor just for allocation
    public File(final java.lang.System[] $dummy) {
        
    }
    
    

    
    //#line 36 "x10/io/File.x10"
    ;
    
    
    //#line 118 "x10/io/File.x10"
    final public static char SEPARATOR = '/';
    
    //#line 119 "x10/io/File.x10"
    final public static char PATH_SEPARATOR = ':';
    
    //#line 123 "x10/io/File.x10"
    public x10.io.File parent;
    
    //#line 124 "x10/io/File.x10"
    public java.lang.String name;
    
    //#line 125 "x10/io/File.x10"
    public boolean absolute;
    
    
    //#line 127 "x10/io/File.x10"
    // creation method for java code (1-phase java constructor)
    public File(final java.lang.String fullName) {
        this((java.lang.System[]) null);
        x10$io$File$$init$S(fullName);
    }
    
    // constructor for non-virtual call
    final public x10.io.File x10$io$File$$init$S(final java.lang.String fullName) {
         {
            
            //#line 127 "x10/io/File.x10"
            
            
            //#line 128 "x10/io/File.x10"
            final int i = (fullName).lastIndexOf(((char)('/')));
            
            //#line 129 "x10/io/File.x10"
            final boolean t$129268 = ((int) i) == ((int) 0);
            
            //#line 129 "x10/io/File.x10"
            if (t$129268) {
                
                //#line 130 "x10/io/File.x10"
                this.parent = null;
                
                //#line 131 "x10/io/File.x10"
                this.name = ((java.lang.String)(fullName));
                
                //#line 132 "x10/io/File.x10"
                this.absolute = true;
            } else {
                
                //#line 134 "x10/io/File.x10"
                final boolean t$129267 = ((i) >= (((int)(0))));
                
                //#line 134 "x10/io/File.x10"
                if (t$129267) {
                    
                    //#line 135 "x10/io/File.x10"
                    final x10.io.File alloc$129224 = ((x10.io.File)(new x10.io.File((java.lang.System[]) null)));
                    
                    //#line 135 "x10/io/File.x10"
                    final java.lang.String t$129333 = (fullName).substring(((int)(0)), ((int)(i)));
                    
                    //#line 135 "x10/io/File.x10"
                    alloc$129224.x10$io$File$$init$S(t$129333);
                    
                    //#line 135 "x10/io/File.x10"
                    this.parent = ((x10.io.File)(alloc$129224));
                    
                    //#line 136 "x10/io/File.x10"
                    final int t$129262 = ((i) + (((int)(1))));
                    
                    //#line 136 "x10/io/File.x10"
                    final int t$129263 = (fullName).length();
                    
                    //#line 136 "x10/io/File.x10"
                    final java.lang.String t$129264 = (fullName).substring(((int)(t$129262)), ((int)(t$129263)));
                    
                    //#line 136 "x10/io/File.x10"
                    this.name = ((java.lang.String)(t$129264));
                    
                    //#line 137 "x10/io/File.x10"
                    final char t$129265 = (fullName).charAt(((int)(0)));
                    
                    //#line 137 "x10/io/File.x10"
                    final boolean t$129266 = ((char) t$129265) == ((char) ':');
                    
                    //#line 137 "x10/io/File.x10"
                    this.absolute = t$129266;
                } else {
                    
                    //#line 140 "x10/io/File.x10"
                    this.parent = null;
                    
                    //#line 141 "x10/io/File.x10"
                    this.name = ((java.lang.String)(fullName));
                    
                    //#line 142 "x10/io/File.x10"
                    this.absolute = false;
                }
            }
        }
        return this;
    }
    
    
    
    //#line 146 "x10/io/File.x10"
    // creation method for java code (1-phase java constructor)
    public File(final x10.io.File p, final java.lang.String n) {
        this((java.lang.System[]) null);
        x10$io$File$$init$S(p, n);
    }
    
    // constructor for non-virtual call
    final public x10.io.File x10$io$File$$init$S(final x10.io.File p, final java.lang.String n) {
         {
            
            //#line 146 "x10/io/File.x10"
            
            
            //#line 147 "x10/io/File.x10"
            assert ((p) != (null));
            
            //#line 148 "x10/io/File.x10"
            this.parent = ((x10.io.File)(p));
            
            //#line 149 "x10/io/File.x10"
            this.name = ((java.lang.String)(n));
            
            //#line 150 "x10/io/File.x10"
            boolean t$129269 = ((p) != (null));
            
            //#line 150 "x10/io/File.x10"
            if (t$129269) {
                
                //#line 150 "x10/io/File.x10"
                t$129269 = p.absolute;
            }
            
            //#line 150 "x10/io/File.x10"
            this.absolute = t$129269;
        }
        return this;
    }
    
    
    
    //#line 153 "x10/io/File.x10"
    public java.lang.String toString() {
        
        //#line 153 "x10/io/File.x10"
        final java.lang.String t$129271 = this.getPath();
        
        //#line 153 "x10/io/File.x10"
        return t$129271;
    }
    
    
    //#line 155 "x10/io/File.x10"
    public x10.io.ReaderIterator lines() {
        
        //#line 156 "x10/io/File.x10"
        final x10.io.FileReader t$129272 = this.openRead();
        
        //#line 156 "x10/io/File.x10"
        final x10.io.ReaderIterator t$129273 = t$129272.lines();
        
        //#line 156 "x10/io/File.x10"
        return t$129273;
    }
    
    
    //#line 157 "x10/io/File.x10"
    public x10.io.ReaderIterator chars() {
        
        //#line 158 "x10/io/File.x10"
        final x10.io.FileReader t$129274 = this.openRead();
        
        //#line 158 "x10/io/File.x10"
        final x10.io.ReaderIterator t$129275 = t$129274.chars();
        
        //#line 158 "x10/io/File.x10"
        return t$129275;
    }
    
    
    //#line 159 "x10/io/File.x10"
    public x10.io.ReaderIterator bytes() {
        
        //#line 160 "x10/io/File.x10"
        final x10.io.FileReader t$129276 = this.openRead();
        
        //#line 160 "x10/io/File.x10"
        final x10.io.ReaderIterator t$129277 = t$129276.bytes();
        
        //#line 160 "x10/io/File.x10"
        return t$129277;
    }
    
    
    //#line 161 "x10/io/File.x10"
    public x10.io.FileReader openRead() {
        
        //#line 162 "x10/io/File.x10"
        final x10.io.FileReader alloc$129225 = ((x10.io.FileReader)(new x10.io.FileReader((java.lang.System[]) null)));
        
        //#line 162 "x10/io/File.x10"
        alloc$129225.x10$io$FileReader$$init$S(((x10.io.File)(this)));
        
        //#line 162 "x10/io/File.x10"
        return alloc$129225;
    }
    
    
    //#line 163 "x10/io/File.x10"
    public x10.io.FileWriter openWrite() {
        
        //#line 163 "x10/io/File.x10"
        final x10.io.FileWriter t$129278 = this.openWrite((boolean)(false));
        
        //#line 163 "x10/io/File.x10"
        return t$129278;
    }
    
    
    //#line 164 "x10/io/File.x10"
    public x10.io.FileWriter openWrite(final boolean append) {
        
        //#line 165 "x10/io/File.x10"
        final x10.io.FileWriter alloc$129226 = ((x10.io.FileWriter)(new x10.io.FileWriter((java.lang.System[]) null)));
        
        //#line 165 "x10/io/File.x10"
        alloc$129226.x10$io$FileWriter$$init$S(((x10.io.File)(this)), ((boolean)(append)));
        
        //#line 165 "x10/io/File.x10"
        return alloc$129226;
    }
    
    
    //#line 166 "x10/io/File.x10"
    public x10.io.Printer printer() {
        
        //#line 166 "x10/io/File.x10"
        final x10.io.Printer t$129279 = this.printer((boolean)(false));
        
        //#line 166 "x10/io/File.x10"
        return t$129279;
    }
    
    
    //#line 167 "x10/io/File.x10"
    public x10.io.Printer printer(final boolean append) {
        
        //#line 168 "x10/io/File.x10"
        final x10.io.Printer alloc$129227 = ((x10.io.Printer)(new x10.io.Printer((java.lang.System[]) null)));
        
        //#line 168 "x10/io/File.x10"
        final x10.io.FileWriter t$129336 = this.openWrite((boolean)(append));
        
        //#line 168 "x10/io/File.x10"
        alloc$129227.x10$io$Printer$$init$S(((x10.io.Writer)(t$129336)));
        
        //#line 168 "x10/io/File.x10"
        return alloc$129227;
    }
    
    
    //#line 170 "x10/io/File.x10"
    public java.lang.String getName() {
        
        //#line 170 "x10/io/File.x10"
        final java.lang.String t$129281 = ((java.lang.String)(this.name));
        
        //#line 170 "x10/io/File.x10"
        return t$129281;
    }
    
    
    //#line 171 "x10/io/File.x10"
    public x10.io.File getParentFile() {
        
        //#line 171 "x10/io/File.x10"
        final x10.io.File t$129282 = ((x10.io.File)(this.parent));
        
        //#line 171 "x10/io/File.x10"
        return t$129282;
    }
    
    
    //#line 172 "x10/io/File.x10"
    public java.lang.String getPath() {
        
        //#line 172 "x10/io/File.x10"
        final x10.io.File t$129283 = ((x10.io.File)(this.parent));
        
        //#line 172 "x10/io/File.x10"
        final boolean t$129288 = ((t$129283) == (null));
        
        //#line 172 "x10/io/File.x10"
        java.lang.String t$129289 =  null;
        
        //#line 172 "x10/io/File.x10"
        if (t$129288) {
            
            //#line 172 "x10/io/File.x10"
            t$129289 = this.name;
        } else {
            
            //#line 172 "x10/io/File.x10"
            final x10.io.File t$129284 = ((x10.io.File)(this.parent));
            
            //#line 172 "x10/io/File.x10"
            final java.lang.String t$129285 = t$129284.getPath();
            
            //#line 172 "x10/io/File.x10"
            final java.lang.String t$129286 = ((t$129285) + ((x10.core.Char.$box('/'))));
            
            //#line 172 "x10/io/File.x10"
            final java.lang.String t$129287 = ((java.lang.String)(this.name));
            
            //#line 172 "x10/io/File.x10"
            t$129289 = ((t$129286) + (t$129287));
        }
        
        //#line 172 "x10/io/File.x10"
        return t$129289;
    }
    
    
    //#line 173 "x10/io/File.x10"
    public boolean isAbsolute$O() {
        
        //#line 173 "x10/io/File.x10"
        final boolean t$129291 = this.absolute;
        
        //#line 173 "x10/io/File.x10"
        return t$129291;
    }
    
    
    //#line 175 "x10/io/File.x10"
    public x10.core.io.NativeFile nativeFile() {
        
        //#line 175 "x10/io/File.x10"
        final java.lang.String t$129292 = this.getPath();
        
        //#line 175 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129293 = ((x10.core.io.NativeFile)(new x10.core.io.NativeFile(t$129292)));
        
        //#line 175 "x10/io/File.x10"
        return t$129293;
    }
    
    
    //#line 177 "x10/io/File.x10"
    public x10.io.File getAbsoluteFile() {
        
        //#line 177 "x10/io/File.x10"
        final x10.io.File alloc$129228 = ((x10.io.File)(new x10.io.File((java.lang.System[]) null)));
        
        //#line 177 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129337 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 177 "x10/io/File.x10"
        final java.lang.String t$129338 = t$129337.getAbsolutePath();
        
        //#line 177 "x10/io/File.x10"
        alloc$129228.x10$io$File$$init$S(t$129338);
        
        //#line 177 "x10/io/File.x10"
        return alloc$129228;
    }
    
    
    //#line 178 "x10/io/File.x10"
    public x10.io.File getCanonicalFile() {
        
        //#line 179 "x10/io/File.x10"
        final x10.io.File alloc$129229 = ((x10.io.File)(new x10.io.File((java.lang.System[]) null)));
        
        //#line 179 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129339 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 179 "x10/io/File.x10"
        final java.lang.String t$129340 = t$129339.getCanonicalPath();
        
        //#line 179 "x10/io/File.x10"
        alloc$129229.x10$io$File$$init$S(t$129340);
        
        //#line 179 "x10/io/File.x10"
        return alloc$129229;
    }
    
    
    //#line 181 "x10/io/File.x10"
    public boolean exists$O() {
        
        //#line 181 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129298 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 181 "x10/io/File.x10"
        final boolean t$129299 = t$129298.exists();
        
        //#line 181 "x10/io/File.x10"
        return t$129299;
    }
    
    
    //#line 184 "x10/io/File.x10"
    public boolean isSymbolicLink$O() {
        
        //#line 184 "x10/io/File.x10"
        final java.lang.UnsupportedOperationException t$129300 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 184 "x10/io/File.x10"
        throw t$129300;
    }
    
    
    //#line 185 "x10/io/File.x10"
    public boolean isAlias$O() {
        
        //#line 185 "x10/io/File.x10"
        final java.lang.UnsupportedOperationException t$129301 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 185 "x10/io/File.x10"
        throw t$129301;
    }
    
    
    //#line 186 "x10/io/File.x10"
    public boolean hardLinkCount$O() {
        
        //#line 186 "x10/io/File.x10"
        final java.lang.UnsupportedOperationException t$129302 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 186 "x10/io/File.x10"
        throw t$129302;
    }
    
    
    //#line 187 "x10/io/File.x10"
    public long inodeNumber$O() {
        
        //#line 187 "x10/io/File.x10"
        final java.lang.UnsupportedOperationException t$129303 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 187 "x10/io/File.x10"
        throw t$129303;
    }
    
    
    //#line 188 "x10/io/File.x10"
    public int permissions$O() {
        
        //#line 188 "x10/io/File.x10"
        final java.lang.UnsupportedOperationException t$129304 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 188 "x10/io/File.x10"
        throw t$129304;
    }
    
    
    //#line 191 "x10/io/File.x10"
    public boolean isDirectory$O() {
        
        //#line 191 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129305 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 191 "x10/io/File.x10"
        final boolean t$129306 = t$129305.isDirectory();
        
        //#line 191 "x10/io/File.x10"
        return t$129306;
    }
    
    
    //#line 192 "x10/io/File.x10"
    public boolean isFile$O() {
        
        //#line 192 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129307 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 192 "x10/io/File.x10"
        final boolean t$129308 = t$129307.isFile();
        
        //#line 192 "x10/io/File.x10"
        return t$129308;
    }
    
    
    //#line 193 "x10/io/File.x10"
    public boolean isHidden$O() {
        
        //#line 193 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129309 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 193 "x10/io/File.x10"
        final boolean t$129310 = t$129309.isHidden();
        
        //#line 193 "x10/io/File.x10"
        return t$129310;
    }
    
    
    //#line 195 "x10/io/File.x10"
    public long lastModified$O() {
        
        //#line 195 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129311 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 195 "x10/io/File.x10"
        final long t$129312 = t$129311.lastModified();
        
        //#line 195 "x10/io/File.x10"
        return t$129312;
    }
    
    
    //#line 196 "x10/io/File.x10"
    public boolean setLastModified$O(final long t) {
        
        //#line 196 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129313 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 196 "x10/io/File.x10"
        final boolean t$129314 = t$129313.setLastModified(((long)(t)));
        
        //#line 196 "x10/io/File.x10"
        return t$129314;
    }
    
    
    //#line 197 "x10/io/File.x10"
    public long size$O() {
        
        //#line 197 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129315 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 197 "x10/io/File.x10"
        final long t$129316 = t$129315.length();
        
        //#line 197 "x10/io/File.x10"
        return t$129316;
    }
    
    
    //#line 199 "x10/io/File.x10"
    public int compareTo(final java.lang.Object f) {
        
        //#line 199 "x10/io/File.x10"
        final java.lang.UnsupportedOperationException t$129317 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 199 "x10/io/File.x10"
        throw t$129317;
    }
    
    
    //#line 201 "x10/io/File.x10"
    public boolean canRead$O() {
        
        //#line 201 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129318 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 201 "x10/io/File.x10"
        final boolean t$129319 = t$129318.canRead();
        
        //#line 201 "x10/io/File.x10"
        return t$129319;
    }
    
    
    //#line 202 "x10/io/File.x10"
    public boolean canWrite$O() {
        
        //#line 202 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129320 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 202 "x10/io/File.x10"
        final boolean t$129321 = t$129320.canWrite();
        
        //#line 202 "x10/io/File.x10"
        return t$129321;
    }
    
    
    //#line 204 "x10/io/File.x10"
    public boolean delete$O() {
        
        //#line 204 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129322 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 204 "x10/io/File.x10"
        final boolean t$129323 = t$129322.delete();
        
        //#line 204 "x10/io/File.x10"
        return t$129323;
    }
    
    
    //#line 205 "x10/io/File.x10"
    public x10.core.Rail list() {
        
        //#line 205 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129324 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 205 "x10/io/File.x10"
        final x10.core.Rail t$129325 = t$129324.listInternal();
        
        //#line 205 "x10/io/File.x10"
        return t$129325;
    }
    
    
    //#line 206 "x10/io/File.x10"
    public boolean mkdir$O() {
        
        //#line 206 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129326 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 206 "x10/io/File.x10"
        final boolean t$129327 = t$129326.mkdir();
        
        //#line 206 "x10/io/File.x10"
        return t$129327;
    }
    
    
    //#line 207 "x10/io/File.x10"
    public boolean mkdirs$O() {
        
        //#line 207 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129328 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 207 "x10/io/File.x10"
        final boolean t$129329 = t$129328.mkdirs();
        
        //#line 207 "x10/io/File.x10"
        return t$129329;
    }
    
    
    //#line 208 "x10/io/File.x10"
    public boolean renameTo$O(final x10.io.File dest) {
        
        //#line 208 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129330 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 208 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129331 = ((x10.core.io.NativeFile)(dest.nativeFile()));
        
        //#line 208 "x10/io/File.x10"
        final boolean t$129332 = t$129330.renameTo(t$129331);
        
        //#line 208 "x10/io/File.x10"
        return t$129332;
    }
    
    
    //#line 35 "x10/io/File.x10"
    final public x10.io.File x10$io$File$$this$x10$io$File() {
        
        //#line 35 "x10/io/File.x10"
        return x10.io.File.this;
    }
    
    
    //#line 35 "x10/io/File.x10"
    final public void __fieldInitializers_x10_io_File() {
        
    }
    
    public static char get$SEPARATOR() {
        return x10.io.File.SEPARATOR;
    }
    
    public static char get$PATH_SEPARATOR() {
        return x10.io.File.PATH_SEPARATOR;
    }
}

