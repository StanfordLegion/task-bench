package x10.io;

/**
 * Types that implement this interface indicate that when instances
 * of the type are copied across an <code>at</code> boundary, that
 * a custom protocol should be used to transfer the objects values 
 * instead of the default system-provided protocol which copies all
 * non-transient fields. This custom protocol is implemented in two 
 * pieces:
 * <ul>
 * <li>A <code>serialize</code> method that will be invoked by the runtime
 *     system when a value that implements CustomSerialization needs to
 *     be copied.  This serialize method will be passed the Serializer
 *     instance into which it should serialize its state. </li>
 * <li>A constructor that takes a single argument of type <code>Deserializer</code>.
 *     The runtime system will invoke this constructor at the destination
 *     place giving it a deserializer instance from which the state that
 *     was written by the Serializer can be read.</li>
 * </ul>
 *
 * @see Serializer
 * @see Deserializer
 * @see Unserializable
 */
@x10.runtime.impl.java.X10Generated
public interface CustomSerialization extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<CustomSerialization> $RTT = 
        x10.rtt.NamedType.<CustomSerialization> make("x10.io.CustomSerialization",
                                                     CustomSerialization.class);
    
    

    
    
    //#line 40 "x10/io/CustomSerialization.x10"
    /**
     * @param s The Serializer into which the object's state should be written.
     */
    void serialize(final x10.io.Serializer s);
}

