package x10.io;


@x10.runtime.impl.java.X10Generated
public class InputStreamReader extends x10.io.Reader implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<InputStreamReader> $RTT = 
        x10.rtt.NamedType.<InputStreamReader> make("x10.io.InputStreamReader",
                                                   InputStreamReader.class,
                                                   new x10.rtt.Type[] {
                                                       x10.io.Reader.$RTT
                                                   });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.InputStreamReader $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.Reader.$_deserialize_body($_obj, $deserializer);
        $_obj.stream = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.InputStreamReader $_obj = new x10.io.InputStreamReader((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.stream);
        
    }
    
    // constructor just for allocation
    public InputStreamReader(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 18 "x10/io/InputStreamReader.x10"
    public x10.core.io.InputStream stream;
    
    //#line 20 "x10/io/InputStreamReader.x10"
    ;
    
    
    
    //#line 48 "x10/io/InputStreamReader.x10"
    // creation method for java code (1-phase java constructor)
    public InputStreamReader(final x10.core.io.InputStream stream) {
        this((java.lang.System[]) null);
        x10$io$InputStreamReader$$init$S(stream);
    }
    
    // constructor for non-virtual call
    final public x10.io.InputStreamReader x10$io$InputStreamReader$$init$S(final x10.core.io.InputStream stream) {
         {
            
            //#line 48 "x10/io/InputStreamReader.x10"
            
            
            //#line 49 "x10/io/InputStreamReader.x10"
            this.stream = ((x10.core.io.InputStream)(stream));
        }
        return this;
    }
    
    
    
    //#line 52 "x10/io/InputStreamReader.x10"
    public x10.core.io.InputStream stream() {
        
        //#line 52 "x10/io/InputStreamReader.x10"
        final x10.core.io.InputStream t$129438 = ((x10.core.io.InputStream)(this.stream));
        
        //#line 52 "x10/io/InputStreamReader.x10"
        return t$129438;
    }
    
    
    //#line 54 "x10/io/InputStreamReader.x10"
    public void close() {
        
        //#line 55 "x10/io/InputStreamReader.x10"
        final x10.core.io.InputStream t$129439 = ((x10.core.io.InputStream)(this.stream));
        
        //#line 55 "x10/io/InputStreamReader.x10"
        t$129439.close();
    }
    
    
    //#line 58 "x10/io/InputStreamReader.x10"
    public byte read$O() {
        
        //#line 59 "x10/io/InputStreamReader.x10"
        final x10.core.io.InputStream t$129440 = ((x10.core.io.InputStream)(this.stream));
        
        //#line 59 "x10/io/InputStreamReader.x10"
        final int n = t$129440.read$O();
        
        //#line 60 "x10/io/InputStreamReader.x10"
        final boolean t$129442 = ((int) n) == ((int) -1);
        
        //#line 60 "x10/io/InputStreamReader.x10"
        if (t$129442) {
            
            //#line 60 "x10/io/InputStreamReader.x10"
            final x10.io.EOFException t$129441 = ((x10.io.EOFException)(new x10.io.EOFException()));
            
            //#line 60 "x10/io/InputStreamReader.x10"
            throw t$129441;
        }
        
        //#line 61 "x10/io/InputStreamReader.x10"
        final byte t$129443 = ((byte)(int)(((int)(n))));
        
        //#line 61 "x10/io/InputStreamReader.x10"
        return t$129443;
    }
    
    
    //#line 64 "x10/io/InputStreamReader.x10"
    public void read__0$1x10$lang$Byte$2(final x10.core.Rail r, final long off, final long len) {
        
        //#line 65 "x10/io/InputStreamReader.x10"
        final x10.core.io.InputStream t$129444 = ((x10.core.io.InputStream)(this.stream));
        
        //#line 65 "x10/io/InputStreamReader.x10"
        t$129444.read__0$1x10$lang$Byte$2(((x10.core.Rail)(r)), (long)(off), (long)(len));
    }
    
    
    //#line 68 "x10/io/InputStreamReader.x10"
    public long available$O() {
        
        //#line 68 "x10/io/InputStreamReader.x10"
        final x10.core.io.InputStream t$129445 = ((x10.core.io.InputStream)(this.stream));
        
        //#line 68 "x10/io/InputStreamReader.x10"
        final long t$129446 = t$129445.available$O();
        
        //#line 68 "x10/io/InputStreamReader.x10"
        return t$129446;
    }
    
    
    //#line 70 "x10/io/InputStreamReader.x10"
    public void skip(final long off) {
        
        //#line 71 "x10/io/InputStreamReader.x10"
        final x10.core.io.InputStream t$129447 = ((x10.core.io.InputStream)(this.stream));
        
        //#line 71 "x10/io/InputStreamReader.x10"
        t$129447.skip((long)(off));
    }
    
    
    //#line 74 "x10/io/InputStreamReader.x10"
    public void mark(final long off) {
        
        //#line 75 "x10/io/InputStreamReader.x10"
        final x10.core.io.InputStream t$129448 = ((x10.core.io.InputStream)(this.stream));
        
        //#line 75 "x10/io/InputStreamReader.x10"
        t$129448.mark((long)(off));
    }
    
    
    //#line 78 "x10/io/InputStreamReader.x10"
    public void reset() {
        
        //#line 79 "x10/io/InputStreamReader.x10"
        final x10.core.io.InputStream t$129449 = ((x10.core.io.InputStream)(this.stream));
        
        //#line 79 "x10/io/InputStreamReader.x10"
        t$129449.reset();
    }
    
    
    //#line 82 "x10/io/InputStreamReader.x10"
    public boolean markSupported$O() {
        
        //#line 82 "x10/io/InputStreamReader.x10"
        final x10.core.io.InputStream t$129450 = ((x10.core.io.InputStream)(this.stream));
        
        //#line 82 "x10/io/InputStreamReader.x10"
        final boolean t$129451 = t$129450.markSupported$O();
        
        //#line 82 "x10/io/InputStreamReader.x10"
        return t$129451;
    }
    
    
    //#line 17 "x10/io/InputStreamReader.x10"
    final public x10.io.InputStreamReader x10$io$InputStreamReader$$this$x10$io$InputStreamReader() {
        
        //#line 17 "x10/io/InputStreamReader.x10"
        return x10.io.InputStreamReader.this;
    }
    
    
    //#line 17 "x10/io/InputStreamReader.x10"
    final public void __fieldInitializers_x10_io_InputStreamReader() {
        
    }
}

