package x10.io;


/**
 * A class to enable programmatic serialization of X10 values.
 *
 * @see Deserializer
 */
@x10.runtime.impl.java.X10Generated
final public class Serializer extends x10.core.Ref implements x10.io.Unserializable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Serializer> $RTT = 
        x10.rtt.NamedType.<Serializer> make("x10.io.Serializer",
                                            Serializer.class,
                                            new x10.rtt.Type[] {
                                                x10.io.Unserializable.$RTT
                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        throw new x10.io.NotSerializableException("Can't serialize x10.io.Serializer");
    }
    
    // constructor just for allocation
    public Serializer(final java.lang.System[] $dummy) {
        
    }
    
    

    
    //#line 24 "x10/io/Serializer.x10"
    public x10.serialization.X10JavaSerializer __NATIVE_FIELD__;
    
    
    //#line 24 "x10/io/Serializer.x10"
    public Serializer(final x10.serialization.X10JavaSerializer id0) {
         {
            
            //#line 24 "x10/io/Serializer.x10"
            this.__NATIVE_FIELD__ = id0;
        }
    }
    
    
    
    //#line 31 "x10/io/Serializer.x10"
    /**
     * Create and initialize a Serializer that will serialize
     * values to an in-memory Rail[] that can be accessed
     * by calling {@link #toRail}.
     */
    public Serializer() {
         {
            
            //#line 24 "x10/io/Serializer.x10"
            this.__NATIVE_FIELD__ = new x10.serialization.X10JavaSerializer((java.lang.System[]) null).x10$serialization$X10JavaSerializer$$init$S();
        }
    }
    
    
    
    //#line 43 "x10/io/Serializer.x10"
    /**
     * Create and initialize a Serializer that will serialize
     * values to the argument OutputStreamWriter.
     * Serializer instances constructed using this constructor
     * do not support the {@link #toRail()} and cannot be
     * used as arguments to the {@link Deserializer(Serializer)}
     * constructor of the Deserializer class.
     * 
     * NOTE: This constructor is currently only implemented for ManagedX10
     */
    public Serializer(final x10.io.OutputStreamWriter o) {
         {
            
            //#line 24 "x10/io/Serializer.x10"
            this.__NATIVE_FIELD__ = new x10.serialization.X10JavaSerializer((java.lang.System[]) null).x10$serialization$X10JavaSerializer$$init$S(o);
        }
    }
    
    
    
    //#line 50 "x10/io/Serializer.x10"
    /**
     * Write the argument value v (and the object
     * graph reachable from it according to X10 serialization semantics)
     * to this objects serialization stream.
     */
    public void writeAny(final java.lang.Object v) {
        
        //#line 24 "x10/io/Serializer.x10"
        final x10.serialization.X10JavaSerializer t$130518 = this.__NATIVE_FIELD__;
        
        //#line 24 "x10/io/Serializer.x10"
        t$130518.writeAny(((java.lang.Object)(v)));
    }
    
    
    //#line 58 "x10/io/Serializer.x10"
    /**
     * Get the serialized values as a Rail[Byte].
     * If this Serializer was created with a user-provided
     * OutputStreamWriter, then toRail will throw an
     * UnsupportedOperationException.
     */
    public x10.core.Rail toRail() {
        
        //#line 24 "x10/io/Serializer.x10"
        final x10.serialization.X10JavaSerializer t$130519 = this.__NATIVE_FIELD__;
        
        //#line 24 "x10/io/Serializer.x10"
        final x10.core.Rail t$130520 = t$130519.toRail();
        
        //#line 24 "x10/io/Serializer.x10"
        return t$130520;
    }
    
    
    //#line 64 "x10/io/Serializer.x10"
    /**
     * Return the number of bytes of data that
     * have been serialized so far.
     */
    public int dataBytesWritten$O() {
        
        //#line 24 "x10/io/Serializer.x10"
        final x10.serialization.X10JavaSerializer t$130521 = this.__NATIVE_FIELD__;
        
        //#line 24 "x10/io/Serializer.x10"
        final int t$130522 = t$130521.dataBytesWritten$O();
        
        //#line 24 "x10/io/Serializer.x10"
        return t$130522;
    }
    
    
    //#line 77 "x10/io/Serializer.x10"
    /**
     * Indicates that the program wants to serialize a logically
     * new object graph.  This resets the internal state that is used
     * to detect duplicate objects and preserve object identity when
     * the object graph is deserialized.  So even if the same object
     * has already been serialized before the call to newObjectGraph,
     * it will be fully serialized again and when deserialized two
     * copies of the object will be created (instead of one).
     * 
     * Note: This function is currently only implemented for Managed X10
     */
    public void newObjectGraph() {
        
        //#line 24 "x10/io/Serializer.x10"
        final x10.serialization.X10JavaSerializer t$130523 = this.__NATIVE_FIELD__;
        
        //#line 24 "x10/io/Serializer.x10"
        t$130523.newObjectGraph();
    }
    
    
    //#line 99 "x10/io/Serializer.x10"
    /**
     * If a serialized data will be deserialized more than once,
     * this method should be called in advance to specify the number of
     * extra deserializations.  For example:
     * <pre>
     *   val ser = new Serializer();
     *   ser.writeAny(data);
     *   val message = ser.toRail();
     *   ser.addDeserializeCount(Place.places().size()-1);
     *   finish for (pl in Place.places()) {
     *     at (pl) async {
     *       val dser = new Deserializer(message);
     *       val received = dser.readAny() as ...
     *   } }
     * </pre>
     * This method needs not be called if the deserialization will be done
     * only once, but for more than once deserialization, this method must 
     * be called *before* the first deserialization, and the argument is 
     * the number of *extra* deserializations.
     */
    public void addDeserializeCount(final long extraCount) {
        
        //#line 24 "x10/io/Serializer.x10"
        final x10.serialization.X10JavaSerializer t$130524 = this.__NATIVE_FIELD__;
        
        //#line 24 "x10/io/Serializer.x10"
        t$130524.addDeserializeCount((long)(extraCount));
    }
    
    
    //#line 22 "x10/io/Serializer.x10"
    final public x10.io.Serializer x10$io$Serializer$$this$x10$io$Serializer() {
        
        //#line 22 "x10/io/Serializer.x10"
        return x10.io.Serializer.this;
    }
    
    
    //#line 22 "x10/io/Serializer.x10"
    final public void __fieldInitializers_x10_io_Serializer() {
        
    }
}

