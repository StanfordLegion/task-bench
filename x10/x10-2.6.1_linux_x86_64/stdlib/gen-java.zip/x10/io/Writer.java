package x10.io;


/**
 * Usage:
 *
 * try {
 *    val input = new File(inputFileName);
 *    val output = new File(outputFileName);
 *    val p = output.printer();
 *    for (line in input.lines()) {
 *       p.println(line);
 *    }
 *    p.flush();
 * } catch (IOException) { }
 */
@x10.runtime.impl.java.X10Generated
abstract public class Writer extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Writer> $RTT = 
        x10.rtt.NamedType.<Writer> make("x10.io.Writer",
                                        Writer.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Writer $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public Writer(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 30 "x10/io/Writer.x10"
    abstract public void close();
    
    
    //#line 31 "x10/io/Writer.x10"
    abstract public void flush();
    
    
    //#line 33 "x10/io/Writer.x10"
    abstract public void write(final byte x);
    
    
    //#line 34 "x10/io/Writer.x10"
    abstract public void write(final java.lang.String x);
    
    
    //#line 35 "x10/io/Writer.x10"
    abstract public void write__0$1x10$lang$Byte$2(final x10.core.Rail x, final long off, final long len);
    
    
    //#line 37 "x10/io/Writer.x10"
    public void write__0$1x10$lang$Byte$2(final x10.core.Rail buf) {
        
        //#line 38 "x10/io/Writer.x10"
        final long t$130583 = ((x10.core.Rail<x10.core.Byte>)buf).size;
        
        //#line 38 "x10/io/Writer.x10"
        this.write__0$1x10$lang$Byte$2(((x10.core.Rail)(buf)), (long)(0L), (long)(t$130583));
    }
    
    
    //#line 41 "x10/io/Writer.x10"
    public void writeByte(final byte x) {
        
        //#line 42 "x10/io/Writer.x10"
        x10.io.Marshal.$Shadow.get$BYTE();
        
        //#line 42 "x10/io/Writer.x10"
        final x10.io.Writer w$130577 = ((x10.io.Writer)(this));
        
        //#line 65 . "x10/io/Marshal.x10"
        w$130577.write((byte)(x));
    }
    
    
    //#line 44 "x10/io/Writer.x10"
    public void writeUByte__0$u(final byte x) {
        
        //#line 45 "x10/io/Writer.x10"
        final x10.io.Marshal.UByteMarshal t$130584 = ((x10.io.Marshal.UByteMarshal)(x10.io.Marshal.$Shadow.get$UBYTE()));
        
        //#line 45 "x10/io/Writer.x10"
        t$130584.write__1$u(((x10.io.Writer)(this)), (byte)(x));
    }
    
    
    //#line 47 "x10/io/Writer.x10"
    public void writeChar(final char x) {
        
        //#line 48 "x10/io/Writer.x10"
        final x10.io.Marshal.CharMarshal t$130585 = ((x10.io.Marshal.CharMarshal)(x10.io.Marshal.$Shadow.get$CHAR()));
        
        //#line 48 "x10/io/Writer.x10"
        t$130585.write(((x10.io.Writer)(this)), (char)(x));
    }
    
    
    //#line 50 "x10/io/Writer.x10"
    public void writeShort(final short x) {
        
        //#line 51 "x10/io/Writer.x10"
        final x10.io.Marshal.ShortMarshal t$130586 = ((x10.io.Marshal.ShortMarshal)(x10.io.Marshal.$Shadow.get$SHORT()));
        
        //#line 51 "x10/io/Writer.x10"
        t$130586.write(((x10.io.Writer)(this)), (short)(x));
    }
    
    
    //#line 53 "x10/io/Writer.x10"
    public void writeUShort__0$u(final short x) {
        
        //#line 54 "x10/io/Writer.x10"
        final x10.io.Marshal.UShortMarshal t$130587 = ((x10.io.Marshal.UShortMarshal)(x10.io.Marshal.$Shadow.get$USHORT()));
        
        //#line 54 "x10/io/Writer.x10"
        t$130587.write__1$u(((x10.io.Writer)(this)), (short)(x));
    }
    
    
    //#line 56 "x10/io/Writer.x10"
    public void writeInt(final int x) {
        
        //#line 57 "x10/io/Writer.x10"
        final x10.io.Marshal.IntMarshal t$130588 = ((x10.io.Marshal.IntMarshal)(x10.io.Marshal.$Shadow.get$INT()));
        
        //#line 57 "x10/io/Writer.x10"
        t$130588.write(((x10.io.Writer)(this)), (int)(x));
    }
    
    
    //#line 59 "x10/io/Writer.x10"
    public void writeUInt__0$u(final int x) {
        
        //#line 60 "x10/io/Writer.x10"
        final x10.io.Marshal.UIntMarshal t$130589 = ((x10.io.Marshal.UIntMarshal)(x10.io.Marshal.$Shadow.get$UINT()));
        
        //#line 60 "x10/io/Writer.x10"
        t$130589.write__1$u(((x10.io.Writer)(this)), (int)(x));
    }
    
    
    //#line 62 "x10/io/Writer.x10"
    public void writeLong(final long x) {
        
        //#line 63 "x10/io/Writer.x10"
        final x10.io.Marshal.LongMarshal t$130590 = ((x10.io.Marshal.LongMarshal)(x10.io.Marshal.$Shadow.get$LONG()));
        
        //#line 63 "x10/io/Writer.x10"
        t$130590.write(((x10.io.Writer)(this)), (long)(x));
    }
    
    
    //#line 65 "x10/io/Writer.x10"
    public void writeULong__0$u(final long x) {
        
        //#line 66 "x10/io/Writer.x10"
        final x10.io.Marshal.ULongMarshal t$130591 = ((x10.io.Marshal.ULongMarshal)(x10.io.Marshal.$Shadow.get$ULONG()));
        
        //#line 66 "x10/io/Writer.x10"
        t$130591.write__1$u(((x10.io.Writer)(this)), (long)(x));
    }
    
    
    //#line 68 "x10/io/Writer.x10"
    public void writeFloat(final float x) {
        
        //#line 69 "x10/io/Writer.x10"
        final x10.io.Marshal.FloatMarshal t$130592 = ((x10.io.Marshal.FloatMarshal)(x10.io.Marshal.$Shadow.get$FLOAT()));
        
        //#line 69 "x10/io/Writer.x10"
        t$130592.write(((x10.io.Writer)(this)), (float)(x));
    }
    
    
    //#line 71 "x10/io/Writer.x10"
    public void writeDouble(final double x) {
        
        //#line 72 "x10/io/Writer.x10"
        final x10.io.Marshal.DoubleMarshal t$130593 = ((x10.io.Marshal.DoubleMarshal)(x10.io.Marshal.$Shadow.get$DOUBLE()));
        
        //#line 72 "x10/io/Writer.x10"
        t$130593.write(((x10.io.Writer)(this)), (double)(x));
    }
    
    
    //#line 74 "x10/io/Writer.x10"
    public void writeBoolean(final boolean x) {
        
        //#line 75 "x10/io/Writer.x10"
        final x10.io.Marshal.BooleanMarshal t$130594 = ((x10.io.Marshal.BooleanMarshal)(x10.io.Marshal.$Shadow.get$BOOLEAN()));
        
        //#line 75 "x10/io/Writer.x10"
        t$130594.write(((x10.io.Writer)(this)), (boolean)(x));
    }
    
    
    //#line 79 "x10/io/Writer.x10"
    final public <$T>void write__0$1x10$io$Writer$$T$2__1x10$io$Writer$$T(final x10.rtt.Type $T, final x10.io.Marshal m, final $T x) {
        
        //#line 80 "x10/io/Writer.x10"
        ((x10.io.Marshal<$T>)m).write$V(((x10.io.Writer)(this)), (($T)(x)), $T);
    }
    
    
    //#line 84 "x10/io/Writer.x10"
    final public x10.core.io.OutputStream getNativeOutputStream() {
        try {
            return x10.core.io.OutputStream.getNativeOutputStream(this);
        }
        catch (java.lang.Throwable exc$205574) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205574);
        }
        
    }
    
    
    
    //#line 29 "x10/io/Writer.x10"
    final public x10.io.Writer x10$io$Writer$$this$x10$io$Writer() {
        
        //#line 29 "x10/io/Writer.x10"
        return x10.io.Writer.this;
    }
    
    
    //#line 29 "x10/io/Writer.x10"
    
    // constructor for non-virtual call
    final public x10.io.Writer x10$io$Writer$$init$S() {
         {
            
            //#line 29 "x10/io/Writer.x10"
            
        }
        return this;
    }
    
    
    
    //#line 29 "x10/io/Writer.x10"
    final public void __fieldInitializers_x10_io_Writer() {
        
    }
}

