package x10.io;

@x10.runtime.impl.java.X10Generated
public class FilterWriter extends x10.io.Writer implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<FilterWriter> $RTT = 
        x10.rtt.NamedType.<FilterWriter> make("x10.io.FilterWriter",
                                              FilterWriter.class,
                                              new x10.rtt.Type[] {
                                                  x10.io.Writer.$RTT
                                              });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.FilterWriter $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.Writer.$_deserialize_body($_obj, $deserializer);
        $_obj.w = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.FilterWriter $_obj = new x10.io.FilterWriter((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.w);
        
    }
    
    // constructor just for allocation
    public FilterWriter(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 15 "x10/io/FilterWriter.x10"
    public x10.io.Writer w;
    
    
    //#line 17 "x10/io/FilterWriter.x10"
    public x10.io.Writer inner() {
        
        //#line 17 "x10/io/FilterWriter.x10"
        final x10.io.Writer t$129426 = ((x10.io.Writer)(this.w));
        
        //#line 17 "x10/io/FilterWriter.x10"
        return t$129426;
    }
    
    
    //#line 19 "x10/io/FilterWriter.x10"
    // creation method for java code (1-phase java constructor)
    public FilterWriter(final x10.io.Writer w) {
        this((java.lang.System[]) null);
        x10$io$FilterWriter$$init$S(w);
    }
    
    // constructor for non-virtual call
    final public x10.io.FilterWriter x10$io$FilterWriter$$init$S(final x10.io.Writer w) {
         {
            
            //#line 19 "x10/io/FilterWriter.x10"
            
            
            //#line 20 "x10/io/FilterWriter.x10"
            this.w = ((x10.io.Writer)(w));
        }
        return this;
    }
    
    
    
    //#line 23 "x10/io/FilterWriter.x10"
    public void close() {
        
        //#line 24 "x10/io/FilterWriter.x10"
        final x10.io.Writer t$129427 = ((x10.io.Writer)(this.w));
        
        //#line 24 "x10/io/FilterWriter.x10"
        t$129427.close();
    }
    
    
    //#line 27 "x10/io/FilterWriter.x10"
    public void flush() {
        
        //#line 28 "x10/io/FilterWriter.x10"
        final x10.io.Writer t$129428 = ((x10.io.Writer)(this.w));
        
        //#line 28 "x10/io/FilterWriter.x10"
        t$129428.flush();
    }
    
    
    //#line 31 "x10/io/FilterWriter.x10"
    public void write(final byte b) {
        
        //#line 32 "x10/io/FilterWriter.x10"
        final x10.io.Writer t$129429 = ((x10.io.Writer)(this.w));
        
        //#line 32 "x10/io/FilterWriter.x10"
        t$129429.write((byte)(b));
    }
    
    
    //#line 35 "x10/io/FilterWriter.x10"
    public void write(final java.lang.String s) {
        
        //#line 36 "x10/io/FilterWriter.x10"
        final x10.io.Writer t$129430 = ((x10.io.Writer)(this.w));
        
        //#line 36 "x10/io/FilterWriter.x10"
        t$129430.write(((java.lang.String)(s)));
    }
    
    
    //#line 39 "x10/io/FilterWriter.x10"
    public void write__0$1x10$lang$Byte$2(final x10.core.Rail x, final long off, final long len) {
        
        //#line 40 "x10/io/FilterWriter.x10"
        final x10.io.Writer t$129431 = ((x10.io.Writer)(this.w));
        
        //#line 40 "x10/io/FilterWriter.x10"
        t$129431.write__0$1x10$lang$Byte$2(((x10.core.Rail)(x)), (long)(off), (long)(len));
    }
    
    
    //#line 14 "x10/io/FilterWriter.x10"
    final public x10.io.FilterWriter x10$io$FilterWriter$$this$x10$io$FilterWriter() {
        
        //#line 14 "x10/io/FilterWriter.x10"
        return x10.io.FilterWriter.this;
    }
    
    
    //#line 14 "x10/io/FilterWriter.x10"
    final public void __fieldInitializers_x10_io_FilterWriter() {
        
    }
}

