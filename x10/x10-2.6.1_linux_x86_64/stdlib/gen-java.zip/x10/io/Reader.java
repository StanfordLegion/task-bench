package x10.io;

/**
 * Usage:
 *
 * try {
 *    val input = new File(inputFileName);
 *    val output = new File(outputFileName);
 *    val p = output.printer();
 *    for (line in input.lines()) {
 *       p.println(line);
 *    }
 *    p.flush();
 * } catch (IOException) { }
 */
@x10.runtime.impl.java.X10Generated
abstract public class Reader extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Reader> $RTT = 
        x10.rtt.NamedType.<Reader> make("x10.io.Reader",
                                        Reader.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Reader $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public Reader(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 31 "x10/io/Reader.x10"
    /**
     * Close the input stream
     */
    abstract public void close();
    
    
    //#line 36 "x10/io/Reader.x10"
    /**
     * Read the next Byte from the input; throws IOException if none.
     */
    abstract public byte read$O();
    
    
    //#line 44 "x10/io/Reader.x10"
    /**
     * Fill len bytes of the argument rail starting at off.
     * Throws IOException if not enough elements.
     * This is significantly faster than read(Marshal.BYTE,r,off,len)
     * since this reads multiple bytes at once if possible.
     */
    abstract public void read__0$1x10$lang$Byte$2(final x10.core.Rail r, final long off, final long len);
    
    
    //#line 53 "x10/io/Reader.x10"
    /**
     * How many bytes can be read from this stream without blocking?
     *
     * NOTE: there may actually be more bytes than this available when
     * the read is made, in particular this method may return 0 even
     * if a non-zero number of bytes are actually available.
     */
    abstract public long available$O();
    
    
    //#line 55 "x10/io/Reader.x10"
    abstract public void skip(final long v);
    
    
    //#line 57 "x10/io/Reader.x10"
    abstract public void mark(final long m);
    
    
    //#line 58 "x10/io/Reader.x10"
    abstract public void reset();
    
    
    //#line 59 "x10/io/Reader.x10"
    abstract public boolean markSupported$O();
    
    
    //#line 64 "x10/io/Reader.x10"
    /**
     * Read the next Boolean from the input; throws IOException if none.
     */
    public boolean readBoolean$O() {
        
        //#line 64 "x10/io/Reader.x10"
        x10.io.Marshal.$Shadow.get$BOOLEAN();
        
        //#line 64 "x10/io/Reader.x10"
        final x10.io.Reader r$130428 = ((x10.io.Reader)(this));
        
        //#line 56 . "x10/io/Marshal.x10"
        final byte t$130451 = r$130428.read$O();
        
        //#line 56 . "x10/io/Marshal.x10"
        final boolean t$130452 = ((byte) t$130451) != ((byte) ((byte) 0));
        
        //#line 64 "x10/io/Reader.x10"
        return t$130452;
    }
    
    
    //#line 69 "x10/io/Reader.x10"
    /**
     * Read the next Byte from the input; throws IOException if none.
     */
    public byte readByte$O() {
        
        //#line 69 "x10/io/Reader.x10"
        x10.io.Marshal.$Shadow.get$BYTE();
        
        //#line 69 "x10/io/Reader.x10"
        final x10.io.Reader r$130431 = ((x10.io.Reader)(this));
        
        //#line 63 . "x10/io/Marshal.x10"
        final byte t$130453 = r$130431.read$O();
        
        //#line 69 "x10/io/Reader.x10"
        return t$130453;
    }
    
    
    //#line 74 "x10/io/Reader.x10"
    /**
     * Read the next UByte from the input; throws IOException if none.
     */
    public byte readUByte$O() {
        
        //#line 74 "x10/io/Reader.x10"
        final x10.io.Marshal.UByteMarshal t$130454 = ((x10.io.Marshal.UByteMarshal)(x10.io.Marshal.$Shadow.get$UBYTE()));
        
        //#line 74 "x10/io/Reader.x10"
        final byte t$130455 = t$130454.read$O(((x10.io.Reader)(this)));
        
        //#line 74 "x10/io/Reader.x10"
        return t$130455;
    }
    
    
    //#line 79 "x10/io/Reader.x10"
    /**
     * Read the next Char from the input; throws IOException if none.
     */
    public char readChar$O() {
        
        //#line 79 "x10/io/Reader.x10"
        final x10.io.Marshal.CharMarshal t$130456 = ((x10.io.Marshal.CharMarshal)(x10.io.Marshal.$Shadow.get$CHAR()));
        
        //#line 79 "x10/io/Reader.x10"
        final char t$130457 = t$130456.read$O(((x10.io.Reader)(this)));
        
        //#line 79 "x10/io/Reader.x10"
        return t$130457;
    }
    
    
    //#line 84 "x10/io/Reader.x10"
    /**
     * Read the next Short from the input; throws IOException if none.
     */
    public short readShort$O() {
        
        //#line 84 "x10/io/Reader.x10"
        final x10.io.Marshal.ShortMarshal t$130458 = ((x10.io.Marshal.ShortMarshal)(x10.io.Marshal.$Shadow.get$SHORT()));
        
        //#line 84 "x10/io/Reader.x10"
        final short t$130459 = t$130458.read$O(((x10.io.Reader)(this)));
        
        //#line 84 "x10/io/Reader.x10"
        return t$130459;
    }
    
    
    //#line 89 "x10/io/Reader.x10"
    /**
     * Read the next UShort from the input; throws IOException if none.
     */
    public short readUShort$O() {
        
        //#line 89 "x10/io/Reader.x10"
        final x10.io.Marshal.UShortMarshal t$130460 = ((x10.io.Marshal.UShortMarshal)(x10.io.Marshal.$Shadow.get$USHORT()));
        
        //#line 89 "x10/io/Reader.x10"
        final short t$130461 = t$130460.read$O(((x10.io.Reader)(this)));
        
        //#line 89 "x10/io/Reader.x10"
        return t$130461;
    }
    
    
    //#line 94 "x10/io/Reader.x10"
    /**
     * Read the next Int from the input; throws IOException if none.
     */
    public int readInt$O() {
        
        //#line 94 "x10/io/Reader.x10"
        final x10.io.Marshal.IntMarshal t$130462 = ((x10.io.Marshal.IntMarshal)(x10.io.Marshal.$Shadow.get$INT()));
        
        //#line 94 "x10/io/Reader.x10"
        final int t$130463 = t$130462.read$O(((x10.io.Reader)(this)));
        
        //#line 94 "x10/io/Reader.x10"
        return t$130463;
    }
    
    
    //#line 99 "x10/io/Reader.x10"
    /**
     * Read the next UInt from the input; throws IOException if none.
     */
    public int readUInt$O() {
        
        //#line 99 "x10/io/Reader.x10"
        final x10.io.Marshal.UIntMarshal t$130464 = ((x10.io.Marshal.UIntMarshal)(x10.io.Marshal.$Shadow.get$UINT()));
        
        //#line 99 "x10/io/Reader.x10"
        final int t$130465 = t$130464.read$O(((x10.io.Reader)(this)));
        
        //#line 99 "x10/io/Reader.x10"
        return t$130465;
    }
    
    
    //#line 104 "x10/io/Reader.x10"
    /**
     * Read the next Long from the input; throws IOException if none.
     */
    public long readLong$O() {
        
        //#line 104 "x10/io/Reader.x10"
        final x10.io.Marshal.LongMarshal t$130466 = ((x10.io.Marshal.LongMarshal)(x10.io.Marshal.$Shadow.get$LONG()));
        
        //#line 104 "x10/io/Reader.x10"
        final long t$130467 = t$130466.read$O(((x10.io.Reader)(this)));
        
        //#line 104 "x10/io/Reader.x10"
        return t$130467;
    }
    
    
    //#line 109 "x10/io/Reader.x10"
    /**
     * Read the next ULong from the input; throws IOException if none.
     */
    public long readULong$O() {
        
        //#line 109 "x10/io/Reader.x10"
        final x10.io.Marshal.ULongMarshal t$130468 = ((x10.io.Marshal.ULongMarshal)(x10.io.Marshal.$Shadow.get$ULONG()));
        
        //#line 109 "x10/io/Reader.x10"
        final long t$130469 = t$130468.read$O(((x10.io.Reader)(this)));
        
        //#line 109 "x10/io/Reader.x10"
        return t$130469;
    }
    
    
    //#line 114 "x10/io/Reader.x10"
    /**
     * Read the next Float from the input; throws IOException if none.
     */
    public float readFloat$O() {
        
        //#line 114 "x10/io/Reader.x10"
        final x10.io.Marshal.FloatMarshal t$130470 = ((x10.io.Marshal.FloatMarshal)(x10.io.Marshal.$Shadow.get$FLOAT()));
        
        //#line 114 "x10/io/Reader.x10"
        final float t$130471 = t$130470.read$O(((x10.io.Reader)(this)));
        
        //#line 114 "x10/io/Reader.x10"
        return t$130471;
    }
    
    
    //#line 119 "x10/io/Reader.x10"
    /**
     * Read the next Double from the input; throws IOException if none.
     */
    public double readDouble$O() {
        
        //#line 119 "x10/io/Reader.x10"
        final x10.io.Marshal.DoubleMarshal t$130472 = ((x10.io.Marshal.DoubleMarshal)(x10.io.Marshal.$Shadow.get$DOUBLE()));
        
        //#line 119 "x10/io/Reader.x10"
        final double t$130473 = t$130472.read$O(((x10.io.Reader)(this)));
        
        //#line 119 "x10/io/Reader.x10"
        return t$130473;
    }
    
    
    //#line 124 "x10/io/Reader.x10"
    /**
     * Read the next line from the input; throws IOException if none.
     */
    public java.lang.String readLine() {
        
        //#line 124 "x10/io/Reader.x10"
        final x10.io.Marshal.LineMarshal t$130474 = ((x10.io.Marshal.LineMarshal)(x10.io.Marshal.$Shadow.get$LINE()));
        
        //#line 124 "x10/io/Reader.x10"
        final java.lang.String t$130475 = t$130474.read(((x10.io.Reader)(this)));
        
        //#line 124 "x10/io/Reader.x10"
        return t$130475;
    }
    
    
    //#line 129 "x10/io/Reader.x10"
    /**
     * Read the next value from the input; throws IOException if none.
     */
    final public <$T>$T read__0$1x10$io$Reader$$T$2$G(final x10.rtt.Type $T, final x10.io.Marshal m) {
        
        //#line 129 "x10/io/Reader.x10"
        final $T t$130476 = (($T)(((x10.io.Marshal<$T>)m).read$G(((x10.io.Reader)(this)))));
        
        //#line 129 "x10/io/Reader.x10"
        return t$130476;
    }
    
    
    //#line 135 "x10/io/Reader.x10"
    /**
     * Fill the argument rail by reading the next a.size elements. 
     * Throws IOException if not enough elements.
     */
    final public <$T>void read__0$1x10$io$Reader$$T$2__1$1x10$io$Reader$$T$2(final x10.rtt.Type $T, final x10.io.Marshal m, final x10.core.Rail a) {
        
        //#line 136 "x10/io/Reader.x10"
        final long t$130477 = ((x10.core.Rail<$T>)a).size;
        
        //#line 136 "x10/io/Reader.x10"
        this.<$T> read__0$1x10$io$Reader$$T$2__1$1x10$io$Reader$$T$2($T, ((x10.io.Marshal)(m)), ((x10.core.Rail)(a)), (long)(0L), (long)(t$130477));
    }
    
    
    //#line 143 "x10/io/Reader.x10"
    /**
     * Fill len elements of the argument rail starting at off.
     * Throws IOException if not enough elements.
     */
    final public <$T>void read__0$1x10$io$Reader$$T$2__1$1x10$io$Reader$$T$2(final x10.rtt.Type $T, final x10.io.Marshal m, final x10.core.Rail a, final long off, final long len) {
        
        //#line 144 "x10/io/Reader.x10"
        long i = off;
        
        //#line 144 "x10/io/Reader.x10"
        for (;
             true;
             ) {
            
            //#line 144 "x10/io/Reader.x10"
            final long t$130480 = ((off) + (((long)(len))));
            
            //#line 144 "x10/io/Reader.x10"
            final boolean t$130485 = ((i) < (((long)(t$130480))));
            
            //#line 144 "x10/io/Reader.x10"
            if (!(t$130485)) {
                
                //#line 144 "x10/io/Reader.x10"
                break;
            }
            
            //#line 145 "x10/io/Reader.x10"
            final x10.io.Reader this$130493 = ((x10.io.Reader)(this));
            
            //#line 129 . "x10/io/Reader.x10"
            final $T t$130495 = (($T)(((x10.io.Marshal<$T>)m).read$G(((x10.io.Reader)(this$130493)))));
            
            //#line 145 "x10/io/Reader.x10"
            ((x10.core.Rail<$T>)a).$set__1x10$lang$Rail$$T$G((long)(i), (($T)(t$130495)));
            
            //#line 144 "x10/io/Reader.x10"
            final long t$130497 = ((i) + (((long)(1L))));
            
            //#line 144 "x10/io/Reader.x10"
            i = t$130497;
        }
    }
    
    
    //#line 149 "x10/io/Reader.x10"
    public x10.io.ReaderIterator lines() {
        
        //#line 149 "x10/io/Reader.x10"
        final x10.io.ReaderIterator alloc$129258 = ((x10.io.ReaderIterator)(new x10.io.ReaderIterator<java.lang.String>((java.lang.System[]) null, x10.rtt.Types.STRING)));
        
        //#line 149 "x10/io/Reader.x10"
        final x10.io.Marshal.LineMarshal t$130486 = ((x10.io.Marshal.LineMarshal)(x10.io.Marshal.$Shadow.get$LINE()));
        
        //#line 149 "x10/io/Reader.x10"
        final x10.io.Marshal m$130437 = ((x10.io.Marshal)(((x10.io.Marshal<java.lang.String>)
                                                            t$130486)));
        
        //#line 149 "x10/io/Reader.x10"
        final x10.io.Reader r$130438 = ((x10.io.Reader)(this));
        
        //#line 32 .. "x10/io/ReaderIterator.x10"
        final java.lang.String t$130498 = (java.lang.String) x10.rtt.Types.zeroValue(x10.rtt.Types.STRING);
        
        //#line 29 .. "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<java.lang.String>)alloc$129258).next = t$130498;
        
        //#line 35 . "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<java.lang.String>)alloc$129258).m = ((x10.io.Marshal)(m$130437));
        
        //#line 36 . "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<java.lang.String>)alloc$129258).r = ((x10.io.Reader)(r$130438));
        
        //#line 149 "x10/io/Reader.x10"
        return alloc$129258;
    }
    
    
    //#line 150 "x10/io/Reader.x10"
    public x10.io.ReaderIterator chars() {
        
        //#line 150 "x10/io/Reader.x10"
        final x10.io.ReaderIterator alloc$129259 = ((x10.io.ReaderIterator)(new x10.io.ReaderIterator<x10.core.Char>((java.lang.System[]) null, x10.rtt.Types.CHAR)));
        
        //#line 150 "x10/io/Reader.x10"
        final x10.io.Marshal.CharMarshal t$130488 = ((x10.io.Marshal.CharMarshal)(x10.io.Marshal.$Shadow.get$CHAR()));
        
        //#line 150 "x10/io/Reader.x10"
        final x10.io.Marshal m$130441 = ((x10.io.Marshal)(((x10.io.Marshal<x10.core.Char>)
                                                            t$130488)));
        
        //#line 150 "x10/io/Reader.x10"
        final x10.io.Reader r$130442 = ((x10.io.Reader)(this));
        
        //#line 32 .. "x10/io/ReaderIterator.x10"
        final char t$130499 = x10.core.Char.$unbox((x10.core.Char) x10.rtt.Types.zeroValue(x10.rtt.Types.CHAR));
        
        //#line 29 .. "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<x10.core.Char>)alloc$129259).next = x10.core.Char.$box(t$130499);
        
        //#line 35 . "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<x10.core.Char>)alloc$129259).m = ((x10.io.Marshal)(m$130441));
        
        //#line 36 . "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<x10.core.Char>)alloc$129259).r = ((x10.io.Reader)(r$130442));
        
        //#line 150 "x10/io/Reader.x10"
        return alloc$129259;
    }
    
    
    //#line 151 "x10/io/Reader.x10"
    public x10.io.ReaderIterator bytes() {
        
        //#line 151 "x10/io/Reader.x10"
        final x10.io.ReaderIterator alloc$129260 = ((x10.io.ReaderIterator)(new x10.io.ReaderIterator<x10.core.Byte>((java.lang.System[]) null, x10.rtt.Types.BYTE)));
        
        //#line 151 "x10/io/Reader.x10"
        final x10.io.Marshal.ByteMarshal t$130490 = ((x10.io.Marshal.ByteMarshal)(x10.io.Marshal.$Shadow.get$BYTE()));
        
        //#line 151 "x10/io/Reader.x10"
        final x10.io.Marshal m$130445 = ((x10.io.Marshal)(((x10.io.Marshal<x10.core.Byte>)
                                                            t$130490)));
        
        //#line 151 "x10/io/Reader.x10"
        final x10.io.Reader r$130446 = ((x10.io.Reader)(this));
        
        //#line 32 .. "x10/io/ReaderIterator.x10"
        final byte t$130500 = x10.core.Byte.$unbox((x10.core.Byte) x10.rtt.Types.zeroValue(x10.rtt.Types.BYTE));
        
        //#line 29 .. "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<x10.core.Byte>)alloc$129260).next = x10.core.Byte.$box(t$130500);
        
        //#line 35 . "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<x10.core.Byte>)alloc$129260).m = ((x10.io.Marshal)(m$130445));
        
        //#line 36 . "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<x10.core.Byte>)alloc$129260).r = ((x10.io.Reader)(r$130446));
        
        //#line 151 "x10/io/Reader.x10"
        return alloc$129260;
    }
    
    
    //#line 27 "x10/io/Reader.x10"
    final public x10.io.Reader x10$io$Reader$$this$x10$io$Reader() {
        
        //#line 27 "x10/io/Reader.x10"
        return x10.io.Reader.this;
    }
    
    
    //#line 27 "x10/io/Reader.x10"
    
    // constructor for non-virtual call
    final public x10.io.Reader x10$io$Reader$$init$S() {
         {
            
            //#line 27 "x10/io/Reader.x10"
            
        }
        return this;
    }
    
    
    
    //#line 27 "x10/io/Reader.x10"
    final public void __fieldInitializers_x10_io_Reader() {
        
    }
}

