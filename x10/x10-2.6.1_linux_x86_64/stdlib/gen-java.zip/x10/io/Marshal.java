package x10.io;


@x10.runtime.impl.java.X10Generated
public interface Marshal<$T> extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<Marshal> $RTT = 
        x10.rtt.NamedType.<Marshal> make("x10.io.Marshal",
                                         Marshal.class,
                                         1);
    
    

    
    
    //#line 17 "x10/io/Marshal.x10"
    $T read$G(final x10.io.Reader r);
    
    
    //#line 18 "x10/io/Marshal.x10"
    void write$V(final x10.io.Writer w, final java.lang.Object v, x10.rtt.Type t1);
    
    
    //#line 34 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class LineMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<LineMarshal> $RTT = 
            x10.rtt.NamedType.<LineMarshal> make("x10.io.Marshal.LineMarshal",
                                                 LineMarshal.class,
                                                 new x10.rtt.Type[] {
                                                     x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.STRING)
                                                 });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.LineMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.LineMarshal $_obj = new x10.io.Marshal.LineMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public LineMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, (java.lang.String)a2); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, (java.lang.String)a2);
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public java.lang.String read$G(x10.io.Reader a1) {
            return read(a1);
        }
        
        
    
        
        
        //#line 35 "x10/io/Marshal.x10"
        public java.lang.String read(final x10.io.Reader r) {
            
            //#line 36 "x10/io/Marshal.x10"
            final x10.util.GrowableRail buf = ((x10.util.GrowableRail)(new x10.util.GrowableRail<x10.core.Byte>((java.lang.System[]) null, x10.rtt.Types.BYTE)));
            
            //#line 36 "x10/io/Marshal.x10"
            buf.x10$util$GrowableRail$$init$S(((long)(32L)));
            
            //#line 37 "x10/io/Marshal.x10"
            try {{
                
                //#line 38 "x10/io/Marshal.x10"
                while (true) {
                    
                    //#line 39 "x10/io/Marshal.x10"
                    final byte b = r.read$O();
                    
                    //#line 40 "x10/io/Marshal.x10"
                    final char t$130029 = ((char) (((byte)(b))));
                    
                    //#line 40 "x10/io/Marshal.x10"
                    final boolean t$130030 = ((char) t$130029) == ((char) '\n');
                    
                    //#line 40 "x10/io/Marshal.x10"
                    if (t$130030) {
                        
                        //#line 40 "x10/io/Marshal.x10"
                        break;
                    }
                    
                    //#line 41 "x10/io/Marshal.x10"
                    ((x10.util.GrowableRail<x10.core.Byte>)buf).add__0x10$util$GrowableRail$$T(x10.core.Byte.$box(b));
                }
            }}catch (final x10.io.IOException e) {
                
                //#line 166 . "x10/util/GrowableRail.x10"
                final long t$130031 = ((x10.util.GrowableRail<x10.core.Byte>)buf).size;
                
                //#line 44 "x10/io/Marshal.x10"
                final boolean t$130032 = ((long) t$130031) == ((long) 0L);
                
                //#line 44 "x10/io/Marshal.x10"
                if (t$130032) {
                    
                    //#line 45 "x10/io/Marshal.x10"
                    throw e;
                }
            }
            
            //#line 48 "x10/io/Marshal.x10"
            final java.lang.String t$130033 = ((java.lang.String)(new java.lang.String((buf).rail().getByteArray(), 0, (int)(buf).size)));
            
            //#line 48 "x10/io/Marshal.x10"
            return t$130033;
        }
        
        
        //#line 50 "x10/io/Marshal.x10"
        public void write(final x10.io.Writer w, final java.lang.String s) {
            
            //#line 51 "x10/io/Marshal.x10"
            final x10.core.Rail t$130034 = x10.runtime.impl.java.ArrayUtils.<x10.core.Byte>makeRailFromJavaArray(x10.rtt.Types.BYTE, (s).getBytes(), false);
            
            //#line 51 "x10/io/Marshal.x10"
            w.write__0$1x10$lang$Byte$2(((x10.core.Rail)(t$130034)));
        }
        
        
        //#line 34 "x10/io/Marshal.x10"
        final public x10.io.Marshal.LineMarshal x10$io$Marshal$LineMarshal$$this$x10$io$Marshal$LineMarshal() {
            
            //#line 34 "x10/io/Marshal.x10"
            return x10.io.Marshal.LineMarshal.this;
        }
        
        
        //#line 34 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public LineMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$LineMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.LineMarshal x10$io$Marshal$LineMarshal$$init$S() {
             {
                
                //#line 34 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 34 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_LineMarshal() {
            
        }
    }
    
    
    //#line 55 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class BooleanMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<BooleanMarshal> $RTT = 
            x10.rtt.NamedType.<BooleanMarshal> make("x10.io.Marshal.BooleanMarshal",
                                                    BooleanMarshal.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.BOOLEAN)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.BooleanMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.BooleanMarshal $_obj = new x10.io.Marshal.BooleanMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public BooleanMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Boolean.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Boolean.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public x10.core.Boolean read$G(x10.io.Reader a1) {
            return x10.core.Boolean.$box(read$O(a1));
        }
        
        
    
        
        
        //#line 56 "x10/io/Marshal.x10"
        public boolean read$O(final x10.io.Reader r) {
            
            //#line 56 "x10/io/Marshal.x10"
            final byte t$130035 = r.read$O();
            
            //#line 56 "x10/io/Marshal.x10"
            final boolean t$130036 = ((byte) t$130035) != ((byte) ((byte) 0));
            
            //#line 56 "x10/io/Marshal.x10"
            return t$130036;
        }
        
        
        //#line 57 "x10/io/Marshal.x10"
        public void write(final x10.io.Writer w, final boolean b) {
            
            //#line 58 "x10/io/Marshal.x10"
            long t$130037 =  0;
            
            //#line 58 "x10/io/Marshal.x10"
            if (b) {
                
                //#line 58 "x10/io/Marshal.x10"
                t$130037 = 0L;
            } else {
                
                //#line 58 "x10/io/Marshal.x10"
                t$130037 = 1L;
            }
            
            //#line 58 "x10/io/Marshal.x10"
            final byte t$130039 = ((byte)(long)(((long)(t$130037))));
            
            //#line 58 "x10/io/Marshal.x10"
            w.write((byte)(t$130039));
        }
        
        
        //#line 55 "x10/io/Marshal.x10"
        final public x10.io.Marshal.BooleanMarshal x10$io$Marshal$BooleanMarshal$$this$x10$io$Marshal$BooleanMarshal() {
            
            //#line 55 "x10/io/Marshal.x10"
            return x10.io.Marshal.BooleanMarshal.this;
        }
        
        
        //#line 55 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public BooleanMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$BooleanMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.BooleanMarshal x10$io$Marshal$BooleanMarshal$$init$S() {
             {
                
                //#line 55 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 55 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_BooleanMarshal() {
            
        }
    }
    
    
    //#line 62 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class ByteMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<ByteMarshal> $RTT = 
            x10.rtt.NamedType.<ByteMarshal> make("x10.io.Marshal.ByteMarshal",
                                                 ByteMarshal.class,
                                                 new x10.rtt.Type[] {
                                                     x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.BYTE)
                                                 });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.ByteMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.ByteMarshal $_obj = new x10.io.Marshal.ByteMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public ByteMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Byte.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Byte.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public x10.core.Byte read$G(x10.io.Reader a1) {
            return x10.core.Byte.$box(read$O(a1));
        }
        
        
    
        
        
        //#line 63 "x10/io/Marshal.x10"
        public byte read$O(final x10.io.Reader r) {
            
            //#line 63 "x10/io/Marshal.x10"
            final byte t$130040 = r.read$O();
            
            //#line 63 "x10/io/Marshal.x10"
            return t$130040;
        }
        
        
        //#line 64 "x10/io/Marshal.x10"
        public void write(final x10.io.Writer w, final byte b) {
            
            //#line 65 "x10/io/Marshal.x10"
            w.write((byte)(b));
        }
        
        
        //#line 62 "x10/io/Marshal.x10"
        final public x10.io.Marshal.ByteMarshal x10$io$Marshal$ByteMarshal$$this$x10$io$Marshal$ByteMarshal() {
            
            //#line 62 "x10/io/Marshal.x10"
            return x10.io.Marshal.ByteMarshal.this;
        }
        
        
        //#line 62 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public ByteMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$ByteMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.ByteMarshal x10$io$Marshal$ByteMarshal$$init$S() {
             {
                
                //#line 62 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 62 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_ByteMarshal() {
            
        }
    }
    
    
    //#line 69 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class UByteMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<UByteMarshal> $RTT = 
            x10.rtt.NamedType.<UByteMarshal> make("x10.io.Marshal.UByteMarshal",
                                                  UByteMarshal.class,
                                                  new x10.rtt.Type[] {
                                                      x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.UBYTE)
                                                  });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.UByteMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.UByteMarshal $_obj = new x10.io.Marshal.UByteMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public UByteMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write__1$u((x10.io.Writer)a1, x10.core.UByte.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write__1$u((x10.io.Writer)a1, x10.core.UByte.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public x10.core.UByte read$G(x10.io.Reader a1) {
            return x10.core.UByte.$box(read$O(a1));
        }
        
        
    
        
        
        //#line 70 "x10/io/Marshal.x10"
        public byte read$O(final x10.io.Reader r) {
            
            //#line 70 "x10/io/Marshal.x10"
            final byte t$130041 = r.readByte$O();
            
            //#line 70 "x10/io/Marshal.x10"
            final byte t$130042 = ((byte)(((byte)(t$130041))));
            
            //#line 70 "x10/io/Marshal.x10"
            return t$130042;
        }
        
        
        //#line 71 "x10/io/Marshal.x10"
        public void write__1$u(final x10.io.Writer w, final byte ub) {
            
            //#line 72 "x10/io/Marshal.x10"
            final byte t$130043 = ((byte)(((byte)(ub))));
            
            //#line 72 "x10/io/Marshal.x10"
            w.write((byte)(t$130043));
        }
        
        
        //#line 69 "x10/io/Marshal.x10"
        final public x10.io.Marshal.UByteMarshal x10$io$Marshal$UByteMarshal$$this$x10$io$Marshal$UByteMarshal() {
            
            //#line 69 "x10/io/Marshal.x10"
            return x10.io.Marshal.UByteMarshal.this;
        }
        
        
        //#line 69 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public UByteMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$UByteMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.UByteMarshal x10$io$Marshal$UByteMarshal$$init$S() {
             {
                
                //#line 69 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 69 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_UByteMarshal() {
            
        }
    }
    
    
    //#line 76 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class CharMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<CharMarshal> $RTT = 
            x10.rtt.NamedType.<CharMarshal> make("x10.io.Marshal.CharMarshal",
                                                 CharMarshal.class,
                                                 new x10.rtt.Type[] {
                                                     x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.CHAR)
                                                 });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.CharMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.CharMarshal $_obj = new x10.io.Marshal.CharMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public CharMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Char.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Char.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public x10.core.Char read$G(x10.io.Reader a1) {
            return x10.core.Char.$box(read$O(a1));
        }
        
        
    
        
        
        //#line 77 "x10/io/Marshal.x10"
        public char read$O(final x10.io.Reader r) {
            
            //#line 78 "x10/io/Marshal.x10"
            final byte b1 = r.read$O();
            
            //#line 79 "x10/io/Marshal.x10"
            final boolean t$130045 = ((byte) b1) == ((byte) ((byte) -1));
            
            //#line 79 "x10/io/Marshal.x10"
            if (t$130045) {
                
                //#line 79 "x10/io/Marshal.x10"
                final x10.io.EOFException t$130044 = ((x10.io.EOFException)(new x10.io.EOFException()));
                
                //#line 79 "x10/io/Marshal.x10"
                throw t$130044;
            }
            
            //#line 80 "x10/io/Marshal.x10"
            final long t$130046 = ((long)(((byte)(b1))));
            
            //#line 80 "x10/io/Marshal.x10"
            final long t$130047 = ((t$130046) & (((long)(248L))));
            
            //#line 80 "x10/io/Marshal.x10"
            final boolean t$130066 = ((long) t$130047) == ((long) 240L);
            
            //#line 80 "x10/io/Marshal.x10"
            if (t$130066) {
                
                //#line 81 "x10/io/Marshal.x10"
                final byte b2 = r.read$O();
                
                //#line 82 "x10/io/Marshal.x10"
                final byte b3 = r.read$O();
                
                //#line 83 "x10/io/Marshal.x10"
                final byte b4 = r.read$O();
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130048 = ((int)(byte)(((byte)(b1))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130049 = ((t$130048) & (((int)(3))));
                
                //#line 84 "x10/io/Marshal.x10"
                final long t$130050 = ((long)(((int)(18))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130054 = ((t$130049) << (int)(((long)(t$130050))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130051 = ((int)(byte)(((byte)(b2))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130052 = ((t$130051) & (((int)(63))));
                
                //#line 84 "x10/io/Marshal.x10"
                final long t$130053 = ((long)(((int)(12))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130055 = ((t$130052) << (int)(((long)(t$130053))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130059 = ((t$130054) | (((int)(t$130055))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130056 = ((int)(byte)(((byte)(b3))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130057 = ((t$130056) & (((int)(63))));
                
                //#line 84 "x10/io/Marshal.x10"
                final long t$130058 = ((long)(((int)(6))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130060 = ((t$130057) << (int)(((long)(t$130058))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130062 = ((t$130059) | (((int)(t$130060))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130061 = ((int)(byte)(((byte)(b4))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130063 = ((t$130061) & (((int)(63))));
                
                //#line 84 "x10/io/Marshal.x10"
                final int t$130064 = ((t$130062) | (((int)(t$130063))));
                
                //#line 84 "x10/io/Marshal.x10"
                final char t$130065 = ((char) (((int)(t$130064))));
                
                //#line 84 "x10/io/Marshal.x10"
                return t$130065;
            }
            
            //#line 86 "x10/io/Marshal.x10"
            final long t$130067 = ((long)(((byte)(b1))));
            
            //#line 86 "x10/io/Marshal.x10"
            final long t$130068 = ((t$130067) & (((long)(240L))));
            
            //#line 86 "x10/io/Marshal.x10"
            final boolean t$130082 = ((long) t$130068) == ((long) 224L);
            
            //#line 86 "x10/io/Marshal.x10"
            if (t$130082) {
                
                //#line 87 "x10/io/Marshal.x10"
                final byte b2 = r.read$O();
                
                //#line 88 "x10/io/Marshal.x10"
                final byte b3 = r.read$O();
                
                //#line 89 "x10/io/Marshal.x10"
                final int t$130069 = ((int)(byte)(((byte)(b1))));
                
                //#line 89 "x10/io/Marshal.x10"
                final int t$130070 = ((t$130069) & (((int)(31))));
                
                //#line 89 "x10/io/Marshal.x10"
                final long t$130071 = ((long)(((int)(12))));
                
                //#line 89 "x10/io/Marshal.x10"
                final int t$130075 = ((t$130070) << (int)(((long)(t$130071))));
                
                //#line 89 "x10/io/Marshal.x10"
                final int t$130072 = ((int)(byte)(((byte)(b2))));
                
                //#line 89 "x10/io/Marshal.x10"
                final int t$130073 = ((t$130072) & (((int)(63))));
                
                //#line 89 "x10/io/Marshal.x10"
                final long t$130074 = ((long)(((int)(6))));
                
                //#line 89 "x10/io/Marshal.x10"
                final int t$130076 = ((t$130073) << (int)(((long)(t$130074))));
                
                //#line 89 "x10/io/Marshal.x10"
                final int t$130078 = ((t$130075) | (((int)(t$130076))));
                
                //#line 89 "x10/io/Marshal.x10"
                final int t$130077 = ((int)(byte)(((byte)(b3))));
                
                //#line 89 "x10/io/Marshal.x10"
                final int t$130079 = ((t$130077) & (((int)(63))));
                
                //#line 89 "x10/io/Marshal.x10"
                final int t$130080 = ((t$130078) | (((int)(t$130079))));
                
                //#line 89 "x10/io/Marshal.x10"
                final char t$130081 = ((char) (((int)(t$130080))));
                
                //#line 89 "x10/io/Marshal.x10"
                return t$130081;
            }
            
            //#line 91 "x10/io/Marshal.x10"
            final long t$130083 = ((long)(((byte)(b1))));
            
            //#line 91 "x10/io/Marshal.x10"
            final long t$130084 = ((t$130083) & (((long)(224L))));
            
            //#line 91 "x10/io/Marshal.x10"
            final boolean t$130093 = ((long) t$130084) == ((long) 192L);
            
            //#line 91 "x10/io/Marshal.x10"
            if (t$130093) {
                
                //#line 92 "x10/io/Marshal.x10"
                final byte b2 = r.read$O();
                
                //#line 93 "x10/io/Marshal.x10"
                final int t$130085 = ((int)(byte)(((byte)(b1))));
                
                //#line 93 "x10/io/Marshal.x10"
                final int t$130086 = ((t$130085) & (((int)(31))));
                
                //#line 93 "x10/io/Marshal.x10"
                final long t$130087 = ((long)(((int)(6))));
                
                //#line 93 "x10/io/Marshal.x10"
                final int t$130089 = ((t$130086) << (int)(((long)(t$130087))));
                
                //#line 93 "x10/io/Marshal.x10"
                final int t$130088 = ((int)(byte)(((byte)(b2))));
                
                //#line 93 "x10/io/Marshal.x10"
                final int t$130090 = ((t$130088) & (((int)(63))));
                
                //#line 93 "x10/io/Marshal.x10"
                final int t$130091 = ((t$130089) | (((int)(t$130090))));
                
                //#line 93 "x10/io/Marshal.x10"
                final char t$130092 = ((char) (((int)(t$130091))));
                
                //#line 93 "x10/io/Marshal.x10"
                return t$130092;
            }
            
            //#line 96 "x10/io/Marshal.x10"
            final int t$130094 = ((int)(byte)(((byte)(b1))));
            
            //#line 96 "x10/io/Marshal.x10"
            final char t$130095 = ((char) (((int)(t$130094))));
            
            //#line 96 "x10/io/Marshal.x10"
            return t$130095;
        }
        
        
        //#line 99 "x10/io/Marshal.x10"
        public void write(final x10.io.Writer w, final char c) {
            
            //#line 100 "x10/io/Marshal.x10"
            final int i = ((int) (c));
            
            //#line 101 "x10/io/Marshal.x10"
            final long t$130096 = ((long)(((int)(i))));
            
            //#line 101 "x10/io/Marshal.x10"
            final long t$130097 = ((t$130096) & (((long)(4294967168L))));
            
            //#line 101 "x10/io/Marshal.x10"
            final boolean t$130099 = ((long) t$130097) == ((long) 0L);
            
            //#line 101 "x10/io/Marshal.x10"
            if (t$130099) {
                
                //#line 102 "x10/io/Marshal.x10"
                final byte t$130098 = ((byte)(int)(((int)(i))));
                
                //#line 102 "x10/io/Marshal.x10"
                w.write((byte)(t$130098));
                
                //#line 103 "x10/io/Marshal.x10"
                return;
            }
            
            //#line 105 "x10/io/Marshal.x10"
            final long t$130100 = ((long)(((int)(i))));
            
            //#line 105 "x10/io/Marshal.x10"
            final long t$130101 = ((t$130100) & (((long)(4294965248L))));
            
            //#line 105 "x10/io/Marshal.x10"
            final boolean t$130112 = ((long) t$130101) == ((long) 0L);
            
            //#line 105 "x10/io/Marshal.x10"
            if (t$130112) {
                
                //#line 106 "x10/io/Marshal.x10"
                final long t$130102 = ((long)(((int)(6))));
                
                //#line 106 "x10/io/Marshal.x10"
                final int t$130103 = ((i) >> (int)(((long)(t$130102))));
                
                //#line 106 "x10/io/Marshal.x10"
                final long t$130104 = ((long)(((int)(t$130103))));
                
                //#line 106 "x10/io/Marshal.x10"
                final long t$130105 = ((t$130104) & (((long)(31L))));
                
                //#line 106 "x10/io/Marshal.x10"
                final long t$130106 = ((t$130105) | (((long)(192L))));
                
                //#line 106 "x10/io/Marshal.x10"
                final byte t$130107 = ((byte)(long)(((long)(t$130106))));
                
                //#line 106 "x10/io/Marshal.x10"
                w.write((byte)(t$130107));
                
                //#line 107 "x10/io/Marshal.x10"
                final long t$130108 = ((long)(((int)(i))));
                
                //#line 107 "x10/io/Marshal.x10"
                final long t$130109 = ((t$130108) & (((long)(63L))));
                
                //#line 107 "x10/io/Marshal.x10"
                final long t$130110 = ((t$130109) | (((long)(128L))));
                
                //#line 107 "x10/io/Marshal.x10"
                final byte t$130111 = ((byte)(long)(((long)(t$130110))));
                
                //#line 107 "x10/io/Marshal.x10"
                w.write((byte)(t$130111));
                
                //#line 108 "x10/io/Marshal.x10"
                return;
            }
            
            //#line 110 "x10/io/Marshal.x10"
            final long t$130113 = ((long)(((int)(i))));
            
            //#line 110 "x10/io/Marshal.x10"
            final long t$130114 = ((t$130113) & (((long)(4294901760L))));
            
            //#line 110 "x10/io/Marshal.x10"
            final boolean t$130131 = ((long) t$130114) == ((long) 0L);
            
            //#line 110 "x10/io/Marshal.x10"
            if (t$130131) {
                
                //#line 111 "x10/io/Marshal.x10"
                final long t$130115 = ((long)(((int)(12))));
                
                //#line 111 "x10/io/Marshal.x10"
                final int t$130116 = ((i) >> (int)(((long)(t$130115))));
                
                //#line 111 "x10/io/Marshal.x10"
                final long t$130117 = ((long)(((int)(t$130116))));
                
                //#line 111 "x10/io/Marshal.x10"
                final long t$130118 = ((t$130117) & (((long)(15L))));
                
                //#line 111 "x10/io/Marshal.x10"
                final long t$130119 = ((t$130118) | (((long)(224L))));
                
                //#line 111 "x10/io/Marshal.x10"
                final byte t$130120 = ((byte)(long)(((long)(t$130119))));
                
                //#line 111 "x10/io/Marshal.x10"
                w.write((byte)(t$130120));
                
                //#line 112 "x10/io/Marshal.x10"
                final long t$130121 = ((long)(((int)(6))));
                
                //#line 112 "x10/io/Marshal.x10"
                final int t$130122 = ((i) >> (int)(((long)(t$130121))));
                
                //#line 112 "x10/io/Marshal.x10"
                final long t$130123 = ((long)(((int)(t$130122))));
                
                //#line 112 "x10/io/Marshal.x10"
                final long t$130124 = ((t$130123) & (((long)(63L))));
                
                //#line 112 "x10/io/Marshal.x10"
                final long t$130125 = ((t$130124) | (((long)(128L))));
                
                //#line 112 "x10/io/Marshal.x10"
                final byte t$130126 = ((byte)(long)(((long)(t$130125))));
                
                //#line 112 "x10/io/Marshal.x10"
                w.write((byte)(t$130126));
                
                //#line 113 "x10/io/Marshal.x10"
                final long t$130127 = ((long)(((int)(i))));
                
                //#line 113 "x10/io/Marshal.x10"
                final long t$130128 = ((t$130127) & (((long)(63L))));
                
                //#line 113 "x10/io/Marshal.x10"
                final long t$130129 = ((t$130128) | (((long)(128L))));
                
                //#line 113 "x10/io/Marshal.x10"
                final byte t$130130 = ((byte)(long)(((long)(t$130129))));
                
                //#line 113 "x10/io/Marshal.x10"
                w.write((byte)(t$130130));
                
                //#line 114 "x10/io/Marshal.x10"
                return;
            }
            
            //#line 116 "x10/io/Marshal.x10"
            final long t$130132 = ((long)(((int)(i))));
            
            //#line 116 "x10/io/Marshal.x10"
            final long t$130133 = ((t$130132) & (((long)(4292870144L))));
            
            //#line 116 "x10/io/Marshal.x10"
            final boolean t$130156 = ((long) t$130133) == ((long) 0L);
            
            //#line 116 "x10/io/Marshal.x10"
            if (t$130156) {
                
                //#line 117 "x10/io/Marshal.x10"
                final long t$130134 = ((long)(((int)(18))));
                
                //#line 117 "x10/io/Marshal.x10"
                final int t$130135 = ((i) >> (int)(((long)(t$130134))));
                
                //#line 117 "x10/io/Marshal.x10"
                final long t$130136 = ((long)(((int)(t$130135))));
                
                //#line 117 "x10/io/Marshal.x10"
                final long t$130137 = ((t$130136) & (((long)(7L))));
                
                //#line 117 "x10/io/Marshal.x10"
                final long t$130138 = ((t$130137) | (((long)(240L))));
                
                //#line 117 "x10/io/Marshal.x10"
                final byte t$130139 = ((byte)(long)(((long)(t$130138))));
                
                //#line 117 "x10/io/Marshal.x10"
                w.write((byte)(t$130139));
                
                //#line 118 "x10/io/Marshal.x10"
                final long t$130140 = ((long)(((int)(12))));
                
                //#line 118 "x10/io/Marshal.x10"
                final int t$130141 = ((i) >> (int)(((long)(t$130140))));
                
                //#line 118 "x10/io/Marshal.x10"
                final long t$130142 = ((long)(((int)(t$130141))));
                
                //#line 118 "x10/io/Marshal.x10"
                final long t$130143 = ((t$130142) & (((long)(63L))));
                
                //#line 118 "x10/io/Marshal.x10"
                final long t$130144 = ((t$130143) | (((long)(128L))));
                
                //#line 118 "x10/io/Marshal.x10"
                final byte t$130145 = ((byte)(long)(((long)(t$130144))));
                
                //#line 118 "x10/io/Marshal.x10"
                w.write((byte)(t$130145));
                
                //#line 119 "x10/io/Marshal.x10"
                final long t$130146 = ((long)(((int)(6))));
                
                //#line 119 "x10/io/Marshal.x10"
                final int t$130147 = ((i) >> (int)(((long)(t$130146))));
                
                //#line 119 "x10/io/Marshal.x10"
                final long t$130148 = ((long)(((int)(t$130147))));
                
                //#line 119 "x10/io/Marshal.x10"
                final long t$130149 = ((t$130148) & (((long)(63L))));
                
                //#line 119 "x10/io/Marshal.x10"
                final long t$130150 = ((t$130149) | (((long)(128L))));
                
                //#line 119 "x10/io/Marshal.x10"
                final byte t$130151 = ((byte)(long)(((long)(t$130150))));
                
                //#line 119 "x10/io/Marshal.x10"
                w.write((byte)(t$130151));
                
                //#line 120 "x10/io/Marshal.x10"
                final long t$130152 = ((long)(((int)(i))));
                
                //#line 120 "x10/io/Marshal.x10"
                final long t$130153 = ((t$130152) & (((long)(63L))));
                
                //#line 120 "x10/io/Marshal.x10"
                final long t$130154 = ((t$130153) | (((long)(128L))));
                
                //#line 120 "x10/io/Marshal.x10"
                final byte t$130155 = ((byte)(long)(((long)(t$130154))));
                
                //#line 120 "x10/io/Marshal.x10"
                w.write((byte)(t$130155));
                
                //#line 121 "x10/io/Marshal.x10"
                return;
            }
        }
        
        
        //#line 76 "x10/io/Marshal.x10"
        final public x10.io.Marshal.CharMarshal x10$io$Marshal$CharMarshal$$this$x10$io$Marshal$CharMarshal() {
            
            //#line 76 "x10/io/Marshal.x10"
            return x10.io.Marshal.CharMarshal.this;
        }
        
        
        //#line 76 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public CharMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$CharMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.CharMarshal x10$io$Marshal$CharMarshal$$init$S() {
             {
                
                //#line 76 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 76 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_CharMarshal() {
            
        }
    }
    
    
    //#line 126 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class ShortMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<ShortMarshal> $RTT = 
            x10.rtt.NamedType.<ShortMarshal> make("x10.io.Marshal.ShortMarshal",
                                                  ShortMarshal.class,
                                                  new x10.rtt.Type[] {
                                                      x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.SHORT)
                                                  });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.ShortMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.ShortMarshal $_obj = new x10.io.Marshal.ShortMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public ShortMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Short.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Short.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public x10.core.Short read$G(x10.io.Reader a1) {
            return x10.core.Short.$box(read$O(a1));
        }
        
        
    
        
        
        //#line 127 "x10/io/Marshal.x10"
        public short read$O(final x10.io.Reader r) {
            
            //#line 128 "x10/io/Marshal.x10"
            final byte b1 = r.read$O();
            
            //#line 129 "x10/io/Marshal.x10"
            final byte b2 = r.read$O();
            
            //#line 130 "x10/io/Marshal.x10"
            final int t$130157 = ((int)(byte)(((byte)(b1))));
            
            //#line 130 "x10/io/Marshal.x10"
            final int t$130158 = ((t$130157) & (((int)(255))));
            
            //#line 130 "x10/io/Marshal.x10"
            final long t$130159 = ((long)(((int)(8))));
            
            //#line 130 "x10/io/Marshal.x10"
            final int t$130161 = ((t$130158) << (int)(((long)(t$130159))));
            
            //#line 130 "x10/io/Marshal.x10"
            final int t$130160 = ((int)(byte)(((byte)(b2))));
            
            //#line 130 "x10/io/Marshal.x10"
            final int t$130162 = ((t$130160) & (((int)(255))));
            
            //#line 130 "x10/io/Marshal.x10"
            final int t$130163 = ((t$130161) | (((int)(t$130162))));
            
            //#line 130 "x10/io/Marshal.x10"
            final short t$130164 = ((short)(int)(((int)(t$130163))));
            
            //#line 130 "x10/io/Marshal.x10"
            return t$130164;
        }
        
        
        //#line 133 "x10/io/Marshal.x10"
        public void write(final x10.io.Writer w, final short s) {
            
            //#line 134 "x10/io/Marshal.x10"
            final int i = ((int)(short)(((short)(s))));
            
            //#line 135 "x10/io/Marshal.x10"
            final long t$130165 = ((long)(((int)(8))));
            
            //#line 135 "x10/io/Marshal.x10"
            final int t$130166 = ((i) >> (int)(((long)(t$130165))));
            
            //#line 135 "x10/io/Marshal.x10"
            final byte b1 = ((byte)(int)(((int)(t$130166))));
            
            //#line 136 "x10/io/Marshal.x10"
            final byte b2 = ((byte)(int)(((int)(i))));
            
            //#line 137 "x10/io/Marshal.x10"
            w.write((byte)(b1));
            
            //#line 138 "x10/io/Marshal.x10"
            w.write((byte)(b2));
        }
        
        
        //#line 126 "x10/io/Marshal.x10"
        final public x10.io.Marshal.ShortMarshal x10$io$Marshal$ShortMarshal$$this$x10$io$Marshal$ShortMarshal() {
            
            //#line 126 "x10/io/Marshal.x10"
            return x10.io.Marshal.ShortMarshal.this;
        }
        
        
        //#line 126 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public ShortMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$ShortMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.ShortMarshal x10$io$Marshal$ShortMarshal$$init$S() {
             {
                
                //#line 126 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 126 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_ShortMarshal() {
            
        }
    }
    
    
    //#line 142 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class UShortMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<UShortMarshal> $RTT = 
            x10.rtt.NamedType.<UShortMarshal> make("x10.io.Marshal.UShortMarshal",
                                                   UShortMarshal.class,
                                                   new x10.rtt.Type[] {
                                                       x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.USHORT)
                                                   });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.UShortMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.UShortMarshal $_obj = new x10.io.Marshal.UShortMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public UShortMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write__1$u((x10.io.Writer)a1, x10.core.UShort.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write__1$u((x10.io.Writer)a1, x10.core.UShort.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public x10.core.UShort read$G(x10.io.Reader a1) {
            return x10.core.UShort.$box(read$O(a1));
        }
        
        
    
        
        
        //#line 143 "x10/io/Marshal.x10"
        public short read$O(final x10.io.Reader r) {
            
            //#line 143 "x10/io/Marshal.x10"
            final short t$130167 = r.readShort$O();
            
            //#line 143 "x10/io/Marshal.x10"
            final short t$130168 = ((short)(short)(((short)(t$130167))));
            
            //#line 143 "x10/io/Marshal.x10"
            return t$130168;
        }
        
        
        //#line 144 "x10/io/Marshal.x10"
        public void write__1$u(final x10.io.Writer w, final short us) {
            
            //#line 145 "x10/io/Marshal.x10"
            final short t$130169 = ((short)(((short)(us))));
            
            //#line 145 "x10/io/Marshal.x10"
            w.writeShort((short)(t$130169));
        }
        
        
        //#line 142 "x10/io/Marshal.x10"
        final public x10.io.Marshal.UShortMarshal x10$io$Marshal$UShortMarshal$$this$x10$io$Marshal$UShortMarshal() {
            
            //#line 142 "x10/io/Marshal.x10"
            return x10.io.Marshal.UShortMarshal.this;
        }
        
        
        //#line 142 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public UShortMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$UShortMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.UShortMarshal x10$io$Marshal$UShortMarshal$$init$S() {
             {
                
                //#line 142 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 142 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_UShortMarshal() {
            
        }
    }
    
    
    //#line 149 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class IntMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<IntMarshal> $RTT = 
            x10.rtt.NamedType.<IntMarshal> make("x10.io.Marshal.IntMarshal",
                                                IntMarshal.class,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.INT)
                                                });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.IntMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.IntMarshal $_obj = new x10.io.Marshal.IntMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public IntMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Int.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Int.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public x10.core.Int read$G(x10.io.Reader a1) {
            return x10.core.Int.$box(read$O(a1));
        }
        
        
    
        
        
        //#line 150 "x10/io/Marshal.x10"
        public int read$O(final x10.io.Reader r) {
            
            //#line 151 "x10/io/Marshal.x10"
            final byte b1 = r.read$O();
            
            //#line 152 "x10/io/Marshal.x10"
            final byte b2 = r.read$O();
            
            //#line 153 "x10/io/Marshal.x10"
            final byte b3 = r.read$O();
            
            //#line 154 "x10/io/Marshal.x10"
            final byte b4 = r.read$O();
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130170 = ((int)(byte)(((byte)(b1))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130171 = ((t$130170) & (((int)(255))));
            
            //#line 155 "x10/io/Marshal.x10"
            final long t$130172 = ((long)(((int)(24))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130176 = ((t$130171) << (int)(((long)(t$130172))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130173 = ((int)(byte)(((byte)(b2))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130174 = ((t$130173) & (((int)(255))));
            
            //#line 155 "x10/io/Marshal.x10"
            final long t$130175 = ((long)(((int)(16))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130177 = ((t$130174) << (int)(((long)(t$130175))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130181 = ((t$130176) | (((int)(t$130177))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130178 = ((int)(byte)(((byte)(b3))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130179 = ((t$130178) & (((int)(255))));
            
            //#line 155 "x10/io/Marshal.x10"
            final long t$130180 = ((long)(((int)(8))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130182 = ((t$130179) << (int)(((long)(t$130180))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130184 = ((t$130181) | (((int)(t$130182))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130183 = ((int)(byte)(((byte)(b4))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130185 = ((t$130183) & (((int)(255))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130186 = ((t$130184) | (((int)(t$130185))));
            
            //#line 155 "x10/io/Marshal.x10"
            final int t$130187 = t$130186;
            
            //#line 155 "x10/io/Marshal.x10"
            return t$130187;
        }
        
        
        //#line 158 "x10/io/Marshal.x10"
        public void write(final x10.io.Writer w, final int i) {
            
            //#line 159 "x10/io/Marshal.x10"
            final long t$130188 = ((long)(((int)(24))));
            
            //#line 159 "x10/io/Marshal.x10"
            final int t$130189 = ((i) >> (int)(((long)(t$130188))));
            
            //#line 159 "x10/io/Marshal.x10"
            final byte b1 = ((byte)(int)(((int)(t$130189))));
            
            //#line 160 "x10/io/Marshal.x10"
            final long t$130190 = ((long)(((int)(16))));
            
            //#line 160 "x10/io/Marshal.x10"
            final int t$130191 = ((i) >> (int)(((long)(t$130190))));
            
            //#line 160 "x10/io/Marshal.x10"
            final byte b2 = ((byte)(int)(((int)(t$130191))));
            
            //#line 161 "x10/io/Marshal.x10"
            final long t$130192 = ((long)(((int)(8))));
            
            //#line 161 "x10/io/Marshal.x10"
            final int t$130193 = ((i) >> (int)(((long)(t$130192))));
            
            //#line 161 "x10/io/Marshal.x10"
            final byte b3 = ((byte)(int)(((int)(t$130193))));
            
            //#line 162 "x10/io/Marshal.x10"
            final byte b4 = ((byte)(int)(((int)(i))));
            
            //#line 163 "x10/io/Marshal.x10"
            w.write((byte)(b1));
            
            //#line 164 "x10/io/Marshal.x10"
            w.write((byte)(b2));
            
            //#line 165 "x10/io/Marshal.x10"
            w.write((byte)(b3));
            
            //#line 166 "x10/io/Marshal.x10"
            w.write((byte)(b4));
        }
        
        
        //#line 149 "x10/io/Marshal.x10"
        final public x10.io.Marshal.IntMarshal x10$io$Marshal$IntMarshal$$this$x10$io$Marshal$IntMarshal() {
            
            //#line 149 "x10/io/Marshal.x10"
            return x10.io.Marshal.IntMarshal.this;
        }
        
        
        //#line 149 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public IntMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$IntMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.IntMarshal x10$io$Marshal$IntMarshal$$init$S() {
             {
                
                //#line 149 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 149 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_IntMarshal() {
            
        }
    }
    
    
    //#line 170 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class UIntMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<UIntMarshal> $RTT = 
            x10.rtt.NamedType.<UIntMarshal> make("x10.io.Marshal.UIntMarshal",
                                                 UIntMarshal.class,
                                                 new x10.rtt.Type[] {
                                                     x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.UINT)
                                                 });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.UIntMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.UIntMarshal $_obj = new x10.io.Marshal.UIntMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public UIntMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write__1$u((x10.io.Writer)a1, x10.core.UInt.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write__1$u((x10.io.Writer)a1, x10.core.UInt.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public x10.core.UInt read$G(x10.io.Reader a1) {
            return x10.core.UInt.$box(read$O(a1));
        }
        
        
    
        
        
        //#line 171 "x10/io/Marshal.x10"
        public int read$O(final x10.io.Reader r) {
            
            //#line 171 "x10/io/Marshal.x10"
            final int t$130194 = r.readInt$O();
            
            //#line 171 "x10/io/Marshal.x10"
            final int t$130195 = ((int)(((int)(t$130194))));
            
            //#line 171 "x10/io/Marshal.x10"
            return t$130195;
        }
        
        
        //#line 172 "x10/io/Marshal.x10"
        public void write__1$u(final x10.io.Writer w, final int ui) {
            
            //#line 173 "x10/io/Marshal.x10"
            final int t$130196 = ((int)((int)(ui)));
            
            //#line 173 "x10/io/Marshal.x10"
            w.writeInt((int)(t$130196));
        }
        
        
        //#line 170 "x10/io/Marshal.x10"
        final public x10.io.Marshal.UIntMarshal x10$io$Marshal$UIntMarshal$$this$x10$io$Marshal$UIntMarshal() {
            
            //#line 170 "x10/io/Marshal.x10"
            return x10.io.Marshal.UIntMarshal.this;
        }
        
        
        //#line 170 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public UIntMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$UIntMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.UIntMarshal x10$io$Marshal$UIntMarshal$$init$S() {
             {
                
                //#line 170 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 170 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_UIntMarshal() {
            
        }
    }
    
    
    //#line 177 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class LongMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<LongMarshal> $RTT = 
            x10.rtt.NamedType.<LongMarshal> make("x10.io.Marshal.LongMarshal",
                                                 LongMarshal.class,
                                                 new x10.rtt.Type[] {
                                                     x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.LONG)
                                                 });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.LongMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.LongMarshal $_obj = new x10.io.Marshal.LongMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public LongMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Long.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Long.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public x10.core.Long read$G(x10.io.Reader a1) {
            return x10.core.Long.$box(read$O(a1));
        }
        
        
    
        
        
        //#line 178 "x10/io/Marshal.x10"
        public long read$O(final x10.io.Reader r) {
            
            //#line 179 "x10/io/Marshal.x10"
            long l = 0L;
            
            //#line 180 "x10/io/Marshal.x10"
            int i$130238 = 0;
            
            //#line 180 "x10/io/Marshal.x10"
            for (;
                 true;
                 ) {
                
                //#line 180 "x10/io/Marshal.x10"
                final boolean t$130240 = ((i$130238) < (((int)(8))));
                
                //#line 180 "x10/io/Marshal.x10"
                if (!(t$130240)) {
                    
                    //#line 180 "x10/io/Marshal.x10"
                    break;
                }
                
                //#line 181 "x10/io/Marshal.x10"
                final byte b$130228 = r.read$O();
                
                //#line 182 "x10/io/Marshal.x10"
                final long t$130230 = ((long)(((int)(8))));
                
                //#line 182 "x10/io/Marshal.x10"
                final long t$130231 = ((l) << (int)(((long)(t$130230))));
                
                //#line 182 "x10/io/Marshal.x10"
                final int t$130232 = ((int)(byte)(((byte)(b$130228))));
                
                //#line 182 "x10/io/Marshal.x10"
                final int t$130233 = ((t$130232) & (((int)(255))));
                
                //#line 182 "x10/io/Marshal.x10"
                final long t$130234 = ((long)(((int)(t$130233))));
                
                //#line 182 "x10/io/Marshal.x10"
                final long t$130235 = ((t$130231) | (((long)(t$130234))));
                
                //#line 182 "x10/io/Marshal.x10"
                l = t$130235;
                
                //#line 180 "x10/io/Marshal.x10"
                final int t$130237 = ((i$130238) + (((int)(1))));
                
                //#line 180 "x10/io/Marshal.x10"
                i$130238 = t$130237;
            }
            
            //#line 184 "x10/io/Marshal.x10"
            return l;
        }
        
        
        //#line 187 "x10/io/Marshal.x10"
        public void write(final x10.io.Writer w, final long l) {
            
            //#line 188 "x10/io/Marshal.x10"
            int shift = 64;
            
            //#line 189 "x10/io/Marshal.x10"
            while (true) {
                
                //#line 189 "x10/io/Marshal.x10"
                final long t$130211 = ((long)(((int)(shift))));
                
                //#line 189 "x10/io/Marshal.x10"
                final boolean t$130218 = ((t$130211) > (((long)(0L))));
                
                //#line 189 "x10/io/Marshal.x10"
                if (!(t$130218)) {
                    
                    //#line 189 "x10/io/Marshal.x10"
                    break;
                }
                
                //#line 190 "x10/io/Marshal.x10"
                final long t$130242 = ((long)(((int)(shift))));
                
                //#line 190 "x10/io/Marshal.x10"
                final long t$130243 = ((t$130242) - (((long)(8L))));
                
                //#line 190 "x10/io/Marshal.x10"
                shift = ((int)(((long)(t$130243))));
                
                //#line 191 "x10/io/Marshal.x10"
                final long t$130245 = ((long)(((int)(shift))));
                
                //#line 191 "x10/io/Marshal.x10"
                final long t$130246 = ((l) >> (int)(((long)(t$130245))));
                
                //#line 191 "x10/io/Marshal.x10"
                final byte b$130247 = ((byte)(long)(((long)(t$130246))));
                
                //#line 192 "x10/io/Marshal.x10"
                w.write((byte)(b$130247));
            }
        }
        
        
        //#line 177 "x10/io/Marshal.x10"
        final public x10.io.Marshal.LongMarshal x10$io$Marshal$LongMarshal$$this$x10$io$Marshal$LongMarshal() {
            
            //#line 177 "x10/io/Marshal.x10"
            return x10.io.Marshal.LongMarshal.this;
        }
        
        
        //#line 177 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public LongMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$LongMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.LongMarshal x10$io$Marshal$LongMarshal$$init$S() {
             {
                
                //#line 177 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 177 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_LongMarshal() {
            
        }
    }
    
    
    //#line 197 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class ULongMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<ULongMarshal> $RTT = 
            x10.rtt.NamedType.<ULongMarshal> make("x10.io.Marshal.ULongMarshal",
                                                  ULongMarshal.class,
                                                  new x10.rtt.Type[] {
                                                      x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.ULONG)
                                                  });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.ULongMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.ULongMarshal $_obj = new x10.io.Marshal.ULongMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public ULongMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write__1$u((x10.io.Writer)a1, x10.core.ULong.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write__1$u((x10.io.Writer)a1, x10.core.ULong.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public x10.core.ULong read$G(x10.io.Reader a1) {
            return x10.core.ULong.$box(read$O(a1));
        }
        
        
    
        
        
        //#line 198 "x10/io/Marshal.x10"
        public long read$O(final x10.io.Reader r) {
            
            //#line 198 "x10/io/Marshal.x10"
            final long t$130219 = r.readLong$O();
            
            //#line 198 "x10/io/Marshal.x10"
            final long t$130220 = ((long)(((long)(t$130219))));
            
            //#line 198 "x10/io/Marshal.x10"
            return t$130220;
        }
        
        
        //#line 199 "x10/io/Marshal.x10"
        public void write__1$u(final x10.io.Writer w, final long ul) {
            
            //#line 200 "x10/io/Marshal.x10"
            final long t$130221 = ((long)(((long)(ul))));
            
            //#line 200 "x10/io/Marshal.x10"
            w.writeLong((long)(t$130221));
        }
        
        
        //#line 197 "x10/io/Marshal.x10"
        final public x10.io.Marshal.ULongMarshal x10$io$Marshal$ULongMarshal$$this$x10$io$Marshal$ULongMarshal() {
            
            //#line 197 "x10/io/Marshal.x10"
            return x10.io.Marshal.ULongMarshal.this;
        }
        
        
        //#line 197 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public ULongMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$ULongMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.ULongMarshal x10$io$Marshal$ULongMarshal$$init$S() {
             {
                
                //#line 197 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 197 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_ULongMarshal() {
            
        }
    }
    
    
    //#line 204 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class FloatMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<FloatMarshal> $RTT = 
            x10.rtt.NamedType.<FloatMarshal> make("x10.io.Marshal.FloatMarshal",
                                                  FloatMarshal.class,
                                                  new x10.rtt.Type[] {
                                                      x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.FLOAT)
                                                  });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.FloatMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.FloatMarshal $_obj = new x10.io.Marshal.FloatMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public FloatMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Float.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Float.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public x10.core.Float read$G(x10.io.Reader a1) {
            return x10.core.Float.$box(read$O(a1));
        }
        
        
    
        
        
        //#line 205 "x10/io/Marshal.x10"
        public float read$O(final x10.io.Reader r) {
            
            //#line 206 "x10/io/Marshal.x10"
            final x10.io.Marshal.IntMarshal t$130222 = ((x10.io.Marshal.IntMarshal)(x10.io.Marshal.$Shadow.get$INT()));
            
            //#line 206 "x10/io/Marshal.x10"
            final int i = t$130222.read$O(((x10.io.Reader)(r)));
            
            //#line 207 "x10/io/Marshal.x10"
            final float t$130223 = java.lang.Float.intBitsToFloat(((int)(i)));
            
            //#line 207 "x10/io/Marshal.x10"
            return t$130223;
        }
        
        
        //#line 209 "x10/io/Marshal.x10"
        public void write(final x10.io.Writer w, final float f) {
            
            //#line 210 "x10/io/Marshal.x10"
            final int i = java.lang.Float.floatToIntBits(f);
            
            //#line 211 "x10/io/Marshal.x10"
            final x10.io.Marshal.IntMarshal t$130224 = ((x10.io.Marshal.IntMarshal)(x10.io.Marshal.$Shadow.get$INT()));
            
            //#line 211 "x10/io/Marshal.x10"
            t$130224.write(((x10.io.Writer)(w)), (int)(i));
        }
        
        
        //#line 204 "x10/io/Marshal.x10"
        final public x10.io.Marshal.FloatMarshal x10$io$Marshal$FloatMarshal$$this$x10$io$Marshal$FloatMarshal() {
            
            //#line 204 "x10/io/Marshal.x10"
            return x10.io.Marshal.FloatMarshal.this;
        }
        
        
        //#line 204 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public FloatMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$FloatMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.FloatMarshal x10$io$Marshal$FloatMarshal$$init$S() {
             {
                
                //#line 204 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 204 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_FloatMarshal() {
            
        }
    }
    
    
    //#line 215 "x10/io/Marshal.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class DoubleMarshal extends x10.core.Ref implements x10.io.Marshal, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<DoubleMarshal> $RTT = 
            x10.rtt.NamedType.<DoubleMarshal> make("x10.io.Marshal.DoubleMarshal",
                                                   DoubleMarshal.class,
                                                   new x10.rtt.Type[] {
                                                       x10.rtt.ParameterizedType.make(x10.io.Marshal.$RTT, x10.rtt.Types.DOUBLE)
                                                   });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.DoubleMarshal $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Marshal.DoubleMarshal $_obj = new x10.io.Marshal.DoubleMarshal((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public DoubleMarshal(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public java.lang.Object write(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Double.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public x10.io.Marshal[T].write(w:x10.io.Writer, v:T){}:void
        public void write$V(final x10.io.Writer a1, final java.lang.Object a2, final x10.rtt.Type t2) {
            write((x10.io.Writer)a1, x10.core.Double.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.io.Marshal[T].read(r:x10.io.Reader){}:T
        public x10.core.Double read$G(x10.io.Reader a1) {
            return x10.core.Double.$box(read$O(a1));
        }
        
        
    
        
        
        //#line 216 "x10/io/Marshal.x10"
        public double read$O(final x10.io.Reader r) {
            
            //#line 217 "x10/io/Marshal.x10"
            final x10.io.Marshal.LongMarshal t$130225 = ((x10.io.Marshal.LongMarshal)(x10.io.Marshal.$Shadow.get$LONG()));
            
            //#line 217 "x10/io/Marshal.x10"
            final long l = t$130225.read$O(((x10.io.Reader)(r)));
            
            //#line 218 "x10/io/Marshal.x10"
            final double t$130226 = java.lang.Double.longBitsToDouble(((long)(l)));
            
            //#line 218 "x10/io/Marshal.x10"
            return t$130226;
        }
        
        
        //#line 220 "x10/io/Marshal.x10"
        public void write(final x10.io.Writer w, final double d) {
            
            //#line 221 "x10/io/Marshal.x10"
            final long l = java.lang.Double.doubleToLongBits(d);
            
            //#line 222 "x10/io/Marshal.x10"
            final x10.io.Marshal.LongMarshal t$130227 = ((x10.io.Marshal.LongMarshal)(x10.io.Marshal.$Shadow.get$LONG()));
            
            //#line 222 "x10/io/Marshal.x10"
            t$130227.write(((x10.io.Writer)(w)), (long)(l));
        }
        
        
        //#line 215 "x10/io/Marshal.x10"
        final public x10.io.Marshal.DoubleMarshal x10$io$Marshal$DoubleMarshal$$this$x10$io$Marshal$DoubleMarshal() {
            
            //#line 215 "x10/io/Marshal.x10"
            return x10.io.Marshal.DoubleMarshal.this;
        }
        
        
        //#line 215 "x10/io/Marshal.x10"
        // creation method for java code (1-phase java constructor)
        public DoubleMarshal() {
            this((java.lang.System[]) null);
            x10$io$Marshal$DoubleMarshal$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.io.Marshal.DoubleMarshal x10$io$Marshal$DoubleMarshal$$init$S() {
             {
                
                //#line 215 "x10/io/Marshal.x10"
                
            }
            return this;
        }
        
        
        
        //#line 215 "x10/io/Marshal.x10"
        final public void __fieldInitializers_x10_io_Marshal_DoubleMarshal() {
            
        }
    }
    
    @x10.runtime.impl.java.X10Generated
    abstract public class $Shadow extends x10.core.Ref implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Shadow> $RTT = 
            x10.rtt.NamedType.<$Shadow> make("x10.io.Marshal.$Shadow",
                                             $Shadow.class);
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Marshal.$Shadow $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return null;
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Shadow(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        //#line 32 "x10/io/Marshal.x10"
        private static x10.io.Marshal.LineMarshal LINE;
        final private static x10.core.concurrent.AtomicInteger initStatus$LINE = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$LINE;
        
        //#line 31 "x10/io/Marshal.x10"
        private static x10.io.Marshal.DoubleMarshal DOUBLE;
        final private static x10.core.concurrent.AtomicInteger initStatus$DOUBLE = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$DOUBLE;
        
        //#line 30 "x10/io/Marshal.x10"
        private static x10.io.Marshal.FloatMarshal FLOAT;
        final private static x10.core.concurrent.AtomicInteger initStatus$FLOAT = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$FLOAT;
        
        //#line 29 "x10/io/Marshal.x10"
        private static x10.io.Marshal.ULongMarshal ULONG;
        final private static x10.core.concurrent.AtomicInteger initStatus$ULONG = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$ULONG;
        
        //#line 28 "x10/io/Marshal.x10"
        private static x10.io.Marshal.LongMarshal LONG;
        final private static x10.core.concurrent.AtomicInteger initStatus$LONG = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$LONG;
        
        //#line 27 "x10/io/Marshal.x10"
        private static x10.io.Marshal.UIntMarshal UINT;
        final private static x10.core.concurrent.AtomicInteger initStatus$UINT = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$UINT;
        
        //#line 26 "x10/io/Marshal.x10"
        private static x10.io.Marshal.IntMarshal INT;
        final private static x10.core.concurrent.AtomicInteger initStatus$INT = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$INT;
        
        //#line 25 "x10/io/Marshal.x10"
        private static x10.io.Marshal.UShortMarshal USHORT;
        final private static x10.core.concurrent.AtomicInteger initStatus$USHORT = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$USHORT;
        
        //#line 24 "x10/io/Marshal.x10"
        private static x10.io.Marshal.ShortMarshal SHORT;
        final private static x10.core.concurrent.AtomicInteger initStatus$SHORT = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$SHORT;
        
        //#line 23 "x10/io/Marshal.x10"
        private static x10.io.Marshal.CharMarshal CHAR;
        final private static x10.core.concurrent.AtomicInteger initStatus$CHAR = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$CHAR;
        
        //#line 22 "x10/io/Marshal.x10"
        private static x10.io.Marshal.UByteMarshal UBYTE;
        final private static x10.core.concurrent.AtomicInteger initStatus$UBYTE = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$UBYTE;
        
        //#line 21 "x10/io/Marshal.x10"
        private static x10.io.Marshal.ByteMarshal BYTE;
        final private static x10.core.concurrent.AtomicInteger initStatus$BYTE = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$BYTE;
        
        //#line 20 "x10/io/Marshal.x10"
        private static x10.io.Marshal.BooleanMarshal BOOLEAN;
        final private static x10.core.concurrent.AtomicInteger initStatus$BOOLEAN = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
        private static x10.lang.ExceptionInInitializer exception$BOOLEAN;
        
        public static x10.io.Marshal.BooleanMarshal get$BOOLEAN() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$BOOLEAN.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.BOOLEAN;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$BOOLEAN.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$BOOLEAN;
            }
            if (x10.io.Marshal.$Shadow.initStatus$BOOLEAN.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.BOOLEAN = ((x10.io.Marshal.BooleanMarshal)(new x10.io.Marshal.BooleanMarshal((java.lang.System[]) null).x10$io$Marshal$BooleanMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130248) {
                    x10.io.Marshal.$Shadow.exception$BOOLEAN = new x10.lang.ExceptionInInitializer(exc$130248);
                    x10.io.Marshal.$Shadow.initStatus$BOOLEAN.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$BOOLEAN;
                }
                x10.io.Marshal.$Shadow.initStatus$BOOLEAN.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$BOOLEAN.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$BOOLEAN.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$BOOLEAN.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$BOOLEAN;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.BOOLEAN;
        }
        
        public static x10.io.Marshal.ByteMarshal get$BYTE() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$BYTE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.BYTE;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$BYTE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$BYTE;
            }
            if (x10.io.Marshal.$Shadow.initStatus$BYTE.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.BYTE = ((x10.io.Marshal.ByteMarshal)(new x10.io.Marshal.ByteMarshal((java.lang.System[]) null).x10$io$Marshal$ByteMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130249) {
                    x10.io.Marshal.$Shadow.exception$BYTE = new x10.lang.ExceptionInInitializer(exc$130249);
                    x10.io.Marshal.$Shadow.initStatus$BYTE.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$BYTE;
                }
                x10.io.Marshal.$Shadow.initStatus$BYTE.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$BYTE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$BYTE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$BYTE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$BYTE;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.BYTE;
        }
        
        public static x10.io.Marshal.UByteMarshal get$UBYTE() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$UBYTE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.UBYTE;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$UBYTE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$UBYTE;
            }
            if (x10.io.Marshal.$Shadow.initStatus$UBYTE.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.UBYTE = ((x10.io.Marshal.UByteMarshal)(new x10.io.Marshal.UByteMarshal((java.lang.System[]) null).x10$io$Marshal$UByteMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130250) {
                    x10.io.Marshal.$Shadow.exception$UBYTE = new x10.lang.ExceptionInInitializer(exc$130250);
                    x10.io.Marshal.$Shadow.initStatus$UBYTE.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$UBYTE;
                }
                x10.io.Marshal.$Shadow.initStatus$UBYTE.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$UBYTE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$UBYTE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$UBYTE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$UBYTE;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.UBYTE;
        }
        
        public static x10.io.Marshal.CharMarshal get$CHAR() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$CHAR.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.CHAR;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$CHAR.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$CHAR;
            }
            if (x10.io.Marshal.$Shadow.initStatus$CHAR.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.CHAR = ((x10.io.Marshal.CharMarshal)(new x10.io.Marshal.CharMarshal((java.lang.System[]) null).x10$io$Marshal$CharMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130251) {
                    x10.io.Marshal.$Shadow.exception$CHAR = new x10.lang.ExceptionInInitializer(exc$130251);
                    x10.io.Marshal.$Shadow.initStatus$CHAR.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$CHAR;
                }
                x10.io.Marshal.$Shadow.initStatus$CHAR.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$CHAR.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$CHAR.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$CHAR.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$CHAR;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.CHAR;
        }
        
        public static x10.io.Marshal.ShortMarshal get$SHORT() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$SHORT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.SHORT;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$SHORT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$SHORT;
            }
            if (x10.io.Marshal.$Shadow.initStatus$SHORT.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.SHORT = ((x10.io.Marshal.ShortMarshal)(new x10.io.Marshal.ShortMarshal((java.lang.System[]) null).x10$io$Marshal$ShortMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130252) {
                    x10.io.Marshal.$Shadow.exception$SHORT = new x10.lang.ExceptionInInitializer(exc$130252);
                    x10.io.Marshal.$Shadow.initStatus$SHORT.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$SHORT;
                }
                x10.io.Marshal.$Shadow.initStatus$SHORT.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$SHORT.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$SHORT.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$SHORT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$SHORT;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.SHORT;
        }
        
        public static x10.io.Marshal.UShortMarshal get$USHORT() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$USHORT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.USHORT;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$USHORT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$USHORT;
            }
            if (x10.io.Marshal.$Shadow.initStatus$USHORT.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.USHORT = ((x10.io.Marshal.UShortMarshal)(new x10.io.Marshal.UShortMarshal((java.lang.System[]) null).x10$io$Marshal$UShortMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130253) {
                    x10.io.Marshal.$Shadow.exception$USHORT = new x10.lang.ExceptionInInitializer(exc$130253);
                    x10.io.Marshal.$Shadow.initStatus$USHORT.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$USHORT;
                }
                x10.io.Marshal.$Shadow.initStatus$USHORT.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$USHORT.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$USHORT.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$USHORT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$USHORT;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.USHORT;
        }
        
        public static x10.io.Marshal.IntMarshal get$INT() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$INT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.INT;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$INT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$INT;
            }
            if (x10.io.Marshal.$Shadow.initStatus$INT.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.INT = ((x10.io.Marshal.IntMarshal)(new x10.io.Marshal.IntMarshal((java.lang.System[]) null).x10$io$Marshal$IntMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130254) {
                    x10.io.Marshal.$Shadow.exception$INT = new x10.lang.ExceptionInInitializer(exc$130254);
                    x10.io.Marshal.$Shadow.initStatus$INT.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$INT;
                }
                x10.io.Marshal.$Shadow.initStatus$INT.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$INT.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$INT.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$INT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$INT;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.INT;
        }
        
        public static x10.io.Marshal.UIntMarshal get$UINT() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$UINT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.UINT;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$UINT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$UINT;
            }
            if (x10.io.Marshal.$Shadow.initStatus$UINT.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.UINT = ((x10.io.Marshal.UIntMarshal)(new x10.io.Marshal.UIntMarshal((java.lang.System[]) null).x10$io$Marshal$UIntMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130255) {
                    x10.io.Marshal.$Shadow.exception$UINT = new x10.lang.ExceptionInInitializer(exc$130255);
                    x10.io.Marshal.$Shadow.initStatus$UINT.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$UINT;
                }
                x10.io.Marshal.$Shadow.initStatus$UINT.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$UINT.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$UINT.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$UINT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$UINT;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.UINT;
        }
        
        public static x10.io.Marshal.LongMarshal get$LONG() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$LONG.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.LONG;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$LONG.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$LONG;
            }
            if (x10.io.Marshal.$Shadow.initStatus$LONG.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.LONG = ((x10.io.Marshal.LongMarshal)(new x10.io.Marshal.LongMarshal((java.lang.System[]) null).x10$io$Marshal$LongMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130256) {
                    x10.io.Marshal.$Shadow.exception$LONG = new x10.lang.ExceptionInInitializer(exc$130256);
                    x10.io.Marshal.$Shadow.initStatus$LONG.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$LONG;
                }
                x10.io.Marshal.$Shadow.initStatus$LONG.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$LONG.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$LONG.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$LONG.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$LONG;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.LONG;
        }
        
        public static x10.io.Marshal.ULongMarshal get$ULONG() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$ULONG.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.ULONG;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$ULONG.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$ULONG;
            }
            if (x10.io.Marshal.$Shadow.initStatus$ULONG.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.ULONG = ((x10.io.Marshal.ULongMarshal)(new x10.io.Marshal.ULongMarshal((java.lang.System[]) null).x10$io$Marshal$ULongMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130257) {
                    x10.io.Marshal.$Shadow.exception$ULONG = new x10.lang.ExceptionInInitializer(exc$130257);
                    x10.io.Marshal.$Shadow.initStatus$ULONG.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$ULONG;
                }
                x10.io.Marshal.$Shadow.initStatus$ULONG.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$ULONG.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$ULONG.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$ULONG.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$ULONG;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.ULONG;
        }
        
        public static x10.io.Marshal.FloatMarshal get$FLOAT() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$FLOAT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.FLOAT;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$FLOAT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$FLOAT;
            }
            if (x10.io.Marshal.$Shadow.initStatus$FLOAT.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.FLOAT = ((x10.io.Marshal.FloatMarshal)(new x10.io.Marshal.FloatMarshal((java.lang.System[]) null).x10$io$Marshal$FloatMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130258) {
                    x10.io.Marshal.$Shadow.exception$FLOAT = new x10.lang.ExceptionInInitializer(exc$130258);
                    x10.io.Marshal.$Shadow.initStatus$FLOAT.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$FLOAT;
                }
                x10.io.Marshal.$Shadow.initStatus$FLOAT.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$FLOAT.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$FLOAT.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$FLOAT.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$FLOAT;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.FLOAT;
        }
        
        public static x10.io.Marshal.DoubleMarshal get$DOUBLE() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$DOUBLE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.DOUBLE;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$DOUBLE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$DOUBLE;
            }
            if (x10.io.Marshal.$Shadow.initStatus$DOUBLE.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.DOUBLE = ((x10.io.Marshal.DoubleMarshal)(new x10.io.Marshal.DoubleMarshal((java.lang.System[]) null).x10$io$Marshal$DoubleMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130259) {
                    x10.io.Marshal.$Shadow.exception$DOUBLE = new x10.lang.ExceptionInInitializer(exc$130259);
                    x10.io.Marshal.$Shadow.initStatus$DOUBLE.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$DOUBLE;
                }
                x10.io.Marshal.$Shadow.initStatus$DOUBLE.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$DOUBLE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$DOUBLE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$DOUBLE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$DOUBLE;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.DOUBLE;
        }
        
        public static x10.io.Marshal.LineMarshal get$LINE() {
            if (((int) x10.io.Marshal.$Shadow.initStatus$LINE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
                return x10.io.Marshal.$Shadow.LINE;
            }
            if (((int) x10.io.Marshal.$Shadow.initStatus$LINE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                throw x10.io.Marshal.$Shadow.exception$LINE;
            }
            if (x10.io.Marshal.$Shadow.initStatus$LINE.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
                try {{
                    x10.io.Marshal.$Shadow.LINE = ((x10.io.Marshal.LineMarshal)(new x10.io.Marshal.LineMarshal((java.lang.System[]) null).x10$io$Marshal$LineMarshal$$init$S()));
                }}catch (java.lang.Throwable exc$130260) {
                    x10.io.Marshal.$Shadow.exception$LINE = new x10.lang.ExceptionInInitializer(exc$130260);
                    x10.io.Marshal.$Shadow.initStatus$LINE.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                    throw x10.io.Marshal.$Shadow.exception$LINE;
                }
                x10.io.Marshal.$Shadow.initStatus$LINE.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
            } else {
                if (x10.io.Marshal.$Shadow.initStatus$LINE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.lockInitialized();
                    while (x10.io.Marshal.$Shadow.initStatus$LINE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                        x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                    }
                    x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                    if (((int) x10.io.Marshal.$Shadow.initStatus$LINE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                        throw x10.io.Marshal.$Shadow.exception$LINE;
                    }
                }
            }
            return x10.io.Marshal.$Shadow.LINE;
        }
    }
    
}

