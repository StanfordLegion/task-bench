package x10.io;

@x10.runtime.impl.java.X10Generated
public class IOException extends java.lang.RuntimeException implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<IOException> $RTT = 
        x10.rtt.NamedType.<IOException> make("x10.io.IOException",
                                             IOException.class,
                                             new x10.rtt.Type[] {
                                                 x10.rtt.Types.EXCEPTION
                                             });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.IOException $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $deserializer.deserializeFieldsStartingFromClass(java.lang.RuntimeException.class, $_obj, 0);
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.IOException $_obj = new x10.io.IOException((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.serializeFieldsStartingFromClass(this, java.lang.RuntimeException.class);
        
    }
    
    // constructor just for allocation
    public IOException(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 17 "x10/io/IOException.x10"
    public IOException() {
        super();
         {
            
            //#line 17 "x10/io/IOException.x10"
            
            
            //#line 15 "x10/io/IOException.x10"
            this.__fieldInitializers_x10_io_IOException();
        }
    }
    
    
    
    //#line 19 "x10/io/IOException.x10"
    public IOException(final java.lang.String message) {
        super(((java.lang.String)(message)));
         {
            
            //#line 19 "x10/io/IOException.x10"
            
            
            //#line 15 "x10/io/IOException.x10"
            this.__fieldInitializers_x10_io_IOException();
        }
    }
    
    
    
    //#line 15 "x10/io/IOException.x10"
    final public x10.io.IOException x10$io$IOException$$this$x10$io$IOException() {
        
        //#line 15 "x10/io/IOException.x10"
        return x10.io.IOException.this;
    }
    
    
    //#line 15 "x10/io/IOException.x10"
    final public void __fieldInitializers_x10_io_IOException() {
        
    }
}

