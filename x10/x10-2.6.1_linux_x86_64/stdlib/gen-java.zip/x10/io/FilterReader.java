package x10.io;

@x10.runtime.impl.java.X10Generated
public class FilterReader extends x10.io.Reader implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<FilterReader> $RTT = 
        x10.rtt.NamedType.<FilterReader> make("x10.io.FilterReader",
                                              FilterReader.class,
                                              new x10.rtt.Type[] {
                                                  x10.io.Reader.$RTT
                                              });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.FilterReader $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.Reader.$_deserialize_body($_obj, $deserializer);
        $_obj.r = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.FilterReader $_obj = new x10.io.FilterReader((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.r);
        
    }
    
    // constructor just for allocation
    public FilterReader(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 15 "x10/io/FilterReader.x10"
    public x10.io.Reader r;
    
    
    //#line 17 "x10/io/FilterReader.x10"
    public x10.io.Reader inner() {
        
        //#line 17 "x10/io/FilterReader.x10"
        final x10.io.Reader t$129408 = ((x10.io.Reader)(this.r));
        
        //#line 17 "x10/io/FilterReader.x10"
        return t$129408;
    }
    
    
    //#line 19 "x10/io/FilterReader.x10"
    // creation method for java code (1-phase java constructor)
    public FilterReader(final x10.io.Reader r) {
        this((java.lang.System[]) null);
        x10$io$FilterReader$$init$S(r);
    }
    
    // constructor for non-virtual call
    final public x10.io.FilterReader x10$io$FilterReader$$init$S(final x10.io.Reader r) {
         {
            
            //#line 19 "x10/io/FilterReader.x10"
            
            
            //#line 20 "x10/io/FilterReader.x10"
            this.r = ((x10.io.Reader)(r));
        }
        return this;
    }
    
    
    
    //#line 23 "x10/io/FilterReader.x10"
    public void close() {
        
        //#line 24 "x10/io/FilterReader.x10"
        final x10.io.Reader t$129409 = ((x10.io.Reader)(this.r));
        
        //#line 24 "x10/io/FilterReader.x10"
        t$129409.close();
    }
    
    
    //#line 26 "x10/io/FilterReader.x10"
    public byte read$O() {
        
        //#line 26 "x10/io/FilterReader.x10"
        final x10.io.Reader t$129410 = ((x10.io.Reader)(this.r));
        
        //#line 26 "x10/io/FilterReader.x10"
        final byte t$129411 = t$129410.read$O();
        
        //#line 26 "x10/io/FilterReader.x10"
        return t$129411;
    }
    
    
    //#line 28 "x10/io/FilterReader.x10"
    public void read__0$1x10$lang$Byte$2(final x10.core.Rail r, final long off, final long len) {
        
        //#line 29 "x10/io/FilterReader.x10"
        final x10.io.Reader t$129412 = ((x10.io.Reader)(this.r));
        
        //#line 29 "x10/io/FilterReader.x10"
        t$129412.read__0$1x10$lang$Byte$2(((x10.core.Rail)(r)), (long)(off), (long)(len));
    }
    
    
    //#line 32 "x10/io/FilterReader.x10"
    public long available$O() {
        
        //#line 32 "x10/io/FilterReader.x10"
        final x10.io.Reader t$129413 = ((x10.io.Reader)(this.r));
        
        //#line 32 "x10/io/FilterReader.x10"
        final long t$129414 = t$129413.available$O();
        
        //#line 32 "x10/io/FilterReader.x10"
        return t$129414;
    }
    
    
    //#line 34 "x10/io/FilterReader.x10"
    public void skip(final long off) {
        
        //#line 35 "x10/io/FilterReader.x10"
        final x10.io.Reader t$129415 = ((x10.io.Reader)(this.r));
        
        //#line 35 "x10/io/FilterReader.x10"
        t$129415.skip((long)(off));
    }
    
    
    //#line 38 "x10/io/FilterReader.x10"
    public void mark(final long off) {
        
        //#line 39 "x10/io/FilterReader.x10"
        final x10.io.Reader t$129416 = ((x10.io.Reader)(this.r));
        
        //#line 39 "x10/io/FilterReader.x10"
        t$129416.mark((long)(off));
    }
    
    
    //#line 42 "x10/io/FilterReader.x10"
    public void reset() {
        
        //#line 43 "x10/io/FilterReader.x10"
        final x10.io.Reader t$129417 = ((x10.io.Reader)(this.r));
        
        //#line 43 "x10/io/FilterReader.x10"
        t$129417.reset();
    }
    
    
    //#line 46 "x10/io/FilterReader.x10"
    public boolean markSupported$O() {
        
        //#line 46 "x10/io/FilterReader.x10"
        final x10.io.Reader t$129418 = ((x10.io.Reader)(this.r));
        
        //#line 46 "x10/io/FilterReader.x10"
        final boolean t$129419 = t$129418.markSupported$O();
        
        //#line 46 "x10/io/FilterReader.x10"
        return t$129419;
    }
    
    
    //#line 14 "x10/io/FilterReader.x10"
    final public x10.io.FilterReader x10$io$FilterReader$$this$x10$io$FilterReader() {
        
        //#line 14 "x10/io/FilterReader.x10"
        return x10.io.FilterReader.this;
    }
    
    
    //#line 14 "x10/io/FilterReader.x10"
    final public void __fieldInitializers_x10_io_FilterReader() {
        
    }
}

