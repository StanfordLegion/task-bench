package x10.io;


@x10.runtime.impl.java.X10Generated
public class StringWriter extends x10.io.Writer implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<StringWriter> $RTT = 
        x10.rtt.NamedType.<StringWriter> make("x10.io.StringWriter",
                                              StringWriter.class,
                                              new x10.rtt.Type[] {
                                                  x10.io.Writer.$RTT
                                              });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.StringWriter $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.Writer.$_deserialize_body($_obj, $deserializer);
        $_obj.b = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.StringWriter $_obj = new x10.io.StringWriter((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.b);
        
    }
    
    // constructor just for allocation
    public StringWriter(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 17 "x10/io/StringWriter.x10"
    public x10.util.StringBuilder b;
    
    
    //#line 19 "x10/io/StringWriter.x10"
    // creation method for java code (1-phase java constructor)
    public StringWriter() {
        this((java.lang.System[]) null);
        x10$io$StringWriter$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.io.StringWriter x10$io$StringWriter$$init$S() {
         {
            
            //#line 19 "x10/io/StringWriter.x10"
            
            
            //#line 20 "x10/io/StringWriter.x10"
            final x10.util.StringBuilder alloc$130546 = ((x10.util.StringBuilder)(new x10.util.StringBuilder((java.lang.System[]) null)));
            
            //#line 20 "x10/io/StringWriter.x10"
            alloc$130546.x10$util$StringBuilder$$init$S();
            
            //#line 20 "x10/io/StringWriter.x10"
            this.b = ((x10.util.StringBuilder)(alloc$130546));
        }
        return this;
    }
    
    
    
    //#line 23 "x10/io/StringWriter.x10"
    public void write(final byte x) {
        
        //#line 24 "x10/io/StringWriter.x10"
        final x10.util.StringBuilder t$130552 = ((x10.util.StringBuilder)(this.b));
        
        //#line 24 "x10/io/StringWriter.x10"
        final char t$130553 = ((char) (((byte)(x))));
        
        //#line 24 "x10/io/StringWriter.x10"
        t$130552.add((char)(t$130553));
    }
    
    
    //#line 27 "x10/io/StringWriter.x10"
    public void write(final java.lang.String s) {
        
        //#line 28 "x10/io/StringWriter.x10"
        final x10.util.StringBuilder t$130554 = ((x10.util.StringBuilder)(this.b));
        
        //#line 28 "x10/io/StringWriter.x10"
        t$130554.addString(((java.lang.String)(s)));
    }
    
    
    //#line 31 "x10/io/StringWriter.x10"
    public void write__0$1x10$lang$Byte$2(final x10.core.Rail x, final long off, final long len) {
        
        //#line 32 "x10/io/StringWriter.x10"
        long i = off;
        {
            
            //#line 32 "x10/io/StringWriter.x10"
            final byte[] x$value$130576 = ((byte[])x.value);
            
            //#line 32 "x10/io/StringWriter.x10"
            for (;
                 true;
                 ) {
                
                //#line 32 "x10/io/StringWriter.x10"
                final long t$130557 = ((off) + (((long)(len))));
                
                //#line 32 "x10/io/StringWriter.x10"
                final boolean t$130564 = ((i) < (((long)(t$130557))));
                
                //#line 32 "x10/io/StringWriter.x10"
                if (!(t$130564)) {
                    
                    //#line 32 "x10/io/StringWriter.x10"
                    break;
                }
                
                //#line 33 "x10/io/StringWriter.x10"
                final x10.util.StringBuilder t$130570 = ((x10.util.StringBuilder)(this.b));
                
                //#line 33 "x10/io/StringWriter.x10"
                final byte t$130572 = ((byte)x$value$130576[(int)i]);
                
                //#line 33 "x10/io/StringWriter.x10"
                final char t$130573 = ((char) (((byte)(t$130572))));
                
                //#line 33 "x10/io/StringWriter.x10"
                t$130570.add((char)(t$130573));
                
                //#line 32 "x10/io/StringWriter.x10"
                final long t$130575 = ((i) + (((long)(1L))));
                
                //#line 32 "x10/io/StringWriter.x10"
                i = t$130575;
            }
        }
    }
    
    
    //#line 37 "x10/io/StringWriter.x10"
    public long size$O() {
        
        //#line 37 "x10/io/StringWriter.x10"
        final x10.util.StringBuilder t$130565 = ((x10.util.StringBuilder)(this.b));
        
        //#line 37 "x10/io/StringWriter.x10"
        final long t$130566 = t$130565.length();
        
        //#line 37 "x10/io/StringWriter.x10"
        return t$130566;
    }
    
    
    //#line 39 "x10/io/StringWriter.x10"
    public java.lang.String result() {
        
        //#line 39 "x10/io/StringWriter.x10"
        final x10.util.StringBuilder t$130567 = ((x10.util.StringBuilder)(this.b));
        
        //#line 39 "x10/io/StringWriter.x10"
        final java.lang.String t$130568 = t$130567.result();
        
        //#line 39 "x10/io/StringWriter.x10"
        return t$130568;
    }
    
    
    //#line 41 "x10/io/StringWriter.x10"
    public void flush() {
        
    }
    
    
    //#line 42 "x10/io/StringWriter.x10"
    public void close() {
        
    }
    
    
    //#line 16 "x10/io/StringWriter.x10"
    final public x10.io.StringWriter x10$io$StringWriter$$this$x10$io$StringWriter() {
        
        //#line 16 "x10/io/StringWriter.x10"
        return x10.io.StringWriter.this;
    }
    
    
    //#line 16 "x10/io/StringWriter.x10"
    final public void __fieldInitializers_x10_io_StringWriter() {
        
    }
}

