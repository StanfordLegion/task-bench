package x10.compiler;


/** An annotation that requests the compiler to...
 * EXPERIMENTAL
 */
@x10.runtime.impl.java.X10Generated
public interface NativeString extends x10.lang.annotations.ExpressionAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<NativeString> $RTT = 
        x10.rtt.NamedType.<NativeString> make("x10.compiler.NativeString",
                                              NativeString.class,
                                              new x10.rtt.Type[] {
                                                  x10.lang.annotations.ExpressionAnnotation.$RTT
                                              });
    
    
}

