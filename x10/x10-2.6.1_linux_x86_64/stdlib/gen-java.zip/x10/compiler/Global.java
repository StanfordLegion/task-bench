package x10.compiler;


/**
 * <p> The Global class annotation is used to support the Dual Class idiom: it
 * marks the class whose instances are proxy objects. The Global method annotation is used to 
 * support the Single Class idiom: it marks methods that are intended to be invoked on proxies.
 * 
 * <p> This method is not processed by any phase of the compiler at this time. 
 * It is intended to document programmer intent.
 * 
 * @see Pinned
 */
@x10.runtime.impl.java.X10Generated
public interface Global extends x10.lang.annotations.MethodAnnotation, x10.lang.annotations.ClassAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Global> $RTT = 
        x10.rtt.NamedType.<Global> make("x10.compiler.Global",
                                        Global.class,
                                        new x10.rtt.Type[] {
                                            x10.lang.annotations.MethodAnnotation.$RTT,
                                            x10.lang.annotations.ClassAnnotation.$RTT
                                        });
    
    
}

