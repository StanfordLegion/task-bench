package x10.compiler;


/** Annotation on a class that causes an additional C++ source file to be
 * postcompiled.  This is useful to support @Native code snippets that may
 * require additional code.  Multiple annotations can be given on a
 class and each will be included as postcompiler commandline arguments.  Has no
effect in the Java backend.
 */
@x10.runtime.impl.java.X10Generated
public interface NativeCPPCompilationUnit extends x10.lang.annotations.ClassAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<NativeCPPCompilationUnit> $RTT = 
        x10.rtt.NamedType.<NativeCPPCompilationUnit> make("x10.compiler.NativeCPPCompilationUnit",
                                                          NativeCPPCompilationUnit.class,
                                                          new x10.rtt.Type[] {
                                                              x10.lang.annotations.ClassAnnotation.$RTT
                                                          });
    
    
}

