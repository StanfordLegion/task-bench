package x10.compiler;


/**
 * This annotation is used to allow the programmer
 * to communicate to the compiler that the type for
 * the annotated method or field should not be
 * inferred (and must be specified explicitly).
 * This annotation is intended to be extended by
 * other annotations.</p>
 *
 * This annotation is processed by the X10 compiler's
 * type checker.
 */
@x10.runtime.impl.java.X10Generated
public interface NoInferType extends x10.lang.annotations.MethodAnnotation, x10.lang.annotations.FieldAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<NoInferType> $RTT = 
        x10.rtt.NamedType.<NoInferType> make("x10.compiler.NoInferType",
                                             NoInferType.class,
                                             new x10.rtt.Type[] {
                                                 x10.lang.annotations.MethodAnnotation.$RTT,
                                                 x10.lang.annotations.FieldAnnotation.$RTT
                                             });
    
    
}

