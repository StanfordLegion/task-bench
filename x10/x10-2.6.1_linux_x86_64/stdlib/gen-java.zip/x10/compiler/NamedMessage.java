package x10.compiler;


/**
 * <p> This annotation is used to provide explicit programmer
 * control over the name of the compiler-generated class
 * that is used to implement an X10-source level <code>at</code>. 
 * By allowing the programmer to specify the logical message name
 * assigned to a particular <code>'at'</code> expression or statement,
 * it allows name-stability of the message name across recompilations 
 * of the source file.</p>
 *
 * <p>It is the responsibility of the programmer who is using this 
 * annotation to ensure that the name is unique within the compilation
 * scope (currently an X10 class). Failure to ensure a unique name
 * will result in post-compilation failures due to multiple definitions
 * of the name in the generated code.</p>
 */
@x10.runtime.impl.java.X10Generated
public interface NamedMessage extends x10.compiler.RemoteInvocation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<NamedMessage> $RTT = 
        x10.rtt.NamedType.<NamedMessage> make("x10.compiler.NamedMessage",
                                              NamedMessage.class,
                                              new x10.rtt.Type[] {
                                                  x10.compiler.RemoteInvocation.$RTT
                                              });
    
    
}

