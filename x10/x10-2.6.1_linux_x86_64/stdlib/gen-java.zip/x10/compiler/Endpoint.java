package x10.compiler;


/**
 * Used to specify the target endpoint of an active message as in:
 * <code>
 * @Endpoint(endpoint) at (place) statement
 * </code>
 */
@x10.runtime.impl.java.X10Generated
public interface Endpoint extends x10.lang.annotations.ExpressionAnnotation, x10.lang.annotations.StatementAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Endpoint> $RTT = 
        x10.rtt.NamedType.<Endpoint> make("x10.compiler.Endpoint",
                                          Endpoint.class,
                                          new x10.rtt.Type[] {
                                              x10.lang.annotations.ExpressionAnnotation.$RTT,
                                              x10.lang.annotations.StatementAnnotation.$RTT
                                          });
    
    
}

