package x10.compiler;


/**
 * This annotation is used to mark a statement or method as determinate.

 * <p> This annotation is currently purely for documentation. Will be checked
 * in subsequent versions of the compiler.
 */
@x10.runtime.impl.java.X10Generated
public interface Det extends x10.lang.annotations.MethodAnnotation, x10.lang.annotations.StatementAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Det> $RTT = 
        x10.rtt.NamedType.<Det> make("x10.compiler.Det",
                                     Det.class,
                                     new x10.rtt.Type[] {
                                         x10.lang.annotations.MethodAnnotation.$RTT,
                                         x10.lang.annotations.StatementAnnotation.$RTT
                                     });
    
    
}

