package x10.compiler;


/**
 * This annotation indicates to the compiler that a field is volatile, with
 * consequences for back-end code generation.
 */
@x10.runtime.impl.java.X10Generated
public interface Volatile extends x10.lang.annotations.FieldAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Volatile> $RTT = 
        x10.rtt.NamedType.<Volatile> make("x10.compiler.Volatile",
                                          Volatile.class,
                                          new x10.rtt.Type[] {
                                              x10.lang.annotations.FieldAnnotation.$RTT
                                          });
    
    
}

