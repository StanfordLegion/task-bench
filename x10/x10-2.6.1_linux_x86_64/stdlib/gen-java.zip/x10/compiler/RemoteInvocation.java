package x10.compiler;


/**
 * This annotation is used internally by the runtime to mark
 * closures that will be used as parameters to runClosureAt methods.
 */
@x10.runtime.impl.java.X10Generated
public interface RemoteInvocation extends x10.compiler.NoInline, x10.lang.annotations.ExpressionAnnotation, x10.lang.annotations.StatementAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<RemoteInvocation> $RTT = 
        x10.rtt.NamedType.<RemoteInvocation> make("x10.compiler.RemoteInvocation",
                                                  RemoteInvocation.class,
                                                  new x10.rtt.Type[] {
                                                      x10.compiler.NoInline.$RTT,
                                                      x10.lang.annotations.ExpressionAnnotation.$RTT,
                                                      x10.lang.annotations.StatementAnnotation.$RTT
                                                  });
    
    
}

