package x10.compiler;


/**
 * Parallel iteration over a set of indices using different patterns of
 * local activity creation; this is intended to be used by the compiler to
 * implement the <code>foreach</code> construct.
 * <p>
 * The <code>body</code> closure is executed for each value of the index, 
 * making use of available local parallelism. The iteration must be both 
 * <em>serializable</em> and <em>parallelizable</em>; in other words, it is 
 * correct to execute <code>body</code> for each index in sequence, and it is 
 * also correct to execute <code>body</code> in parallel for any subset of 
 * indices.</p>
 * <p>There is an implied <code>finish</code> i.e. all iterations must complete
 * before <code>foreach</code> is complete.</p>
 * <p>Restrictions:</p>
 * <ul>
 * <li>A conditional atomic statement (<code>when</code>) may not be included 
 * as it could introduce ordering dependencies. Unconditional <code>atomic</code>
 * may be included as it cannot create an ordering dependency.</li>
 * <li>Changing place with <code>at</code> is not recommended as it may introduce
 * arbitrary delays.</p>
 * </ul>
 */
@x10.runtime.impl.java.X10Generated
final public class Foreach extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Foreach> $RTT = 
        x10.rtt.NamedType.<Foreach> make("x10.compiler.Foreach",
                                         Foreach.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.Foreach $_obj = new x10.compiler.Foreach((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public Foreach(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 50 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in sequence in a single activity.
     * This may be used for debugging purposes or as a compiler target where
     * there is no benefit to be gained from parallelizing an iteration.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     */
    public static void sequential__2$1x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_1<x10.core.Long> body) {
        
        //#line 52 "x10/compiler/Foreach.x10"
        long i$112689 = min;
        
        //#line 52 "x10/compiler/Foreach.x10"
        for (;
             true;
             ) {
            
            //#line 52 "x10/compiler/Foreach.x10"
            final boolean t$112691 = ((i$112689) <= (((long)(max))));
            
            //#line 52 "x10/compiler/Foreach.x10"
            if (!(t$112691)) {
                
                //#line 52 "x10/compiler/Foreach.x10"
                break;
            }
            
            //#line 52 "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_1<x10.core.Long>)body).$apply(x10.core.Long.$box(i$112689), x10.rtt.Types.LONG);
            
            //#line 52 "x10/compiler/Foreach.x10"
            final long t$112688 = ((i$112689) + (((long)(1L))));
            
            //#line 52 "x10/compiler/Foreach.x10"
            i$112689 = t$112688;
        }
    }
    
    
    //#line 63 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in sequence in a single activity.
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param body a closure that executes over a single value of the index [i,j]
     */
    public static void sequential__4$1x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 66 "x10/compiler/Foreach.x10"
        long i$112703 = min0;
        
        //#line 66 "x10/compiler/Foreach.x10"
        for (;
             true;
             ) {
            
            //#line 66 "x10/compiler/Foreach.x10"
            final boolean t$112705 = ((i$112703) <= (((long)(max0))));
            
            //#line 66 "x10/compiler/Foreach.x10"
            if (!(t$112705)) {
                
                //#line 66 "x10/compiler/Foreach.x10"
                break;
            }
            
            //#line 67 "x10/compiler/Foreach.x10"
            long i$112695 = min1;
            
            //#line 67 "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 67 "x10/compiler/Foreach.x10"
                final boolean t$112697 = ((i$112695) <= (((long)(max1))));
                
                //#line 67 "x10/compiler/Foreach.x10"
                if (!(t$112697)) {
                    
                    //#line 67 "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 68 "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$112703), x10.rtt.Types.LONG, x10.core.Long.$box(i$112695), x10.rtt.Types.LONG);
                
                //#line 67 "x10/compiler/Foreach.x10"
                final long t$112694 = ((i$112695) + (((long)(1L))));
                
                //#line 67 "x10/compiler/Foreach.x10"
                i$112695 = t$112694;
            }
            
            //#line 66 "x10/compiler/Foreach.x10"
            final long t$112702 = ((i$112703) + (((long)(1L))));
            
            //#line 66 "x10/compiler/Foreach.x10"
            i$112703 = t$112702;
        }
    }
    
    
    //#line 81 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in sequence in a single activity.
     * This may be used for debugging purposes or as a compiler target where
     * there is no benefit to be gained from parallelizing an iteration.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices
     */
    public static void sequential__2$1x10$lang$Long$3x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 83 "x10/compiler/Foreach.x10"
        ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG);
    }
    
    
    //#line 92 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a dense rectangular block of indices in single sequence in a
     * single activity.
     * @param space the 2D dense space over which to iterate
     * @param body a closure that executes over a single index [i,j]
     */
    public static void sequential__1$1x10$lang$Long$3x10$lang$Long$2(final x10.array.DenseIterationSpace_2 space, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 94 "x10/compiler/Foreach.x10"
        final long min$111378 = space.min0;
        
        //#line 94 "x10/compiler/Foreach.x10"
        final long max$111379 = space.max0;
        
        //#line 94 "x10/compiler/Foreach.x10"
        final long min$111380 = space.min1;
        
        //#line 94 "x10/compiler/Foreach.x10"
        final long max$111381 = space.max1;
        
        //#line 66 . "x10/compiler/Foreach.x10"
        long i$112717 = min$111378;
        
        //#line 66 . "x10/compiler/Foreach.x10"
        for (;
             true;
             ) {
            
            //#line 66 . "x10/compiler/Foreach.x10"
            final boolean t$112719 = ((i$112717) <= (((long)(max$111379))));
            
            //#line 66 . "x10/compiler/Foreach.x10"
            if (!(t$112719)) {
                
                //#line 66 . "x10/compiler/Foreach.x10"
                break;
            }
            
            //#line 67 . "x10/compiler/Foreach.x10"
            long i$112709 = min$111380;
            
            //#line 67 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 67 . "x10/compiler/Foreach.x10"
                final boolean t$112711 = ((i$112709) <= (((long)(max$111381))));
                
                //#line 67 . "x10/compiler/Foreach.x10"
                if (!(t$112711)) {
                    
                    //#line 67 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 68 . "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$112717), x10.rtt.Types.LONG, x10.core.Long.$box(i$112709), x10.rtt.Types.LONG);
                
                //#line 67 . "x10/compiler/Foreach.x10"
                final long t$112708 = ((i$112709) + (((long)(1L))));
                
                //#line 67 . "x10/compiler/Foreach.x10"
                i$112709 = t$112708;
            }
            
            //#line 66 . "x10/compiler/Foreach.x10"
            final long t$112716 = ((i$112717) + (((long)(1L))));
            
            //#line 66 . "x10/compiler/Foreach.x10"
            i$112717 = t$112716;
        }
    }
    
    
    //#line 105 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in sequence in a single activity.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T sequentialReduce__2$1x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__4x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 108 "x10/compiler/Foreach.x10"
        $T myRes = (($T)(identity));
        
        //#line 109 "x10/compiler/Foreach.x10"
        long i$112728 = min;
        
        //#line 109 "x10/compiler/Foreach.x10"
        for (;
             true;
             ) {
            
            //#line 109 "x10/compiler/Foreach.x10"
            final boolean t$112730 = ((i$112728) <= (((long)(max))));
            
            //#line 109 "x10/compiler/Foreach.x10"
            if (!(t$112730)) {
                
                //#line 109 "x10/compiler/Foreach.x10"
                break;
            }
            
            //#line 110 "x10/compiler/Foreach.x10"
            final $T t$112723 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$112728), x10.rtt.Types.LONG))));
            
            //#line 110 "x10/compiler/Foreach.x10"
            final $T t$112724 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes, $T, t$112723, $T))));
            
            //#line 110 "x10/compiler/Foreach.x10"
            myRes = (($T)(t$112724));
            
            //#line 109 "x10/compiler/Foreach.x10"
            final long t$112727 = ((i$112728) + (((long)(1L))));
            
            //#line 109 "x10/compiler/Foreach.x10"
            i$112728 = t$112727;
        }
        
        //#line 112 "x10/compiler/Foreach.x10"
        return myRes;
    }
    
    
    //#line 123 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in sequence in a single activity.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices, 
     *   returning the reduced value for that range
     * @param reduce the reduction operation
     */
    public static <$T>$T sequentialReduce__2$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        
        //#line 126 "x10/compiler/Foreach.x10"
        final $T t$111944 = (($T)((($T)
                                    ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG))));
        
        //#line 126 "x10/compiler/Foreach.x10"
        return t$111944;
    }
    
    
    //#line 136 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in sequence in a single activity.
     * @param space the 2D dense space over which to reduce
     * @param body a closure that executes over a single index [i,j]
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T sequentialReduce__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__2$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__3x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final x10.array.DenseIterationSpace_2 space, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 139 "x10/compiler/Foreach.x10"
        $T myRes = (($T)(identity));
        
        //#line 140 "x10/compiler/Foreach.x10"
        final long i$111091min$112750 = space.min0;
        
        //#line 140 "x10/compiler/Foreach.x10"
        final long i$111091max$112751 = space.max0;
        
        //#line 140 "x10/compiler/Foreach.x10"
        long i$112747 = i$111091min$112750;
        
        //#line 140 "x10/compiler/Foreach.x10"
        for (;
             true;
             ) {
            
            //#line 140 "x10/compiler/Foreach.x10"
            final boolean t$112749 = ((i$112747) <= (((long)(i$111091max$112751))));
            
            //#line 140 "x10/compiler/Foreach.x10"
            if (!(t$112749)) {
                
                //#line 140 "x10/compiler/Foreach.x10"
                break;
            }
            
            //#line 141 "x10/compiler/Foreach.x10"
            final long i$111073min$112742 = space.min1;
            
            //#line 141 "x10/compiler/Foreach.x10"
            final long i$111073max$112743 = space.max1;
            
            //#line 141 "x10/compiler/Foreach.x10"
            long i$112739 = i$111073min$112742;
            
            //#line 141 "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 141 "x10/compiler/Foreach.x10"
                final boolean t$112741 = ((i$112739) <= (((long)(i$111073max$112743))));
                
                //#line 141 "x10/compiler/Foreach.x10"
                if (!(t$112741)) {
                    
                    //#line 141 "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 142 "x10/compiler/Foreach.x10"
                final $T t$112734 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$112747), x10.rtt.Types.LONG, x10.core.Long.$box(i$112739), x10.rtt.Types.LONG))));
                
                //#line 142 "x10/compiler/Foreach.x10"
                final $T t$112735 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes, $T, t$112734, $T))));
                
                //#line 142 "x10/compiler/Foreach.x10"
                myRes = (($T)(t$112735));
                
                //#line 141 "x10/compiler/Foreach.x10"
                final long t$112738 = ((i$112739) + (((long)(1L))));
                
                //#line 141 "x10/compiler/Foreach.x10"
                i$112739 = t$112738;
            }
            
            //#line 140 "x10/compiler/Foreach.x10"
            final long t$112746 = ((i$112747) + (((long)(1L))));
            
            //#line 140 "x10/compiler/Foreach.x10"
            i$112747 = t$112746;
        }
        
        //#line 145 "x10/compiler/Foreach.x10"
        return myRes;
    }
    
    
    //#line 155 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using a basic async
     * transformation. A separate async is started for every index in min..max
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     */
    public static void basic__2$1x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_1<x10.core.Long> body) {
        
        //#line 157 "x10/compiler/Foreach.x10"
        final int t$111959 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 157 "x10/compiler/Foreach.x10"
        final boolean t$111970 = ((int) t$111959) == ((int) 1);
        
        //#line 157 "x10/compiler/Foreach.x10"
        if (t$111970) {
            
            //#line 52 . "x10/compiler/Foreach.x10"
            long i$112755 = min;
            
            //#line 52 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 52 . "x10/compiler/Foreach.x10"
                final boolean t$112757 = ((i$112755) <= (((long)(max))));
                
                //#line 52 . "x10/compiler/Foreach.x10"
                if (!(t$112757)) {
                    
                    //#line 52 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 52 . "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Long>)body).$apply(x10.core.Long.$box(i$112755), x10.rtt.Types.LONG);
                
                //#line 52 . "x10/compiler/Foreach.x10"
                final long t$112754 = ((i$112755) + (((long)(1L))));
                
                //#line 52 . "x10/compiler/Foreach.x10"
                i$112755 = t$112754;
            }
        } else {
            {
                
                //#line 160 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 160 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113503 = x10.xrx.Runtime.startFinish();
                
                //#line 160 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 160 "x10/compiler/Foreach.x10"
                        final long i$111109max$111111 = max;
                        
                        //#line 160 "x10/compiler/Foreach.x10"
                        long i$112763 = min;
                        
                        //#line 160 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 160 "x10/compiler/Foreach.x10"
                            final boolean t$112765 = ((i$112763) <= (((long)(i$111109max$111111))));
                            
                            //#line 160 "x10/compiler/Foreach.x10"
                            if (!(t$112765)) {
                                
                                //#line 160 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 160 "x10/compiler/Foreach.x10"
                            final long i$112760 = i$112763;
                            
                            //#line 160 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$22(body, i$112760, (x10.compiler.Foreach.$Closure$22.__0$1x10$lang$Long$2) null))));
                            
                            //#line 160 "x10/compiler/Foreach.x10"
                            final long t$112762 = ((i$112763) + (((long)(1L))));
                            
                            //#line 160 "x10/compiler/Foreach.x10"
                            i$112763 = t$112762;
                        }
                    }
                }}catch (java.lang.Throwable ct$113501) {
                    
                    //#line 160 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113501)));
                    
                    //#line 160 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 160 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113503)));
                 }}
                }
            }
        }
    
    
    //#line 172 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using a basic async
     * transformation. A separate async is started for every index in min..max
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param body a closure that executes over a single value of the index [i,j]
     */
    public static void basic__4$1x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 175 "x10/compiler/Foreach.x10"
        final int t$111971 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 175 "x10/compiler/Foreach.x10"
        final boolean t$111992 = ((int) t$111971) == ((int) 1);
        
        //#line 175 "x10/compiler/Foreach.x10"
        if (t$111992) {
            
            //#line 66 . "x10/compiler/Foreach.x10"
            long i$112777 = min0;
            
            //#line 66 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 66 . "x10/compiler/Foreach.x10"
                final boolean t$112779 = ((i$112777) <= (((long)(max0))));
                
                //#line 66 . "x10/compiler/Foreach.x10"
                if (!(t$112779)) {
                    
                    //#line 66 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 67 . "x10/compiler/Foreach.x10"
                long i$112769 = min1;
                
                //#line 67 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 67 . "x10/compiler/Foreach.x10"
                    final boolean t$112771 = ((i$112769) <= (((long)(max1))));
                    
                    //#line 67 . "x10/compiler/Foreach.x10"
                    if (!(t$112771)) {
                        
                        //#line 67 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 68 . "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$112777), x10.rtt.Types.LONG, x10.core.Long.$box(i$112769), x10.rtt.Types.LONG);
                    
                    //#line 67 . "x10/compiler/Foreach.x10"
                    final long t$112768 = ((i$112769) + (((long)(1L))));
                    
                    //#line 67 . "x10/compiler/Foreach.x10"
                    i$112769 = t$112768;
                }
                
                //#line 66 . "x10/compiler/Foreach.x10"
                final long t$112776 = ((i$112777) + (((long)(1L))));
                
                //#line 66 . "x10/compiler/Foreach.x10"
                i$112777 = t$112776;
            }
        } else {
            {
                
                //#line 178 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 178 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113509 = x10.xrx.Runtime.startFinish();
                
                //#line 178 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 178 "x10/compiler/Foreach.x10"
                        final long i$111145max$111147 = max0;
                        
                        //#line 178 "x10/compiler/Foreach.x10"
                        long i$112793 = min0;
                        
                        //#line 178 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 178 "x10/compiler/Foreach.x10"
                            final boolean t$112795 = ((i$112793) <= (((long)(i$111145max$111147))));
                            
                            //#line 178 "x10/compiler/Foreach.x10"
                            if (!(t$112795)) {
                                
                                //#line 178 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 178 "x10/compiler/Foreach.x10"
                            final long i$112790 = i$112793;
                            
                            //#line 179 "x10/compiler/Foreach.x10"
                            final long i$111127max$112789 = max1;
                            
                            //#line 179 "x10/compiler/Foreach.x10"
                            long i$112785 = min1;
                            
                            //#line 179 "x10/compiler/Foreach.x10"
                            for (;
                                 true;
                                 ) {
                                
                                //#line 179 "x10/compiler/Foreach.x10"
                                final boolean t$112787 = ((i$112785) <= (((long)(i$111127max$112789))));
                                
                                //#line 179 "x10/compiler/Foreach.x10"
                                if (!(t$112787)) {
                                    
                                    //#line 179 "x10/compiler/Foreach.x10"
                                    break;
                                }
                                
                                //#line 179 "x10/compiler/Foreach.x10"
                                final long j$112782 = i$112785;
                                
                                //#line 180 "x10/compiler/Foreach.x10"
                                x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$23(body, i$112790, j$112782, (x10.compiler.Foreach.$Closure$23.__0$1x10$lang$Long$3x10$lang$Long$2) null))));
                                
                                //#line 179 "x10/compiler/Foreach.x10"
                                final long t$112784 = ((i$112785) + (((long)(1L))));
                                
                                //#line 179 "x10/compiler/Foreach.x10"
                                i$112785 = t$112784;
                            }
                            
                            //#line 178 "x10/compiler/Foreach.x10"
                            final long t$112792 = ((i$112793) + (((long)(1L))));
                            
                            //#line 178 "x10/compiler/Foreach.x10"
                            i$112793 = t$112792;
                        }
                    }
                }}catch (java.lang.Throwable ct$113507) {
                    
                    //#line 178 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113507)));
                    
                    //#line 178 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 178 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113509)));
                 }}
                }
            }
        }
    
    
    //#line 195 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices
     */
    public static void block__2$1x10$lang$Long$3x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 197 "x10/compiler/Foreach.x10"
        final int nthreads = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 198 "x10/compiler/Foreach.x10"
        final boolean t$112013 = ((int) nthreads) == ((int) 1);
        
        //#line 198 "x10/compiler/Foreach.x10"
        if (t$112013) {
            
            //#line 83 . "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG);
        } else {
            
            //#line 201 "x10/compiler/Foreach.x10"
            final long t$111993 = ((max) - (((long)(min))));
            
            //#line 201 "x10/compiler/Foreach.x10"
            final long numElems = ((t$111993) + (((long)(1L))));
            
            //#line 202 "x10/compiler/Foreach.x10"
            final boolean t$111994 = ((numElems) < (((long)(1L))));
            
            //#line 202 "x10/compiler/Foreach.x10"
            if (t$111994) {
                
                //#line 202 "x10/compiler/Foreach.x10"
                return;
            }
            
            //#line 203 "x10/compiler/Foreach.x10"
            final long t$111995 = ((long)(((int)(nthreads))));
            
            //#line 203 "x10/compiler/Foreach.x10"
            final long blockSize = ((numElems) / (((long)(t$111995))));
            
            //#line 204 "x10/compiler/Foreach.x10"
            final long t$111996 = ((long)(((int)(nthreads))));
            
            //#line 204 "x10/compiler/Foreach.x10"
            final long t$111997 = ((t$111996) * (((long)(blockSize))));
            
            //#line 204 "x10/compiler/Foreach.x10"
            final long leftOver = ((numElems) - (((long)(t$111997))));
            {
                
                //#line 205 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 205 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113515 = x10.xrx.Runtime.startFinish();
                
                //#line 205 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 205 "x10/compiler/Foreach.x10"
                        final long t$111999 = ((long)(((int)(nthreads))));
                        
                        //#line 205 "x10/compiler/Foreach.x10"
                        long t = ((t$111999) - (((long)(1L))));
                        
                        //#line 205 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 205 "x10/compiler/Foreach.x10"
                            final boolean t$112012 = ((t) >= (((long)(0L))));
                            
                            //#line 205 "x10/compiler/Foreach.x10"
                            if (!(t$112012)) {
                                
                                //#line 205 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 206 "x10/compiler/Foreach.x10"
                            final long myT$112796 = t;
                            
                            //#line 207 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$24(blockSize, myT$112796, min, leftOver, body, (x10.compiler.Foreach.$Closure$24.__4$1x10$lang$Long$3x10$lang$Long$2) null))));
                            
                            //#line 205 "x10/compiler/Foreach.x10"
                            final long t$112809 = ((t) - (((long)(1L))));
                            
                            //#line 205 "x10/compiler/Foreach.x10"
                            t = t$112809;
                        }
                    }
                }}catch (java.lang.Throwable ct$113513) {
                    
                    //#line 205 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113513)));
                    
                    //#line 205 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 205 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113515)));
                 }}
                }
            }
        }
    
    
    //#line 225 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     */
    public static void block__2$1x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_1<x10.core.Long> body) {
        
        //#line 228 "x10/compiler/Foreach.x10"
        final long min$111426 = min;
        
        //#line 196 . "x10/compiler/Foreach.x10"
        __ret$111437: {
            
            //#line 197 . "x10/compiler/Foreach.x10"
            final int nthreads$111429 = x10.xrx.Runtime.get$NTHREADS();
            //#line 198 . "x10/compiler/Foreach.x10"
            final boolean t$112044 = ((int) nthreads$111429) == ((int) 1);
            //#line 198 . "x10/compiler/Foreach.x10"
            if (t$112044) {
                
                //#line 52 .... "x10/compiler/Foreach.x10"
                long i$112813 = min;
                
                //#line 52 .... "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 52 .... "x10/compiler/Foreach.x10"
                    final boolean t$112815 = ((i$112813) <= (((long)(max))));
                    
                    //#line 52 .... "x10/compiler/Foreach.x10"
                    if (!(t$112815)) {
                        
                        //#line 52 .... "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 52 .... "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_1<x10.core.Long>)body).$apply(x10.core.Long.$box(i$112813), x10.rtt.Types.LONG);
                    
                    //#line 52 .... "x10/compiler/Foreach.x10"
                    final long t$112812 = ((i$112813) + (((long)(1L))));
                    
                    //#line 52 .... "x10/compiler/Foreach.x10"
                    i$112813 = t$112812;
                }
            } else {
                
                //#line 201 . "x10/compiler/Foreach.x10"
                final long t$112019 = ((max) - (((long)(min))));
                
                //#line 201 . "x10/compiler/Foreach.x10"
                final long numElems$111430 = ((t$112019) + (((long)(1L))));
                
                //#line 202 . "x10/compiler/Foreach.x10"
                final boolean t$112020 = ((numElems$111430) < (((long)(1L))));
                
                //#line 202 . "x10/compiler/Foreach.x10"
                if (t$112020) {
                    
                    //#line 202 . "x10/compiler/Foreach.x10"
                    break __ret$111437;
                }
                
                //#line 203 . "x10/compiler/Foreach.x10"
                final long t$112021 = ((long)(((int)(nthreads$111429))));
                
                //#line 203 . "x10/compiler/Foreach.x10"
                final long blockSize$111431 = ((numElems$111430) / (((long)(t$112021))));
                
                //#line 204 . "x10/compiler/Foreach.x10"
                final long t$112022 = ((long)(((int)(nthreads$111429))));
                
                //#line 204 . "x10/compiler/Foreach.x10"
                final long t$112023 = ((t$112022) * (((long)(blockSize$111431))));
                
                //#line 204 . "x10/compiler/Foreach.x10"
                final long leftOver$111432 = ((numElems$111430) - (((long)(t$112023))));
                {
                    
                    //#line 205 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.ensureNotInAtomic();
                    
                    //#line 205 . "x10/compiler/Foreach.x10"
                    final x10.xrx.FinishState fs$113521 = x10.xrx.Runtime.startFinish();
                    
                    //#line 205 . "x10/compiler/Foreach.x10"
                    try {{
                        {
                            
                            //#line 205 . "x10/compiler/Foreach.x10"
                            final long t$112025 = ((long)(((int)(nthreads$111429))));
                            
                            //#line 205 . "x10/compiler/Foreach.x10"
                            long t$111433 = ((t$112025) - (((long)(1L))));
                            
                            //#line 205 . "x10/compiler/Foreach.x10"
                            for (;
                                 true;
                                 ) {
                                
                                //#line 205 . "x10/compiler/Foreach.x10"
                                final boolean t$112043 = ((t$111433) >= (((long)(0L))));
                                
                                //#line 205 . "x10/compiler/Foreach.x10"
                                if (!(t$112043)) {
                                    
                                    //#line 205 . "x10/compiler/Foreach.x10"
                                    break;
                                }
                                
                                //#line 206 . "x10/compiler/Foreach.x10"
                                final long myT$112834 = t$111433;
                                
                                //#line 207 . "x10/compiler/Foreach.x10"
                                x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$25(blockSize$111431, myT$112834, min$111426, leftOver$111432, body, (x10.compiler.Foreach.$Closure$25.__4$1x10$lang$Long$2) null))));
                                
                                //#line 205 . "x10/compiler/Foreach.x10"
                                final long t$112849 = ((t$111433) - (((long)(1L))));
                                
                                //#line 205 . "x10/compiler/Foreach.x10"
                                t$111433 = t$112849;
                            }
                        }
                    }}catch (java.lang.Throwable ct$113519) {
                        
                        //#line 205 . "x10/compiler/Foreach.x10"
                        x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113519)));
                        
                        //#line 205 . "x10/compiler/Foreach.x10"
                        throw new java.lang.RuntimeException();
                    }finally {{
                         
                         //#line 205 . "x10/compiler/Foreach.x10"
                         x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113521)));
                     }}
                    }
                }
            }
        }
    
    
    //#line 242 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices, 
     *   returning the reduced value for that range
     * @param reduce the reduction operation
     */
    public static <$T>$T blockReduce__2$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        
        //#line 245 "x10/compiler/Foreach.x10"
        final int nthreads = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 246 "x10/compiler/Foreach.x10"
        final boolean t$112079 = ((int) nthreads) == ((int) 1);
        
        //#line 246 "x10/compiler/Foreach.x10"
        if (t$112079) {
            
            //#line 247 "x10/compiler/Foreach.x10"
            final $T t$112045 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG))));
            
            //#line 247 "x10/compiler/Foreach.x10"
            return t$112045;
        } else {
            
            //#line 249 "x10/compiler/Foreach.x10"
            final long t$112046 = ((max) - (((long)(min))));
            
            //#line 249 "x10/compiler/Foreach.x10"
            final long numElems = ((t$112046) + (((long)(1L))));
            
            //#line 250 "x10/compiler/Foreach.x10"
            final boolean t$112048 = ((numElems) < (((long)(1L))));
            
            //#line 250 "x10/compiler/Foreach.x10"
            if (t$112048) {
                
                //#line 250 "x10/compiler/Foreach.x10"
                final $T t$112047 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG))));
                
                //#line 250 "x10/compiler/Foreach.x10"
                return t$112047;
            }
            
            //#line 251 "x10/compiler/Foreach.x10"
            final long t$112049 = ((long)(((int)(nthreads))));
            
            //#line 251 "x10/compiler/Foreach.x10"
            final long blockSize = ((numElems) / (((long)(t$112049))));
            
            //#line 252 "x10/compiler/Foreach.x10"
            final long t$112050 = ((long)(((int)(nthreads))));
            
            //#line 252 "x10/compiler/Foreach.x10"
            final long t$112051 = ((t$112050) * (((long)(blockSize))));
            
            //#line 252 "x10/compiler/Foreach.x10"
            final long leftOver = ((numElems) - (((long)(t$112051))));
            
            //#line 253 "x10/compiler/Foreach.x10"
            final long t$112052 = ((long)(((int)(nthreads))));
            
            //#line 253 "x10/compiler/Foreach.x10"
            final x10.core.Rail results = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$112052)), false)));
            {
                
                //#line 254 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 254 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113527 = x10.xrx.Runtime.startFinish();
                
                //#line 254 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 254 "x10/compiler/Foreach.x10"
                        final long t$112054 = ((long)(((int)(nthreads))));
                        
                        //#line 254 "x10/compiler/Foreach.x10"
                        long t = ((t$112054) - (((long)(1L))));
                        
                        //#line 254 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 254 "x10/compiler/Foreach.x10"
                            final boolean t$112068 = ((t) >= (((long)(0L))));
                            
                            //#line 254 "x10/compiler/Foreach.x10"
                            if (!(t$112068)) {
                                
                                //#line 254 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 255 "x10/compiler/Foreach.x10"
                            final long myT$112850 = t;
                            
                            //#line 256 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$26<$T>($T, blockSize, myT$112850, min, leftOver, body, results, (x10.compiler.Foreach.$Closure$26.__4$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$26$$T$2__5$1x10$compiler$Foreach$$Closure$26$$T$2) null))));
                            
                            //#line 254 "x10/compiler/Foreach.x10"
                            final long t$112864 = ((t) - (((long)(1L))));
                            
                            //#line 254 "x10/compiler/Foreach.x10"
                            t = t$112864;
                        }
                    }
                }}catch (java.lang.Throwable ct$113525) {
                    
                    //#line 254 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113525)));
                    
                    //#line 254 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 254 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113527)));
                 }}
                }
            
            //#line 262 "x10/compiler/Foreach.x10"
            $T res = (($T)(((x10.core.Rail<$T>)results).$apply$G((long)(0L))));
            
            //#line 263 "x10/compiler/Foreach.x10"
            final long t$112874 = ((long)(((int)(nthreads))));
            
            //#line 263 "x10/compiler/Foreach.x10"
            final long i$111163max$112875 = ((t$112874) - (((long)(1L))));
            
            //#line 263 "x10/compiler/Foreach.x10"
            long i$112871 = 1L;
            
            //#line 263 "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 263 "x10/compiler/Foreach.x10"
                final boolean t$112873 = ((i$112871) <= (((long)(i$111163max$112875))));
                
                //#line 263 "x10/compiler/Foreach.x10"
                if (!(t$112873)) {
                    
                    //#line 263 "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 264 "x10/compiler/Foreach.x10"
                final $T t$112866 = (($T)(((x10.core.Rail<$T>)results).$apply$G((long)(i$112871))));
                
                //#line 264 "x10/compiler/Foreach.x10"
                final $T t$112867 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(res, $T, t$112866, $T))));
                
                //#line 264 "x10/compiler/Foreach.x10"
                res = (($T)(t$112867));
                
                //#line 263 "x10/compiler/Foreach.x10"
                final long t$112870 = ((i$112871) + (((long)(1L))));
                
                //#line 263 "x10/compiler/Foreach.x10"
                i$112871 = t$112870;
            }
            
            //#line 266 "x10/compiler/Foreach.x10"
            return res;
            }
        }
    
    
    //#line 281 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T blockReduce__2$1x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__4x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 292 "x10/compiler/Foreach.x10"
        final long min$111464 = min;
        
        //#line 292 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 reduce$111467 = ((x10.core.fun.Fun_0_2)(reduce));
        
        //#line 242 . "x10/compiler/Foreach.x10"
        $T ret$111482 =  null;
        
        //#line 244 . "x10/compiler/Foreach.x10"
        __ret$111483: {
            
            //#line 245 . "x10/compiler/Foreach.x10"
            final int nthreads$111468 = x10.xrx.Runtime.get$NTHREADS();
            //#line 246 . "x10/compiler/Foreach.x10"
            final boolean t$112138 = ((int) nthreads$111468) == ((int) 1);
            //#line 246 . "x10/compiler/Foreach.x10"
            if (t$112138) {
                
                //#line 285 .. "x10/compiler/Foreach.x10"
                $T myRes$111486 = (($T)(identity));
                
                //#line 286 .. "x10/compiler/Foreach.x10"
                long i$112882 = min;
                
                //#line 286 .. "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    final boolean t$112884 = ((i$112882) <= (((long)(max))));
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    if (!(t$112884)) {
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 287 .. "x10/compiler/Foreach.x10"
                    final $T t$112877 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$112882), x10.rtt.Types.LONG))));
                    
                    //#line 287 .. "x10/compiler/Foreach.x10"
                    final $T t$112878 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$111486, $T, t$112877, $T))));
                    
                    //#line 287 .. "x10/compiler/Foreach.x10"
                    myRes$111486 = (($T)(t$112878));
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    final long t$112881 = ((i$112882) + (((long)(1L))));
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    i$112882 = t$112881;
                }
                
                //#line 247 . "x10/compiler/Foreach.x10"
                ret$111482 = (($T)(myRes$111486));
                
                //#line 247 . "x10/compiler/Foreach.x10"
                break __ret$111483;
            } else {
                
                //#line 249 . "x10/compiler/Foreach.x10"
                final long t$112089 = ((max) - (((long)(min))));
                
                //#line 249 . "x10/compiler/Foreach.x10"
                final long numElems$111469 = ((t$112089) + (((long)(1L))));
                
                //#line 250 . "x10/compiler/Foreach.x10"
                final boolean t$112099 = ((numElems$111469) < (((long)(1L))));
                
                //#line 250 . "x10/compiler/Foreach.x10"
                if (t$112099) {
                    
                    //#line 285 .. "x10/compiler/Foreach.x10"
                    $T myRes$111494 = (($T)(identity));
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    long i$112893 = min;
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        final boolean t$112895 = ((i$112893) <= (((long)(max))));
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        if (!(t$112895)) {
                            
                            //#line 286 .. "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 287 .. "x10/compiler/Foreach.x10"
                        final $T t$112888 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$112893), x10.rtt.Types.LONG))));
                        
                        //#line 287 .. "x10/compiler/Foreach.x10"
                        final $T t$112889 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$111494, $T, t$112888, $T))));
                        
                        //#line 287 .. "x10/compiler/Foreach.x10"
                        myRes$111494 = (($T)(t$112889));
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        final long t$112892 = ((i$112893) + (((long)(1L))));
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        i$112893 = t$112892;
                    }
                    
                    //#line 250 . "x10/compiler/Foreach.x10"
                    ret$111482 = (($T)(myRes$111494));
                    
                    //#line 250 . "x10/compiler/Foreach.x10"
                    break __ret$111483;
                }
                
                //#line 251 . "x10/compiler/Foreach.x10"
                final long t$112100 = ((long)(((int)(nthreads$111468))));
                
                //#line 251 . "x10/compiler/Foreach.x10"
                final long blockSize$111470 = ((numElems$111469) / (((long)(t$112100))));
                
                //#line 252 . "x10/compiler/Foreach.x10"
                final long t$112101 = ((long)(((int)(nthreads$111468))));
                
                //#line 252 . "x10/compiler/Foreach.x10"
                final long t$112102 = ((t$112101) * (((long)(blockSize$111470))));
                
                //#line 252 . "x10/compiler/Foreach.x10"
                final long leftOver$111471 = ((numElems$111469) - (((long)(t$112102))));
                
                //#line 253 . "x10/compiler/Foreach.x10"
                final long t$112103 = ((long)(((int)(nthreads$111468))));
                
                //#line 253 . "x10/compiler/Foreach.x10"
                final x10.core.Rail results$111472 = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$112103)), false)));
                {
                    
                    //#line 254 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.ensureNotInAtomic();
                    
                    //#line 254 . "x10/compiler/Foreach.x10"
                    final x10.xrx.FinishState fs$113533 = x10.xrx.Runtime.startFinish();
                    
                    //#line 254 . "x10/compiler/Foreach.x10"
                    try {{
                        {
                            
                            //#line 254 . "x10/compiler/Foreach.x10"
                            final long t$112105 = ((long)(((int)(nthreads$111468))));
                            
                            //#line 254 . "x10/compiler/Foreach.x10"
                            long t$111473 = ((t$112105) - (((long)(1L))));
                            
                            //#line 254 . "x10/compiler/Foreach.x10"
                            for (;
                                 true;
                                 ) {
                                
                                //#line 254 . "x10/compiler/Foreach.x10"
                                final boolean t$112127 = ((t$111473) >= (((long)(0L))));
                                
                                //#line 254 . "x10/compiler/Foreach.x10"
                                if (!(t$112127)) {
                                    
                                    //#line 254 . "x10/compiler/Foreach.x10"
                                    break;
                                }
                                
                                //#line 255 . "x10/compiler/Foreach.x10"
                                final long myT$112909 = t$111473;
                                
                                //#line 256 . "x10/compiler/Foreach.x10"
                                x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$27<$T>($T, blockSize$111470, myT$112909, min$111464, leftOver$111471, identity, body, reduce, results$111472, (x10.compiler.Foreach.$Closure$27.$_9021ff2d) null))));
                                
                                //#line 254 . "x10/compiler/Foreach.x10"
                                final long t$112926 = ((t$111473) - (((long)(1L))));
                                
                                //#line 254 . "x10/compiler/Foreach.x10"
                                t$111473 = t$112926;
                            }
                        }
                    }}catch (java.lang.Throwable ct$113531) {
                        
                        //#line 254 . "x10/compiler/Foreach.x10"
                        x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113531)));
                        
                        //#line 254 . "x10/compiler/Foreach.x10"
                        throw new java.lang.RuntimeException();
                    }finally {{
                         
                         //#line 254 . "x10/compiler/Foreach.x10"
                         x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113533)));
                     }}
                    }
                
                //#line 262 . "x10/compiler/Foreach.x10"
                $T res$111477 = (($T)(((x10.core.Rail<$T>)results$111472).$apply$G((long)(0L))));
                
                //#line 263 . "x10/compiler/Foreach.x10"
                final long t$112936 = ((long)(((int)(nthreads$111468))));
                
                //#line 263 . "x10/compiler/Foreach.x10"
                final long i$111163max$112937 = ((t$112936) - (((long)(1L))));
                
                //#line 263 . "x10/compiler/Foreach.x10"
                long i$112933 = 1L;
                
                //#line 263 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 263 . "x10/compiler/Foreach.x10"
                    final boolean t$112935 = ((i$112933) <= (((long)(i$111163max$112937))));
                    
                    //#line 263 . "x10/compiler/Foreach.x10"
                    if (!(t$112935)) {
                        
                        //#line 263 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 264 . "x10/compiler/Foreach.x10"
                    final $T t$112928 = (($T)(((x10.core.Rail<$T>)results$111472).$apply$G((long)(i$112933))));
                    
                    //#line 264 . "x10/compiler/Foreach.x10"
                    final $T t$112929 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce$111467).$apply(res$111477, $T, t$112928, $T))));
                    
                    //#line 264 . "x10/compiler/Foreach.x10"
                    res$111477 = (($T)(t$112929));
                    
                    //#line 263 . "x10/compiler/Foreach.x10"
                    final long t$112932 = ((i$112933) + (((long)(1L))));
                    
                    //#line 263 . "x10/compiler/Foreach.x10"
                    i$112933 = t$112932;
                }
                
                //#line 266 . "x10/compiler/Foreach.x10"
                ret$111482 = (($T)(res$111477));
                
                //#line 266 . "x10/compiler/Foreach.x10"
                break __ret$111483;
                }
            }
        
        //#line 292 "x10/compiler/Foreach.x10"
        return ret$111482;
        }
    
    
    //#line 306 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param body a closure that executes over a single index [i,j]
     */
    public static void block__4$1x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 309 "x10/compiler/Foreach.x10"
        final x10.array.DenseIterationSpace_2 alloc$110998 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 309 "x10/compiler/Foreach.x10"
        alloc$110998.x10$array$DenseIterationSpace_2$$init$S(((long)(min0)), ((long)(min1)), ((long)(max0)), ((long)(max1)));
        
        //#line 309 "x10/compiler/Foreach.x10"
        final x10.array.DenseIterationSpace_2 space$111508 = ((x10.array.DenseIterationSpace_2)(alloc$110998));
        
        //#line 309 "x10/compiler/Foreach.x10"
        final x10.core.fun.VoidFun_0_2 body$111509 = ((x10.core.fun.VoidFun_0_2)(body));
        
        //#line 323 . "x10/compiler/Foreach.x10"
        final int t$112988 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 323 . "x10/compiler/Foreach.x10"
        final boolean t$112989 = ((int) t$112988) == ((int) 1);
        
        //#line 323 . "x10/compiler/Foreach.x10"
        if (t$112989) {
            
            //#line 94 .. "x10/compiler/Foreach.x10"
            final long min$112954 = alloc$110998.min0;
            
            //#line 94 .. "x10/compiler/Foreach.x10"
            final long max$112955 = alloc$110998.max0;
            
            //#line 94 .. "x10/compiler/Foreach.x10"
            final long min$112956 = alloc$110998.min1;
            
            //#line 94 .. "x10/compiler/Foreach.x10"
            final long max$112957 = alloc$110998.max1;
            
            //#line 66 ... "x10/compiler/Foreach.x10"
            long i$112949 = min$112954;
            
            //#line 66 ... "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 66 ... "x10/compiler/Foreach.x10"
                final boolean t$112951 = ((i$112949) <= (((long)(max$112955))));
                
                //#line 66 ... "x10/compiler/Foreach.x10"
                if (!(t$112951)) {
                    
                    //#line 66 ... "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 67 ... "x10/compiler/Foreach.x10"
                long i$112941 = min$112956;
                
                //#line 67 ... "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 67 ... "x10/compiler/Foreach.x10"
                    final boolean t$112943 = ((i$112941) <= (((long)(max$112957))));
                    
                    //#line 67 ... "x10/compiler/Foreach.x10"
                    if (!(t$112943)) {
                        
                        //#line 67 ... "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 68 ... "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$112949), x10.rtt.Types.LONG, x10.core.Long.$box(i$112941), x10.rtt.Types.LONG);
                    
                    //#line 67 ... "x10/compiler/Foreach.x10"
                    final long t$112940 = ((i$112941) + (((long)(1L))));
                    
                    //#line 67 ... "x10/compiler/Foreach.x10"
                    i$112941 = t$112940;
                }
                
                //#line 66 ... "x10/compiler/Foreach.x10"
                final long t$112948 = ((i$112949) + (((long)(1L))));
                
                //#line 66 ... "x10/compiler/Foreach.x10"
                i$112949 = t$112948;
            }
        } else {
            {
                
                //#line 326 . "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 326 . "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113539 = x10.xrx.Runtime.startFinish();
                
                //#line 326 . "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 326 . "x10/compiler/Foreach.x10"
                        final int t$112992 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 326 . "x10/compiler/Foreach.x10"
                        final long t$112993 = ((long)(((int)(t$112992))));
                        
                        //#line 326 . "x10/compiler/Foreach.x10"
                        long t$112994 = ((t$112993) - (((long)(1L))));
                        
                        //#line 326 . "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 326 . "x10/compiler/Foreach.x10"
                            final boolean t$112996 = ((t$112994) >= (((long)(0L))));
                            
                            //#line 326 . "x10/compiler/Foreach.x10"
                            if (!(t$112996)) {
                                
                                //#line 326 . "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 327 . "x10/compiler/Foreach.x10"
                            final long myT$112980 = t$112994;
                            
                            //#line 328 . "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$28(space$111508, myT$112980, body$111509, (x10.compiler.Foreach.$Closure$28.__2$1x10$lang$Long$3x10$lang$Long$2) null))));
                            
                            //#line 326 . "x10/compiler/Foreach.x10"
                            final long t$112987 = ((t$112994) - (((long)(1L))));
                            
                            //#line 326 . "x10/compiler/Foreach.x10"
                            t$112994 = t$112987;
                        }
                    }
                }}catch (java.lang.Throwable ct$113537) {
                    
                    //#line 326 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113537)));
                    
                    //#line 326 . "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 326 . "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113539)));
                 }}
                }
            }
        }
    
    
    //#line 321 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a dense rectangular block of indices in parallel using
     * a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param space the 2D dense space over which to iterate
     * @param body a closure that executes over a single index [i,j]
     */
    public static void block__1$1x10$lang$Long$3x10$lang$Long$2(final x10.array.DenseIterationSpace_2 space, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 323 "x10/compiler/Foreach.x10"
        final int t$112171 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 323 "x10/compiler/Foreach.x10"
        final boolean t$112201 = ((int) t$112171) == ((int) 1);
        
        //#line 323 "x10/compiler/Foreach.x10"
        if (t$112201) {
            
            //#line 94 . "x10/compiler/Foreach.x10"
            final long min$113013 = space.min0;
            
            //#line 94 . "x10/compiler/Foreach.x10"
            final long max$113014 = space.max0;
            
            //#line 94 . "x10/compiler/Foreach.x10"
            final long min$113015 = space.min1;
            
            //#line 94 . "x10/compiler/Foreach.x10"
            final long max$113016 = space.max1;
            
            //#line 66 .. "x10/compiler/Foreach.x10"
            long i$113008 = min$113013;
            
            //#line 66 .. "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 66 .. "x10/compiler/Foreach.x10"
                final boolean t$113010 = ((i$113008) <= (((long)(max$113014))));
                
                //#line 66 .. "x10/compiler/Foreach.x10"
                if (!(t$113010)) {
                    
                    //#line 66 .. "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 67 .. "x10/compiler/Foreach.x10"
                long i$113000 = min$113015;
                
                //#line 67 .. "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 67 .. "x10/compiler/Foreach.x10"
                    final boolean t$113002 = ((i$113000) <= (((long)(max$113016))));
                    
                    //#line 67 .. "x10/compiler/Foreach.x10"
                    if (!(t$113002)) {
                        
                        //#line 67 .. "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 68 .. "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$113008), x10.rtt.Types.LONG, x10.core.Long.$box(i$113000), x10.rtt.Types.LONG);
                    
                    //#line 67 .. "x10/compiler/Foreach.x10"
                    final long t$112999 = ((i$113000) + (((long)(1L))));
                    
                    //#line 67 .. "x10/compiler/Foreach.x10"
                    i$113000 = t$112999;
                }
                
                //#line 66 .. "x10/compiler/Foreach.x10"
                final long t$113007 = ((i$113008) + (((long)(1L))));
                
                //#line 66 .. "x10/compiler/Foreach.x10"
                i$113008 = t$113007;
            }
        } else {
            {
                
                //#line 326 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 326 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113545 = x10.xrx.Runtime.startFinish();
                
                //#line 326 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 326 "x10/compiler/Foreach.x10"
                        final int t$112183 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 326 "x10/compiler/Foreach.x10"
                        final long t$112184 = ((long)(((int)(t$112183))));
                        
                        //#line 326 "x10/compiler/Foreach.x10"
                        long t = ((t$112184) - (((long)(1L))));
                        
                        //#line 326 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 326 "x10/compiler/Foreach.x10"
                            final boolean t$112200 = ((t) >= (((long)(0L))));
                            
                            //#line 326 "x10/compiler/Foreach.x10"
                            if (!(t$112200)) {
                                
                                //#line 326 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 327 "x10/compiler/Foreach.x10"
                            final long myT$113039 = t;
                            
                            //#line 328 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$29(space, myT$113039, body, (x10.compiler.Foreach.$Closure$29.__2$1x10$lang$Long$3x10$lang$Long$2) null))));
                            
                            //#line 326 "x10/compiler/Foreach.x10"
                            final long t$113046 = ((t) - (((long)(1L))));
                            
                            //#line 326 "x10/compiler/Foreach.x10"
                            t = t$113046;
                        }
                    }
                }}catch (java.lang.Throwable ct$113543) {
                    
                    //#line 326 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113543)));
                    
                    //#line 326 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 326 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113545)));
                 }}
                }
            }
        }
    
    
    //#line 346 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param space the 2D dense space over which to reduce
     * @param body a closure that executes over a single index [i,j]
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T blockReduce__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__2$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__3x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final x10.array.DenseIterationSpace_2 space, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 349 "x10/compiler/Foreach.x10"
        final int t$112202 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 349 "x10/compiler/Foreach.x10"
        final boolean t$112253 = ((int) t$112202) == ((int) 1);
        
        //#line 349 "x10/compiler/Foreach.x10"
        if (t$112253) {
            
            //#line 139 . "x10/compiler/Foreach.x10"
            $T myRes$111586 = (($T)(identity));
            
            //#line 140 . "x10/compiler/Foreach.x10"
            final long i$111091min$113064 = space.min0;
            
            //#line 140 . "x10/compiler/Foreach.x10"
            final long i$111091max$113065 = space.max0;
            
            //#line 140 . "x10/compiler/Foreach.x10"
            long i$113061 = i$111091min$113064;
            
            //#line 140 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 140 . "x10/compiler/Foreach.x10"
                final boolean t$113063 = ((i$113061) <= (((long)(i$111091max$113065))));
                
                //#line 140 . "x10/compiler/Foreach.x10"
                if (!(t$113063)) {
                    
                    //#line 140 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 141 . "x10/compiler/Foreach.x10"
                final long i$111073min$113056 = space.min1;
                
                //#line 141 . "x10/compiler/Foreach.x10"
                final long i$111073max$113057 = space.max1;
                
                //#line 141 . "x10/compiler/Foreach.x10"
                long i$113053 = i$111073min$113056;
                
                //#line 141 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    final boolean t$113055 = ((i$113053) <= (((long)(i$111073max$113057))));
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    if (!(t$113055)) {
                        
                        //#line 141 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 142 . "x10/compiler/Foreach.x10"
                    final $T t$113048 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113061), x10.rtt.Types.LONG, x10.core.Long.$box(i$113053), x10.rtt.Types.LONG))));
                    
                    //#line 142 . "x10/compiler/Foreach.x10"
                    final $T t$113049 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$111586, $T, t$113048, $T))));
                    
                    //#line 142 . "x10/compiler/Foreach.x10"
                    myRes$111586 = (($T)(t$113049));
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    final long t$113052 = ((i$113053) + (((long)(1L))));
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    i$113053 = t$113052;
                }
                
                //#line 140 . "x10/compiler/Foreach.x10"
                final long t$113060 = ((i$113061) + (((long)(1L))));
                
                //#line 140 . "x10/compiler/Foreach.x10"
                i$113061 = t$113060;
            }
            
            //#line 350 "x10/compiler/Foreach.x10"
            return myRes$111586;
        } else {
            
            //#line 352 "x10/compiler/Foreach.x10"
            final int t$112217 = x10.xrx.Runtime.get$NTHREADS();
            
            //#line 352 "x10/compiler/Foreach.x10"
            final long t$112218 = ((long)(((int)(t$112217))));
            
            //#line 352 "x10/compiler/Foreach.x10"
            final x10.core.Rail results = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$112218)), false)));
            {
                
                //#line 353 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 353 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113551 = x10.xrx.Runtime.startFinish();
                
                //#line 353 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 353 "x10/compiler/Foreach.x10"
                        final int t$112220 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 353 "x10/compiler/Foreach.x10"
                        final long t$112221 = ((long)(((int)(t$112220))));
                        
                        //#line 353 "x10/compiler/Foreach.x10"
                        long t = ((t$112221) - (((long)(1L))));
                        
                        //#line 353 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 353 "x10/compiler/Foreach.x10"
                            final boolean t$112241 = ((t) >= (((long)(0L))));
                            
                            //#line 353 "x10/compiler/Foreach.x10"
                            if (!(t$112241)) {
                                
                                //#line 353 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 354 "x10/compiler/Foreach.x10"
                            final long myT$113085 = t;
                            
                            //#line 355 "x10/compiler/Foreach.x10"
                            final int t$113086 = x10.xrx.Runtime.get$NTHREADS();
                            
                            //#line 355 "x10/compiler/Foreach.x10"
                            final long t$113087 = ((long)(((int)(t$113086))));
                            
                            //#line 355 "x10/compiler/Foreach.x10"
                            final x10.array.DenseIterationSpace_2 block$113088 = ((x10.array.DenseIterationSpace_2)(x10.array.BlockingUtils.partitionBlockBlock(((x10.array.IterationSpace)(space)), (long)(t$113087), (long)(t))));
                            
                            //#line 356 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$30<$T>($T, identity, block$113088, body, reduce, results, myT$113085, (x10.compiler.Foreach.$Closure$30.$_273ec00a) null))));
                            
                            //#line 353 "x10/compiler/Foreach.x10"
                            final long t$113096 = ((t) - (((long)(1L))));
                            
                            //#line 353 "x10/compiler/Foreach.x10"
                            t = t$113096;
                        }
                    }
                }}catch (java.lang.Throwable ct$113549) {
                    
                    //#line 353 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113549)));
                    
                    //#line 353 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 353 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113551)));
                 }}
                }
            
            //#line 358 "x10/compiler/Foreach.x10"
            $T res = (($T)(((x10.core.Rail<$T>)results).$apply$G((long)(0L))));
            
            //#line 359 "x10/compiler/Foreach.x10"
            final int t$113106 = x10.xrx.Runtime.get$NTHREADS();
            
            //#line 359 "x10/compiler/Foreach.x10"
            final long t$113107 = ((long)(((int)(t$113106))));
            
            //#line 359 "x10/compiler/Foreach.x10"
            final long i$111199max$113108 = ((t$113107) - (((long)(1L))));
            
            //#line 359 "x10/compiler/Foreach.x10"
            long i$113103 = 1L;
            
            //#line 359 "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 359 "x10/compiler/Foreach.x10"
                final boolean t$113105 = ((i$113103) <= (((long)(i$111199max$113108))));
                
                //#line 359 "x10/compiler/Foreach.x10"
                if (!(t$113105)) {
                    
                    //#line 359 "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 360 "x10/compiler/Foreach.x10"
                final $T t$113098 = (($T)(((x10.core.Rail<$T>)results).$apply$G((long)(i$113103))));
                
                //#line 360 "x10/compiler/Foreach.x10"
                final $T t$113099 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(res, $T, t$113098, $T))));
                
                //#line 360 "x10/compiler/Foreach.x10"
                res = (($T)(t$113099));
                
                //#line 359 "x10/compiler/Foreach.x10"
                final long t$113102 = ((i$113103) + (((long)(1L))));
                
                //#line 359 "x10/compiler/Foreach.x10"
                i$113103 = t$113102;
            }
            
            //#line 362 "x10/compiler/Foreach.x10"
            return res;
            }
        }
    
    
    //#line 375 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using a cyclic decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Given T=Runtime.NTHREADS, activity for thread number 
     * <code>t</code> executes iterations (t, t+T, t+2 &times; T, ...).
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     */
    public static void cyclic__2$1x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_1<x10.core.Long> body) {
        
        //#line 377 "x10/compiler/Foreach.x10"
        final int t$112254 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 377 "x10/compiler/Foreach.x10"
        final boolean t$112275 = ((int) t$112254) == ((int) 1);
        
        //#line 377 "x10/compiler/Foreach.x10"
        if (t$112275) {
            
            //#line 52 . "x10/compiler/Foreach.x10"
            long i$113112 = min;
            
            //#line 52 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 52 . "x10/compiler/Foreach.x10"
                final boolean t$113114 = ((i$113112) <= (((long)(max))));
                
                //#line 52 . "x10/compiler/Foreach.x10"
                if (!(t$113114)) {
                    
                    //#line 52 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 52 . "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Long>)body).$apply(x10.core.Long.$box(i$113112), x10.rtt.Types.LONG);
                
                //#line 52 . "x10/compiler/Foreach.x10"
                final long t$113111 = ((i$113112) + (((long)(1L))));
                
                //#line 52 . "x10/compiler/Foreach.x10"
                i$113112 = t$113111;
            }
        } else {
            {
                
                //#line 380 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 380 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113557 = x10.xrx.Runtime.startFinish();
                
                //#line 380 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 380 "x10/compiler/Foreach.x10"
                        final int t$112260 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 380 "x10/compiler/Foreach.x10"
                        final long t$112261 = ((long)(((int)(t$112260))));
                        
                        //#line 380 "x10/compiler/Foreach.x10"
                        final long i$111217max$111219 = ((t$112261) - (((long)(1L))));
                        
                        //#line 380 "x10/compiler/Foreach.x10"
                        long i$113128 = 0L;
                        
                        //#line 380 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 380 "x10/compiler/Foreach.x10"
                            final boolean t$113130 = ((i$113128) <= (((long)(i$111217max$111219))));
                            
                            //#line 380 "x10/compiler/Foreach.x10"
                            if (!(t$113130)) {
                                
                                //#line 380 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 380 "x10/compiler/Foreach.x10"
                            final long t$113125 = i$113128;
                            
                            //#line 380 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$31(min, t$113125, max, body, (x10.compiler.Foreach.$Closure$31.__3$1x10$lang$Long$2) null))));
                            
                            //#line 380 "x10/compiler/Foreach.x10"
                            final long t$113127 = ((i$113128) + (((long)(1L))));
                            
                            //#line 380 "x10/compiler/Foreach.x10"
                            i$113128 = t$113127;
                        }
                    }
                }}catch (java.lang.Throwable ct$113555) {
                    
                    //#line 380 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113555)));
                    
                    //#line 380 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 380 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113557)));
                 }}
                }
            }
        }
    
    
    //#line 399 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using a cyclic decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Given T=Runtime.NTHREADS, activity for thread number 
     * <code>t</code> executes iterations (t, t+T, t+2 &times; T, ...).
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T cyclicReduce__2$1x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__4x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 402 "x10/compiler/Foreach.x10"
        final int t$112276 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 402 "x10/compiler/Foreach.x10"
        final boolean t$112318 = ((int) t$112276) == ((int) 1);
        
        //#line 402 "x10/compiler/Foreach.x10"
        if (t$112318) {
            
            //#line 108 . "x10/compiler/Foreach.x10"
            $T myRes$111623 = (($T)(identity));
            
            //#line 109 . "x10/compiler/Foreach.x10"
            long i$113137 = min;
            
            //#line 109 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 109 . "x10/compiler/Foreach.x10"
                final boolean t$113139 = ((i$113137) <= (((long)(max))));
                
                //#line 109 . "x10/compiler/Foreach.x10"
                if (!(t$113139)) {
                    
                    //#line 109 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 110 . "x10/compiler/Foreach.x10"
                final $T t$113132 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113137), x10.rtt.Types.LONG))));
                
                //#line 110 . "x10/compiler/Foreach.x10"
                final $T t$113133 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$111623, $T, t$113132, $T))));
                
                //#line 110 . "x10/compiler/Foreach.x10"
                myRes$111623 = (($T)(t$113133));
                
                //#line 109 . "x10/compiler/Foreach.x10"
                final long t$113136 = ((i$113137) + (((long)(1L))));
                
                //#line 109 . "x10/compiler/Foreach.x10"
                i$113137 = t$113136;
            }
            
            //#line 403 "x10/compiler/Foreach.x10"
            return myRes$111623;
        } else {
            
            //#line 405 "x10/compiler/Foreach.x10"
            final int t$112286 = x10.xrx.Runtime.get$NTHREADS();
            
            //#line 405 "x10/compiler/Foreach.x10"
            final long t$112287 = ((long)(((int)(t$112286))));
            
            //#line 405 "x10/compiler/Foreach.x10"
            final x10.core.Rail results = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$112287)), false)));
            {
                
                //#line 406 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 406 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113563 = x10.xrx.Runtime.startFinish();
                
                //#line 406 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 406 "x10/compiler/Foreach.x10"
                        final int t$112288 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 406 "x10/compiler/Foreach.x10"
                        final long t$112289 = ((long)(((int)(t$112288))));
                        
                        //#line 406 "x10/compiler/Foreach.x10"
                        final long i$111235max$111237 = ((t$112289) - (((long)(1L))));
                        
                        //#line 406 "x10/compiler/Foreach.x10"
                        long i$113158 = 0L;
                        
                        //#line 406 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 406 "x10/compiler/Foreach.x10"
                            final boolean t$113160 = ((i$113158) <= (((long)(i$111235max$111237))));
                            
                            //#line 406 "x10/compiler/Foreach.x10"
                            if (!(t$113160)) {
                                
                                //#line 406 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 406 "x10/compiler/Foreach.x10"
                            final long t$113155 = i$113158;
                            
                            //#line 406 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$32<$T>($T, identity, min, t$113155, max, body, reduce, results, (x10.compiler.Foreach.$Closure$32.$_eec31cb6) null))));
                            
                            //#line 406 "x10/compiler/Foreach.x10"
                            final long t$113157 = ((i$113158) + (((long)(1L))));
                            
                            //#line 406 "x10/compiler/Foreach.x10"
                            i$113158 = t$113157;
                        }
                    }
                }}catch (java.lang.Throwable ct$113561) {
                    
                    //#line 406 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113561)));
                    
                    //#line 406 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 406 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113563)));
                 }}
                }
            
            //#line 413 "x10/compiler/Foreach.x10"
            $T res = (($T)(((x10.core.Rail<$T>)results).$apply$G((long)(0L))));
            
            //#line 414 "x10/compiler/Foreach.x10"
            final int t$113170 = x10.xrx.Runtime.get$NTHREADS();
            
            //#line 414 "x10/compiler/Foreach.x10"
            final long t$113171 = ((long)(((int)(t$113170))));
            
            //#line 414 "x10/compiler/Foreach.x10"
            final long i$111253max$113172 = ((t$113171) - (((long)(1L))));
            
            //#line 414 "x10/compiler/Foreach.x10"
            long i$113167 = 1L;
            
            //#line 414 "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 414 "x10/compiler/Foreach.x10"
                final boolean t$113169 = ((i$113167) <= (((long)(i$111253max$113172))));
                
                //#line 414 "x10/compiler/Foreach.x10"
                if (!(t$113169)) {
                    
                    //#line 414 "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 415 "x10/compiler/Foreach.x10"
                final $T t$113162 = (($T)(((x10.core.Rail<$T>)results).$apply$G((long)(i$113167))));
                
                //#line 415 "x10/compiler/Foreach.x10"
                final $T t$113163 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(res, $T, t$113162, $T))));
                
                //#line 415 "x10/compiler/Foreach.x10"
                res = (($T)(t$113163));
                
                //#line 414 "x10/compiler/Foreach.x10"
                final long t$113166 = ((i$113167) + (((long)(1L))));
                
                //#line 414 "x10/compiler/Foreach.x10"
                i$113167 = t$113166;
            }
            
            //#line 417 "x10/compiler/Foreach.x10"
            return res;
            }
        }
    
    
    //#line 431 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until each activity is
     * less than or equal to a maximum grain size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param grainSize the maximum grain size for an activity
     * @param body a closure that executes over a contiguous range of indices
     */
    public static void bisect__3$1x10$lang$Long$3x10$lang$Long$2(final long min, final long max, final long grainSize, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 434 "x10/compiler/Foreach.x10"
        final int t$112319 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 434 "x10/compiler/Foreach.x10"
        final boolean t$112321 = ((int) t$112319) == ((int) 1);
        
        //#line 434 "x10/compiler/Foreach.x10"
        if (t$112321) {
            
            //#line 83 . "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG);
        } else {
            {
                
                //#line 437 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 437 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113567 = x10.xrx.Runtime.startFinish();
                
                //#line 437 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 437 "x10/compiler/Foreach.x10"
                        final long t$112320 = ((max) + (((long)(1L))));
                        
                        //#line 437 "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(min), (long)(t$112320), (long)(grainSize), ((x10.core.fun.VoidFun_0_2)(body)));
                    }
                }}catch (java.lang.Throwable ct$113565) {
                    
                    //#line 437 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113565)));
                    
                    //#line 437 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 437 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113567)));
                 }}
                }
            }
        }
    
    
    //#line 450 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until a minimum grain
     * size of (max-min+1) / (Runtime.NTHREADS &times; 8) is reached.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices
     */
    public static void bisect__2$1x10$lang$Long$3x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 452 "x10/compiler/Foreach.x10"
        final long t$112324 = ((max) - (((long)(min))));
        
        //#line 452 "x10/compiler/Foreach.x10"
        final int t$112322 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 452 "x10/compiler/Foreach.x10"
        final long t$112323 = ((long)(((int)(t$112322))));
        
        //#line 452 "x10/compiler/Foreach.x10"
        final long t$112325 = ((t$112323) * (((long)(8L))));
        
        //#line 452 "x10/compiler/Foreach.x10"
        final long t$112326 = ((t$112324) / (((long)(t$112325))));
        
        //#line 452 "x10/compiler/Foreach.x10"
        final long grainSize = java.lang.Math.max(((long)(1L)),((long)(t$112326)));
        
        //#line 434 . "x10/compiler/Foreach.x10"
        final int t$113173 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 434 . "x10/compiler/Foreach.x10"
        final boolean t$113174 = ((int) t$113173) == ((int) 1);
        
        //#line 434 . "x10/compiler/Foreach.x10"
        if (t$113174) {
            
            //#line 83 .. "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG);
        } else {
            {
                
                //#line 437 . "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 437 . "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113571 = x10.xrx.Runtime.startFinish();
                
                //#line 437 . "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 437 . "x10/compiler/Foreach.x10"
                        final long t$113178 = ((max) + (((long)(1L))));
                        
                        //#line 437 . "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(min), (long)(t$113178), (long)(grainSize), ((x10.core.fun.VoidFun_0_2)(body)));
                    }
                }}catch (java.lang.Throwable ct$113569) {
                    
                    //#line 437 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113569)));
                    
                    //#line 437 . "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 437 . "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113571)));
                 }}
                }
            }
        }
    
    
    //#line 466 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until each activity is
     * less than or equal to a maximum grain size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param grainSize the maximum grain size for an activity
     * @param body a closure that executes over a single value of the index
     */
    public static void bisect__3$1x10$lang$Long$2(final long min, final long max, final long grainSize, final x10.core.fun.VoidFun_0_1<x10.core.Long> body) {
        
        //#line 469 "x10/compiler/Foreach.x10"
        final int t$112330 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 469 "x10/compiler/Foreach.x10"
        final boolean t$112343 = ((int) t$112330) == ((int) 1);
        
        //#line 469 "x10/compiler/Foreach.x10"
        if (t$112343) {
            
            //#line 52 . "x10/compiler/Foreach.x10"
            long i$113182 = min;
            
            //#line 52 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 52 . "x10/compiler/Foreach.x10"
                final boolean t$113184 = ((i$113182) <= (((long)(max))));
                
                //#line 52 . "x10/compiler/Foreach.x10"
                if (!(t$113184)) {
                    
                    //#line 52 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 52 . "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Long>)body).$apply(x10.core.Long.$box(i$113182), x10.rtt.Types.LONG);
                
                //#line 52 . "x10/compiler/Foreach.x10"
                final long t$113181 = ((i$113182) + (((long)(1L))));
                
                //#line 52 . "x10/compiler/Foreach.x10"
                i$113182 = t$113181;
            }
        } else {
            {
                
                //#line 476 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 476 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113575 = x10.xrx.Runtime.startFinish();
                
                //#line 476 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 476 "x10/compiler/Foreach.x10"
                        final long t$112341 = ((max) + (((long)(1L))));
                        
                        //#line 473 "x10/compiler/Foreach.x10"
                        final x10.core.fun.VoidFun_0_2 t$112342 = ((x10.core.fun.VoidFun_0_2)(new x10.compiler.Foreach.$Closure$33(body, (x10.compiler.Foreach.$Closure$33.__0$1x10$lang$Long$2) null)));
                        
                        //#line 476 "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(min), (long)(t$112341), (long)(grainSize), ((x10.core.fun.VoidFun_0_2)(t$112342)));
                    }
                }}catch (java.lang.Throwable ct$113573) {
                    
                    //#line 476 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113573)));
                    
                    //#line 476 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 476 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113575)));
                 }}
                }
            }
        }
    
    
    //#line 489 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until a minimum grain
     * size of (max-min+1) / (Runtime.NTHREADS &times; 8) is reached.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices
     */
    public static void bisect__2$1x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_1<x10.core.Long> body) {
        
        //#line 491 "x10/compiler/Foreach.x10"
        final long t$112346 = ((max) - (((long)(min))));
        
        //#line 491 "x10/compiler/Foreach.x10"
        final int t$112344 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 491 "x10/compiler/Foreach.x10"
        final long t$112345 = ((long)(((int)(t$112344))));
        
        //#line 491 "x10/compiler/Foreach.x10"
        final long t$112347 = ((t$112345) * (((long)(8L))));
        
        //#line 491 "x10/compiler/Foreach.x10"
        final long t$112348 = ((t$112346) / (((long)(t$112347))));
        
        //#line 491 "x10/compiler/Foreach.x10"
        final long grainSize = java.lang.Math.max(((long)(1L)),((long)(t$112348)));
        
        //#line 492 "x10/compiler/Foreach.x10"
        final long min$111650 = min;
        
        //#line 492 "x10/compiler/Foreach.x10"
        final long grainSize$111652 = grainSize;
        
        //#line 492 "x10/compiler/Foreach.x10"
        final x10.core.fun.VoidFun_0_1 body$111653 = ((x10.core.fun.VoidFun_0_1)(body));
        
        //#line 469 . "x10/compiler/Foreach.x10"
        final int t$113207 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 469 . "x10/compiler/Foreach.x10"
        final boolean t$113208 = ((int) t$113207) == ((int) 1);
        
        //#line 469 . "x10/compiler/Foreach.x10"
        if (t$113208) {
            
            //#line 52 .. "x10/compiler/Foreach.x10"
            long i$113196 = min;
            
            //#line 52 .. "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 52 .. "x10/compiler/Foreach.x10"
                final boolean t$113198 = ((i$113196) <= (((long)(max))));
                
                //#line 52 .. "x10/compiler/Foreach.x10"
                if (!(t$113198)) {
                    
                    //#line 52 .. "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 52 .. "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Long>)body).$apply(x10.core.Long.$box(i$113196), x10.rtt.Types.LONG);
                
                //#line 52 .. "x10/compiler/Foreach.x10"
                final long t$113195 = ((i$113196) + (((long)(1L))));
                
                //#line 52 .. "x10/compiler/Foreach.x10"
                i$113196 = t$113195;
            }
        } else {
            {
                
                //#line 476 . "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 476 . "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113579 = x10.xrx.Runtime.startFinish();
                
                //#line 476 . "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 476 . "x10/compiler/Foreach.x10"
                        final long t$113212 = ((max) + (((long)(1L))));
                        
                        //#line 473 . "x10/compiler/Foreach.x10"
                        final x10.core.fun.VoidFun_0_2 t$113213 = ((x10.core.fun.VoidFun_0_2)(new x10.compiler.Foreach.$Closure$34(body$111653, (x10.compiler.Foreach.$Closure$34.__0$1x10$lang$Long$2) null)));
                        
                        //#line 476 . "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(min$111650), (long)(t$113212), (long)(grainSize$111652), ((x10.core.fun.VoidFun_0_2)(t$113213)));
                    }
                }}catch (java.lang.Throwable ct$113577) {
                    
                    //#line 476 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113577)));
                    
                    //#line 476 . "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 476 . "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113579)));
                 }}
                }
            }
        }
    
    
    //#line 495 "x10/compiler/Foreach.x10"
    private static void doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2(final long start, final long end, final long grainSize, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 498 "x10/compiler/Foreach.x10"
        final long t$112363 = ((end) - (((long)(start))));
        
        //#line 498 "x10/compiler/Foreach.x10"
        final boolean t$112369 = ((t$112363) > (((long)(grainSize))));
        
        //#line 498 "x10/compiler/Foreach.x10"
        if (t$112369) {
            
            //#line 499 "x10/compiler/Foreach.x10"
            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$35(start, end, grainSize, body, (x10.compiler.Foreach.$Closure$35.__3$1x10$lang$Long$3x10$lang$Long$2) null))));
            
            //#line 500 "x10/compiler/Foreach.x10"
            final long t$112366 = ((start) + (((long)(end))));
            
            //#line 500 "x10/compiler/Foreach.x10"
            final long t$112367 = ((t$112366) / (((long)(2L))));
            
            //#line 500 "x10/compiler/Foreach.x10"
            x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(start), (long)(t$112367), (long)(grainSize), ((x10.core.fun.VoidFun_0_2)(body)));
        } else {
            
            //#line 502 "x10/compiler/Foreach.x10"
            final long t$112368 = ((end) - (((long)(1L))));
            
            //#line 502 "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(start), x10.rtt.Types.LONG, x10.core.Long.$box(t$112368), x10.rtt.Types.LONG);
        }
    }
    
    public static void doBisect1D$P__3$1x10$lang$Long$3x10$lang$Long$2(final long start, final long end, final long grainSize, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(start), (long)(end), (long)(grainSize), ((x10.core.fun.VoidFun_0_2)(body)));
    }
    
    
    //#line 518 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until each activity is
     * less than or equal to a maximum grain size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param grainSize the maximum grain size for an activity
     * @param body a closure that executes over a single value of the index
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T bisectReduce__3$1x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__5x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final long min, final long max, final long grainSize, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 530 "x10/compiler/Foreach.x10"
        final long min$111670 = min;
        
        //#line 530 "x10/compiler/Foreach.x10"
        final long grainSize$111672 = grainSize;
        
        //#line 530 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 reduce$111674 = ((x10.core.fun.Fun_0_2)(reduce));
        
        //#line 545 . "x10/compiler/Foreach.x10"
        $T ret$111675 =  null;
        
        //#line 548 . "x10/compiler/Foreach.x10"
        __ret$111676: {
            
            //#line 549 . "x10/compiler/Foreach.x10"
            final int t$112370 = x10.xrx.Runtime.get$NTHREADS();
            //#line 549 . "x10/compiler/Foreach.x10"
            final boolean t$112392 = ((int) t$112370) == ((int) 1);
            //#line 549 . "x10/compiler/Foreach.x10"
            if (t$112392) {
                
                //#line 524 ... "x10/compiler/Foreach.x10"
                $T myRes$111684 = (($T)(identity));
                
                //#line 525 ... "x10/compiler/Foreach.x10"
                long i$113224 = min;
                
                //#line 525 ... "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 525 ... "x10/compiler/Foreach.x10"
                    final boolean t$113226 = ((i$113224) <= (((long)(max))));
                    
                    //#line 525 ... "x10/compiler/Foreach.x10"
                    if (!(t$113226)) {
                        
                        //#line 525 ... "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 526 ... "x10/compiler/Foreach.x10"
                    final $T t$113219 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113224), x10.rtt.Types.LONG))));
                    
                    //#line 526 ... "x10/compiler/Foreach.x10"
                    final $T t$113220 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$111684, $T, t$113219, $T))));
                    
                    //#line 526 ... "x10/compiler/Foreach.x10"
                    myRes$111684 = (($T)(t$113220));
                    
                    //#line 525 ... "x10/compiler/Foreach.x10"
                    final long t$113223 = ((i$113224) + (((long)(1L))));
                    
                    //#line 525 ... "x10/compiler/Foreach.x10"
                    i$113224 = t$113223;
                }
                
                //#line 550 . "x10/compiler/Foreach.x10"
                ret$111675 = (($T)(myRes$111684));
                
                //#line 550 . "x10/compiler/Foreach.x10"
                break __ret$111676;
            } else {
                
                //#line 552 . "x10/compiler/Foreach.x10"
                final long t$112389 = ((max) + (((long)(1L))));
                
                //#line 523 "x10/compiler/Foreach.x10"
                final x10.core.fun.Fun_0_2 t$112390 = ((x10.core.fun.Fun_0_2)(new x10.compiler.Foreach.$Closure$36<$T>($T, identity, body, reduce, (x10.compiler.Foreach.$Closure$36.__0x10$compiler$Foreach$$Closure$36$$T__1$1x10$lang$Long$3x10$compiler$Foreach$$Closure$36$$T$2__2$1x10$compiler$Foreach$$Closure$36$$T$3x10$compiler$Foreach$$Closure$36$$T$3x10$compiler$Foreach$$Closure$36$$T$2) null)));
                
                //#line 552 . "x10/compiler/Foreach.x10"
                final $T t$112391 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min$111670), (long)(t$112389), (long)(grainSize$111672), ((x10.core.fun.Fun_0_2)(t$112390)), ((x10.core.fun.Fun_0_2)(reduce$111674)))));
                
                //#line 552 . "x10/compiler/Foreach.x10"
                ret$111675 = (($T)(t$112391));
                
                //#line 552 . "x10/compiler/Foreach.x10"
                break __ret$111676;
            }
        }
        
        //#line 530 "x10/compiler/Foreach.x10"
        return ret$111675;
    }
    
    
    //#line 545 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until each activity is
     * less than or equal to a maximum grain size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param grainSize the maximum grain size for an activity
     * @param body a closure that executes over a contiguous range of indices, 
     *   returning the reduced value for that range
     * @param reduce the reduction operation
     */
    public static <$T>$T bisectReduce__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long min, final long max, final long grainSize, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        
        //#line 549 "x10/compiler/Foreach.x10"
        final int t$112394 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 549 "x10/compiler/Foreach.x10"
        final boolean t$112398 = ((int) t$112394) == ((int) 1);
        
        //#line 549 "x10/compiler/Foreach.x10"
        if (t$112398) {
            
            //#line 126 . "x10/compiler/Foreach.x10"
            final $T t$112395 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG))));
            
            //#line 550 "x10/compiler/Foreach.x10"
            return t$112395;
        } else {
            
            //#line 552 "x10/compiler/Foreach.x10"
            final long t$112396 = ((max) + (((long)(1L))));
            
            //#line 552 "x10/compiler/Foreach.x10"
            final $T t$112397 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min), (long)(t$112396), (long)(grainSize), ((x10.core.fun.Fun_0_2)(body)), ((x10.core.fun.Fun_0_2)(reduce)))));
            
            //#line 552 "x10/compiler/Foreach.x10"
            return t$112397;
        }
    }
    
    
    //#line 567 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until a minimum grain
     * size of (max-min+1) / (Runtime.NTHREADS &times; 8) is reached.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices, 
     *   returning the reduced value for that range
     * @param reduce the reduction operation
     */
    public static <$T>$T bisectReduce__2$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        
        //#line 570 "x10/compiler/Foreach.x10"
        final long t$112401 = ((max) - (((long)(min))));
        
        //#line 570 "x10/compiler/Foreach.x10"
        final int t$112399 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 570 "x10/compiler/Foreach.x10"
        final long t$112400 = ((long)(((int)(t$112399))));
        
        //#line 570 "x10/compiler/Foreach.x10"
        final long t$112402 = ((t$112400) * (((long)(8L))));
        
        //#line 570 "x10/compiler/Foreach.x10"
        final long t$112403 = ((t$112401) / (((long)(t$112402))));
        
        //#line 570 "x10/compiler/Foreach.x10"
        final long grainSize = java.lang.Math.max(((long)(1L)),((long)(t$112403)));
        
        //#line 545 . "x10/compiler/Foreach.x10"
        $T ret$111700 =  null;
        
        //#line 548 . "x10/compiler/Foreach.x10"
        __ret$111701: {
            
            //#line 549 . "x10/compiler/Foreach.x10"
            final int t$112404 = x10.xrx.Runtime.get$NTHREADS();
            //#line 549 . "x10/compiler/Foreach.x10"
            final boolean t$112408 = ((int) t$112404) == ((int) 1);
            //#line 549 . "x10/compiler/Foreach.x10"
            if (t$112408) {
                
                //#line 126 .. "x10/compiler/Foreach.x10"
                final $T t$112405 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG))));
                
                //#line 550 . "x10/compiler/Foreach.x10"
                ret$111700 = (($T)(t$112405));
                
                //#line 550 . "x10/compiler/Foreach.x10"
                break __ret$111701;
            } else {
                
                //#line 552 . "x10/compiler/Foreach.x10"
                final long t$112406 = ((max) + (((long)(1L))));
                
                //#line 552 . "x10/compiler/Foreach.x10"
                final $T t$112407 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min), (long)(t$112406), (long)(grainSize), ((x10.core.fun.Fun_0_2)(body)), ((x10.core.fun.Fun_0_2)(reduce)))));
                
                //#line 552 . "x10/compiler/Foreach.x10"
                ret$111700 = (($T)(t$112407));
                
                //#line 552 . "x10/compiler/Foreach.x10"
                break __ret$111701;
            }
        }
        
        //#line 571 "x10/compiler/Foreach.x10"
        return ret$111700;
    }
    
    
    //#line 583 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until a minimum grain
     * size of (max-min+1) / (Runtime.NTHREADS &times; 8) is reached.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices
     */
    public static <$T>$T bisectReduce__2$1x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__4x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 586 "x10/compiler/Foreach.x10"
        final long t$112412 = ((max) - (((long)(min))));
        
        //#line 586 "x10/compiler/Foreach.x10"
        final int t$112410 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 586 "x10/compiler/Foreach.x10"
        final long t$112411 = ((long)(((int)(t$112410))));
        
        //#line 586 "x10/compiler/Foreach.x10"
        final long t$112413 = ((t$112411) * (((long)(8L))));
        
        //#line 586 "x10/compiler/Foreach.x10"
        final long t$112414 = ((t$112412) / (((long)(t$112413))));
        
        //#line 586 "x10/compiler/Foreach.x10"
        final long grainSize = java.lang.Math.max(((long)(1L)),((long)(t$112414)));
        
        //#line 587 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_1 body$111710 = ((x10.core.fun.Fun_0_1)(body));
        
        //#line 587 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 reduce$111711 = ((x10.core.fun.Fun_0_2)(reduce));
        
        //#line 587 "x10/compiler/Foreach.x10"
        final $T identity$111712 = (($T)(identity));
        
        //#line 518 . "x10/compiler/Foreach.x10"
        $T ret$111721 =  null;
        
        //#line 530 . "x10/compiler/Foreach.x10"
        final long min$113262 = min;
        
        //#line 530 . "x10/compiler/Foreach.x10"
        final long grainSize$113264 = grainSize;
        
        //#line 530 . "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 reduce$113265 = ((x10.core.fun.Fun_0_2)(reduce));
        
        //#line 545 .. "x10/compiler/Foreach.x10"
        $T ret$113266 =  null;
        
        //#line 548 .. "x10/compiler/Foreach.x10"
        __ret$113267: {
            
            //#line 549 .. "x10/compiler/Foreach.x10"
            final int t$113268 = x10.xrx.Runtime.get$NTHREADS();
            //#line 549 .. "x10/compiler/Foreach.x10"
            final boolean t$113269 = ((int) t$113268) == ((int) 1);
            //#line 549 .. "x10/compiler/Foreach.x10"
            if (t$113269) {
                
                //#line 524 ..... "x10/compiler/Foreach.x10"
                $T myRes$113275 = (($T)(identity));
                
                //#line 525 ..... "x10/compiler/Foreach.x10"
                long i$113246 = min;
                
                //#line 525 ..... "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 525 ..... "x10/compiler/Foreach.x10"
                    final boolean t$113248 = ((i$113246) <= (((long)(max))));
                    
                    //#line 525 ..... "x10/compiler/Foreach.x10"
                    if (!(t$113248)) {
                        
                        //#line 525 ..... "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 526 ..... "x10/compiler/Foreach.x10"
                    final $T t$113241 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113246), x10.rtt.Types.LONG))));
                    
                    //#line 526 ..... "x10/compiler/Foreach.x10"
                    final $T t$113242 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$113275, $T, t$113241, $T))));
                    
                    //#line 526 ..... "x10/compiler/Foreach.x10"
                    myRes$113275 = (($T)(t$113242));
                    
                    //#line 525 ..... "x10/compiler/Foreach.x10"
                    final long t$113245 = ((i$113246) + (((long)(1L))));
                    
                    //#line 525 ..... "x10/compiler/Foreach.x10"
                    i$113246 = t$113245;
                }
                
                //#line 550 .. "x10/compiler/Foreach.x10"
                ret$113266 = (($T)(myRes$113275));
                
                //#line 550 .. "x10/compiler/Foreach.x10"
                break __ret$113267;
            } else {
                
                //#line 552 .. "x10/compiler/Foreach.x10"
                final long t$113277 = ((max) + (((long)(1L))));
                
                //#line 523 . "x10/compiler/Foreach.x10"
                final x10.core.fun.Fun_0_2 t$113278 = ((x10.core.fun.Fun_0_2)(new x10.compiler.Foreach.$Closure$37<$T>($T, identity$111712, body$111710, reduce$111711, (x10.compiler.Foreach.$Closure$37.__0x10$compiler$Foreach$$Closure$37$$T__1$1x10$lang$Long$3x10$compiler$Foreach$$Closure$37$$T$2__2$1x10$compiler$Foreach$$Closure$37$$T$3x10$compiler$Foreach$$Closure$37$$T$3x10$compiler$Foreach$$Closure$37$$T$2) null)));
                
                //#line 552 .. "x10/compiler/Foreach.x10"
                final $T t$113283 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min$113262), (long)(t$113277), (long)(grainSize$113264), ((x10.core.fun.Fun_0_2)(t$113278)), ((x10.core.fun.Fun_0_2)(reduce$113265)))));
                
                //#line 552 .. "x10/compiler/Foreach.x10"
                ret$113266 = (($T)(t$113283));
                
                //#line 552 .. "x10/compiler/Foreach.x10"
                break __ret$113267;
            }
        }
        
        //#line 530 . "x10/compiler/Foreach.x10"
        ret$111721 = (($T)(ret$113266));
        
        //#line 587 "x10/compiler/Foreach.x10"
        return ret$111721;
    }
    
    
    //#line 590 "x10/compiler/Foreach.x10"
    private static <$T>$T doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long start, final long end, final long grainSize, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        
        //#line 594 "x10/compiler/Foreach.x10"
        final long t$112440 = ((end) - (((long)(start))));
        
        //#line 594 "x10/compiler/Foreach.x10"
        final boolean t$112450 = ((t$112440) > (((long)(grainSize))));
        
        //#line 594 "x10/compiler/Foreach.x10"
        if (t$112450) {
            
            //#line 595 "x10/compiler/Foreach.x10"
            final $T asyncResult;
            
            //#line 596 "x10/compiler/Foreach.x10"
            final $T syncResult;
            {
                
                //#line 597 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 597 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113587 = x10.xrx.Runtime.startFinish();
                {
                    
                    //#line 597 "x10/compiler/Foreach.x10"
                    final $T[] $asyncResult$113621 = ($T[]) new java.lang.Object[1];
                    
                    //#line 597 "x10/compiler/Foreach.x10"
                    try {{
                        {
                            
                            //#line 598 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$38<$T>($T, start, end, grainSize, body, reduce, $asyncResult$113621, (x10.compiler.Foreach.$Closure$38.__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$38$$T$2__4$1x10$compiler$Foreach$$Closure$38$$T$3x10$compiler$Foreach$$Closure$38$$T$3x10$compiler$Foreach$$Closure$38$$T$2) null))));
                            
                            //#line 599 "x10/compiler/Foreach.x10"
                            final long t$112444 = ((start) + (((long)(end))));
                            
                            //#line 599 "x10/compiler/Foreach.x10"
                            final long t$112445 = ((t$112444) / (((long)(2L))));
                            
                            //#line 599 "x10/compiler/Foreach.x10"
                            final $T t$112446 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(start), (long)(t$112445), (long)(grainSize), ((x10.core.fun.Fun_0_2)(body)), ((x10.core.fun.Fun_0_2)(reduce)))));
                            
                            //#line 599 "x10/compiler/Foreach.x10"
                            syncResult = (($T)(t$112446));
                        }
                    }}catch (java.lang.Throwable ct$113585) {
                        
                        //#line 597 "x10/compiler/Foreach.x10"
                        x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113585)));
                        
                        //#line 597 "x10/compiler/Foreach.x10"
                        throw new java.lang.RuntimeException();
                    }finally {{
                         
                         //#line 597 "x10/compiler/Foreach.x10"
                         x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113587)));
                     }}
                    
                    //#line 597 "x10/compiler/Foreach.x10"
                    asyncResult = (($T)((($T)$asyncResult$113621[(int)0])));
                    }
                }
            
            //#line 601 "x10/compiler/Foreach.x10"
            final $T t$112447 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(syncResult, $T, asyncResult, $T))));
            
            //#line 601 "x10/compiler/Foreach.x10"
            return t$112447;
            } else {
                
                //#line 603 "x10/compiler/Foreach.x10"
                final long t$112448 = ((end) - (((long)(1L))));
                
                //#line 603 "x10/compiler/Foreach.x10"
                final $T t$112449 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(start), x10.rtt.Types.LONG, x10.core.Long.$box(t$112448), x10.rtt.Types.LONG))));
                
                //#line 603 "x10/compiler/Foreach.x10"
                return t$112449;
            }
        }
    
    public static <$T>$T doBisectReduce1D$P__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long start, final long end, final long grainSize, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        return x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(start), (long)(end), (long)(grainSize), ((x10.core.fun.Fun_0_2)(body)), ((x10.core.fun.Fun_0_2)(reduce)));
    }
    
    
    //#line 622 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a maximum grain size in each 
     * dimension.
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param grainSize0 the maximum grain size for the first index dimension
     * @param grainSize1 the maximum grain size for the second index dimension
     * @param body a closure that executes over a rectangular block of indices
     */
    public static void bisect__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final long grainSize0, final long grainSize1, final x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body) {
        
        //#line 626 "x10/compiler/Foreach.x10"
        final int t$112451 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 626 "x10/compiler/Foreach.x10"
        final boolean t$112454 = ((int) t$112451) == ((int) 1);
        
        //#line 626 "x10/compiler/Foreach.x10"
        if (t$112454) {
            
            //#line 627 "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(min0), x10.rtt.Types.LONG, x10.core.Long.$box(max0), x10.rtt.Types.LONG, x10.core.Long.$box(min1), x10.rtt.Types.LONG, x10.core.Long.$box(max1), x10.rtt.Types.LONG);
        } else {
            {
                
                //#line 629 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 629 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113591 = x10.xrx.Runtime.startFinish();
                
                //#line 629 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 629 "x10/compiler/Foreach.x10"
                        final long t$112452 = ((max0) + (((long)(1L))));
                        
                        //#line 629 "x10/compiler/Foreach.x10"
                        final long t$112453 = ((max1) + (((long)(1L))));
                        
                        //#line 629 "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(min0), (long)(t$112452), (long)(min1), (long)(t$112453), (long)(grainSize0), (long)(grainSize1), ((x10.core.fun.VoidFun_0_4)(body)));
                    }
                }}catch (java.lang.Throwable ct$113589) {
                    
                    //#line 629 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113589)));
                    
                    //#line 629 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 629 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113591)));
                 }}
                }
            }
        }
    
    
    //#line 648 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a grain size of 
     * (max-min+1) / Runtime.NTHREADS in each dimension.
     * <p>TODO divide each dim by N ~= sqrt(Runtime.NTHREADS &times; 8), biased
     *   towards more divisions in longer dim
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param body a closure that executes over a rectangular block of indices
     */
    public static void bisect__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body) {
        
        //#line 651 "x10/compiler/Foreach.x10"
        final long t$112456 = ((max0) - (((long)(min0))));
        
        //#line 651 "x10/compiler/Foreach.x10"
        final int t$112455 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 651 "x10/compiler/Foreach.x10"
        final long t$112457 = ((long)(((int)(t$112455))));
        
        //#line 651 "x10/compiler/Foreach.x10"
        final long t$112458 = ((t$112456) / (((long)(t$112457))));
        
        //#line 651 "x10/compiler/Foreach.x10"
        final long grainSize0 = java.lang.Math.max(((long)(1L)),((long)(t$112458)));
        
        //#line 652 "x10/compiler/Foreach.x10"
        final long t$112460 = ((max1) - (((long)(min1))));
        
        //#line 652 "x10/compiler/Foreach.x10"
        final int t$112459 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 652 "x10/compiler/Foreach.x10"
        final long t$112461 = ((long)(((int)(t$112459))));
        
        //#line 652 "x10/compiler/Foreach.x10"
        final long t$112462 = ((t$112460) / (((long)(t$112461))));
        
        //#line 652 "x10/compiler/Foreach.x10"
        final long grainSize1 = java.lang.Math.max(((long)(1L)),((long)(t$112462)));
        
        //#line 626 . "x10/compiler/Foreach.x10"
        final int t$113285 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 626 . "x10/compiler/Foreach.x10"
        final boolean t$113286 = ((int) t$113285) == ((int) 1);
        
        //#line 626 . "x10/compiler/Foreach.x10"
        if (t$113286) {
            
            //#line 627 . "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(min0), x10.rtt.Types.LONG, x10.core.Long.$box(max0), x10.rtt.Types.LONG, x10.core.Long.$box(min1), x10.rtt.Types.LONG, x10.core.Long.$box(max1), x10.rtt.Types.LONG);
        } else {
            {
                
                //#line 629 . "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 629 . "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113595 = x10.xrx.Runtime.startFinish();
                
                //#line 629 . "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 629 . "x10/compiler/Foreach.x10"
                        final long t$113287 = ((max0) + (((long)(1L))));
                        
                        //#line 629 . "x10/compiler/Foreach.x10"
                        final long t$113288 = ((max1) + (((long)(1L))));
                        
                        //#line 629 . "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(min0), (long)(t$113287), (long)(min1), (long)(t$113288), (long)(grainSize0), (long)(grainSize1), ((x10.core.fun.VoidFun_0_4)(body)));
                    }
                }}catch (java.lang.Throwable ct$113593) {
                    
                    //#line 629 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113593)));
                    
                    //#line 629 . "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 629 . "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113595)));
                 }}
                }
            }
        }
    
    
    //#line 671 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a maximum grain size in each 
     * dimension.
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param grainSize0 the maximum grain size for the first index dimension
     * @param grainSize1 the maximum grain size for the second index dimension
     * @param body a closure that executes over a single index [i,j]
     */
    public static void bisect__6$1x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final long grainSize0, final long grainSize1, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 681 "x10/compiler/Foreach.x10"
        final long min$111751 = min0;
        
        //#line 681 "x10/compiler/Foreach.x10"
        final long min$111753 = min1;
        
        //#line 681 "x10/compiler/Foreach.x10"
        final long grainSize$111755 = grainSize0;
        
        //#line 681 "x10/compiler/Foreach.x10"
        final long grainSize$111756 = grainSize1;
        
        //#line 626 . "x10/compiler/Foreach.x10"
        final int t$113319 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 626 . "x10/compiler/Foreach.x10"
        final boolean t$113320 = ((int) t$113319) == ((int) 1);
        
        //#line 626 . "x10/compiler/Foreach.x10"
        if (t$113320) {
            
            //#line 677 .. "x10/compiler/Foreach.x10"
            long i$113300 = min0;
            
            //#line 677 .. "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 677 .. "x10/compiler/Foreach.x10"
                final boolean t$113302 = ((i$113300) <= (((long)(max0))));
                
                //#line 677 .. "x10/compiler/Foreach.x10"
                if (!(t$113302)) {
                    
                    //#line 677 .. "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 678 .. "x10/compiler/Foreach.x10"
                long i$113292 = min1;
                
                //#line 678 .. "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 678 .. "x10/compiler/Foreach.x10"
                    final boolean t$113294 = ((i$113292) <= (((long)(max1))));
                    
                    //#line 678 .. "x10/compiler/Foreach.x10"
                    if (!(t$113294)) {
                        
                        //#line 678 .. "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 679 .. "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$113300), x10.rtt.Types.LONG, x10.core.Long.$box(i$113292), x10.rtt.Types.LONG);
                    
                    //#line 678 .. "x10/compiler/Foreach.x10"
                    final long t$113291 = ((i$113292) + (((long)(1L))));
                    
                    //#line 678 .. "x10/compiler/Foreach.x10"
                    i$113292 = t$113291;
                }
                
                //#line 677 .. "x10/compiler/Foreach.x10"
                final long t$113299 = ((i$113300) + (((long)(1L))));
                
                //#line 677 .. "x10/compiler/Foreach.x10"
                i$113300 = t$113299;
            }
        } else {
            {
                
                //#line 629 . "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 629 . "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113599 = x10.xrx.Runtime.startFinish();
                
                //#line 629 . "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 629 . "x10/compiler/Foreach.x10"
                        final long t$113325 = ((max0) + (((long)(1L))));
                        
                        //#line 629 . "x10/compiler/Foreach.x10"
                        final long t$113326 = ((max1) + (((long)(1L))));
                        
                        //#line 676 "x10/compiler/Foreach.x10"
                        final x10.core.fun.VoidFun_0_4 t$113327 = ((x10.core.fun.VoidFun_0_4)(new x10.compiler.Foreach.$Closure$39(body, (x10.compiler.Foreach.$Closure$39.__0$1x10$lang$Long$3x10$lang$Long$2) null)));
                        
                        //#line 629 . "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(min$111751), (long)(t$113325), (long)(min$111753), (long)(t$113326), (long)(grainSize$111755), (long)(grainSize$111756), ((x10.core.fun.VoidFun_0_4)(t$113327)));
                    }
                }}catch (java.lang.Throwable ct$113597) {
                    
                    //#line 629 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113597)));
                    
                    //#line 629 . "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 629 . "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113599)));
                 }}
                }
            }
        }
    
    
    //#line 699 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a grain size of 
     * (max-min+1) / Runtime.NTHREADS in each dimension.
     * <p>TODO divide each dim by N ~= sqrt(Runtime.NTHREADS &times; 8), biased
     *   towards more divisions in longer dim
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param body a closure that executes over a single index [i,j]
     */
    public static void bisect__4$1x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 702 "x10/compiler/Foreach.x10"
        final long t$112493 = ((max0) - (((long)(min0))));
        
        //#line 702 "x10/compiler/Foreach.x10"
        final int t$112492 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 702 "x10/compiler/Foreach.x10"
        final long t$112494 = ((long)(((int)(t$112492))));
        
        //#line 702 "x10/compiler/Foreach.x10"
        final long t$112495 = ((t$112493) / (((long)(t$112494))));
        
        //#line 702 "x10/compiler/Foreach.x10"
        final long grainSize0 = java.lang.Math.max(((long)(1L)),((long)(t$112495)));
        
        //#line 703 "x10/compiler/Foreach.x10"
        final long t$112497 = ((max1) - (((long)(min1))));
        
        //#line 703 "x10/compiler/Foreach.x10"
        final int t$112496 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 703 "x10/compiler/Foreach.x10"
        final long t$112498 = ((long)(((int)(t$112496))));
        
        //#line 703 "x10/compiler/Foreach.x10"
        final long t$112499 = ((t$112497) / (((long)(t$112498))));
        
        //#line 703 "x10/compiler/Foreach.x10"
        final long grainSize1 = java.lang.Math.max(((long)(1L)),((long)(t$112499)));
        
        //#line 704 "x10/compiler/Foreach.x10"
        final x10.core.fun.VoidFun_0_2 body$111778 = ((x10.core.fun.VoidFun_0_2)(body));
        
        //#line 681 . "x10/compiler/Foreach.x10"
        final long min$113379 = min0;
        
        //#line 681 . "x10/compiler/Foreach.x10"
        final long min$113381 = min1;
        
        //#line 681 . "x10/compiler/Foreach.x10"
        final long grainSize$113383 = grainSize0;
        
        //#line 681 . "x10/compiler/Foreach.x10"
        final long grainSize$113384 = grainSize1;
        
        //#line 626 .. "x10/compiler/Foreach.x10"
        final int t$113364 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 626 .. "x10/compiler/Foreach.x10"
        final boolean t$113365 = ((int) t$113364) == ((int) 1);
        
        //#line 626 .. "x10/compiler/Foreach.x10"
        if (t$113365) {
            
            //#line 677 .... "x10/compiler/Foreach.x10"
            long i$113345 = min0;
            
            //#line 677 .... "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 677 .... "x10/compiler/Foreach.x10"
                final boolean t$113347 = ((i$113345) <= (((long)(max0))));
                
                //#line 677 .... "x10/compiler/Foreach.x10"
                if (!(t$113347)) {
                    
                    //#line 677 .... "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 678 .... "x10/compiler/Foreach.x10"
                long i$113337 = min1;
                
                //#line 678 .... "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 678 .... "x10/compiler/Foreach.x10"
                    final boolean t$113339 = ((i$113337) <= (((long)(max1))));
                    
                    //#line 678 .... "x10/compiler/Foreach.x10"
                    if (!(t$113339)) {
                        
                        //#line 678 .... "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 679 .... "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$113345), x10.rtt.Types.LONG, x10.core.Long.$box(i$113337), x10.rtt.Types.LONG);
                    
                    //#line 678 .... "x10/compiler/Foreach.x10"
                    final long t$113336 = ((i$113337) + (((long)(1L))));
                    
                    //#line 678 .... "x10/compiler/Foreach.x10"
                    i$113337 = t$113336;
                }
                
                //#line 677 .... "x10/compiler/Foreach.x10"
                final long t$113344 = ((i$113345) + (((long)(1L))));
                
                //#line 677 .... "x10/compiler/Foreach.x10"
                i$113345 = t$113344;
            }
        } else {
            {
                
                //#line 629 .. "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 629 .. "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113603 = x10.xrx.Runtime.startFinish();
                
                //#line 629 .. "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 629 .. "x10/compiler/Foreach.x10"
                        final long t$113370 = ((max0) + (((long)(1L))));
                        
                        //#line 629 .. "x10/compiler/Foreach.x10"
                        final long t$113371 = ((max1) + (((long)(1L))));
                        
                        //#line 676 . "x10/compiler/Foreach.x10"
                        final x10.core.fun.VoidFun_0_4 t$113372 = ((x10.core.fun.VoidFun_0_4)(new x10.compiler.Foreach.$Closure$40(body$111778, (x10.compiler.Foreach.$Closure$40.__0$1x10$lang$Long$3x10$lang$Long$2) null)));
                        
                        //#line 629 .. "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(min$113379), (long)(t$113370), (long)(min$113381), (long)(t$113371), (long)(grainSize$113383), (long)(grainSize$113384), ((x10.core.fun.VoidFun_0_4)(t$113372)));
                    }
                }}catch (java.lang.Throwable ct$113601) {
                    
                    //#line 629 .. "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113601)));
                    
                    //#line 629 .. "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 629 .. "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113603)));
                 }}
                }
            }
        }
    
    
    //#line 711 "x10/compiler/Foreach.x10"
    /**
     * Perform a parallel iteration using recursive bisection.
     * Do not wait for termination.
     */
    private static void doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2(final long s0, final long e0, final long s1, final long e1, final long g1, final long g2, final x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body) {
        
        //#line 715 "x10/compiler/Foreach.x10"
        final long t$112525 = ((e0) - (((long)(s0))));
        
        //#line 715 "x10/compiler/Foreach.x10"
        boolean t$112530 = ((t$112525) > (((long)(g1))));
        
        //#line 715 "x10/compiler/Foreach.x10"
        if (t$112530) {
            
            //#line 715 "x10/compiler/Foreach.x10"
            final long t$112526 = ((e0) - (((long)(s0))));
            
            //#line 715 "x10/compiler/Foreach.x10"
            final long t$112527 = ((e1) - (((long)(s1))));
            
            //#line 715 "x10/compiler/Foreach.x10"
            boolean t$112529 = ((t$112526) >= (((long)(t$112527))));
            
            //#line 715 "x10/compiler/Foreach.x10"
            if (!(t$112529)) {
                
                //#line 715 "x10/compiler/Foreach.x10"
                final long t$112528 = ((e1) - (((long)(s1))));
                
                //#line 715 "x10/compiler/Foreach.x10"
                t$112529 = ((t$112528) <= (((long)(g2))));
            }
            
            //#line 715 "x10/compiler/Foreach.x10"
            t$112530 = t$112529;
        }
        
        //#line 715 "x10/compiler/Foreach.x10"
        if (t$112530) {
            
            //#line 716 "x10/compiler/Foreach.x10"
            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$41(s0, e0, s1, e1, g1, g2, body, (x10.compiler.Foreach.$Closure$41.__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2) null))));
            
            //#line 717 "x10/compiler/Foreach.x10"
            final long t$112533 = ((s0) + (((long)(e0))));
            
            //#line 717 "x10/compiler/Foreach.x10"
            final long t$112534 = ((t$112533) / (((long)(2L))));
            
            //#line 717 "x10/compiler/Foreach.x10"
            x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(s0), (long)(t$112534), (long)(s1), (long)(e1), (long)(g1), (long)(g2), ((x10.core.fun.VoidFun_0_4)(body)));
        } else {
            
            //#line 718 "x10/compiler/Foreach.x10"
            final long t$112535 = ((e1) - (((long)(s1))));
            
            //#line 718 "x10/compiler/Foreach.x10"
            final boolean t$112542 = ((t$112535) > (((long)(g2))));
            
            //#line 718 "x10/compiler/Foreach.x10"
            if (t$112542) {
                
                //#line 719 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$42(s1, e1, s0, e0, g1, g2, body, (x10.compiler.Foreach.$Closure$42.__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2) null))));
                
                //#line 720 "x10/compiler/Foreach.x10"
                final long t$112538 = ((s1) + (((long)(e1))));
                
                //#line 720 "x10/compiler/Foreach.x10"
                final long t$112539 = ((t$112538) / (((long)(2L))));
                
                //#line 720 "x10/compiler/Foreach.x10"
                x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(s0), (long)(e0), (long)(s1), (long)(t$112539), (long)(g1), (long)(g2), ((x10.core.fun.VoidFun_0_4)(body)));
            } else {
                
                //#line 722 "x10/compiler/Foreach.x10"
                final long t$112540 = ((e0) - (((long)(1L))));
                
                //#line 722 "x10/compiler/Foreach.x10"
                final long t$112541 = ((e1) - (((long)(1L))));
                
                //#line 722 "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(s0), x10.rtt.Types.LONG, x10.core.Long.$box(t$112540), x10.rtt.Types.LONG, x10.core.Long.$box(s1), x10.rtt.Types.LONG, x10.core.Long.$box(t$112541), x10.rtt.Types.LONG);
            }
        }
    }
    
    public static void doBisect2D$P__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2(final long s0, final long e0, final long s1, final long e1, final long g1, final long g2, final x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body) {
        x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(s0), (long)(e0), (long)(s1), (long)(e1), (long)(g1), (long)(g2), ((x10.core.fun.VoidFun_0_4)(body)));
    }
    
    
    //#line 743 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a maximum grain size in each 
     * dimension.
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param grainSize0 the maximum grain size for the first index dimension
     * @param grainSize1 the maximum grain size for the second index dimension
     * @param body a closure that executes over a single index [i,j]
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T bisectReduce__6$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__8x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final long min0, final long max0, final long min1, final long max1, final long grainSize0, final long grainSize1, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 748 "x10/compiler/Foreach.x10"
        final int t$112544 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 748 "x10/compiler/Foreach.x10"
        final boolean t$112577 = ((int) t$112544) == ((int) 1);
        
        //#line 748 "x10/compiler/Foreach.x10"
        if (t$112577) {
            
            //#line 749 "x10/compiler/Foreach.x10"
            final x10.array.DenseIterationSpace_2 alloc$110999 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
            
            //#line 749 "x10/compiler/Foreach.x10"
            alloc$110999.x10$array$DenseIterationSpace_2$$init$S(((long)(min0)), ((long)(min1)), ((long)(max0)), ((long)(max1)));
            
            //#line 139 . "x10/compiler/Foreach.x10"
            $T myRes$111818 = (($T)(identity));
            
            //#line 140 . "x10/compiler/Foreach.x10"
            final long i$111091min$113402 = alloc$110999.min0;
            
            //#line 140 . "x10/compiler/Foreach.x10"
            final long i$111091max$113403 = alloc$110999.max0;
            
            //#line 140 . "x10/compiler/Foreach.x10"
            long i$113399 = i$111091min$113402;
            
            //#line 140 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 140 . "x10/compiler/Foreach.x10"
                final boolean t$113401 = ((i$113399) <= (((long)(i$111091max$113403))));
                
                //#line 140 . "x10/compiler/Foreach.x10"
                if (!(t$113401)) {
                    
                    //#line 140 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 141 . "x10/compiler/Foreach.x10"
                final long i$111073min$113394 = alloc$110999.min1;
                
                //#line 141 . "x10/compiler/Foreach.x10"
                final long i$111073max$113395 = alloc$110999.max1;
                
                //#line 141 . "x10/compiler/Foreach.x10"
                long i$113391 = i$111073min$113394;
                
                //#line 141 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    final boolean t$113393 = ((i$113391) <= (((long)(i$111073max$113395))));
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    if (!(t$113393)) {
                        
                        //#line 141 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 142 . "x10/compiler/Foreach.x10"
                    final $T t$113386 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113399), x10.rtt.Types.LONG, x10.core.Long.$box(i$113391), x10.rtt.Types.LONG))));
                    
                    //#line 142 . "x10/compiler/Foreach.x10"
                    final $T t$113387 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$111818, $T, t$113386, $T))));
                    
                    //#line 142 . "x10/compiler/Foreach.x10"
                    myRes$111818 = (($T)(t$113387));
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    final long t$113390 = ((i$113391) + (((long)(1L))));
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    i$113391 = t$113390;
                }
                
                //#line 140 . "x10/compiler/Foreach.x10"
                final long t$113398 = ((i$113399) + (((long)(1L))));
                
                //#line 140 . "x10/compiler/Foreach.x10"
                i$113399 = t$113398;
            }
            
            //#line 749 "x10/compiler/Foreach.x10"
            return myRes$111818;
        } else {
            
            //#line 761 "x10/compiler/Foreach.x10"
            final long t$112573 = ((max0) + (((long)(1L))));
            
            //#line 761 "x10/compiler/Foreach.x10"
            final long t$112574 = ((max1) + (((long)(1L))));
            
            //#line 752 "x10/compiler/Foreach.x10"
            final x10.core.fun.Fun_0_4 t$112575 = ((x10.core.fun.Fun_0_4)(new x10.compiler.Foreach.$Closure$43<$T>($T, identity, body, reduce, (x10.compiler.Foreach.$Closure$43.__0x10$compiler$Foreach$$Closure$43$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$43$$T$2__2$1x10$compiler$Foreach$$Closure$43$$T$3x10$compiler$Foreach$$Closure$43$$T$3x10$compiler$Foreach$$Closure$43$$T$2) null)));
            
            //#line 761 "x10/compiler/Foreach.x10"
            final $T t$112576 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min0), (long)(t$112573), (long)(min1), (long)(t$112574), (long)(grainSize0), (long)(grainSize1), ((x10.core.fun.Fun_0_4)(t$112575)), ((x10.core.fun.Fun_0_2)(reduce)))));
            
            //#line 761 "x10/compiler/Foreach.x10"
            return t$112576;
        }
    }
    
    
    //#line 779 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a maximum grain size in each 
     * dimension.
     * @param space the 2D dense space over which to reduce
     * @param grainSize0 the maximum grain size for the first index dimension
     * @param grainSize1 the maximum grain size for the second index dimension
     * @param body a closure that executes over a single index [i,j]
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T bisectReduce__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__5x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final x10.array.DenseIterationSpace_2 space, final long grainSize0, final long grainSize1, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 783 "x10/compiler/Foreach.x10"
        final long min$111828 = space.min0;
        
        //#line 783 "x10/compiler/Foreach.x10"
        final long max$111829 = space.max0;
        
        //#line 783 "x10/compiler/Foreach.x10"
        final long min$111830 = space.min1;
        
        //#line 783 "x10/compiler/Foreach.x10"
        final long max$111831 = space.max1;
        
        //#line 783 "x10/compiler/Foreach.x10"
        final long grainSize$111832 = grainSize0;
        
        //#line 783 "x10/compiler/Foreach.x10"
        final long grainSize$111833 = grainSize1;
        
        //#line 783 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 body$111834 = ((x10.core.fun.Fun_0_2)(body));
        
        //#line 783 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 reduce$111835 = ((x10.core.fun.Fun_0_2)(reduce));
        
        //#line 783 "x10/compiler/Foreach.x10"
        final $T identity$111836 = (($T)(identity));
        
        //#line 743 . "x10/compiler/Foreach.x10"
        $T ret$111852 =  null;
        
        //#line 747 . "x10/compiler/Foreach.x10"
        __ret$111853: {
            
            //#line 748 . "x10/compiler/Foreach.x10"
            final int t$112578 = x10.xrx.Runtime.get$NTHREADS();
            //#line 748 . "x10/compiler/Foreach.x10"
            final boolean t$112611 = ((int) t$112578) == ((int) 1);
            //#line 748 . "x10/compiler/Foreach.x10"
            if (t$112611) {
                
                //#line 749 . "x10/compiler/Foreach.x10"
                final x10.array.DenseIterationSpace_2 alloc$111837 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
                
                //#line 749 . "x10/compiler/Foreach.x10"
                alloc$111837.x10$array$DenseIterationSpace_2$$init$S(((long)(min$111828)), ((long)(min$111830)), ((long)(max$111829)), ((long)(max$111831)));
                
                //#line 139 .. "x10/compiler/Foreach.x10"
                $T myRes$111858 = (($T)(identity));
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                final long i$111091min$113440 = alloc$111837.min0;
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                final long i$111091max$113441 = alloc$111837.max0;
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                long i$113437 = i$111091min$113440;
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    final boolean t$113439 = ((i$113437) <= (((long)(i$111091max$113441))));
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    if (!(t$113439)) {
                        
                        //#line 140 .. "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    final long i$111073min$113432 = alloc$111837.min1;
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    final long i$111073max$113433 = alloc$111837.max1;
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    long i$113429 = i$111073min$113432;
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        final boolean t$113431 = ((i$113429) <= (((long)(i$111073max$113433))));
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        if (!(t$113431)) {
                            
                            //#line 141 .. "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 142 .. "x10/compiler/Foreach.x10"
                        final $T t$113424 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113437), x10.rtt.Types.LONG, x10.core.Long.$box(i$113429), x10.rtt.Types.LONG))));
                        
                        //#line 142 .. "x10/compiler/Foreach.x10"
                        final $T t$113425 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$111858, $T, t$113424, $T))));
                        
                        //#line 142 .. "x10/compiler/Foreach.x10"
                        myRes$111858 = (($T)(t$113425));
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        final long t$113428 = ((i$113429) + (((long)(1L))));
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        i$113429 = t$113428;
                    }
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    final long t$113436 = ((i$113437) + (((long)(1L))));
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    i$113437 = t$113436;
                }
                
                //#line 749 . "x10/compiler/Foreach.x10"
                ret$111852 = (($T)(myRes$111858));
                
                //#line 749 . "x10/compiler/Foreach.x10"
                break __ret$111853;
            } else {
                
                //#line 761 . "x10/compiler/Foreach.x10"
                final long t$112607 = ((max$111829) + (((long)(1L))));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                final long t$112608 = ((max$111831) + (((long)(1L))));
                
                //#line 752 . "x10/compiler/Foreach.x10"
                final x10.core.fun.Fun_0_4 t$112609 = ((x10.core.fun.Fun_0_4)(new x10.compiler.Foreach.$Closure$44<$T>($T, identity$111836, body$111834, reduce$111835, (x10.compiler.Foreach.$Closure$44.__0x10$compiler$Foreach$$Closure$44$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$44$$T$2__2$1x10$compiler$Foreach$$Closure$44$$T$3x10$compiler$Foreach$$Closure$44$$T$3x10$compiler$Foreach$$Closure$44$$T$2) null)));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                final $T t$112610 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min$111828), (long)(t$112607), (long)(min$111830), (long)(t$112608), (long)(grainSize$111832), (long)(grainSize$111833), ((x10.core.fun.Fun_0_4)(t$112609)), ((x10.core.fun.Fun_0_2)(reduce$111835)))));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                ret$111852 = (($T)(t$112610));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                break __ret$111853;
            }
        }
        
        //#line 783 "x10/compiler/Foreach.x10"
        return ret$111852;
    }
    
    
    //#line 798 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a maximum grain size in each 
     * dimension.
     * @param space the 2D dense space over which to reduce
     * @param body a closure that executes over a single index [i,j]
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T bisectReduce__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__2$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__3x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final x10.array.DenseIterationSpace_2 space, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 801 "x10/compiler/Foreach.x10"
        final long t$112613 = space.max0;
        
        //#line 801 "x10/compiler/Foreach.x10"
        final long t$112614 = space.min0;
        
        //#line 801 "x10/compiler/Foreach.x10"
        final long t$112616 = ((t$112613) - (((long)(t$112614))));
        
        //#line 801 "x10/compiler/Foreach.x10"
        final int t$112615 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 801 "x10/compiler/Foreach.x10"
        final long t$112617 = ((long)(((int)(t$112615))));
        
        //#line 801 "x10/compiler/Foreach.x10"
        final long t$112618 = ((t$112616) / (((long)(t$112617))));
        
        //#line 801 "x10/compiler/Foreach.x10"
        final long grainSize0 = java.lang.Math.max(((long)(1L)),((long)(t$112618)));
        
        //#line 802 "x10/compiler/Foreach.x10"
        final long t$112619 = space.max1;
        
        //#line 802 "x10/compiler/Foreach.x10"
        final long t$112620 = space.min1;
        
        //#line 802 "x10/compiler/Foreach.x10"
        final long t$112622 = ((t$112619) - (((long)(t$112620))));
        
        //#line 802 "x10/compiler/Foreach.x10"
        final int t$112621 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 802 "x10/compiler/Foreach.x10"
        final long t$112623 = ((long)(((int)(t$112621))));
        
        //#line 802 "x10/compiler/Foreach.x10"
        final long t$112624 = ((t$112622) / (((long)(t$112623))));
        
        //#line 802 "x10/compiler/Foreach.x10"
        final long grainSize1 = java.lang.Math.max(((long)(1L)),((long)(t$112624)));
        
        //#line 803 "x10/compiler/Foreach.x10"
        final long min$111868 = space.min0;
        
        //#line 803 "x10/compiler/Foreach.x10"
        final long max$111869 = space.max0;
        
        //#line 803 "x10/compiler/Foreach.x10"
        final long min$111870 = space.min1;
        
        //#line 803 "x10/compiler/Foreach.x10"
        final long max$111871 = space.max1;
        
        //#line 803 "x10/compiler/Foreach.x10"
        final long grainSize$111872 = grainSize0;
        
        //#line 803 "x10/compiler/Foreach.x10"
        final long grainSize$111873 = grainSize1;
        
        //#line 803 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 body$111874 = ((x10.core.fun.Fun_0_2)(body));
        
        //#line 803 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 reduce$111875 = ((x10.core.fun.Fun_0_2)(reduce));
        
        //#line 803 "x10/compiler/Foreach.x10"
        final $T identity$111876 = (($T)(identity));
        
        //#line 743 . "x10/compiler/Foreach.x10"
        $T ret$111892 =  null;
        
        //#line 747 . "x10/compiler/Foreach.x10"
        __ret$111893: {
            
            //#line 748 . "x10/compiler/Foreach.x10"
            final int t$112625 = x10.xrx.Runtime.get$NTHREADS();
            //#line 748 . "x10/compiler/Foreach.x10"
            final boolean t$112658 = ((int) t$112625) == ((int) 1);
            //#line 748 . "x10/compiler/Foreach.x10"
            if (t$112658) {
                
                //#line 749 . "x10/compiler/Foreach.x10"
                final x10.array.DenseIterationSpace_2 alloc$111877 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
                
                //#line 749 . "x10/compiler/Foreach.x10"
                alloc$111877.x10$array$DenseIterationSpace_2$$init$S(((long)(min$111868)), ((long)(min$111870)), ((long)(max$111869)), ((long)(max$111871)));
                
                //#line 139 .. "x10/compiler/Foreach.x10"
                $T myRes$111898 = (($T)(identity));
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                final long i$111091min$113478 = alloc$111877.min0;
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                final long i$111091max$113479 = alloc$111877.max0;
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                long i$113475 = i$111091min$113478;
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    final boolean t$113477 = ((i$113475) <= (((long)(i$111091max$113479))));
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    if (!(t$113477)) {
                        
                        //#line 140 .. "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    final long i$111073min$113470 = alloc$111877.min1;
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    final long i$111073max$113471 = alloc$111877.max1;
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    long i$113467 = i$111073min$113470;
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        final boolean t$113469 = ((i$113467) <= (((long)(i$111073max$113471))));
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        if (!(t$113469)) {
                            
                            //#line 141 .. "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 142 .. "x10/compiler/Foreach.x10"
                        final $T t$113462 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113475), x10.rtt.Types.LONG, x10.core.Long.$box(i$113467), x10.rtt.Types.LONG))));
                        
                        //#line 142 .. "x10/compiler/Foreach.x10"
                        final $T t$113463 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$111898, $T, t$113462, $T))));
                        
                        //#line 142 .. "x10/compiler/Foreach.x10"
                        myRes$111898 = (($T)(t$113463));
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        final long t$113466 = ((i$113467) + (((long)(1L))));
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        i$113467 = t$113466;
                    }
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    final long t$113474 = ((i$113475) + (((long)(1L))));
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    i$113475 = t$113474;
                }
                
                //#line 749 . "x10/compiler/Foreach.x10"
                ret$111892 = (($T)(myRes$111898));
                
                //#line 749 . "x10/compiler/Foreach.x10"
                break __ret$111893;
            } else {
                
                //#line 761 . "x10/compiler/Foreach.x10"
                final long t$112654 = ((max$111869) + (((long)(1L))));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                final long t$112655 = ((max$111871) + (((long)(1L))));
                
                //#line 752 . "x10/compiler/Foreach.x10"
                final x10.core.fun.Fun_0_4 t$112656 = ((x10.core.fun.Fun_0_4)(new x10.compiler.Foreach.$Closure$45<$T>($T, identity$111876, body$111874, reduce$111875, (x10.compiler.Foreach.$Closure$45.__0x10$compiler$Foreach$$Closure$45$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$45$$T$2__2$1x10$compiler$Foreach$$Closure$45$$T$3x10$compiler$Foreach$$Closure$45$$T$3x10$compiler$Foreach$$Closure$45$$T$2) null)));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                final $T t$112657 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min$111868), (long)(t$112654), (long)(min$111870), (long)(t$112655), (long)(grainSize$111872), (long)(grainSize$111873), ((x10.core.fun.Fun_0_4)(t$112656)), ((x10.core.fun.Fun_0_2)(reduce$111875)))));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                ret$111892 = (($T)(t$112657));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                break __ret$111893;
            }
        }
        
        //#line 803 "x10/compiler/Foreach.x10"
        return ret$111892;
    }
    
    
    //#line 811 "x10/compiler/Foreach.x10"
    /**
     * Perform a parallel reduction using recursive bisection.
     * Results of each branch are reduced together at each level of the tree.
     * Wait for termination of all nested asyncs.
     */
    private static <$T>$T doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long s0, final long e0, final long s1, final long e1, final long g1, final long g2, final x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        
        //#line 816 "x10/compiler/Foreach.x10"
        final long t$112660 = ((e0) - (((long)(s0))));
        
        //#line 816 "x10/compiler/Foreach.x10"
        boolean t$112665 = ((t$112660) > (((long)(g1))));
        
        //#line 816 "x10/compiler/Foreach.x10"
        if (t$112665) {
            
            //#line 816 "x10/compiler/Foreach.x10"
            final long t$112661 = ((e0) - (((long)(s0))));
            
            //#line 816 "x10/compiler/Foreach.x10"
            final long t$112662 = ((e1) - (((long)(s1))));
            
            //#line 816 "x10/compiler/Foreach.x10"
            boolean t$112664 = ((t$112661) >= (((long)(t$112662))));
            
            //#line 816 "x10/compiler/Foreach.x10"
            if (!(t$112664)) {
                
                //#line 816 "x10/compiler/Foreach.x10"
                final long t$112663 = ((e1) - (((long)(s1))));
                
                //#line 816 "x10/compiler/Foreach.x10"
                t$112664 = ((t$112663) <= (((long)(g2))));
            }
            
            //#line 816 "x10/compiler/Foreach.x10"
            t$112665 = t$112664;
        }
        
        //#line 816 "x10/compiler/Foreach.x10"
        if (t$112665) {
            
            //#line 817 "x10/compiler/Foreach.x10"
            final $T asyncResult;
            
            //#line 818 "x10/compiler/Foreach.x10"
            final $T syncResult;
            {
                
                //#line 819 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 819 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113613 = x10.xrx.Runtime.startFinish();
                {
                    
                    //#line 819 "x10/compiler/Foreach.x10"
                    final $T[] $asyncResult$113622 = ($T[]) new java.lang.Object[1];
                    
                    //#line 819 "x10/compiler/Foreach.x10"
                    try {{
                        {
                            
                            //#line 820 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$46<$T>($T, s0, e0, s1, e1, g1, g2, body, reduce, $asyncResult$113622, (x10.compiler.Foreach.$Closure$46.__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$46$$T$2__7$1x10$compiler$Foreach$$Closure$46$$T$3x10$compiler$Foreach$$Closure$46$$T$3x10$compiler$Foreach$$Closure$46$$T$2) null))));
                            
                            //#line 821 "x10/compiler/Foreach.x10"
                            final long t$112669 = ((s0) + (((long)(e0))));
                            
                            //#line 821 "x10/compiler/Foreach.x10"
                            final long t$112670 = ((t$112669) / (((long)(2L))));
                            
                            //#line 821 "x10/compiler/Foreach.x10"
                            final $T t$112671 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(s0), (long)(t$112670), (long)(s1), (long)(e1), (long)(g1), (long)(g2), ((x10.core.fun.Fun_0_4)(body)), ((x10.core.fun.Fun_0_2)(reduce)))));
                            
                            //#line 821 "x10/compiler/Foreach.x10"
                            syncResult = (($T)(t$112671));
                        }
                    }}catch (java.lang.Throwable ct$113611) {
                        
                        //#line 819 "x10/compiler/Foreach.x10"
                        x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113611)));
                        
                        //#line 819 "x10/compiler/Foreach.x10"
                        throw new java.lang.RuntimeException();
                    }finally {{
                         
                         //#line 819 "x10/compiler/Foreach.x10"
                         x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113613)));
                     }}
                    
                    //#line 819 "x10/compiler/Foreach.x10"
                    asyncResult = (($T)((($T)$asyncResult$113622[(int)0])));
                    }
                }
            
            //#line 823 "x10/compiler/Foreach.x10"
            final $T t$112672 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(asyncResult, $T, syncResult, $T))));
            
            //#line 823 "x10/compiler/Foreach.x10"
            return t$112672;
            } else {
                
                //#line 824 "x10/compiler/Foreach.x10"
                final long t$112673 = ((e1) - (((long)(s1))));
                
                //#line 824 "x10/compiler/Foreach.x10"
                final boolean t$112684 = ((t$112673) > (((long)(g2))));
                
                //#line 824 "x10/compiler/Foreach.x10"
                if (t$112684) {
                    
                    //#line 825 "x10/compiler/Foreach.x10"
                    final $T asyncResult;
                    
                    //#line 826 "x10/compiler/Foreach.x10"
                    final $T syncResult;
                    {
                        
                        //#line 827 "x10/compiler/Foreach.x10"
                        x10.xrx.Runtime.ensureNotInAtomic();
                        
                        //#line 827 "x10/compiler/Foreach.x10"
                        final x10.xrx.FinishState fs$113619 = x10.xrx.Runtime.startFinish();
                        {
                            
                            //#line 827 "x10/compiler/Foreach.x10"
                            final $T[] $asyncResult$113623 = ($T[]) new java.lang.Object[1];
                            
                            //#line 827 "x10/compiler/Foreach.x10"
                            try {{
                                {
                                    
                                    //#line 828 "x10/compiler/Foreach.x10"
                                    x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$47<$T>($T, s1, e1, s0, e0, g1, g2, body, reduce, $asyncResult$113623, (x10.compiler.Foreach.$Closure$47.__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$47$$T$2__7$1x10$compiler$Foreach$$Closure$47$$T$3x10$compiler$Foreach$$Closure$47$$T$3x10$compiler$Foreach$$Closure$47$$T$2) null))));
                                    
                                    //#line 829 "x10/compiler/Foreach.x10"
                                    final long t$112677 = ((s1) + (((long)(e1))));
                                    
                                    //#line 829 "x10/compiler/Foreach.x10"
                                    final long t$112678 = ((t$112677) / (((long)(2L))));
                                    
                                    //#line 829 "x10/compiler/Foreach.x10"
                                    final $T t$112679 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(s0), (long)(e0), (long)(s1), (long)(t$112678), (long)(g1), (long)(g2), ((x10.core.fun.Fun_0_4)(body)), ((x10.core.fun.Fun_0_2)(reduce)))));
                                    
                                    //#line 829 "x10/compiler/Foreach.x10"
                                    syncResult = (($T)(t$112679));
                                }
                            }}catch (java.lang.Throwable ct$113617) {
                                
                                //#line 827 "x10/compiler/Foreach.x10"
                                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113617)));
                                
                                //#line 827 "x10/compiler/Foreach.x10"
                                throw new java.lang.RuntimeException();
                            }finally {{
                                 
                                 //#line 827 "x10/compiler/Foreach.x10"
                                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113619)));
                             }}
                            
                            //#line 827 "x10/compiler/Foreach.x10"
                            asyncResult = (($T)((($T)$asyncResult$113623[(int)0])));
                            }
                        }
                    
                    //#line 831 "x10/compiler/Foreach.x10"
                    final $T t$112680 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(asyncResult, $T, syncResult, $T))));
                    
                    //#line 831 "x10/compiler/Foreach.x10"
                    return t$112680;
                    } else {
                        
                        //#line 833 "x10/compiler/Foreach.x10"
                        final long t$112681 = ((e0) - (((long)(1L))));
                        
                        //#line 833 "x10/compiler/Foreach.x10"
                        final long t$112682 = ((e1) - (((long)(1L))));
                        
                        //#line 833 "x10/compiler/Foreach.x10"
                        final $T t$112683 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(s0), x10.rtt.Types.LONG, x10.core.Long.$box(t$112681), x10.rtt.Types.LONG, x10.core.Long.$box(s1), x10.rtt.Types.LONG, x10.core.Long.$box(t$112682), x10.rtt.Types.LONG))));
                        
                        //#line 833 "x10/compiler/Foreach.x10"
                        return t$112683;
                    }
                }
        }
        
        public static <$T>$T doBisectReduce2D$P__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long s0, final long e0, final long s1, final long e1, final long g1, final long g2, final x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
            return x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(s0), (long)(e0), (long)(s1), (long)(e1), (long)(g1), (long)(g2), ((x10.core.fun.Fun_0_4)(body)), ((x10.core.fun.Fun_0_2)(reduce)));
        }
        
        
        //#line 41 "x10/compiler/Foreach.x10"
        final public x10.compiler.Foreach x10$compiler$Foreach$$this$x10$compiler$Foreach() {
            
            //#line 41 "x10/compiler/Foreach.x10"
            return x10.compiler.Foreach.this;
        }
        
        
        //#line 41 "x10/compiler/Foreach.x10"
        // creation method for java code (1-phase java constructor)
        public Foreach() {
            this((java.lang.System[]) null);
            x10$compiler$Foreach$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.compiler.Foreach x10$compiler$Foreach$$init$S() {
             {
                
                //#line 41 "x10/compiler/Foreach.x10"
                
            }
            return this;
        }
        
        
        
        //#line 41 "x10/compiler/Foreach.x10"
        final public void __fieldInitializers_x10_compiler_Foreach() {
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$22 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$22> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$22> make($Closure$22.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$22 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.i$112760 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$22 $_obj = new x10.compiler.Foreach.$Closure$22((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.i$112760);
                
            }
            
            // constructor just for allocation
            public $Closure$22(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 160 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 160 "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_1<x10.core.Long>)this.body).$apply(x10.core.Long.$box(this.i$112760), x10.rtt.Types.LONG);
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 160 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 160 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.core.fun.VoidFun_0_1<x10.core.Long> body;
            public long i$112760;
            
            public $Closure$22(final x10.core.fun.VoidFun_0_1<x10.core.Long> body, final long i$112760, __0$1x10$lang$Long$2 $dummy) {
                 {
                    this.body = ((x10.core.fun.VoidFun_0_1)(body));
                    this.i$112760 = i$112760;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$23 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$23> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$23> make($Closure$23.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$23 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.i$112790 = $deserializer.readLong();
                $_obj.j$112782 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$23 $_obj = new x10.compiler.Foreach.$Closure$23((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.i$112790);
                $serializer.write(this.j$112782);
                
            }
            
            // constructor just for allocation
            public $Closure$23(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 180 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 180 "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)this.body).$apply(x10.core.Long.$box(this.i$112790), x10.rtt.Types.LONG, x10.core.Long.$box(this.j$112782), x10.rtt.Types.LONG);
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 180 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 180 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body;
            public long i$112790;
            public long j$112782;
            
            public $Closure$23(final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body, final long i$112790, final long j$112782, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.body = ((x10.core.fun.VoidFun_0_2)(body));
                    this.i$112790 = i$112790;
                    this.j$112782 = j$112782;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$24 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$24> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$24> make($Closure$24.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$24 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.blockSize = $deserializer.readLong();
                $_obj.body = $deserializer.readObject();
                $_obj.leftOver = $deserializer.readLong();
                $_obj.min = $deserializer.readLong();
                $_obj.myT$112796 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$24 $_obj = new x10.compiler.Foreach.$Closure$24((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.blockSize);
                $serializer.write(this.body);
                $serializer.write(this.leftOver);
                $serializer.write(this.min);
                $serializer.write(this.myT$112796);
                
            }
            
            // constructor just for allocation
            public $Closure$24(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __4$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 207 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 208 "x10/compiler/Foreach.x10"
                    final long t$112797 = ((this.blockSize) * (((long)(this.myT$112796))));
                    
                    //#line 208 "x10/compiler/Foreach.x10"
                    final long t$112798 = ((this.min) + (((long)(t$112797))));
                    
                    //#line 208 "x10/compiler/Foreach.x10"
                    final boolean t$112799 = ((this.myT$112796) < (((long)(this.leftOver))));
                    
                    //#line 208 "x10/compiler/Foreach.x10"
                    long t$112800 =  0;
                    
                    //#line 208 "x10/compiler/Foreach.x10"
                    if (t$112799) {
                        
                        //#line 208 "x10/compiler/Foreach.x10"
                        t$112800 = this.myT$112796;
                    } else {
                        
                        //#line 208 "x10/compiler/Foreach.x10"
                        t$112800 = this.leftOver;
                    }
                    
                    //#line 208 "x10/compiler/Foreach.x10"
                    final long lo$112802 = ((t$112798) + (((long)(t$112800))));
                    
                    //#line 209 "x10/compiler/Foreach.x10"
                    final long t$112803 = ((lo$112802) + (((long)(this.blockSize))));
                    
                    //#line 209 "x10/compiler/Foreach.x10"
                    final boolean t$112804 = ((this.myT$112796) < (((long)(this.leftOver))));
                    
                    //#line 209 "x10/compiler/Foreach.x10"
                    long t$112805 =  0;
                    
                    //#line 209 "x10/compiler/Foreach.x10"
                    if (t$112804) {
                        
                        //#line 209 "x10/compiler/Foreach.x10"
                        t$112805 = 0L;
                    } else {
                        
                        //#line 209 "x10/compiler/Foreach.x10"
                        t$112805 = -1L;
                    }
                    
                    //#line 209 "x10/compiler/Foreach.x10"
                    final long hi$112807 = ((t$112803) + (((long)(t$112805))));
                    
                    //#line 210 "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)this.body).$apply(x10.core.Long.$box(lo$112802), x10.rtt.Types.LONG, x10.core.Long.$box(hi$112807), x10.rtt.Types.LONG);
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 207 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 207 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long blockSize;
            public long myT$112796;
            public long min;
            public long leftOver;
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body;
            
            public $Closure$24(final long blockSize, final long myT$112796, final long min, final long leftOver, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body, __4$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.blockSize = blockSize;
                    this.myT$112796 = myT$112796;
                    this.min = min;
                    this.leftOver = leftOver;
                    this.body = ((x10.core.fun.VoidFun_0_2)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$25 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$25> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$25> make($Closure$25.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$25 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.blockSize$111431 = $deserializer.readLong();
                $_obj.body = $deserializer.readObject();
                $_obj.leftOver$111432 = $deserializer.readLong();
                $_obj.min$111426 = $deserializer.readLong();
                $_obj.myT$112834 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$25 $_obj = new x10.compiler.Foreach.$Closure$25((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.blockSize$111431);
                $serializer.write(this.body);
                $serializer.write(this.leftOver$111432);
                $serializer.write(this.min$111426);
                $serializer.write(this.myT$112834);
                
            }
            
            // constructor just for allocation
            public $Closure$25(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __4$1x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 207 . "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 208 . "x10/compiler/Foreach.x10"
                    final long t$112835 = ((this.blockSize$111431) * (((long)(this.myT$112834))));
                    
                    //#line 208 . "x10/compiler/Foreach.x10"
                    final long t$112836 = ((this.min$111426) + (((long)(t$112835))));
                    
                    //#line 208 . "x10/compiler/Foreach.x10"
                    final boolean t$112837 = ((this.myT$112834) < (((long)(this.leftOver$111432))));
                    
                    //#line 208 . "x10/compiler/Foreach.x10"
                    long t$112838 =  0;
                    
                    //#line 208 . "x10/compiler/Foreach.x10"
                    if (t$112837) {
                        
                        //#line 208 . "x10/compiler/Foreach.x10"
                        t$112838 = this.myT$112834;
                    } else {
                        
                        //#line 208 . "x10/compiler/Foreach.x10"
                        t$112838 = this.leftOver$111432;
                    }
                    
                    //#line 208 . "x10/compiler/Foreach.x10"
                    final long lo$112840 = ((t$112836) + (((long)(t$112838))));
                    
                    //#line 209 . "x10/compiler/Foreach.x10"
                    final long t$112841 = ((lo$112840) + (((long)(this.blockSize$111431))));
                    
                    //#line 209 . "x10/compiler/Foreach.x10"
                    final boolean t$112842 = ((this.myT$112834) < (((long)(this.leftOver$111432))));
                    
                    //#line 209 . "x10/compiler/Foreach.x10"
                    long t$112843 =  0;
                    
                    //#line 209 . "x10/compiler/Foreach.x10"
                    if (t$112842) {
                        
                        //#line 209 . "x10/compiler/Foreach.x10"
                        t$112843 = 0L;
                    } else {
                        
                        //#line 209 . "x10/compiler/Foreach.x10"
                        t$112843 = -1L;
                    }
                    
                    //#line 209 . "x10/compiler/Foreach.x10"
                    final long hi$112845 = ((t$112841) + (((long)(t$112843))));
                    
                    //#line 52 ... "x10/compiler/Foreach.x10"
                    long i$112826 = lo$112840;
                    
                    //#line 52 ... "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 52 ... "x10/compiler/Foreach.x10"
                        final boolean t$112828 = ((i$112826) <= (((long)(hi$112845))));
                        
                        //#line 52 ... "x10/compiler/Foreach.x10"
                        if (!(t$112828)) {
                            
                            //#line 52 ... "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 52 ... "x10/compiler/Foreach.x10"
                        ((x10.core.fun.VoidFun_0_1<x10.core.Long>)this.body).$apply(x10.core.Long.$box(i$112826), x10.rtt.Types.LONG);
                        
                        //#line 52 ... "x10/compiler/Foreach.x10"
                        final long t$112825 = ((i$112826) + (((long)(1L))));
                        
                        //#line 52 ... "x10/compiler/Foreach.x10"
                        i$112826 = t$112825;
                    }
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 207 . "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 207 . "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long blockSize$111431;
            public long myT$112834;
            public long min$111426;
            public long leftOver$111432;
            public x10.core.fun.VoidFun_0_1<x10.core.Long> body;
            
            public $Closure$25(final long blockSize$111431, final long myT$112834, final long min$111426, final long leftOver$111432, final x10.core.fun.VoidFun_0_1<x10.core.Long> body, __4$1x10$lang$Long$2 $dummy) {
                 {
                    this.blockSize$111431 = blockSize$111431;
                    this.myT$112834 = myT$112834;
                    this.min$111426 = min$111426;
                    this.leftOver$111432 = leftOver$111432;
                    this.body = body;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$26<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$26> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$26> make($Closure$26.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$26<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.blockSize = $deserializer.readLong();
                $_obj.body = $deserializer.readObject();
                $_obj.leftOver = $deserializer.readLong();
                $_obj.min = $deserializer.readLong();
                $_obj.myT$112850 = $deserializer.readLong();
                $_obj.results = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$26 $_obj = new x10.compiler.Foreach.$Closure$26((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.blockSize);
                $serializer.write(this.body);
                $serializer.write(this.leftOver);
                $serializer.write(this.min);
                $serializer.write(this.myT$112850);
                $serializer.write(this.results);
                
            }
            
            // constructor just for allocation
            public $Closure$26(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$26.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$26 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __4$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$26$$T$2__5$1x10$compiler$Foreach$$Closure$26$$T$2 {}
            
        
            
            public void $apply() {
                
                //#line 256 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 257 "x10/compiler/Foreach.x10"
                    final long t$112851 = ((this.blockSize) * (((long)(this.myT$112850))));
                    
                    //#line 257 "x10/compiler/Foreach.x10"
                    final long t$112852 = ((this.min) + (((long)(t$112851))));
                    
                    //#line 257 "x10/compiler/Foreach.x10"
                    final boolean t$112853 = ((this.myT$112850) < (((long)(this.leftOver))));
                    
                    //#line 257 "x10/compiler/Foreach.x10"
                    long t$112854 =  0;
                    
                    //#line 257 "x10/compiler/Foreach.x10"
                    if (t$112853) {
                        
                        //#line 257 "x10/compiler/Foreach.x10"
                        t$112854 = this.myT$112850;
                    } else {
                        
                        //#line 257 "x10/compiler/Foreach.x10"
                        t$112854 = this.leftOver;
                    }
                    
                    //#line 257 "x10/compiler/Foreach.x10"
                    final long lo$112856 = ((t$112852) + (((long)(t$112854))));
                    
                    //#line 258 "x10/compiler/Foreach.x10"
                    final long t$112857 = ((lo$112856) + (((long)(this.blockSize))));
                    
                    //#line 258 "x10/compiler/Foreach.x10"
                    final boolean t$112858 = ((this.myT$112850) < (((long)(this.leftOver))));
                    
                    //#line 258 "x10/compiler/Foreach.x10"
                    long t$112859 =  0;
                    
                    //#line 258 "x10/compiler/Foreach.x10"
                    if (t$112858) {
                        
                        //#line 258 "x10/compiler/Foreach.x10"
                        t$112859 = 0L;
                    } else {
                        
                        //#line 258 "x10/compiler/Foreach.x10"
                        t$112859 = -1L;
                    }
                    
                    //#line 258 "x10/compiler/Foreach.x10"
                    final long hi$112861 = ((t$112857) + (((long)(t$112859))));
                    
                    //#line 259 "x10/compiler/Foreach.x10"
                    final $T t$112862 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)this.body).$apply(x10.core.Long.$box(lo$112856), x10.rtt.Types.LONG, x10.core.Long.$box(hi$112861), x10.rtt.Types.LONG))));
                    
                    //#line 259 "x10/compiler/Foreach.x10"
                    ((x10.core.Rail<$T>)this.results).$set__1x10$lang$Rail$$T$G((long)(this.myT$112850), (($T)(t$112862)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 256 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 256 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long blockSize;
            public long myT$112850;
            public long min;
            public long leftOver;
            public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body;
            public x10.core.Rail<$T> results;
            
            public $Closure$26(final x10.rtt.Type $T, final long blockSize, final long myT$112850, final long min, final long leftOver, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.Rail<$T> results, __4$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$26$$T$2__5$1x10$compiler$Foreach$$Closure$26$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$26.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$26<$T>)this).blockSize = blockSize;
                    ((x10.compiler.Foreach.$Closure$26<$T>)this).myT$112850 = myT$112850;
                    ((x10.compiler.Foreach.$Closure$26<$T>)this).min = min;
                    ((x10.compiler.Foreach.$Closure$26<$T>)this).leftOver = leftOver;
                    ((x10.compiler.Foreach.$Closure$26<$T>)this).body = ((x10.core.fun.Fun_0_2)(body));
                    ((x10.compiler.Foreach.$Closure$26<$T>)this).results = ((x10.core.Rail)(results));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$27<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$27> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$27> make($Closure$27.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$27<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.blockSize$111470 = $deserializer.readLong();
                $_obj.body = $deserializer.readObject();
                $_obj.identity = $deserializer.readObject();
                $_obj.leftOver$111471 = $deserializer.readLong();
                $_obj.min$111464 = $deserializer.readLong();
                $_obj.myT$112909 = $deserializer.readLong();
                $_obj.reduce = $deserializer.readObject();
                $_obj.results$111472 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$27 $_obj = new x10.compiler.Foreach.$Closure$27((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.blockSize$111470);
                $serializer.write(this.body);
                $serializer.write(this.identity);
                $serializer.write(this.leftOver$111471);
                $serializer.write(this.min$111464);
                $serializer.write(this.myT$112909);
                $serializer.write(this.reduce);
                $serializer.write(this.results$111472);
                
            }
            
            // constructor just for allocation
            public $Closure$27(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$27.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$27 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling for __4x10$compiler$Foreach$$Closure$27$$T__5$1x10$lang$Long$3x10$compiler$Foreach$$Closure$27$$T$2__6$1x10$compiler$Foreach$$Closure$27$$T$3x10$compiler$Foreach$$Closure$27$$T$3x10$compiler$Foreach$$Closure$27$$T$2__7$1x10$compiler$Foreach$$Closure$27$$T$2
            public static final class $_9021ff2d {}
            
        
            
            public void $apply() {
                
                //#line 256 . "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 257 . "x10/compiler/Foreach.x10"
                    final long t$112910 = ((this.blockSize$111470) * (((long)(this.myT$112909))));
                    
                    //#line 257 . "x10/compiler/Foreach.x10"
                    final long t$112911 = ((this.min$111464) + (((long)(t$112910))));
                    
                    //#line 257 . "x10/compiler/Foreach.x10"
                    final boolean t$112912 = ((this.myT$112909) < (((long)(this.leftOver$111471))));
                    
                    //#line 257 . "x10/compiler/Foreach.x10"
                    long t$112913 =  0;
                    
                    //#line 257 . "x10/compiler/Foreach.x10"
                    if (t$112912) {
                        
                        //#line 257 . "x10/compiler/Foreach.x10"
                        t$112913 = this.myT$112909;
                    } else {
                        
                        //#line 257 . "x10/compiler/Foreach.x10"
                        t$112913 = this.leftOver$111471;
                    }
                    
                    //#line 257 . "x10/compiler/Foreach.x10"
                    final long lo$112915 = ((t$112911) + (((long)(t$112913))));
                    
                    //#line 258 . "x10/compiler/Foreach.x10"
                    final long t$112916 = ((lo$112915) + (((long)(this.blockSize$111470))));
                    
                    //#line 258 . "x10/compiler/Foreach.x10"
                    final boolean t$112917 = ((this.myT$112909) < (((long)(this.leftOver$111471))));
                    
                    //#line 258 . "x10/compiler/Foreach.x10"
                    long t$112918 =  0;
                    
                    //#line 258 . "x10/compiler/Foreach.x10"
                    if (t$112917) {
                        
                        //#line 258 . "x10/compiler/Foreach.x10"
                        t$112918 = 0L;
                    } else {
                        
                        //#line 258 . "x10/compiler/Foreach.x10"
                        t$112918 = -1L;
                    }
                    
                    //#line 258 . "x10/compiler/Foreach.x10"
                    final long hi$112920 = ((t$112916) + (((long)(t$112918))));
                    
                    //#line 285 .. "x10/compiler/Foreach.x10"
                    $T myRes$112923 = (($T)(this.identity));
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    long i$112904 = lo$112915;
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        final boolean t$112906 = ((i$112904) <= (((long)(hi$112920))));
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        if (!(t$112906)) {
                            
                            //#line 286 .. "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 287 .. "x10/compiler/Foreach.x10"
                        final $T t$112899 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)this.body).$apply(x10.core.Long.$box(i$112904), x10.rtt.Types.LONG))));
                        
                        //#line 287 .. "x10/compiler/Foreach.x10"
                        final $T t$112900 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce).$apply(myRes$112923, $T, t$112899, $T))));
                        
                        //#line 287 .. "x10/compiler/Foreach.x10"
                        myRes$112923 = (($T)(t$112900));
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        final long t$112903 = ((i$112904) + (((long)(1L))));
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        i$112904 = t$112903;
                    }
                    
                    //#line 259 . "x10/compiler/Foreach.x10"
                    ((x10.core.Rail<$T>)this.results$111472).$set__1x10$lang$Rail$$T$G((long)(this.myT$112909), (($T)(myRes$112923)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 256 . "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 256 . "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long blockSize$111470;
            public long myT$112909;
            public long min$111464;
            public long leftOver$111471;
            public $T identity;
            public x10.core.fun.Fun_0_1<x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            public x10.core.Rail<$T> results$111472;
            
            public $Closure$27(final x10.rtt.Type $T, final long blockSize$111470, final long myT$112909, final long min$111464, final long leftOver$111471, final $T identity, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final x10.core.Rail<$T> results$111472, $_9021ff2d $dummy) {
                x10.compiler.Foreach.$Closure$27.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).blockSize$111470 = blockSize$111470;
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).myT$112909 = myT$112909;
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).min$111464 = min$111464;
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).leftOver$111471 = leftOver$111471;
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).identity = (($T)(identity));
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).body = ((x10.core.fun.Fun_0_1)(body));
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).results$111472 = ((x10.core.Rail)(results$111472));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$28 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$28> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$28> make($Closure$28.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$28 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body$111509 = $deserializer.readObject();
                $_obj.myT$112980 = $deserializer.readLong();
                $_obj.space$111508 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$28 $_obj = new x10.compiler.Foreach.$Closure$28((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body$111509);
                $serializer.write(this.myT$112980);
                $serializer.write(this.space$111508);
                
            }
            
            // constructor just for allocation
            public $Closure$28(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __2$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 328 . "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 329 . "x10/compiler/Foreach.x10"
                    final int t$112981 = x10.xrx.Runtime.get$NTHREADS();
                    
                    //#line 329 . "x10/compiler/Foreach.x10"
                    final long t$112982 = ((long)(((int)(t$112981))));
                    
                    //#line 329 . "x10/compiler/Foreach.x10"
                    final x10.array.DenseIterationSpace_2 block$112983 = ((x10.array.DenseIterationSpace_2)(x10.array.BlockingUtils.partitionBlockBlock(((x10.array.IterationSpace)(this.space$111508)), (long)(t$112982), (long)(this.myT$112980))));
                    
                    //#line 94 .. "x10/compiler/Foreach.x10"
                    final long min$112975 = block$112983.min0;
                    
                    //#line 94 .. "x10/compiler/Foreach.x10"
                    final long max$112976 = block$112983.max0;
                    
                    //#line 94 .. "x10/compiler/Foreach.x10"
                    final long min$112977 = block$112983.min1;
                    
                    //#line 94 .. "x10/compiler/Foreach.x10"
                    final long max$112978 = block$112983.max1;
                    
                    //#line 66 ... "x10/compiler/Foreach.x10"
                    long i$112970 = min$112975;
                    
                    //#line 66 ... "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 66 ... "x10/compiler/Foreach.x10"
                        final boolean t$112972 = ((i$112970) <= (((long)(max$112976))));
                        
                        //#line 66 ... "x10/compiler/Foreach.x10"
                        if (!(t$112972)) {
                            
                            //#line 66 ... "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 67 ... "x10/compiler/Foreach.x10"
                        long i$112962 = min$112977;
                        
                        //#line 67 ... "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 67 ... "x10/compiler/Foreach.x10"
                            final boolean t$112964 = ((i$112962) <= (((long)(max$112978))));
                            
                            //#line 67 ... "x10/compiler/Foreach.x10"
                            if (!(t$112964)) {
                                
                                //#line 67 ... "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 68 ... "x10/compiler/Foreach.x10"
                            ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)this.body$111509).$apply(x10.core.Long.$box(i$112970), x10.rtt.Types.LONG, x10.core.Long.$box(i$112962), x10.rtt.Types.LONG);
                            
                            //#line 67 ... "x10/compiler/Foreach.x10"
                            final long t$112961 = ((i$112962) + (((long)(1L))));
                            
                            //#line 67 ... "x10/compiler/Foreach.x10"
                            i$112962 = t$112961;
                        }
                        
                        //#line 66 ... "x10/compiler/Foreach.x10"
                        final long t$112969 = ((i$112970) + (((long)(1L))));
                        
                        //#line 66 ... "x10/compiler/Foreach.x10"
                        i$112970 = t$112969;
                    }
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 328 . "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 328 . "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.array.DenseIterationSpace_2 space$111508;
            public long myT$112980;
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body$111509;
            
            public $Closure$28(final x10.array.DenseIterationSpace_2 space$111508, final long myT$112980, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body$111509, __2$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.space$111508 = ((x10.array.DenseIterationSpace_2)(space$111508));
                    this.myT$112980 = myT$112980;
                    this.body$111509 = ((x10.core.fun.VoidFun_0_2)(body$111509));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$29 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$29> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$29> make($Closure$29.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$29 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.myT$113039 = $deserializer.readLong();
                $_obj.space = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$29 $_obj = new x10.compiler.Foreach.$Closure$29((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.myT$113039);
                $serializer.write(this.space);
                
            }
            
            // constructor just for allocation
            public $Closure$29(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __2$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 328 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 329 "x10/compiler/Foreach.x10"
                    final int t$113040 = x10.xrx.Runtime.get$NTHREADS();
                    
                    //#line 329 "x10/compiler/Foreach.x10"
                    final long t$113041 = ((long)(((int)(t$113040))));
                    
                    //#line 329 "x10/compiler/Foreach.x10"
                    final x10.array.DenseIterationSpace_2 block$113042 = ((x10.array.DenseIterationSpace_2)(x10.array.BlockingUtils.partitionBlockBlock(((x10.array.IterationSpace)(this.space)), (long)(t$113041), (long)(this.myT$113039))));
                    
                    //#line 94 . "x10/compiler/Foreach.x10"
                    final long min$113034 = block$113042.min0;
                    
                    //#line 94 . "x10/compiler/Foreach.x10"
                    final long max$113035 = block$113042.max0;
                    
                    //#line 94 . "x10/compiler/Foreach.x10"
                    final long min$113036 = block$113042.min1;
                    
                    //#line 94 . "x10/compiler/Foreach.x10"
                    final long max$113037 = block$113042.max1;
                    
                    //#line 66 .. "x10/compiler/Foreach.x10"
                    long i$113029 = min$113034;
                    
                    //#line 66 .. "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 66 .. "x10/compiler/Foreach.x10"
                        final boolean t$113031 = ((i$113029) <= (((long)(max$113035))));
                        
                        //#line 66 .. "x10/compiler/Foreach.x10"
                        if (!(t$113031)) {
                            
                            //#line 66 .. "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 67 .. "x10/compiler/Foreach.x10"
                        long i$113021 = min$113036;
                        
                        //#line 67 .. "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 67 .. "x10/compiler/Foreach.x10"
                            final boolean t$113023 = ((i$113021) <= (((long)(max$113037))));
                            
                            //#line 67 .. "x10/compiler/Foreach.x10"
                            if (!(t$113023)) {
                                
                                //#line 67 .. "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 68 .. "x10/compiler/Foreach.x10"
                            ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)this.body).$apply(x10.core.Long.$box(i$113029), x10.rtt.Types.LONG, x10.core.Long.$box(i$113021), x10.rtt.Types.LONG);
                            
                            //#line 67 .. "x10/compiler/Foreach.x10"
                            final long t$113020 = ((i$113021) + (((long)(1L))));
                            
                            //#line 67 .. "x10/compiler/Foreach.x10"
                            i$113021 = t$113020;
                        }
                        
                        //#line 66 .. "x10/compiler/Foreach.x10"
                        final long t$113028 = ((i$113029) + (((long)(1L))));
                        
                        //#line 66 .. "x10/compiler/Foreach.x10"
                        i$113029 = t$113028;
                    }
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 328 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 328 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.array.DenseIterationSpace_2 space;
            public long myT$113039;
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body;
            
            public $Closure$29(final x10.array.DenseIterationSpace_2 space, final long myT$113039, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body, __2$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.space = ((x10.array.DenseIterationSpace_2)(space));
                    this.myT$113039 = myT$113039;
                    this.body = body;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$30<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$30> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$30> make($Closure$30.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$30<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.block$113088 = $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.identity = $deserializer.readObject();
                $_obj.myT$113085 = $deserializer.readLong();
                $_obj.reduce = $deserializer.readObject();
                $_obj.results = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$30 $_obj = new x10.compiler.Foreach.$Closure$30((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.block$113088);
                $serializer.write(this.body);
                $serializer.write(this.identity);
                $serializer.write(this.myT$113085);
                $serializer.write(this.reduce);
                $serializer.write(this.results);
                
            }
            
            // constructor just for allocation
            public $Closure$30(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$30.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$30 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling for __0x10$compiler$Foreach$$Closure$30$$T__2$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$30$$T$2__3$1x10$compiler$Foreach$$Closure$30$$T$3x10$compiler$Foreach$$Closure$30$$T$3x10$compiler$Foreach$$Closure$30$$T$2__4$1x10$compiler$Foreach$$Closure$30$$T$2
            public static final class $_273ec00a {}
            
        
            
            public void $apply() {
                
                //#line 356 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 139 . "x10/compiler/Foreach.x10"
                    $T myRes$113093 = (($T)(this.identity));
                    
                    //#line 140 . "x10/compiler/Foreach.x10"
                    final long i$111091min$113083 = this.block$113088.min0;
                    
                    //#line 140 . "x10/compiler/Foreach.x10"
                    final long i$111091max$113084 = this.block$113088.max0;
                    
                    //#line 140 . "x10/compiler/Foreach.x10"
                    long i$113080 = i$111091min$113083;
                    
                    //#line 140 . "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 140 . "x10/compiler/Foreach.x10"
                        final boolean t$113082 = ((i$113080) <= (((long)(i$111091max$113084))));
                        
                        //#line 140 . "x10/compiler/Foreach.x10"
                        if (!(t$113082)) {
                            
                            //#line 140 . "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 141 . "x10/compiler/Foreach.x10"
                        final long i$111073min$113075 = this.block$113088.min1;
                        
                        //#line 141 . "x10/compiler/Foreach.x10"
                        final long i$111073max$113076 = this.block$113088.max1;
                        
                        //#line 141 . "x10/compiler/Foreach.x10"
                        long i$113072 = i$111073min$113075;
                        
                        //#line 141 . "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 141 . "x10/compiler/Foreach.x10"
                            final boolean t$113074 = ((i$113072) <= (((long)(i$111073max$113076))));
                            
                            //#line 141 . "x10/compiler/Foreach.x10"
                            if (!(t$113074)) {
                                
                                //#line 141 . "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 142 . "x10/compiler/Foreach.x10"
                            final $T t$113067 = (($T)((($T)
                                                        ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)this.body).$apply(x10.core.Long.$box(i$113080), x10.rtt.Types.LONG, x10.core.Long.$box(i$113072), x10.rtt.Types.LONG))));
                            
                            //#line 142 . "x10/compiler/Foreach.x10"
                            final $T t$113068 = (($T)((($T)
                                                        ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce).$apply(myRes$113093, $T, t$113067, $T))));
                            
                            //#line 142 . "x10/compiler/Foreach.x10"
                            myRes$113093 = (($T)(t$113068));
                            
                            //#line 141 . "x10/compiler/Foreach.x10"
                            final long t$113071 = ((i$113072) + (((long)(1L))));
                            
                            //#line 141 . "x10/compiler/Foreach.x10"
                            i$113072 = t$113071;
                        }
                        
                        //#line 140 . "x10/compiler/Foreach.x10"
                        final long t$113079 = ((i$113080) + (((long)(1L))));
                        
                        //#line 140 . "x10/compiler/Foreach.x10"
                        i$113080 = t$113079;
                    }
                    
                    //#line 356 "x10/compiler/Foreach.x10"
                    ((x10.core.Rail<$T>)this.results).$set__1x10$lang$Rail$$T$G((long)(this.myT$113085), (($T)(myRes$113093)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 356 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 356 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public $T identity;
            public x10.array.DenseIterationSpace_2 block$113088;
            public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            public x10.core.Rail<$T> results;
            public long myT$113085;
            
            public $Closure$30(final x10.rtt.Type $T, final $T identity, final x10.array.DenseIterationSpace_2 block$113088, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final x10.core.Rail<$T> results, final long myT$113085, $_273ec00a $dummy) {
                x10.compiler.Foreach.$Closure$30.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$30<$T>)this).identity = (($T)(identity));
                    ((x10.compiler.Foreach.$Closure$30<$T>)this).block$113088 = ((x10.array.DenseIterationSpace_2)(block$113088));
                    ((x10.compiler.Foreach.$Closure$30<$T>)this).body = body;
                    ((x10.compiler.Foreach.$Closure$30<$T>)this).reduce = reduce;
                    ((x10.compiler.Foreach.$Closure$30<$T>)this).results = ((x10.core.Rail)(results));
                    ((x10.compiler.Foreach.$Closure$30<$T>)this).myT$113085 = myT$113085;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$31 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$31> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$31> make($Closure$31.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$31 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.max = $deserializer.readLong();
                $_obj.min = $deserializer.readLong();
                $_obj.t$113125 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$31 $_obj = new x10.compiler.Foreach.$Closure$31((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.max);
                $serializer.write(this.min);
                $serializer.write(this.t$113125);
                
            }
            
            // constructor just for allocation
            public $Closure$31(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __3$1x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 380 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 381 "x10/compiler/Foreach.x10"
                    long i$113122 = ((this.min) + (((long)(this.t$113125))));
                    
                    //#line 381 "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 381 "x10/compiler/Foreach.x10"
                        final boolean t$113124 = ((i$113122) <= (((long)(this.max))));
                        
                        //#line 381 "x10/compiler/Foreach.x10"
                        if (!(t$113124)) {
                            
                            //#line 381 "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 382 "x10/compiler/Foreach.x10"
                        ((x10.core.fun.VoidFun_0_1<x10.core.Long>)this.body).$apply(x10.core.Long.$box(i$113122), x10.rtt.Types.LONG);
                        
                        //#line 381 "x10/compiler/Foreach.x10"
                        final int t$113119 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 381 "x10/compiler/Foreach.x10"
                        final long t$113120 = ((long)(((int)(t$113119))));
                        
                        //#line 381 "x10/compiler/Foreach.x10"
                        final long t$113121 = ((i$113122) + (((long)(t$113120))));
                        
                        //#line 381 "x10/compiler/Foreach.x10"
                        i$113122 = t$113121;
                    }
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 380 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 380 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long min;
            public long t$113125;
            public long max;
            public x10.core.fun.VoidFun_0_1<x10.core.Long> body;
            
            public $Closure$31(final long min, final long t$113125, final long max, final x10.core.fun.VoidFun_0_1<x10.core.Long> body, __3$1x10$lang$Long$2 $dummy) {
                 {
                    this.min = min;
                    this.t$113125 = t$113125;
                    this.max = max;
                    this.body = ((x10.core.fun.VoidFun_0_1)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$32<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$32> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$32> make($Closure$32.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$32<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.identity = $deserializer.readObject();
                $_obj.max = $deserializer.readLong();
                $_obj.min = $deserializer.readLong();
                $_obj.reduce = $deserializer.readObject();
                $_obj.results = $deserializer.readObject();
                $_obj.t$113155 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$32 $_obj = new x10.compiler.Foreach.$Closure$32((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.body);
                $serializer.write(this.identity);
                $serializer.write(this.max);
                $serializer.write(this.min);
                $serializer.write(this.reduce);
                $serializer.write(this.results);
                $serializer.write(this.t$113155);
                
            }
            
            // constructor just for allocation
            public $Closure$32(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$32.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$32 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling for __0x10$compiler$Foreach$$Closure$32$$T__4$1x10$lang$Long$3x10$compiler$Foreach$$Closure$32$$T$2__5$1x10$compiler$Foreach$$Closure$32$$T$3x10$compiler$Foreach$$Closure$32$$T$3x10$compiler$Foreach$$Closure$32$$T$2__6$1x10$compiler$Foreach$$Closure$32$$T$2
            public static final class $_eec31cb6 {}
            
        
            
            public void $apply() {
                
                //#line 406 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 407 "x10/compiler/Foreach.x10"
                    $T myRes$113153 = (($T)(this.identity));
                    
                    //#line 408 "x10/compiler/Foreach.x10"
                    long i$113150 = ((this.min) + (((long)(this.t$113155))));
                    
                    //#line 408 "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 408 "x10/compiler/Foreach.x10"
                        final boolean t$113152 = ((i$113150) <= (((long)(this.max))));
                        
                        //#line 408 "x10/compiler/Foreach.x10"
                        if (!(t$113152)) {
                            
                            //#line 408 "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 409 "x10/compiler/Foreach.x10"
                        final $T t$113144 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)this.body).$apply(x10.core.Long.$box(i$113150), x10.rtt.Types.LONG))));
                        
                        //#line 409 "x10/compiler/Foreach.x10"
                        final $T t$113145 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce).$apply(myRes$113153, $T, t$113144, $T))));
                        
                        //#line 409 "x10/compiler/Foreach.x10"
                        myRes$113153 = (($T)(t$113145));
                        
                        //#line 408 "x10/compiler/Foreach.x10"
                        final int t$113147 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 408 "x10/compiler/Foreach.x10"
                        final long t$113148 = ((long)(((int)(t$113147))));
                        
                        //#line 408 "x10/compiler/Foreach.x10"
                        final long t$113149 = ((i$113150) + (((long)(t$113148))));
                        
                        //#line 408 "x10/compiler/Foreach.x10"
                        i$113150 = t$113149;
                    }
                    
                    //#line 411 "x10/compiler/Foreach.x10"
                    ((x10.core.Rail<$T>)this.results).$set__1x10$lang$Rail$$T$G((long)(this.t$113155), (($T)(myRes$113153)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 406 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 406 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public $T identity;
            public long min;
            public long t$113155;
            public long max;
            public x10.core.fun.Fun_0_1<x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            public x10.core.Rail<$T> results;
            
            public $Closure$32(final x10.rtt.Type $T, final $T identity, final long min, final long t$113155, final long max, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final x10.core.Rail<$T> results, $_eec31cb6 $dummy) {
                x10.compiler.Foreach.$Closure$32.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).identity = (($T)(identity));
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).min = min;
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).t$113155 = t$113155;
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).max = max;
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).body = ((x10.core.fun.Fun_0_1)(body));
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).results = ((x10.core.Rail)(results));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$33 extends x10.core.Ref implements x10.core.fun.VoidFun_0_2, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$33> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$33> make($Closure$33.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$33 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$33 $_obj = new x10.compiler.Foreach.$Closure$33((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                
            }
            
            // constructor just for allocation
            public $Closure$33(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2)); return null;
                
            }
            
            // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
            public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$2 {}
            
        
            
            public void $apply(final long start, final long end) {
                
                //#line 474 "x10/compiler/Foreach.x10"
                long i$113190 = start;
                
                //#line 474 "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 474 "x10/compiler/Foreach.x10"
                    final boolean t$113192 = ((i$113190) <= (((long)(end))));
                    
                    //#line 474 "x10/compiler/Foreach.x10"
                    if (!(t$113192)) {
                        
                        //#line 474 "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 474 "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_1<x10.core.Long>)this.body).$apply(x10.core.Long.$box(i$113190), x10.rtt.Types.LONG);
                    
                    //#line 474 "x10/compiler/Foreach.x10"
                    final long t$113189 = ((i$113190) + (((long)(1L))));
                    
                    //#line 474 "x10/compiler/Foreach.x10"
                    i$113190 = t$113189;
                }
            }
            
            public x10.core.fun.VoidFun_0_1<x10.core.Long> body;
            
            public $Closure$33(final x10.core.fun.VoidFun_0_1<x10.core.Long> body, __0$1x10$lang$Long$2 $dummy) {
                 {
                    this.body = ((x10.core.fun.VoidFun_0_1)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$34 extends x10.core.Ref implements x10.core.fun.VoidFun_0_2, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$34> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$34> make($Closure$34.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$34 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body$111653 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$34 $_obj = new x10.compiler.Foreach.$Closure$34((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body$111653);
                
            }
            
            // constructor just for allocation
            public $Closure$34(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2)); return null;
                
            }
            
            // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
            public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$2 {}
            
        
            
            public void $apply(final long start$113214, final long end$113215) {
                
                //#line 474 . "x10/compiler/Foreach.x10"
                long i$113204 = start$113214;
                
                //#line 474 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 474 . "x10/compiler/Foreach.x10"
                    final boolean t$113206 = ((i$113204) <= (((long)(end$113215))));
                    
                    //#line 474 . "x10/compiler/Foreach.x10"
                    if (!(t$113206)) {
                        
                        //#line 474 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 474 . "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_1<x10.core.Long>)this.body$111653).$apply(x10.core.Long.$box(i$113204), x10.rtt.Types.LONG);
                    
                    //#line 474 . "x10/compiler/Foreach.x10"
                    final long t$113203 = ((i$113204) + (((long)(1L))));
                    
                    //#line 474 . "x10/compiler/Foreach.x10"
                    i$113204 = t$113203;
                }
            }
            
            public x10.core.fun.VoidFun_0_1<x10.core.Long> body$111653;
            
            public $Closure$34(final x10.core.fun.VoidFun_0_1<x10.core.Long> body$111653, __0$1x10$lang$Long$2 $dummy) {
                 {
                    this.body$111653 = ((x10.core.fun.VoidFun_0_1)(body$111653));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$35 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$35> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$35> make($Closure$35.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$35 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.end = $deserializer.readLong();
                $_obj.grainSize = $deserializer.readLong();
                $_obj.start = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$35 $_obj = new x10.compiler.Foreach.$Closure$35((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.end);
                $serializer.write(this.grainSize);
                $serializer.write(this.start);
                
            }
            
            // constructor just for allocation
            public $Closure$35(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __3$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 499 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 499 "x10/compiler/Foreach.x10"
                    final long t$112364 = ((this.start) + (((long)(this.end))));
                    
                    //#line 499 "x10/compiler/Foreach.x10"
                    final long t$112365 = ((t$112364) / (((long)(2L))));
                    
                    //#line 499 "x10/compiler/Foreach.x10"
                    x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(t$112365), (long)(this.end), (long)(this.grainSize), ((x10.core.fun.VoidFun_0_2)(this.body)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 499 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 499 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long start;
            public long end;
            public long grainSize;
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body;
            
            public $Closure$35(final long start, final long end, final long grainSize, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body, __3$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.start = start;
                    this.end = end;
                    this.grainSize = grainSize;
                    this.body = ((x10.core.fun.VoidFun_0_2)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$36<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$36> $RTT = 
                x10.rtt.StaticFunType.<$Closure$36> make($Closure$36.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$36<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.identity = $deserializer.readObject();
                $_obj.reduce = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$36 $_obj = new x10.compiler.Foreach.$Closure$36((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.body);
                $serializer.write(this.identity);
                $serializer.write(this.reduce);
                
            }
            
            // constructor just for allocation
            public $Closure$36(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$36.$initParams(this, $T);
                
            }
            
            // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
                return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$36 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0x10$compiler$Foreach$$Closure$36$$T__1$1x10$lang$Long$3x10$compiler$Foreach$$Closure$36$$T$2__2$1x10$compiler$Foreach$$Closure$36$$T$3x10$compiler$Foreach$$Closure$36$$T$3x10$compiler$Foreach$$Closure$36$$T$2 {}
            
        
            
            public $T $apply$G(final long start, final long end) {
                
                //#line 524 "x10/compiler/Foreach.x10"
                $T myRes = (($T)(this.identity));
                
                //#line 525 "x10/compiler/Foreach.x10"
                long i$113235 = start;
                
                //#line 525 "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 525 "x10/compiler/Foreach.x10"
                    final boolean t$113237 = ((i$113235) <= (((long)(end))));
                    
                    //#line 525 "x10/compiler/Foreach.x10"
                    if (!(t$113237)) {
                        
                        //#line 525 "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 526 "x10/compiler/Foreach.x10"
                    final $T t$113230 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)this.body).$apply(x10.core.Long.$box(i$113235), x10.rtt.Types.LONG))));
                    
                    //#line 526 "x10/compiler/Foreach.x10"
                    final $T t$113231 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce).$apply(myRes, $T, t$113230, $T))));
                    
                    //#line 526 "x10/compiler/Foreach.x10"
                    myRes = (($T)(t$113231));
                    
                    //#line 525 "x10/compiler/Foreach.x10"
                    final long t$113234 = ((i$113235) + (((long)(1L))));
                    
                    //#line 525 "x10/compiler/Foreach.x10"
                    i$113235 = t$113234;
                }
                
                //#line 528 "x10/compiler/Foreach.x10"
                return myRes;
            }
            
            public $T identity;
            public x10.core.fun.Fun_0_1<x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            
            public $Closure$36(final x10.rtt.Type $T, final $T identity, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, __0x10$compiler$Foreach$$Closure$36$$T__1$1x10$lang$Long$3x10$compiler$Foreach$$Closure$36$$T$2__2$1x10$compiler$Foreach$$Closure$36$$T$3x10$compiler$Foreach$$Closure$36$$T$3x10$compiler$Foreach$$Closure$36$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$36.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$36<$T>)this).identity = (($T)(identity));
                    ((x10.compiler.Foreach.$Closure$36<$T>)this).body = ((x10.core.fun.Fun_0_1)(body));
                    ((x10.compiler.Foreach.$Closure$36<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$37<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$37> $RTT = 
                x10.rtt.StaticFunType.<$Closure$37> make($Closure$37.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$37<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.body$111710 = $deserializer.readObject();
                $_obj.identity$111712 = $deserializer.readObject();
                $_obj.reduce$111711 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$37 $_obj = new x10.compiler.Foreach.$Closure$37((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.body$111710);
                $serializer.write(this.identity$111712);
                $serializer.write(this.reduce$111711);
                
            }
            
            // constructor just for allocation
            public $Closure$37(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$37.$initParams(this, $T);
                
            }
            
            // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
                return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$37 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0x10$compiler$Foreach$$Closure$37$$T__1$1x10$lang$Long$3x10$compiler$Foreach$$Closure$37$$T$2__2$1x10$compiler$Foreach$$Closure$37$$T$3x10$compiler$Foreach$$Closure$37$$T$3x10$compiler$Foreach$$Closure$37$$T$2 {}
            
        
            
            public $T $apply$G(final long start$113279, final long end$113280) {
                
                //#line 524 . "x10/compiler/Foreach.x10"
                $T myRes$113281 = (($T)(this.identity$111712));
                
                //#line 525 . "x10/compiler/Foreach.x10"
                long i$113257 = start$113279;
                
                //#line 525 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 525 . "x10/compiler/Foreach.x10"
                    final boolean t$113259 = ((i$113257) <= (((long)(end$113280))));
                    
                    //#line 525 . "x10/compiler/Foreach.x10"
                    if (!(t$113259)) {
                        
                        //#line 525 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 526 . "x10/compiler/Foreach.x10"
                    final $T t$113252 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)this.body$111710).$apply(x10.core.Long.$box(i$113257), x10.rtt.Types.LONG))));
                    
                    //#line 526 . "x10/compiler/Foreach.x10"
                    final $T t$113253 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce$111711).$apply(myRes$113281, $T, t$113252, $T))));
                    
                    //#line 526 . "x10/compiler/Foreach.x10"
                    myRes$113281 = (($T)(t$113253));
                    
                    //#line 525 . "x10/compiler/Foreach.x10"
                    final long t$113256 = ((i$113257) + (((long)(1L))));
                    
                    //#line 525 . "x10/compiler/Foreach.x10"
                    i$113257 = t$113256;
                }
                
                //#line 528 . "x10/compiler/Foreach.x10"
                return myRes$113281;
            }
            
            public $T identity$111712;
            public x10.core.fun.Fun_0_1<x10.core.Long,$T> body$111710;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce$111711;
            
            public $Closure$37(final x10.rtt.Type $T, final $T identity$111712, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body$111710, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce$111711, __0x10$compiler$Foreach$$Closure$37$$T__1$1x10$lang$Long$3x10$compiler$Foreach$$Closure$37$$T$2__2$1x10$compiler$Foreach$$Closure$37$$T$3x10$compiler$Foreach$$Closure$37$$T$3x10$compiler$Foreach$$Closure$37$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$37.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$37<$T>)this).identity$111712 = (($T)(identity$111712));
                    ((x10.compiler.Foreach.$Closure$37<$T>)this).body$111710 = ((x10.core.fun.Fun_0_1)(body$111710));
                    ((x10.compiler.Foreach.$Closure$37<$T>)this).reduce$111711 = ((x10.core.fun.Fun_0_2)(reduce$111711));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$38<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$38> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$38> make($Closure$38.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$38<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.$asyncResult$113621 = $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.end = $deserializer.readLong();
                $_obj.grainSize = $deserializer.readLong();
                $_obj.reduce = $deserializer.readObject();
                $_obj.start = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$38 $_obj = new x10.compiler.Foreach.$Closure$38((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.$asyncResult$113621);
                $serializer.write(this.body);
                $serializer.write(this.end);
                $serializer.write(this.grainSize);
                $serializer.write(this.reduce);
                $serializer.write(this.start);
                
            }
            
            // constructor just for allocation
            public $Closure$38(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$38.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$38 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$38$$T$2__4$1x10$compiler$Foreach$$Closure$38$$T$3x10$compiler$Foreach$$Closure$38$$T$3x10$compiler$Foreach$$Closure$38$$T$2 {}
            
        
            
            public void $apply() {
                
                //#line 598 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 598 "x10/compiler/Foreach.x10"
                    final long t$112441 = ((this.start) + (((long)(this.end))));
                    
                    //#line 598 "x10/compiler/Foreach.x10"
                    final long t$112442 = ((t$112441) / (((long)(2L))));
                    
                    //#line 598 "x10/compiler/Foreach.x10"
                    final $T t$112443 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(t$112442), (long)(this.end), (long)(this.grainSize), ((x10.core.fun.Fun_0_2)(this.body)), ((x10.core.fun.Fun_0_2)(this.reduce)))));
                    
                    //#line 598 "x10/compiler/Foreach.x10"
                    this.$asyncResult$113621[(int)0]=t$112443;
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 598 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 598 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long start;
            public long end;
            public long grainSize;
            public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            public $T[] $asyncResult$113621;
            
            public $Closure$38(final x10.rtt.Type $T, final long start, final long end, final long grainSize, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T[] $asyncResult$113621, __3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$38$$T$2__4$1x10$compiler$Foreach$$Closure$38$$T$3x10$compiler$Foreach$$Closure$38$$T$3x10$compiler$Foreach$$Closure$38$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$38.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$38<$T>)this).start = start;
                    ((x10.compiler.Foreach.$Closure$38<$T>)this).end = end;
                    ((x10.compiler.Foreach.$Closure$38<$T>)this).grainSize = grainSize;
                    ((x10.compiler.Foreach.$Closure$38<$T>)this).body = ((x10.core.fun.Fun_0_2)(body));
                    ((x10.compiler.Foreach.$Closure$38<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                    ((x10.compiler.Foreach.$Closure$38<$T>)this).$asyncResult$113621 = $asyncResult$113621;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$39 extends x10.core.Ref implements x10.core.fun.VoidFun_0_4, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$39> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$39> make($Closure$39.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_4.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$39 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$39 $_obj = new x10.compiler.Foreach.$Closure$39((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                
            }
            
            // constructor just for allocation
            public $Closure$39(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>void.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):void
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4)); return null;
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>void.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):void
            public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4));
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply(final long min$113328, final long max$113329, final long min$113330, final long max$113331) {
                
                //#line 677 "x10/compiler/Foreach.x10"
                long i$113316 = min$113328;
                
                //#line 677 "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 677 "x10/compiler/Foreach.x10"
                    final boolean t$113318 = ((i$113316) <= (((long)(max$113329))));
                    
                    //#line 677 "x10/compiler/Foreach.x10"
                    if (!(t$113318)) {
                        
                        //#line 677 "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 678 "x10/compiler/Foreach.x10"
                    long i$113308 = min$113330;
                    
                    //#line 678 "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 678 "x10/compiler/Foreach.x10"
                        final boolean t$113310 = ((i$113308) <= (((long)(max$113331))));
                        
                        //#line 678 "x10/compiler/Foreach.x10"
                        if (!(t$113310)) {
                            
                            //#line 678 "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 679 "x10/compiler/Foreach.x10"
                        ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)this.body).$apply(x10.core.Long.$box(i$113316), x10.rtt.Types.LONG, x10.core.Long.$box(i$113308), x10.rtt.Types.LONG);
                        
                        //#line 678 "x10/compiler/Foreach.x10"
                        final long t$113307 = ((i$113308) + (((long)(1L))));
                        
                        //#line 678 "x10/compiler/Foreach.x10"
                        i$113308 = t$113307;
                    }
                    
                    //#line 677 "x10/compiler/Foreach.x10"
                    final long t$113315 = ((i$113316) + (((long)(1L))));
                    
                    //#line 677 "x10/compiler/Foreach.x10"
                    i$113316 = t$113315;
                }
            }
            
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body;
            
            public $Closure$39(final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.body = ((x10.core.fun.VoidFun_0_2)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$40 extends x10.core.Ref implements x10.core.fun.VoidFun_0_4, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$40> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$40> make($Closure$40.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_4.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$40 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body$111778 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$40 $_obj = new x10.compiler.Foreach.$Closure$40((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body$111778);
                
            }
            
            // constructor just for allocation
            public $Closure$40(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>void.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):void
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4)); return null;
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>void.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):void
            public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4));
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply(final long min$113373, final long max$113374, final long min$113375, final long max$113376) {
                
                //#line 677 . "x10/compiler/Foreach.x10"
                long i$113361 = min$113373;
                
                //#line 677 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 677 . "x10/compiler/Foreach.x10"
                    final boolean t$113363 = ((i$113361) <= (((long)(max$113374))));
                    
                    //#line 677 . "x10/compiler/Foreach.x10"
                    if (!(t$113363)) {
                        
                        //#line 677 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 678 . "x10/compiler/Foreach.x10"
                    long i$113353 = min$113375;
                    
                    //#line 678 . "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 678 . "x10/compiler/Foreach.x10"
                        final boolean t$113355 = ((i$113353) <= (((long)(max$113376))));
                        
                        //#line 678 . "x10/compiler/Foreach.x10"
                        if (!(t$113355)) {
                            
                            //#line 678 . "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 679 . "x10/compiler/Foreach.x10"
                        ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)this.body$111778).$apply(x10.core.Long.$box(i$113361), x10.rtt.Types.LONG, x10.core.Long.$box(i$113353), x10.rtt.Types.LONG);
                        
                        //#line 678 . "x10/compiler/Foreach.x10"
                        final long t$113352 = ((i$113353) + (((long)(1L))));
                        
                        //#line 678 . "x10/compiler/Foreach.x10"
                        i$113353 = t$113352;
                    }
                    
                    //#line 677 . "x10/compiler/Foreach.x10"
                    final long t$113360 = ((i$113361) + (((long)(1L))));
                    
                    //#line 677 . "x10/compiler/Foreach.x10"
                    i$113361 = t$113360;
                }
            }
            
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body$111778;
            
            public $Closure$40(final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body$111778, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.body$111778 = ((x10.core.fun.VoidFun_0_2)(body$111778));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$41 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$41> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$41> make($Closure$41.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$41 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.e0 = $deserializer.readLong();
                $_obj.e1 = $deserializer.readLong();
                $_obj.g1 = $deserializer.readLong();
                $_obj.g2 = $deserializer.readLong();
                $_obj.s0 = $deserializer.readLong();
                $_obj.s1 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$41 $_obj = new x10.compiler.Foreach.$Closure$41((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.e0);
                $serializer.write(this.e1);
                $serializer.write(this.g1);
                $serializer.write(this.g2);
                $serializer.write(this.s0);
                $serializer.write(this.s1);
                
            }
            
            // constructor just for allocation
            public $Closure$41(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 716 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 716 "x10/compiler/Foreach.x10"
                    final long t$112531 = ((this.s0) + (((long)(this.e0))));
                    
                    //#line 716 "x10/compiler/Foreach.x10"
                    final long t$112532 = ((t$112531) / (((long)(2L))));
                    
                    //#line 716 "x10/compiler/Foreach.x10"
                    x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(t$112532), (long)(this.e0), (long)(this.s1), (long)(this.e1), (long)(this.g1), (long)(this.g2), ((x10.core.fun.VoidFun_0_4)(this.body)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 716 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 716 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long s0;
            public long e0;
            public long s1;
            public long e1;
            public long g1;
            public long g2;
            public x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body;
            
            public $Closure$41(final long s0, final long e0, final long s1, final long e1, final long g1, final long g2, final x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body, __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.s0 = s0;
                    this.e0 = e0;
                    this.s1 = s1;
                    this.e1 = e1;
                    this.g1 = g1;
                    this.g2 = g2;
                    this.body = ((x10.core.fun.VoidFun_0_4)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$42 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$42> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$42> make($Closure$42.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$42 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.e0 = $deserializer.readLong();
                $_obj.e1 = $deserializer.readLong();
                $_obj.g1 = $deserializer.readLong();
                $_obj.g2 = $deserializer.readLong();
                $_obj.s0 = $deserializer.readLong();
                $_obj.s1 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$42 $_obj = new x10.compiler.Foreach.$Closure$42((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.e0);
                $serializer.write(this.e1);
                $serializer.write(this.g1);
                $serializer.write(this.g2);
                $serializer.write(this.s0);
                $serializer.write(this.s1);
                
            }
            
            // constructor just for allocation
            public $Closure$42(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 719 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 719 "x10/compiler/Foreach.x10"
                    final long t$112536 = ((this.s1) + (((long)(this.e1))));
                    
                    //#line 719 "x10/compiler/Foreach.x10"
                    final long t$112537 = ((t$112536) / (((long)(2L))));
                    
                    //#line 719 "x10/compiler/Foreach.x10"
                    x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(this.s0), (long)(this.e0), (long)(t$112537), (long)(this.e1), (long)(this.g1), (long)(this.g2), ((x10.core.fun.VoidFun_0_4)(this.body)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 719 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 719 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long s1;
            public long e1;
            public long s0;
            public long e0;
            public long g1;
            public long g2;
            public x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body;
            
            public $Closure$42(final long s1, final long e1, final long s0, final long e0, final long g1, final long g2, final x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body, __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.s1 = s1;
                    this.e1 = e1;
                    this.s0 = s0;
                    this.e0 = e0;
                    this.g1 = g1;
                    this.g2 = g2;
                    this.body = ((x10.core.fun.VoidFun_0_4)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$43<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_4, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$43> $RTT = 
                x10.rtt.StaticFunType.<$Closure$43> make($Closure$43.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_4.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$43<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.identity = $deserializer.readObject();
                $_obj.reduce = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$43 $_obj = new x10.compiler.Foreach.$Closure$43((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.body);
                $serializer.write(this.identity);
                $serializer.write(this.reduce);
                
            }
            
            // constructor just for allocation
            public $Closure$43(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$43.$initParams(this, $T);
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>U.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4));
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$43 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0x10$compiler$Foreach$$Closure$43$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$43$$T$2__2$1x10$compiler$Foreach$$Closure$43$$T$3x10$compiler$Foreach$$Closure$43$$T$3x10$compiler$Foreach$$Closure$43$$T$2 {}
            
        
            
            public $T $apply$G(final long min0, final long max0, final long min1, final long max1) {
                
                //#line 753 "x10/compiler/Foreach.x10"
                $T myResult = (($T)(this.identity));
                
                //#line 754 "x10/compiler/Foreach.x10"
                long i$113418 = min0;
                
                //#line 754 "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 754 "x10/compiler/Foreach.x10"
                    final boolean t$113420 = ((i$113418) <= (((long)(max0))));
                    
                    //#line 754 "x10/compiler/Foreach.x10"
                    if (!(t$113420)) {
                        
                        //#line 754 "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 755 "x10/compiler/Foreach.x10"
                    long i$113410 = min1;
                    
                    //#line 755 "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 755 "x10/compiler/Foreach.x10"
                        final boolean t$113412 = ((i$113410) <= (((long)(max1))));
                        
                        //#line 755 "x10/compiler/Foreach.x10"
                        if (!(t$113412)) {
                            
                            //#line 755 "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 756 "x10/compiler/Foreach.x10"
                        final $T t$113405 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)this.body).$apply(x10.core.Long.$box(i$113418), x10.rtt.Types.LONG, x10.core.Long.$box(i$113410), x10.rtt.Types.LONG))));
                        
                        //#line 756 "x10/compiler/Foreach.x10"
                        final $T t$113406 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce).$apply(myResult, $T, t$113405, $T))));
                        
                        //#line 756 "x10/compiler/Foreach.x10"
                        myResult = (($T)(t$113406));
                        
                        //#line 755 "x10/compiler/Foreach.x10"
                        final long t$113409 = ((i$113410) + (((long)(1L))));
                        
                        //#line 755 "x10/compiler/Foreach.x10"
                        i$113410 = t$113409;
                    }
                    
                    //#line 754 "x10/compiler/Foreach.x10"
                    final long t$113417 = ((i$113418) + (((long)(1L))));
                    
                    //#line 754 "x10/compiler/Foreach.x10"
                    i$113418 = t$113417;
                }
                
                //#line 759 "x10/compiler/Foreach.x10"
                return myResult;
            }
            
            public $T identity;
            public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            
            public $Closure$43(final x10.rtt.Type $T, final $T identity, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, __0x10$compiler$Foreach$$Closure$43$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$43$$T$2__2$1x10$compiler$Foreach$$Closure$43$$T$3x10$compiler$Foreach$$Closure$43$$T$3x10$compiler$Foreach$$Closure$43$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$43.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$43<$T>)this).identity = (($T)(identity));
                    ((x10.compiler.Foreach.$Closure$43<$T>)this).body = ((x10.core.fun.Fun_0_2)(body));
                    ((x10.compiler.Foreach.$Closure$43<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$44<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_4, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$44> $RTT = 
                x10.rtt.StaticFunType.<$Closure$44> make($Closure$44.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_4.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$44<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.body$111834 = $deserializer.readObject();
                $_obj.identity$111836 = $deserializer.readObject();
                $_obj.reduce$111835 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$44 $_obj = new x10.compiler.Foreach.$Closure$44((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.body$111834);
                $serializer.write(this.identity$111836);
                $serializer.write(this.reduce$111835);
                
            }
            
            // constructor just for allocation
            public $Closure$44(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$44.$initParams(this, $T);
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>U.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4));
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$44 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0x10$compiler$Foreach$$Closure$44$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$44$$T$2__2$1x10$compiler$Foreach$$Closure$44$$T$3x10$compiler$Foreach$$Closure$44$$T$3x10$compiler$Foreach$$Closure$44$$T$2 {}
            
        
            
            public $T $apply$G(final long min$111839, final long max$111840, final long min$111841, final long max$111842) {
                
                //#line 753 . "x10/compiler/Foreach.x10"
                $T myResult$111843 = (($T)(this.identity$111836));
                
                //#line 754 . "x10/compiler/Foreach.x10"
                long i$113456 = min$111839;
                
                //#line 754 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    final boolean t$113458 = ((i$113456) <= (((long)(max$111840))));
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    if (!(t$113458)) {
                        
                        //#line 754 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 755 . "x10/compiler/Foreach.x10"
                    long i$113448 = min$111841;
                    
                    //#line 755 . "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        final boolean t$113450 = ((i$113448) <= (((long)(max$111842))));
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        if (!(t$113450)) {
                            
                            //#line 755 . "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 756 . "x10/compiler/Foreach.x10"
                        final $T t$113443 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)this.body$111834).$apply(x10.core.Long.$box(i$113456), x10.rtt.Types.LONG, x10.core.Long.$box(i$113448), x10.rtt.Types.LONG))));
                        
                        //#line 756 . "x10/compiler/Foreach.x10"
                        final $T t$113444 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce$111835).$apply(myResult$111843, $T, t$113443, $T))));
                        
                        //#line 756 . "x10/compiler/Foreach.x10"
                        myResult$111843 = (($T)(t$113444));
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        final long t$113447 = ((i$113448) + (((long)(1L))));
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        i$113448 = t$113447;
                    }
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    final long t$113455 = ((i$113456) + (((long)(1L))));
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    i$113456 = t$113455;
                }
                
                //#line 759 . "x10/compiler/Foreach.x10"
                return myResult$111843;
            }
            
            public $T identity$111836;
            public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body$111834;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce$111835;
            
            public $Closure$44(final x10.rtt.Type $T, final $T identity$111836, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body$111834, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce$111835, __0x10$compiler$Foreach$$Closure$44$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$44$$T$2__2$1x10$compiler$Foreach$$Closure$44$$T$3x10$compiler$Foreach$$Closure$44$$T$3x10$compiler$Foreach$$Closure$44$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$44.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$44<$T>)this).identity$111836 = (($T)(identity$111836));
                    ((x10.compiler.Foreach.$Closure$44<$T>)this).body$111834 = ((x10.core.fun.Fun_0_2)(body$111834));
                    ((x10.compiler.Foreach.$Closure$44<$T>)this).reduce$111835 = ((x10.core.fun.Fun_0_2)(reduce$111835));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$45<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_4, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$45> $RTT = 
                x10.rtt.StaticFunType.<$Closure$45> make($Closure$45.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_4.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$45<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.body$111874 = $deserializer.readObject();
                $_obj.identity$111876 = $deserializer.readObject();
                $_obj.reduce$111875 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$45 $_obj = new x10.compiler.Foreach.$Closure$45((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.body$111874);
                $serializer.write(this.identity$111876);
                $serializer.write(this.reduce$111875);
                
            }
            
            // constructor just for allocation
            public $Closure$45(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$45.$initParams(this, $T);
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>U.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4));
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$45 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0x10$compiler$Foreach$$Closure$45$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$45$$T$2__2$1x10$compiler$Foreach$$Closure$45$$T$3x10$compiler$Foreach$$Closure$45$$T$3x10$compiler$Foreach$$Closure$45$$T$2 {}
            
        
            
            public $T $apply$G(final long min$111879, final long max$111880, final long min$111881, final long max$111882) {
                
                //#line 753 . "x10/compiler/Foreach.x10"
                $T myResult$111883 = (($T)(this.identity$111876));
                
                //#line 754 . "x10/compiler/Foreach.x10"
                long i$113494 = min$111879;
                
                //#line 754 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    final boolean t$113496 = ((i$113494) <= (((long)(max$111880))));
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    if (!(t$113496)) {
                        
                        //#line 754 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 755 . "x10/compiler/Foreach.x10"
                    long i$113486 = min$111881;
                    
                    //#line 755 . "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        final boolean t$113488 = ((i$113486) <= (((long)(max$111882))));
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        if (!(t$113488)) {
                            
                            //#line 755 . "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 756 . "x10/compiler/Foreach.x10"
                        final $T t$113481 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)this.body$111874).$apply(x10.core.Long.$box(i$113494), x10.rtt.Types.LONG, x10.core.Long.$box(i$113486), x10.rtt.Types.LONG))));
                        
                        //#line 756 . "x10/compiler/Foreach.x10"
                        final $T t$113482 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce$111875).$apply(myResult$111883, $T, t$113481, $T))));
                        
                        //#line 756 . "x10/compiler/Foreach.x10"
                        myResult$111883 = (($T)(t$113482));
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        final long t$113485 = ((i$113486) + (((long)(1L))));
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        i$113486 = t$113485;
                    }
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    final long t$113493 = ((i$113494) + (((long)(1L))));
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    i$113494 = t$113493;
                }
                
                //#line 759 . "x10/compiler/Foreach.x10"
                return myResult$111883;
            }
            
            public $T identity$111876;
            public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body$111874;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce$111875;
            
            public $Closure$45(final x10.rtt.Type $T, final $T identity$111876, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body$111874, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce$111875, __0x10$compiler$Foreach$$Closure$45$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$45$$T$2__2$1x10$compiler$Foreach$$Closure$45$$T$3x10$compiler$Foreach$$Closure$45$$T$3x10$compiler$Foreach$$Closure$45$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$45.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$45<$T>)this).identity$111876 = (($T)(identity$111876));
                    ((x10.compiler.Foreach.$Closure$45<$T>)this).body$111874 = ((x10.core.fun.Fun_0_2)(body$111874));
                    ((x10.compiler.Foreach.$Closure$45<$T>)this).reduce$111875 = ((x10.core.fun.Fun_0_2)(reduce$111875));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$46<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$46> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$46> make($Closure$46.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$46<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.$asyncResult$113622 = $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.e0 = $deserializer.readLong();
                $_obj.e1 = $deserializer.readLong();
                $_obj.g1 = $deserializer.readLong();
                $_obj.g2 = $deserializer.readLong();
                $_obj.reduce = $deserializer.readObject();
                $_obj.s0 = $deserializer.readLong();
                $_obj.s1 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$46 $_obj = new x10.compiler.Foreach.$Closure$46((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.$asyncResult$113622);
                $serializer.write(this.body);
                $serializer.write(this.e0);
                $serializer.write(this.e1);
                $serializer.write(this.g1);
                $serializer.write(this.g2);
                $serializer.write(this.reduce);
                $serializer.write(this.s0);
                $serializer.write(this.s1);
                
            }
            
            // constructor just for allocation
            public $Closure$46(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$46.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$46 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$46$$T$2__7$1x10$compiler$Foreach$$Closure$46$$T$3x10$compiler$Foreach$$Closure$46$$T$3x10$compiler$Foreach$$Closure$46$$T$2 {}
            
        
            
            public void $apply() {
                
                //#line 820 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 820 "x10/compiler/Foreach.x10"
                    final long t$112666 = ((this.s0) + (((long)(this.e0))));
                    
                    //#line 820 "x10/compiler/Foreach.x10"
                    final long t$112667 = ((t$112666) / (((long)(2L))));
                    
                    //#line 820 "x10/compiler/Foreach.x10"
                    final $T t$112668 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(t$112667), (long)(this.e0), (long)(this.s1), (long)(this.e1), (long)(this.g1), (long)(this.g2), ((x10.core.fun.Fun_0_4)(this.body)), ((x10.core.fun.Fun_0_2)(this.reduce)))));
                    
                    //#line 820 "x10/compiler/Foreach.x10"
                    this.$asyncResult$113622[(int)0]=t$112668;
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 820 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 820 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long s0;
            public long e0;
            public long s1;
            public long e1;
            public long g1;
            public long g2;
            public x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            public $T[] $asyncResult$113622;
            
            public $Closure$46(final x10.rtt.Type $T, final long s0, final long e0, final long s1, final long e1, final long g1, final long g2, final x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T[] $asyncResult$113622, __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$46$$T$2__7$1x10$compiler$Foreach$$Closure$46$$T$3x10$compiler$Foreach$$Closure$46$$T$3x10$compiler$Foreach$$Closure$46$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$46.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).s0 = s0;
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).e0 = e0;
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).s1 = s1;
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).e1 = e1;
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).g1 = g1;
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).g2 = g2;
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).body = ((x10.core.fun.Fun_0_4)(body));
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).$asyncResult$113622 = $asyncResult$113622;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$47<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$47> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$47> make($Closure$47.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$47<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.$asyncResult$113623 = $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.e0 = $deserializer.readLong();
                $_obj.e1 = $deserializer.readLong();
                $_obj.g1 = $deserializer.readLong();
                $_obj.g2 = $deserializer.readLong();
                $_obj.reduce = $deserializer.readObject();
                $_obj.s0 = $deserializer.readLong();
                $_obj.s1 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$47 $_obj = new x10.compiler.Foreach.$Closure$47((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.$asyncResult$113623);
                $serializer.write(this.body);
                $serializer.write(this.e0);
                $serializer.write(this.e1);
                $serializer.write(this.g1);
                $serializer.write(this.g2);
                $serializer.write(this.reduce);
                $serializer.write(this.s0);
                $serializer.write(this.s1);
                
            }
            
            // constructor just for allocation
            public $Closure$47(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$47.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$47 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$47$$T$2__7$1x10$compiler$Foreach$$Closure$47$$T$3x10$compiler$Foreach$$Closure$47$$T$3x10$compiler$Foreach$$Closure$47$$T$2 {}
            
        
            
            public void $apply() {
                
                //#line 828 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 828 "x10/compiler/Foreach.x10"
                    final long t$112674 = ((this.s1) + (((long)(this.e1))));
                    
                    //#line 828 "x10/compiler/Foreach.x10"
                    final long t$112675 = ((t$112674) / (((long)(2L))));
                    
                    //#line 828 "x10/compiler/Foreach.x10"
                    final $T t$112676 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(this.s0), (long)(this.e0), (long)(t$112675), (long)(this.e1), (long)(this.g1), (long)(this.g2), ((x10.core.fun.Fun_0_4)(this.body)), ((x10.core.fun.Fun_0_2)(this.reduce)))));
                    
                    //#line 828 "x10/compiler/Foreach.x10"
                    this.$asyncResult$113623[(int)0]=t$112676;
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 828 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 828 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long s1;
            public long e1;
            public long s0;
            public long e0;
            public long g1;
            public long g2;
            public x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            public $T[] $asyncResult$113623;
            
            public $Closure$47(final x10.rtt.Type $T, final long s1, final long e1, final long s0, final long e0, final long g1, final long g2, final x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T[] $asyncResult$113623, __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$47$$T$2__7$1x10$compiler$Foreach$$Closure$47$$T$3x10$compiler$Foreach$$Closure$47$$T$3x10$compiler$Foreach$$Closure$47$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$47.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).s1 = s1;
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).e1 = e1;
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).s0 = s0;
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).e0 = e0;
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).g1 = g1;
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).g2 = g2;
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).body = ((x10.core.fun.Fun_0_4)(body));
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).$asyncResult$113623 = $asyncResult$113623;
                }
            }
            
        }
        
    }
    
    