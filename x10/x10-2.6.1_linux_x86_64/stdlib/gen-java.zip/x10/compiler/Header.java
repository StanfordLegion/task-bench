package x10.compiler;


/**
 * This annotation is used to allow the programmer
 * to direct the compiler to mark the method as 'inline'
 * in the C++ backend and generate code for it in the
 * header file.
 * WARNING: This annotation can only
 * be correctly applied to methods of generic types
 * and to methods whose bodies only operate
 * on fields/methods of the annotated method's class
 * and on primitive structs.  If the annotation is
 * improperly applied, the generated C++ code won't
 * compile.
 */
@x10.runtime.impl.java.X10Generated
public interface Header extends x10.lang.annotations.MethodAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Header> $RTT = 
        x10.rtt.NamedType.<Header> make("x10.compiler.Header",
                                        Header.class,
                                        new x10.rtt.Type[] {
                                            x10.lang.annotations.MethodAnnotation.$RTT
                                        });
    
    
}

