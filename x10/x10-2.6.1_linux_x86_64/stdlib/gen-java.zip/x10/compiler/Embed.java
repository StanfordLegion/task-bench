package x10.compiler;


/** An annotation that requests the compiler to embed an object inside another object
 * must be used *exactly* as the following for now:
 * <code>
 * class C {
 *   @Embed val v:T;
 *   def this() {
 *     v = @Embed new T(...);
 *   }
 * }
 * </code>
 * EXPERIMENTAL
 */
@x10.runtime.impl.java.X10Generated
public interface Embed extends x10.lang.annotations.FieldAnnotation, x10.lang.annotations.StatementAnnotation, x10.lang.annotations.ExpressionAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Embed> $RTT = 
        x10.rtt.NamedType.<Embed> make("x10.compiler.Embed",
                                       Embed.class,
                                       new x10.rtt.Type[] {
                                           x10.lang.annotations.FieldAnnotation.$RTT,
                                           x10.lang.annotations.StatementAnnotation.$RTT,
                                           x10.lang.annotations.ExpressionAnnotation.$RTT
                                       });
    
    
}

