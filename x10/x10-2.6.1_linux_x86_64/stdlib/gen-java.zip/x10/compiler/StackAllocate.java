package x10.compiler;


/** An annotation that requests the compiler to stack allocate an object
 * must be used *exactly* as the following for now:
 *   @StackAllocate val v = @StackAllocate new T(...);
 * EXPERIMENTAL
 */
@x10.runtime.impl.java.X10Generated
public interface StackAllocate extends x10.lang.annotations.ExpressionAnnotation, x10.lang.annotations.StatementAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<StackAllocate> $RTT = 
        x10.rtt.NamedType.<StackAllocate> make("x10.compiler.StackAllocate",
                                               StackAllocate.class,
                                               new x10.rtt.Type[] {
                                                   x10.lang.annotations.ExpressionAnnotation.$RTT,
                                                   x10.lang.annotations.StatementAnnotation.$RTT
                                               });
    
    
}

