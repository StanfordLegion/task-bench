package x10.compiler;


/**
 * This annotation is used to allow the programmer
 * to direct the compiler to unconditionally inline
 * the annotated method (or call) whenever a call expression is
 * statically resolved to invoke the method.</p>
 *
 * This annotation is processed by the X10 compiler's
 * common optimizer.
 */
@x10.runtime.impl.java.X10Generated
public interface Inline extends x10.lang.annotations.MethodAnnotation, x10.lang.annotations.ExpressionAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Inline> $RTT = 
        x10.rtt.NamedType.<Inline> make("x10.compiler.Inline",
                                        Inline.class,
                                        new x10.rtt.Type[] {
                                            x10.lang.annotations.MethodAnnotation.$RTT,
                                            x10.lang.annotations.ExpressionAnnotation.$RTT
                                        });
    
    
}

