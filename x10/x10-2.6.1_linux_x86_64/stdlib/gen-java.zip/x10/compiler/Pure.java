package x10.compiler;


/**
 * This annotation is used to allow the programmer
 * to permit the compiler to delete this expression
 * or call to this method if its result is not used.</p>
 *
 * This annotation is processed by the X10 compiler's
 * common optimizer.
 */
@x10.runtime.impl.java.X10Generated
public interface Pure extends x10.lang.annotations.MethodAnnotation, x10.lang.annotations.ExpressionAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Pure> $RTT = 
        x10.rtt.NamedType.<Pure> make("x10.compiler.Pure",
                                      Pure.class,
                                      new x10.rtt.Type[] {
                                          x10.lang.annotations.MethodAnnotation.$RTT,
                                          x10.lang.annotations.ExpressionAnnotation.$RTT
                                      });
    
    
}

