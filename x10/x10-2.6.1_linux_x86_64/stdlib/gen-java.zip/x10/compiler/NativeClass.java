package x10.compiler;


@x10.runtime.impl.java.X10Generated
public interface NativeClass extends x10.lang.annotations.ClassAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<NativeClass> $RTT = 
        x10.rtt.NamedType.<NativeClass> make("x10.compiler.NativeClass",
                                             NativeClass.class,
                                             new x10.rtt.Type[] {
                                                 x10.lang.annotations.ClassAnnotation.$RTT
                                             });
    
    
}

