package x10.compiler;


/**
 * Annotation to mark a static native method that should resolve to a native c++ function
 * with the given name and arguments. Has no effect in the Java backend.
 *
 * Restrictions (not enforced):
 * Non-generic methods only.
 * Method may be void or return a primitive numerical type.
 * Boolean, Byte, Char, Double, Float, Int, Long, Short, UByte, UInt, ULong, UShort.
 * Permitted argument types are the primitive numerical types and arrays of primitive numerical types.
 *
 * For arrays, the native method should expect a pointer to the backing storage.
 */
@x10.runtime.impl.java.X10Generated
public interface NativeCPPExtern extends x10.lang.annotations.MethodAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<NativeCPPExtern> $RTT = 
        x10.rtt.NamedType.<NativeCPPExtern> make("x10.compiler.NativeCPPExtern",
                                                 NativeCPPExtern.class,
                                                 new x10.rtt.Type[] {
                                                     x10.lang.annotations.MethodAnnotation.$RTT
                                                 });
    
    
}

