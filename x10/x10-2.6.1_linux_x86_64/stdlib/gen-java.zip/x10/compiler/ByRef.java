package x10.compiler;


/** An annotation on a struct that instructs the C++ backend to pass instances
 * of this struct by reference and not value.
 */
@x10.runtime.impl.java.X10Generated
public interface ByRef extends x10.lang.annotations.ClassAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<ByRef> $RTT = 
        x10.rtt.NamedType.<ByRef> make("x10.compiler.ByRef",
                                       ByRef.class,
                                       new x10.rtt.Type[] {
                                           x10.lang.annotations.ClassAnnotation.$RTT
                                       });
    
    
}

