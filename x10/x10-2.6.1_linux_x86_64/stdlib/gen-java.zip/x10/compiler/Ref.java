package x10.compiler;


/**
 * This annotation on an async specifies that variable v should be captured by reference. */
@x10.runtime.impl.java.X10Generated
public interface Ref<$T> extends x10.lang.annotations.StatementAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Ref> $RTT = 
        x10.rtt.NamedType.<Ref> make("x10.compiler.Ref",
                                     Ref.class,
                                     1,
                                     new x10.rtt.Type[] {
                                         x10.lang.annotations.StatementAnnotation.$RTT
                                     });
    
    

    
    
    //#line 20 "x10/compiler/Ref.x10"
    $T id$G();
}

