package x10.compiler;


/**
 * Temporary. Processed by WSCodeGenerator.
 */
@x10.runtime.impl.java.X10Generated
public interface Ephemeral extends x10.lang.annotations.StatementAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Ephemeral> $RTT = 
        x10.rtt.NamedType.<Ephemeral> make("x10.compiler.Ephemeral",
                                           Ephemeral.class,
                                           new x10.rtt.Type[] {
                                               x10.lang.annotations.StatementAnnotation.$RTT
                                           });
    
    
}

