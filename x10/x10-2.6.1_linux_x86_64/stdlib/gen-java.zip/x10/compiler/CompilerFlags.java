package x10.compiler;

/** 
 * A class that allows transmission of compiler command line 
 * flags to to code in the class libraries that wants to check
 * compilation modes.
 */
@x10.runtime.impl.java.X10Generated
public class CompilerFlags extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<CompilerFlags> $RTT = 
        x10.rtt.NamedType.<CompilerFlags> make("x10.compiler.CompilerFlags",
                                               CompilerFlags.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.CompilerFlags $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.CompilerFlags $_obj = new x10.compiler.CompilerFlags((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public CompilerFlags(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 25 "x10/compiler/CompilerFlags.x10"
    /**
     * @return <code>true</code> if the compiler was invoked with
     *          the -NO_CHECKS flags, <code>false</code> otherwise.
     */
    public static boolean checkBounds$O() {
        try {
            return (!false);
        }
        catch (java.lang.Throwable exc$205528) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205528);
        }
        
    }
    
    
    
    //#line 34 "x10/compiler/CompilerFlags.x10"
    /**
     * @return <code>true</code> if the compiler was invoked with
     *          the -NO_CHECKS flags, <code>false</code> otherwise.
     */
    public static boolean checkPlace$O() {
        try {
            return (!false);
        }
        catch (java.lang.Throwable exc$205529) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205529);
        }
        
    }
    
    
    
    //#line 42 "x10/compiler/CompilerFlags.x10"
    /**
     * Should bounds checking operations be optimized by using unsigned compares
     */
    public static boolean useUnsigned$O() {
        try {
            return true;
        }
        catch (java.lang.Throwable exc$205530) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205530);
        }
        
    }
    
    
    
    //#line 49 "x10/compiler/CompilerFlags.x10"
    /**
     * A false that is not understood by the constant propagator
     */
    public static boolean FALSE$O() {
        try {
            return false;
        }
        catch (java.lang.Throwable exc$205531) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205531);
        }
        
    }
    
    
    
    //#line 56 "x10/compiler/CompilerFlags.x10"
    /**
     * A "true" that is not understood by the constant propagator
     */
    public static boolean TRUE$O() {
        try {
            return true;
        }
        catch (java.lang.Throwable exc$205532) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205532);
        }
        
    }
    
    
    
    //#line 19 "x10/compiler/CompilerFlags.x10"
    final public x10.compiler.CompilerFlags x10$compiler$CompilerFlags$$this$x10$compiler$CompilerFlags() {
        
        //#line 19 "x10/compiler/CompilerFlags.x10"
        return x10.compiler.CompilerFlags.this;
    }
    
    
    //#line 19 "x10/compiler/CompilerFlags.x10"
    // creation method for java code (1-phase java constructor)
    public CompilerFlags() {
        this((java.lang.System[]) null);
        x10$compiler$CompilerFlags$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.compiler.CompilerFlags x10$compiler$CompilerFlags$$init$S() {
         {
            
            //#line 19 "x10/compiler/CompilerFlags.x10"
            
        }
        return this;
    }
    
    
    
    //#line 19 "x10/compiler/CompilerFlags.x10"
    final public void __fieldInitializers_x10_compiler_CompilerFlags() {
        
    }
}

