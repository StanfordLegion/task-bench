package x10.compiler.ws;


@x10.runtime.impl.java.X10Generated
abstract public class FinishFrame extends x10.compiler.ws.Frame implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<FinishFrame> $RTT = 
        x10.rtt.NamedType.<FinishFrame> make("x10.compiler.ws.FinishFrame",
                                             FinishFrame.class,
                                             new x10.rtt.Type[] {
                                                 x10.compiler.ws.Frame.$RTT
                                             });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.FinishFrame $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.ws.Frame.$_deserialize_body($_obj, $deserializer);
        $_obj.asyncs = $deserializer.readInt();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.asyncs);
        
    }
    
    // constructor just for allocation
    public FinishFrame(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 27 "x10/compiler/ws/FinishFrame.x10"
    public int asyncs;
    
    //#line 28 "x10/compiler/ws/FinishFrame.x10"
    public transient x10.util.GrowableRail<java.lang.Throwable> exceptions;
    
    
    //#line 33 "x10/compiler/ws/FinishFrame.x10"
    
    // constructor for non-virtual call
    final public x10.compiler.ws.FinishFrame x10$compiler$ws$FinishFrame$$init$S(final x10.compiler.ws.Frame up) {
         {
            
            //#line 34 "x10/compiler/ws/FinishFrame.x10"
            final x10.compiler.ws.Frame this$115518 = this;
            
            //#line 31 . "x10/compiler/ws/Frame.x10"
            this$115518.up = ((x10.compiler.ws.Frame)(up));
            
            //#line 33 "x10/compiler/ws/FinishFrame.x10"
            
            
            //#line 35 "x10/compiler/ws/FinishFrame.x10"
            this.exceptions = null;
            {
                
                //#line 40 "x10/compiler/ws/FinishFrame.x10"
                this.asyncs = 1;
            }
        }
        return this;
    }
    
    
    
    //#line 70 "x10/compiler/ws/FinishFrame.x10"
    public void wrapBack(final x10.compiler.ws.Worker worker, final x10.compiler.ws.Frame frame) {
        
        //#line 71 "x10/compiler/ws/FinishFrame.x10"
        final java.lang.RuntimeException t$116510 = ((java.lang.RuntimeException)(worker.throwable));
        
        //#line 71 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116512 = ((null) != (t$116510));
        
        //#line 71 "x10/compiler/ws/FinishFrame.x10"
        if (t$116512) {
            
            //#line 73 "x10/compiler/ws/FinishFrame.x10"
            final java.lang.RuntimeException t$116511 = ((java.lang.RuntimeException)(worker.throwable));
            
            //#line 73 "x10/compiler/ws/FinishFrame.x10"
            this.caught(((java.lang.Throwable)(t$116511)));
            
            //#line 74 "x10/compiler/ws/FinishFrame.x10"
            worker.throwable = null;
        }
    }
    
    
    //#line 79 "x10/compiler/ws/FinishFrame.x10"
    public void wrapResume(final x10.compiler.ws.Worker worker) {
        
        //#line 80 "x10/compiler/ws/FinishFrame.x10"
        int n =  0;
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.concurrent.Monitor t$116513 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        t$116513.lock();
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        final int t$116514 = this.asyncs;
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        final int t$116515 = ((t$116514) - (((int)(1))));
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        final int t$116516 = this.asyncs = t$116515;
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        n = t$116516;
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.concurrent.Monitor t$116517 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        t$116517.unlock();
        
        //#line 82 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116520 = ((int) 0) != ((int) n);
        
        //#line 82 "x10/compiler/ws/FinishFrame.x10"
        if (t$116520) {
            
            //#line 82 "x10/compiler/ws/FinishFrame.x10"
            final x10.compiler.Abort t$116519 = ((x10.compiler.Abort)(x10.compiler.Abort.get$ABORT()));
            
            //#line 82 "x10/compiler/ws/FinishFrame.x10"
            throw t$116519;
        }
        
        //#line 83 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$116521 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 83 "x10/compiler/ws/FinishFrame.x10"
        final x10.lang.MultipleExceptions t$116522 = x10.lang.MultipleExceptions.make__0$1x10$lang$CheckedThrowable$2(((x10.util.GrowableRail)(t$116521)));
        
        //#line 83 "x10/compiler/ws/FinishFrame.x10"
        worker.throwable = ((java.lang.RuntimeException)(t$116522));
    }
    
    
    //#line 86 "x10/compiler/ws/FinishFrame.x10"
    final public void append__0$1x10$lang$CheckedThrowable$2(final x10.util.GrowableRail s) {
        
        //#line 87 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116532 = ((null) != (s));
        
        //#line 87 "x10/compiler/ws/FinishFrame.x10"
        if (t$116532) {
            
            //#line 88 "x10/compiler/ws/FinishFrame.x10"
            final x10.util.concurrent.Monitor t$116523 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 88 "x10/compiler/ws/FinishFrame.x10"
            t$116523.lock();
            
            //#line 89 "x10/compiler/ws/FinishFrame.x10"
            final x10.util.GrowableRail t$116524 = ((x10.util.GrowableRail)(this.exceptions));
            
            //#line 89 "x10/compiler/ws/FinishFrame.x10"
            final boolean t$116525 = ((null) == (t$116524));
            
            //#line 89 "x10/compiler/ws/FinishFrame.x10"
            if (t$116525) {
                
                //#line 89 "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail alloc$115242 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
                
                //#line 50 . "x10/util/GrowableRail.x10"
                alloc$115242.x10$util$GrowableRail$$init$S(((long)(0L)));
                
                //#line 89 "x10/compiler/ws/FinishFrame.x10"
                this.exceptions = ((x10.util.GrowableRail)(alloc$115242));
            }
            
            //#line 90 "x10/compiler/ws/FinishFrame.x10"
            while (true) {
                
                //#line 160 . "x10/util/GrowableRail.x10"
                final long t$116526 = ((x10.util.GrowableRail<java.lang.Throwable>)s).size;
                
                //#line 160 . "x10/util/GrowableRail.x10"
                final boolean t$116527 = ((long) t$116526) == ((long) 0L);
                
                //#line 90 "x10/compiler/ws/FinishFrame.x10"
                final boolean t$116530 = !(t$116527);
                
                //#line 90 "x10/compiler/ws/FinishFrame.x10"
                if (!(t$116530)) {
                    
                    //#line 90 "x10/compiler/ws/FinishFrame.x10"
                    break;
                }
                
                //#line 90 "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail t$116563 = ((x10.util.GrowableRail)(this.exceptions));
                
                //#line 90 "x10/compiler/ws/FinishFrame.x10"
                final java.lang.Throwable t$116564 = ((x10.util.GrowableRail<java.lang.Throwable>)s).removeLast$G();
                
                //#line 90 "x10/compiler/ws/FinishFrame.x10"
                ((x10.util.GrowableRail<java.lang.Throwable>)t$116563).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(t$116564)));
            }
            
            //#line 91 "x10/compiler/ws/FinishFrame.x10"
            final x10.util.concurrent.Monitor t$116531 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 91 "x10/compiler/ws/FinishFrame.x10"
            t$116531.unlock();
        }
    }
    
    
    //#line 95 "x10/compiler/ws/FinishFrame.x10"
    final public void append(final x10.compiler.ws.FinishFrame ff) {
        
        //#line 96 "x10/compiler/ws/FinishFrame.x10"
        final x10.compiler.ws.FinishFrame this$116503 = ((x10.compiler.ws.FinishFrame)(this));
        
        //#line 96 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail s$116501 = ((x10.util.GrowableRail)(ff.exceptions));
        
        //#line 87 . "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116567 = ((null) != (s$116501));
        
        //#line 87 . "x10/compiler/ws/FinishFrame.x10"
        if (t$116567) {
            
            //#line 88 . "x10/compiler/ws/FinishFrame.x10"
            final x10.util.concurrent.Monitor t$116568 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 88 . "x10/compiler/ws/FinishFrame.x10"
            t$116568.lock();
            
            //#line 89 . "x10/compiler/ws/FinishFrame.x10"
            final x10.util.GrowableRail t$116569 = ((x10.util.GrowableRail)(this$116503.exceptions));
            
            //#line 89 . "x10/compiler/ws/FinishFrame.x10"
            final boolean t$116570 = ((null) == (t$116569));
            
            //#line 89 . "x10/compiler/ws/FinishFrame.x10"
            if (t$116570) {
                
                //#line 89 . "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail alloc$116571 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
                
                //#line 50 .. "x10/util/GrowableRail.x10"
                alloc$116571.x10$util$GrowableRail$$init$S(((long)(0L)));
                
                //#line 89 . "x10/compiler/ws/FinishFrame.x10"
                this$116503.exceptions = ((x10.util.GrowableRail)(alloc$116571));
            }
            
            //#line 90 . "x10/compiler/ws/FinishFrame.x10"
            while (true) {
                
                //#line 160 .. "x10/util/GrowableRail.x10"
                final long t$116572 = ((x10.util.GrowableRail<java.lang.Throwable>)s$116501).size;
                
                //#line 160 .. "x10/util/GrowableRail.x10"
                final boolean t$116573 = ((long) t$116572) == ((long) 0L);
                
                //#line 90 . "x10/compiler/ws/FinishFrame.x10"
                final boolean t$116574 = !(t$116573);
                
                //#line 90 . "x10/compiler/ws/FinishFrame.x10"
                if (!(t$116574)) {
                    
                    //#line 90 . "x10/compiler/ws/FinishFrame.x10"
                    break;
                }
                
                //#line 90 . "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail t$116565 = ((x10.util.GrowableRail)(this$116503.exceptions));
                
                //#line 90 . "x10/compiler/ws/FinishFrame.x10"
                final java.lang.Throwable t$116566 = ((x10.util.GrowableRail<java.lang.Throwable>)s$116501).removeLast$G();
                
                //#line 90 . "x10/compiler/ws/FinishFrame.x10"
                ((x10.util.GrowableRail<java.lang.Throwable>)t$116565).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(t$116566)));
            }
            
            //#line 91 . "x10/compiler/ws/FinishFrame.x10"
            final x10.util.concurrent.Monitor t$116575 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 91 . "x10/compiler/ws/FinishFrame.x10"
            t$116575.unlock();
        }
    }
    
    
    //#line 99 "x10/compiler/ws/FinishFrame.x10"
    final public void caught(final java.lang.Throwable t) {
        
        //#line 101 "x10/compiler/ws/FinishFrame.x10"
        final x10.compiler.Abort t$116543 = ((x10.compiler.Abort)(x10.compiler.Abort.get$ABORT()));
        
        //#line 101 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116545 = x10.rtt.Equality.equalsequals((t),(t$116543));
        
        //#line 101 "x10/compiler/ws/FinishFrame.x10"
        if (t$116545) {
            
            //#line 101 "x10/compiler/ws/FinishFrame.x10"
            final x10.compiler.Abort t$116544 = ((x10.compiler.Abort)(x10.compiler.Abort.get$ABORT()));
            
            //#line 101 "x10/compiler/ws/FinishFrame.x10"
            throw t$116544;
        }
        
        //#line 102 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.concurrent.Monitor t$116546 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
        
        //#line 102 "x10/compiler/ws/FinishFrame.x10"
        t$116546.lock();
        
        //#line 103 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$116547 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 103 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116548 = ((null) == (t$116547));
        
        //#line 103 "x10/compiler/ws/FinishFrame.x10"
        if (t$116548) {
            
            //#line 103 "x10/compiler/ws/FinishFrame.x10"
            final x10.util.GrowableRail alloc$115243 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            alloc$115243.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 103 "x10/compiler/ws/FinishFrame.x10"
            this.exceptions = ((x10.util.GrowableRail)(alloc$115243));
        }
        
        //#line 104 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$116549 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 104 "x10/compiler/ws/FinishFrame.x10"
        ((x10.util.GrowableRail<java.lang.Throwable>)t$116549).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(t)));
        
        //#line 105 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.concurrent.Monitor t$116550 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
        
        //#line 105 "x10/compiler/ws/FinishFrame.x10"
        t$116550.unlock();
    }
    
    
    //#line 108 "x10/compiler/ws/FinishFrame.x10"
    final public void rethrow() {
        
        //#line 109 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$116551 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 109 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116552 = ((null) != (t$116551));
        
        //#line 109 "x10/compiler/ws/FinishFrame.x10"
        if (t$116552) {
            
            //#line 109 "x10/compiler/ws/FinishFrame.x10"
            this.rethrowSlow();
        }
    }
    
    
    //#line 112 "x10/compiler/ws/FinishFrame.x10"
    final public void rethrowSlow() {
        
        //#line 113 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$116553 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 113 "x10/compiler/ws/FinishFrame.x10"
        final x10.lang.MultipleExceptions t$116554 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(t$116553, (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
        
        //#line 113 "x10/compiler/ws/FinishFrame.x10"
        throw t$116554;
    }
    
    
    //#line 116 "x10/compiler/ws/FinishFrame.x10"
    final public void check() {
        
        //#line 117 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$116555 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 117 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116561 = ((null) != (t$116555));
        
        //#line 117 "x10/compiler/ws/FinishFrame.x10"
        if (t$116561) {
            
            //#line 118 "x10/compiler/ws/FinishFrame.x10"
            while (true) {
                
                //#line 118 "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail this$116508 = ((x10.util.GrowableRail)(this.exceptions));
                
                //#line 160 . "x10/util/GrowableRail.x10"
                final long t$116556 = ((x10.util.GrowableRail<java.lang.Throwable>)this$116508).size;
                
                //#line 160 . "x10/util/GrowableRail.x10"
                final boolean t$116557 = ((long) t$116556) == ((long) 0L);
                
                //#line 118 "x10/compiler/ws/FinishFrame.x10"
                final boolean t$116560 = !(t$116557);
                
                //#line 118 "x10/compiler/ws/FinishFrame.x10"
                if (!(t$116560)) {
                    
                    //#line 118 "x10/compiler/ws/FinishFrame.x10"
                    break;
                }
                
                //#line 119 "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail t$116576 = ((x10.util.GrowableRail)(this.exceptions));
                
                //#line 119 "x10/compiler/ws/FinishFrame.x10"
                final java.lang.Throwable t$116577 = ((x10.util.GrowableRail<java.lang.Throwable>)t$116576).removeLast$G();
                
                //#line 119 "x10/compiler/ws/FinishFrame.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(t$116577)));
            }
        }
    }
    
    
    //#line 26 "x10/compiler/ws/FinishFrame.x10"
    final public x10.compiler.ws.FinishFrame x10$compiler$ws$FinishFrame$$this$x10$compiler$ws$FinishFrame() {
        
        //#line 26 "x10/compiler/ws/FinishFrame.x10"
        return x10.compiler.ws.FinishFrame.this;
    }
    
    
    //#line 26 "x10/compiler/ws/FinishFrame.x10"
    final public void __fieldInitializers_x10_compiler_ws_FinishFrame() {
        
    }
}

