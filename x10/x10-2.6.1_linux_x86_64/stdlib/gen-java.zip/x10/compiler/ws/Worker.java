package x10.compiler.ws;


@x10.runtime.impl.java.X10Generated
final public class Worker extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Worker> $RTT = 
        x10.rtt.NamedType.<Worker> make("x10.compiler.ws.Worker",
                                        Worker.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.Worker $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.deque = $deserializer.readObject();
        $_obj.fifo = $deserializer.readObject();
        $_obj.id = $deserializer.readInt();
        $_obj.lock = $deserializer.readObject();
        $_obj.random = $deserializer.readObject();
        $_obj.throwable = $deserializer.readObject();
        $_obj.workers = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.ws.Worker $_obj = new x10.compiler.ws.Worker((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.deque);
        $serializer.write(this.fifo);
        $serializer.write(this.id);
        $serializer.write(this.lock);
        $serializer.write(this.random);
        $serializer.write(this.throwable);
        $serializer.write(this.workers);
        
    }
    
    // constructor just for allocation
    public Worker(final java.lang.System[] $dummy) {
        
    }
    
    // synthetic type for parameter mangling
    public static final class __1$1x10$compiler$ws$Worker$2 {}
    

    
    //#line 24 "x10/compiler/ws/Worker.x10"
    public x10.core.Rail<x10.compiler.ws.Worker> workers;
    
    //#line 25 "x10/compiler/ws/Worker.x10"
    public x10.util.Random random;
    
    //#line 27 "x10/compiler/ws/Worker.x10"
    public int id;
    
    //#line 28 "x10/compiler/ws/Worker.x10"
    public x10.core.Deque deque;
    
    //#line 29 "x10/compiler/ws/Worker.x10"
    public x10.core.Deque fifo;
    
    //#line 30 "x10/compiler/ws/Worker.x10"
    public x10.util.concurrent.Lock lock;
    
    //#line 32 "x10/compiler/ws/Worker.x10"
    public java.lang.RuntimeException throwable;
    
    
    //#line 34 "x10/compiler/ws/Worker.x10"
    // creation method for java code (1-phase java constructor)
    public Worker(final int i, final x10.core.Rail<x10.compiler.ws.Worker> workers, __1$1x10$compiler$ws$Worker$2 $dummy) {
        this((java.lang.System[]) null);
        x10$compiler$ws$Worker$$init$S(i, workers, (x10.compiler.ws.Worker.__1$1x10$compiler$ws$Worker$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.compiler.ws.Worker x10$compiler$ws$Worker$$init$S(final int i, final x10.core.Rail<x10.compiler.ws.Worker> workers, __1$1x10$compiler$ws$Worker$2 $dummy) {
         {
            
            //#line 34 "x10/compiler/ws/Worker.x10"
            
            
            //#line 23 "x10/compiler/ws/Worker.x10"
            this.__fieldInitializers_x10_compiler_ws_Worker();
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final x10.util.Random alloc$115227 = ((x10.util.Random)(new x10.util.Random((java.lang.System[]) null)));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final long t$117277 = ((long)(((int)(8))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final int t$117278 = ((i) << (int)(((long)(t$117277))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final int t$117280 = ((i) + (((int)(t$117278))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final long t$117279 = ((long)(((int)(16))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final int t$117281 = ((i) << (int)(((long)(t$117279))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final int t$117283 = ((t$117280) + (((int)(t$117281))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final long t$117282 = ((long)(((int)(24))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final int t$117284 = ((i) << (int)(((long)(t$117282))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final int t$117285 = ((t$117283) + (((int)(t$117284))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final long seed$117243 = ((long)(((int)(t$117285))));
            
            //#line 24 ... "x10/util/Random.x10"
            alloc$115227.seed = 0L;
            
            //#line 24 ... "x10/util/Random.x10"
            alloc$115227.storedGaussian = 0.0;
            
            //#line 24 ... "x10/util/Random.x10"
            alloc$115227.haveStoredGaussian = false;
            
            //#line 36 .. "x10/util/Random.x10"
            alloc$115227.seed = seed$117243;
            
            //#line 37 .. "x10/util/Random.x10"
            alloc$115227.gamma = -7046029254386353131L;
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            this.random = ((x10.util.Random)(alloc$115227));
            
            //#line 36 "x10/compiler/ws/Worker.x10"
            this.id = i;
            
            //#line 37 "x10/compiler/ws/Worker.x10"
            this.workers = ((x10.core.Rail)(workers));
        }
        return this;
    }
    
    
    
    //#line 40 "x10/compiler/ws/Worker.x10"
    public void migrate() {
        
        //#line 41 "x10/compiler/ws/Worker.x10"
        x10.compiler.ws.RegularFrame k =  null;
        
        //#line 42 "x10/compiler/ws/Worker.x10"
        final x10.util.concurrent.Lock t$117286 = ((x10.util.concurrent.Lock)(this.lock));
        
        //#line 42 "x10/compiler/ws/Worker.x10"
        t$117286.lock();
        
        //#line 43 "x10/compiler/ws/Worker.x10"
        while (true) {
            
            //#line 43 "x10/compiler/ws/Worker.x10"
            final x10.core.Deque t$117287 = ((x10.core.Deque)(this.deque));
            
            //#line 43 "x10/compiler/ws/Worker.x10"
            final java.lang.Object t$117288 = t$117287.steal();
            
            //#line 43 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.RegularFrame t$117289 = ((x10.compiler.ws.RegularFrame) t$117288);
            
            //#line 43 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.RegularFrame t$117290 = k = ((x10.compiler.ws.RegularFrame)(t$117289));
            
            //#line 43 "x10/compiler/ws/Worker.x10"
            final boolean t$117298 = ((null) != (t$117290));
            
            //#line 43 "x10/compiler/ws/Worker.x10"
            if (!(t$117298)) {
                
                //#line 43 "x10/compiler/ws/Worker.x10"
                break;
            }
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            final x10.util.concurrent.Monitor t$117403 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            t$117403.lock();
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.FinishFrame obj$117405 = ((x10.compiler.ws.FinishFrame)(t$117289.ff));
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            final int t$117406 = obj$117405.asyncs;
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            final int t$117407 = ((t$117406) + (((int)(1))));
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            obj$117405.asyncs = t$117407;
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            final x10.util.concurrent.Monitor t$117408 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            t$117408.unlock();
            
            //#line 48 "x10/compiler/ws/Worker.x10"
            final x10.core.Deque t$117409 = ((x10.core.Deque)(this.fifo));
            
            //#line 48 "x10/compiler/ws/Worker.x10"
            t$117409.push(((java.lang.Object)(t$117289)));
        }
        
        //#line 50 "x10/compiler/ws/Worker.x10"
        final x10.util.concurrent.Lock t$117299 = ((x10.util.concurrent.Lock)(this.lock));
        
        //#line 50 "x10/compiler/ws/Worker.x10"
        t$117299.unlock();
    }
    
    
    //#line 53 "x10/compiler/ws/Worker.x10"
    public void run() {
        
        //#line 54 "x10/compiler/ws/Worker.x10"
        try {{
            
            //#line 55 "x10/compiler/ws/Worker.x10"
            while (true) {
                
                //#line 56 "x10/compiler/ws/Worker.x10"
                final java.lang.Object k = this.find();
                
                //#line 57 "x10/compiler/ws/Worker.x10"
                final boolean t$117300 = ((null) == (k));
                
                //#line 57 "x10/compiler/ws/Worker.x10"
                if (t$117300) {
                    
                    //#line 57 "x10/compiler/ws/Worker.x10"
                    return;
                }
                
                //#line 58 "x10/compiler/ws/Worker.x10"
                try {{
                    
                    //#line 59 "x10/compiler/ws/Worker.x10"
                    final x10.compiler.ws.Frame t$117301 = ((x10.compiler.ws.Frame) k);
                    
                    //#line 59 "x10/compiler/ws/Worker.x10"
                    this.unroll(((x10.compiler.ws.Frame)(t$117301)));
                }}catch (final x10.compiler.Abort id$116) {
                    
                }
            }
        }}catch (final java.lang.RuntimeException t) {
            
            //#line 63 "x10/compiler/ws/Worker.x10"
            final java.lang.String t$117302 = (("Uncaught exception at place ") + (x10.x10rt.X10RT.here()));
            
            //#line 63 "x10/compiler/ws/Worker.x10"
            final java.lang.String t$117303 = ((t$117302) + (" in WS worker: "));
            
            //#line 63 "x10/compiler/ws/Worker.x10"
            final java.lang.String t$117304 = ((t$117303) + (t));
            
            //#line 63 "x10/compiler/ws/Worker.x10"
            java.lang.System.err.println(t$117304);
            
            //#line 64 "x10/compiler/ws/Worker.x10"
            t.printStackTrace();
        }
    }
    
    
    //#line 68 "x10/compiler/ws/Worker.x10"
    public java.lang.Object find() {
        
        //#line 69 "x10/compiler/ws/Worker.x10"
        java.lang.Object k =  null;
        
        //#line 71 "x10/compiler/ws/Worker.x10"
        final x10.core.Deque t$117305 = ((x10.core.Deque)(this.fifo));
        
        //#line 71 "x10/compiler/ws/Worker.x10"
        final java.lang.Object t$117306 = t$117305.steal();
        
        //#line 71 "x10/compiler/ws/Worker.x10"
        k = ((java.lang.Object)(t$117306));
        
        //#line 72 "x10/compiler/ws/Worker.x10"
        while (true) {
            
            //#line 72 "x10/compiler/ws/Worker.x10"
            final boolean t$117335 = ((null) == (k));
            
            //#line 72 "x10/compiler/ws/Worker.x10"
            if (!(t$117335)) {
                
                //#line 72 "x10/compiler/ws/Worker.x10"
                break;
            }
            
            //#line 321 . "x10/xrx/Runtime.x10"
            final x10.xrx.Pool t$117411 = ((x10.xrx.Pool)(x10.xrx.Runtime.get$pool()));
            
            //#line 321 . "x10/xrx/Runtime.x10"
            final boolean t$117412 = t$117411.wsEnd;
            
            //#line 73 "x10/compiler/ws/Worker.x10"
            if (t$117412) {
                
                //#line 73 "x10/compiler/ws/Worker.x10"
                return null;
            }
            
            //#line 75 "x10/compiler/ws/Worker.x10"
            final x10.util.Random t$117413 = ((x10.util.Random)(this.random));
            
            //#line 75 "x10/compiler/ws/Worker.x10"
            final int t$117414 = x10.xrx.Runtime.get$NTHREADS();
            
            //#line 75 "x10/compiler/ws/Worker.x10"
            final int rand$117415 = t$117413.nextInt$O((int)(t$117414));
            
            //#line 76 "x10/compiler/ws/Worker.x10"
            final x10.core.Rail t$117416 = ((x10.core.Rail)(this.workers));
            
            //#line 76 "x10/compiler/ws/Worker.x10"
            final long t$117417 = ((long)(((int)(rand$117415))));
            
            //#line 76 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.Worker victim$117418 = ((x10.compiler.ws.Worker[])t$117416.value)[(int)t$117417];
            
            //#line 77 "x10/compiler/ws/Worker.x10"
            final x10.core.Deque t$117419 = ((x10.core.Deque)(victim$117418.fifo));
            
            //#line 77 "x10/compiler/ws/Worker.x10"
            final java.lang.Object t$117420 = t$117419.steal();
            
            //#line 77 "x10/compiler/ws/Worker.x10"
            k = ((java.lang.Object)(t$117420));
            
            //#line 78 "x10/compiler/ws/Worker.x10"
            final boolean t$117422 = ((null) != (k));
            
            //#line 78 "x10/compiler/ws/Worker.x10"
            if (t$117422) {
                
                //#line 78 "x10/compiler/ws/Worker.x10"
                break;
            }
            
            //#line 80 "x10/compiler/ws/Worker.x10"
            final x10.util.concurrent.Lock t$117423 = ((x10.util.concurrent.Lock)(victim$117418.lock));
            
            //#line 80 "x10/compiler/ws/Worker.x10"
            final boolean t$117424 = t$117423.tryLock();
            
            //#line 80 "x10/compiler/ws/Worker.x10"
            if (t$117424) {
                
                //#line 81 "x10/compiler/ws/Worker.x10"
                final x10.core.Deque t$117425 = ((x10.core.Deque)(victim$117418.deque));
                
                //#line 81 "x10/compiler/ws/Worker.x10"
                final java.lang.Object t$117426 = t$117425.steal();
                
                //#line 81 "x10/compiler/ws/Worker.x10"
                k = ((java.lang.Object)(t$117426));
                
                //#line 82 "x10/compiler/ws/Worker.x10"
                final boolean t$117428 = ((null) != (k));
                
                //#line 82 "x10/compiler/ws/Worker.x10"
                if (t$117428) {
                    
                    //#line 83 "x10/compiler/ws/Worker.x10"
                    x10.compiler.ws.RegularFrame r$117430 = ((x10.compiler.ws.RegularFrame) k);
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    final x10.util.concurrent.Monitor t$117431 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    t$117431.lock();
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    final x10.compiler.ws.FinishFrame obj$117433 = ((x10.compiler.ws.FinishFrame)(r$117430.ff));
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    final int t$117434 = obj$117433.asyncs;
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    final int t$117435 = ((t$117434) + (((int)(1))));
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    obj$117433.asyncs = t$117435;
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    final x10.util.concurrent.Monitor t$117436 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    t$117436.unlock();
                }
                
                //#line 90 "x10/compiler/ws/Worker.x10"
                final x10.util.concurrent.Lock t$117437 = ((x10.util.concurrent.Lock)(victim$117418.lock));
                
                //#line 90 "x10/compiler/ws/Worker.x10"
                t$117437.unlock();
            }
            
            //#line 92 "x10/compiler/ws/Worker.x10"
            final boolean t$117439 = ((null) != (k));
            
            //#line 92 "x10/compiler/ws/Worker.x10"
            if (t$117439) {
                
                //#line 92 "x10/compiler/ws/Worker.x10"
                break;
            }
            
            //#line 94 "x10/compiler/ws/Worker.x10"
            x10.runtime.impl.java.Runtime.eventProbe();
            
            //#line 95 "x10/compiler/ws/Worker.x10"
            final x10.core.Deque t$117440 = ((x10.core.Deque)(this.fifo));
            
            //#line 95 "x10/compiler/ws/Worker.x10"
            final java.lang.Object t$117441 = t$117440.steal();
            
            //#line 95 "x10/compiler/ws/Worker.x10"
            k = ((java.lang.Object)(t$117441));
        }
        
        //#line 97 "x10/compiler/ws/Worker.x10"
        return k;
    }
    
    
    //#line 100 "x10/compiler/ws/Worker.x10"
    public void unroll(x10.compiler.ws.Frame frame) {
        
        //#line 101 "x10/compiler/ws/Worker.x10"
        x10.compiler.ws.Frame up =  null;
        
        //#line 102 "x10/compiler/ws/Worker.x10"
        while (true) {
            
            //#line 103 "x10/compiler/ws/Worker.x10"
            frame.wrapResume(((x10.compiler.ws.Worker)(this)));
            
            //#line 104 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.Frame t$117339 = ((x10.compiler.ws.Frame)(frame.up));
            
            //#line 104 "x10/compiler/ws/Worker.x10"
            up = ((x10.compiler.ws.Frame)(t$117339));
            
            //#line 105 "x10/compiler/ws/Worker.x10"
            up.wrapBack(((x10.compiler.ws.Worker)(this)), ((x10.compiler.ws.Frame)(frame)));
            
            //#line 107 "x10/compiler/ws/Worker.x10"
            frame = ((x10.compiler.ws.Frame)(up));
        }
    }
    
    
    //#line 111 "x10/compiler/ws/Worker.x10"
    public static void wsRunAsync(final long id, final x10.core.fun.VoidFun_0_0 body) {
        
        //#line 112 "x10/compiler/ws/Worker.x10"
        final long t$117343 = ((long)x10.x10rt.X10RT.hereId());
        
        //#line 112 "x10/compiler/ws/Worker.x10"
        final boolean t$117344 = ((long) id) == ((long) t$117343);
        
        //#line 112 "x10/compiler/ws/Worker.x10"
        if (t$117344) {
            
            //#line 113 "x10/compiler/ws/Worker.x10"
            final x10.core.fun.VoidFun_0_0 copy = ((x10.core.fun.VoidFun_0_0)(x10.xrx.Runtime.<x10.core.fun.VoidFun_0_0> deepCopy__0x10$xrx$Runtime$$T$G(x10.core.fun.VoidFun_0_0.$RTT, ((x10.core.fun.VoidFun_0_0)(body)), ((x10.xrx.Runtime.Profile)(null)))));
            
            //#line 114 "x10/compiler/ws/Worker.x10"
            ((x10.core.fun.VoidFun_0_0)copy).$apply();
        } else {
            
            //#line 117 "x10/compiler/ws/Worker.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.xrx.Runtime.Profile)
                                                   (null)));
            
            //#line 75 . "x10/xrx/Runtime.x10"
            x10.xrx.Runtime.x10rtSendMessage((long)(id), ((x10.core.fun.VoidFun_0_0)(body)), ((x10.xrx.Runtime.Profile)(null)), ((x10.core.fun.VoidFun_0_0)(null)));
        }
    }
    
    
    //#line 122 "x10/compiler/ws/Worker.x10"
    public static void runAsyncAt(final x10.lang.Place place, final x10.compiler.ws.RegularFrame frame) {
        
        //#line 123 "x10/compiler/ws/Worker.x10"
        final x10.core.fun.VoidFun_0_0 body = ((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.Worker.$Closure_runAsyncAt(frame)));
        
        //#line 124 "x10/compiler/ws/Worker.x10"
        final long t$117346 = place.id;
        
        //#line 124 "x10/compiler/ws/Worker.x10"
        x10.compiler.ws.Worker.wsRunAsync((long)(t$117346), ((x10.core.fun.VoidFun_0_0)(body)));
    }
    
    
    //#line 127 "x10/compiler/ws/Worker.x10"
    public static void runAt(final x10.lang.Place place, final x10.compiler.ws.RegularFrame frame) {
        
        //#line 128 "x10/compiler/ws/Worker.x10"
        final x10.core.fun.VoidFun_0_0 body = ((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.Worker.$Closure_runAt(frame)));
        
        //#line 129 "x10/compiler/ws/Worker.x10"
        final long t$117348 = place.id;
        
        //#line 129 "x10/compiler/ws/Worker.x10"
        x10.compiler.ws.Worker.wsRunAsync((long)(t$117348), ((x10.core.fun.VoidFun_0_0)(body)));
        
        //#line 130 "x10/compiler/ws/Worker.x10"
        final x10.compiler.Abort t$117349 = ((x10.compiler.Abort)(x10.compiler.Abort.get$ABORT()));
        
        //#line 130 "x10/compiler/ws/Worker.x10"
        throw t$117349;
    }
    
    
    //#line 133 "x10/compiler/ws/Worker.x10"
    public static void stop() {
        
        //#line 134 "x10/compiler/ws/Worker.x10"
        final x10.core.fun.VoidFun_0_0 body = ((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.Worker.$Closure_stop()));
        
        //#line 135 "x10/compiler/ws/Worker.x10"
        final x10.lang.PlaceGroup t$117447 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 135 "x10/compiler/ws/Worker.x10"
        final x10.lang.Iterator p$117448 = t$117447.iterator();
        
        //#line 135 "x10/compiler/ws/Worker.x10"
        for (;
             true;
             ) {
            
            //#line 135 "x10/compiler/ws/Worker.x10"
            final boolean t$117449 = ((x10.lang.Iterator<x10.lang.Place>)p$117448).hasNext$O();
            
            //#line 135 "x10/compiler/ws/Worker.x10"
            if (!(t$117449)) {
                
                //#line 135 "x10/compiler/ws/Worker.x10"
                break;
            }
            
            //#line 135 "x10/compiler/ws/Worker.x10"
            final x10.lang.Place p$117442 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$117448).next$G()));
            
            //#line 136 "x10/compiler/ws/Worker.x10"
            final boolean t$117443 = (!x10.rtt.Equality.equalsequals((p$117442),(x10.x10rt.X10RT.here())));
            
            //#line 136 "x10/compiler/ws/Worker.x10"
            if (t$117443) {
                
                //#line 137 "x10/compiler/ws/Worker.x10"
                final long id$117444 = p$117442.id;
                
                //#line 137 "x10/compiler/ws/Worker.x10"
                x10.runtime.impl.java.EvalUtils.eval(((x10.xrx.Runtime.Profile)
                                                       (null)));
                
                //#line 75 . "x10/xrx/Runtime.x10"
                x10.xrx.Runtime.x10rtSendMessage((long)(id$117444), ((x10.core.fun.VoidFun_0_0)(body)), ((x10.xrx.Runtime.Profile)(null)), ((x10.core.fun.VoidFun_0_0)(null)));
            }
        }
        
        //#line 318 . "x10/xrx/Runtime.x10"
        final x10.xrx.Pool t$117450 = ((x10.xrx.Pool)(x10.xrx.Runtime.get$pool()));
        
        //#line 318 . "x10/xrx/Runtime.x10"
        t$117450.wsEnd = true;
    }
    
    
    //#line 144 "x10/compiler/ws/Worker.x10"
    public static x10.compiler.ws.Worker startHere() {
        
        //#line 299 . "x10/xrx/Runtime.x10"
        final x10.xrx.Pool t$117465 = ((x10.xrx.Pool)(x10.xrx.Runtime.get$pool()));
        
        //#line 299 . "x10/xrx/Runtime.x10"
        final x10.core.Deque t$117466 = ((x10.core.Deque)(new x10.core.Deque()));
        
        //#line 299 . "x10/xrx/Runtime.x10"
        t$117465.wsBlockedContinuations = ((x10.core.Deque)(t$117466));
        
        //#line 146 "x10/compiler/ws/Worker.x10"
        final int t$117357 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 146 "x10/compiler/ws/Worker.x10"
        final long t$117358 = ((long)(((int)(t$117357))));
        
        //#line 146 "x10/compiler/ws/Worker.x10"
        final x10.core.Rail workers = ((x10.core.Rail)(new x10.core.Rail<x10.compiler.ws.Worker>(x10.compiler.ws.Worker.$RTT, t$117358)));
        
        //#line 147 "x10/compiler/ws/Worker.x10"
        int i$117467 = 0;
        {
            
            //#line 147 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.Worker[] workers$value$117495 = ((x10.compiler.ws.Worker[])workers.value);
            
            //#line 147 "x10/compiler/ws/Worker.x10"
            for (;
                 true;
                 ) {
                
                //#line 147 "x10/compiler/ws/Worker.x10"
                final int t$117469 = x10.xrx.Runtime.get$NTHREADS();
                
                //#line 147 "x10/compiler/ws/Worker.x10"
                final boolean t$117470 = ((i$117467) < (((int)(t$117469))));
                
                //#line 147 "x10/compiler/ws/Worker.x10"
                if (!(t$117470)) {
                    
                    //#line 147 "x10/compiler/ws/Worker.x10"
                    break;
                }
                
                //#line 148 "x10/compiler/ws/Worker.x10"
                final long t$117453 = ((long)(((int)(i$117467))));
                
                //#line 148 "x10/compiler/ws/Worker.x10"
                final x10.compiler.ws.Worker alloc$117454 = ((x10.compiler.ws.Worker)(new x10.compiler.ws.Worker((java.lang.System[]) null)));
                
                //#line 148 "x10/compiler/ws/Worker.x10"
                alloc$117454.x10$compiler$ws$Worker$$init$S(i$117467, ((x10.core.Rail)(workers)), (x10.compiler.ws.Worker.__1$1x10$compiler$ws$Worker$2) null);
                
                //#line 148 "x10/compiler/ws/Worker.x10"
                workers$value$117495[(int)t$117453]=alloc$117454;
                
                //#line 147 "x10/compiler/ws/Worker.x10"
                final int t$117456 = ((i$117467) + (((int)(1))));
                
                //#line 147 "x10/compiler/ws/Worker.x10"
                i$117467 = t$117456;
            }
        }
        
        //#line 150 "x10/compiler/ws/Worker.x10"
        final x10.compiler.ws.Worker t$117370 = ((x10.compiler.ws.Worker[])workers.value)[(int)0L];
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.core.Thread t$117368 = x10.core.Thread.currentThread();
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.xrx.Worker t$117369 = x10.rtt.Types.<x10.xrx.Worker> cast(t$117368,x10.xrx.Worker.$RTT);
        
        //#line 303 . "x10/xrx/Runtime.x10"
        final x10.core.Deque t$117371 = ((x10.core.Deque)(t$117369.wsfifo));
        
        //#line 150 "x10/compiler/ws/Worker.x10"
        t$117370.fifo = ((x10.core.Deque)(t$117371));
        
        //#line 151 "x10/compiler/ws/Worker.x10"
        int i$117471 = 1;
        {
            
            //#line 151 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.Worker[] workers$value$117496 = ((x10.compiler.ws.Worker[])workers.value);
            
            //#line 151 "x10/compiler/ws/Worker.x10"
            for (;
                 true;
                 ) {
                
                //#line 151 "x10/compiler/ws/Worker.x10"
                final int t$117473 = x10.xrx.Runtime.get$NTHREADS();
                
                //#line 151 "x10/compiler/ws/Worker.x10"
                final boolean t$117474 = ((i$117471) < (((int)(t$117473))));
                
                //#line 151 "x10/compiler/ws/Worker.x10"
                if (!(t$117474)) {
                    
                    //#line 151 "x10/compiler/ws/Worker.x10"
                    break;
                }
                
                //#line 152 "x10/compiler/ws/Worker.x10"
                final long t$117458 = ((long)(((int)(i$117471))));
                
                //#line 152 "x10/compiler/ws/Worker.x10"
                final x10.compiler.ws.Worker worker$117459 = ((x10.compiler.ws.Worker)workers$value$117496[(int)t$117458]);
                
                //#line 153 "x10/compiler/ws/Worker.x10"
                x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.Worker.$Closure$53(worker$117459))));
                
                //#line 151 "x10/compiler/ws/Worker.x10"
                final int t$117464 = ((i$117471) + (((int)(1))));
                
                //#line 151 "x10/compiler/ws/Worker.x10"
                i$117471 = t$117464;
            }
        }
        
        //#line 158 "x10/compiler/ws/Worker.x10"
        final x10.compiler.ws.Worker t$117383 = ((x10.compiler.ws.Worker[])workers.value)[(int)0L];
        
        //#line 158 "x10/compiler/ws/Worker.x10"
        return t$117383;
    }
    
    
    //#line 161 "x10/compiler/ws/Worker.x10"
    public static x10.compiler.ws.Worker start() {
        
        //#line 162 "x10/compiler/ws/Worker.x10"
        final x10.compiler.ws.Worker worker = x10.compiler.ws.Worker.startHere();
        
        //#line 163 "x10/compiler/ws/Worker.x10"
        final x10.lang.PlaceGroup t$117478 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 163 "x10/compiler/ws/Worker.x10"
        final x10.lang.Iterator p$117479 = t$117478.iterator();
        
        //#line 163 "x10/compiler/ws/Worker.x10"
        for (;
             true;
             ) {
            
            //#line 163 "x10/compiler/ws/Worker.x10"
            final boolean t$117480 = ((x10.lang.Iterator<x10.lang.Place>)p$117479).hasNext$O();
            
            //#line 163 "x10/compiler/ws/Worker.x10"
            if (!(t$117480)) {
                
                //#line 163 "x10/compiler/ws/Worker.x10"
                break;
            }
            
            //#line 163 "x10/compiler/ws/Worker.x10"
            final x10.lang.Place p$117475 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$117479).next$G()));
            
            //#line 164 "x10/compiler/ws/Worker.x10"
            final boolean t$117476 = (!x10.rtt.Equality.equalsequals((p$117475),(x10.x10rt.X10RT.here())));
            
            //#line 164 "x10/compiler/ws/Worker.x10"
            if (t$117476) {
                
                //#line 165 "x10/compiler/ws/Worker.x10"
                x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$117475)), ((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.Worker.$Closure$54())), ((x10.xrx.Runtime.Profile)(null)));
            }
        }
        
        //#line 168 "x10/compiler/ws/Worker.x10"
        return worker;
    }
    
    
    //#line 171 "x10/compiler/ws/Worker.x10"
    public static void main(final x10.compiler.ws.MainFrame frame) {
        
        //#line 172 "x10/compiler/ws/Worker.x10"
        final x10.compiler.ws.Worker worker = ((x10.compiler.ws.Worker)(x10.compiler.ws.Worker.start()));
        
        //#line 173 "x10/compiler/ws/Worker.x10"
        final x10.compiler.ws.FinishFrame ff = ((x10.compiler.ws.FinishFrame)(frame.ff));
        
        //#line 174 "x10/compiler/ws/Worker.x10"
        boolean finalize = true;
        
        //#line 175 "x10/compiler/ws/Worker.x10"
        try {{
            
            //#line 176 "x10/compiler/ws/Worker.x10"
            frame.fast(((x10.compiler.ws.Worker)(worker)));
        }}catch (final x10.compiler.Abort t) {
            
            //#line 178 "x10/compiler/ws/Worker.x10"
            finalize = false;
            
            //#line 179 "x10/compiler/ws/Worker.x10"
            worker.run();
        }catch (final java.lang.RuntimeException t) {
            
            //#line 181 "x10/compiler/ws/Worker.x10"
            ff.caught(((java.lang.Throwable)(t)));
        }finally {{
             
             //#line 183 "x10/compiler/ws/Worker.x10"
             if (finalize) {
                 
                 //#line 183 "x10/compiler/ws/Worker.x10"
                 x10.compiler.ws.Worker.stop();
             }
         }}
        
        //#line 117 . "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$117483 = ((x10.util.GrowableRail)(ff.exceptions));
        
        //#line 117 . "x10/compiler/ws/FinishFrame.x10"
        final boolean t$117484 = ((null) != (t$117483));
        
        //#line 117 . "x10/compiler/ws/FinishFrame.x10"
        if (t$117484) {
            
            //#line 118 . "x10/compiler/ws/FinishFrame.x10"
            while (true) {
                
                //#line 118 . "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail this$117485 = ((x10.util.GrowableRail)(ff.exceptions));
                
                //#line 160 .. "x10/util/GrowableRail.x10"
                final long t$117486 = ((x10.util.GrowableRail<java.lang.Throwable>)this$117485).size;
                
                //#line 160 .. "x10/util/GrowableRail.x10"
                final boolean t$117487 = ((long) t$117486) == ((long) 0L);
                
                //#line 118 . "x10/compiler/ws/FinishFrame.x10"
                final boolean t$117488 = !(t$117487);
                
                //#line 118 . "x10/compiler/ws/FinishFrame.x10"
                if (!(t$117488)) {
                    
                    //#line 118 . "x10/compiler/ws/FinishFrame.x10"
                    break;
                }
                
                //#line 119 . "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail t$117481 = ((x10.util.GrowableRail)(ff.exceptions));
                
                //#line 119 . "x10/compiler/ws/FinishFrame.x10"
                final java.lang.Throwable t$117482 = ((x10.util.GrowableRail<java.lang.Throwable>)t$117481).removeLast$G();
                
                //#line 119 . "x10/compiler/ws/FinishFrame.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(t$117482)));
            }
        }
        }
    
    
    //#line 188 "x10/compiler/ws/Worker.x10"
    public void rethrow() {
        
        //#line 189 "x10/compiler/ws/Worker.x10"
        final java.lang.RuntimeException t$117397 = ((java.lang.RuntimeException)(this.throwable));
        
        //#line 189 "x10/compiler/ws/Worker.x10"
        final boolean t$117398 = ((null) != (t$117397));
        
        //#line 189 "x10/compiler/ws/Worker.x10"
        if (t$117398) {
            
            //#line 190 "x10/compiler/ws/Worker.x10"
            final java.lang.RuntimeException t = ((java.lang.RuntimeException)(this.throwable));
            
            //#line 191 "x10/compiler/ws/Worker.x10"
            this.throwable = null;
            
            //#line 192 "x10/compiler/ws/Worker.x10"
            throw t;
        }
    }
    
    
    //#line 23 "x10/compiler/ws/Worker.x10"
    final public x10.compiler.ws.Worker x10$compiler$ws$Worker$$this$x10$compiler$ws$Worker() {
        
        //#line 23 "x10/compiler/ws/Worker.x10"
        return x10.compiler.ws.Worker.this;
    }
    
    
    //#line 23 "x10/compiler/ws/Worker.x10"
    final public void __fieldInitializers_x10_compiler_ws_Worker() {
        
        //#line 28 "x10/compiler/ws/Worker.x10"
        final x10.core.Deque t$117399 = ((x10.core.Deque)(new x10.core.Deque()));
        
        //#line 23 "x10/compiler/ws/Worker.x10"
        this.deque = ((x10.core.Deque)(t$117399));
        
        //#line 29 "x10/compiler/ws/Worker.x10"
        final x10.core.Deque t$117400 = ((x10.core.Deque)(this.deque));
        
        //#line 23 "x10/compiler/ws/Worker.x10"
        this.fifo = t$117400;
        
        //#line 30 "x10/compiler/ws/Worker.x10"
        final x10.util.concurrent.Lock t$117401 = ((x10.util.concurrent.Lock)(new x10.util.concurrent.Lock()));
        
        //#line 23 "x10/compiler/ws/Worker.x10"
        this.lock = ((x10.util.concurrent.Lock)(t$117401));
        
        //#line 23 "x10/compiler/ws/Worker.x10"
        this.throwable = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure_runAsyncAt extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure_runAsyncAt> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure_runAsyncAt> make($Closure_runAsyncAt.class,
                                                                 new x10.rtt.Type[] {
                                                                     x10.core.fun.VoidFun_0_0.$RTT
                                                                 });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.Worker.$Closure_runAsyncAt $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.frame = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.Worker.$Closure_runAsyncAt $_obj = new x10.compiler.ws.Worker.$Closure_runAsyncAt((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.frame);
            
        }
        
        // constructor just for allocation
        public $Closure_runAsyncAt(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 123 "x10/compiler/ws/Worker.x10"
            final x10.core.Deque t$117345 = x10.xrx.Runtime.wsFIFO();
            
            //#line 123 "x10/compiler/ws/Worker.x10"
            t$117345.push(((java.lang.Object)(this.frame)));
        }
        
        public x10.compiler.ws.RegularFrame frame;
        
        public $Closure_runAsyncAt(final x10.compiler.ws.RegularFrame frame) {
             {
                this.frame = ((x10.compiler.ws.RegularFrame)(frame));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure_runAt extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure_runAt> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure_runAt> make($Closure_runAt.class,
                                                            new x10.rtt.Type[] {
                                                                x10.core.fun.VoidFun_0_0.$RTT
                                                            });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.Worker.$Closure_runAt $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.frame = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.Worker.$Closure_runAt $_obj = new x10.compiler.ws.Worker.$Closure_runAt((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.frame);
            
        }
        
        // constructor just for allocation
        public $Closure_runAt(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 128 "x10/compiler/ws/Worker.x10"
            final x10.core.Deque t$117347 = x10.xrx.Runtime.wsFIFO();
            
            //#line 128 "x10/compiler/ws/Worker.x10"
            t$117347.push(((java.lang.Object)(this.frame)));
        }
        
        public x10.compiler.ws.RegularFrame frame;
        
        public $Closure_runAt(final x10.compiler.ws.RegularFrame frame) {
             {
                this.frame = ((x10.compiler.ws.RegularFrame)(frame));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure_stop extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure_stop> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure_stop> make($Closure_stop.class,
                                                           new x10.rtt.Type[] {
                                                               x10.core.fun.VoidFun_0_0.$RTT
                                                           });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.Worker.$Closure_stop $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.Worker.$Closure_stop $_obj = new x10.compiler.ws.Worker.$Closure_stop((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure_stop(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 134 "x10/compiler/ws/Worker.x10"
            x10.xrx.Runtime.wsEnd();
        }
        
        public $Closure_stop() {
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$53 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$53> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$53> make($Closure$53.class,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.Worker.$Closure$53 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.worker$117459 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.Worker.$Closure$53 $_obj = new x10.compiler.ws.Worker.$Closure$53((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.worker$117459);
            
        }
        
        // constructor just for allocation
        public $Closure$53(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 153 "x10/compiler/ws/Worker.x10"
            try {{
                
                //#line 331 .. "x10/xrx/Runtime.x10"
                final x10.core.Thread t$117460 = x10.core.Thread.currentThread();
                
                //#line 331 .. "x10/xrx/Runtime.x10"
                final x10.xrx.Worker t$117461 = x10.rtt.Types.<x10.xrx.Worker> cast(t$117460,x10.xrx.Worker.$RTT);
                
                //#line 303 . "x10/xrx/Runtime.x10"
                final x10.core.Deque t$117462 = ((x10.core.Deque)(t$117461.wsfifo));
                
                //#line 154 "x10/compiler/ws/Worker.x10"
                this.worker$117459.fifo = ((x10.core.Deque)(t$117462));
                
                //#line 155 "x10/compiler/ws/Worker.x10"
                this.worker$117459.run();
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 153 "x10/compiler/ws/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 153 "x10/compiler/ws/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.compiler.ws.Worker worker$117459;
        
        public $Closure$53(final x10.compiler.ws.Worker worker$117459) {
             {
                this.worker$117459 = ((x10.compiler.ws.Worker)(worker$117459));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$54 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$54> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$54> make($Closure$54.class,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.Worker.$Closure$54 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.Worker.$Closure$54 $_obj = new x10.compiler.ws.Worker.$Closure$54((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure$54(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 165 "x10/compiler/ws/Worker.x10"
            try {{
                
                //#line 165 "x10/compiler/ws/Worker.x10"
                final x10.compiler.ws.Worker t$117477 = x10.compiler.ws.Worker.startHere();
                
                //#line 165 "x10/compiler/ws/Worker.x10"
                t$117477.run();
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 165 "x10/compiler/ws/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 165 "x10/compiler/ws/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public $Closure$54() {
             {
                
            }
        }
        
    }
    
    }
    
    