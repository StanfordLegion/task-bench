package x10.compiler.ws;


@x10.runtime.impl.java.X10Generated
final public class AtFrame extends x10.compiler.ws.Frame implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<AtFrame> $RTT = 
        x10.rtt.NamedType.<AtFrame> make("x10.compiler.ws.AtFrame",
                                         AtFrame.class,
                                         new x10.rtt.Type[] {
                                             x10.compiler.ws.Frame.$RTT
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.AtFrame $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.ws.Frame.$_deserialize_body($_obj, $deserializer);
        $_obj.upRef = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.ws.AtFrame $_obj = new x10.compiler.ws.AtFrame((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.upRef);
        
    }
    
    // constructor just for allocation
    public AtFrame(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 19 "x10/compiler/ws/AtFrame.x10"
    public x10.core.GlobalRef<x10.compiler.ws.Frame> upRef;
    
    
    //#line 21 "x10/compiler/ws/AtFrame.x10"
    // creation method for java code (1-phase java constructor)
    public AtFrame(final x10.compiler.ws.Frame up, final x10.compiler.ws.FinishFrame ff) {
        this((java.lang.System[]) null);
        x10$compiler$ws$AtFrame$$init$S(up, ff);
    }
    
    // constructor for non-virtual call
    final public x10.compiler.ws.AtFrame x10$compiler$ws$AtFrame$$init$S(final x10.compiler.ws.Frame up, final x10.compiler.ws.FinishFrame ff) {
         {
            
            //#line 22 "x10/compiler/ws/AtFrame.x10"
            final x10.compiler.ws.Frame this$115258 = this;
            
            //#line 22 "x10/compiler/ws/AtFrame.x10"
            final x10.compiler.ws.Frame up$115257 = ((x10.compiler.ws.Frame)(((x10.compiler.ws.Frame)
                                                                               ff)));
            
            //#line 31 . "x10/compiler/ws/Frame.x10"
            this$115258.up = ((x10.compiler.ws.Frame)(up$115257));
            
            //#line 21 "x10/compiler/ws/AtFrame.x10"
            
            
            //#line 23 "x10/compiler/ws/AtFrame.x10"
            final x10.core.GlobalRef t$115270 = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.compiler.ws.Frame>(x10.compiler.ws.Frame.$RTT, ((x10.compiler.ws.Frame)(up)), (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
            
            //#line 23 "x10/compiler/ws/AtFrame.x10"
            this.upRef = ((x10.core.GlobalRef)(t$115270));
        }
        return this;
    }
    
    
    
    //#line 29 "x10/compiler/ws/AtFrame.x10"
    public void wrapResume(final x10.compiler.ws.Worker worker) {
        
        //#line 30 "x10/compiler/ws/AtFrame.x10"
        final x10.core.GlobalRef upRef$115263 = ((x10.core.GlobalRef)(this.upRef));
        
        //#line 30 "x10/compiler/ws/AtFrame.x10"
        final java.lang.RuntimeException throwable$115264 = ((java.lang.RuntimeException)(worker.throwable));
        
        //#line 35 . "x10/compiler/ws/AtFrame.x10"
        final x10.core.fun.VoidFun_0_0 body$115293 = ((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.AtFrame.$Closure$49(upRef$115263, throwable$115264, (x10.compiler.ws.AtFrame.$Closure$49.__0$1x10$compiler$ws$Frame$2) null)));
        
        //#line 42 . "x10/compiler/ws/AtFrame.x10"
        final x10.lang.Place t$115304 = ((x10.lang.Place)((upRef$115263).home));
        
        //#line 42 . "x10/compiler/ws/AtFrame.x10"
        final long t$115305 = t$115304.id;
        
        //#line 42 . "x10/compiler/ws/AtFrame.x10"
        x10.compiler.ws.Worker.wsRunAsync((long)(t$115305), ((x10.core.fun.VoidFun_0_0)(body$115293)));
        
        //#line 31 "x10/compiler/ws/AtFrame.x10"
        worker.throwable = null;
    }
    
    
    //#line 34 "x10/compiler/ws/AtFrame.x10"
    public static void update__0$1x10$compiler$ws$Frame$2(final x10.core.GlobalRef<x10.compiler.ws.Frame> upRef, final java.lang.RuntimeException throwable) {
        
        //#line 35 "x10/compiler/ws/AtFrame.x10"
        final x10.core.fun.VoidFun_0_0 body = ((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.AtFrame.$Closure$50(upRef, throwable, (x10.compiler.ws.AtFrame.$Closure$50.__0$1x10$compiler$ws$Frame$2) null)));
        
        //#line 42 "x10/compiler/ws/AtFrame.x10"
        final x10.lang.Place t$115289 = ((x10.lang.Place)((upRef).home));
        
        //#line 42 "x10/compiler/ws/AtFrame.x10"
        final long t$115290 = t$115289.id;
        
        //#line 42 "x10/compiler/ws/AtFrame.x10"
        x10.compiler.ws.Worker.wsRunAsync((long)(t$115290), ((x10.core.fun.VoidFun_0_0)(body)));
    }
    
    
    //#line 18 "x10/compiler/ws/AtFrame.x10"
    final public x10.compiler.ws.AtFrame x10$compiler$ws$AtFrame$$this$x10$compiler$ws$AtFrame() {
        
        //#line 18 "x10/compiler/ws/AtFrame.x10"
        return x10.compiler.ws.AtFrame.this;
    }
    
    
    //#line 18 "x10/compiler/ws/AtFrame.x10"
    final public void __fieldInitializers_x10_compiler_ws_AtFrame() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$49 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$49> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$49> make($Closure$49.class,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.AtFrame.$Closure$49 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.throwable$115264 = $deserializer.readObject();
            $_obj.upRef$115263 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.AtFrame.$Closure$49 $_obj = new x10.compiler.ws.AtFrame.$Closure$49((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.throwable$115264);
            $serializer.write(this.upRef$115263);
            
        }
        
        // constructor just for allocation
        public $Closure$49(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$compiler$ws$Frame$2 {}
        
    
        
        public void $apply() {
            
            //#line 36 . "x10/compiler/ws/AtFrame.x10"
            final x10.core.GlobalRef t$115294 = ((x10.core.GlobalRef)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.core.GlobalRef.$RTT, x10.compiler.ws.Frame.$RTT),this.upRef$115263));
            
            //#line 36 . "x10/compiler/ws/AtFrame.x10"
            final x10.lang.Place t$115295 = ((x10.lang.Place)((t$115294).home));
            
            //#line 36 . "x10/compiler/ws/AtFrame.x10"
            final boolean t$115296 = x10.rtt.Equality.equalsequals((t$115295),(x10.x10rt.X10RT.here()));
            
            //#line 36 . "x10/compiler/ws/AtFrame.x10"
            final boolean t$115297 = !(t$115296);
            
            //#line 36 . "x10/compiler/ws/AtFrame.x10"
            if (t$115297) {
                
                //#line 36 . "x10/compiler/ws/AtFrame.x10"
                final x10.lang.FailedDynamicCheckException t$115298 = new x10.lang.FailedDynamicCheckException("x10.lang.GlobalRef[x10.compiler.ws.Frame]{self.home==here}");
                
                //#line 36 . "x10/compiler/ws/AtFrame.x10"
                throw t$115298;
            }
            
            //#line 36 . "x10/compiler/ws/AtFrame.x10"
            x10.compiler.ws.Frame up$115299 = (((x10.core.GlobalRef<x10.compiler.ws.Frame>)(t$115294))).$apply$G();
            
            //#line 37 . "x10/compiler/ws/AtFrame.x10"
            final boolean t$115300 = ((null) != (this.throwable$115264));
            
            //#line 37 . "x10/compiler/ws/AtFrame.x10"
            if (t$115300) {
                
                //#line 38 . "x10/compiler/ws/AtFrame.x10"
                final x10.compiler.ws.ThrowFrame alloc$115301 = ((x10.compiler.ws.ThrowFrame)(new x10.compiler.ws.ThrowFrame((java.lang.System[]) null)));
                
                //#line 38 . "x10/compiler/ws/AtFrame.x10"
                alloc$115301.x10$compiler$ws$ThrowFrame$$init$S(up$115299, this.throwable$115264);
                
                //#line 38 . "x10/compiler/ws/AtFrame.x10"
                up$115299 = ((x10.compiler.ws.Frame)(alloc$115301));
            }
            
            //#line 40 . "x10/compiler/ws/AtFrame.x10"
            final x10.core.Deque t$115302 = x10.xrx.Runtime.wsFIFO();
            
            //#line 40 . "x10/compiler/ws/AtFrame.x10"
            ;
            
            //#line 40 . "x10/compiler/ws/AtFrame.x10"
            t$115302.push(((java.lang.Object)(up$115299)));
        }
        
        public x10.core.GlobalRef<x10.compiler.ws.Frame> upRef$115263;
        public java.lang.RuntimeException throwable$115264;
        
        public $Closure$49(final x10.core.GlobalRef<x10.compiler.ws.Frame> upRef$115263, final java.lang.RuntimeException throwable$115264, __0$1x10$compiler$ws$Frame$2 $dummy) {
             {
                this.upRef$115263 = ((x10.core.GlobalRef)(upRef$115263));
                this.throwable$115264 = ((java.lang.RuntimeException)(throwable$115264));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$50 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$50> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$50> make($Closure$50.class,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.AtFrame.$Closure$50 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.throwable = $deserializer.readObject();
            $_obj.upRef = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.AtFrame.$Closure$50 $_obj = new x10.compiler.ws.AtFrame.$Closure$50((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.throwable);
            $serializer.write(this.upRef);
            
        }
        
        // constructor just for allocation
        public $Closure$50(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$compiler$ws$Frame$2 {}
        
    
        
        public void $apply() {
            
            //#line 36 "x10/compiler/ws/AtFrame.x10"
            final x10.core.GlobalRef t$115254 = ((x10.core.GlobalRef)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.core.GlobalRef.$RTT, x10.compiler.ws.Frame.$RTT),this.upRef));
            
            //#line 36 "x10/compiler/ws/AtFrame.x10"
            final x10.lang.Place t$115281 = ((x10.lang.Place)((t$115254).home));
            
            //#line 36 "x10/compiler/ws/AtFrame.x10"
            final boolean t$115282 = x10.rtt.Equality.equalsequals((t$115281),(x10.x10rt.X10RT.here()));
            
            //#line 36 "x10/compiler/ws/AtFrame.x10"
            final boolean t$115284 = !(t$115282);
            
            //#line 36 "x10/compiler/ws/AtFrame.x10"
            if (t$115284) {
                
                //#line 36 "x10/compiler/ws/AtFrame.x10"
                final x10.lang.FailedDynamicCheckException t$115283 = new x10.lang.FailedDynamicCheckException("x10.lang.GlobalRef[x10.compiler.ws.Frame]{self.home==here}");
                
                //#line 36 "x10/compiler/ws/AtFrame.x10"
                throw t$115283;
            }
            
            //#line 36 "x10/compiler/ws/AtFrame.x10"
            x10.compiler.ws.Frame up = (((x10.core.GlobalRef<x10.compiler.ws.Frame>)(t$115254))).$apply$G();
            
            //#line 37 "x10/compiler/ws/AtFrame.x10"
            final boolean t$115286 = ((null) != (this.throwable));
            
            //#line 37 "x10/compiler/ws/AtFrame.x10"
            if (t$115286) {
                
                //#line 38 "x10/compiler/ws/AtFrame.x10"
                final x10.compiler.ws.ThrowFrame alloc$115256 = ((x10.compiler.ws.ThrowFrame)(new x10.compiler.ws.ThrowFrame((java.lang.System[]) null)));
                
                //#line 38 "x10/compiler/ws/AtFrame.x10"
                alloc$115256.x10$compiler$ws$ThrowFrame$$init$S(up, this.throwable);
                
                //#line 38 "x10/compiler/ws/AtFrame.x10"
                up = ((x10.compiler.ws.Frame)(alloc$115256));
            }
            
            //#line 40 "x10/compiler/ws/AtFrame.x10"
            final x10.core.Deque t$115287 = x10.xrx.Runtime.wsFIFO();
            
            //#line 40 "x10/compiler/ws/AtFrame.x10"
            ;
            
            //#line 40 "x10/compiler/ws/AtFrame.x10"
            t$115287.push(((java.lang.Object)(up)));
        }
        
        public x10.core.GlobalRef<x10.compiler.ws.Frame> upRef;
        public java.lang.RuntimeException throwable;
        
        public $Closure$50(final x10.core.GlobalRef<x10.compiler.ws.Frame> upRef, final java.lang.RuntimeException throwable, __0$1x10$compiler$ws$Frame$2 $dummy) {
             {
                this.upRef = ((x10.core.GlobalRef)(upRef));
                this.throwable = ((java.lang.RuntimeException)(throwable));
            }
        }
        
    }
    
}

