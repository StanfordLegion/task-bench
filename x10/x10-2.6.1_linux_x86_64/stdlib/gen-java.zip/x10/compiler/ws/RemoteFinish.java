package x10.compiler.ws;


@x10.runtime.impl.java.X10Generated
final public class RemoteFinish extends x10.compiler.ws.FinishFrame implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<RemoteFinish> $RTT = 
        x10.rtt.NamedType.<RemoteFinish> make("x10.compiler.ws.RemoteFinish",
                                              RemoteFinish.class,
                                              new x10.rtt.Type[] {
                                                  x10.compiler.ws.FinishFrame.$RTT
                                              });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.RemoteFinish $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.ws.FinishFrame.$_deserialize_body($_obj, $deserializer);
        $_obj.ffRef = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.ws.RemoteFinish $_obj = new x10.compiler.ws.RemoteFinish((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.ffRef);
        
    }
    
    // constructor just for allocation
    public RemoteFinish(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 22 "x10/compiler/ws/RemoteFinish.x10"
    public x10.core.GlobalRef<x10.compiler.ws.FinishFrame> ffRef;
    
    
    //#line 24 "x10/compiler/ws/RemoteFinish.x10"
    // creation method for java code (1-phase java constructor)
    public RemoteFinish(final x10.compiler.ws.FinishFrame ff) {
        this((java.lang.System[]) null);
        x10$compiler$ws$RemoteFinish$$init$S(ff);
    }
    
    // constructor for non-virtual call
    final public x10.compiler.ws.RemoteFinish x10$compiler$ws$RemoteFinish$$init$S(final x10.compiler.ws.FinishFrame ff) {
         {
            
            //#line 25 "x10/compiler/ws/RemoteFinish.x10"
            /*super.*/x10$compiler$ws$FinishFrame$$init$S(((x10.compiler.ws.Frame)(null)));
            
            //#line 24 "x10/compiler/ws/RemoteFinish.x10"
            
            
            //#line 26 "x10/compiler/ws/RemoteFinish.x10"
            this.asyncs = 1;
            
            //#line 27 "x10/compiler/ws/RemoteFinish.x10"
            final x10.core.GlobalRef t$116624 = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.compiler.ws.FinishFrame>(x10.compiler.ws.FinishFrame.$RTT, ((x10.compiler.ws.FinishFrame)(ff)), (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
            
            //#line 27 "x10/compiler/ws/RemoteFinish.x10"
            this.ffRef = ((x10.core.GlobalRef)(t$116624));
            
            //#line 28 "x10/compiler/ws/RemoteFinish.x10"
            final x10.util.concurrent.Monitor t$116625 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 28 "x10/compiler/ws/RemoteFinish.x10"
            t$116625.lock();
            
            //#line 28 "x10/compiler/ws/RemoteFinish.x10"
            final int t$116626 = ff.asyncs;
            
            //#line 28 "x10/compiler/ws/RemoteFinish.x10"
            final int t$116627 = ((t$116626) + (((int)(1))));
            
            //#line 28 "x10/compiler/ws/RemoteFinish.x10"
            ff.asyncs = t$116627;
            
            //#line 28 "x10/compiler/ws/RemoteFinish.x10"
            final x10.util.concurrent.Monitor t$116628 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 28 "x10/compiler/ws/RemoteFinish.x10"
            t$116628.unlock();
        }
        return this;
    }
    
    
    
    //#line 34 "x10/compiler/ws/RemoteFinish.x10"
    public void wrapResume(final x10.compiler.ws.Worker worker) {
        
        //#line 35 "x10/compiler/ws/RemoteFinish.x10"
        super.wrapResume(((x10.compiler.ws.Worker)(worker)));
        
        //#line 36 "x10/compiler/ws/RemoteFinish.x10"
        final x10.core.GlobalRef ffRef$116618 = ((x10.core.GlobalRef)(this.ffRef));
        
        //#line 36 "x10/compiler/ws/RemoteFinish.x10"
        final x10.util.GrowableRail exceptions$116619 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 42 . "x10/compiler/ws/RemoteFinish.x10"
        final x10.core.fun.VoidFun_0_0 body$116645 = ((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.RemoteFinish.$Closure$51(ffRef$116618, exceptions$116619, (x10.compiler.ws.RemoteFinish.$Closure$51.__0$1x10$compiler$ws$FinishFrame$2__1$1x10$lang$CheckedThrowable$2) null)));
        
        //#line 47 . "x10/compiler/ws/RemoteFinish.x10"
        final x10.lang.Place t$116653 = ((x10.lang.Place)((ffRef$116618).home));
        
        //#line 47 . "x10/compiler/ws/RemoteFinish.x10"
        final long t$116654 = t$116653.id;
        
        //#line 47 . "x10/compiler/ws/RemoteFinish.x10"
        x10.compiler.ws.Worker.wsRunAsync((long)(t$116654), ((x10.core.fun.VoidFun_0_0)(body$116645)));
        
        //#line 37 "x10/compiler/ws/RemoteFinish.x10"
        worker.throwable = null;
        
        //#line 38 "x10/compiler/ws/RemoteFinish.x10"
        final x10.compiler.Abort t$116636 = ((x10.compiler.Abort)(x10.compiler.Abort.get$ABORT()));
        
        //#line 38 "x10/compiler/ws/RemoteFinish.x10"
        throw t$116636;
    }
    
    
    //#line 41 "x10/compiler/ws/RemoteFinish.x10"
    public static void update__0$1x10$compiler$ws$FinishFrame$2__1$1x10$lang$CheckedThrowable$2(final x10.core.GlobalRef<x10.compiler.ws.FinishFrame> ffRef, final x10.util.GrowableRail<java.lang.Throwable> exceptions) {
        
        //#line 42 "x10/compiler/ws/RemoteFinish.x10"
        final x10.core.fun.VoidFun_0_0 body = ((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.RemoteFinish.$Closure$52(ffRef, exceptions, (x10.compiler.ws.RemoteFinish.$Closure$52.__0$1x10$compiler$ws$FinishFrame$2__1$1x10$lang$CheckedThrowable$2) null)));
        
        //#line 47 "x10/compiler/ws/RemoteFinish.x10"
        final x10.lang.Place t$116642 = ((x10.lang.Place)((ffRef).home));
        
        //#line 47 "x10/compiler/ws/RemoteFinish.x10"
        final long t$116643 = t$116642.id;
        
        //#line 47 "x10/compiler/ws/RemoteFinish.x10"
        x10.compiler.ws.Worker.wsRunAsync((long)(t$116643), ((x10.core.fun.VoidFun_0_0)(body)));
    }
    
    
    //#line 21 "x10/compiler/ws/RemoteFinish.x10"
    final public x10.compiler.ws.RemoteFinish x10$compiler$ws$RemoteFinish$$this$x10$compiler$ws$RemoteFinish() {
        
        //#line 21 "x10/compiler/ws/RemoteFinish.x10"
        return x10.compiler.ws.RemoteFinish.this;
    }
    
    
    //#line 21 "x10/compiler/ws/RemoteFinish.x10"
    final public void __fieldInitializers_x10_compiler_ws_RemoteFinish() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$51 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$51> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$51> make($Closure$51.class,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.RemoteFinish.$Closure$51 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.exceptions$116619 = $deserializer.readObject();
            $_obj.ffRef$116618 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.RemoteFinish.$Closure$51 $_obj = new x10.compiler.ws.RemoteFinish.$Closure$51((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.exceptions$116619);
            $serializer.write(this.ffRef$116618);
            
        }
        
        // constructor just for allocation
        public $Closure$51(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$compiler$ws$FinishFrame$2__1$1x10$lang$CheckedThrowable$2 {}
        
    
        
        public void $apply() {
            
            //#line 43 . "x10/compiler/ws/RemoteFinish.x10"
            final x10.core.GlobalRef t$116646 = ((x10.core.GlobalRef)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.core.GlobalRef.$RTT, x10.compiler.ws.FinishFrame.$RTT),this.ffRef$116618));
            
            //#line 43 . "x10/compiler/ws/RemoteFinish.x10"
            final x10.lang.Place t$116647 = ((x10.lang.Place)((t$116646).home));
            
            //#line 43 . "x10/compiler/ws/RemoteFinish.x10"
            final boolean t$116648 = x10.rtt.Equality.equalsequals((t$116647),(x10.x10rt.X10RT.here()));
            
            //#line 43 . "x10/compiler/ws/RemoteFinish.x10"
            final boolean t$116649 = !(t$116648);
            
            //#line 43 . "x10/compiler/ws/RemoteFinish.x10"
            if (t$116649) {
                
                //#line 43 . "x10/compiler/ws/RemoteFinish.x10"
                final x10.lang.FailedDynamicCheckException t$116650 = new x10.lang.FailedDynamicCheckException("x10.lang.GlobalRef[x10.compiler.ws.FinishFrame]{self.home==here}");
                
                //#line 43 . "x10/compiler/ws/RemoteFinish.x10"
                throw t$116650;
            }
            
            //#line 43 . "x10/compiler/ws/RemoteFinish.x10"
            final x10.compiler.ws.FinishFrame ff$116651 = (((x10.core.GlobalRef<x10.compiler.ws.FinishFrame>)(t$116646))).$apply$G();
            
            //#line 44 . "x10/compiler/ws/RemoteFinish.x10"
            ff$116651.append__0$1x10$lang$CheckedThrowable$2(((x10.util.GrowableRail)(this.exceptions$116619)));
            
            //#line 45 . "x10/compiler/ws/RemoteFinish.x10"
            final x10.core.Deque t$116652 = x10.xrx.Runtime.wsFIFO();
            
            //#line 45 . "x10/compiler/ws/RemoteFinish.x10"
            t$116652.push(((java.lang.Object)(ff$116651)));
        }
        
        public x10.core.GlobalRef<x10.compiler.ws.FinishFrame> ffRef$116618;
        public x10.util.GrowableRail<java.lang.Throwable> exceptions$116619;
        
        public $Closure$51(final x10.core.GlobalRef<x10.compiler.ws.FinishFrame> ffRef$116618, final x10.util.GrowableRail<java.lang.Throwable> exceptions$116619, __0$1x10$compiler$ws$FinishFrame$2__1$1x10$lang$CheckedThrowable$2 $dummy) {
             {
                this.ffRef$116618 = ((x10.core.GlobalRef)(ffRef$116618));
                this.exceptions$116619 = ((x10.util.GrowableRail)(exceptions$116619));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$52 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$52> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$52> make($Closure$52.class,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.RemoteFinish.$Closure$52 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.exceptions = $deserializer.readObject();
            $_obj.ffRef = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.RemoteFinish.$Closure$52 $_obj = new x10.compiler.ws.RemoteFinish.$Closure$52((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.exceptions);
            $serializer.write(this.ffRef);
            
        }
        
        // constructor just for allocation
        public $Closure$52(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$compiler$ws$FinishFrame$2__1$1x10$lang$CheckedThrowable$2 {}
        
    
        
        public void $apply() {
            
            //#line 43 "x10/compiler/ws/RemoteFinish.x10"
            final x10.core.GlobalRef t$116614 = ((x10.core.GlobalRef)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.core.GlobalRef.$RTT, x10.compiler.ws.FinishFrame.$RTT),this.ffRef));
            
            //#line 43 "x10/compiler/ws/RemoteFinish.x10"
            final x10.lang.Place t$116637 = ((x10.lang.Place)((t$116614).home));
            
            //#line 43 "x10/compiler/ws/RemoteFinish.x10"
            final boolean t$116638 = x10.rtt.Equality.equalsequals((t$116637),(x10.x10rt.X10RT.here()));
            
            //#line 43 "x10/compiler/ws/RemoteFinish.x10"
            final boolean t$116640 = !(t$116638);
            
            //#line 43 "x10/compiler/ws/RemoteFinish.x10"
            if (t$116640) {
                
                //#line 43 "x10/compiler/ws/RemoteFinish.x10"
                final x10.lang.FailedDynamicCheckException t$116639 = new x10.lang.FailedDynamicCheckException("x10.lang.GlobalRef[x10.compiler.ws.FinishFrame]{self.home==here}");
                
                //#line 43 "x10/compiler/ws/RemoteFinish.x10"
                throw t$116639;
            }
            
            //#line 43 "x10/compiler/ws/RemoteFinish.x10"
            final x10.compiler.ws.FinishFrame ff = (((x10.core.GlobalRef<x10.compiler.ws.FinishFrame>)(t$116614))).$apply$G();
            
            //#line 44 "x10/compiler/ws/RemoteFinish.x10"
            ff.append__0$1x10$lang$CheckedThrowable$2(((x10.util.GrowableRail)(this.exceptions)));
            
            //#line 45 "x10/compiler/ws/RemoteFinish.x10"
            final x10.core.Deque t$116641 = x10.xrx.Runtime.wsFIFO();
            
            //#line 45 "x10/compiler/ws/RemoteFinish.x10"
            t$116641.push(((java.lang.Object)(ff)));
        }
        
        public x10.core.GlobalRef<x10.compiler.ws.FinishFrame> ffRef;
        public x10.util.GrowableRail<java.lang.Throwable> exceptions;
        
        public $Closure$52(final x10.core.GlobalRef<x10.compiler.ws.FinishFrame> ffRef, final x10.util.GrowableRail<java.lang.Throwable> exceptions, __0$1x10$compiler$ws$FinishFrame$2__1$1x10$lang$CheckedThrowable$2 $dummy) {
             {
                this.ffRef = ((x10.core.GlobalRef)(ffRef));
                this.exceptions = ((x10.util.GrowableRail)(exceptions));
            }
        }
        
    }
    
    
    public void x10$compiler$ws$FinishFrame$wrapResume$S(final x10.compiler.ws.Worker a0) {
        super.wrapResume(((x10.compiler.ws.Worker)(a0)));
    }
}

