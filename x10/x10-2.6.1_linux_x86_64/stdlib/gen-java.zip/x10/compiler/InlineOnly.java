package x10.compiler;

@x10.runtime.impl.java.X10Generated
public interface InlineOnly extends x10.compiler.Inline, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<InlineOnly> $RTT = 
        x10.rtt.NamedType.<InlineOnly> make("x10.compiler.InlineOnly",
                                            InlineOnly.class,
                                            new x10.rtt.Type[] {
                                                x10.compiler.Inline.$RTT
                                            });
    
    
}

