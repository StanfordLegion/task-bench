package x10.compiler;


/**
 * This annotation on an at statement makes profiling information relating to
 * the statement available to applications.
 *
 * EXAMPLE:
 *
 *      val x = new x10.xrx.Runtime.Profile();
 *      @Profile(x) at (here.next()) {
 *      }
 *      // x now populated with profiling data
 *
 * @see x10.xrx.Runtime.Profile
 */
@x10.runtime.impl.java.X10Generated
public interface Profile extends x10.lang.annotations.StatementAnnotation, x10.lang.annotations.ExpressionAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Profile> $RTT = 
        x10.rtt.NamedType.<Profile> make("x10.compiler.Profile",
                                         Profile.class,
                                         new x10.rtt.Type[] {
                                             x10.lang.annotations.StatementAnnotation.$RTT,
                                             x10.lang.annotations.ExpressionAnnotation.$RTT
                                         });
    
    
}

