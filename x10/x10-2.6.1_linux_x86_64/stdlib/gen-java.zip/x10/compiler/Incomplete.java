package x10.compiler;


/**
 * This annotation is used to mark a method as incomplete.
 * The body of the method should contain something like throw new UnimplementedException().

 * <p> This annotation is putrely for documentation.
 */
@x10.runtime.impl.java.X10Generated
public interface Incomplete extends x10.lang.annotations.MethodAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Incomplete> $RTT = 
        x10.rtt.NamedType.<Incomplete> make("x10.compiler.Incomplete",
                                            Incomplete.class,
                                            new x10.rtt.Type[] {
                                                x10.lang.annotations.MethodAnnotation.$RTT
                                            });
    
    
}

