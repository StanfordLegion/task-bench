package x10.compiler;


/** Annotation on a class that indicates that the post compiler will need an additional file from
 * the same dir as the current x10 file.  This is used e.g. for headers included by headers that are
 * included using NativeCPPInclude.  Does nothing for the Java backend.
 */
@x10.runtime.impl.java.X10Generated
public interface NativeCPPOutputFile extends x10.lang.annotations.ClassAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<NativeCPPOutputFile> $RTT = 
        x10.rtt.NamedType.<NativeCPPOutputFile> make("x10.compiler.NativeCPPOutputFile",
                                                     NativeCPPOutputFile.class,
                                                     new x10.rtt.Type[] {
                                                         x10.lang.annotations.ClassAnnotation.$RTT
                                                     });
    
    
}

