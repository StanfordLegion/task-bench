package x10.compiler;


/**
 * This annotation is used internally by the compiler to mark
 * closures generated as part of the desugaring of async constructs.
 */
@x10.runtime.impl.java.X10Generated
public interface AsyncClosure extends x10.lang.annotations.ExpressionAnnotation, x10.lang.annotations.StatementAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<AsyncClosure> $RTT = 
        x10.rtt.NamedType.<AsyncClosure> make("x10.compiler.AsyncClosure",
                                              AsyncClosure.class,
                                              new x10.rtt.Type[] {
                                                  x10.lang.annotations.ExpressionAnnotation.$RTT,
                                                  x10.lang.annotations.StatementAnnotation.$RTT
                                              });
    
    
}

