package x10.compiler;


/**
 * A single-place lazy-initialised worker-local store.
 * On first access by a particular worker thread, a worker-local instance
 * of type T is created using the provided init operation.
 */
@x10.runtime.impl.java.X10Generated
final public class WorkerLocal<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.core.fun.VoidFun_0_1, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<WorkerLocal> $RTT = 
        x10.rtt.NamedType.<WorkerLocal> make("x10.compiler.WorkerLocal",
                                             WorkerLocal.class,
                                             1,
                                             new x10.rtt.Type[] {
                                                 x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                                 x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_1.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                             });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.WorkerLocal<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.init = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.WorkerLocal $_obj = new x10.compiler.WorkerLocal((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.init);
        
    }
    
    // constructor just for allocation
    public WorkerLocal(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.compiler.WorkerLocal.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1){}:void
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        $apply__0x10$compiler$WorkerLocal$$T(($T)a1); return null;
        
    }
    
    // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1){}:void
    public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1) {
        $apply__0x10$compiler$WorkerLocal$$T(($T)a1);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final WorkerLocal $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$compiler$WorkerLocal$$T$2 {}
    

    
    //#line 23 "x10/compiler/WorkerLocal.x10"
    public transient x10.core.Rail<$T> store;
    
    //#line 24 "x10/compiler/WorkerLocal.x10"
    public x10.core.fun.Fun_0_0<$T> init;
    
    
    //#line 26 "x10/compiler/WorkerLocal.x10"
    // creation method for java code (1-phase java constructor)
    public WorkerLocal(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, __0$1x10$compiler$WorkerLocal$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$compiler$WorkerLocal$$init$S(init, (x10.compiler.WorkerLocal.__0$1x10$compiler$WorkerLocal$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.compiler.WorkerLocal<$T> x10$compiler$WorkerLocal$$init$S(final x10.core.fun.Fun_0_0<$T> init, __0$1x10$compiler$WorkerLocal$$T$2 $dummy) {
         {
            
            //#line 26 "x10/compiler/WorkerLocal.x10"
            
            
            //#line 22 "x10/compiler/WorkerLocal.x10"
            final x10.compiler.WorkerLocal this$115034 = this;
            
            //#line 22 "x10/compiler/WorkerLocal.x10"
            ((x10.compiler.WorkerLocal<$T>)this$115034).init = null;
            
            //#line 27 "x10/compiler/WorkerLocal.x10"
            final int t$114974 = x10.xrx.Runtime.get$MAX_THREADS();
            
            //#line 27 "x10/compiler/WorkerLocal.x10"
            final long t$114975 = ((long)(((int)(t$114974))));
            
            //#line 27 "x10/compiler/WorkerLocal.x10"
            final x10.core.Rail t$114976 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, t$114975)));
            
            //#line 27 "x10/compiler/WorkerLocal.x10"
            ((x10.compiler.WorkerLocal<$T>)this).store = ((x10.core.Rail)(t$114976));
            
            //#line 28 "x10/compiler/WorkerLocal.x10"
            ((x10.compiler.WorkerLocal<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
        }
        return this;
    }
    
    
    
    //#line 31 "x10/compiler/WorkerLocal.x10"
    public $T $apply$G() {
        
        //#line 32 "x10/compiler/WorkerLocal.x10"
        final x10.core.Rail t$114980 = ((x10.core.Rail)(this.store));
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.core.Thread t$114977 = x10.core.Thread.currentThread();
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.xrx.Worker t$114978 = x10.rtt.Types.<x10.xrx.Worker> cast(t$114977,x10.xrx.Worker.$RTT);
        
        //#line 336 . "x10/xrx/Runtime.x10"
        final int t$114979 = t$114978.workerId;
        
        //#line 32 "x10/compiler/WorkerLocal.x10"
        final long t$114981 = ((long)(((int)(t$114979))));
        
        //#line 32 "x10/compiler/WorkerLocal.x10"
        $T t = (($T)(((x10.core.Rail<$T>)t$114980).$apply$G((long)(t$114981))));
        
        //#line 33 "x10/compiler/WorkerLocal.x10"
        final boolean t$114991 = ((t) == (null));
        
        //#line 33 "x10/compiler/WorkerLocal.x10"
        if (t$114991) {
            
            //#line 34 "x10/compiler/WorkerLocal.x10"
            final x10.core.fun.Fun_0_0 t$114983 = ((x10.core.fun.Fun_0_0)(this.init));
            
            //#line 34 "x10/compiler/WorkerLocal.x10"
            final $T t$114984 = (($T)(((x10.core.fun.Fun_0_0<$T>)t$114983).$apply$G()));
            
            //#line 34 "x10/compiler/WorkerLocal.x10"
            t = (($T)(t$114984));
            
            //#line 35 "x10/compiler/WorkerLocal.x10"
            final x10.core.Rail t$114988 = ((x10.core.Rail)(this.store));
            
            //#line 331 .. "x10/xrx/Runtime.x10"
            final x10.core.Thread t$114985 = x10.core.Thread.currentThread();
            
            //#line 331 .. "x10/xrx/Runtime.x10"
            final x10.xrx.Worker t$114986 = x10.rtt.Types.<x10.xrx.Worker> cast(t$114985,x10.xrx.Worker.$RTT);
            
            //#line 336 . "x10/xrx/Runtime.x10"
            final int t$114987 = t$114986.workerId;
            
            //#line 35 "x10/compiler/WorkerLocal.x10"
            final long t$114989 = ((long)(((int)(t$114987))));
            
            //#line 35 "x10/compiler/WorkerLocal.x10"
            ((x10.core.Rail<$T>)t$114988).$set__1x10$lang$Rail$$T$G((long)(t$114989), (($T)(t)));
        }
        
        //#line 37 "x10/compiler/WorkerLocal.x10"
        return t;
    }
    
    
    //#line 40 "x10/compiler/WorkerLocal.x10"
    public void $apply__0x10$compiler$WorkerLocal$$T(final $T t) {
        
        //#line 41 "x10/compiler/WorkerLocal.x10"
        final x10.core.Rail t$114996 = ((x10.core.Rail)(this.store));
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.core.Thread t$114993 = x10.core.Thread.currentThread();
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.xrx.Worker t$114994 = x10.rtt.Types.<x10.xrx.Worker> cast(t$114993,x10.xrx.Worker.$RTT);
        
        //#line 336 . "x10/xrx/Runtime.x10"
        final int t$114995 = t$114994.workerId;
        
        //#line 41 "x10/compiler/WorkerLocal.x10"
        final long t$114997 = ((long)(((int)(t$114995))));
        
        //#line 41 "x10/compiler/WorkerLocal.x10"
        ((x10.core.Rail<$T>)t$114996).$set__1x10$lang$Rail$$T$G((long)(t$114997), (($T)(t)));
    }
    
    
    //#line 48 "x10/compiler/WorkerLocal.x10"
    /**
     * Set the init operation for this worker local handle, and clear all
     * current values.
     */
    public void resetAll__0$1x10$compiler$WorkerLocal$$T$2(final x10.core.fun.Fun_0_0 init) {
        
        //#line 49 "x10/compiler/WorkerLocal.x10"
        final x10.core.Rail t$114998 = ((x10.core.Rail)(this.store));
        
        //#line 49 "x10/compiler/WorkerLocal.x10"
        ((x10.core.Rail<$T>)t$114998).clear();
        
        //#line 50 "x10/compiler/WorkerLocal.x10"
        ((x10.compiler.WorkerLocal<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
    }
    
    
    //#line 56 "x10/compiler/WorkerLocal.x10"
    /** 
     * Apply the given operation in parallel to each thread local value.
     */
    public void applyToAll__0$1x10$compiler$WorkerLocal$$T$2(final x10.core.fun.VoidFun_0_1 op) {
        {
            
            //#line 57 "x10/compiler/WorkerLocal.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 57 "x10/compiler/WorkerLocal.x10"
            final x10.xrx.FinishState fs$115078 = x10.xrx.Runtime.startFinish();
            
            //#line 57 "x10/compiler/WorkerLocal.x10"
            try {{
                {
                    
                    //#line 57 "x10/compiler/WorkerLocal.x10"
                    final x10.core.Rail t$114999 = ((x10.core.Rail)(this.store));
                    
                    //#line 57 "x10/compiler/WorkerLocal.x10"
                    final long t$115000 = ((x10.core.Rail<$T>)t$114999).size;
                    
                    //#line 57 "x10/compiler/WorkerLocal.x10"
                    final long i$113656max$113658 = ((t$115000) - (((long)(1L))));
                    
                    //#line 57 "x10/compiler/WorkerLocal.x10"
                    long i$115041 = 0L;
                    
                    //#line 57 "x10/compiler/WorkerLocal.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 57 "x10/compiler/WorkerLocal.x10"
                        final boolean t$115043 = ((i$115041) <= (((long)(i$113656max$113658))));
                        
                        //#line 57 "x10/compiler/WorkerLocal.x10"
                        if (!(t$115043)) {
                            
                            //#line 57 "x10/compiler/WorkerLocal.x10"
                            break;
                        }
                        
                        //#line 58 "x10/compiler/WorkerLocal.x10"
                        final x10.core.Rail t$115035 = ((x10.core.Rail)(this.store));
                        
                        //#line 58 "x10/compiler/WorkerLocal.x10"
                        final $T t$115036 = (($T)(((x10.core.Rail<$T>)t$115035).$apply$G((long)(i$115041))));
                        
                        //#line 59 "x10/compiler/WorkerLocal.x10"
                        final boolean t$115037 = ((t$115036) != (null));
                        
                        //#line 59 "x10/compiler/WorkerLocal.x10"
                        if (t$115037) {
                            
                            //#line 60 "x10/compiler/WorkerLocal.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.WorkerLocal.$Closure$48<$T>($T, op, t$115036, (x10.compiler.WorkerLocal.$Closure$48.__0$1x10$compiler$WorkerLocal$$Closure$48$$T$2__1x10$compiler$WorkerLocal$$Closure$48$$T) null))));
                        }
                        
                        //#line 57 "x10/compiler/WorkerLocal.x10"
                        final long t$115040 = ((i$115041) + (((long)(1L))));
                        
                        //#line 57 "x10/compiler/WorkerLocal.x10"
                        i$115041 = t$115040;
                    }
                }
            }}catch (java.lang.Throwable ct$115076) {
                
                //#line 57 "x10/compiler/WorkerLocal.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$115076)));
                
                //#line 57 "x10/compiler/WorkerLocal.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 57 "x10/compiler/WorkerLocal.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$115078)));
             }}
            }
        
        //#line 63 "x10/compiler/WorkerLocal.x10"
        return;
        }
    
    
    //#line 69 "x10/compiler/WorkerLocal.x10"
    /** 
     * Reduce partial results from each thread and return combined result.
     */
    public $T reduce__0$1x10$compiler$WorkerLocal$$T$3x10$compiler$WorkerLocal$$T$3x10$compiler$WorkerLocal$$T$2$G(final x10.core.fun.Fun_0_2 op) {
        
        //#line 70 "x10/compiler/WorkerLocal.x10"
        $T result = null;
        
        //#line 71 "x10/compiler/WorkerLocal.x10"
        final x10.core.Rail t$115057 = ((x10.core.Rail)(this.store));
        
        //#line 71 "x10/compiler/WorkerLocal.x10"
        final long t$115058 = ((x10.core.Rail<$T>)t$115057).size;
        
        //#line 71 "x10/compiler/WorkerLocal.x10"
        final long i$113674max$115059 = ((t$115058) - (((long)(1L))));
        
        //#line 71 "x10/compiler/WorkerLocal.x10"
        long i$115054 = 0L;
        
        //#line 71 "x10/compiler/WorkerLocal.x10"
        for (;
             true;
             ) {
            
            //#line 71 "x10/compiler/WorkerLocal.x10"
            final boolean t$115056 = ((i$115054) <= (((long)(i$113674max$115059))));
            
            //#line 71 "x10/compiler/WorkerLocal.x10"
            if (!(t$115056)) {
                
                //#line 71 "x10/compiler/WorkerLocal.x10"
                break;
            }
            
            //#line 72 "x10/compiler/WorkerLocal.x10"
            final x10.core.Rail t$115044 = ((x10.core.Rail)(this.store));
            
            //#line 72 "x10/compiler/WorkerLocal.x10"
            final $T t$115045 = (($T)(((x10.core.Rail<$T>)t$115044).$apply$G((long)(i$115054))));
            
            //#line 73 "x10/compiler/WorkerLocal.x10"
            final boolean t$115046 = ((t$115045) != (null));
            
            //#line 73 "x10/compiler/WorkerLocal.x10"
            if (t$115046) {
                
                //#line 74 "x10/compiler/WorkerLocal.x10"
                final boolean t$115048 = ((result) == (null));
                
                //#line 74 "x10/compiler/WorkerLocal.x10"
                if (t$115048) {
                    
                    //#line 74 "x10/compiler/WorkerLocal.x10"
                    result = (($T)(t$115045));
                } else {
                    
                    //#line 75 "x10/compiler/WorkerLocal.x10"
                    final $T t$115050 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)op).$apply(result, $T, t$115045, $T))));
                    
                    //#line 75 "x10/compiler/WorkerLocal.x10"
                    result = (($T)(t$115050));
                }
            }
            
            //#line 71 "x10/compiler/WorkerLocal.x10"
            final long t$115053 = ((i$115054) + (((long)(1L))));
            
            //#line 71 "x10/compiler/WorkerLocal.x10"
            i$115054 = t$115053;
        }
        
        //#line 78 "x10/compiler/WorkerLocal.x10"
        return result;
    }
    
    
    //#line 90 "x10/compiler/WorkerLocal.x10"
    /** 
     * Reduce partial results from each thread using the given 'result' as
     * the initial value.  
     * This can be used e.g. to sum a Rail[Double] 'in place' as follows:
     * result_worker.reduceLocal( result, 
     *   (a:Rail[Double],b:Rail[Double]) => 
     *      { a.map(result, b, (x:Double,y:Double)=>(x+y) ) as Rail[Double] }
     *   );
     */
    public $T reduce__0x10$compiler$WorkerLocal$$T__1$1x10$compiler$WorkerLocal$$T$3x10$compiler$WorkerLocal$$T$3x10$compiler$WorkerLocal$$T$2$G($T result, final x10.core.fun.Fun_0_2 op) {
        
        //#line 91 "x10/compiler/WorkerLocal.x10"
        final x10.core.Rail t$115071 = ((x10.core.Rail)(this.store));
        
        //#line 91 "x10/compiler/WorkerLocal.x10"
        final long t$115072 = ((x10.core.Rail<$T>)t$115071).size;
        
        //#line 91 "x10/compiler/WorkerLocal.x10"
        final long i$113692max$115073 = ((t$115072) - (((long)(1L))));
        
        //#line 91 "x10/compiler/WorkerLocal.x10"
        long i$115068 = 0L;
        
        //#line 91 "x10/compiler/WorkerLocal.x10"
        for (;
             true;
             ) {
            
            //#line 91 "x10/compiler/WorkerLocal.x10"
            final boolean t$115070 = ((i$115068) <= (((long)(i$113692max$115073))));
            
            //#line 91 "x10/compiler/WorkerLocal.x10"
            if (!(t$115070)) {
                
                //#line 91 "x10/compiler/WorkerLocal.x10"
                break;
            }
            
            //#line 92 "x10/compiler/WorkerLocal.x10"
            final x10.core.Rail t$115060 = ((x10.core.Rail)(this.store));
            
            //#line 92 "x10/compiler/WorkerLocal.x10"
            final $T t$115061 = (($T)(((x10.core.Rail<$T>)t$115060).$apply$G((long)(i$115068))));
            
            //#line 93 "x10/compiler/WorkerLocal.x10"
            final boolean t$115062 = ((t$115061) != (null));
            
            //#line 93 "x10/compiler/WorkerLocal.x10"
            if (t$115062) {
                
                //#line 94 "x10/compiler/WorkerLocal.x10"
                final $T t$115064 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<$T,$T,$T>)op).$apply(result, $T, t$115061, $T))));
                
                //#line 94 "x10/compiler/WorkerLocal.x10"
                result = (($T)(t$115064));
            }
            
            //#line 91 "x10/compiler/WorkerLocal.x10"
            final long t$115067 = ((i$115068) + (((long)(1L))));
            
            //#line 91 "x10/compiler/WorkerLocal.x10"
            i$115068 = t$115067;
        }
        
        //#line 97 "x10/compiler/WorkerLocal.x10"
        return result;
    }
    
    
    //#line 22 "x10/compiler/WorkerLocal.x10"
    final public x10.compiler.WorkerLocal x10$compiler$WorkerLocal$$this$x10$compiler$WorkerLocal() {
        
        //#line 22 "x10/compiler/WorkerLocal.x10"
        return x10.compiler.WorkerLocal.this;
    }
    
    
    //#line 22 "x10/compiler/WorkerLocal.x10"
    final public void __fieldInitializers_x10_compiler_WorkerLocal() {
        
        //#line 22 "x10/compiler/WorkerLocal.x10"
        ((x10.compiler.WorkerLocal<$T>)this).init = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$48<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$48> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$48> make($Closure$48.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.WorkerLocal.$Closure$48<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.t$115036 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.WorkerLocal.$Closure$48 $_obj = new x10.compiler.WorkerLocal.$Closure$48((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            $serializer.write(this.t$115036);
            
        }
        
        // constructor just for allocation
        public $Closure$48(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.compiler.WorkerLocal.$Closure$48.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$48 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$compiler$WorkerLocal$$Closure$48$$T$2__1x10$compiler$WorkerLocal$$Closure$48$$T {}
        
    
        
        public void $apply() {
            
            //#line 60 "x10/compiler/WorkerLocal.x10"
            try {{
                
                //#line 60 "x10/compiler/WorkerLocal.x10"
                ((x10.core.fun.VoidFun_0_1<$T>)this.op).$apply(this.t$115036, $T);
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 60 "x10/compiler/WorkerLocal.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 60 "x10/compiler/WorkerLocal.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.VoidFun_0_1<$T> op;
        public $T t$115036;
        
        public $Closure$48(final x10.rtt.Type $T, final x10.core.fun.VoidFun_0_1<$T> op, final $T t$115036, __0$1x10$compiler$WorkerLocal$$Closure$48$$T$2__1x10$compiler$WorkerLocal$$Closure$48$$T $dummy) {
            x10.compiler.WorkerLocal.$Closure$48.$initParams(this, $T);
             {
                ((x10.compiler.WorkerLocal.$Closure$48<$T>)this).op = ((x10.core.fun.VoidFun_0_1)(op));
                ((x10.compiler.WorkerLocal.$Closure$48<$T>)this).t$115036 = (($T)(t$115036));
            }
        }
        
    }
    
    }
    
    