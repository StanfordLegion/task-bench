package x10.compiler;


/**
 * An annotation to mark classes, fields, or methods that don't appear in the source code.
 */
@x10.runtime.impl.java.X10Generated
public interface Synthetic extends x10.lang.annotations.ClassAnnotation, x10.lang.annotations.FieldAnnotation, x10.lang.annotations.MethodAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Synthetic> $RTT = 
        x10.rtt.NamedType.<Synthetic> make("x10.compiler.Synthetic",
                                           Synthetic.class,
                                           new x10.rtt.Type[] {
                                               x10.lang.annotations.ClassAnnotation.$RTT,
                                               x10.lang.annotations.FieldAnnotation.$RTT,
                                               x10.lang.annotations.MethodAnnotation.$RTT
                                           });
    
    
}

