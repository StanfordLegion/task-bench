package x10.regionarray;


/**
 * This class is an optimized implementation for a
 * distribution that maps all points in its region
 * to a single place.<p>
 */
@x10.runtime.impl.java.X10Generated
final public class ConstantDist extends x10.regionarray.Dist implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<ConstantDist> $RTT = 
        x10.rtt.NamedType.<ConstantDist> make("x10.regionarray.ConstantDist",
                                              ConstantDist.class,
                                              new x10.rtt.Type[] {
                                                  x10.regionarray.Dist.$RTT
                                              });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.ConstantDist $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Dist.$_deserialize_body($_obj, $deserializer);
        $_obj.onePlace = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.ConstantDist $_obj = new x10.regionarray.ConstantDist((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.onePlace);
        
    }
    
    // constructor just for allocation
    public ConstantDist(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    
    // properties
    
    //#line 22 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Place onePlace;
    

    
    
    //#line 27 "x10/regionarray/ConstantDist.x10"
    /**
     * Create a distribution that maps every point in r to p
     */
    // creation method for java code (1-phase java constructor)
    public ConstantDist(final x10.regionarray.Region r, final x10.lang.Place p) {
        this((java.lang.System[]) null);
        x10$regionarray$ConstantDist$$init$S(r, p);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.ConstantDist x10$regionarray$ConstantDist$$init$S(final x10.regionarray.Region r, final x10.lang.Place p) {
         {
            
            //#line 28 "x10/regionarray/ConstantDist.x10"
            final x10.regionarray.Dist this$148548 = ((x10.regionarray.Dist)(this));
            
            //#line 548 . "x10/regionarray/Dist.x10"
            this$148548.region = r;
            
            //#line 29 "x10/regionarray/ConstantDist.x10"
            this.onePlace = p;
            
        }
        return this;
    }
    
    
    
    //#line 32 "x10/regionarray/ConstantDist.x10"
    public x10.lang.PlaceGroup places() {
        
        //#line 32 "x10/regionarray/ConstantDist.x10"
        final x10.lang.SparsePlaceGroup alloc$148544 = ((x10.lang.SparsePlaceGroup)(new x10.lang.SparsePlaceGroup((java.lang.System[]) null)));
        
        //#line 32 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$148615 = ((x10.lang.Place)(this.onePlace));
        
        //#line 32 "x10/regionarray/ConstantDist.x10"
        alloc$148544.x10$lang$SparsePlaceGroup$$init$S(((x10.lang.Place)(t$148615)));
        
        //#line 32 "x10/regionarray/ConstantDist.x10"
        return alloc$148544;
    }
    
    
    //#line 34 "x10/regionarray/ConstantDist.x10"
    public long numPlaces$O() {
        
        //#line 34 "x10/regionarray/ConstantDist.x10"
        return 1L;
    }
    
    
    //#line 36 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Iterable regions() {
        
        //#line 37 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$148570 = ((x10.regionarray.Region)(this.region));
        
        //#line 37 "x10/regionarray/ConstantDist.x10"
        final x10.core.Rail t$148571 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.Region>(x10.regionarray.Region.$RTT, ((long)(1L)), ((x10.regionarray.Region)(t$148570)), (x10.core.Rail.__1x10$lang$Rail$$T) null)));
        
        //#line 37 "x10/regionarray/ConstantDist.x10"
        return t$148571;
    }
    
    
    //#line 40 "x10/regionarray/ConstantDist.x10"
    public x10.regionarray.Region get(final x10.lang.Place p) {
        
        //#line 41 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$148572 = ((x10.lang.Place)(this.onePlace));
        
        //#line 41 "x10/regionarray/ConstantDist.x10"
        final boolean t$148576 = x10.rtt.Equality.equalsequals((p),(t$148572));
        
        //#line 41 "x10/regionarray/ConstantDist.x10"
        if (t$148576) {
            
            //#line 42 "x10/regionarray/ConstantDist.x10"
            final x10.regionarray.Region t$148573 = ((x10.regionarray.Region)(this.region));
            
            //#line 42 "x10/regionarray/ConstantDist.x10"
            return t$148573;
        } else {
            
            //#line 44 "x10/regionarray/ConstantDist.x10"
            final x10.regionarray.Dist this$148553 = ((x10.regionarray.Dist)
                                                       this);
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$148574 = ((x10.regionarray.Region)(this$148553.region));
            
            //#line 44 "x10/regionarray/ConstantDist.x10"
            final long rank$148555 = t$148574.rank;
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.EmptyRegion alloc$148556 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            alloc$148556.x10$regionarray$EmptyRegion$$init$S(((long)(rank$148555)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$148575 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$148556)));
            
            //#line 44 "x10/regionarray/ConstantDist.x10"
            return t$148575;
        }
    }
    
    
    //#line 49 "x10/regionarray/ConstantDist.x10"
    public x10.regionarray.Region $apply(final x10.lang.Place p) {
        
        //#line 49 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$148577 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(p)))));
        
        //#line 49 "x10/regionarray/ConstantDist.x10"
        return t$148577;
    }
    
    
    //#line 51 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Place $apply(final x10.lang.Point pt) {
        
        //#line 52 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$148578 = ((x10.regionarray.Region)(this.region));
        
        //#line 52 "x10/regionarray/ConstantDist.x10"
        final boolean t$148579 = t$148578.contains$O(((x10.lang.Point)(pt)));
        
        //#line 52 "x10/regionarray/ConstantDist.x10"
        final boolean t$148580 = !(t$148579);
        
        //#line 52 "x10/regionarray/ConstantDist.x10"
        if (t$148580) {
            
            //#line 52 "x10/regionarray/ConstantDist.x10"
            x10.regionarray.Dist.raiseBoundsError(((x10.lang.Point)(pt)));
        }
        
        //#line 53 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$148581 = ((x10.lang.Place)(this.onePlace));
        
        //#line 53 "x10/regionarray/ConstantDist.x10"
        return t$148581;
    }
    
    
    //#line 56 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Place $apply(final long i0) {
        
        //#line 57 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$148584 = ((x10.regionarray.Region)(this.region));
        
        //#line 57 "x10/regionarray/ConstantDist.x10"
        final boolean t$148585 = t$148584.contains$O((long)(i0));
        
        //#line 57 "x10/regionarray/ConstantDist.x10"
        final boolean t$148586 = !(t$148585);
        
        //#line 57 "x10/regionarray/ConstantDist.x10"
        if (t$148586) {
            
            //#line 57 "x10/regionarray/ConstantDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0));
        }
        
        //#line 58 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$148587 = ((x10.lang.Place)(this.onePlace));
        
        //#line 58 "x10/regionarray/ConstantDist.x10"
        return t$148587;
    }
    
    
    //#line 61 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1) {
        
        //#line 62 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$148590 = ((x10.regionarray.Region)(this.region));
        
        //#line 62 "x10/regionarray/ConstantDist.x10"
        final boolean t$148591 = t$148590.contains$O((long)(i0), (long)(i1));
        
        //#line 62 "x10/regionarray/ConstantDist.x10"
        final boolean t$148592 = !(t$148591);
        
        //#line 62 "x10/regionarray/ConstantDist.x10"
        if (t$148592) {
            
            //#line 62 "x10/regionarray/ConstantDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1));
        }
        
        //#line 63 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$148593 = ((x10.lang.Place)(this.onePlace));
        
        //#line 63 "x10/regionarray/ConstantDist.x10"
        return t$148593;
    }
    
    
    //#line 66 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2) {
        
        //#line 67 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$148596 = ((x10.regionarray.Region)(this.region));
        
        //#line 67 "x10/regionarray/ConstantDist.x10"
        final boolean t$148597 = t$148596.contains$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 67 "x10/regionarray/ConstantDist.x10"
        final boolean t$148598 = !(t$148597);
        
        //#line 67 "x10/regionarray/ConstantDist.x10"
        if (t$148598) {
            
            //#line 67 "x10/regionarray/ConstantDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 68 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$148599 = ((x10.lang.Place)(this.onePlace));
        
        //#line 68 "x10/regionarray/ConstantDist.x10"
        return t$148599;
    }
    
    
    //#line 71 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 72 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$148602 = ((x10.regionarray.Region)(this.region));
        
        //#line 72 "x10/regionarray/ConstantDist.x10"
        final boolean t$148603 = t$148602.contains$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 72 "x10/regionarray/ConstantDist.x10"
        final boolean t$148604 = !(t$148603);
        
        //#line 72 "x10/regionarray/ConstantDist.x10"
        if (t$148604) {
            
            //#line 72 "x10/regionarray/ConstantDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        }
        
        //#line 73 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$148605 = ((x10.lang.Place)(this.onePlace));
        
        //#line 73 "x10/regionarray/ConstantDist.x10"
        return t$148605;
    }
    
    
    //#line 76 "x10/regionarray/ConstantDist.x10"
    public x10.regionarray.Dist restriction(final x10.regionarray.Region r) {
        
        //#line 77 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.WrappedDistRegionRestricted alloc$148545 = ((x10.regionarray.WrappedDistRegionRestricted)(new x10.regionarray.WrappedDistRegionRestricted((java.lang.System[]) null)));
        
        //#line 77 "x10/regionarray/ConstantDist.x10"
        alloc$148545.x10$regionarray$WrappedDistRegionRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.regionarray.Region)(r)));
        
        //#line 77 "x10/regionarray/ConstantDist.x10"
        return alloc$148545;
    }
    
    
    //#line 80 "x10/regionarray/ConstantDist.x10"
    public x10.regionarray.Dist restriction(final x10.lang.Place p) {
        
        //#line 81 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.WrappedDistPlaceRestricted alloc$148546 = ((x10.regionarray.WrappedDistPlaceRestricted)(new x10.regionarray.WrappedDistPlaceRestricted((java.lang.System[]) null)));
        
        //#line 81 "x10/regionarray/ConstantDist.x10"
        alloc$148546.x10$regionarray$WrappedDistPlaceRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.lang.Place)(p)));
        
        //#line 81 "x10/regionarray/ConstantDist.x10"
        return alloc$148546;
    }
    
    
    //#line 84 "x10/regionarray/ConstantDist.x10"
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 85 "x10/regionarray/ConstantDist.x10"
        final boolean t$148606 = x10.regionarray.ConstantDist.$RTT.isInstance(thatObj);
        
        //#line 85 "x10/regionarray/ConstantDist.x10"
        final boolean t$148607 = !(t$148606);
        
        //#line 85 "x10/regionarray/ConstantDist.x10"
        if (t$148607) {
            
            //#line 85 "x10/regionarray/ConstantDist.x10"
            return false;
        }
        
        //#line 86 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.ConstantDist that = ((x10.regionarray.ConstantDist)(x10.rtt.Types.<x10.regionarray.ConstantDist> cast(thatObj,x10.regionarray.ConstantDist.$RTT)));
        
        //#line 87 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place this$148567 = ((x10.lang.Place)(this.onePlace));
        
        //#line 87 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place p$148566 = ((x10.lang.Place)(that.onePlace));
        
        //#line 139 . "x10/lang/Place.x10"
        final long t$148608 = p$148566.id;
        
        //#line 139 . "x10/lang/Place.x10"
        final long t$148609 = this$148567.id;
        
        //#line 87 "x10/regionarray/ConstantDist.x10"
        boolean t$148612 = ((long) t$148608) == ((long) t$148609);
        
        //#line 87 "x10/regionarray/ConstantDist.x10"
        if (t$148612) {
            
            //#line 87 "x10/regionarray/ConstantDist.x10"
            final x10.regionarray.Region t$148610 = ((x10.regionarray.Region)(this.region));
            
            //#line 87 "x10/regionarray/ConstantDist.x10"
            final x10.regionarray.Region t$148611 = ((x10.regionarray.Region)(that.region));
            
            //#line 87 "x10/regionarray/ConstantDist.x10"
            t$148612 = t$148610.equals(((java.lang.Object)(t$148611)));
        }
        
        //#line 87 "x10/regionarray/ConstantDist.x10"
        return t$148612;
    }
    
    
    //#line 22 "x10/regionarray/ConstantDist.x10"
    final public x10.regionarray.ConstantDist x10$regionarray$ConstantDist$$this$x10$regionarray$ConstantDist() {
        
        //#line 22 "x10/regionarray/ConstantDist.x10"
        return x10.regionarray.ConstantDist.this;
    }
    
    
    //#line 22 "x10/regionarray/ConstantDist.x10"
    final public void __fieldInitializers_x10_regionarray_ConstantDist() {
        
    }
}

