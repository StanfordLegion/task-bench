package x10.regionarray;


/**
 * <p>A distributed array (DistArray) defines a mapping from {@link Point}s to data 
 * values of some type T. The Points in the DistArray's domain are defined by
 * specifying a {@link Region} over which the Array is defined.  Attempting to access 
 * a data value at a Point not included in the Array's Region will result in a 
 * {@link ArrayIndexOutOfBoundsException} being raised. The array's distribution ({@link Dist})
 * defines a mapping for the Points in the DistArray's region to Places. This defines
 * the Place where the data element for each Point is actually stored. Attempting to access
 * a data element from any other place will result in a {@link BadPlaceException} being
 * raised.</p>
 *
 * <p>The closely related class {@link Array} is used to define 
 * non-distributed arrays where the data values for the Points in the 
 * array's domain are all stored in a single place.  Although it is possible to
 * use a DistArray to store data in only a single place by creating a "constant distribution",
 * an Array will significantly outperform a DistArray with a constant distribution.</p>
 *
 * @see Point
 * @see Region
 * @see Dist
 * @see Array
 */
@x10.runtime.impl.java.X10Generated
final public class DistArray<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.lang.Iterable, x10.regionarray.Ghostable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray> $RTT = 
        x10.rtt.NamedType.<DistArray> make("x10.regionarray.DistArray",
                                           DistArray.class,
                                           1,
                                           new x10.rtt.Type[] {
                                               x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.lang.Point.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                               x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.lang.Point.$RTT),
                                               x10.regionarray.Ghostable.$RTT
                                           });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.dist = $deserializer.readObject();
        $_obj.localHandle = $deserializer.readObject();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localRegion = $_obj.getLocalRegionFromLocalHandle();
        $_obj.raw = $_obj.getRawFromLocalHandle();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.DistArray $_obj = new x10.regionarray.DistArray((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.dist);
        $serializer.write(this.localHandle);
        
    }
    
    // constructor just for allocation
    public DistArray(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.regionarray.DistArray.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $apply$G((x10.lang.Point)a1);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1x10$regionarray$DistArray$$T {}
    // synthetic type for parameter mangling
    public static final class __0$1x10$regionarray$DistArray$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$T$2$2 {}
    
    // properties
    
    //#line 49 "x10/regionarray/DistArray.x10"
    /**
     * The distribution of this array.
     */
    public x10.regionarray.Dist dist;
    

    
    
    //#line 62 "x10/regionarray/DistArray.x10"
    /**
     * The region this array is defined over.
     */
    final public x10.regionarray.Region region() {
        
        //#line 62 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150081 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 62 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150082 = ((x10.regionarray.Region)(t$150081.region));
        
        //#line 62 "x10/regionarray/DistArray.x10"
        return t$150082;
    }
    
    
    //#line 67 "x10/regionarray/DistArray.x10"
    /**
     * The rank of this array.
     */
    final public long rank$O() {
        
        //#line 67 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist this$149828 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 38 . "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$150083 = ((x10.regionarray.Region)(this$149828.region));
        
        //#line 38 . "x10/regionarray/Dist.x10"
        final long t$150084 = t$150083.rank;
        
        //#line 67 "x10/regionarray/DistArray.x10"
        return t$150084;
    }
    
    
    //#line 69 "x10/regionarray/DistArray.x10"
    public x10.regionarray.Dist getDist() {
        
        //#line 69 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150085 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 69 "x10/regionarray/DistArray.x10"
        return t$150085;
    }
    
    
    //#line 71 "x10/regionarray/DistArray.x10"
    @x10.runtime.impl.java.X10Generated
    public static class LocalState<$T> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<LocalState> $RTT = 
            x10.rtt.NamedType.<LocalState> make("x10.regionarray.DistArray.LocalState",
                                                LocalState.class,
                                                1);
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.LocalState<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.data = $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.ghostManager = $deserializer.readObject();
            $_obj.localRegion = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.LocalState $_obj = new x10.regionarray.DistArray.LocalState((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.data);
            $serializer.write(this.dist);
            $serializer.write(this.ghostManager);
            $serializer.write(this.localRegion);
            
        }
        
        // constructor just for allocation
        public LocalState(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.LocalState.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final LocalState $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __1$1x10$regionarray$DistArray$LocalState$$T$2 {}
        
        // properties
        
        //#line 71 "x10/regionarray/DistArray.x10"
        public x10.regionarray.Dist dist;
        
        //#line 71 "x10/regionarray/DistArray.x10"
        public x10.core.Rail<$T> data;
        
        //#line 71 "x10/regionarray/DistArray.x10"
        public x10.regionarray.Region localRegion;
        
    
        
        //#line 72 "x10/regionarray/DistArray.x10"
        public x10.regionarray.GhostManager ghostManager;
        
        
        //#line 73 "x10/regionarray/DistArray.x10"
        // creation method for java code (1-phase java constructor)
        public LocalState(final x10.rtt.Type $T, final x10.regionarray.Dist d, final x10.core.Rail<$T> c, final x10.regionarray.Region r, final x10.regionarray.GhostManager ghostManager, __1$1x10$regionarray$DistArray$LocalState$$T$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$regionarray$DistArray$LocalState$$init$S(d, c, r, ghostManager, (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.DistArray.LocalState<$T> x10$regionarray$DistArray$LocalState$$init$S(final x10.regionarray.Dist d, final x10.core.Rail<$T> c, final x10.regionarray.Region r, final x10.regionarray.GhostManager ghostManager, __1$1x10$regionarray$DistArray$LocalState$$T$2 $dummy) {
             {
                
                //#line 74 "x10/regionarray/DistArray.x10"
                this.dist = d;
                this.data = ((x10.core.Rail)(c));
                this.localRegion = ((x10.regionarray.Region)(r));
                
                
                //#line 75 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.DistArray.LocalState<$T>)this).ghostManager = ((x10.regionarray.GhostManager)(ghostManager));
                
                //#line 81 "x10/regionarray/DistArray.x10"
                d.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())));
            }
            return this;
        }
        
        
        
        //#line 84 "x10/regionarray/DistArray.x10"
        // creation method for java code (1-phase java constructor)
        public LocalState(final x10.rtt.Type $T, final x10.regionarray.Dist d, final x10.core.Rail<$T> c, __1$1x10$regionarray$DistArray$LocalState$$T$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$regionarray$DistArray$LocalState$$init$S(d, c, (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.DistArray.LocalState<$T> x10$regionarray$DistArray$LocalState$$init$S(final x10.regionarray.Dist d, final x10.core.Rail<$T> c, __1$1x10$regionarray$DistArray$LocalState$$T$2 $dummy) {
             {
                
                //#line 85 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150664 = ((x10.regionarray.Region)(d.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 85 "x10/regionarray/DistArray.x10"
                this.dist = d;
                this.data = ((x10.core.Rail)(c));
                this.localRegion = ((x10.regionarray.Region)(t$150664));
                
                
                //#line 86 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.DistArray.LocalState<$T>)this).ghostManager = null;
                
                //#line 87 "x10/regionarray/DistArray.x10"
                d.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())));
            }
            return this;
        }
        
        
        
        //#line 71 "x10/regionarray/DistArray.x10"
        final public x10.regionarray.DistArray.LocalState x10$regionarray$DistArray$LocalState$$this$x10$regionarray$DistArray$LocalState() {
            
            //#line 71 "x10/regionarray/DistArray.x10"
            return x10.regionarray.DistArray.LocalState.this;
        }
        
        
        //#line 71 "x10/regionarray/DistArray.x10"
        final public void __fieldInitializers_x10_regionarray_DistArray_LocalState() {
            
        }
    }
    
    
    
    //#line 91 "x10/regionarray/DistArray.x10"
    private static x10.regionarray.GhostManager getGhostManager(final x10.regionarray.Dist d, final long ghostWidth, final boolean periodic) {
        
        //#line 92 "x10/regionarray/DistArray.x10"
        final boolean t$150087 = ((ghostWidth) < (((long)(1L))));
        
        //#line 92 "x10/regionarray/DistArray.x10"
        if (t$150087) {
            
            //#line 92 "x10/regionarray/DistArray.x10"
            return null;
        }
        
        //#line 94 "x10/regionarray/DistArray.x10"
        boolean t$150089 = !(periodic);
        
        //#line 94 "x10/regionarray/DistArray.x10"
        if (t$150089) {
            
            //#line 94 "x10/regionarray/DistArray.x10"
            final long t$150088 = d.numPlaces$O();
            
            //#line 94 "x10/regionarray/DistArray.x10"
            t$150089 = ((long) t$150088) == ((long) 1L);
        }
        
        //#line 94 "x10/regionarray/DistArray.x10"
        if (t$150089) {
            
            //#line 94 "x10/regionarray/DistArray.x10"
            return null;
        }
        
        //#line 96 "x10/regionarray/DistArray.x10"
        final x10.regionarray.GhostManager t$150091 = d.getLocalGhostManager((long)(ghostWidth), (boolean)(periodic));
        
        //#line 96 "x10/regionarray/DistArray.x10"
        return t$150091;
    }
    
    public static x10.regionarray.GhostManager getGhostManager$P(final x10.regionarray.Dist d, final long ghostWidth, final boolean periodic) {
        return x10.regionarray.DistArray.getGhostManager(((x10.regionarray.Dist)(d)), (long)(ghostWidth), (boolean)(periodic));
    }
    
    
    //#line 100 "x10/regionarray/DistArray.x10"
    /** The place-local state for the DistArray */
    public x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle;
    
    //#line 106 "x10/regionarray/DistArray.x10"
    /** 
     * The place-local backing storage for elements of the DistArray.
     */
    public transient x10.core.Rail<$T> raw;
    
    
    //#line 107 "x10/regionarray/DistArray.x10"
    public x10.core.Rail getRawFromLocalHandle() {
        
        //#line 108 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle t$150092 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 108 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray.LocalState ls = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$150092).$apply$G()));
        
        //#line 109 "x10/regionarray/DistArray.x10"
        final boolean t$150093 = ((ls) != (null));
        
        //#line 109 "x10/regionarray/DistArray.x10"
        x10.core.Rail t$150094 =  null;
        
        //#line 109 "x10/regionarray/DistArray.x10"
        if (t$150093) {
            
            //#line 109 "x10/regionarray/DistArray.x10"
            t$150094 = ((x10.core.Rail)(((x10.regionarray.DistArray.LocalState<$T>)ls).data));
        } else {
            
            //#line 109 "x10/regionarray/DistArray.x10"
            t$150094 = ((x10.core.Rail)(new x10.core.Rail<$T>($T)));
        }
        
        //#line 109 "x10/regionarray/DistArray.x10"
        return t$150094;
    }
    
    
    //#line 117 "x10/regionarray/DistArray.x10"
    /**
     * Method to acquire a pointer to the backing storage for the 
     * array's data in the current place.
     */
    final public x10.core.Rail raw() {
        
        //#line 117 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150096 = ((x10.core.Rail)(this.raw));
        
        //#line 117 "x10/regionarray/DistArray.x10"
        return t$150096;
    }
    
    
    //#line 123 "x10/regionarray/DistArray.x10"
    /**
     * The region for which backing storage is allocated at this place.
     */
    public transient x10.regionarray.Region localRegion;
    
    
    //#line 124 "x10/regionarray/DistArray.x10"
    public x10.regionarray.Region getLocalRegionFromLocalHandle() {
        
        //#line 125 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle t$150097 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 125 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray.LocalState ls = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$150097).$apply$G()));
        
        //#line 126 "x10/regionarray/DistArray.x10"
        x10.regionarray.Region r =  null;
        
        //#line 127 "x10/regionarray/DistArray.x10"
        final boolean t$150101 = ((ls) != (null));
        
        //#line 127 "x10/regionarray/DistArray.x10"
        if (t$150101) {
            
            //#line 127 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150098 = ((x10.regionarray.Region)(((x10.regionarray.DistArray.LocalState<$T>)ls).localRegion));
            
            //#line 127 "x10/regionarray/DistArray.x10"
            r = ((x10.regionarray.Region)(t$150098));
        } else {
            
            //#line 128 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$149834 = ((x10.regionarray.DistArray)(this));
            
            //#line 67 . "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist this$149836 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$149834).dist));
            
            //#line 38 .. "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$150099 = ((x10.regionarray.Region)(this$149836.region));
            
            //#line 128 "x10/regionarray/DistArray.x10"
            final long rank$149838 = t$150099.rank;
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.EmptyRegion alloc$149839 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            alloc$149839.x10$regionarray$EmptyRegion$$init$S(((long)(rank$149838)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$150100 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$149839)));
            
            //#line 128 "x10/regionarray/DistArray.x10"
            r = ((x10.regionarray.Region)(t$150100));
        }
        
        //#line 129 "x10/regionarray/DistArray.x10"
        return r;
    }
    
    
    //#line 138 "x10/regionarray/DistArray.x10"
    final public x10.regionarray.Region localRegion() {
        
        //#line 138 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150103 = ((x10.regionarray.Region)(this.localRegion));
        
        //#line 138 "x10/regionarray/DistArray.x10"
        return t$150103;
    }
    
    
    //#line 144 "x10/regionarray/DistArray.x10"
    /**
     * @return the portion of the DistArray (including ghosts) that is stored 
     *   locally at the current place, as an Array
     */
    public x10.regionarray.Array getLocalPortion() {
        
        //#line 145 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149841 = ((x10.regionarray.DistArray)(this));
        
        //#line 145 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region regionForHere = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149841).localRegion));
        
        //#line 146 "x10/regionarray/DistArray.x10"
        final boolean t$150104 = regionForHere.rect;
        
        //#line 146 "x10/regionarray/DistArray.x10"
        final boolean t$150108 = !(t$150104);
        
        //#line 146 "x10/regionarray/DistArray.x10"
        if (t$150108) {
            
            //#line 146 "x10/regionarray/DistArray.x10"
            final java.lang.String t$150105 = x10.rtt.Types.typeName(((java.lang.Object)(this)));
            
            //#line 146 "x10/regionarray/DistArray.x10"
            final java.lang.String t$150106 = ((t$150105) + (".getLocalPortion(): local portion is not rectangular!"));
            
            //#line 146 "x10/regionarray/DistArray.x10"
            final java.lang.UnsupportedOperationException t$150107 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$150106)));
            
            //#line 146 "x10/regionarray/DistArray.x10"
            throw t$150107;
        }
        
        //#line 147 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Array alloc$149718 = ((x10.regionarray.Array)(new x10.regionarray.Array<$T>((java.lang.System[]) null, $T)));
        
        //#line 147 "x10/regionarray/DistArray.x10"
        final x10.core.Rail backingStore$149844 = ((x10.core.Rail)(this.raw));
        
        //#line 233 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$150666 = ((x10.regionarray.Region)
                                                  regionForHere);
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$150667 = ((t$150666) != (null));
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$150668 = !(t$150667);
        
        //#line 233 . "x10/regionarray/Array.x10"
        if (t$150668) {
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$150669 = true;
            
            //#line 233 . "x10/regionarray/Array.x10"
            if (t$150669) {
                
                //#line 233 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$150670 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 233 . "x10/regionarray/Array.x10"
                throw t$150670;
            }
        }
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149718).region = ((x10.regionarray.Region)(t$150666));
        
        //#line 233 . "x10/regionarray/Array.x10"
        final long t$150671 = regionForHere.rank;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149718).rank = t$150671;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$150672 = regionForHere.rect;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149718).rect = t$150672;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$150673 = regionForHere.zeroBased;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149718).zeroBased = t$150673;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$150674 = regionForHere.rail;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149718).rail = t$150674;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final long t$150675 = regionForHere.size$O();
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149718).size = t$150675;
        
        //#line 235 . "x10/regionarray/Array.x10"
        final x10.regionarray.Array.LayoutHelper crh$150676 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
        
        //#line 235 . "x10/regionarray/Array.x10"
        crh$150676.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(regionForHere)));
        
        //#line 236 . "x10/regionarray/Array.x10"
        final long t$150677 = crh$150676.min0;
        
        //#line 236 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149718).layout_min0 = t$150677;
        
        //#line 237 . "x10/regionarray/Array.x10"
        final long t$150678 = crh$150676.stride1;
        
        //#line 237 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149718).layout_stride1 = t$150678;
        
        //#line 238 . "x10/regionarray/Array.x10"
        final long t$150679 = crh$150676.min1;
        
        //#line 238 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149718).layout_min1 = t$150679;
        
        //#line 239 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$150680 = ((x10.core.Rail)(crh$150676.layout));
        
        //#line 239 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149718).layout = ((x10.core.Rail)(t$150680));
        
        //#line 240 . "x10/regionarray/Array.x10"
        final long n$150681 = crh$150676.size;
        
        //#line 241 . "x10/regionarray/Array.x10"
        final long t$150682 = ((x10.core.Rail<$T>)backingStore$149844).size;
        
        //#line 241 . "x10/regionarray/Array.x10"
        final boolean t$150683 = ((n$150681) > (((long)(t$150682))));
        
        //#line 241 . "x10/regionarray/Array.x10"
        if (t$150683) {
            
            //#line 242 . "x10/regionarray/Array.x10"
            final boolean t$150684 = true;
            
            //#line 242 . "x10/regionarray/Array.x10"
            if (t$150684) {
                
                //#line 242 . "x10/regionarray/Array.x10"
                final java.lang.IllegalArgumentException t$150685 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("backingStore too small")));
                
                //#line 242 . "x10/regionarray/Array.x10"
                throw t$150685;
            }
        }
        
        //#line 244 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$150686 = ((x10.core.Rail<$T>)
                                         backingStore$149844);
        
        //#line 244 . "x10/regionarray/Array.x10"
        final boolean t$150687 = ((t$150686) != (null));
        
        //#line 244 . "x10/regionarray/Array.x10"
        final boolean t$150688 = !(t$150687);
        
        //#line 244 . "x10/regionarray/Array.x10"
        if (t$150688) {
            
            //#line 244 . "x10/regionarray/Array.x10"
            final boolean t$150689 = true;
            
            //#line 244 . "x10/regionarray/Array.x10"
            if (t$150689) {
                
                //#line 244 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$150690 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self!=null}");
                
                //#line 244 . "x10/regionarray/Array.x10"
                throw t$150690;
            }
        }
        
        //#line 244 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149718).raw = ((x10.core.Rail)(t$150686));
        
        //#line 147 "x10/regionarray/DistArray.x10"
        return alloc$149718;
    }
    
    
    //#line 156 "x10/regionarray/DistArray.x10"
    /**
     * Create a zero-initialized distributed array over the argument distribution.
     *
     * @param dist the given distribution
     * @return the newly created DistArray
     */
    public static <$T>x10.regionarray.DistArray make(final x10.rtt.Type $T, final x10.regionarray.Dist dist) {
        
        //#line 156 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$149719 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 169 . "x10/regionarray/DistArray.x10"
        alloc$149719.x10$regionarray$DistArray$$init$S(dist, ((long)(0L)), ((boolean)(false)));
        
        //#line 156 "x10/regionarray/DistArray.x10"
        return alloc$149719;
    }
    
    
    //#line 166 "x10/regionarray/DistArray.x10"
    /**
     * Create a zero-initialized distributed array over the argument distribution.
     *
     * @param dist the given distribution
     * @param ghostWidth the width of the ghost region in every dimension
     * @param periodic whether to apply periodic boundary conditions
     * @return the newly created DistArray
     */
    public static <$T>x10.regionarray.DistArray make(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final long ghostWidth, final boolean periodic) {
        
        //#line 166 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$149720 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 166 "x10/regionarray/DistArray.x10"
        alloc$149720.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(dist)), ((long)(ghostWidth)), ((boolean)(periodic)));
        
        //#line 166 "x10/regionarray/DistArray.x10"
        return alloc$149720;
    }
    
    
    //#line 168 "x10/regionarray/DistArray.x10"
    // creation method for java code (1-phase java constructor)
    public DistArray(final x10.rtt.Type $T, final x10.regionarray.Dist dist) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$DistArray$$init$S(dist);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.DistArray<$T> x10$regionarray$DistArray$$init$S(final x10.regionarray.Dist dist) {
         {
            
            //#line 169 "x10/regionarray/DistArray.x10"
            /*this.*/x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(dist)), ((long)(0L)), ((boolean)(false)));
        }
        return this;
    }
    
    
    
    //#line 172 "x10/regionarray/DistArray.x10"
    // creation method for java code (1-phase java constructor)
    public DistArray(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final long ghostWidth, final boolean periodic) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$DistArray$$init$S(dist, ghostWidth, periodic);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.DistArray<$T> x10$regionarray$DistArray$$init$S(final x10.regionarray.Dist dist, final long ghostWidth, final boolean periodic) {
         {
            
            //#line 173 "x10/regionarray/DistArray.x10"
            this.dist = dist;
            
            
            //#line 187 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceGroup t$150140 = dist.places();
            
            //#line 175 "x10/regionarray/DistArray.x10"
            final x10.core.fun.Fun_0_0 t$150141 = ((x10.core.fun.Fun_0_0)(new x10.regionarray.DistArray.$Closure$179<$T>($T, dist, ghostWidth, periodic)));
            
            //#line 187 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceLocalHandle t$150142 = x10.lang.PlaceLocalHandle.<x10.regionarray.DistArray.LocalState<$T>> makeFlat__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, $T), ((x10.lang.PlaceGroup)(t$150140)), ((x10.core.fun.Fun_0_0)(t$150141)));
            
            //#line 187 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(t$150142));
            
            //#line 188 "x10/regionarray/DistArray.x10"
            final x10.core.Rail t$150143 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                              this.getRawFromLocalHandle())));
            
            //#line 188 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).raw = ((x10.core.Rail)(t$150143));
            
            //#line 189 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150144 = ((x10.regionarray.Region)(this.getLocalRegionFromLocalHandle()));
            
            //#line 189 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localRegion = ((x10.regionarray.Region)(t$150144));
        }
        return this;
    }
    
    
    
    //#line 208 "x10/regionarray/DistArray.x10"
    /**
     * Create a distributed array over the argument distribution whose elements
     * are initialized by executing the given initializer function for each 
     * element of the array in the place where the argument Point is mapped. 
     * The function will be evaluated exactly once for each point
     * in dist in an arbitrary order to compute the initial value for each array element.</p>
     * 
     * Within each place, it is unspecified whether the function evaluations will
     * be done sequentially by a single activity for each point or concurrently for disjoint sets 
     * of points by one or more child activities. 
     * 
     * @param dist the given distribution
     * @param init the initializer function
     * @return the newly created DistArray
     * @see #make[T](Dist)
     */
    public static <$T>x10.regionarray.DistArray make__1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init) {
        
        //#line 208 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$149722 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 208 "x10/regionarray/DistArray.x10"
        alloc$149722.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(dist)), ((x10.core.fun.Fun_0_1)(init)), ((long)(0L)), ((boolean)(false)), (x10.regionarray.DistArray.__1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2) null);
        
        //#line 208 "x10/regionarray/DistArray.x10"
        return alloc$149722;
    }
    
    
    //#line 228 "x10/regionarray/DistArray.x10"
    /**
     * Create a distributed array over the argument distribution whose elements
     * are initialized by executing the given initializer function for each 
     * element of the array in the place where the argument Point is mapped. 
     * The function will be evaluated exactly once for each point in dist in an
     * arbitrary order to compute the initial value for each array element.</p>
     * 
     * Within each place, it is unspecified whether the function evaluations will
     * be done sequentially by a single activity for each point or concurrently for disjoint sets 
     * of points by one or more child activities. 
     * 
     * @param dist the given distribution
     * @param init the initializer function
     * @param ghostWidth the width of the ghost region in every dimension
     * @param periodic whether to apply periodic boundary conditions
     * @return the newly created DistArray
     * @see #make[T](Dist)
     */
    public static <$T>x10.regionarray.DistArray make__1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init, final long ghostWidth, final boolean periodic) {
        
        //#line 228 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$149723 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 228 "x10/regionarray/DistArray.x10"
        alloc$149723.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(dist)), ((x10.core.fun.Fun_0_1)(init)), ((long)(ghostWidth)), ((boolean)(periodic)), (x10.regionarray.DistArray.__1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2) null);
        
        //#line 228 "x10/regionarray/DistArray.x10"
        return alloc$149723;
    }
    
    
    //#line 230 "x10/regionarray/DistArray.x10"
    // creation method for java code (1-phase java constructor)
    public DistArray(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init, final long ghostWidth, final boolean periodic, __1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$DistArray$$init$S(dist, init, ghostWidth, periodic, (x10.regionarray.DistArray.__1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.DistArray<$T> x10$regionarray$DistArray$$init$S(final x10.regionarray.Dist dist, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init, final long ghostWidth, final boolean periodic, __1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2 $dummy) {
         {
            
            //#line 231 "x10/regionarray/DistArray.x10"
            this.dist = dist;
            
            
            //#line 249 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceGroup t$150159 = dist.places();
            
            //#line 233 "x10/regionarray/DistArray.x10"
            final x10.core.fun.Fun_0_0 t$150160 = ((x10.core.fun.Fun_0_0)(new x10.regionarray.DistArray.$Closure$180<$T>($T, dist, ghostWidth, periodic, init, (x10.regionarray.DistArray.$Closure$180.__3$1x10$lang$Point$3x10$regionarray$DistArray$$Closure$180$$T$2) null)));
            
            //#line 249 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceLocalHandle t$150161 = x10.lang.PlaceLocalHandle.<x10.regionarray.DistArray.LocalState<$T>> make__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, $T), ((x10.lang.PlaceGroup)(t$150159)), ((x10.core.fun.Fun_0_0)(t$150160)));
            
            //#line 249 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(t$150161));
            
            //#line 250 "x10/regionarray/DistArray.x10"
            final x10.core.Rail t$150162 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                              this.getRawFromLocalHandle())));
            
            //#line 250 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).raw = ((x10.core.Rail)(t$150162));
            
            //#line 251 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150163 = ((x10.regionarray.Region)(this.getLocalRegionFromLocalHandle()));
            
            //#line 251 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localRegion = ((x10.regionarray.Region)(t$150163));
        }
        return this;
    }
    
    
    
    //#line 264 "x10/regionarray/DistArray.x10"
    /**
     * Create a distributed array over the argument distribution whose elements
     * are initialized to the given initial value.
     *
     * @param dist the given distribution
     * @param init the initial value
     * @return the newly created DistArray
     * @see #make[T](Dist)
     */
    public static <$T>x10.regionarray.DistArray make__1x10$regionarray$DistArray$$T(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final $T init) {
        
        //#line 264 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$149725 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 264 "x10/regionarray/DistArray.x10"
        alloc$149725.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(dist)), (($T)(init)), ((long)(0L)), ((boolean)(false)), (x10.regionarray.DistArray.__1x10$regionarray$DistArray$$T) null);
        
        //#line 264 "x10/regionarray/DistArray.x10"
        return alloc$149725;
    }
    
    
    //#line 277 "x10/regionarray/DistArray.x10"
    /**
     * Create a distributed array over the argument distribution whose elements
     * are initialized to the given initial value.
     *
     * @param dist the given distribution
     * @param init the initial value
     * @param ghostWidth the width of the ghost region in every dimension
     * @param periodic whether to apply periodic boundary conditions
     * @return the newly created DistArray
     * @see #make[T](Dist)
     */
    public static <$T>x10.regionarray.DistArray make__1x10$regionarray$DistArray$$T(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final $T init, final long ghostWidth, final boolean periodic) {
        
        //#line 277 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$149726 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 277 "x10/regionarray/DistArray.x10"
        alloc$149726.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(dist)), (($T)(init)), ((long)(ghostWidth)), ((boolean)(periodic)), (x10.regionarray.DistArray.__1x10$regionarray$DistArray$$T) null);
        
        //#line 277 "x10/regionarray/DistArray.x10"
        return alloc$149726;
    }
    
    
    //#line 279 "x10/regionarray/DistArray.x10"
    // creation method for java code (1-phase java constructor)
    public DistArray(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final $T init, final long ghostWidth, final boolean periodic, __1x10$regionarray$DistArray$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$DistArray$$init$S(dist, init, ghostWidth, periodic, (x10.regionarray.DistArray.__1x10$regionarray$DistArray$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.DistArray<$T> x10$regionarray$DistArray$$init$S(final x10.regionarray.Dist dist, final $T init, final long ghostWidth, final boolean periodic, __1x10$regionarray$DistArray$$T $dummy) {
         {
            
            //#line 280 "x10/regionarray/DistArray.x10"
            this.dist = dist;
            
            
            //#line 294 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceGroup t$150174 = dist.places();
            
            //#line 282 "x10/regionarray/DistArray.x10"
            final x10.core.fun.Fun_0_0 t$150175 = ((x10.core.fun.Fun_0_0)(new x10.regionarray.DistArray.$Closure$181<$T>($T, dist, ghostWidth, periodic, init, (x10.regionarray.DistArray.$Closure$181.__3x10$regionarray$DistArray$$Closure$181$$T) null)));
            
            //#line 294 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceLocalHandle t$150176 = x10.lang.PlaceLocalHandle.<x10.regionarray.DistArray.LocalState<$T>> make__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, $T), ((x10.lang.PlaceGroup)(t$150174)), ((x10.core.fun.Fun_0_0)(t$150175)));
            
            //#line 294 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(t$150176));
            
            //#line 295 "x10/regionarray/DistArray.x10"
            final x10.core.Rail t$150177 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                              this.getRawFromLocalHandle())));
            
            //#line 295 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).raw = ((x10.core.Rail)(t$150177));
            
            //#line 296 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150178 = ((x10.regionarray.Region)(this.getLocalRegionFromLocalHandle()));
            
            //#line 296 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localRegion = ((x10.regionarray.Region)(t$150178));
        }
        return this;
    }
    
    
    
    //#line 308 "x10/regionarray/DistArray.x10"
    /**
     * Create a DistArray that views the same backing data
     * as the argument DistArray using a different distribution.</p>
     * 
     * An unchecked invariant for this to be correct is that for each place in
     * d.places, local storage must be allocated for each point p in d(place).
     * This invariant is too expensive to be checked dynamically, so it simply must
     * be respected by the DistArray code that calls this constructor.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> a, final x10.regionarray.Dist d, __0$1x10$regionarray$DistArray$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$DistArray$$init$S(a, d, (x10.regionarray.DistArray.__0$1x10$regionarray$DistArray$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.DistArray<$T> x10$regionarray$DistArray$$init$S(final x10.regionarray.DistArray<$T> a, final x10.regionarray.Dist d, __0$1x10$regionarray$DistArray$$T$2 $dummy) {
         {
            
            //#line 309 "x10/regionarray/DistArray.x10"
            this.dist = d;
            
            
            //#line 316 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceGroup t$150188 = d.places();
            
            //#line 312 "x10/regionarray/DistArray.x10"
            final x10.core.fun.Fun_0_0 t$150189 = ((x10.core.fun.Fun_0_0)(new x10.regionarray.DistArray.$Closure$182<$T>($T, a, d, (x10.regionarray.DistArray.$Closure$182.__0$1x10$regionarray$DistArray$$Closure$182$$T$2) null)));
            
            //#line 316 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceLocalHandle t$150190 = x10.lang.PlaceLocalHandle.<x10.regionarray.DistArray.LocalState<$T>> makeFlat__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, $T), ((x10.lang.PlaceGroup)(t$150188)), ((x10.core.fun.Fun_0_0)(t$150189)));
            
            //#line 316 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(t$150190));
            
            //#line 317 "x10/regionarray/DistArray.x10"
            final x10.core.Rail t$150191 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                              this.getRawFromLocalHandle())));
            
            //#line 317 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).raw = ((x10.core.Rail)(t$150191));
            
            //#line 318 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150192 = ((x10.regionarray.Region)(this.getLocalRegionFromLocalHandle()));
            
            //#line 318 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localRegion = ((x10.regionarray.Region)(t$150192));
        }
        return this;
    }
    
    
    
    //#line 326 "x10/regionarray/DistArray.x10"
    /**
     * Create a DistArray from a distribution and a PlaceLocalHandle[LocalState[T]]
     * This constructor is intended for internal use only by operations such as 
     * map to enable them to complete with only 1 collective operation instead of 2.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray(final x10.rtt.Type $T, final x10.regionarray.Dist d, final x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> pls, __1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$T$2$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$DistArray$$init$S(d, pls, (x10.regionarray.DistArray.__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$T$2$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.DistArray<$T> x10$regionarray$DistArray$$init$S(final x10.regionarray.Dist d, final x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> pls, __1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$T$2$2 $dummy) {
         {
            
            //#line 327 "x10/regionarray/DistArray.x10"
            this.dist = d;
            
            
            //#line 328 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(pls));
            
            //#line 329 "x10/regionarray/DistArray.x10"
            final x10.core.Rail t$150193 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                              this.getRawFromLocalHandle())));
            
            //#line 329 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).raw = ((x10.core.Rail)(t$150193));
            
            //#line 330 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150194 = ((x10.regionarray.Region)(this.getLocalRegionFromLocalHandle()));
            
            //#line 330 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localRegion = ((x10.regionarray.Region)(t$150194));
        }
        return this;
    }
    
    
    
    //#line 345 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given point.
     * The rank of the given point has to be the same as the rank of this array.
     * If the distribution does not map the given Point to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param pt the given point
     * @return the element of this array corresponding to the given point.
     * @see #operator(Long)
     * @see #set(T, Point)
     */
    final public $T $apply$G(final x10.lang.Point pt) {
        
        //#line 346 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149863 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150195 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149863).localRegion));
        
        //#line 346 "x10/regionarray/DistArray.x10"
        final long offset = t$150195.indexOf$O(((x10.lang.Point)(pt)));
        
        //#line 347 "x10/regionarray/DistArray.x10"
        final boolean t$150196 = ((long) offset) == ((long) -1L);
        
        //#line 347 "x10/regionarray/DistArray.x10"
        if (t$150196) {
            
            //#line 347 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError(((x10.lang.Point)(pt)));
        }
        
        //#line 348 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150197 = ((x10.core.Rail)(this.raw));
        
        //#line 348 "x10/regionarray/DistArray.x10"
        final $T t$150198 = (($T)(((x10.core.Rail<$T>)t$150197).$apply$G((long)(offset))));
        
        //#line 348 "x10/regionarray/DistArray.x10"
        return t$150198;
    }
    
    
    //#line 363 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * Only applies to one-dimensional arrays.
     * Functionally equivalent to indexing the array via a one-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param i0 the given index in the first dimension
     * @return the element of this array corresponding to the given index.
     * @see #operator(Point)
     * @see #set(T, Long)
     */
    final public $T $apply$G(final long i0) {
        
        //#line 364 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149869 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150201 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149869).localRegion));
        
        //#line 364 "x10/regionarray/DistArray.x10"
        final long offset = t$150201.indexOf$O((long)(i0));
        
        //#line 365 "x10/regionarray/DistArray.x10"
        final boolean t$150202 = ((long) offset) == ((long) -1L);
        
        //#line 365 "x10/regionarray/DistArray.x10"
        if (t$150202) {
            
            //#line 365 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0));
        }
        
        //#line 366 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150203 = ((x10.core.Rail)(this.raw));
        
        //#line 366 "x10/regionarray/DistArray.x10"
        final $T t$150204 = (($T)(((x10.core.Rail<$T>)t$150203).$apply$G((long)(offset))));
        
        //#line 366 "x10/regionarray/DistArray.x10"
        return t$150204;
    }
    
    
    //#line 382 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given pair of indices.
     * Only applies to two-dimensional arrays.
     * Functionally equivalent to indexing the array via a two-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @return the element of this array corresponding to the given pair of indices.
     * @see #operator(Point)
     * @see #set(T, Long, Long)
     */
    final public $T $apply$G(final long i0, final long i1) {
        
        //#line 383 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149875 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150207 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149875).localRegion));
        
        //#line 383 "x10/regionarray/DistArray.x10"
        final long offset = t$150207.indexOf$O((long)(i0), (long)(i1));
        
        //#line 384 "x10/regionarray/DistArray.x10"
        final boolean t$150208 = ((long) offset) == ((long) -1L);
        
        //#line 384 "x10/regionarray/DistArray.x10"
        if (t$150208) {
            
            //#line 384 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1));
        }
        
        //#line 385 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150209 = ((x10.core.Rail)(this.raw));
        
        //#line 385 "x10/regionarray/DistArray.x10"
        final $T t$150210 = (($T)(((x10.core.Rail<$T>)t$150209).$apply$G((long)(offset))));
        
        //#line 385 "x10/regionarray/DistArray.x10"
        return t$150210;
    }
    
    
    //#line 402 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given triple of indices.
     * Only applies to three-dimensional arrays.
     * Functionally equivalent to indexing the array via a three-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     *
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @return the element of this array corresponding to the given triple of indices.
     * @see #operator(Point)
     * @see #set(T, Long, Long, Long)
     */
    final public $T $apply$G(final long i0, final long i1, final long i2) {
        
        //#line 403 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149881 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150213 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149881).localRegion));
        
        //#line 403 "x10/regionarray/DistArray.x10"
        final long offset = t$150213.indexOf$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 404 "x10/regionarray/DistArray.x10"
        final boolean t$150214 = ((long) offset) == ((long) -1L);
        
        //#line 404 "x10/regionarray/DistArray.x10"
        if (t$150214) {
            
            //#line 404 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 405 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150215 = ((x10.core.Rail)(this.raw));
        
        //#line 405 "x10/regionarray/DistArray.x10"
        final $T t$150216 = (($T)(((x10.core.Rail<$T>)t$150215).$apply$G((long)(offset))));
        
        //#line 405 "x10/regionarray/DistArray.x10"
        return t$150216;
    }
    
    
    //#line 423 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given quartet of indices.
     * Only applies to four-dimensional arrays.
     * Functionally equivalent to indexing the array via a four-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @param i3 the given index in the fourth dimension
     * @return the element of this array corresponding to the given quartet of indices.
     * @see #operator(Point)
     * @see #set(T, Long, Long, Long, Long)
     */
    final public $T $apply$G(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 424 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149887 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150219 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149887).localRegion));
        
        //#line 424 "x10/regionarray/DistArray.x10"
        final long offset = t$150219.indexOf$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 425 "x10/regionarray/DistArray.x10"
        final boolean t$150220 = ((long) offset) == ((long) -1L);
        
        //#line 425 "x10/regionarray/DistArray.x10"
        if (t$150220) {
            
            //#line 425 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        }
        
        //#line 426 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150221 = ((x10.core.Rail)(this.raw));
        
        //#line 426 "x10/regionarray/DistArray.x10"
        final $T t$150222 = (($T)(((x10.core.Rail<$T>)t$150221).$apply$G((long)(offset))));
        
        //#line 426 "x10/regionarray/DistArray.x10"
        return t$150222;
    }
    
    
    //#line 441 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given point,
     * wrapped for periodic boundary conditions.
     * The rank of the given point must be the same as the rank of this array.
     * If the distribution does not map the given Point to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param pt the given point
     * @return the element of this array corresponding to the given point,
     *   wrapped for periodic boundary conditions.
     * @see #setPeriodic(T, Point)
     */
    final public $T getPeriodic$G(final x10.lang.Point pt) {
        
        //#line 442 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149889 = ((x10.regionarray.DistArray)(this));
        
        //#line 442 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region l = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149889).localRegion));
        
        //#line 443 "x10/regionarray/DistArray.x10"
        final x10.lang.Point actualPt;
        
        //#line 444 "x10/regionarray/DistArray.x10"
        final boolean t$150226 = l.contains$O(((x10.lang.Point)(pt)));
        
        //#line 444 "x10/regionarray/DistArray.x10"
        if (t$150226) {
            
            //#line 445 "x10/regionarray/DistArray.x10"
            actualPt = ((x10.lang.Point)(pt));
        } else {
            
            //#line 447 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$149891 = ((x10.regionarray.DistArray)(this));
            
            //#line 62 . "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$150223 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$149891).dist));
            
            //#line 62 . "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150224 = ((x10.regionarray.Region)(t$150223.region));
            
            //#line 447 "x10/regionarray/DistArray.x10"
            final x10.lang.Point t$150225 = ((x10.lang.Point)(x10.regionarray.PeriodicBoundaryConditions.wrapPeriodic(((x10.lang.Point)(pt)), ((x10.regionarray.Region)(l)), ((x10.regionarray.Region)(t$150224)))));
            
            //#line 447 "x10/regionarray/DistArray.x10"
            actualPt = ((x10.lang.Point)(t$150225));
        }
        
        //#line 449 "x10/regionarray/DistArray.x10"
        final long offset = l.indexOf$O(((x10.lang.Point)(actualPt)));
        
        //#line 450 "x10/regionarray/DistArray.x10"
        final boolean t$150227 = ((long) offset) == ((long) -1L);
        
        //#line 450 "x10/regionarray/DistArray.x10"
        if (t$150227) {
            
            //#line 450 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError(((x10.lang.Point)(pt)));
        }
        
        //#line 451 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149949 = ((x10.regionarray.DistArray)(this));
        
        //#line 117 . "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150228 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$149949).raw));
        
        //#line 451 "x10/regionarray/DistArray.x10"
        final $T t$150229 = (($T)(((x10.core.Rail<$T>)t$150228).$apply$G((long)(offset))));
        
        //#line 451 "x10/regionarray/DistArray.x10"
        return t$150229;
    }
    
    
    //#line 468 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this three-dimensional array according to the given
     * indices, wrapped for periodic boundary conditions.
     * Only applies to three-dimensional arrays.
     * Functionally equivalent to getPeriodic(Point{rank==3}).
     * If the distribution does not map the given indices to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param i0 the index in the first dimension
     * @param i1 the index in the second dimension
     * @param i2 the index in the third dimension
     * @return the element of this array corresponding to the given triple of indices.
     * @see #setPeriodic(T, Point)
     */
    final public $T getPeriodic$G(final long i0, final long i1, final long i2) {
        
        //#line 469 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149955 = ((x10.regionarray.DistArray)(this));
        
        //#line 469 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region l = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149955).localRegion));
        
        //#line 470 "x10/regionarray/DistArray.x10"
        final long offset;
        
        //#line 471 "x10/regionarray/DistArray.x10"
        final boolean t$150253 = l.contains$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 471 "x10/regionarray/DistArray.x10"
        if (t$150253) {
            
            //#line 472 "x10/regionarray/DistArray.x10"
            final long t$150232 = l.indexOf$O((long)(i0), (long)(i1), (long)(i2));
            
            //#line 472 "x10/regionarray/DistArray.x10"
            offset = t$150232;
        } else {
            
            //#line 474 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$149957 = ((x10.regionarray.DistArray)(this));
            
            //#line 62 . "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$150233 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$149957).dist));
            
            //#line 474 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region r = ((x10.regionarray.Region)(t$150233.region));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long t$150237 = l.min$O((long)(0L));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long t$150238 = l.max$O((long)(0L));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long t$150234 = r.max$O((long)(0L));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long t$150235 = r.min$O((long)(0L));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long t$150236 = ((t$150234) - (((long)(t$150235))));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long t$150239 = ((t$150236) + (((long)(1L))));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long a0 = x10.regionarray.PeriodicBoundaryConditions.getPeriodicIndex$O((long)(i0), (long)(t$150237), (long)(t$150238), (long)(t$150239));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long t$150243 = l.min$O((long)(1L));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long t$150244 = l.max$O((long)(1L));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long t$150240 = r.max$O((long)(1L));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long t$150241 = r.min$O((long)(1L));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long t$150242 = ((t$150240) - (((long)(t$150241))));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long t$150245 = ((t$150242) + (((long)(1L))));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long a1 = x10.regionarray.PeriodicBoundaryConditions.getPeriodicIndex$O((long)(i1), (long)(t$150243), (long)(t$150244), (long)(t$150245));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long t$150249 = l.min$O((long)(2L));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long t$150250 = l.max$O((long)(2L));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long t$150246 = r.max$O((long)(2L));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long t$150247 = r.min$O((long)(2L));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long t$150248 = ((t$150246) - (((long)(t$150247))));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long t$150251 = ((t$150248) + (((long)(1L))));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long a2 = x10.regionarray.PeriodicBoundaryConditions.getPeriodicIndex$O((long)(i2), (long)(t$150249), (long)(t$150250), (long)(t$150251));
            
            //#line 478 "x10/regionarray/DistArray.x10"
            final long t$150252 = l.indexOf$O((long)(a0), (long)(a1), (long)(a2));
            
            //#line 478 "x10/regionarray/DistArray.x10"
            offset = t$150252;
        }
        
        //#line 480 "x10/regionarray/DistArray.x10"
        final boolean t$150254 = ((long) offset) == ((long) -1L);
        
        //#line 480 "x10/regionarray/DistArray.x10"
        if (t$150254) {
            
            //#line 480 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 481 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149959 = ((x10.regionarray.DistArray)(this));
        
        //#line 117 . "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150255 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$149959).raw));
        
        //#line 481 "x10/regionarray/DistArray.x10"
        final $T t$150256 = (($T)(((x10.core.Rail<$T>)t$150255).$apply$G((long)(offset))));
        
        //#line 481 "x10/regionarray/DistArray.x10"
        return t$150256;
    }
    
    
    //#line 497 "x10/regionarray/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given point to the given value.
     * Return the new value of the element.
     * The rank of the given point has to be the same as the rank of this array.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param v the given value
     * @param pt the given point
     * @return the new value of the element of this array corresponding to the given point.
     * @see #operator(Point)
     * @see #set(T, Long)
     */
    final public $T $set__1x10$regionarray$DistArray$$T$G(final x10.lang.Point pt, final $T v) {
        
        //#line 498 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150257 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 498 "x10/regionarray/DistArray.x10"
        final x10.lang.Place t$150258 = t$150257.$apply(((x10.lang.Point)(pt)));
        
        //#line 498 "x10/regionarray/DistArray.x10"
        final boolean t$150259 = (!x10.rtt.Equality.equalsequals((t$150258),(x10.x10rt.X10RT.here())));
        
        //#line 498 "x10/regionarray/DistArray.x10"
        if (t$150259) {
            
            //#line 498 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError(((x10.lang.Point)(pt)));
        }
        
        //#line 499 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149961 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150260 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149961).localRegion));
        
        //#line 499 "x10/regionarray/DistArray.x10"
        final long offset = t$150260.indexOf$O(((x10.lang.Point)(pt)));
        
        //#line 500 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150261 = ((x10.core.Rail)(this.raw));
        
        //#line 500 "x10/regionarray/DistArray.x10"
        ((x10.core.Rail<$T>)t$150261).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 501 "x10/regionarray/DistArray.x10"
        return v;
    }
    
    
    //#line 518 "x10/regionarray/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * Only applies to one-dimensional arrays.
     * Functionally equivalent to setting the array via a one-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long)
     * @see #set(T, Point)
     */
    final public $T $set__1x10$regionarray$DistArray$$T$G(final long i0, final $T v) {
        
        //#line 519 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150264 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 519 "x10/regionarray/DistArray.x10"
        final x10.lang.Place t$150265 = t$150264.$apply((long)(i0));
        
        //#line 519 "x10/regionarray/DistArray.x10"
        final boolean t$150266 = (!x10.rtt.Equality.equalsequals((t$150265),(x10.x10rt.X10RT.here())));
        
        //#line 519 "x10/regionarray/DistArray.x10"
        if (t$150266) {
            
            //#line 519 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0));
        }
        
        //#line 520 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149967 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150267 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149967).localRegion));
        
        //#line 520 "x10/regionarray/DistArray.x10"
        final long offset = t$150267.indexOf$O((long)(i0));
        
        //#line 521 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150268 = ((x10.core.Rail)(this.raw));
        
        //#line 521 "x10/regionarray/DistArray.x10"
        ((x10.core.Rail<$T>)t$150268).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 522 "x10/regionarray/DistArray.x10"
        return v;
    }
    
    
    //#line 540 "x10/regionarray/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given pair of indices to the given value.
     * Return the new value of the element.
     * Only applies to two-dimensional arrays.
     * Functionally equivalent to setting the array via a two-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @return the new value of the element of this array corresponding to the given pair of indices.
     * @see #operator(Long, Long)
     * @see #set(T, Point)
     */
    final public $T $set__2x10$regionarray$DistArray$$T$G(final long i0, final long i1, final $T v) {
        
        //#line 541 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150271 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 541 "x10/regionarray/DistArray.x10"
        final x10.lang.Place t$150272 = t$150271.$apply((long)(i0), (long)(i1));
        
        //#line 541 "x10/regionarray/DistArray.x10"
        final boolean t$150273 = (!x10.rtt.Equality.equalsequals((t$150272),(x10.x10rt.X10RT.here())));
        
        //#line 541 "x10/regionarray/DistArray.x10"
        if (t$150273) {
            
            //#line 541 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1));
        }
        
        //#line 542 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149973 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150274 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149973).localRegion));
        
        //#line 542 "x10/regionarray/DistArray.x10"
        final long offset = t$150274.indexOf$O((long)(i0), (long)(i1));
        
        //#line 543 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150275 = ((x10.core.Rail)(this.raw));
        
        //#line 543 "x10/regionarray/DistArray.x10"
        ((x10.core.Rail<$T>)t$150275).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 544 "x10/regionarray/DistArray.x10"
        return v;
    }
    
    
    //#line 563 "x10/regionarray/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given triple of indices to the given value.
     * Return the new value of the element.
     * Only applies to three-dimensional arrays.
     * Functionally equivalent to setting the array via a three-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @return the new value of the element of this array corresponding to the given triple of indices.
     * @see #operator(Long, Long, Long)
     * @see #set(T, Point)
     */
    final public $T $set__3x10$regionarray$DistArray$$T$G(final long i0, final long i1, final long i2, final $T v) {
        
        //#line 564 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150278 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 564 "x10/regionarray/DistArray.x10"
        final x10.lang.Place t$150279 = t$150278.$apply((long)(i0), (long)(i1), (long)(i2));
        
        //#line 564 "x10/regionarray/DistArray.x10"
        final boolean t$150280 = (!x10.rtt.Equality.equalsequals((t$150279),(x10.x10rt.X10RT.here())));
        
        //#line 564 "x10/regionarray/DistArray.x10"
        if (t$150280) {
            
            //#line 564 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 565 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149979 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150281 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149979).localRegion));
        
        //#line 565 "x10/regionarray/DistArray.x10"
        final long offset = t$150281.indexOf$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 566 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150282 = ((x10.core.Rail)(this.raw));
        
        //#line 566 "x10/regionarray/DistArray.x10"
        ((x10.core.Rail<$T>)t$150282).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 567 "x10/regionarray/DistArray.x10"
        return v;
    }
    
    
    //#line 588 "x10/regionarray/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given quartet of indices to the given value.
     * Return the new value of the element.
     * Only applies to four-dimensional arrays.
     * Functionally equivalent to setting the array via a four-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @param i3 the given index in the fourth dimension
     * @return the new value of the element of this array corresponding to the given quartet of indices.
     * @see #operator(Long, Long, Long, Long)
     * @see #set(T, Point)
     */
    final public $T $set__4x10$regionarray$DistArray$$T$G(final long i0, final long i1, final long i2, final long i3, final $T v) {
        
        //#line 589 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150285 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 589 "x10/regionarray/DistArray.x10"
        final x10.lang.Place t$150286 = t$150285.$apply((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 589 "x10/regionarray/DistArray.x10"
        final boolean t$150287 = (!x10.rtt.Equality.equalsequals((t$150286),(x10.x10rt.X10RT.here())));
        
        //#line 589 "x10/regionarray/DistArray.x10"
        if (t$150287) {
            
            //#line 589 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        }
        
        //#line 590 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149985 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150288 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149985).localRegion));
        
        //#line 590 "x10/regionarray/DistArray.x10"
        final long offset = t$150288.indexOf$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 591 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150289 = ((x10.core.Rail)(this.raw));
        
        //#line 591 "x10/regionarray/DistArray.x10"
        ((x10.core.Rail<$T>)t$150289).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 592 "x10/regionarray/DistArray.x10"
        return v;
    }
    
    
    //#line 609 "x10/regionarray/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given point (wrapped
     * for periodic boundary conditions) to the given value.
     * Return the new value of the element.
     * The rank of the given point must be the same as the rank of this array.
     * If the dist does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param v the given value
     * @param pt the given point
     * @return the new value of the element of this array corresponding to the
     *   given point
     * @see #getPeriodic(Point)
     */
    final public $T setPeriodic__1x10$regionarray$DistArray$$T$G(final x10.lang.Point pt, final $T v) {
        
        //#line 610 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149987 = ((x10.regionarray.DistArray)(this));
        
        //#line 610 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region l = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$149987).localRegion));
        
        //#line 611 "x10/regionarray/DistArray.x10"
        final x10.lang.Point actualPt;
        
        //#line 612 "x10/regionarray/DistArray.x10"
        final boolean t$150293 = l.contains$O(((x10.lang.Point)(pt)));
        
        //#line 612 "x10/regionarray/DistArray.x10"
        if (t$150293) {
            
            //#line 613 "x10/regionarray/DistArray.x10"
            actualPt = ((x10.lang.Point)(pt));
        } else {
            
            //#line 615 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$149989 = ((x10.regionarray.DistArray)(this));
            
            //#line 62 . "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$150290 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$149989).dist));
            
            //#line 62 . "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150291 = ((x10.regionarray.Region)(t$150290.region));
            
            //#line 615 "x10/regionarray/DistArray.x10"
            final x10.lang.Point t$150292 = ((x10.lang.Point)(x10.regionarray.PeriodicBoundaryConditions.wrapPeriodic(((x10.lang.Point)(pt)), ((x10.regionarray.Region)(l)), ((x10.regionarray.Region)(t$150291)))));
            
            //#line 615 "x10/regionarray/DistArray.x10"
            actualPt = ((x10.lang.Point)(t$150292));
        }
        
        //#line 617 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150294 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 617 "x10/regionarray/DistArray.x10"
        final x10.lang.Place t$150295 = t$150294.$apply(((x10.lang.Point)(actualPt)));
        
        //#line 617 "x10/regionarray/DistArray.x10"
        final boolean t$150296 = (!x10.rtt.Equality.equalsequals((t$150295),(x10.x10rt.X10RT.here())));
        
        //#line 617 "x10/regionarray/DistArray.x10"
        if (t$150296) {
            
            //#line 617 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError(((x10.lang.Point)(pt)));
        }
        
        //#line 618 "x10/regionarray/DistArray.x10"
        final long offset = l.indexOf$O(((x10.lang.Point)(actualPt)));
        
        //#line 619 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149991 = ((x10.regionarray.DistArray)(this));
        
        //#line 117 . "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150297 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$149991).raw));
        
        //#line 619 "x10/regionarray/DistArray.x10"
        ((x10.core.Rail<$T>)t$150297).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 620 "x10/regionarray/DistArray.x10"
        return v;
    }
    
    
    //#line 636 "x10/regionarray/DistArray.x10"
    /**
     * Return a DistArray that accesses the same backing storage
     * as this array, but only over the Points in the argument
     * distribution.</p>
     * 
     * For this operation to be semantically sound, it should
     * be the case that for every point p in d, 
     * <code>this.dist(here).indexOf(p) == d(here).indexOf(p)</code>.
     * This invariant is not statically or dynamically checked;
     * but must be ensured by the callers of this API. 
     * 
     * @param d the Dist to use as the restriction
     */
    public x10.regionarray.DistArray restriction(final x10.regionarray.Dist d) {
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$149729 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 637 "x10/regionarray/DistArray.x10"
        alloc$149729.x10$regionarray$DistArray$$init$S(((x10.regionarray.DistArray)(this)), ((x10.regionarray.Dist)(d)), (x10.regionarray.DistArray.__0$1x10$regionarray$DistArray$$T$2) null);
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray t$148927 = ((x10.regionarray.DistArray<$T>)
                                                     alloc$149729);
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150298 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)t$148927).dist));
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150299 = ((x10.regionarray.Region)(t$150298.region));
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final long t$150302 = t$150299.rank;
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150300 = ((x10.regionarray.Dist)(x10.regionarray.DistArray.this.dist));
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150301 = ((x10.regionarray.Region)(t$150300.region));
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final long t$150303 = t$150301.rank;
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final boolean t$150304 = ((long) t$150302) == ((long) t$150303);
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final boolean t$150306 = !(t$150304);
        
        //#line 637 "x10/regionarray/DistArray.x10"
        if (t$150306) {
            
            //#line 637 "x10/regionarray/DistArray.x10"
            final x10.lang.FailedDynamicCheckException t$150305 = new x10.lang.FailedDynamicCheckException("x10.regionarray.DistArray[T]{self.dist.region.rank==this(:x10.regionarray.DistArray).dist.region.rank}");
            
            //#line 637 "x10/regionarray/DistArray.x10"
            throw t$150305;
        }
        
        //#line 637 "x10/regionarray/DistArray.x10"
        return t$148927;
    }
    
    
    //#line 648 "x10/regionarray/DistArray.x10"
    /**
     * Return a DistArray that is defined over the same distribution
     * and backing storage as this DistArray instance, but is 
     * restricted to only allowing access to those points that are
     * contained in the argument region r.
     * 
     * @param r the Region to which to restrict the array
     */
    public x10.regionarray.DistArray restriction(final x10.regionarray.Region r) {
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150307 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150308 = ((x10.regionarray.Dist)(t$150307.restriction(((x10.regionarray.Region)(r)))));
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$148929 = ((x10.regionarray.Dist)
                                                t$150308);
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150309 = ((x10.regionarray.Region)(t$148929.region));
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final long t$150312 = t$150309.rank;
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150310 = ((x10.regionarray.Dist)(x10.regionarray.DistArray.this.dist));
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150311 = ((x10.regionarray.Region)(t$150310.region));
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final long t$150313 = t$150311.rank;
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final boolean t$150314 = ((long) t$150312) == ((long) t$150313);
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final boolean t$150316 = !(t$150314);
        
        //#line 649 "x10/regionarray/DistArray.x10"
        if (t$150316) {
            
            //#line 649 "x10/regionarray/DistArray.x10"
            final x10.lang.FailedDynamicCheckException t$150315 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Dist{self.region.rank==this(:x10.regionarray.DistArray).dist.region.rank}");
            
            //#line 649 "x10/regionarray/DistArray.x10"
            throw t$150315;
        }
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray t$150317 = ((x10.regionarray.DistArray)(((x10.regionarray.DistArray<$T>)
                                                                                  this.restriction(((x10.regionarray.Dist)(t$148929))))));
        
        //#line 649 "x10/regionarray/DistArray.x10"
        return t$150317;
    }
    
    
    //#line 660 "x10/regionarray/DistArray.x10"
    /**
     * Return a DistArray that is defined over the same distribution
     * and backing storage as this DistArray instance, but is 
     * restricted to only allowing access to those points that are
     * mapped by the defining distripution to the argument Place. 
     * 
     * @param p the Place to which to restrict the array
     */
    public x10.regionarray.DistArray restriction(final x10.lang.Place p) {
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150318 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150319 = ((x10.regionarray.Dist)(t$150318.restriction(((x10.lang.Place)(p)))));
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$148931 = ((x10.regionarray.Dist)
                                                t$150319);
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150320 = ((x10.regionarray.Region)(t$148931.region));
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final long t$150323 = t$150320.rank;
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150321 = ((x10.regionarray.Dist)(x10.regionarray.DistArray.this.dist));
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150322 = ((x10.regionarray.Region)(t$150321.region));
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final long t$150324 = t$150322.rank;
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final boolean t$150325 = ((long) t$150323) == ((long) t$150324);
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final boolean t$150327 = !(t$150325);
        
        //#line 661 "x10/regionarray/DistArray.x10"
        if (t$150327) {
            
            //#line 661 "x10/regionarray/DistArray.x10"
            final x10.lang.FailedDynamicCheckException t$150326 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Dist{self.region.rank==this(:x10.regionarray.DistArray).dist.region.rank}");
            
            //#line 661 "x10/regionarray/DistArray.x10"
            throw t$150326;
        }
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray t$150328 = ((x10.regionarray.DistArray)(((x10.regionarray.DistArray<$T>)
                                                                                  this.restriction(((x10.regionarray.Dist)(t$148931))))));
        
        //#line 661 "x10/regionarray/DistArray.x10"
        return t$150328;
    }
    
    
    //#line 672 "x10/regionarray/DistArray.x10"
    /**
     * Return a DistArray that is defined over the same distribution
     * and backing storage as this DistArray instance, but is 
     * restricted to only allowing access to those points that are
     * contained in the argument region r.
     * 
     * @param r the Region to which to restrict the array
     */
    public x10.regionarray.DistArray $bar(final x10.regionarray.Region r) {
        
        //#line 672 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray t$150329 = ((x10.regionarray.DistArray)(((x10.regionarray.DistArray<$T>)
                                                                                  this.restriction(((x10.regionarray.Region)(r))))));
        
        //#line 672 "x10/regionarray/DistArray.x10"
        return t$150329;
    }
    
    
    //#line 682 "x10/regionarray/DistArray.x10"
    /**
     * Return a DistArray that is defined over the same distribution
     * and backing storage as this DistArray instance, but is 
     * restricted to only allowing access to those points that are
     * mapped by the defining distripution to the argument Place. 
     * 
     * @param p the Place to which to restrict the array
     */
    public x10.regionarray.DistArray $bar(final x10.lang.Place p) {
        
        //#line 682 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray t$150330 = ((x10.regionarray.DistArray)(((x10.regionarray.DistArray<$T>)
                                                                                  this.restriction(((x10.lang.Place)(p))))));
        
        //#line 682 "x10/regionarray/DistArray.x10"
        return t$150330;
    }
    
    
    //#line 696 "x10/regionarray/DistArray.x10"
    /**
     * Returns the specified region of this array as a new Array object.
     * 
     * @param region the region of the array to copy to this array
     * @see Region#indexOf
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in this array
     */
    public x10.regionarray.Array getPatch(final x10.regionarray.Region r) {
        
        //#line 697 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150331 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 697 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region regionHere = ((x10.regionarray.Region)(t$150331.get(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
        
        //#line 48 . "x10/regionarray/Region.x10"
        final boolean t$150332 = regionHere.rect;
        
        //#line 698 "x10/regionarray/DistArray.x10"
        final boolean t$150335 = !(t$150332);
        
        //#line 698 "x10/regionarray/DistArray.x10"
        if (t$150335) {
            
            //#line 699 "x10/regionarray/DistArray.x10"
            final java.lang.String t$150333 = (("DistArray.getPatch not supported for non-rectangular region: ") + (regionHere));
            
            //#line 699 "x10/regionarray/DistArray.x10"
            final java.lang.UnsupportedOperationException t$150334 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$150333)));
            
            //#line 699 "x10/regionarray/DistArray.x10"
            throw t$150334;
        }
        
        //#line 701 "x10/regionarray/DistArray.x10"
        final boolean t$150336 = regionHere.contains$O(((x10.regionarray.Region)(r)));
        
        //#line 701 "x10/regionarray/DistArray.x10"
        final boolean t$150341 = !(t$150336);
        
        //#line 701 "x10/regionarray/DistArray.x10"
        if (t$150341) {
            
            //#line 702 "x10/regionarray/DistArray.x10"
            final java.lang.String t$150337 = (("region to copy: ") + (r));
            
            //#line 702 "x10/regionarray/DistArray.x10"
            final java.lang.String t$150338 = ((t$150337) + (" not contained in local region: "));
            
            //#line 702 "x10/regionarray/DistArray.x10"
            final java.lang.String t$150339 = ((t$150338) + (regionHere));
            
            //#line 702 "x10/regionarray/DistArray.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$150340 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$150339)));
            
            //#line 702 "x10/regionarray/DistArray.x10"
            throw t$150340;
        }
        
        //#line 705 "x10/regionarray/DistArray.x10"
        final x10.core.fun.Fun_0_1 min = regionHere.min();
        
        //#line 706 "x10/regionarray/DistArray.x10"
        regionHere.max();
        
        //#line 707 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$149994 = ((x10.regionarray.DistArray)(this));
        
        //#line 67 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist this$149996 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$149994).dist));
        
        //#line 38 .. "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$150342 = ((x10.regionarray.Region)(this$149996.region));
        
        //#line 38 .. "x10/regionarray/Dist.x10"
        final long t$150347 = t$150342.rank;
        
        //#line 707 "x10/regionarray/DistArray.x10"
        final x10.core.fun.Fun_0_1 t$150348 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.DistArray.$Closure$183<$T>($T, regionHere)));
        
        //#line 707 "x10/regionarray/DistArray.x10"
        final x10.core.Rail delta = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$150347)), ((x10.core.fun.Fun_0_1)(t$150348)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 708 "x10/regionarray/DistArray.x10"
        final long t$150349 = r.size$O();
        
        //#line 708 "x10/regionarray/DistArray.x10"
        final x10.core.Rail patchRaw = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$150349)), false)));
        
        //#line 709 "x10/regionarray/DistArray.x10"
        long patchIndex = 0L;
        
        //#line 710 "x10/regionarray/DistArray.x10"
        final x10.lang.Iterator p$150747 = r.iterator();
        {
            
            //#line 710 "x10/regionarray/DistArray.x10"
            final long[] delta$value$151033 = ((long[])delta.value);
            
            //#line 710 "x10/regionarray/DistArray.x10"
            for (;
                 true;
                 ) {
                
                //#line 710 "x10/regionarray/DistArray.x10"
                final boolean t$150748 = ((x10.lang.Iterator<x10.lang.Point>)p$150747).hasNext$O();
                
                //#line 710 "x10/regionarray/DistArray.x10"
                if (!(t$150748)) {
                    
                    //#line 710 "x10/regionarray/DistArray.x10"
                    break;
                }
                
                //#line 710 "x10/regionarray/DistArray.x10"
                final x10.lang.Point p$150729 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$150747).next$G()));
                
                //#line 711 "x10/regionarray/DistArray.x10"
                final long t$150730 = p$150729.$apply$O((long)(0L));
                
                //#line 711 "x10/regionarray/DistArray.x10"
                final long t$150731 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)min).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                
                //#line 711 "x10/regionarray/DistArray.x10"
                long offset$150732 = ((t$150730) - (((long)(t$150731))));
                
                //#line 712 "x10/regionarray/DistArray.x10"
                long i$150722 = 1L;
                {
                    
                    //#line 712 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 712 "x10/regionarray/DistArray.x10"
                        final x10.regionarray.DistArray this$150724 = ((x10.regionarray.DistArray)(this));
                        
                        //#line 67 . "x10/regionarray/DistArray.x10"
                        final x10.regionarray.Dist this$150725 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$150724).dist));
                        
                        //#line 38 .. "x10/regionarray/Dist.x10"
                        final x10.regionarray.Region t$150726 = ((x10.regionarray.Region)(this$150725.region));
                        
                        //#line 38 .. "x10/regionarray/Dist.x10"
                        final long t$150727 = t$150726.rank;
                        
                        //#line 712 "x10/regionarray/DistArray.x10"
                        final boolean t$150728 = ((i$150722) < (((long)(t$150727))));
                        
                        //#line 712 "x10/regionarray/DistArray.x10"
                        if (!(t$150728)) {
                            
                            //#line 712 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        final long t$150712 = ((long)delta$value$151033[(int)i$150722]);
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        final long t$150713 = ((offset$150732) * (((long)(t$150712))));
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        final long t$150715 = p$150729.$apply$O((long)(i$150722));
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        final long t$150716 = ((t$150713) + (((long)(t$150715))));
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        final long t$150718 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)min).$apply(x10.core.Long.$box(i$150722), x10.rtt.Types.LONG));
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        final long t$150719 = ((t$150716) - (((long)(t$150718))));
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        offset$150732 = t$150719;
                        
                        //#line 712 "x10/regionarray/DistArray.x10"
                        final long t$150721 = ((i$150722) + (((long)(1L))));
                        
                        //#line 712 "x10/regionarray/DistArray.x10"
                        i$150722 = t$150721;
                    }
                }
                
                //#line 715 "x10/regionarray/DistArray.x10"
                final long pre$150733 = patchIndex;
                
                //#line 715 "x10/regionarray/DistArray.x10"
                final long t$150735 = ((patchIndex) + (((long)(1L))));
                
                //#line 715 "x10/regionarray/DistArray.x10"
                patchIndex = t$150735;
                
                //#line 715 "x10/regionarray/DistArray.x10"
                final $T t$150736 = (($T)(this.$apply$G(((x10.lang.Point)(p$150729)))));
                
                //#line 715 "x10/regionarray/DistArray.x10"
                ((x10.core.Rail<$T>)patchRaw).$set__1x10$lang$Rail$$T$G((long)(pre$150733), (($T)(t$150736)));
            }
        }
        
        //#line 717 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Array alloc$149730 = ((x10.regionarray.Array)(new x10.regionarray.Array<$T>((java.lang.System[]) null, $T)));
        
        //#line 233 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$150737 = ((x10.regionarray.Region)
                                                  r);
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$150738 = ((t$150737) != (null));
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$150739 = !(t$150738);
        
        //#line 233 . "x10/regionarray/Array.x10"
        if (t$150739) {
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$150740 = true;
            
            //#line 233 . "x10/regionarray/Array.x10"
            if (t$150740) {
                
                //#line 233 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$150741 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 233 . "x10/regionarray/Array.x10"
                throw t$150741;
            }
        }
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149730).region = ((x10.regionarray.Region)(t$150737));
        
        //#line 233 . "x10/regionarray/Array.x10"
        final long t$150742 = r.rank;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149730).rank = t$150742;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$150743 = r.rect;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149730).rect = t$150743;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$150744 = r.zeroBased;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149730).zeroBased = t$150744;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$150745 = r.rail;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149730).rail = t$150745;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final long t$150746 = r.size$O();
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149730).size = t$150746;
        
        //#line 235 . "x10/regionarray/Array.x10"
        final x10.regionarray.Array.LayoutHelper crh$150749 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
        
        //#line 235 . "x10/regionarray/Array.x10"
        crh$150749.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(r)));
        
        //#line 236 . "x10/regionarray/Array.x10"
        final long t$150750 = crh$150749.min0;
        
        //#line 236 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149730).layout_min0 = t$150750;
        
        //#line 237 . "x10/regionarray/Array.x10"
        final long t$150751 = crh$150749.stride1;
        
        //#line 237 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149730).layout_stride1 = t$150751;
        
        //#line 238 . "x10/regionarray/Array.x10"
        final long t$150752 = crh$150749.min1;
        
        //#line 238 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149730).layout_min1 = t$150752;
        
        //#line 239 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$150753 = ((x10.core.Rail)(crh$150749.layout));
        
        //#line 239 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149730).layout = ((x10.core.Rail)(t$150753));
        
        //#line 240 . "x10/regionarray/Array.x10"
        final long n$150754 = crh$150749.size;
        
        //#line 241 . "x10/regionarray/Array.x10"
        final long t$150755 = ((x10.core.Rail<$T>)patchRaw).size;
        
        //#line 241 . "x10/regionarray/Array.x10"
        final boolean t$150756 = ((n$150754) > (((long)(t$150755))));
        
        //#line 241 . "x10/regionarray/Array.x10"
        if (t$150756) {
            
            //#line 242 . "x10/regionarray/Array.x10"
            final boolean t$150757 = true;
            
            //#line 242 . "x10/regionarray/Array.x10"
            if (t$150757) {
                
                //#line 242 . "x10/regionarray/Array.x10"
                final java.lang.IllegalArgumentException t$150758 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("backingStore too small")));
                
                //#line 242 . "x10/regionarray/Array.x10"
                throw t$150758;
            }
        }
        
        //#line 244 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$150759 = ((x10.core.Rail<$T>)
                                         patchRaw);
        
        //#line 244 . "x10/regionarray/Array.x10"
        final boolean t$150760 = ((t$150759) != (null));
        
        //#line 244 . "x10/regionarray/Array.x10"
        final boolean t$150761 = !(t$150760);
        
        //#line 244 . "x10/regionarray/Array.x10"
        if (t$150761) {
            
            //#line 244 . "x10/regionarray/Array.x10"
            final boolean t$150762 = true;
            
            //#line 244 . "x10/regionarray/Array.x10"
            if (t$150762) {
                
                //#line 244 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$150763 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self!=null}");
                
                //#line 244 . "x10/regionarray/Array.x10"
                throw t$150763;
            }
        }
        
        //#line 244 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$149730).raw = ((x10.core.Rail)(t$150759));
        
        //#line 717 "x10/regionarray/DistArray.x10"
        return alloc$149730;
    }
    
    
    //#line 725 "x10/regionarray/DistArray.x10"
    /**
     * Fill all elements of the array to contain the argument value.
     * 
     * @param v the value with which to fill the array
     */
    public void fill__0x10$regionarray$DistArray$$T(final $T v) {
        {
            
            //#line 726 "x10/regionarray/DistArray.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 726 "x10/regionarray/DistArray.x10"
            final x10.xrx.FinishState fs$150963 = x10.xrx.Runtime.startFinish();
            
            //#line 726 "x10/regionarray/DistArray.x10"
            try {{
                {
                    
                    //#line 726 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$150396 = ((x10.regionarray.Dist)(this.dist));
                    
                    //#line 726 "x10/regionarray/DistArray.x10"
                    final x10.lang.PlaceGroup t$150397 = t$150396.places();
                    
                    //#line 726 "x10/regionarray/DistArray.x10"
                    final x10.lang.Iterator where$149742 = t$150397.iterator();
                    
                    //#line 726 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 726 "x10/regionarray/DistArray.x10"
                        final boolean t$150402 = ((x10.lang.Iterator<x10.lang.Place>)where$149742).hasNext$O();
                        
                        //#line 726 "x10/regionarray/DistArray.x10"
                        if (!(t$150402)) {
                            
                            //#line 726 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 726 "x10/regionarray/DistArray.x10"
                        final x10.lang.Place where$150768 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$149742).next$G()));
                        
                        //#line 727 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$150768)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$184<$T>($T, ((x10.regionarray.DistArray)(this)), this.dist, v, (x10.regionarray.DistArray.$Closure$184.__0$1x10$regionarray$DistArray$$Closure$184$$T$2__2x10$regionarray$DistArray$$Closure$184$$T) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$150961) {
                
                //#line 726 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$150961)));
                
                //#line 726 "x10/regionarray/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 726 "x10/regionarray/DistArray.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$150963)));
             }}
            }
        }
    
    
    //#line 747 "x10/regionarray/DistArray.x10"
    /**
     * Map the function onto the elements of this array
     * constructing a new result array such that for all points <code>p</code>
     * in <code>this.dist</code>,
     * <code>result(p) == op(this(p))</code>.<p>
     * 
     * @param op the function to apply to each element of the array
     * @return a new array with the same distribution as this array where <code>result(p) == op(this(p))</code>
     */
    final public <$U>x10.regionarray.DistArray map__0$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$2(final x10.rtt.Type $U, final x10.core.fun.Fun_0_1 op) {
        
        //#line 749 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150403 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 749 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceGroup t$150411 = t$150403.places();
        
        //#line 750 "x10/regionarray/DistArray.x10"
        final x10.core.fun.Fun_0_0 t$150412 = ((x10.core.fun.Fun_0_0)(new x10.regionarray.DistArray.$Closure$185<$T, $U>($T, $U, ((x10.regionarray.DistArray)(this)), this.dist, op, (x10.regionarray.DistArray.$Closure$185.__0$1x10$regionarray$DistArray$$Closure$185$$T$2__2$1x10$regionarray$DistArray$$Closure$185$$T$3x10$regionarray$DistArray$$Closure$185$$U$2) null)));
        
        //#line 748 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle plh = x10.lang.PlaceLocalHandle.<x10.regionarray.DistArray.LocalState<$U>> make__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, $U), ((x10.lang.PlaceGroup)(t$150411)), ((x10.core.fun.Fun_0_0)(t$150412)));
        
        //#line 761 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$149732 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$U>((java.lang.System[]) null, $U)));
        
        //#line 761 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150781 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 761 "x10/regionarray/DistArray.x10"
        alloc$149732.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(t$150781)), ((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$U>>)(plh)), (x10.regionarray.DistArray.__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$T$2$2) null);
        
        //#line 761 "x10/regionarray/DistArray.x10"
        return alloc$149732;
    }
    
    
    //#line 774 "x10/regionarray/DistArray.x10"
    /**
     * Map the given function onto the elements of this array
     * storing the results in the dst array such that for all points <code>p</code>
     * in <code>this.dist</code>,
     * <code>dst(p) == op(this(p))</code>.<p>
     * 
     * @param dst the destination array for the results of the map operation
     * @param op the function to apply to each element of the array
     * @return dst after applying the map operation.
     */
    final public <$U>x10.regionarray.DistArray map__0$1x10$regionarray$DistArray$$U$2__1$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$2(final x10.rtt.Type $U, final x10.regionarray.DistArray dst, final x10.core.fun.Fun_0_1 op) {
        {
            
            //#line 775 "x10/regionarray/DistArray.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 775 "x10/regionarray/DistArray.x10"
            final x10.xrx.FinishState fs$150971 = x10.xrx.Runtime.startFinish();
            
            //#line 775 "x10/regionarray/DistArray.x10"
            try {{
                {
                    
                    //#line 776 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$150415 = ((x10.regionarray.Dist)(this.dist));
                    
                    //#line 776 "x10/regionarray/DistArray.x10"
                    final x10.lang.PlaceGroup t$150416 = t$150415.places();
                    
                    //#line 776 "x10/regionarray/DistArray.x10"
                    final x10.lang.Iterator where$149748 = t$150416.iterator();
                    
                    //#line 776 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 776 "x10/regionarray/DistArray.x10"
                        final boolean t$150422 = ((x10.lang.Iterator<x10.lang.Place>)where$149748).hasNext$O();
                        
                        //#line 776 "x10/regionarray/DistArray.x10"
                        if (!(t$150422)) {
                            
                            //#line 776 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 776 "x10/regionarray/DistArray.x10"
                        final x10.lang.Place where$150788 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$149748).next$G()));
                        
                        //#line 777 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$150788)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$186<$T, $U>($T, $U, ((x10.regionarray.DistArray)(this)), this.dist, dst, op, (x10.regionarray.DistArray.$Closure$186.__0$1x10$regionarray$DistArray$$Closure$186$$T$2__2$1x10$regionarray$DistArray$$Closure$186$$U$2__3$1x10$regionarray$DistArray$$Closure$186$$T$3x10$regionarray$DistArray$$Closure$186$$U$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$150969) {
                
                //#line 775 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$150969)));
                
                //#line 775 "x10/regionarray/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 775 "x10/regionarray/DistArray.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$150971)));
             }}
            }
        
        //#line 789 "x10/regionarray/DistArray.x10"
        return dst;
        }
    
    
    //#line 804 "x10/regionarray/DistArray.x10"
    /**
     * Map the given function onto the elements of this array
     * storing the results in the dst array for the subset of points included
     * in the filter region such that for all points <code>p</code>
     * in <code>filter</code>,
     * <code>dst(p) == op(this(p))</code>.<p>
     * 
     * @param dst the destination array for the results of the map operation
     * @param op the function to apply to each element of the array
     * @param filter the region to use as a filter on the map operation
     * @return dst after applying the map operation.
     */
    final public <$U>x10.regionarray.DistArray map__0$1x10$regionarray$DistArray$$U$2__2$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$2(final x10.rtt.Type $U, final x10.regionarray.DistArray dst, final x10.regionarray.Region filter, final x10.core.fun.Fun_0_1 op) {
        {
            
            //#line 805 "x10/regionarray/DistArray.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 805 "x10/regionarray/DistArray.x10"
            final x10.xrx.FinishState fs$150979 = x10.xrx.Runtime.startFinish();
            
            //#line 805 "x10/regionarray/DistArray.x10"
            try {{
                {
                    
                    //#line 806 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$150424 = ((x10.regionarray.Dist)(this.dist));
                    
                    //#line 806 "x10/regionarray/DistArray.x10"
                    final x10.lang.PlaceGroup t$150425 = t$150424.places();
                    
                    //#line 806 "x10/regionarray/DistArray.x10"
                    final x10.lang.Iterator where$149752 = t$150425.iterator();
                    
                    //#line 806 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 806 "x10/regionarray/DistArray.x10"
                        final boolean t$150431 = ((x10.lang.Iterator<x10.lang.Place>)where$149752).hasNext$O();
                        
                        //#line 806 "x10/regionarray/DistArray.x10"
                        if (!(t$150431)) {
                            
                            //#line 806 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 806 "x10/regionarray/DistArray.x10"
                        final x10.lang.Place where$150802 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$149752).next$G()));
                        
                        //#line 807 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$150802)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$187<$T, $U>($T, $U, ((x10.regionarray.DistArray)(this)), this.dist, filter, dst, op, (x10.regionarray.DistArray.$Closure$187.__0$1x10$regionarray$DistArray$$Closure$187$$T$2__3$1x10$regionarray$DistArray$$Closure$187$$U$2__4$1x10$regionarray$DistArray$$Closure$187$$T$3x10$regionarray$DistArray$$Closure$187$$U$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$150977) {
                
                //#line 805 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$150977)));
                
                //#line 805 "x10/regionarray/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 805 "x10/regionarray/DistArray.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$150979)));
             }}
            }
        
        //#line 820 "x10/regionarray/DistArray.x10"
        return dst;
        }
    
    
    //#line 833 "x10/regionarray/DistArray.x10"
    /**
     * Map the given function onto the elements of this array
     * and the other src array, storing the results in a new result array 
     * such that for all points <code>p</code> in <code>this.dist</code>,
     * <code>result(p) == op(this(p), src(p))</code>.<p>
     * 
     * @param src the other src array
     * @param op the function to apply to each element of the array
     * @return a new array with the same distribution as this array containing the result of the map
     */
    final public <$S, $U>x10.regionarray.DistArray map__0$1x10$regionarray$DistArray$$U$2__1$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$S$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.DistArray src, final x10.core.fun.Fun_0_2 op) {
        
        //#line 835 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150432 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 835 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceGroup t$150441 = t$150432.places();
        
        //#line 836 "x10/regionarray/DistArray.x10"
        final x10.core.fun.Fun_0_0 t$150442 = ((x10.core.fun.Fun_0_0)(new x10.regionarray.DistArray.$Closure$188<$T, $S, $U>($T, $S, $U, ((x10.regionarray.DistArray)(this)), src, this.dist, op, (x10.regionarray.DistArray.$Closure$188.$_3f6666c7) null)));
        
        //#line 834 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle plh = x10.lang.PlaceLocalHandle.<x10.regionarray.DistArray.LocalState<$S>> make__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, $S), ((x10.lang.PlaceGroup)(t$150441)), ((x10.core.fun.Fun_0_0)(t$150442)));
        
        //#line 848 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$149734 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$S>((java.lang.System[]) null, $S)));
        
        //#line 848 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150819 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 848 "x10/regionarray/DistArray.x10"
        alloc$149734.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(t$150819)), ((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$S>>)(plh)), (x10.regionarray.DistArray.__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$T$2$2) null);
        
        //#line 848 "x10/regionarray/DistArray.x10"
        return alloc$149734;
    }
    
    
    //#line 862 "x10/regionarray/DistArray.x10"
    /**
     * Map the given function onto the elements of this array
     * and the other src array, storing the results in the given dst array 
     * such that for all points <code>p</code> in <code>this.dist</code>,
     * <code>dst(p) == op(this(p), src(p))</code>.<p>
     * 
     * @param dst the destination array for the map operation
     * @param src the second source array for the map operation
     * @param op the function to apply to each element of the array
     * @return destination after applying the map operation.
     */
    final public <$S, $U>x10.regionarray.DistArray map__0$1x10$regionarray$DistArray$$S$2__1$1x10$regionarray$DistArray$$U$2__2$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$S$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.DistArray dst, final x10.regionarray.DistArray src, final x10.core.fun.Fun_0_2 op) {
        {
            
            //#line 863 "x10/regionarray/DistArray.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 863 "x10/regionarray/DistArray.x10"
            final x10.xrx.FinishState fs$150987 = x10.xrx.Runtime.startFinish();
            
            //#line 863 "x10/regionarray/DistArray.x10"
            try {{
                {
                    
                    //#line 864 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$150445 = ((x10.regionarray.Dist)(this.dist));
                    
                    //#line 864 "x10/regionarray/DistArray.x10"
                    final x10.lang.PlaceGroup t$150446 = t$150445.places();
                    
                    //#line 864 "x10/regionarray/DistArray.x10"
                    final x10.lang.Iterator where$149758 = t$150446.iterator();
                    
                    //#line 864 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 864 "x10/regionarray/DistArray.x10"
                        final boolean t$150453 = ((x10.lang.Iterator<x10.lang.Place>)where$149758).hasNext$O();
                        
                        //#line 864 "x10/regionarray/DistArray.x10"
                        if (!(t$150453)) {
                            
                            //#line 864 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 864 "x10/regionarray/DistArray.x10"
                        final x10.lang.Place where$150827 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$149758).next$G()));
                        
                        //#line 865 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$150827)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$189<$T, $S, $U>($T, $S, $U, ((x10.regionarray.DistArray)(this)), this.dist, src, dst, op, (x10.regionarray.DistArray.$Closure$189.$_742f51e1) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$150985) {
                
                //#line 863 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$150985)));
                
                //#line 863 "x10/regionarray/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 863 "x10/regionarray/DistArray.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$150987)));
             }}
            }
        
        //#line 878 "x10/regionarray/DistArray.x10"
        return dst;
        }
    
    
    //#line 893 "x10/regionarray/DistArray.x10"
    /**
     * Map the given function onto the elements of this array
     * and the other src array, storing the results in the given dst array 
     * such that for all points in the filter region <code>p</code> in <code>filter</code>,
     * <code>dst(p) == op(this(p), src(p))</code>.<p>
     * 
     * @param dst the destination array for the map operation
     * @param src the second source array for the map operation
     * @param op the function to apply to each element of the array
     * @param filter the region to use to select the subset of points to include in the map
     * @return destination after applying the map operation.
     */
    final public <$S, $U>x10.regionarray.DistArray map__0$1x10$regionarray$DistArray$$S$2__1$1x10$regionarray$DistArray$$U$2__3$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$S$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.DistArray dst, final x10.regionarray.DistArray src, final x10.regionarray.Region filter, final x10.core.fun.Fun_0_2 op) {
        {
            
            //#line 894 "x10/regionarray/DistArray.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 894 "x10/regionarray/DistArray.x10"
            final x10.xrx.FinishState fs$150995 = x10.xrx.Runtime.startFinish();
            
            //#line 894 "x10/regionarray/DistArray.x10"
            try {{
                {
                    
                    //#line 895 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$150455 = ((x10.regionarray.Dist)(this.dist));
                    
                    //#line 895 "x10/regionarray/DistArray.x10"
                    final x10.lang.PlaceGroup t$150456 = t$150455.places();
                    
                    //#line 895 "x10/regionarray/DistArray.x10"
                    final x10.lang.Iterator where$149762 = t$150456.iterator();
                    
                    //#line 895 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 895 "x10/regionarray/DistArray.x10"
                        final boolean t$150463 = ((x10.lang.Iterator<x10.lang.Place>)where$149762).hasNext$O();
                        
                        //#line 895 "x10/regionarray/DistArray.x10"
                        if (!(t$150463)) {
                            
                            //#line 895 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 895 "x10/regionarray/DistArray.x10"
                        final x10.lang.Place where$150843 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$149762).next$G()));
                        
                        //#line 896 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$150843)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$190<$T, $S, $U>($T, $S, $U, ((x10.regionarray.DistArray)(this)), this.dist, filter, src, dst, op, (x10.regionarray.DistArray.$Closure$190.$_66f10b66) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$150993) {
                
                //#line 894 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$150993)));
                
                //#line 894 "x10/regionarray/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 894 "x10/regionarray/DistArray.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$150995)));
             }}
            }
        
        //#line 910 "x10/regionarray/DistArray.x10"
        return dst;
        }
    
    
    //#line 925 "x10/regionarray/DistArray.x10"
    /**
     * Reduce this array using the given function and the given initial value.
     * Each element of the array will be given as an argument to the reduction
     * function exactly once, but in an arbitrary order.  The reduction function
     * may be applied concurrently to implement a parallel reduction.
     * 
     * @param op the reduction function
     * @param unit the given initial value
     * @return the final result of the reduction.
     * @see #map((T)=>S)
     * @see #reduce((U,T)=>U,(U,U)=>U,U)
     */
    final public $T reduce__0$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$T$2__1x10$regionarray$DistArray$$T$G(final x10.core.fun.Fun_0_2 op, final $T unit) {
        
        //#line 925 "x10/regionarray/DistArray.x10"
        final $T t$150464 = (($T)(this.<$T> reduce__0$1x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$2__1$1x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$U$2__2x10$regionarray$DistArray$$U$G($T, ((x10.core.fun.Fun_0_2)(op)), ((x10.core.fun.Fun_0_2)(op)), (($T)(unit)))));
        
        //#line 925 "x10/regionarray/DistArray.x10"
        return t$150464;
    }
    
    
    //#line 939 "x10/regionarray/DistArray.x10"
    /**
     * Reduce this array using the given function and the given initial value.
     * Each element of the array will be given as an argument to the reduction
     * function exactly once, but in an arbitrary order.  The reduction function
     * may be applied concurrently to implement a parallel reduction.
     * 
     * @param lop the local reduction function
     * @param gop the global reduction function
     * @param unit the given initial value
     * @return the final result of the reduction.
     * @see #map((T)=>S)
     */
    final public <$U>$U reduce__0$1x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$2__1$1x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$U$2__2x10$regionarray$DistArray$$U$G(final x10.rtt.Type $U, final x10.core.fun.Fun_0_2 lop, final x10.core.fun.Fun_0_2 gop, final $U unit) {
        
        //#line 940 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray.Anonymous$39192 reducer = ((x10.regionarray.DistArray.Anonymous$39192)(new x10.regionarray.DistArray.Anonymous$39192<$U, $T>((java.lang.System[]) null, $U, $T)));
        
        //#line 940 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray out$150043 = ((x10.regionarray.DistArray)(this));
        
        //#line 45 . "x10/regionarray/DistArray.x10"
        ((x10.regionarray.DistArray.Anonymous$39192<$U, $T>)reducer).out$ = out$150043;
        
        //#line 939 . "x10/regionarray/DistArray.x10"
        ((x10.regionarray.DistArray.Anonymous$39192<$U, $T>)reducer).unit = (($U)(unit));
        
        //#line 939 . "x10/regionarray/DistArray.x10"
        ((x10.regionarray.DistArray.Anonymous$39192<$U, $T>)reducer).gop = gop;
        
        //#line 945 "x10/regionarray/DistArray.x10"
        final $U result;
        {
            
            //#line 945 "x10/regionarray/DistArray.x10"
            final x10.xrx.FinishState fs$151005 = ((x10.xrx.FinishState)(x10.xrx.Runtime.<$U> startCollectingFinish__0$1x10$xrx$Runtime$$T$2($U, ((x10.lang.Reducible)(reducer)))));
            
            //#line 945 "x10/regionarray/DistArray.x10"
            try {{
                {
                    
                    //#line 946 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$150466 = ((x10.regionarray.Dist)(this.dist));
                    
                    //#line 946 "x10/regionarray/DistArray.x10"
                    final x10.lang.PlaceGroup t$150467 = t$150466.places();
                    
                    //#line 946 "x10/regionarray/DistArray.x10"
                    final x10.lang.Iterator where$149766 = t$150467.iterator();
                    
                    //#line 946 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 946 "x10/regionarray/DistArray.x10"
                        final boolean t$150476 = ((x10.lang.Iterator<x10.lang.Place>)where$149766).hasNext$O();
                        
                        //#line 946 "x10/regionarray/DistArray.x10"
                        if (!(t$150476)) {
                            
                            //#line 946 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 946 "x10/regionarray/DistArray.x10"
                        final x10.lang.Place where$150860 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$149766).next$G()));
                        
                        //#line 947 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$150860)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$191<$T, $U>($T, $U, ((x10.regionarray.DistArray)(this)), this.dist, unit, lop, (x10.regionarray.DistArray.$Closure$191.__0$1x10$regionarray$DistArray$$Closure$191$$T$2__2x10$regionarray$DistArray$$Closure$191$$U__3$1x10$regionarray$DistArray$$Closure$191$$U$3x10$regionarray$DistArray$$Closure$191$$T$3x10$regionarray$DistArray$$Closure$191$$U$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 945 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(__lowerer__var__0__)));
                
                //#line 945 "x10/regionarray/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 945 "x10/regionarray/DistArray.x10"
                 result = (($U)(x10.xrx.Runtime.<$U> stopCollectingFinish$G($U, ((x10.xrx.FinishState)(fs$151005)))));
             }}
            }
        
        //#line 960 "x10/regionarray/DistArray.x10"
        return result;
        }
    
    
    //#line 967 "x10/regionarray/DistArray.x10"
    /**
     * Update ghost data for every place in this DistArray.
     * This includes synchronization before and after the update.
     */
    public void updateGhosts() {
        
        //#line 968 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle t$150477 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 968 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray.LocalState t$150478 = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$150477).$apply$G()));
        
        //#line 968 "x10/regionarray/DistArray.x10"
        final x10.regionarray.GhostManager t$150479 = ((x10.regionarray.GhostManager)(((x10.regionarray.DistArray.LocalState<$T>)t$150478).ghostManager));
        
        //#line 968 "x10/regionarray/DistArray.x10"
        final boolean t$150485 = ((t$150479) != (null));
        
        //#line 968 "x10/regionarray/DistArray.x10"
        if (t$150485) {
            {
                
                //#line 969 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 969 "x10/regionarray/DistArray.x10"
                final x10.xrx.FinishState fs$151023 = x10.xrx.Runtime.startFinish();
                
                //#line 969 "x10/regionarray/DistArray.x10"
                try {{
                    {
                        
                        //#line 969 "x10/regionarray/DistArray.x10"
                        final x10.regionarray.Dist t$150480 = ((x10.regionarray.Dist)(this.dist));
                        
                        //#line 969 "x10/regionarray/DistArray.x10"
                        final x10.lang.PlaceGroup t$150481 = t$150480.places();
                        
                        //#line 969 "x10/regionarray/DistArray.x10"
                        final x10.regionarray.Dist t$150484 = ((x10.regionarray.Dist)(x10.regionarray.Dist.makeUnique(((x10.lang.PlaceGroup)(t$150481)))));
                        {
                            
                            //#line 969 "x10/regionarray/DistArray.x10"
                            x10.xrx.Runtime.ensureNotInAtomic();
                            
                            //#line 969 "x10/regionarray/DistArray.x10"
                            final x10.regionarray.Dist __lowerer__var__0__ = ((x10.regionarray.Dist)(t$150484));
                            
                            //#line 969 "x10/regionarray/DistArray.x10"
                            for (
                                 //#line 969 "x10/regionarray/DistArray.x10"
                                 final x10.lang.Iterator __lowerer__var__3__$151020 = __lowerer__var__0__.places().iterator();
                                 ((x10.lang.Iterator<x10.lang.Place>)__lowerer__var__3__$151020).hasNext$O();
                                 ) {
                                
                                //#line 969 "x10/regionarray/DistArray.x10"
                                final x10.lang.Place __lowerer__var__3__ = ((x10.lang.Iterator<x10.lang.Place>)__lowerer__var__3__$151020).next$G();
                                
                                //#line 969 "x10/regionarray/DistArray.x10"
                                x10.xrx.Runtime.runAsync(((x10.lang.Place)(__lowerer__var__3__)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$193<$T>($T, ((x10.regionarray.DistArray)(this)), __lowerer__var__0__, this.localHandle, (x10.regionarray.DistArray.$Closure$193.__0$1x10$regionarray$DistArray$$Closure$193$$T$2__2$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$193$$T$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                            }
                        }
                    }
                }}catch (java.lang.Throwable ct$151021) {
                    
                    //#line 969 "x10/regionarray/DistArray.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$151021)));
                    
                    //#line 969 "x10/regionarray/DistArray.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 969 "x10/regionarray/DistArray.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$151023)));
                 }}
                }
            }
        }
    
    
    //#line 981 "x10/regionarray/DistArray.x10"
    public void sendGhostsLocal() {
        
        //#line 982 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle t$150486 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 982 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray.LocalState t$150487 = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$150486).$apply$G()));
        
        //#line 982 "x10/regionarray/DistArray.x10"
        final x10.regionarray.GhostManager ghostManager = ((x10.regionarray.GhostManager)(((x10.regionarray.DistArray.LocalState<$T>)t$150487).ghostManager));
        
        //#line 983 "x10/regionarray/DistArray.x10"
        final boolean t$150488 = ((ghostManager) != (null));
        
        //#line 983 "x10/regionarray/DistArray.x10"
        if (t$150488) {
            
            //#line 984 "x10/regionarray/DistArray.x10"
            ghostManager.sendGhosts(((x10.regionarray.Ghostable)(this)));
        }
    }
    
    
    //#line 992 "x10/regionarray/DistArray.x10"
    public void waitForGhostsLocal() {
        
        //#line 993 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle t$150489 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 993 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray.LocalState t$150490 = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$150489).$apply$G()));
        
        //#line 993 "x10/regionarray/DistArray.x10"
        final x10.regionarray.GhostManager ghostManager = ((x10.regionarray.GhostManager)(((x10.regionarray.DistArray.LocalState<$T>)t$150490).ghostManager));
        
        //#line 994 "x10/regionarray/DistArray.x10"
        final boolean t$150491 = ((ghostManager) != (null));
        
        //#line 994 "x10/regionarray/DistArray.x10"
        if (t$150491) {
            
            //#line 995 "x10/regionarray/DistArray.x10"
            ghostManager.waitOnGhosts();
        }
    }
    
    
    //#line 999 "x10/regionarray/DistArray.x10"
    public void putOverlap(final x10.regionarray.Region overlap, final x10.lang.Place neighborPlace, final x10.lang.Point shift, final byte phase) {
        
        //#line 1000 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150051 = ((x10.regionarray.DistArray)(this));
        
        //#line 67 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist this$150053 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$150051).dist));
        
        //#line 38 .. "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$150492 = ((x10.regionarray.Region)(this$150053.region));
        
        //#line 38 .. "x10/regionarray/Dist.x10"
        final long t$150493 = t$150492.rank;
        
        //#line 1000 "x10/regionarray/DistArray.x10"
        final boolean t$150555 = ((long) t$150493) == ((long) 3L);
        
        //#line 1000 "x10/regionarray/DistArray.x10"
        if (t$150555) {
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$149058 = ((x10.regionarray.Region)
                                                      overlap);
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            final boolean t$150494 = t$149058.rect;
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            boolean t$150496 = ((boolean) t$150494) == ((boolean) true);
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            if (t$150496) {
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                final long t$150495 = t$149058.rank;
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                t$150496 = ((long) t$150495) == ((long) 3L);
            }
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            boolean t$150500 = t$150496;
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            if (t$150496) {
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$150497 = ((x10.regionarray.Dist)(x10.regionarray.DistArray.this.dist));
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150498 = ((x10.regionarray.Region)(t$150497.region));
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                final long t$150499 = t$150498.rank;
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                t$150500 = ((long) t$150499) == ((long) 3L);
            }
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            final boolean t$150503 = !(t$150500);
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            if (t$150503) {
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                final x10.lang.FailedDynamicCheckException t$150502 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==3L, this(:x10.regionarray.DistArray).dist.region.rank==3L}");
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                throw t$150502;
            }
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            this.putOverlap3(((x10.regionarray.Region)(t$149058)), ((x10.lang.Place)(neighborPlace)), ((x10.lang.Point)(shift)), (byte)(phase));
        } else {
            
            //#line 1003 "x10/regionarray/DistArray.x10"
            final boolean t$150504 = overlap.isEmpty$O();
            
            //#line 1003 "x10/regionarray/DistArray.x10"
            final boolean t$150554 = !(t$150504);
            
            //#line 1003 "x10/regionarray/DistArray.x10"
            if (t$150554) {
                
                //#line 1004 "x10/regionarray/DistArray.x10"
                final x10.lang.Place sourcePlace = ((x10.lang.Place)(x10.x10rt.X10RT.here()));
                
                //#line 1005 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150055 = ((x10.regionarray.DistArray)(this));
                
                //#line 1005 "x10/regionarray/DistArray.x10"
                final x10.core.Rail localRaw = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150055).raw));
                
                //#line 1006 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150057 = ((x10.regionarray.DistArray)(this));
                
                //#line 1006 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region g = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150057).localRegion));
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150505 = ((x10.regionarray.Region)(overlap.$plus(((x10.lang.Point)(shift)))));
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$149062 = ((x10.regionarray.Region)
                                                          t$150505);
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                final boolean t$150506 = t$149062.rect;
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                boolean t$150509 = ((boolean) t$150506) == ((boolean) true);
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                if (t$150509) {
                    
                    //#line 1007 "x10/regionarray/DistArray.x10"
                    final long t$150507 = t$149062.rank;
                    
                    //#line 1007 "x10/regionarray/DistArray.x10"
                    final long t$150508 = overlap.rank;
                    
                    //#line 1007 "x10/regionarray/DistArray.x10"
                    t$150509 = ((long) t$150507) == ((long) t$150508);
                }
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                final boolean t$150512 = !(t$150509);
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                if (t$150512) {
                    
                    //#line 1007 "x10/regionarray/DistArray.x10"
                    final x10.lang.FailedDynamicCheckException t$150511 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==overlap.rank}");
                    
                    //#line 1007 "x10/regionarray/DistArray.x10"
                    throw t$150511;
                }
                
                //#line 1008 "x10/regionarray/DistArray.x10"
                final long t$150513 = t$149062.size$O();
                
                //#line 1008 "x10/regionarray/DistArray.x10"
                final x10.core.Rail neighborPortionRaw = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$150513)), false)));
                
                //#line 1009 "x10/regionarray/DistArray.x10"
                long offset = 0L;
                
                //#line 1010 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator p$150885 = overlap.iterator();
                
                //#line 1010 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1010 "x10/regionarray/DistArray.x10"
                    final boolean t$150886 = ((x10.lang.Iterator<x10.lang.Point>)p$150885).hasNext$O();
                    
                    //#line 1010 "x10/regionarray/DistArray.x10"
                    if (!(t$150886)) {
                        
                        //#line 1010 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 1010 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point p$150869 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$150885).next$G()));
                    
                    //#line 1011 "x10/regionarray/DistArray.x10"
                    final long pre$150870 = offset;
                    
                    //#line 1011 "x10/regionarray/DistArray.x10"
                    final long t$150872 = ((offset) + (((long)(1L))));
                    
                    //#line 1011 "x10/regionarray/DistArray.x10"
                    offset = t$150872;
                    
                    //#line 1011 "x10/regionarray/DistArray.x10"
                    final long t$150873 = g.indexOf$O(((x10.lang.Point)(p$150869)));
                    
                    //#line 1011 "x10/regionarray/DistArray.x10"
                    final $T t$150874 = (($T)(((x10.core.Rail<$T>)localRaw).$apply$G((long)(t$150873))));
                    
                    //#line 1011 "x10/regionarray/DistArray.x10"
                    ((x10.core.Rail<$T>)neighborPortionRaw).$set__1x10$lang$Rail$$T$G((long)(pre$150870), (($T)(t$150874)));
                }
                
                //#line 1013 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Array neighborPortion = ((x10.regionarray.Array)(new x10.regionarray.Array<$T>((java.lang.System[]) null, $T)));
                
                //#line 233 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$150875 = ((x10.regionarray.Region)
                                                          t$149062);
                
                //#line 233 . "x10/regionarray/Array.x10"
                final boolean t$150876 = ((t$150875) != (null));
                
                //#line 233 . "x10/regionarray/Array.x10"
                final boolean t$150877 = !(t$150876);
                
                //#line 233 . "x10/regionarray/Array.x10"
                if (t$150877) {
                    
                    //#line 233 . "x10/regionarray/Array.x10"
                    final boolean t$150878 = true;
                    
                    //#line 233 . "x10/regionarray/Array.x10"
                    if (t$150878) {
                        
                        //#line 233 . "x10/regionarray/Array.x10"
                        final x10.lang.FailedDynamicCheckException t$150879 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                        
                        //#line 233 . "x10/regionarray/Array.x10"
                        throw t$150879;
                    }
                }
                
                //#line 233 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).region = ((x10.regionarray.Region)(t$150875));
                
                //#line 233 . "x10/regionarray/Array.x10"
                final long t$150880 = t$149062.rank;
                
                //#line 233 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).rank = t$150880;
                
                //#line 233 . "x10/regionarray/Array.x10"
                final boolean t$150881 = t$149062.rect;
                
                //#line 233 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).rect = t$150881;
                
                //#line 233 . "x10/regionarray/Array.x10"
                final boolean t$150882 = t$149062.zeroBased;
                
                //#line 233 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).zeroBased = t$150882;
                
                //#line 233 . "x10/regionarray/Array.x10"
                final boolean t$150883 = t$149062.rail;
                
                //#line 233 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).rail = t$150883;
                
                //#line 233 . "x10/regionarray/Array.x10"
                final long t$150884 = t$149062.size$O();
                
                //#line 233 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).size = t$150884;
                
                //#line 235 . "x10/regionarray/Array.x10"
                final x10.regionarray.Array.LayoutHelper crh$150887 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
                
                //#line 235 . "x10/regionarray/Array.x10"
                crh$150887.x10$regionarray$Array$LayoutHelper$$init$S(t$149062);
                
                //#line 236 . "x10/regionarray/Array.x10"
                final long t$150888 = crh$150887.min0;
                
                //#line 236 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).layout_min0 = t$150888;
                
                //#line 237 . "x10/regionarray/Array.x10"
                final long t$150889 = crh$150887.stride1;
                
                //#line 237 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).layout_stride1 = t$150889;
                
                //#line 238 . "x10/regionarray/Array.x10"
                final long t$150890 = crh$150887.min1;
                
                //#line 238 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).layout_min1 = t$150890;
                
                //#line 239 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$150891 = ((x10.core.Rail)(crh$150887.layout));
                
                //#line 239 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).layout = ((x10.core.Rail)(t$150891));
                
                //#line 240 . "x10/regionarray/Array.x10"
                final long n$150892 = crh$150887.size;
                
                //#line 241 . "x10/regionarray/Array.x10"
                final long t$150893 = ((x10.core.Rail<$T>)neighborPortionRaw).size;
                
                //#line 241 . "x10/regionarray/Array.x10"
                final boolean t$150894 = ((n$150892) > (((long)(t$150893))));
                
                //#line 241 . "x10/regionarray/Array.x10"
                if (t$150894) {
                    
                    //#line 242 . "x10/regionarray/Array.x10"
                    final boolean t$150895 = true;
                    
                    //#line 242 . "x10/regionarray/Array.x10"
                    if (t$150895) {
                        
                        //#line 242 . "x10/regionarray/Array.x10"
                        final java.lang.IllegalArgumentException t$150896 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("backingStore too small")));
                        
                        //#line 242 . "x10/regionarray/Array.x10"
                        throw t$150896;
                    }
                }
                
                //#line 244 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$150897 = ((x10.core.Rail<$T>)
                                                 neighborPortionRaw);
                
                //#line 244 . "x10/regionarray/Array.x10"
                final boolean t$150898 = ((t$150897) != (null));
                
                //#line 244 . "x10/regionarray/Array.x10"
                final boolean t$150899 = !(t$150898);
                
                //#line 244 . "x10/regionarray/Array.x10"
                if (t$150899) {
                    
                    //#line 244 . "x10/regionarray/Array.x10"
                    final boolean t$150900 = true;
                    
                    //#line 244 . "x10/regionarray/Array.x10"
                    if (t$150900) {
                        
                        //#line 244 . "x10/regionarray/Array.x10"
                        final x10.lang.FailedDynamicCheckException t$150901 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self!=null}");
                        
                        //#line 244 . "x10/regionarray/Array.x10"
                        throw t$150901;
                    }
                }
                
                //#line 244 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).raw = ((x10.core.Rail)(t$150897));
                
                //#line 1014 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.runAsync(((x10.lang.Place)(neighborPlace)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$194<$T>($T, ((x10.regionarray.DistArray)(this)), this.localHandle, phase, neighborPortion, shift, sourcePlace, (x10.regionarray.DistArray.$Closure$194.__0$1x10$regionarray$DistArray$$Closure$194$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$194$$T$2$2__3$1x10$regionarray$DistArray$$Closure$194$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            }
        }
    }
    
    
    //#line 1025 "x10/regionarray/DistArray.x10"
    private void putOverlap3(final x10.regionarray.Region overlap, final x10.lang.Place neighborPlace, final x10.lang.Point shift, final byte phase) {
        
        //#line 1026 "x10/regionarray/DistArray.x10"
        final boolean t$150556 = overlap.isEmpty$O();
        
        //#line 1026 "x10/regionarray/DistArray.x10"
        final boolean t$150620 = !(t$150556);
        
        //#line 1026 "x10/regionarray/DistArray.x10"
        if (t$150620) {
            
            //#line 1027 "x10/regionarray/DistArray.x10"
            final x10.lang.Place sourcePlace = ((x10.lang.Place)(x10.x10rt.X10RT.here()));
            
            //#line 1028 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150067 = ((x10.regionarray.DistArray)(this));
            
            //#line 1028 "x10/regionarray/DistArray.x10"
            final x10.core.Rail localRaw = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150067).raw));
            
            //#line 1029 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150069 = ((x10.regionarray.DistArray)(this));
            
            //#line 1029 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region g = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150069).localRegion));
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150557 = ((x10.regionarray.Region)(overlap.$plus(((x10.lang.Point)(shift)))));
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$149077 = ((x10.regionarray.Region)
                                                      t$150557);
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            final boolean t$150558 = t$149077.rect;
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            boolean t$150560 = ((boolean) t$150558) == ((boolean) true);
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            if (t$150560) {
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                final long t$150559 = t$149077.rank;
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                t$150560 = ((long) t$150559) == ((long) 3L);
            }
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            boolean t$150564 = t$150560;
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            if (t$150560) {
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$150561 = ((x10.regionarray.Dist)(x10.regionarray.DistArray.this.dist));
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150562 = ((x10.regionarray.Region)(t$150561.region));
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                final long t$150563 = t$150562.rank;
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                t$150564 = ((long) t$150563) == ((long) 3L);
            }
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            final boolean t$150567 = !(t$150564);
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            if (t$150567) {
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                final x10.lang.FailedDynamicCheckException t$150566 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==3L, this(:x10.regionarray.DistArray).dist.region.rank==3L}");
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                throw t$150566;
            }
            
            //#line 1031 "x10/regionarray/DistArray.x10"
            final long t$150568 = t$149077.size$O();
            
            //#line 1031 "x10/regionarray/DistArray.x10"
            final x10.core.Rail neighborPortionRaw = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$150568)), false)));
            
            //#line 1032 "x10/regionarray/DistArray.x10"
            long offset = 0L;
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            final long k$149771min$150936 = overlap.min$O((long)(2L));
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            final long k$149771max$150937 = overlap.max$O((long)(2L));
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            final long j$149790min$150938 = overlap.min$O((long)(1L));
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            final long j$149790max$150939 = overlap.max$O((long)(1L));
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            final long i$149809min$150940 = overlap.min$O((long)(0L));
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            final long i$149809max$150941 = overlap.max$O((long)(0L));
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            long i$150922 = i$149809min$150940;
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            for (;
                 true;
                 ) {
                
                //#line 1033 "x10/regionarray/DistArray.x10"
                final boolean t$150924 = ((i$150922) <= (((long)(i$149809max$150941))));
                
                //#line 1033 "x10/regionarray/DistArray.x10"
                if (!(t$150924)) {
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    break;
                }
                
                //#line 1033 "x10/regionarray/DistArray.x10"
                long j$150916 = j$149790min$150938;
                
                //#line 1033 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    final boolean t$150918 = ((j$150916) <= (((long)(j$149790max$150939))));
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    if (!(t$150918)) {
                        
                        //#line 1033 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    long k$150910 = k$149771min$150936;
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1033 "x10/regionarray/DistArray.x10"
                        final boolean t$150912 = ((k$150910) <= (((long)(k$149771max$150937))));
                        
                        //#line 1033 "x10/regionarray/DistArray.x10"
                        if (!(t$150912)) {
                            
                            //#line 1033 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 1034 "x10/regionarray/DistArray.x10"
                        final long pre$150902 = offset;
                        
                        //#line 1034 "x10/regionarray/DistArray.x10"
                        final long t$150904 = ((offset) + (((long)(1L))));
                        
                        //#line 1034 "x10/regionarray/DistArray.x10"
                        offset = t$150904;
                        
                        //#line 1034 "x10/regionarray/DistArray.x10"
                        final long t$150905 = g.indexOf$O((long)(i$150922), (long)(j$150916), (long)(k$150910));
                        
                        //#line 1034 "x10/regionarray/DistArray.x10"
                        final $T t$150906 = (($T)(((x10.core.Rail<$T>)localRaw).$apply$G((long)(t$150905))));
                        
                        //#line 1034 "x10/regionarray/DistArray.x10"
                        ((x10.core.Rail<$T>)neighborPortionRaw).$set__1x10$lang$Rail$$T$G((long)(pre$150902), (($T)(t$150906)));
                        
                        //#line 1033 "x10/regionarray/DistArray.x10"
                        final long t$150909 = ((k$150910) + (((long)(1L))));
                        
                        //#line 1033 "x10/regionarray/DistArray.x10"
                        k$150910 = t$150909;
                    }
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    final long t$150915 = ((j$150916) + (((long)(1L))));
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    j$150916 = t$150915;
                }
                
                //#line 1033 "x10/regionarray/DistArray.x10"
                final long t$150921 = ((i$150922) + (((long)(1L))));
                
                //#line 1033 "x10/regionarray/DistArray.x10"
                i$150922 = t$150921;
            }
            
            //#line 1036 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Array neighborPortion = ((x10.regionarray.Array)(new x10.regionarray.Array<$T>((java.lang.System[]) null, $T)));
            
            //#line 233 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$150925 = ((x10.regionarray.Region)
                                                      t$149077);
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$150926 = ((t$150925) != (null));
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$150927 = !(t$150926);
            
            //#line 233 . "x10/regionarray/Array.x10"
            if (t$150927) {
                
                //#line 233 . "x10/regionarray/Array.x10"
                final boolean t$150928 = true;
                
                //#line 233 . "x10/regionarray/Array.x10"
                if (t$150928) {
                    
                    //#line 233 . "x10/regionarray/Array.x10"
                    final x10.lang.FailedDynamicCheckException t$150929 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                    
                    //#line 233 . "x10/regionarray/Array.x10"
                    throw t$150929;
                }
            }
            
            //#line 233 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).region = ((x10.regionarray.Region)(t$150925));
            
            //#line 233 . "x10/regionarray/Array.x10"
            final long t$150930 = t$149077.rank;
            
            //#line 233 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).rank = t$150930;
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$150931 = t$149077.rect;
            
            //#line 233 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).rect = t$150931;
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$150932 = t$149077.zeroBased;
            
            //#line 233 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).zeroBased = t$150932;
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$150933 = t$149077.rail;
            
            //#line 233 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).rail = t$150933;
            
            //#line 233 . "x10/regionarray/Array.x10"
            final long t$150934 = t$149077.size$O();
            
            //#line 233 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).size = t$150934;
            
            //#line 235 . "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh$150942 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 235 . "x10/regionarray/Array.x10"
            crh$150942.x10$regionarray$Array$LayoutHelper$$init$S(t$149077);
            
            //#line 236 . "x10/regionarray/Array.x10"
            final long t$150943 = crh$150942.min0;
            
            //#line 236 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).layout_min0 = t$150943;
            
            //#line 237 . "x10/regionarray/Array.x10"
            final long t$150944 = crh$150942.stride1;
            
            //#line 237 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).layout_stride1 = t$150944;
            
            //#line 238 . "x10/regionarray/Array.x10"
            final long t$150945 = crh$150942.min1;
            
            //#line 238 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).layout_min1 = t$150945;
            
            //#line 239 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$150946 = ((x10.core.Rail)(crh$150942.layout));
            
            //#line 239 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).layout = ((x10.core.Rail)(t$150946));
            
            //#line 240 . "x10/regionarray/Array.x10"
            final long n$150947 = crh$150942.size;
            
            //#line 241 . "x10/regionarray/Array.x10"
            final long t$150948 = ((x10.core.Rail<$T>)neighborPortionRaw).size;
            
            //#line 241 . "x10/regionarray/Array.x10"
            final boolean t$150949 = ((n$150947) > (((long)(t$150948))));
            
            //#line 241 . "x10/regionarray/Array.x10"
            if (t$150949) {
                
                //#line 242 . "x10/regionarray/Array.x10"
                final boolean t$150950 = true;
                
                //#line 242 . "x10/regionarray/Array.x10"
                if (t$150950) {
                    
                    //#line 242 . "x10/regionarray/Array.x10"
                    final java.lang.IllegalArgumentException t$150951 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("backingStore too small")));
                    
                    //#line 242 . "x10/regionarray/Array.x10"
                    throw t$150951;
                }
            }
            
            //#line 244 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$150952 = ((x10.core.Rail<$T>)
                                             neighborPortionRaw);
            
            //#line 244 . "x10/regionarray/Array.x10"
            final boolean t$150953 = ((t$150952) != (null));
            
            //#line 244 . "x10/regionarray/Array.x10"
            final boolean t$150954 = !(t$150953);
            
            //#line 244 . "x10/regionarray/Array.x10"
            if (t$150954) {
                
                //#line 244 . "x10/regionarray/Array.x10"
                final boolean t$150955 = true;
                
                //#line 244 . "x10/regionarray/Array.x10"
                if (t$150955) {
                    
                    //#line 244 . "x10/regionarray/Array.x10"
                    final x10.lang.FailedDynamicCheckException t$150956 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self!=null}");
                    
                    //#line 244 . "x10/regionarray/Array.x10"
                    throw t$150956;
                }
            }
            
            //#line 244 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).raw = ((x10.core.Rail)(t$150952));
            
            //#line 1037 "x10/regionarray/DistArray.x10"
            x10.xrx.Runtime.runAsync(((x10.lang.Place)(neighborPlace)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$195<$T>($T, ((x10.regionarray.DistArray)(this)), this.localHandle, phase, neighborPortion, shift, sourcePlace, (x10.regionarray.DistArray.$Closure$195.__0$1x10$regionarray$DistArray$$Closure$195$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$195$$T$2$2__3$1x10$regionarray$DistArray$$Closure$195$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    public static <$T>void putOverlap3$P__4$1x10$regionarray$DistArray$$T$2(final x10.rtt.Type $T, final x10.regionarray.Region overlap, final x10.lang.Place neighborPlace, final x10.lang.Point shift, final byte phase, final x10.regionarray.DistArray<$T> DistArray) {
        ((x10.regionarray.DistArray<$T>)DistArray).putOverlap3(((x10.regionarray.Region)(overlap)), ((x10.lang.Place)(neighborPlace)), ((x10.lang.Point)(shift)), (byte)(phase));
    }
    
    
    //#line 1048 "x10/regionarray/DistArray.x10"
    public java.lang.String toString() {
        
        //#line 1049 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150621 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 1049 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150622 = (("DistArray(") + (t$150621));
        
        //#line 1049 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150623 = ((t$150622) + (")"));
        
        //#line 1049 "x10/regionarray/DistArray.x10"
        return t$150623;
    }
    
    
    //#line 1058 "x10/regionarray/DistArray.x10"
    /**
     * Return an iterator over the points in the region of this array.
     *
     * @return an iterator over the points in the region of this array.
     * @see x10.lang.Iterable[T]#iterator()
     */
    public x10.lang.Iterator iterator() {
        
        //#line 1058 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150079 = ((x10.regionarray.DistArray)(this));
        
        //#line 62 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150624 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$150079).dist));
        
        //#line 62 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150625 = ((x10.regionarray.Region)(t$150624.region));
        
        //#line 1058 "x10/regionarray/DistArray.x10"
        final x10.lang.Iterator t$150626 = t$150625.iterator();
        
        //#line 1058 "x10/regionarray/DistArray.x10"
        final x10.lang.Iterator t$150627 = ((x10.lang.Iterator<x10.lang.Point>)
                                             t$150626);
        
        //#line 1058 "x10/regionarray/DistArray.x10"
        return t$150627;
    }
    
    
    //#line 1060 "x10/regionarray/DistArray.x10"
    public static void raisePlaceError(final long i0) {
        
        //#line 1061 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150628 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1061 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150629 = ((t$150628) + (") not defined at "));
        
        //#line 1061 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150630 = ((t$150629) + (x10.x10rt.X10RT.here()));
        
        //#line 1061 "x10/regionarray/DistArray.x10"
        final x10.lang.BadPlaceException t$150631 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$150630)));
        
        //#line 1061 "x10/regionarray/DistArray.x10"
        throw t$150631;
    }
    
    
    //#line 1063 "x10/regionarray/DistArray.x10"
    public static void raisePlaceError(final long i0, final long i1) {
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150632 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150633 = ((t$150632) + (", "));
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150634 = ((t$150633) + ((x10.core.Long.$box(i1))));
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150635 = ((t$150634) + (") not defined at "));
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150636 = ((t$150635) + (x10.x10rt.X10RT.here()));
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        final x10.lang.BadPlaceException t$150637 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$150636)));
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        throw t$150637;
    }
    
    
    //#line 1066 "x10/regionarray/DistArray.x10"
    public static void raisePlaceError(final long i0, final long i1, final long i2) {
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150638 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150639 = ((t$150638) + (", "));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150640 = ((t$150639) + ((x10.core.Long.$box(i1))));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150641 = ((t$150640) + (", "));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150642 = ((t$150641) + ((x10.core.Long.$box(i2))));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150643 = ((t$150642) + (") not defined at "));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150644 = ((t$150643) + (x10.x10rt.X10RT.here()));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final x10.lang.BadPlaceException t$150645 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$150644)));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        throw t$150645;
    }
    
    
    //#line 1069 "x10/regionarray/DistArray.x10"
    public static void raisePlaceError(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150646 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150647 = ((t$150646) + (", "));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150648 = ((t$150647) + ((x10.core.Long.$box(i1))));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150649 = ((t$150648) + (", "));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150650 = ((t$150649) + ((x10.core.Long.$box(i2))));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150651 = ((t$150650) + (", "));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150652 = ((t$150651) + ((x10.core.Long.$box(i3))));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150653 = ((t$150652) + (") not defined at "));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150654 = ((t$150653) + (x10.x10rt.X10RT.here()));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final x10.lang.BadPlaceException t$150655 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$150654)));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        throw t$150655;
    }
    
    
    //#line 1072 "x10/regionarray/DistArray.x10"
    public static void raisePlaceError(final x10.lang.Point pt) {
        
        //#line 1073 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150656 = (("point ") + (pt));
        
        //#line 1073 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150657 = ((t$150656) + (" not defined at "));
        
        //#line 1073 "x10/regionarray/DistArray.x10"
        final java.lang.String t$150658 = ((t$150657) + (x10.x10rt.X10RT.here()));
        
        //#line 1073 "x10/regionarray/DistArray.x10"
        final x10.lang.BadPlaceException t$150659 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$150658)));
        
        //#line 1073 "x10/regionarray/DistArray.x10"
        throw t$150659;
    }
    
    
    //#line 45 "x10/regionarray/DistArray.x10"
    final public x10.regionarray.DistArray x10$regionarray$DistArray$$this$x10$regionarray$DistArray() {
        
        //#line 45 "x10/regionarray/DistArray.x10"
        return x10.regionarray.DistArray.this;
    }
    
    
    //#line 45 "x10/regionarray/DistArray.x10"
    final public void __fieldInitializers_x10_regionarray_DistArray() {
        
    }
    
    
    //#line 940 "x10/regionarray/DistArray.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$39192<$U, $T> extends x10.core.Ref implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$39192> $RTT = 
            x10.rtt.NamedType.<Anonymous$39192> make("x10.regionarray.DistArray.Anonymous$39192",
                                                     Anonymous$39192.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $U; if (i == 1) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$U, $T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.Anonymous$39192<$U, $T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.gop = $deserializer.readObject();
            $_obj.out$ = $deserializer.readObject();
            $_obj.unit = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.Anonymous$39192 $_obj = new x10.regionarray.DistArray.Anonymous$39192((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$U);
            $serializer.write(this.$T);
            $serializer.write(this.gop);
            $serializer.write(this.out$);
            $serializer.write(this.unit);
            
        }
        
        // constructor just for allocation
        public Anonymous$39192(final java.lang.System[] $dummy, final x10.rtt.Type $U, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.Anonymous$39192.$initParams(this, $U, $T);
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$regionarray$DistArray$Anonymous$39192$$U__1x10$regionarray$DistArray$Anonymous$39192$$U$G(($U)a1, ($U)a2);
            
        }
        
        private x10.rtt.Type $U;
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$39192 $this, final x10.rtt.Type $U, final x10.rtt.Type $T) {
            $this.$U = $U;
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling for __0$1x10$regionarray$DistArray$Anonymous$39192$$T$2__1x10$regionarray$DistArray$Anonymous$39192$$U__2$1x10$regionarray$DistArray$Anonymous$39192$$U$3x10$regionarray$DistArray$Anonymous$39192$$U$3x10$regionarray$DistArray$Anonymous$39192$$U$2
        public static final class $_d5f1deb3 {}
        
    
        
        //#line 45 "x10/regionarray/DistArray.x10"
        public x10.regionarray.DistArray<$T> out$;
        
        //#line 939 "x10/regionarray/DistArray.x10"
        public $U unit;
        
        //#line 939 "x10/regionarray/DistArray.x10"
        public x10.core.fun.Fun_0_2<$U,$U,$U> gop;
        
        
        //#line 941 "x10/regionarray/DistArray.x10"
        public $U zero$G() {
            
            //#line 941 "x10/regionarray/DistArray.x10"
            final $U t$150660 = (($U)(x10.regionarray.DistArray.Anonymous$39192.this.unit));
            
            //#line 941 "x10/regionarray/DistArray.x10"
            return t$150660;
        }
        
        
        //#line 942 "x10/regionarray/DistArray.x10"
        public $U $apply__0x10$regionarray$DistArray$Anonymous$39192$$U__1x10$regionarray$DistArray$Anonymous$39192$$U$G(final $U a, final $U b) {
            
            //#line 942 "x10/regionarray/DistArray.x10"
            final x10.core.fun.Fun_0_2 t$150661 = x10.regionarray.DistArray.Anonymous$39192.this.gop;
            
            //#line 942 "x10/regionarray/DistArray.x10"
            final $U t$150662 = (($U)((($U)
                                        ((x10.core.fun.Fun_0_2<$U,$U,$U>)t$150661).$apply(a, $U, b, $U))));
            
            //#line 942 "x10/regionarray/DistArray.x10"
            return t$150662;
        }
        
        
        //#line 940 "x10/regionarray/DistArray.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$39192(final x10.rtt.Type $U, final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> out$, final $U unit, final x10.core.fun.Fun_0_2<$U,$U,$U> gop, $_d5f1deb3 $dummy) {
            this((java.lang.System[]) null, $U, $T);
            x10$regionarray$DistArray$Anonymous$39192$$init$S(out$, unit, gop, (x10.regionarray.DistArray.Anonymous$39192.$_d5f1deb3) null);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.DistArray.Anonymous$39192<$U, $T> x10$regionarray$DistArray$Anonymous$39192$$init$S(final x10.regionarray.DistArray<$T> out$, final $U unit, final x10.core.fun.Fun_0_2<$U,$U,$U> gop, $_d5f1deb3 $dummy) {
             {
                
                //#line 45 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.DistArray.Anonymous$39192<$U, $T>)this).out$ = out$;
                
                //#line 939 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.DistArray.Anonymous$39192<$U, $T>)this).unit = (($U)(unit));
                
                //#line 939 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.DistArray.Anonymous$39192<$U, $T>)this).gop = gop;
            }
            return this;
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$179<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$179> $RTT = 
            x10.rtt.StaticFunType.<$Closure$179> make($Closure$179.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$179<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.ghostWidth = $deserializer.readLong();
            $_obj.periodic = $deserializer.readBoolean();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$179 $_obj = new x10.regionarray.DistArray.$Closure$179((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.dist);
            $serializer.write(this.ghostWidth);
            $serializer.write(this.periodic);
            
        }
        
        // constructor just for allocation
        public $Closure$179(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$179.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.regionarray.DistArray.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$179 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public x10.regionarray.DistArray.LocalState $apply() {
            
            //#line 176 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region localRegion;
            
            //#line 177 "x10/regionarray/DistArray.x10"
            final x10.regionarray.GhostManager ghostManager = x10.regionarray.DistArray.getGhostManager(((x10.regionarray.Dist)(this.dist)), (long)(this.ghostWidth), (boolean)(this.periodic));
            
            //#line 178 "x10/regionarray/DistArray.x10"
            final boolean t$150138 = ((ghostManager) != (null));
            
            //#line 178 "x10/regionarray/DistArray.x10"
            if (t$150138) {
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150130 = ghostManager.getGhostRegion(((x10.lang.Place)(x10.x10rt.X10RT.here())));
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$148877 = ((x10.regionarray.Region)
                                                          t$150130);
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final long t$150132 = t$148877.rank;
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150131 = ((x10.regionarray.Region)(this.dist.region));
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final long t$150133 = t$150131.rank;
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final boolean t$150134 = ((long) t$150132) == ((long) t$150133);
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final boolean t$150136 = !(t$150134);
                
                //#line 179 "x10/regionarray/DistArray.x10"
                if (t$150136) {
                    
                    //#line 179 "x10/regionarray/DistArray.x10"
                    final x10.lang.FailedDynamicCheckException t$150135 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==dist.region.rank}");
                    
                    //#line 179 "x10/regionarray/DistArray.x10"
                    throw t$150135;
                }
                
                //#line 179 "x10/regionarray/DistArray.x10"
                localRegion = ((x10.regionarray.Region)(t$148877));
            } else {
                
                //#line 181 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150137 = ((x10.regionarray.Region)(this.dist.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 181 "x10/regionarray/DistArray.x10"
                localRegion = ((x10.regionarray.Region)(t$150137));
            }
            
            //#line 183 "x10/regionarray/DistArray.x10"
            final long t$150139 = localRegion.size$O();
            
            //#line 183 "x10/regionarray/DistArray.x10"
            final x10.core.Rail localRaw = ((x10.core.Rail)(new x10.core.Rail<$T>($T, t$150139)));
            
            //#line 184 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState alloc$149721 = ((x10.regionarray.DistArray.LocalState)(new x10.regionarray.DistArray.LocalState<$T>((java.lang.System[]) null, $T)));
            
            //#line 184 "x10/regionarray/DistArray.x10"
            alloc$149721.x10$regionarray$DistArray$LocalState$$init$S(this.dist, ((x10.core.Rail)(localRaw)), ((x10.regionarray.Region)(localRegion)), ((x10.regionarray.GhostManager)(ghostManager)), (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
            
            //#line 184 "x10/regionarray/DistArray.x10"
            return alloc$149721;
        }
        
        public x10.regionarray.Dist dist;
        public long ghostWidth;
        public boolean periodic;
        
        public $Closure$179(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final long ghostWidth, final boolean periodic) {
            x10.regionarray.DistArray.$Closure$179.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$179<$T>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$179<$T>)this).ghostWidth = ghostWidth;
                ((x10.regionarray.DistArray.$Closure$179<$T>)this).periodic = periodic;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$180<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$180> $RTT = 
            x10.rtt.StaticFunType.<$Closure$180> make($Closure$180.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$180<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.ghostWidth = $deserializer.readLong();
            $_obj.init = $deserializer.readObject();
            $_obj.periodic = $deserializer.readBoolean();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$180 $_obj = new x10.regionarray.DistArray.$Closure$180((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.dist);
            $serializer.write(this.ghostWidth);
            $serializer.write(this.init);
            $serializer.write(this.periodic);
            
        }
        
        // constructor just for allocation
        public $Closure$180(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$180.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.regionarray.DistArray.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$180 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __3$1x10$lang$Point$3x10$regionarray$DistArray$$Closure$180$$T$2 {}
        
    
        
        public x10.regionarray.DistArray.LocalState $apply() {
            
            //#line 234 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region localRegion;
            
            //#line 235 "x10/regionarray/DistArray.x10"
            final x10.regionarray.GhostManager ghostManager = x10.regionarray.DistArray.getGhostManager(((x10.regionarray.Dist)(this.dist)), (long)(this.ghostWidth), (boolean)(this.periodic));
            
            //#line 236 "x10/regionarray/DistArray.x10"
            final boolean t$150153 = ((ghostManager) != (null));
            
            //#line 236 "x10/regionarray/DistArray.x10"
            if (t$150153) {
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150145 = ghostManager.getGhostRegion(((x10.lang.Place)(x10.x10rt.X10RT.here())));
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$148879 = ((x10.regionarray.Region)
                                                          t$150145);
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final long t$150147 = t$148879.rank;
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150146 = ((x10.regionarray.Region)(this.dist.region));
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final long t$150148 = t$150146.rank;
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final boolean t$150149 = ((long) t$150147) == ((long) t$150148);
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final boolean t$150151 = !(t$150149);
                
                //#line 237 "x10/regionarray/DistArray.x10"
                if (t$150151) {
                    
                    //#line 237 "x10/regionarray/DistArray.x10"
                    final x10.lang.FailedDynamicCheckException t$150150 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==dist.region.rank}");
                    
                    //#line 237 "x10/regionarray/DistArray.x10"
                    throw t$150150;
                }
                
                //#line 237 "x10/regionarray/DistArray.x10"
                localRegion = ((x10.regionarray.Region)(t$148879));
            } else {
                
                //#line 239 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150152 = ((x10.regionarray.Region)(this.dist.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 239 "x10/regionarray/DistArray.x10"
                localRegion = ((x10.regionarray.Region)(t$150152));
            }
            
            //#line 241 "x10/regionarray/DistArray.x10"
            final long t$150154 = localRegion.size$O();
            
            //#line 241 "x10/regionarray/DistArray.x10"
            final x10.core.Rail localRaw = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$150154)), false)));
            
            //#line 242 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region reg = ((x10.regionarray.Region)(this.dist.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
            
            //#line 243 "x10/regionarray/DistArray.x10"
            final x10.lang.Iterator pt$150695 = reg.iterator();
            
            //#line 243 "x10/regionarray/DistArray.x10"
            for (;
                 true;
                 ) {
                
                //#line 243 "x10/regionarray/DistArray.x10"
                final boolean t$150696 = ((x10.lang.Iterator<x10.lang.Point>)pt$150695).hasNext$O();
                
                //#line 243 "x10/regionarray/DistArray.x10"
                if (!(t$150696)) {
                    
                    //#line 243 "x10/regionarray/DistArray.x10"
                    break;
                }
                
                //#line 243 "x10/regionarray/DistArray.x10"
                final x10.lang.Point pt$150692 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$150695).next$G()));
                
                //#line 244 "x10/regionarray/DistArray.x10"
                final long t$150693 = localRegion.indexOf$O(((x10.lang.Point)(pt$150692)));
                
                //#line 244 "x10/regionarray/DistArray.x10"
                final $T t$150694 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<x10.lang.Point,$T>)this.init).$apply(pt$150692, x10.lang.Point.$RTT))));
                
                //#line 244 "x10/regionarray/DistArray.x10"
                ((x10.core.Rail<$T>)localRaw).$set__1x10$lang$Rail$$T$G((long)(t$150693), (($T)(t$150694)));
            }
            
            //#line 246 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState alloc$149724 = ((x10.regionarray.DistArray.LocalState)(new x10.regionarray.DistArray.LocalState<$T>((java.lang.System[]) null, $T)));
            
            //#line 246 "x10/regionarray/DistArray.x10"
            alloc$149724.x10$regionarray$DistArray$LocalState$$init$S(this.dist, ((x10.core.Rail)(localRaw)), ((x10.regionarray.Region)(localRegion)), ((x10.regionarray.GhostManager)(ghostManager)), (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
            
            //#line 246 "x10/regionarray/DistArray.x10"
            return alloc$149724;
        }
        
        public x10.regionarray.Dist dist;
        public long ghostWidth;
        public boolean periodic;
        public x10.core.fun.Fun_0_1<x10.lang.Point,$T> init;
        
        public $Closure$180(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final long ghostWidth, final boolean periodic, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init, __3$1x10$lang$Point$3x10$regionarray$DistArray$$Closure$180$$T$2 $dummy) {
            x10.regionarray.DistArray.$Closure$180.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$180<$T>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$180<$T>)this).ghostWidth = ghostWidth;
                ((x10.regionarray.DistArray.$Closure$180<$T>)this).periodic = periodic;
                ((x10.regionarray.DistArray.$Closure$180<$T>)this).init = ((x10.core.fun.Fun_0_1)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$181<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$181> $RTT = 
            x10.rtt.StaticFunType.<$Closure$181> make($Closure$181.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$181<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.ghostWidth = $deserializer.readLong();
            $_obj.init = $deserializer.readObject();
            $_obj.periodic = $deserializer.readBoolean();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$181 $_obj = new x10.regionarray.DistArray.$Closure$181((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.dist);
            $serializer.write(this.ghostWidth);
            $serializer.write(this.init);
            $serializer.write(this.periodic);
            
        }
        
        // constructor just for allocation
        public $Closure$181(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$181.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.regionarray.DistArray.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$181 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __3x10$regionarray$DistArray$$Closure$181$$T {}
        
    
        
        public x10.regionarray.DistArray.LocalState $apply() {
            
            //#line 283 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region localRegion;
            
            //#line 284 "x10/regionarray/DistArray.x10"
            final x10.regionarray.GhostManager ghostManager = x10.regionarray.DistArray.getGhostManager(((x10.regionarray.Dist)(this.dist)), (long)(this.ghostWidth), (boolean)(this.periodic));
            
            //#line 285 "x10/regionarray/DistArray.x10"
            final boolean t$150172 = ((ghostManager) != (null));
            
            //#line 285 "x10/regionarray/DistArray.x10"
            if (t$150172) {
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150164 = ghostManager.getGhostRegion(((x10.lang.Place)(x10.x10rt.X10RT.here())));
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$148881 = ((x10.regionarray.Region)
                                                          t$150164);
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final long t$150166 = t$148881.rank;
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150165 = ((x10.regionarray.Region)(this.dist.region));
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final long t$150167 = t$150165.rank;
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final boolean t$150168 = ((long) t$150166) == ((long) t$150167);
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final boolean t$150170 = !(t$150168);
                
                //#line 286 "x10/regionarray/DistArray.x10"
                if (t$150170) {
                    
                    //#line 286 "x10/regionarray/DistArray.x10"
                    final x10.lang.FailedDynamicCheckException t$150169 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==dist.region.rank}");
                    
                    //#line 286 "x10/regionarray/DistArray.x10"
                    throw t$150169;
                }
                
                //#line 286 "x10/regionarray/DistArray.x10"
                localRegion = ((x10.regionarray.Region)(t$148881));
            } else {
                
                //#line 288 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150171 = ((x10.regionarray.Region)(this.dist.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 288 "x10/regionarray/DistArray.x10"
                localRegion = ((x10.regionarray.Region)(t$150171));
            }
            
            //#line 290 "x10/regionarray/DistArray.x10"
            final long t$150173 = localRegion.size$O();
            
            //#line 290 "x10/regionarray/DistArray.x10"
            final x10.core.Rail localRaw = ((x10.core.Rail)(new x10.core.Rail<$T>($T, t$150173, this.init, (x10.core.Rail.__1x10$lang$Rail$$T) null)));
            
            //#line 291 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState alloc$149727 = ((x10.regionarray.DistArray.LocalState)(new x10.regionarray.DistArray.LocalState<$T>((java.lang.System[]) null, $T)));
            
            //#line 291 "x10/regionarray/DistArray.x10"
            alloc$149727.x10$regionarray$DistArray$LocalState$$init$S(this.dist, ((x10.core.Rail)(localRaw)), ((x10.regionarray.Region)(localRegion)), ((x10.regionarray.GhostManager)(ghostManager)), (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
            
            //#line 291 "x10/regionarray/DistArray.x10"
            return alloc$149727;
        }
        
        public x10.regionarray.Dist dist;
        public long ghostWidth;
        public boolean periodic;
        public $T init;
        
        public $Closure$181(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final long ghostWidth, final boolean periodic, final $T init, __3x10$regionarray$DistArray$$Closure$181$$T $dummy) {
            x10.regionarray.DistArray.$Closure$181.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$181<$T>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$181<$T>)this).ghostWidth = ghostWidth;
                ((x10.regionarray.DistArray.$Closure$181<$T>)this).periodic = periodic;
                ((x10.regionarray.DistArray.$Closure$181<$T>)this).init = (($T)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$182<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$182> $RTT = 
            x10.rtt.StaticFunType.<$Closure$182> make($Closure$182.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$182<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.a = $deserializer.readObject();
            $_obj.d = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$182 $_obj = new x10.regionarray.DistArray.$Closure$182((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.a);
            $serializer.write(this.d);
            
        }
        
        // constructor just for allocation
        public $Closure$182(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$182.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.regionarray.DistArray.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$182 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$182$$T$2 {}
        
    
        
        public x10.regionarray.DistArray.LocalState $apply() {
            
            //#line 313 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceLocalHandle t$150179 = ((x10.lang.PlaceLocalHandle)(((x10.regionarray.DistArray<$T>)this.a).localHandle));
            
            //#line 313 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState local = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$150179).$apply$G()));
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState alloc$149728 = ((x10.regionarray.DistArray.LocalState)(new x10.regionarray.DistArray.LocalState<$T>((java.lang.System[]) null, $T)));
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final x10.core.Rail t$150699 = ((x10.core.Rail)(((x10.regionarray.DistArray.LocalState<$T>)local).data));
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150700 = ((x10.regionarray.Region)(((x10.regionarray.DistArray.LocalState<$T>)local).localRegion));
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150701 = ((x10.regionarray.Region)
                                                      t$150700);
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final long t$150702 = t$150701.rank;
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150703 = ((x10.regionarray.Region)(this.d.region));
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final long t$150704 = t$150703.rank;
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final boolean t$150705 = ((long) t$150702) == ((long) t$150704);
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final boolean t$150706 = !(t$150705);
            
            //#line 314 "x10/regionarray/DistArray.x10"
            if (t$150706) {
                
                //#line 314 "x10/regionarray/DistArray.x10"
                final x10.lang.FailedDynamicCheckException t$150707 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==d.region.rank}");
                
                //#line 314 "x10/regionarray/DistArray.x10"
                throw t$150707;
            }
            
            //#line 314 "x10/regionarray/DistArray.x10"
            alloc$149728.x10$regionarray$DistArray$LocalState$$init$S(this.d, ((x10.core.Rail)(t$150699)), ((x10.regionarray.Region)(t$150701)), ((x10.regionarray.GhostManager)(null)), (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
            
            //#line 314 "x10/regionarray/DistArray.x10"
            return alloc$149728;
        }
        
        public x10.regionarray.DistArray<$T> a;
        public x10.regionarray.Dist d;
        
        public $Closure$182(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> a, final x10.regionarray.Dist d, __0$1x10$regionarray$DistArray$$Closure$182$$T$2 $dummy) {
            x10.regionarray.DistArray.$Closure$182.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$182<$T>)this).a = ((x10.regionarray.DistArray)(a));
                ((x10.regionarray.DistArray.$Closure$182<$T>)this).d = ((x10.regionarray.Dist)(d));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$183<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$183> $RTT = 
            x10.rtt.StaticFunType.<$Closure$183> make($Closure$183.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$183<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.regionHere = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$183 $_obj = new x10.regionarray.DistArray.$Closure$183((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.regionHere);
            
        }
        
        // constructor just for allocation
        public $Closure$183(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$183.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$183 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public long $apply$O(final long i) {
            
            //#line 707 "x10/regionarray/DistArray.x10"
            final long t$150343 = this.regionHere.max$O((long)(i));
            
            //#line 707 "x10/regionarray/DistArray.x10"
            final long t$150344 = this.regionHere.min$O((long)(i));
            
            //#line 707 "x10/regionarray/DistArray.x10"
            final long t$150345 = ((t$150343) - (((long)(t$150344))));
            
            //#line 707 "x10/regionarray/DistArray.x10"
            final long t$150346 = ((t$150345) + (((long)(1L))));
            
            //#line 707 "x10/regionarray/DistArray.x10"
            return t$150346;
        }
        
        public x10.regionarray.Region regionHere;
        
        public $Closure$183(final x10.rtt.Type $T, final x10.regionarray.Region regionHere) {
            x10.regionarray.DistArray.$Closure$183.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$183<$T>)this).regionHere = ((x10.regionarray.Region)(regionHere));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$184<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$184> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$184> make($Closure$184.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$184<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.v = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$184 $_obj = new x10.regionarray.DistArray.$Closure$184((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.dist);
            $serializer.write(this.out$$);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$184(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$184.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$184 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$184$$T$2__2x10$regionarray$DistArray$$Closure$184$$T {}
        
    
        
        public void $apply() {
            
            //#line 727 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 728 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$150769 = ((x10.regionarray.Dist)(this.dist));
                
                //#line 728 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region reg$150770 = ((x10.regionarray.Region)(t$150769.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 729 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150771 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 729 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region localRegion$150772 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150771).localRegion));
                
                //#line 730 "x10/regionarray/DistArray.x10"
                final x10.core.Rail rail$150773 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this.out$$).raw));
                
                //#line 731 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator pt$150766 = reg$150770.iterator();
                
                //#line 731 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 731 "x10/regionarray/DistArray.x10"
                    final boolean t$150767 = ((x10.lang.Iterator<x10.lang.Point>)pt$150766).hasNext$O();
                    
                    //#line 731 "x10/regionarray/DistArray.x10"
                    if (!(t$150767)) {
                        
                        //#line 731 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 731 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point pt$150764 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$150766).next$G()));
                    
                    //#line 732 "x10/regionarray/DistArray.x10"
                    final long t$150765 = localRegion$150772.indexOf$O(((x10.lang.Point)(pt$150764)));
                    
                    //#line 732 "x10/regionarray/DistArray.x10"
                    ((x10.core.Rail<$T>)rail$150773).$set__1x10$lang$Rail$$T$G((long)(t$150765), (($T)(this.v)));
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 727 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 727 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public $T v;
        
        public $Closure$184(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final $T v, __0$1x10$regionarray$DistArray$$Closure$184$$T$2__2x10$regionarray$DistArray$$Closure$184$$T $dummy) {
            x10.regionarray.DistArray.$Closure$184.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$184<$T>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$184<$T>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$184<$T>)this).v = (($T)(v));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$185<$T, $U> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$185> $RTT = 
            x10.rtt.StaticFunType.<$Closure$185> make($Closure$185.class,
                                                      2,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(1)))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$185<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$185 $_obj = new x10.regionarray.DistArray.$Closure$185((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$185(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$185.$initParams(this, $T, $U);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.regionarray.DistArray.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$185 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$185$$T$2__2$1x10$regionarray$DistArray$$Closure$185$$T$3x10$regionarray$DistArray$$Closure$185$$U$2 {}
        
    
        
        public x10.regionarray.DistArray.LocalState $apply() {
            
            //#line 751 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150012 = ((x10.regionarray.DistArray)(this.out$$));
            
            //#line 751 "x10/regionarray/DistArray.x10"
            final x10.core.Rail srcRail = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150012).raw));
            
            //#line 752 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150014 = ((x10.regionarray.DistArray)(this.out$$));
            
            //#line 752 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region localRegion = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150014).localRegion));
            
            //#line 753 "x10/regionarray/DistArray.x10"
            final long t$150404 = localRegion.size$O();
            
            //#line 753 "x10/regionarray/DistArray.x10"
            final x10.core.Rail newRail = ((x10.core.Rail)(x10.core.Rail.<$U>makeUnsafe($U, ((long)(t$150404)), false)));
            
            //#line 754 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$150405 = ((x10.regionarray.Dist)(this.dist));
            
            //#line 754 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region reg = ((x10.regionarray.Region)(t$150405.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
            
            //#line 755 "x10/regionarray/DistArray.x10"
            final x10.lang.Iterator pt$150778 = reg.iterator();
            
            //#line 755 "x10/regionarray/DistArray.x10"
            for (;
                 true;
                 ) {
                
                //#line 755 "x10/regionarray/DistArray.x10"
                final boolean t$150779 = ((x10.lang.Iterator<x10.lang.Point>)pt$150778).hasNext$O();
                
                //#line 755 "x10/regionarray/DistArray.x10"
                if (!(t$150779)) {
                    
                    //#line 755 "x10/regionarray/DistArray.x10"
                    break;
                }
                
                //#line 755 "x10/regionarray/DistArray.x10"
                final x10.lang.Point pt$150774 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$150778).next$G()));
                
                //#line 756 "x10/regionarray/DistArray.x10"
                final long offset$150775 = localRegion.indexOf$O(((x10.lang.Point)(pt$150774)));
                
                //#line 757 "x10/regionarray/DistArray.x10"
                final $T t$150776 = (($T)(((x10.core.Rail<$T>)srcRail).$apply$G((long)(offset$150775))));
                
                //#line 757 "x10/regionarray/DistArray.x10"
                final $U t$150777 = (($U)((($U)
                                            ((x10.core.fun.Fun_0_1<$T,$U>)this.op).$apply(t$150776, $T))));
                
                //#line 757 "x10/regionarray/DistArray.x10"
                ((x10.core.Rail<$U>)newRail).$set__1x10$lang$Rail$$T$G((long)(offset$150775), (($U)(t$150777)));
            }
            
            //#line 759 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState alloc$149731 = ((x10.regionarray.DistArray.LocalState)(new x10.regionarray.DistArray.LocalState<$U>((java.lang.System[]) null, $U)));
            
            //#line 759 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$150780 = ((x10.regionarray.Dist)(this.dist));
            
            //#line 759 "x10/regionarray/DistArray.x10"
            alloc$149731.x10$regionarray$DistArray$LocalState$$init$S(((x10.regionarray.Dist)(t$150780)), ((x10.core.Rail)(newRail)), (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
            
            //#line 759 "x10/regionarray/DistArray.x10"
            return alloc$149731;
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public x10.core.fun.Fun_0_1<$T,$U> op;
        
        public $Closure$185(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final x10.core.fun.Fun_0_1<$T,$U> op, __0$1x10$regionarray$DistArray$$Closure$185$$T$2__2$1x10$regionarray$DistArray$$Closure$185$$T$3x10$regionarray$DistArray$$Closure$185$$U$2 $dummy) {
            x10.regionarray.DistArray.$Closure$185.$initParams(this, $T, $U);
             {
                ((x10.regionarray.DistArray.$Closure$185<$T, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$185<$T, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$185<$T, $U>)this).op = ((x10.core.fun.Fun_0_1)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$186<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$186> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$186> make($Closure$186.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$186<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.dst = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$186 $_obj = new x10.regionarray.DistArray.$Closure$186((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.dst);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$186(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$186.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$186 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$186$$T$2__2$1x10$regionarray$DistArray$$Closure$186$$U$2__3$1x10$regionarray$DistArray$$Closure$186$$T$3x10$regionarray$DistArray$$Closure$186$$U$2 {}
        
    
        
        public void $apply() {
            
            //#line 777 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 778 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$150789 = ((x10.regionarray.Dist)(this.dist));
                
                //#line 778 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region reg$150790 = ((x10.regionarray.Region)(t$150789.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 779 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150791 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 779 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region localRegion$150792 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150791).localRegion));
                
                //#line 780 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150793 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 780 "x10/regionarray/DistArray.x10"
                final x10.core.Rail srcRail$150794 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150793).raw));
                
                //#line 781 "x10/regionarray/DistArray.x10"
                final x10.core.Rail dstRail$150795 = ((x10.core.Rail)(((x10.regionarray.DistArray<$U>)this.dst).raw));
                
                //#line 782 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator pt$150786 = reg$150790.iterator();
                
                //#line 782 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 782 "x10/regionarray/DistArray.x10"
                    final boolean t$150787 = ((x10.lang.Iterator<x10.lang.Point>)pt$150786).hasNext$O();
                    
                    //#line 782 "x10/regionarray/DistArray.x10"
                    if (!(t$150787)) {
                        
                        //#line 782 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 782 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point pt$150782 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$150786).next$G()));
                    
                    //#line 783 "x10/regionarray/DistArray.x10"
                    final long offset$150783 = localRegion$150792.indexOf$O(((x10.lang.Point)(pt$150782)));
                    
                    //#line 784 "x10/regionarray/DistArray.x10"
                    final $T t$150784 = (($T)(((x10.core.Rail<$T>)srcRail$150794).$apply$G((long)(offset$150783))));
                    
                    //#line 784 "x10/regionarray/DistArray.x10"
                    final $U t$150785 = (($U)((($U)
                                                ((x10.core.fun.Fun_0_1<$T,$U>)this.op).$apply(t$150784, $T))));
                    
                    //#line 784 "x10/regionarray/DistArray.x10"
                    ((x10.core.Rail<$U>)dstRail$150795).$set__1x10$lang$Rail$$T$G((long)(offset$150783), (($U)(t$150785)));
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 777 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 777 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public x10.regionarray.DistArray<$U> dst;
        public x10.core.fun.Fun_0_1<$T,$U> op;
        
        public $Closure$186(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final x10.regionarray.DistArray<$U> dst, final x10.core.fun.Fun_0_1<$T,$U> op, __0$1x10$regionarray$DistArray$$Closure$186$$T$2__2$1x10$regionarray$DistArray$$Closure$186$$U$2__3$1x10$regionarray$DistArray$$Closure$186$$T$3x10$regionarray$DistArray$$Closure$186$$U$2 $dummy) {
            x10.regionarray.DistArray.$Closure$186.$initParams(this, $T, $U);
             {
                ((x10.regionarray.DistArray.$Closure$186<$T, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$186<$T, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$186<$T, $U>)this).dst = ((x10.regionarray.DistArray)(dst));
                ((x10.regionarray.DistArray.$Closure$186<$T, $U>)this).op = ((x10.core.fun.Fun_0_1)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$187<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$187> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$187> make($Closure$187.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$187<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.dst = $deserializer.readObject();
            $_obj.filter = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$187 $_obj = new x10.regionarray.DistArray.$Closure$187((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.dst);
            $serializer.write(this.filter);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$187(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$187.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$187 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$187$$T$2__3$1x10$regionarray$DistArray$$Closure$187$$U$2__4$1x10$regionarray$DistArray$$Closure$187$$T$3x10$regionarray$DistArray$$Closure$187$$U$2 {}
        
    
        
        public void $apply() {
            
            //#line 807 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 808 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$150803 = ((x10.regionarray.Dist)(this.dist));
                
                //#line 808 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region reg$150804 = ((x10.regionarray.Region)(t$150803.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 809 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150805 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 809 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region localRegion$150806 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150805).localRegion));
                
                //#line 810 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region freg$150807 = ((x10.regionarray.Region)(reg$150804.$and(((x10.regionarray.Region)(this.filter)))));
                
                //#line 811 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150808 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 811 "x10/regionarray/DistArray.x10"
                final x10.core.Rail srcRail$150809 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150808).raw));
                
                //#line 812 "x10/regionarray/DistArray.x10"
                final x10.core.Rail dstRail$150810 = ((x10.core.Rail)(((x10.regionarray.DistArray<$U>)this.dst).raw));
                
                //#line 813 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator pt$150800 = freg$150807.iterator();
                
                //#line 813 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 813 "x10/regionarray/DistArray.x10"
                    final boolean t$150801 = ((x10.lang.Iterator<x10.lang.Point>)pt$150800).hasNext$O();
                    
                    //#line 813 "x10/regionarray/DistArray.x10"
                    if (!(t$150801)) {
                        
                        //#line 813 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 813 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point pt$150796 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$150800).next$G()));
                    
                    //#line 814 "x10/regionarray/DistArray.x10"
                    final long offset$150797 = localRegion$150806.indexOf$O(((x10.lang.Point)(pt$150796)));
                    
                    //#line 815 "x10/regionarray/DistArray.x10"
                    final $T t$150798 = (($T)(((x10.core.Rail<$T>)srcRail$150809).$apply$G((long)(offset$150797))));
                    
                    //#line 815 "x10/regionarray/DistArray.x10"
                    final $U t$150799 = (($U)((($U)
                                                ((x10.core.fun.Fun_0_1<$T,$U>)this.op).$apply(t$150798, $T))));
                    
                    //#line 815 "x10/regionarray/DistArray.x10"
                    ((x10.core.Rail<$U>)dstRail$150810).$set__1x10$lang$Rail$$T$G((long)(offset$150797), (($U)(t$150799)));
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 807 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 807 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public x10.regionarray.Region filter;
        public x10.regionarray.DistArray<$U> dst;
        public x10.core.fun.Fun_0_1<$T,$U> op;
        
        public $Closure$187(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final x10.regionarray.Region filter, final x10.regionarray.DistArray<$U> dst, final x10.core.fun.Fun_0_1<$T,$U> op, __0$1x10$regionarray$DistArray$$Closure$187$$T$2__3$1x10$regionarray$DistArray$$Closure$187$$U$2__4$1x10$regionarray$DistArray$$Closure$187$$T$3x10$regionarray$DistArray$$Closure$187$$U$2 $dummy) {
            x10.regionarray.DistArray.$Closure$187.$initParams(this, $T, $U);
             {
                ((x10.regionarray.DistArray.$Closure$187<$T, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$187<$T, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$187<$T, $U>)this).filter = ((x10.regionarray.Region)(filter));
                ((x10.regionarray.DistArray.$Closure$187<$T, $U>)this).dst = ((x10.regionarray.DistArray)(dst));
                ((x10.regionarray.DistArray.$Closure$187<$T, $U>)this).op = ((x10.core.fun.Fun_0_1)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$188<$T, $S, $U> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$188> $RTT = 
            x10.rtt.StaticFunType.<$Closure$188> make($Closure$188.class,
                                                      3,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(1)))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $S; if (i == 2) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $S, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$188<$T, $S, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.src = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$188 $_obj = new x10.regionarray.DistArray.$Closure$188((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$S);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            $serializer.write(this.src);
            
        }
        
        // constructor just for allocation
        public $Closure$188(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$188.$initParams(this, $T, $S, $U);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.regionarray.DistArray.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $S;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$188 $this, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$S = $S;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling for __0$1x10$regionarray$DistArray$$Closure$188$$T$2__1$1x10$regionarray$DistArray$$Closure$188$$U$2__3$1x10$regionarray$DistArray$$Closure$188$$T$3x10$regionarray$DistArray$$Closure$188$$U$3x10$regionarray$DistArray$$Closure$188$$S$2
        public static final class $_3f6666c7 {}
        
    
        
        public x10.regionarray.DistArray.LocalState $apply() {
            
            //#line 837 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150026 = ((x10.regionarray.DistArray)(this.out$$));
            
            //#line 837 "x10/regionarray/DistArray.x10"
            final x10.core.Rail src1Rail = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150026).raw));
            
            //#line 838 "x10/regionarray/DistArray.x10"
            final x10.core.Rail src2Rail = ((x10.core.Rail)(((x10.regionarray.DistArray<$U>)this.src).raw));
            
            //#line 839 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150029 = ((x10.regionarray.DistArray)(this.out$$));
            
            //#line 839 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region localRegion = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150029).localRegion));
            
            //#line 840 "x10/regionarray/DistArray.x10"
            final long t$150433 = localRegion.size$O();
            
            //#line 840 "x10/regionarray/DistArray.x10"
            final x10.core.Rail newRail = ((x10.core.Rail)(x10.core.Rail.<$S>makeUnsafe($S, ((long)(t$150433)), false)));
            
            //#line 841 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$150434 = ((x10.regionarray.Dist)(this.dist));
            
            //#line 841 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region reg = ((x10.regionarray.Region)(t$150434.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
            
            //#line 842 "x10/regionarray/DistArray.x10"
            final x10.lang.Iterator pt$150816 = reg.iterator();
            
            //#line 842 "x10/regionarray/DistArray.x10"
            for (;
                 true;
                 ) {
                
                //#line 842 "x10/regionarray/DistArray.x10"
                final boolean t$150817 = ((x10.lang.Iterator<x10.lang.Point>)pt$150816).hasNext$O();
                
                //#line 842 "x10/regionarray/DistArray.x10"
                if (!(t$150817)) {
                    
                    //#line 842 "x10/regionarray/DistArray.x10"
                    break;
                }
                
                //#line 842 "x10/regionarray/DistArray.x10"
                final x10.lang.Point pt$150811 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$150816).next$G()));
                
                //#line 843 "x10/regionarray/DistArray.x10"
                final long offset$150812 = localRegion.indexOf$O(((x10.lang.Point)(pt$150811)));
                
                //#line 844 "x10/regionarray/DistArray.x10"
                final $T t$150813 = (($T)(((x10.core.Rail<$T>)src1Rail).$apply$G((long)(offset$150812))));
                
                //#line 844 "x10/regionarray/DistArray.x10"
                final $U t$150814 = (($U)(((x10.core.Rail<$U>)src2Rail).$apply$G((long)(offset$150812))));
                
                //#line 844 "x10/regionarray/DistArray.x10"
                final $S t$150815 = (($S)((($S)
                                            ((x10.core.fun.Fun_0_2<$T,$U,$S>)this.op).$apply(t$150813, $T, t$150814, $U))));
                
                //#line 844 "x10/regionarray/DistArray.x10"
                ((x10.core.Rail<$S>)newRail).$set__1x10$lang$Rail$$T$G((long)(offset$150812), (($S)(t$150815)));
            }
            
            //#line 846 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState alloc$149733 = ((x10.regionarray.DistArray.LocalState)(new x10.regionarray.DistArray.LocalState<$S>((java.lang.System[]) null, $S)));
            
            //#line 846 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$150818 = ((x10.regionarray.Dist)(this.dist));
            
            //#line 846 "x10/regionarray/DistArray.x10"
            alloc$149733.x10$regionarray$DistArray$LocalState$$init$S(((x10.regionarray.Dist)(t$150818)), ((x10.core.Rail)(newRail)), (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
            
            //#line 846 "x10/regionarray/DistArray.x10"
            return alloc$149733;
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.DistArray<$U> src;
        public x10.regionarray.Dist dist;
        public x10.core.fun.Fun_0_2<$T,$U,$S> op;
        
        public $Closure$188(final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.DistArray<$U> src, final x10.regionarray.Dist dist, final x10.core.fun.Fun_0_2<$T,$U,$S> op, $_3f6666c7 $dummy) {
            x10.regionarray.DistArray.$Closure$188.$initParams(this, $T, $S, $U);
             {
                ((x10.regionarray.DistArray.$Closure$188<$T, $S, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$188<$T, $S, $U>)this).src = ((x10.regionarray.DistArray)(src));
                ((x10.regionarray.DistArray.$Closure$188<$T, $S, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$188<$T, $S, $U>)this).op = ((x10.core.fun.Fun_0_2)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$189<$T, $S, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$189> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$189> make($Closure$189.class,
                                                          3,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $S; if (i == 2) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $S, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$189<$T, $S, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.dst = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.src = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$189 $_obj = new x10.regionarray.DistArray.$Closure$189((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$S);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.dst);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            $serializer.write(this.src);
            
        }
        
        // constructor just for allocation
        public $Closure$189(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$189.$initParams(this, $T, $S, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $S;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$189 $this, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$S = $S;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling for __0$1x10$regionarray$DistArray$$Closure$189$$T$2__2$1x10$regionarray$DistArray$$Closure$189$$U$2__3$1x10$regionarray$DistArray$$Closure$189$$S$2__4$1x10$regionarray$DistArray$$Closure$189$$T$3x10$regionarray$DistArray$$Closure$189$$U$3x10$regionarray$DistArray$$Closure$189$$S$2
        public static final class $_742f51e1 {}
        
    
        
        public void $apply() {
            
            //#line 865 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 866 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$150828 = ((x10.regionarray.Dist)(this.dist));
                
                //#line 866 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region reg$150829 = ((x10.regionarray.Region)(t$150828.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 867 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150830 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 867 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region localRegion$150831 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150830).localRegion));
                
                //#line 868 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150832 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 868 "x10/regionarray/DistArray.x10"
                final x10.core.Rail src1Rail$150833 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150832).raw));
                
                //#line 869 "x10/regionarray/DistArray.x10"
                final x10.core.Rail src2Rail$150834 = ((x10.core.Rail)(((x10.regionarray.DistArray<$U>)this.src).raw));
                
                //#line 870 "x10/regionarray/DistArray.x10"
                final x10.core.Rail dstRail$150835 = ((x10.core.Rail)(((x10.regionarray.DistArray<$S>)this.dst).raw));
                
                //#line 871 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator pt$150825 = reg$150829.iterator();
                
                //#line 871 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 871 "x10/regionarray/DistArray.x10"
                    final boolean t$150826 = ((x10.lang.Iterator<x10.lang.Point>)pt$150825).hasNext$O();
                    
                    //#line 871 "x10/regionarray/DistArray.x10"
                    if (!(t$150826)) {
                        
                        //#line 871 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 871 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point pt$150820 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$150825).next$G()));
                    
                    //#line 872 "x10/regionarray/DistArray.x10"
                    final long offset$150821 = localRegion$150831.indexOf$O(((x10.lang.Point)(pt$150820)));
                    
                    //#line 873 "x10/regionarray/DistArray.x10"
                    final $T t$150822 = (($T)(((x10.core.Rail<$T>)src1Rail$150833).$apply$G((long)(offset$150821))));
                    
                    //#line 873 "x10/regionarray/DistArray.x10"
                    final $U t$150823 = (($U)(((x10.core.Rail<$U>)src2Rail$150834).$apply$G((long)(offset$150821))));
                    
                    //#line 873 "x10/regionarray/DistArray.x10"
                    final $S t$150824 = (($S)((($S)
                                                ((x10.core.fun.Fun_0_2<$T,$U,$S>)this.op).$apply(t$150822, $T, t$150823, $U))));
                    
                    //#line 873 "x10/regionarray/DistArray.x10"
                    ((x10.core.Rail<$S>)dstRail$150835).$set__1x10$lang$Rail$$T$G((long)(offset$150821), (($S)(t$150824)));
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 865 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 865 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public x10.regionarray.DistArray<$U> src;
        public x10.regionarray.DistArray<$S> dst;
        public x10.core.fun.Fun_0_2<$T,$U,$S> op;
        
        public $Closure$189(final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final x10.regionarray.DistArray<$U> src, final x10.regionarray.DistArray<$S> dst, final x10.core.fun.Fun_0_2<$T,$U,$S> op, $_742f51e1 $dummy) {
            x10.regionarray.DistArray.$Closure$189.$initParams(this, $T, $S, $U);
             {
                ((x10.regionarray.DistArray.$Closure$189<$T, $S, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$189<$T, $S, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$189<$T, $S, $U>)this).src = ((x10.regionarray.DistArray)(src));
                ((x10.regionarray.DistArray.$Closure$189<$T, $S, $U>)this).dst = ((x10.regionarray.DistArray)(dst));
                ((x10.regionarray.DistArray.$Closure$189<$T, $S, $U>)this).op = ((x10.core.fun.Fun_0_2)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$190<$T, $S, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$190> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$190> make($Closure$190.class,
                                                          3,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $S; if (i == 2) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $S, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$190<$T, $S, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.dst = $deserializer.readObject();
            $_obj.filter = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.src = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$190 $_obj = new x10.regionarray.DistArray.$Closure$190((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$S);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.dst);
            $serializer.write(this.filter);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            $serializer.write(this.src);
            
        }
        
        // constructor just for allocation
        public $Closure$190(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$190.$initParams(this, $T, $S, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $S;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$190 $this, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$S = $S;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling for __0$1x10$regionarray$DistArray$$Closure$190$$T$2__3$1x10$regionarray$DistArray$$Closure$190$$U$2__4$1x10$regionarray$DistArray$$Closure$190$$S$2__5$1x10$regionarray$DistArray$$Closure$190$$T$3x10$regionarray$DistArray$$Closure$190$$U$3x10$regionarray$DistArray$$Closure$190$$S$2
        public static final class $_66f10b66 {}
        
    
        
        public void $apply() {
            
            //#line 896 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 897 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$150844 = ((x10.regionarray.Dist)(this.dist));
                
                //#line 897 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region reg$150845 = ((x10.regionarray.Region)(t$150844.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 898 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150846 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 898 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region localRegion$150847 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150846).localRegion));
                
                //#line 899 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region freg$150848 = ((x10.regionarray.Region)(reg$150845.$and(((x10.regionarray.Region)(this.filter)))));
                
                //#line 900 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150849 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 900 "x10/regionarray/DistArray.x10"
                final x10.core.Rail src1Rail$150850 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150849).raw));
                
                //#line 901 "x10/regionarray/DistArray.x10"
                final x10.core.Rail src2Rail$150851 = ((x10.core.Rail)(((x10.regionarray.DistArray<$U>)this.src).raw));
                
                //#line 902 "x10/regionarray/DistArray.x10"
                final x10.core.Rail dstRail$150852 = ((x10.core.Rail)(((x10.regionarray.DistArray<$S>)this.dst).raw));
                
                //#line 903 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator pt$150841 = freg$150848.iterator();
                
                //#line 903 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 903 "x10/regionarray/DistArray.x10"
                    final boolean t$150842 = ((x10.lang.Iterator<x10.lang.Point>)pt$150841).hasNext$O();
                    
                    //#line 903 "x10/regionarray/DistArray.x10"
                    if (!(t$150842)) {
                        
                        //#line 903 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 903 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point pt$150836 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$150841).next$G()));
                    
                    //#line 904 "x10/regionarray/DistArray.x10"
                    final long offset$150837 = localRegion$150847.indexOf$O(((x10.lang.Point)(pt$150836)));
                    
                    //#line 905 "x10/regionarray/DistArray.x10"
                    final $T t$150838 = (($T)(((x10.core.Rail<$T>)src1Rail$150850).$apply$G((long)(offset$150837))));
                    
                    //#line 905 "x10/regionarray/DistArray.x10"
                    final $U t$150839 = (($U)(((x10.core.Rail<$U>)src2Rail$150851).$apply$G((long)(offset$150837))));
                    
                    //#line 905 "x10/regionarray/DistArray.x10"
                    final $S t$150840 = (($S)((($S)
                                                ((x10.core.fun.Fun_0_2<$T,$U,$S>)this.op).$apply(t$150838, $T, t$150839, $U))));
                    
                    //#line 905 "x10/regionarray/DistArray.x10"
                    ((x10.core.Rail<$S>)dstRail$150852).$set__1x10$lang$Rail$$T$G((long)(offset$150837), (($S)(t$150840)));
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 896 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 896 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public x10.regionarray.Region filter;
        public x10.regionarray.DistArray<$U> src;
        public x10.regionarray.DistArray<$S> dst;
        public x10.core.fun.Fun_0_2<$T,$U,$S> op;
        
        public $Closure$190(final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final x10.regionarray.Region filter, final x10.regionarray.DistArray<$U> src, final x10.regionarray.DistArray<$S> dst, final x10.core.fun.Fun_0_2<$T,$U,$S> op, $_66f10b66 $dummy) {
            x10.regionarray.DistArray.$Closure$190.$initParams(this, $T, $S, $U);
             {
                ((x10.regionarray.DistArray.$Closure$190<$T, $S, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$190<$T, $S, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$190<$T, $S, $U>)this).filter = ((x10.regionarray.Region)(filter));
                ((x10.regionarray.DistArray.$Closure$190<$T, $S, $U>)this).src = ((x10.regionarray.DistArray)(src));
                ((x10.regionarray.DistArray.$Closure$190<$T, $S, $U>)this).dst = ((x10.regionarray.DistArray)(dst));
                ((x10.regionarray.DistArray.$Closure$190<$T, $S, $U>)this).op = ((x10.core.fun.Fun_0_2)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$191<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$191> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$191> make($Closure$191.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$191<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.lop = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.unit = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$191 $_obj = new x10.regionarray.DistArray.$Closure$191((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.lop);
            $serializer.write(this.out$$);
            $serializer.write(this.unit);
            
        }
        
        // constructor just for allocation
        public $Closure$191(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$191.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$191 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$191$$T$2__2x10$regionarray$DistArray$$Closure$191$$U__3$1x10$regionarray$DistArray$$Closure$191$$U$3x10$regionarray$DistArray$$Closure$191$$T$3x10$regionarray$DistArray$$Closure$191$$U$2 {}
        
    
        
        public void $apply() {
            
            //#line 947 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 948 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$150861 = ((x10.regionarray.Dist)(this.dist));
                
                //#line 948 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region reg$150862 = ((x10.regionarray.Region)(t$150861.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 949 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150863 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 949 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region localRegion$150864 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150863).localRegion));
                
                //#line 950 "x10/regionarray/DistArray.x10"
                $U localRes$150865 = (($U)(this.unit));
                
                //#line 951 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150866 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 951 "x10/regionarray/DistArray.x10"
                final x10.core.Rail rail$150867 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150866).raw));
                
                //#line 952 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator pt$150858 = reg$150862.iterator();
                
                //#line 952 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 952 "x10/regionarray/DistArray.x10"
                    final boolean t$150859 = ((x10.lang.Iterator<x10.lang.Point>)pt$150858).hasNext$O();
                    
                    //#line 952 "x10/regionarray/DistArray.x10"
                    if (!(t$150859)) {
                        
                        //#line 952 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 952 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point pt$150853 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$150858).next$G()));
                    
                    //#line 953 "x10/regionarray/DistArray.x10"
                    final long t$150855 = localRegion$150864.indexOf$O(((x10.lang.Point)(pt$150853)));
                    
                    //#line 953 "x10/regionarray/DistArray.x10"
                    final $T t$150856 = (($T)(((x10.core.Rail<$T>)rail$150867).$apply$G((long)(t$150855))));
                    
                    //#line 953 "x10/regionarray/DistArray.x10"
                    final $U t$150857 = (($U)((($U)
                                                ((x10.core.fun.Fun_0_2<$U,$T,$U>)this.lop).$apply(localRes$150865, $U, t$150856, $T))));
                    
                    //#line 953 "x10/regionarray/DistArray.x10"
                    localRes$150865 = (($U)(t$150857));
                }
                
                //#line 955 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.<$U> makeOffer__0x10$xrx$Runtime$$T($U, (($U)(localRes$150865)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 947 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 947 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public $U unit;
        public x10.core.fun.Fun_0_2<$U,$T,$U> lop;
        
        public $Closure$191(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final $U unit, final x10.core.fun.Fun_0_2<$U,$T,$U> lop, __0$1x10$regionarray$DistArray$$Closure$191$$T$2__2x10$regionarray$DistArray$$Closure$191$$U__3$1x10$regionarray$DistArray$$Closure$191$$U$3x10$regionarray$DistArray$$Closure$191$$T$3x10$regionarray$DistArray$$Closure$191$$U$2 $dummy) {
            x10.regionarray.DistArray.$Closure$191.$initParams(this, $T, $U);
             {
                ((x10.regionarray.DistArray.$Closure$191<$T, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$191<$T, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$191<$T, $U>)this).unit = (($U)(unit));
                ((x10.regionarray.DistArray.$Closure$191<$T, $U>)this).lop = ((x10.core.fun.Fun_0_2)(lop));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$192<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$192> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$192> make($Closure$192.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$192<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.localHandle = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$192 $_obj = new x10.regionarray.DistArray.$Closure$192((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.localHandle);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$192(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$192.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$192 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$192$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$192$$T$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 969 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 970 "x10/regionarray/DistArray.x10"
                final x10.lang.PlaceLocalHandle t$150482 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
                
                //#line 970 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray.LocalState t$150483 = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$150482).$apply$G()));
                
                //#line 970 "x10/regionarray/DistArray.x10"
                final x10.regionarray.GhostManager ghostManager = ((x10.regionarray.GhostManager)(((x10.regionarray.DistArray.LocalState<$T>)t$150483).ghostManager));
                
                //#line 971 "x10/regionarray/DistArray.x10"
                ghostManager.sendGhosts(((x10.regionarray.Ghostable)(this.out$$)));
                
                //#line 972 "x10/regionarray/DistArray.x10"
                ghostManager.waitOnGhosts();
            }}catch (java.lang.Error __lowerer__var__1__) {
                
                //#line 969 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__1__;
            }catch (java.lang.Throwable __lowerer__var__2__) {
                
                //#line 969 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__2__) ? (java.lang.RuntimeException)(__lowerer__var__2__) : new x10.lang.WrappedThrowable(__lowerer__var__2__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle;
        
        public $Closure$192(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> out$$, final x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle, __0$1x10$regionarray$DistArray$$Closure$192$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$192$$T$2$2 $dummy) {
            x10.regionarray.DistArray.$Closure$192.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$192<$T>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$192<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(localHandle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$193<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$193> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$193> make($Closure$193.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$193<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.__lowerer__var__0__ = $deserializer.readObject();
            $_obj.localHandle = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$193 $_obj = new x10.regionarray.DistArray.$Closure$193((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.__lowerer__var__0__);
            $serializer.write(this.localHandle);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$193(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$193.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$193 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$193$$T$2__2$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$193$$T$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 969 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 969 "x10/regionarray/DistArray.x10"
                for (
                     //#line 969 "x10/regionarray/DistArray.x10"
                     final x10.lang.Iterator place$151018 = this.__lowerer__var__0__.restriction(((x10.lang.Place)(x10.x10rt.X10RT.here()))).region.iterator();
                     ((x10.lang.Iterator<x10.lang.Point>)place$151018).hasNext$O();
                     ) {
                    
                    //#line 969 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point place = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)place$151018).next$G()));
                    
                    //#line 969 "x10/regionarray/DistArray.x10"
                    x10.xrx.Runtime.runAsync(((x10.lang.Place)(x10.x10rt.X10RT.here())), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$192<$T>($T, ((x10.regionarray.DistArray)(this.out$$)), ((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)(this.localHandle)), (x10.regionarray.DistArray.$Closure$192.__0$1x10$regionarray$DistArray$$Closure$192$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$192$$T$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                }
            }}catch (java.lang.Error __lowerer__var__4__) {
                
                //#line 969 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__4__;
            }catch (java.lang.Throwable __lowerer__var__5__) {
                
                //#line 969 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__5__) ? (java.lang.RuntimeException)(__lowerer__var__5__) : new x10.lang.WrappedThrowable(__lowerer__var__5__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist __lowerer__var__0__;
        public x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle;
        
        public $Closure$193(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist __lowerer__var__0__, final x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle, __0$1x10$regionarray$DistArray$$Closure$193$$T$2__2$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$193$$T$2$2 $dummy) {
            x10.regionarray.DistArray.$Closure$193.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$193<$T>)this).out$$ = ((x10.regionarray.DistArray)(out$$));
                ((x10.regionarray.DistArray.$Closure$193<$T>)this).__lowerer__var__0__ = ((x10.regionarray.Dist)(__lowerer__var__0__));
                ((x10.regionarray.DistArray.$Closure$193<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(localHandle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$194<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$194> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$194> make($Closure$194.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$194<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.localHandle = $deserializer.readObject();
            $_obj.neighborPortion = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.phase = $deserializer.readByte();
            $_obj.shift = $deserializer.readObject();
            $_obj.sourcePlace = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$194 $_obj = new x10.regionarray.DistArray.$Closure$194((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.localHandle);
            $serializer.write(this.neighborPortion);
            $serializer.write(this.out$$);
            $serializer.write(this.phase);
            $serializer.write(this.shift);
            $serializer.write(this.sourcePlace);
            
        }
        
        // constructor just for allocation
        public $Closure$194(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$194.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$194 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$194$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$194$$T$2$2__3$1x10$regionarray$DistArray$$Closure$194$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 1014 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 1015 "x10/regionarray/DistArray.x10"
                final x10.lang.PlaceLocalHandle t$150541 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
                
                //#line 1015 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray.LocalState t$150542 = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$150541).$apply$G()));
                
                //#line 1015 "x10/regionarray/DistArray.x10"
                final x10.regionarray.GhostManager ghostManager = ((x10.regionarray.GhostManager)(((x10.regionarray.DistArray.LocalState<$T>)t$150542).ghostManager));
                {
                    
                    //#line 1016 "x10/regionarray/DistArray.x10"
                    x10.xrx.Runtime.ensureNotInAtomic();
                    
                    //#line 1016 "x10/regionarray/DistArray.x10"
                    try {{
                        
                        //#line 1016 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.enterAtomic();
                        
                        //#line 1016 "x10/regionarray/DistArray.x10"
                        while (true) {
                            
                            //#line 1016 "x10/regionarray/DistArray.x10"
                            if (((byte) ghostManager.currentPhase$O()) == ((byte) this.phase)) {
                                {
                                    
                                }
                                
                                //#line 1016 "x10/regionarray/DistArray.x10"
                                break;
                            }
                            
                            //#line 1016 "x10/regionarray/DistArray.x10"
                            x10.xrx.Runtime.awaitAtomic();
                        }
                    }}finally {{
                          
                          //#line 1016 "x10/regionarray/DistArray.x10"
                          x10.xrx.Runtime.exitAtomic();
                      }}
                    }
                
                //#line 1017 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Array local2 = ((x10.regionarray.Array)(((x10.regionarray.Array<$T>)
                                                                                ((x10.regionarray.DistArray<$T>)this.out$$).getLocalPortion())));
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150543 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this.neighborPortion).region));
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$149072 = ((x10.regionarray.Region)
                                                          t$150543);
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                final boolean t$150544 = t$149072.rect;
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                boolean t$150549 = ((boolean) t$150544) == ((boolean) true);
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                if (t$150549) {
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    final long t$150547 = t$149072.rank;
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$150545 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this.out$$).dist));
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Region t$150546 = ((x10.regionarray.Region)(t$150545.region));
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    final long t$150548 = t$150546.rank;
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    t$150549 = ((long) t$150547) == ((long) t$150548);
                }
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                final boolean t$150552 = !(t$150549);
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                if (t$150552) {
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    final x10.lang.FailedDynamicCheckException t$150551 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==this(:x10.regionarray.DistArray).dist.region.rank}");
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    throw t$150551;
                }
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.Array<$T>)local2).copy__0$1x10$regionarray$Array$$T$2(((x10.regionarray.Array)(this.neighborPortion)), ((x10.regionarray.Region)(t$149072)));
                
                //#line 1019 "x10/regionarray/DistArray.x10"
                final x10.lang.Point t$150553 = ((x10.lang.Point)(this.shift.$minus()));
                
                //#line 1019 "x10/regionarray/DistArray.x10"
                ghostManager.setNeighborReceived(((x10.lang.Place)(this.sourcePlace)), ((x10.lang.Point)(t$150553)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 1014 "x10/regionarray/DistArray.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 1014 "x10/regionarray/DistArray.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle;
        public byte phase;
        public x10.regionarray.Array<$T> neighborPortion;
        public x10.lang.Point shift;
        public x10.lang.Place sourcePlace;
        
        public $Closure$194(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> out$$, final x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle, final byte phase, final x10.regionarray.Array<$T> neighborPortion, final x10.lang.Point shift, final x10.lang.Place sourcePlace, __0$1x10$regionarray$DistArray$$Closure$194$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$194$$T$2$2__3$1x10$regionarray$DistArray$$Closure$194$$T$2 $dummy) {
            x10.regionarray.DistArray.$Closure$194.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$194<$T>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$194<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(localHandle));
                ((x10.regionarray.DistArray.$Closure$194<$T>)this).phase = phase;
                ((x10.regionarray.DistArray.$Closure$194<$T>)this).neighborPortion = ((x10.regionarray.Array)(neighborPortion));
                ((x10.regionarray.DistArray.$Closure$194<$T>)this).shift = ((x10.lang.Point)(shift));
                ((x10.regionarray.DistArray.$Closure$194<$T>)this).sourcePlace = ((x10.lang.Place)(sourcePlace));
            }
        }
        
        }
        
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$195<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$195> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$195> make($Closure$195.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$195<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.localHandle = $deserializer.readObject();
            $_obj.neighborPortion = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.phase = $deserializer.readByte();
            $_obj.shift = $deserializer.readObject();
            $_obj.sourcePlace = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$195 $_obj = new x10.regionarray.DistArray.$Closure$195((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.localHandle);
            $serializer.write(this.neighborPortion);
            $serializer.write(this.out$$);
            $serializer.write(this.phase);
            $serializer.write(this.shift);
            $serializer.write(this.sourcePlace);
            
        }
        
        // constructor just for allocation
        public $Closure$195(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$195.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$195 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$195$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$195$$T$2$2__3$1x10$regionarray$DistArray$$Closure$195$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 1037 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 1038 "x10/regionarray/DistArray.x10"
                final x10.lang.PlaceLocalHandle t$150609 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
                
                //#line 1038 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray.LocalState t$150610 = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$150609).$apply$G()));
                
                //#line 1038 "x10/regionarray/DistArray.x10"
                final x10.regionarray.GhostManager ghostManager = ((x10.regionarray.GhostManager)(((x10.regionarray.DistArray.LocalState<$T>)t$150610).ghostManager));
                {
                    
                    //#line 1039 "x10/regionarray/DistArray.x10"
                    x10.xrx.Runtime.ensureNotInAtomic();
                    
                    //#line 1039 "x10/regionarray/DistArray.x10"
                    try {{
                        
                        //#line 1039 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.enterAtomic();
                        
                        //#line 1039 "x10/regionarray/DistArray.x10"
                        while (true) {
                            
                            //#line 1039 "x10/regionarray/DistArray.x10"
                            if (((byte) ghostManager.currentPhase$O()) == ((byte) this.phase)) {
                                {
                                    
                                }
                                
                                //#line 1039 "x10/regionarray/DistArray.x10"
                                break;
                            }
                            
                            //#line 1039 "x10/regionarray/DistArray.x10"
                            x10.xrx.Runtime.awaitAtomic();
                        }
                    }}finally {{
                          
                          //#line 1039 "x10/regionarray/DistArray.x10"
                          x10.xrx.Runtime.exitAtomic();
                      }}
                    }
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Array t$150611 = ((x10.regionarray.Array)(((x10.regionarray.Array<$T>)
                                                                                  ((x10.regionarray.DistArray<$T>)this.out$$).getLocalPortion())));
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Array t$149087 = ((x10.regionarray.Array<$T>)
                                                         t$150611);
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                final boolean t$150612 = ((x10.regionarray.Array<$T>)t$149087).rect;
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                boolean t$150614 = ((boolean) t$150612) == ((boolean) true);
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                if (t$150614) {
                    
                    //#line 1040 "x10/regionarray/DistArray.x10"
                    final long t$150613 = ((x10.regionarray.Array<$T>)t$149087).rank;
                    
                    //#line 1040 "x10/regionarray/DistArray.x10"
                    t$150614 = ((long) t$150613) == ((long) 3L);
                }
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                final boolean t$150617 = !(t$150614);
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                if (t$150617) {
                    
                    //#line 1040 "x10/regionarray/DistArray.x10"
                    final x10.lang.FailedDynamicCheckException t$150616 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Array[T]{self.rect==true, self.rank==3L}");
                    
                    //#line 1040 "x10/regionarray/DistArray.x10"
                    throw t$150616;
                }
                
                //#line 1041 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150618 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this.neighborPortion).region));
                
                //#line 1041 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.Array<$T>)t$149087).copy__0$1x10$regionarray$Array$$T$2(((x10.regionarray.Array)(this.neighborPortion)), ((x10.regionarray.Region)(t$150618)));
                
                //#line 1042 "x10/regionarray/DistArray.x10"
                final x10.lang.Point t$150619 = ((x10.lang.Point)(this.shift.$minus()));
                
                //#line 1042 "x10/regionarray/DistArray.x10"
                ghostManager.setNeighborReceived(((x10.lang.Place)(this.sourcePlace)), ((x10.lang.Point)(t$150619)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 1037 "x10/regionarray/DistArray.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 1037 "x10/regionarray/DistArray.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle;
        public byte phase;
        public x10.regionarray.Array<$T> neighborPortion;
        public x10.lang.Point shift;
        public x10.lang.Place sourcePlace;
        
        public $Closure$195(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> out$$, final x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle, final byte phase, final x10.regionarray.Array<$T> neighborPortion, final x10.lang.Point shift, final x10.lang.Place sourcePlace, __0$1x10$regionarray$DistArray$$Closure$195$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$195$$T$2$2__3$1x10$regionarray$DistArray$$Closure$195$$T$2 $dummy) {
            x10.regionarray.DistArray.$Closure$195.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$195<$T>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$195<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(localHandle));
                ((x10.regionarray.DistArray.$Closure$195<$T>)this).phase = phase;
                ((x10.regionarray.DistArray.$Closure$195<$T>)this).neighborPortion = ((x10.regionarray.Array)(neighborPortion));
                ((x10.regionarray.DistArray.$Closure$195<$T>)this).shift = ((x10.lang.Point)(shift));
                ((x10.regionarray.DistArray.$Closure$195<$T>)this).sourcePlace = ((x10.lang.Place)(sourcePlace));
            }
        }
        
        }
        
    }
    
    
    
    
    
    