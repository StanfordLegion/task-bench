package x10.regionarray;


/**
 * A RectRegion is a finite dense rectangular region with a specified rank.
 * This class implements a specialization of PolyRegion.
 */
@x10.runtime.impl.java.X10Generated
final public class RectRegion extends x10.regionarray.Region implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<RectRegion> $RTT = 
        x10.rtt.NamedType.<RectRegion> make("x10.regionarray.RectRegion",
                                            RectRegion.class,
                                            new x10.rtt.Type[] {
                                                x10.regionarray.Region.$RTT
                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Region.$_deserialize_body($_obj, $deserializer);
        $_obj.max0 = $deserializer.readLong();
        $_obj.max1 = $deserializer.readLong();
        $_obj.max2 = $deserializer.readLong();
        $_obj.max3 = $deserializer.readLong();
        $_obj.maxs = $deserializer.readObject();
        $_obj.min0 = $deserializer.readLong();
        $_obj.min1 = $deserializer.readLong();
        $_obj.min2 = $deserializer.readLong();
        $_obj.min3 = $deserializer.readLong();
        $_obj.mins = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.RectRegion $_obj = new x10.regionarray.RectRegion((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.max0);
        $serializer.write(this.max1);
        $serializer.write(this.max2);
        $serializer.write(this.max3);
        $serializer.write(this.maxs);
        $serializer.write(this.min0);
        $serializer.write(this.min1);
        $serializer.write(this.min2);
        $serializer.write(this.min3);
        $serializer.write(this.mins);
        $serializer.write(this.size);
        
    }
    
    // constructor just for allocation
    public RectRegion(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$Long$2__1$1x10$lang$Long$2 {}
    

    
    //#line 23 "x10/regionarray/RectRegion.x10"
    public long size;
    
    //#line 24 "x10/regionarray/RectRegion.x10"
    public x10.core.Rail<x10.core.Long> mins;
    
    //#line 25 "x10/regionarray/RectRegion.x10"
    public x10.core.Rail<x10.core.Long> maxs;
    
    //#line 27 "x10/regionarray/RectRegion.x10"
    public long min0;
    
    //#line 28 "x10/regionarray/RectRegion.x10"
    public long min1;
    
    //#line 29 "x10/regionarray/RectRegion.x10"
    public long min2;
    
    //#line 30 "x10/regionarray/RectRegion.x10"
    public long min3;
    
    //#line 31 "x10/regionarray/RectRegion.x10"
    public long max0;
    
    //#line 32 "x10/regionarray/RectRegion.x10"
    public long max1;
    
    //#line 33 "x10/regionarray/RectRegion.x10"
    public long max2;
    
    //#line 34 "x10/regionarray/RectRegion.x10"
    public long max3;
    
    //#line 37 "x10/regionarray/RectRegion.x10"
    public transient x10.regionarray.Region polyRep;
    
    
    //#line 39 "x10/regionarray/RectRegion.x10"
    private static boolean allZeros__0$1x10$lang$Long$2$O(final x10.core.Rail<x10.core.Long> a) {
        
        //#line 40 "x10/regionarray/RectRegion.x10"
        final long i$145423max$157303 = ((x10.core.Rail<x10.core.Long>)a).size;
        
        //#line 40 "x10/regionarray/RectRegion.x10"
        long i$157299 = 0L;
        {
            
            //#line 40 "x10/regionarray/RectRegion.x10"
            final long[] a$value$157494 = ((long[])a.value);
            
            //#line 40 "x10/regionarray/RectRegion.x10"
            for (;
                 true;
                 ) {
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                final boolean t$157301 = ((i$157299) < (((long)(i$145423max$157303))));
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                if (!(t$157301)) {
                    
                    //#line 40 "x10/regionarray/RectRegion.x10"
                    break;
                }
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                final long t$157294 = ((long)a$value$157494[(int)i$157299]);
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                final boolean t$157295 = ((long) t$157294) != ((long) 0L);
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                if (t$157295) {
                    
                    //#line 40 "x10/regionarray/RectRegion.x10"
                    return false;
                }
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                final long t$157298 = ((i$157299) + (((long)(1L))));
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                i$157299 = t$157298;
            }
        }
        
        //#line 41 "x10/regionarray/RectRegion.x10"
        return true;
    }
    
    public static boolean allZeros$P__0$1x10$lang$Long$2$O(final x10.core.Rail<x10.core.Long> a) {
        return x10.regionarray.RectRegion.allZeros__0$1x10$lang$Long$2$O(((x10.core.Rail)(a)));
    }
    
    
    //#line 47 "x10/regionarray/RectRegion.x10"
    /**
     * Create a rectangular region containing all points p such that min <= p and p <= max.
     */
    // creation method for java code (1-phase java constructor)
    public RectRegion(final x10.core.Rail<x10.core.Long> minArg, final x10.core.Rail<x10.core.Long> maxArg, __0$1x10$lang$Long$2__1$1x10$lang$Long$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$RectRegion$$init$S(minArg, maxArg, (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.RectRegion x10$regionarray$RectRegion$$init$S(final x10.core.Rail<x10.core.Long> minArg, final x10.core.Rail<x10.core.Long> maxArg, __0$1x10$lang$Long$2__1$1x10$lang$Long$2 $dummy) {
         {
            
            //#line 48 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.Region this$156490 = ((x10.regionarray.Region)(this));
            
            //#line 48 "x10/regionarray/RectRegion.x10"
            final long r$156486 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 48 "x10/regionarray/RectRegion.x10"
            final boolean z$156488 = x10.regionarray.RectRegion.allZeros__0$1x10$lang$Long$2$O(((x10.core.Rail)(minArg)));
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$157325 = ((long) r$156486) == ((long) 1L);
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$157325) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$157325 = true;
            }
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$157326 = t$157325;
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$157325) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$157326 = z$156488;
            }
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$156490.rank = r$156486;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$156490.rect = true;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$156490.zeroBased = z$156488;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$156490.rail = t$157326;
            
            //#line 47 "x10/regionarray/RectRegion.x10"
            
            
            //#line 21 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.RectRegion this$157328 = this;
            
            //#line 21 "x10/regionarray/RectRegion.x10"
            this$157328.polyRep = null;
            
            //#line 50 "x10/regionarray/RectRegion.x10"
            final long t$156597 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 50 "x10/regionarray/RectRegion.x10"
            final long t$156598 = ((x10.core.Rail<x10.core.Long>)maxArg).size;
            
            //#line 50 "x10/regionarray/RectRegion.x10"
            final boolean t$156600 = ((long) t$156597) != ((long) t$156598);
            
            //#line 50 "x10/regionarray/RectRegion.x10"
            if (t$156600) {
                
                //#line 50 "x10/regionarray/RectRegion.x10"
                final java.lang.IllegalArgumentException t$156599 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("size of min and max args are not equal")));
                
                //#line 50 "x10/regionarray/RectRegion.x10"
                throw t$156599;
            }
            
            //#line 52 "x10/regionarray/RectRegion.x10"
            long s = 1L;
            
            //#line 53 "x10/regionarray/RectRegion.x10"
            final long i$145442max$157330 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 53 "x10/regionarray/RectRegion.x10"
            long i$157322 = 0L;
            {
                
                //#line 53 "x10/regionarray/RectRegion.x10"
                final long[] maxArg$value$157495 = ((long[])maxArg.value);
                
                //#line 53 "x10/regionarray/RectRegion.x10"
                final long[] minArg$value$157496 = ((long[])minArg.value);
                
                //#line 53 "x10/regionarray/RectRegion.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 53 "x10/regionarray/RectRegion.x10"
                    final boolean t$157324 = ((i$157322) < (((long)(i$145442max$157330))));
                    
                    //#line 53 "x10/regionarray/RectRegion.x10"
                    if (!(t$157324)) {
                        
                        //#line 53 "x10/regionarray/RectRegion.x10"
                        break;
                    }
                    
                    //#line 54 "x10/regionarray/RectRegion.x10"
                    final long t$157304 = ((long)maxArg$value$157495[(int)i$157322]);
                    
                    //#line 54 "x10/regionarray/RectRegion.x10"
                    final long t$157305 = ((long)minArg$value$157496[(int)i$157322]);
                    
                    //#line 54 "x10/regionarray/RectRegion.x10"
                    final long t$157306 = ((t$157304) - (((long)(t$157305))));
                    
                    //#line 54 "x10/regionarray/RectRegion.x10"
                    long rs$157307 = ((t$157306) + (((long)(1L))));
                    
                    //#line 55 "x10/regionarray/RectRegion.x10"
                    final boolean t$157309 = ((rs$157307) < (((long)(0L))));
                    
                    //#line 55 "x10/regionarray/RectRegion.x10"
                    if (t$157309) {
                        
                        //#line 55 "x10/regionarray/RectRegion.x10"
                        rs$157307 = 0L;
                    }
                    
                    //#line 56 "x10/regionarray/RectRegion.x10"
                    final long t$157310 = ((long)maxArg$value$157495[(int)i$157322]);
                    
                    //#line 56 "x10/regionarray/RectRegion.x10"
                    final long t$157311 = java.lang.Long.MAX_VALUE;
                    
                    //#line 56 "x10/regionarray/RectRegion.x10"
                    boolean t$157312 = ((long) t$157310) == ((long) t$157311);
                    
                    //#line 56 "x10/regionarray/RectRegion.x10"
                    if (t$157312) {
                        
                        //#line 56 "x10/regionarray/RectRegion.x10"
                        final long t$157313 = ((long)minArg$value$157496[(int)i$157322]);
                        
                        //#line 56 "x10/regionarray/RectRegion.x10"
                        final long t$157314 = java.lang.Long.MIN_VALUE;
                        
                        //#line 56 "x10/regionarray/RectRegion.x10"
                        t$157312 = ((long) t$157313) == ((long) t$157314);
                    }
                    
                    //#line 56 "x10/regionarray/RectRegion.x10"
                    if (t$157312) {
                        
                        //#line 57 "x10/regionarray/RectRegion.x10"
                        s = -1L;
                        
                        //#line 58 "x10/regionarray/RectRegion.x10"
                        break;
                    }
                    
                    //#line 60 "x10/regionarray/RectRegion.x10"
                    final long t$157318 = ((s) * (((long)(rs$157307))));
                    
                    //#line 60 "x10/regionarray/RectRegion.x10"
                    s = t$157318;
                    
                    //#line 53 "x10/regionarray/RectRegion.x10"
                    final long t$157321 = ((i$157322) + (((long)(1L))));
                    
                    //#line 53 "x10/regionarray/RectRegion.x10"
                    i$157322 = t$157321;
                }
            }
            
            //#line 62 "x10/regionarray/RectRegion.x10"
            this.size = s;
            
            //#line 64 "x10/regionarray/RectRegion.x10"
            final long t$156621 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 64 "x10/regionarray/RectRegion.x10"
            final boolean t$156625 = ((t$156621) > (((long)(0L))));
            
            //#line 64 "x10/regionarray/RectRegion.x10"
            if (t$156625) {
                
                //#line 65 "x10/regionarray/RectRegion.x10"
                final long t$156622 = ((long[])minArg.value)[(int)0L];
                
                //#line 65 "x10/regionarray/RectRegion.x10"
                this.min0 = t$156622;
                
                //#line 66 "x10/regionarray/RectRegion.x10"
                final long t$156623 = ((long[])maxArg.value)[(int)0L];
                
                //#line 66 "x10/regionarray/RectRegion.x10"
                this.max0 = t$156623;
            } else {
                
                //#line 68 "x10/regionarray/RectRegion.x10"
                final long t$156624 = this.max0 = 0L;
                
                //#line 68 "x10/regionarray/RectRegion.x10"
                this.min0 = t$156624;
            }
            
            //#line 71 "x10/regionarray/RectRegion.x10"
            final long t$156626 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 71 "x10/regionarray/RectRegion.x10"
            final boolean t$156630 = ((t$156626) > (((long)(1L))));
            
            //#line 71 "x10/regionarray/RectRegion.x10"
            if (t$156630) {
                
                //#line 72 "x10/regionarray/RectRegion.x10"
                final long t$156627 = ((long[])minArg.value)[(int)1L];
                
                //#line 72 "x10/regionarray/RectRegion.x10"
                this.min1 = t$156627;
                
                //#line 73 "x10/regionarray/RectRegion.x10"
                final long t$156628 = ((long[])maxArg.value)[(int)1L];
                
                //#line 73 "x10/regionarray/RectRegion.x10"
                this.max1 = t$156628;
            } else {
                
                //#line 75 "x10/regionarray/RectRegion.x10"
                final long t$156629 = this.max1 = 0L;
                
                //#line 75 "x10/regionarray/RectRegion.x10"
                this.min1 = t$156629;
            }
            
            //#line 78 "x10/regionarray/RectRegion.x10"
            final long t$156631 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 78 "x10/regionarray/RectRegion.x10"
            final boolean t$156635 = ((t$156631) > (((long)(2L))));
            
            //#line 78 "x10/regionarray/RectRegion.x10"
            if (t$156635) {
                
                //#line 79 "x10/regionarray/RectRegion.x10"
                final long t$156632 = ((long[])minArg.value)[(int)2L];
                
                //#line 79 "x10/regionarray/RectRegion.x10"
                this.min2 = t$156632;
                
                //#line 80 "x10/regionarray/RectRegion.x10"
                final long t$156633 = ((long[])maxArg.value)[(int)2L];
                
                //#line 80 "x10/regionarray/RectRegion.x10"
                this.max2 = t$156633;
            } else {
                
                //#line 82 "x10/regionarray/RectRegion.x10"
                final long t$156634 = this.max2 = 0L;
                
                //#line 82 "x10/regionarray/RectRegion.x10"
                this.min2 = t$156634;
            }
            
            //#line 85 "x10/regionarray/RectRegion.x10"
            final long t$156636 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 85 "x10/regionarray/RectRegion.x10"
            final boolean t$156640 = ((t$156636) > (((long)(3L))));
            
            //#line 85 "x10/regionarray/RectRegion.x10"
            if (t$156640) {
                
                //#line 86 "x10/regionarray/RectRegion.x10"
                final long t$156637 = ((long[])minArg.value)[(int)3L];
                
                //#line 86 "x10/regionarray/RectRegion.x10"
                this.min3 = t$156637;
                
                //#line 87 "x10/regionarray/RectRegion.x10"
                final long t$156638 = ((long[])maxArg.value)[(int)3L];
                
                //#line 87 "x10/regionarray/RectRegion.x10"
                this.max3 = t$156638;
            } else {
                
                //#line 89 "x10/regionarray/RectRegion.x10"
                final long t$156639 = this.max3 = 0L;
                
                //#line 89 "x10/regionarray/RectRegion.x10"
                this.min3 = t$156639;
            }
            
            //#line 92 "x10/regionarray/RectRegion.x10"
            final long t$156641 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 92 "x10/regionarray/RectRegion.x10"
            final boolean t$156642 = ((t$156641) > (((long)(4L))));
            
            //#line 92 "x10/regionarray/RectRegion.x10"
            if (t$156642) {
                
                //#line 93 "x10/regionarray/RectRegion.x10"
                this.mins = ((x10.core.Rail)(minArg));
                
                //#line 94 "x10/regionarray/RectRegion.x10"
                this.maxs = ((x10.core.Rail)(maxArg));
            } else {
                
                //#line 96 "x10/regionarray/RectRegion.x10"
                this.mins = null;
                
                //#line 97 "x10/regionarray/RectRegion.x10"
                this.maxs = null;
            }
        }
        return this;
    }
    
    
    
    //#line 104 "x10/regionarray/RectRegion.x10"
    /**
     * Create a 1-dim region min..max.
     */
    // creation method for java code (1-phase java constructor)
    public RectRegion(final long min, final long max) {
        this((java.lang.System[]) null);
        x10$regionarray$RectRegion$$init$S(min, max);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.RectRegion x10$regionarray$RectRegion$$init$S(final long min, final long max) {
         {
            
            //#line 105 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.Region this$156499 = ((x10.regionarray.Region)(this));
            
            //#line 105 "x10/regionarray/RectRegion.x10"
            final boolean z$156497 = ((long) min) == ((long) 0L);
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$156499.rank = 1L;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$156499.rect = true;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$156499.zeroBased = z$156497;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$156499.rail = z$156497;
            
            //#line 104 "x10/regionarray/RectRegion.x10"
            
            
            //#line 21 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.RectRegion this$157332 = this;
            
            //#line 21 "x10/regionarray/RectRegion.x10"
            this$157332.polyRep = null;
            
            //#line 107 "x10/regionarray/RectRegion.x10"
            final long t$156643 = java.lang.Long.MIN_VALUE;
            
            //#line 107 "x10/regionarray/RectRegion.x10"
            boolean t$156645 = ((long) min) == ((long) t$156643);
            
            //#line 107 "x10/regionarray/RectRegion.x10"
            if (t$156645) {
                
                //#line 107 "x10/regionarray/RectRegion.x10"
                final long t$156644 = java.lang.Long.MAX_VALUE;
                
                //#line 107 "x10/regionarray/RectRegion.x10"
                t$156645 = ((long) max) == ((long) t$156644);
            }
            
            //#line 107 "x10/regionarray/RectRegion.x10"
            long t$156648 =  0;
            
            //#line 107 "x10/regionarray/RectRegion.x10"
            if (t$156645) {
                
                //#line 107 "x10/regionarray/RectRegion.x10"
                t$156648 = -1L;
            } else {
                
                //#line 107 "x10/regionarray/RectRegion.x10"
                final long t$156646 = ((max) - (((long)(min))));
                
                //#line 107 "x10/regionarray/RectRegion.x10"
                t$156648 = ((t$156646) + (((long)(1L))));
            }
            
            //#line 107 "x10/regionarray/RectRegion.x10"
            this.size = t$156648;
            
            //#line 108 "x10/regionarray/RectRegion.x10"
            this.min0 = min;
            
            //#line 109 "x10/regionarray/RectRegion.x10"
            this.max0 = max;
            
            //#line 111 "x10/regionarray/RectRegion.x10"
            final long t$156650 = this.min3 = 0L;
            
            //#line 111 "x10/regionarray/RectRegion.x10"
            final long t$156651 = this.min2 = t$156650;
            
            //#line 111 "x10/regionarray/RectRegion.x10"
            this.min1 = t$156651;
            
            //#line 112 "x10/regionarray/RectRegion.x10"
            final long t$156652 = this.max3 = 0L;
            
            //#line 112 "x10/regionarray/RectRegion.x10"
            final long t$156653 = this.max2 = t$156652;
            
            //#line 112 "x10/regionarray/RectRegion.x10"
            this.max1 = t$156653;
            
            //#line 113 "x10/regionarray/RectRegion.x10"
            this.mins = null;
            
            //#line 114 "x10/regionarray/RectRegion.x10"
            this.maxs = null;
        }
        return this;
    }
    
    
    
    //#line 117 "x10/regionarray/RectRegion.x10"
    public long size$O() {
        
        //#line 118 "x10/regionarray/RectRegion.x10"
        final long t$156654 = this.size;
        
        //#line 118 "x10/regionarray/RectRegion.x10"
        final boolean t$156656 = ((t$156654) < (((long)(0L))));
        
        //#line 118 "x10/regionarray/RectRegion.x10"
        if (t$156656) {
            
            //#line 118 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.UnboundedRegionException t$156655 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)("size exceeds capacity of long")))));
            
            //#line 118 "x10/regionarray/RectRegion.x10"
            throw t$156655;
        }
        
        //#line 119 "x10/regionarray/RectRegion.x10"
        final long t$156657 = this.size;
        
        //#line 119 "x10/regionarray/RectRegion.x10"
        return t$156657;
    }
    
    
    //#line 122 "x10/regionarray/RectRegion.x10"
    public boolean isConvex$O() {
        
        //#line 122 "x10/regionarray/RectRegion.x10"
        return true;
    }
    
    
    //#line 124 "x10/regionarray/RectRegion.x10"
    public boolean isEmpty$O() {
        
        //#line 124 "x10/regionarray/RectRegion.x10"
        final long t$156658 = this.size;
        
        //#line 124 "x10/regionarray/RectRegion.x10"
        final boolean t$156659 = ((long) t$156658) == ((long) 0L);
        
        //#line 124 "x10/regionarray/RectRegion.x10"
        return t$156659;
    }
    
    
    //#line 126 "x10/regionarray/RectRegion.x10"
    public long indexOf$O(final x10.lang.Point pt) {
        
        //#line 127 "x10/regionarray/RectRegion.x10"
        final boolean t$156660 = this.contains$O(((x10.lang.Point)(pt)));
        
        //#line 127 "x10/regionarray/RectRegion.x10"
        final boolean t$156661 = !(t$156660);
        
        //#line 127 "x10/regionarray/RectRegion.x10"
        if (t$156661) {
            
            //#line 127 "x10/regionarray/RectRegion.x10"
            return -1L;
        }
        
        //#line 128 "x10/regionarray/RectRegion.x10"
        final long t$156662 = ((long)(((int)(0))));
        
        //#line 128 "x10/regionarray/RectRegion.x10"
        final long t$156664 = pt.$apply$O((long)(t$156662));
        
        //#line 128 "x10/regionarray/RectRegion.x10"
        final long t$156663 = ((long)(((int)(0))));
        
        //#line 128 "x10/regionarray/RectRegion.x10"
        final long t$156665 = this.min$O((long)(t$156663));
        
        //#line 128 "x10/regionarray/RectRegion.x10"
        long offset = ((t$156664) - (((long)(t$156665))));
        
        //#line 129 "x10/regionarray/RectRegion.x10"
        final long t$157348 = this.rank;
        
        //#line 129 "x10/regionarray/RectRegion.x10"
        final long i$145461max$157349 = ((t$157348) - (((long)(1L))));
        
        //#line 129 "x10/regionarray/RectRegion.x10"
        long i$157345 = 1L;
        
        //#line 129 "x10/regionarray/RectRegion.x10"
        for (;
             true;
             ) {
            
            //#line 129 "x10/regionarray/RectRegion.x10"
            final boolean t$157347 = ((i$157345) <= (((long)(i$145461max$157349))));
            
            //#line 129 "x10/regionarray/RectRegion.x10"
            if (!(t$157347)) {
                
                //#line 129 "x10/regionarray/RectRegion.x10"
                break;
            }
            
            //#line 130 "x10/regionarray/RectRegion.x10"
            final long min_i$157333 = this.min$O((long)(i$157345));
            
            //#line 131 "x10/regionarray/RectRegion.x10"
            final long max_i$157334 = this.max$O((long)(i$157345));
            
            //#line 132 "x10/regionarray/RectRegion.x10"
            final long pt_i$157335 = pt.$apply$O((long)(i$157345));
            
            //#line 133 "x10/regionarray/RectRegion.x10"
            final long t$157336 = ((max_i$157334) - (((long)(min_i$157333))));
            
            //#line 133 "x10/regionarray/RectRegion.x10"
            final long delta_i$157337 = ((t$157336) + (((long)(1L))));
            
            //#line 134 "x10/regionarray/RectRegion.x10"
            final long t$157339 = ((offset) * (((long)(delta_i$157337))));
            
            //#line 134 "x10/regionarray/RectRegion.x10"
            final long t$157340 = ((t$157339) + (((long)(pt_i$157335))));
            
            //#line 134 "x10/regionarray/RectRegion.x10"
            final long t$157341 = ((t$157340) - (((long)(min_i$157333))));
            
            //#line 134 "x10/regionarray/RectRegion.x10"
            offset = t$157341;
            
            //#line 129 "x10/regionarray/RectRegion.x10"
            final long t$157344 = ((i$157345) + (((long)(1L))));
            
            //#line 129 "x10/regionarray/RectRegion.x10"
            i$157345 = t$157344;
        }
        
        //#line 136 "x10/regionarray/RectRegion.x10"
        return offset;
    }
    
    
    //#line 139 "x10/regionarray/RectRegion.x10"
    public long indexOf$O(final long i0) {
        
        //#line 140 "x10/regionarray/RectRegion.x10"
        final boolean t$156694 = this.zeroBased;
        
        //#line 140 "x10/regionarray/RectRegion.x10"
        if (t$156694) {
            
            //#line 141 "x10/regionarray/RectRegion.x10"
            final long t$156678 = this.rank;
            
            //#line 141 "x10/regionarray/RectRegion.x10"
            boolean t$156683 = ((long) t$156678) != ((long) 1L);
            
            //#line 141 "x10/regionarray/RectRegion.x10"
            if (!(t$156683)) {
                
                //#line 141 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.RectRegion this$156505 = ((x10.regionarray.RectRegion)(this));
                
                //#line 264 . "x10/regionarray/RectRegion.x10"
                final long t$156679 = this$156505.min0;
                
                //#line 264 . "x10/regionarray/RectRegion.x10"
                boolean t$156681 = ((i0) >= (((long)(t$156679))));
                
                //#line 264 . "x10/regionarray/RectRegion.x10"
                if (t$156681) {
                    
                    //#line 264 . "x10/regionarray/RectRegion.x10"
                    final long t$156680 = this$156505.max0;
                    
                    //#line 264 . "x10/regionarray/RectRegion.x10"
                    t$156681 = ((i0) <= (((long)(t$156680))));
                }
                
                //#line 141 "x10/regionarray/RectRegion.x10"
                t$156683 = !(t$156681);
            }
            
            //#line 141 "x10/regionarray/RectRegion.x10"
            if (t$156683) {
                
                //#line 141 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 142 "x10/regionarray/RectRegion.x10"
            return i0;
        } else {
            
            //#line 144 "x10/regionarray/RectRegion.x10"
            final long t$156685 = this.rank;
            
            //#line 144 "x10/regionarray/RectRegion.x10"
            boolean t$156690 = ((long) t$156685) != ((long) 1L);
            
            //#line 144 "x10/regionarray/RectRegion.x10"
            if (!(t$156690)) {
                
                //#line 144 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.RectRegion this$156508 = ((x10.regionarray.RectRegion)(this));
                
                //#line 264 . "x10/regionarray/RectRegion.x10"
                final long t$156686 = this$156508.min0;
                
                //#line 264 . "x10/regionarray/RectRegion.x10"
                boolean t$156688 = ((i0) >= (((long)(t$156686))));
                
                //#line 264 . "x10/regionarray/RectRegion.x10"
                if (t$156688) {
                    
                    //#line 264 . "x10/regionarray/RectRegion.x10"
                    final long t$156687 = this$156508.max0;
                    
                    //#line 264 . "x10/regionarray/RectRegion.x10"
                    t$156688 = ((i0) <= (((long)(t$156687))));
                }
                
                //#line 144 "x10/regionarray/RectRegion.x10"
                t$156690 = !(t$156688);
            }
            
            //#line 144 "x10/regionarray/RectRegion.x10"
            if (t$156690) {
                
                //#line 144 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 145 "x10/regionarray/RectRegion.x10"
            final long t$156692 = this.min0;
            
            //#line 145 "x10/regionarray/RectRegion.x10"
            final long t$156693 = ((i0) - (((long)(t$156692))));
            
            //#line 145 "x10/regionarray/RectRegion.x10"
            return t$156693;
        }
    }
    
    
    //#line 149 "x10/regionarray/RectRegion.x10"
    public long indexOf$O(final long i0, final long i1) {
        
        //#line 150 "x10/regionarray/RectRegion.x10"
        final boolean t$156720 = this.zeroBased;
        
        //#line 150 "x10/regionarray/RectRegion.x10"
        if (t$156720) {
            
            //#line 151 "x10/regionarray/RectRegion.x10"
            final long t$156695 = this.rank;
            
            //#line 151 "x10/regionarray/RectRegion.x10"
            boolean t$156697 = ((long) t$156695) != ((long) 2L);
            
            //#line 151 "x10/regionarray/RectRegion.x10"
            if (!(t$156697)) {
                
                //#line 151 "x10/regionarray/RectRegion.x10"
                final boolean t$156696 = this.containsInternal$O((long)(i0), (long)(i1));
                
                //#line 151 "x10/regionarray/RectRegion.x10"
                t$156697 = !(t$156696);
            }
            
            //#line 151 "x10/regionarray/RectRegion.x10"
            if (t$156697) {
                
                //#line 151 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 152 "x10/regionarray/RectRegion.x10"
            long offset = i0;
            
            //#line 153 "x10/regionarray/RectRegion.x10"
            final long t$156699 = this.max1;
            
            //#line 153 "x10/regionarray/RectRegion.x10"
            final long t$156701 = ((t$156699) + (((long)(1L))));
            
            //#line 153 "x10/regionarray/RectRegion.x10"
            final long t$156702 = ((i0) * (((long)(t$156701))));
            
            //#line 153 "x10/regionarray/RectRegion.x10"
            final long t$156703 = ((t$156702) + (((long)(i1))));
            
            //#line 153 "x10/regionarray/RectRegion.x10"
            offset = t$156703;
            
            //#line 154 "x10/regionarray/RectRegion.x10"
            return offset;
        } else {
            
            //#line 156 "x10/regionarray/RectRegion.x10"
            final long t$156705 = this.rank;
            
            //#line 156 "x10/regionarray/RectRegion.x10"
            boolean t$156707 = ((long) t$156705) != ((long) 2L);
            
            //#line 156 "x10/regionarray/RectRegion.x10"
            if (!(t$156707)) {
                
                //#line 156 "x10/regionarray/RectRegion.x10"
                final boolean t$156706 = this.containsInternal$O((long)(i0), (long)(i1));
                
                //#line 156 "x10/regionarray/RectRegion.x10"
                t$156707 = !(t$156706);
            }
            
            //#line 156 "x10/regionarray/RectRegion.x10"
            if (t$156707) {
                
                //#line 156 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 157 "x10/regionarray/RectRegion.x10"
            final long t$156709 = this.min0;
            
            //#line 157 "x10/regionarray/RectRegion.x10"
            long offset = ((i0) - (((long)(t$156709))));
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$156710 = this.max1;
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$156711 = this.min1;
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$156712 = ((t$156710) - (((long)(t$156711))));
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$156714 = ((t$156712) + (((long)(1L))));
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$156715 = ((offset) * (((long)(t$156714))));
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$156716 = ((t$156715) + (((long)(i1))));
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$156717 = this.min1;
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$156718 = ((t$156716) - (((long)(t$156717))));
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            offset = t$156718;
            
            //#line 159 "x10/regionarray/RectRegion.x10"
            return offset;
        }
    }
    
    
    //#line 163 "x10/regionarray/RectRegion.x10"
    public long indexOf$O(final long i0, final long i1, final long i2) {
        
        //#line 164 "x10/regionarray/RectRegion.x10"
        final boolean t$156760 = this.zeroBased;
        
        //#line 164 "x10/regionarray/RectRegion.x10"
        if (t$156760) {
            
            //#line 165 "x10/regionarray/RectRegion.x10"
            final long t$156721 = this.rank;
            
            //#line 165 "x10/regionarray/RectRegion.x10"
            boolean t$156723 = ((long) t$156721) != ((long) 3L);
            
            //#line 165 "x10/regionarray/RectRegion.x10"
            if (!(t$156723)) {
                
                //#line 165 "x10/regionarray/RectRegion.x10"
                final boolean t$156722 = this.containsInternal$O((long)(i0), (long)(i1), (long)(i2));
                
                //#line 165 "x10/regionarray/RectRegion.x10"
                t$156723 = !(t$156722);
            }
            
            //#line 165 "x10/regionarray/RectRegion.x10"
            if (t$156723) {
                
                //#line 165 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 166 "x10/regionarray/RectRegion.x10"
            long offset = i0;
            
            //#line 167 "x10/regionarray/RectRegion.x10"
            final long t$156725 = this.max1;
            
            //#line 167 "x10/regionarray/RectRegion.x10"
            final long t$156727 = ((t$156725) + (((long)(1L))));
            
            //#line 167 "x10/regionarray/RectRegion.x10"
            final long t$156728 = ((i0) * (((long)(t$156727))));
            
            //#line 167 "x10/regionarray/RectRegion.x10"
            final long t$156729 = ((t$156728) + (((long)(i1))));
            
            //#line 167 "x10/regionarray/RectRegion.x10"
            offset = t$156729;
            
            //#line 168 "x10/regionarray/RectRegion.x10"
            final long t$156730 = this.max2;
            
            //#line 168 "x10/regionarray/RectRegion.x10"
            final long t$156732 = ((t$156730) + (((long)(1L))));
            
            //#line 168 "x10/regionarray/RectRegion.x10"
            final long t$156733 = ((offset) * (((long)(t$156732))));
            
            //#line 168 "x10/regionarray/RectRegion.x10"
            final long t$156734 = ((t$156733) + (((long)(i2))));
            
            //#line 168 "x10/regionarray/RectRegion.x10"
            offset = t$156734;
            
            //#line 169 "x10/regionarray/RectRegion.x10"
            return offset;
        } else {
            
            //#line 171 "x10/regionarray/RectRegion.x10"
            final long t$156736 = this.rank;
            
            //#line 171 "x10/regionarray/RectRegion.x10"
            boolean t$156738 = ((long) t$156736) != ((long) 3L);
            
            //#line 171 "x10/regionarray/RectRegion.x10"
            if (!(t$156738)) {
                
                //#line 171 "x10/regionarray/RectRegion.x10"
                final boolean t$156737 = this.containsInternal$O((long)(i0), (long)(i1), (long)(i2));
                
                //#line 171 "x10/regionarray/RectRegion.x10"
                t$156738 = !(t$156737);
            }
            
            //#line 171 "x10/regionarray/RectRegion.x10"
            if (t$156738) {
                
                //#line 171 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 172 "x10/regionarray/RectRegion.x10"
            final long t$156740 = this.min0;
            
            //#line 172 "x10/regionarray/RectRegion.x10"
            long offset = ((i0) - (((long)(t$156740))));
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$156741 = this.max1;
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$156742 = this.min1;
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$156743 = ((t$156741) - (((long)(t$156742))));
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$156745 = ((t$156743) + (((long)(1L))));
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$156746 = ((offset) * (((long)(t$156745))));
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$156747 = ((t$156746) + (((long)(i1))));
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$156748 = this.min1;
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$156749 = ((t$156747) - (((long)(t$156748))));
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            offset = t$156749;
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$156750 = this.max2;
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$156751 = this.min2;
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$156752 = ((t$156750) - (((long)(t$156751))));
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$156754 = ((t$156752) + (((long)(1L))));
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$156755 = ((offset) * (((long)(t$156754))));
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$156756 = ((t$156755) + (((long)(i2))));
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$156757 = this.min2;
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$156758 = ((t$156756) - (((long)(t$156757))));
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            offset = t$156758;
            
            //#line 175 "x10/regionarray/RectRegion.x10"
            return offset;
        }
    }
    
    
    //#line 179 "x10/regionarray/RectRegion.x10"
    public long indexOf$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 180 "x10/regionarray/RectRegion.x10"
        final boolean t$156814 = this.zeroBased;
        
        //#line 180 "x10/regionarray/RectRegion.x10"
        if (t$156814) {
            
            //#line 181 "x10/regionarray/RectRegion.x10"
            final long t$156761 = this.rank;
            
            //#line 181 "x10/regionarray/RectRegion.x10"
            boolean t$156763 = ((long) t$156761) != ((long) 4L);
            
            //#line 181 "x10/regionarray/RectRegion.x10"
            if (!(t$156763)) {
                
                //#line 181 "x10/regionarray/RectRegion.x10"
                final boolean t$156762 = this.containsInternal$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
                
                //#line 181 "x10/regionarray/RectRegion.x10"
                t$156763 = !(t$156762);
            }
            
            //#line 181 "x10/regionarray/RectRegion.x10"
            if (t$156763) {
                
                //#line 181 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 182 "x10/regionarray/RectRegion.x10"
            long offset = i0;
            
            //#line 183 "x10/regionarray/RectRegion.x10"
            final long t$156765 = this.max1;
            
            //#line 183 "x10/regionarray/RectRegion.x10"
            final long t$156767 = ((t$156765) + (((long)(1L))));
            
            //#line 183 "x10/regionarray/RectRegion.x10"
            final long t$156768 = ((i0) * (((long)(t$156767))));
            
            //#line 183 "x10/regionarray/RectRegion.x10"
            final long t$156769 = ((t$156768) + (((long)(i1))));
            
            //#line 183 "x10/regionarray/RectRegion.x10"
            offset = t$156769;
            
            //#line 184 "x10/regionarray/RectRegion.x10"
            final long t$156770 = this.max2;
            
            //#line 184 "x10/regionarray/RectRegion.x10"
            final long t$156772 = ((t$156770) + (((long)(1L))));
            
            //#line 184 "x10/regionarray/RectRegion.x10"
            final long t$156773 = ((offset) * (((long)(t$156772))));
            
            //#line 184 "x10/regionarray/RectRegion.x10"
            final long t$156774 = ((t$156773) + (((long)(i2))));
            
            //#line 184 "x10/regionarray/RectRegion.x10"
            offset = t$156774;
            
            //#line 185 "x10/regionarray/RectRegion.x10"
            final long t$156775 = this.max3;
            
            //#line 185 "x10/regionarray/RectRegion.x10"
            final long t$156777 = ((t$156775) + (((long)(1L))));
            
            //#line 185 "x10/regionarray/RectRegion.x10"
            final long t$156778 = ((offset) * (((long)(t$156777))));
            
            //#line 185 "x10/regionarray/RectRegion.x10"
            final long t$156779 = ((t$156778) + (((long)(i3))));
            
            //#line 185 "x10/regionarray/RectRegion.x10"
            offset = t$156779;
            
            //#line 186 "x10/regionarray/RectRegion.x10"
            return offset;
        } else {
            
            //#line 188 "x10/regionarray/RectRegion.x10"
            final long t$156781 = this.rank;
            
            //#line 188 "x10/regionarray/RectRegion.x10"
            boolean t$156783 = ((long) t$156781) != ((long) 4L);
            
            //#line 188 "x10/regionarray/RectRegion.x10"
            if (!(t$156783)) {
                
                //#line 188 "x10/regionarray/RectRegion.x10"
                final boolean t$156782 = this.containsInternal$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
                
                //#line 188 "x10/regionarray/RectRegion.x10"
                t$156783 = !(t$156782);
            }
            
            //#line 188 "x10/regionarray/RectRegion.x10"
            if (t$156783) {
                
                //#line 188 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 189 "x10/regionarray/RectRegion.x10"
            final long t$156785 = this.min0;
            
            //#line 189 "x10/regionarray/RectRegion.x10"
            long offset = ((i0) - (((long)(t$156785))));
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$156786 = this.max1;
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$156787 = this.min1;
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$156788 = ((t$156786) - (((long)(t$156787))));
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$156790 = ((t$156788) + (((long)(1L))));
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$156791 = ((offset) * (((long)(t$156790))));
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$156792 = ((t$156791) + (((long)(i1))));
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$156793 = this.min1;
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$156794 = ((t$156792) - (((long)(t$156793))));
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            offset = t$156794;
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$156795 = this.max2;
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$156796 = this.min2;
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$156797 = ((t$156795) - (((long)(t$156796))));
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$156799 = ((t$156797) + (((long)(1L))));
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$156800 = ((offset) * (((long)(t$156799))));
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$156801 = ((t$156800) + (((long)(i2))));
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$156802 = this.min2;
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$156803 = ((t$156801) - (((long)(t$156802))));
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            offset = t$156803;
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$156804 = this.max3;
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$156805 = this.min3;
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$156806 = ((t$156804) - (((long)(t$156805))));
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$156808 = ((t$156806) + (((long)(1L))));
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$156809 = ((offset) * (((long)(t$156808))));
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$156810 = ((t$156809) + (((long)(i3))));
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$156811 = this.min3;
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$156812 = ((t$156810) - (((long)(t$156811))));
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            offset = t$156812;
            
            //#line 193 "x10/regionarray/RectRegion.x10"
            return offset;
        }
    }
    
    
    //#line 198 "x10/regionarray/RectRegion.x10"
    public long min$O(final long i) {
        
        //#line 199 "x10/regionarray/RectRegion.x10"
        final boolean t$156816 = ((long) i) == ((long) 0L);
        
        //#line 199 "x10/regionarray/RectRegion.x10"
        if (t$156816) {
            
            //#line 199 "x10/regionarray/RectRegion.x10"
            final long t$156815 = this.min0;
            
            //#line 199 "x10/regionarray/RectRegion.x10"
            return t$156815;
        }
        
        //#line 200 "x10/regionarray/RectRegion.x10"
        final boolean t$156818 = ((long) i) == ((long) 1L);
        
        //#line 200 "x10/regionarray/RectRegion.x10"
        if (t$156818) {
            
            //#line 200 "x10/regionarray/RectRegion.x10"
            final long t$156817 = this.min1;
            
            //#line 200 "x10/regionarray/RectRegion.x10"
            return t$156817;
        }
        
        //#line 201 "x10/regionarray/RectRegion.x10"
        final boolean t$156820 = ((long) i) == ((long) 2L);
        
        //#line 201 "x10/regionarray/RectRegion.x10"
        if (t$156820) {
            
            //#line 201 "x10/regionarray/RectRegion.x10"
            final long t$156819 = this.min2;
            
            //#line 201 "x10/regionarray/RectRegion.x10"
            return t$156819;
        }
        
        //#line 202 "x10/regionarray/RectRegion.x10"
        final boolean t$156822 = ((long) i) == ((long) 3L);
        
        //#line 202 "x10/regionarray/RectRegion.x10"
        if (t$156822) {
            
            //#line 202 "x10/regionarray/RectRegion.x10"
            final long t$156821 = this.min3;
            
            //#line 202 "x10/regionarray/RectRegion.x10"
            return t$156821;
        }
        
        //#line 203 "x10/regionarray/RectRegion.x10"
        boolean t$156824 = ((i) < (((long)(0L))));
        
        //#line 203 "x10/regionarray/RectRegion.x10"
        if (!(t$156824)) {
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            final long t$156823 = this.rank;
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            t$156824 = ((i) >= (((long)(t$156823))));
        }
        
        //#line 203 "x10/regionarray/RectRegion.x10"
        if (t$156824) {
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$156825 = (("min: ") + ((x10.core.Long.$box(i))));
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$156826 = ((t$156825) + (" is not a valid rank for "));
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$156827 = ((t$156826) + (this));
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$156828 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$156827)));
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            throw t$156828;
        }
        
        //#line 204 "x10/regionarray/RectRegion.x10"
        final x10.core.Rail t$156830 = ((x10.core.Rail)(this.mins));
        
        //#line 204 "x10/regionarray/RectRegion.x10"
        final long t$156831 = ((long[])t$156830.value)[(int)i];
        
        //#line 204 "x10/regionarray/RectRegion.x10"
        return t$156831;
    }
    
    
    //#line 207 "x10/regionarray/RectRegion.x10"
    public long max$O(final long i) {
        
        //#line 208 "x10/regionarray/RectRegion.x10"
        final boolean t$156833 = ((long) i) == ((long) 0L);
        
        //#line 208 "x10/regionarray/RectRegion.x10"
        if (t$156833) {
            
            //#line 208 "x10/regionarray/RectRegion.x10"
            final long t$156832 = this.max0;
            
            //#line 208 "x10/regionarray/RectRegion.x10"
            return t$156832;
        }
        
        //#line 209 "x10/regionarray/RectRegion.x10"
        final boolean t$156835 = ((long) i) == ((long) 1L);
        
        //#line 209 "x10/regionarray/RectRegion.x10"
        if (t$156835) {
            
            //#line 209 "x10/regionarray/RectRegion.x10"
            final long t$156834 = this.max1;
            
            //#line 209 "x10/regionarray/RectRegion.x10"
            return t$156834;
        }
        
        //#line 210 "x10/regionarray/RectRegion.x10"
        final boolean t$156837 = ((long) i) == ((long) 2L);
        
        //#line 210 "x10/regionarray/RectRegion.x10"
        if (t$156837) {
            
            //#line 210 "x10/regionarray/RectRegion.x10"
            final long t$156836 = this.max2;
            
            //#line 210 "x10/regionarray/RectRegion.x10"
            return t$156836;
        }
        
        //#line 211 "x10/regionarray/RectRegion.x10"
        final boolean t$156839 = ((long) i) == ((long) 3L);
        
        //#line 211 "x10/regionarray/RectRegion.x10"
        if (t$156839) {
            
            //#line 211 "x10/regionarray/RectRegion.x10"
            final long t$156838 = this.max3;
            
            //#line 211 "x10/regionarray/RectRegion.x10"
            return t$156838;
        }
        
        //#line 212 "x10/regionarray/RectRegion.x10"
        boolean t$156841 = ((i) < (((long)(0L))));
        
        //#line 212 "x10/regionarray/RectRegion.x10"
        if (!(t$156841)) {
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            final long t$156840 = this.rank;
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            t$156841 = ((i) >= (((long)(t$156840))));
        }
        
        //#line 212 "x10/regionarray/RectRegion.x10"
        if (t$156841) {
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$156842 = (("max: ") + ((x10.core.Long.$box(i))));
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$156843 = ((t$156842) + (" is not a valid rank for "));
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$156844 = ((t$156843) + (this));
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$156845 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$156844)));
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            throw t$156845;
        }
        
        //#line 213 "x10/regionarray/RectRegion.x10"
        final x10.core.Rail t$156847 = ((x10.core.Rail)(this.maxs));
        
        //#line 213 "x10/regionarray/RectRegion.x10"
        final long t$156848 = ((long[])t$156847.value)[(int)i];
        
        //#line 213 "x10/regionarray/RectRegion.x10"
        return t$156848;
    }
    
    
    //#line 221 "x10/regionarray/RectRegion.x10"
    public x10.regionarray.Region computeBoundingBox() {
        
        //#line 221 "x10/regionarray/RectRegion.x10"
        return this;
    }
    
    
    //#line 223 "x10/regionarray/RectRegion.x10"
    public x10.core.fun.Fun_0_1 min() {
        
        //#line 223 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$156850 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$220(this)));
        
        //#line 223 "x10/regionarray/RectRegion.x10"
        return t$156850;
    }
    
    
    //#line 224 "x10/regionarray/RectRegion.x10"
    public x10.core.fun.Fun_0_1 max() {
        
        //#line 224 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$156852 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$221(this)));
        
        //#line 224 "x10/regionarray/RectRegion.x10"
        return t$156852;
    }
    
    
    //#line 226 "x10/regionarray/RectRegion.x10"
    public boolean contains$O(final x10.regionarray.Region that) {
        
        //#line 227 "x10/regionarray/RectRegion.x10"
        final boolean t$156878 = x10.regionarray.RectRegion.$RTT.isInstance(that);
        
        //#line 227 "x10/regionarray/RectRegion.x10"
        if (t$156878) {
            
            //#line 228 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.RectRegion this$156511 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            x10.core.fun.Fun_0_1 ret$156512 =  null;
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final x10.core.fun.Fun_0_1 t$157362 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$222(this$156511)));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            ret$156512 = ((x10.core.fun.Fun_0_1)(t$157362));
            
            //#line 228 "x10/regionarray/RectRegion.x10"
            final x10.core.fun.Fun_0_1 thatMin = ret$156512;
            
            //#line 229 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.RectRegion this$156515 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            x10.core.fun.Fun_0_1 ret$156516 =  null;
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final x10.core.fun.Fun_0_1 t$157365 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$223(this$156515)));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            ret$156516 = ((x10.core.fun.Fun_0_1)(t$157365));
            
            //#line 230 "x10/regionarray/RectRegion.x10"
            final long t$157368 = this.rank;
            
            //#line 230 "x10/regionarray/RectRegion.x10"
            final long i$145479max$157369 = ((t$157368) - (((long)(1L))));
            
            //#line 230 "x10/regionarray/RectRegion.x10"
            long i$157359 = 0L;
            
            //#line 230 "x10/regionarray/RectRegion.x10"
            for (;
                 true;
                 ) {
                
                //#line 230 "x10/regionarray/RectRegion.x10"
                final boolean t$157361 = ((i$157359) <= (((long)(i$145479max$157369))));
                
                //#line 230 "x10/regionarray/RectRegion.x10"
                if (!(t$157361)) {
                    
                    //#line 230 "x10/regionarray/RectRegion.x10"
                    break;
                }
                
                //#line 231 "x10/regionarray/RectRegion.x10"
                final long t$157350 = this.min$O((long)(i$157359));
                
                //#line 231 "x10/regionarray/RectRegion.x10"
                final long t$157351 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)thatMin).$apply(x10.core.Long.$box(i$157359), x10.rtt.Types.LONG));
                
                //#line 231 "x10/regionarray/RectRegion.x10"
                final boolean t$157352 = ((t$157350) > (((long)(t$157351))));
                
                //#line 231 "x10/regionarray/RectRegion.x10"
                if (t$157352) {
                    
                    //#line 231 "x10/regionarray/RectRegion.x10"
                    return false;
                }
                
                //#line 232 "x10/regionarray/RectRegion.x10"
                final long t$157353 = this.max$O((long)(i$157359));
                
                //#line 232 "x10/regionarray/RectRegion.x10"
                final long t$157354 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)ret$156516).$apply(x10.core.Long.$box(i$157359), x10.rtt.Types.LONG));
                
                //#line 232 "x10/regionarray/RectRegion.x10"
                final boolean t$157355 = ((t$157353) < (((long)(t$157354))));
                
                //#line 232 "x10/regionarray/RectRegion.x10"
                if (t$157355) {
                    
                    //#line 232 "x10/regionarray/RectRegion.x10"
                    return false;
                }
                
                //#line 230 "x10/regionarray/RectRegion.x10"
                final long t$157358 = ((i$157359) + (((long)(1L))));
                
                //#line 230 "x10/regionarray/RectRegion.x10"
                i$157359 = t$157358;
            }
            
            //#line 234 "x10/regionarray/RectRegion.x10"
            return true;
        } else {
            
            //#line 235 "x10/regionarray/RectRegion.x10"
            final boolean t$156877 = x10.regionarray.RectRegion1D.$RTT.isInstance(that);
            
            //#line 235 "x10/regionarray/RectRegion.x10"
            if (t$156877) {
                
                //#line 236 "x10/regionarray/RectRegion.x10"
                final long t$156869 = this.min$O((long)(0L));
                
                //#line 236 "x10/regionarray/RectRegion.x10"
                final long t$156870 = that.min$O((long)(0L));
                
                //#line 236 "x10/regionarray/RectRegion.x10"
                boolean t$156873 = ((t$156869) <= (((long)(t$156870))));
                
                //#line 236 "x10/regionarray/RectRegion.x10"
                if (t$156873) {
                    
                    //#line 236 "x10/regionarray/RectRegion.x10"
                    final long t$156871 = this.max$O((long)(0L));
                    
                    //#line 236 "x10/regionarray/RectRegion.x10"
                    final long t$156872 = that.max$O((long)(0L));
                    
                    //#line 236 "x10/regionarray/RectRegion.x10"
                    t$156873 = ((t$156871) >= (((long)(t$156872))));
                }
                
                //#line 236 "x10/regionarray/RectRegion.x10"
                return t$156873;
            } else {
                
                //#line 238 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.Region t$156875 = ((x10.regionarray.Region)(that.computeBoundingBox()));
                
                //#line 238 "x10/regionarray/RectRegion.x10"
                final boolean t$156876 = this.contains$O(((x10.regionarray.Region)(t$156875)));
                
                //#line 238 "x10/regionarray/RectRegion.x10"
                return t$156876;
            }
        }
    }
    
    
    //#line 242 "x10/regionarray/RectRegion.x10"
    public boolean contains$O(final x10.lang.Point p) {
        
        //#line 243 "x10/regionarray/RectRegion.x10"
        final long t$156879 = p.rank;
        
        //#line 243 "x10/regionarray/RectRegion.x10"
        final long t$156880 = this.rank;
        
        //#line 243 "x10/regionarray/RectRegion.x10"
        final boolean t$156881 = ((long) t$156879) != ((long) t$156880);
        
        //#line 243 "x10/regionarray/RectRegion.x10"
        if (t$156881) {
            
            //#line 243 "x10/regionarray/RectRegion.x10"
            return false;
        }
        
        //#line 245 "x10/regionarray/RectRegion.x10"
        final long t$156882 = p.rank;
        
        //#line 245 "x10/regionarray/RectRegion.x10"
        final long t$156883 = ((t$156882) - (((long)(1L))));
        
        //#line 245 "x10/regionarray/RectRegion.x10"
        final int t$156914 = ((int)(long)(((long)(t$156883))));
        
        //#line 245 "x10/regionarray/RectRegion.x10"
        switch (t$156914) {
            
            //#line 246 "x10/regionarray/RectRegion.x10"
            default:
                {
                    
                    //#line 247 "x10/regionarray/RectRegion.x10"
                    final long t$156884 = p.rank;
                    
                    //#line 247 "x10/regionarray/RectRegion.x10"
                    final long i$145497min$145498 = ((t$156884) - (((long)(1L))));
                    
                    //#line 247 "x10/regionarray/RectRegion.x10"
                    long i$157381 = i$145497min$145498;
                    
                    //#line 247 "x10/regionarray/RectRegion.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 247 "x10/regionarray/RectRegion.x10"
                        final boolean t$157383 = ((i$157381) <= (((long)(4L))));
                        
                        //#line 247 "x10/regionarray/RectRegion.x10"
                        if (!(t$157383)) {
                            
                            //#line 247 "x10/regionarray/RectRegion.x10"
                            break;
                        }
                        
                        //#line 248 "x10/regionarray/RectRegion.x10"
                        final long t$157370 = p.$apply$O((long)(i$157381));
                        
                        //#line 248 "x10/regionarray/RectRegion.x10"
                        final x10.core.Rail t$157371 = ((x10.core.Rail)(this.mins));
                        
                        //#line 248 "x10/regionarray/RectRegion.x10"
                        final long t$157372 = ((long[])t$157371.value)[(int)i$157381];
                        
                        //#line 248 "x10/regionarray/RectRegion.x10"
                        boolean t$157373 = ((t$157370) < (((long)(t$157372))));
                        
                        //#line 248 "x10/regionarray/RectRegion.x10"
                        if (!(t$157373)) {
                            
                            //#line 248 "x10/regionarray/RectRegion.x10"
                            final long t$157374 = p.$apply$O((long)(i$157381));
                            
                            //#line 248 "x10/regionarray/RectRegion.x10"
                            final x10.core.Rail t$157375 = ((x10.core.Rail)(this.maxs));
                            
                            //#line 248 "x10/regionarray/RectRegion.x10"
                            final long t$157376 = ((long[])t$157375.value)[(int)i$157381];
                            
                            //#line 248 "x10/regionarray/RectRegion.x10"
                            t$157373 = ((t$157374) > (((long)(t$157376))));
                        }
                        
                        //#line 248 "x10/regionarray/RectRegion.x10"
                        if (t$157373) {
                            
                            //#line 248 "x10/regionarray/RectRegion.x10"
                            return false;
                        }
                        
                        //#line 247 "x10/regionarray/RectRegion.x10"
                        final long t$157380 = ((i$157381) + (((long)(1L))));
                        
                        //#line 247 "x10/regionarray/RectRegion.x10"
                        i$157381 = t$157380;
                    }
                }
            
            //#line 250 "x10/regionarray/RectRegion.x10"
            case 3:
                {
                    
                    //#line 250 "x10/regionarray/RectRegion.x10"
                    final long tmp = p.$apply$O((long)(3L));
                    
                    //#line 250 "x10/regionarray/RectRegion.x10"
                    final long t$156898 = this.min3;
                    
                    //#line 250 "x10/regionarray/RectRegion.x10"
                    boolean t$156900 = ((tmp) < (((long)(t$156898))));
                    
                    //#line 250 "x10/regionarray/RectRegion.x10"
                    if (!(t$156900)) {
                        
                        //#line 250 "x10/regionarray/RectRegion.x10"
                        final long t$156899 = this.max3;
                        
                        //#line 250 "x10/regionarray/RectRegion.x10"
                        t$156900 = ((tmp) > (((long)(t$156899))));
                    }
                    
                    //#line 250 "x10/regionarray/RectRegion.x10"
                    if (t$156900) {
                        
                        //#line 250 "x10/regionarray/RectRegion.x10"
                        return false;
                    }
                }
            
            //#line 251 "x10/regionarray/RectRegion.x10"
            case 2:
                {
                    
                    //#line 251 "x10/regionarray/RectRegion.x10"
                    final long tmp = p.$apply$O((long)(2L));
                    
                    //#line 251 "x10/regionarray/RectRegion.x10"
                    final long t$156902 = this.min2;
                    
                    //#line 251 "x10/regionarray/RectRegion.x10"
                    boolean t$156904 = ((tmp) < (((long)(t$156902))));
                    
                    //#line 251 "x10/regionarray/RectRegion.x10"
                    if (!(t$156904)) {
                        
                        //#line 251 "x10/regionarray/RectRegion.x10"
                        final long t$156903 = this.max2;
                        
                        //#line 251 "x10/regionarray/RectRegion.x10"
                        t$156904 = ((tmp) > (((long)(t$156903))));
                    }
                    
                    //#line 251 "x10/regionarray/RectRegion.x10"
                    if (t$156904) {
                        
                        //#line 251 "x10/regionarray/RectRegion.x10"
                        return false;
                    }
                }
            
            //#line 252 "x10/regionarray/RectRegion.x10"
            case 1:
                {
                    
                    //#line 252 "x10/regionarray/RectRegion.x10"
                    final long tmp = p.$apply$O((long)(1L));
                    
                    //#line 252 "x10/regionarray/RectRegion.x10"
                    final long t$156906 = this.min1;
                    
                    //#line 252 "x10/regionarray/RectRegion.x10"
                    boolean t$156908 = ((tmp) < (((long)(t$156906))));
                    
                    //#line 252 "x10/regionarray/RectRegion.x10"
                    if (!(t$156908)) {
                        
                        //#line 252 "x10/regionarray/RectRegion.x10"
                        final long t$156907 = this.max1;
                        
                        //#line 252 "x10/regionarray/RectRegion.x10"
                        t$156908 = ((tmp) > (((long)(t$156907))));
                    }
                    
                    //#line 252 "x10/regionarray/RectRegion.x10"
                    if (t$156908) {
                        
                        //#line 252 "x10/regionarray/RectRegion.x10"
                        return false;
                    }
                }
            
            //#line 253 "x10/regionarray/RectRegion.x10"
            case 0:
                {
                    
                    //#line 253 "x10/regionarray/RectRegion.x10"
                    final long tmp = p.$apply$O((long)(0L));
                    
                    //#line 253 "x10/regionarray/RectRegion.x10"
                    final long t$156910 = this.min0;
                    
                    //#line 253 "x10/regionarray/RectRegion.x10"
                    boolean t$156912 = ((tmp) < (((long)(t$156910))));
                    
                    //#line 253 "x10/regionarray/RectRegion.x10"
                    if (!(t$156912)) {
                        
                        //#line 253 "x10/regionarray/RectRegion.x10"
                        final long t$156911 = this.max0;
                        
                        //#line 253 "x10/regionarray/RectRegion.x10"
                        t$156912 = ((tmp) > (((long)(t$156911))));
                    }
                    
                    //#line 253 "x10/regionarray/RectRegion.x10"
                    if (t$156912) {
                        
                        //#line 253 "x10/regionarray/RectRegion.x10"
                        return false;
                    }
                }
        }
        
        //#line 255 "x10/regionarray/RectRegion.x10"
        return true;
    }
    
    
    //#line 258 "x10/regionarray/RectRegion.x10"
    public boolean contains$O(final long i0) {
        
        //#line 258 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$156519 = ((x10.regionarray.RectRegion)(this));
        
        //#line 264 . "x10/regionarray/RectRegion.x10"
        final long t$156915 = this$156519.min0;
        
        //#line 264 . "x10/regionarray/RectRegion.x10"
        boolean t$156917 = ((i0) >= (((long)(t$156915))));
        
        //#line 264 . "x10/regionarray/RectRegion.x10"
        if (t$156917) {
            
            //#line 264 . "x10/regionarray/RectRegion.x10"
            final long t$156916 = this$156519.max0;
            
            //#line 264 . "x10/regionarray/RectRegion.x10"
            t$156917 = ((i0) <= (((long)(t$156916))));
        }
        
        //#line 258 "x10/regionarray/RectRegion.x10"
        return t$156917;
    }
    
    
    //#line 259 "x10/regionarray/RectRegion.x10"
    public boolean contains$O(final long i0, final long i1) {
        
        //#line 259 "x10/regionarray/RectRegion.x10"
        final boolean t$156919 = this.containsInternal$O((long)(i0), (long)(i1));
        
        //#line 259 "x10/regionarray/RectRegion.x10"
        return t$156919;
    }
    
    
    //#line 260 "x10/regionarray/RectRegion.x10"
    public boolean contains$O(final long i0, final long i1, final long i2) {
        
        //#line 260 "x10/regionarray/RectRegion.x10"
        final boolean t$156920 = this.containsInternal$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 260 "x10/regionarray/RectRegion.x10"
        return t$156920;
    }
    
    
    //#line 261 "x10/regionarray/RectRegion.x10"
    public boolean contains$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 261 "x10/regionarray/RectRegion.x10"
        final boolean t$156921 = this.containsInternal$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 261 "x10/regionarray/RectRegion.x10"
        return t$156921;
    }
    
    
    //#line 263 "x10/regionarray/RectRegion.x10"
    private boolean containsInternal$O(final long i0) {
        
        //#line 264 "x10/regionarray/RectRegion.x10"
        final long t$156922 = this.min0;
        
        //#line 264 "x10/regionarray/RectRegion.x10"
        boolean t$156924 = ((i0) >= (((long)(t$156922))));
        
        //#line 264 "x10/regionarray/RectRegion.x10"
        if (t$156924) {
            
            //#line 264 "x10/regionarray/RectRegion.x10"
            final long t$156923 = this.max0;
            
            //#line 264 "x10/regionarray/RectRegion.x10"
            t$156924 = ((i0) <= (((long)(t$156923))));
        }
        
        //#line 264 "x10/regionarray/RectRegion.x10"
        return t$156924;
    }
    
    public static boolean containsInternal$P$O(final long i0, final x10.regionarray.RectRegion RectRegion) {
        return RectRegion.containsInternal$O((long)(i0));
    }
    
    
    //#line 267 "x10/regionarray/RectRegion.x10"
    private boolean containsInternal$O(final long i0, final long i1) {
        
        //#line 268 "x10/regionarray/RectRegion.x10"
        boolean t$156926 = true;
        
        //#line 268 "x10/regionarray/RectRegion.x10"
        if (t$156926) {
            
            //#line 268 "x10/regionarray/RectRegion.x10"
            t$156926 = this.zeroBased;
        }
        
        //#line 268 "x10/regionarray/RectRegion.x10"
        if (t$156926) {
            
            //#line 269 "x10/regionarray/RectRegion.x10"
            final long t$156928 = ((long)(((long)(i0))));
            
            //#line 269 "x10/regionarray/RectRegion.x10"
            final long t$156927 = this.max0;
            
            //#line 269 "x10/regionarray/RectRegion.x10"
            final long t$156929 = ((long)(((long)(t$156927))));
            
            //#line 269 "x10/regionarray/RectRegion.x10"
            boolean t$156933 = x10.runtime.impl.java.ULongUtils.le(t$156928, ((long)(t$156929)));
            
            //#line 269 "x10/regionarray/RectRegion.x10"
            if (t$156933) {
                
                //#line 270 "x10/regionarray/RectRegion.x10"
                final long t$156931 = ((long)(((long)(i1))));
                
                //#line 270 "x10/regionarray/RectRegion.x10"
                final long t$156930 = this.max1;
                
                //#line 270 "x10/regionarray/RectRegion.x10"
                final long t$156932 = ((long)(((long)(t$156930))));
                
                //#line 269 "x10/regionarray/RectRegion.x10"
                t$156933 = x10.runtime.impl.java.ULongUtils.le(t$156931, ((long)(t$156932)));
            }
            
            //#line 269 "x10/regionarray/RectRegion.x10"
            return t$156933;
        } else {
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            final long t$156935 = this.min0;
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            boolean t$156937 = ((i0) >= (((long)(t$156935))));
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            if (t$156937) {
                
                //#line 272 "x10/regionarray/RectRegion.x10"
                final long t$156936 = this.max0;
                
                //#line 272 "x10/regionarray/RectRegion.x10"
                t$156937 = ((i0) <= (((long)(t$156936))));
            }
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            boolean t$156939 = t$156937;
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            if (t$156937) {
                
                //#line 273 "x10/regionarray/RectRegion.x10"
                final long t$156938 = this.min1;
                
                //#line 272 "x10/regionarray/RectRegion.x10"
                t$156939 = ((i1) >= (((long)(t$156938))));
            }
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            boolean t$156941 = t$156939;
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            if (t$156939) {
                
                //#line 273 "x10/regionarray/RectRegion.x10"
                final long t$156940 = this.max1;
                
                //#line 272 "x10/regionarray/RectRegion.x10"
                t$156941 = ((i1) <= (((long)(t$156940))));
            }
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            return t$156941;
        }
    }
    
    public static boolean containsInternal$P$O(final long i0, final long i1, final x10.regionarray.RectRegion RectRegion) {
        return RectRegion.containsInternal$O((long)(i0), (long)(i1));
    }
    
    
    //#line 277 "x10/regionarray/RectRegion.x10"
    private boolean containsInternal$O(final long i0, final long i1, final long i2) {
        
        //#line 278 "x10/regionarray/RectRegion.x10"
        boolean t$156944 = true;
        
        //#line 278 "x10/regionarray/RectRegion.x10"
        if (t$156944) {
            
            //#line 278 "x10/regionarray/RectRegion.x10"
            t$156944 = this.zeroBased;
        }
        
        //#line 278 "x10/regionarray/RectRegion.x10"
        if (t$156944) {
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            final long t$156946 = ((long)(((long)(i0))));
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            final long t$156945 = this.max0;
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            final long t$156947 = ((long)(((long)(t$156945))));
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            boolean t$156951 = x10.runtime.impl.java.ULongUtils.le(t$156946, ((long)(t$156947)));
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            if (t$156951) {
                
                //#line 280 "x10/regionarray/RectRegion.x10"
                final long t$156949 = ((long)(((long)(i1))));
                
                //#line 280 "x10/regionarray/RectRegion.x10"
                final long t$156948 = this.max1;
                
                //#line 280 "x10/regionarray/RectRegion.x10"
                final long t$156950 = ((long)(((long)(t$156948))));
                
                //#line 279 "x10/regionarray/RectRegion.x10"
                t$156951 = x10.runtime.impl.java.ULongUtils.le(t$156949, ((long)(t$156950)));
            }
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            boolean t$156955 = t$156951;
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            if (t$156951) {
                
                //#line 281 "x10/regionarray/RectRegion.x10"
                final long t$156953 = ((long)(((long)(i2))));
                
                //#line 281 "x10/regionarray/RectRegion.x10"
                final long t$156952 = this.max2;
                
                //#line 281 "x10/regionarray/RectRegion.x10"
                final long t$156954 = ((long)(((long)(t$156952))));
                
                //#line 279 "x10/regionarray/RectRegion.x10"
                t$156955 = x10.runtime.impl.java.ULongUtils.le(t$156953, ((long)(t$156954)));
            }
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            return t$156955;
        } else {
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            final long t$156957 = this.min0;
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            boolean t$156959 = ((i0) >= (((long)(t$156957))));
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            if (t$156959) {
                
                //#line 283 "x10/regionarray/RectRegion.x10"
                final long t$156958 = this.max0;
                
                //#line 283 "x10/regionarray/RectRegion.x10"
                t$156959 = ((i0) <= (((long)(t$156958))));
            }
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            boolean t$156961 = t$156959;
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            if (t$156959) {
                
                //#line 284 "x10/regionarray/RectRegion.x10"
                final long t$156960 = this.min1;
                
                //#line 283 "x10/regionarray/RectRegion.x10"
                t$156961 = ((i1) >= (((long)(t$156960))));
            }
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            boolean t$156963 = t$156961;
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            if (t$156961) {
                
                //#line 284 "x10/regionarray/RectRegion.x10"
                final long t$156962 = this.max1;
                
                //#line 283 "x10/regionarray/RectRegion.x10"
                t$156963 = ((i1) <= (((long)(t$156962))));
            }
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            boolean t$156965 = t$156963;
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            if (t$156963) {
                
                //#line 285 "x10/regionarray/RectRegion.x10"
                final long t$156964 = this.min2;
                
                //#line 283 "x10/regionarray/RectRegion.x10"
                t$156965 = ((i2) >= (((long)(t$156964))));
            }
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            boolean t$156967 = t$156965;
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            if (t$156965) {
                
                //#line 285 "x10/regionarray/RectRegion.x10"
                final long t$156966 = this.max2;
                
                //#line 283 "x10/regionarray/RectRegion.x10"
                t$156967 = ((i2) <= (((long)(t$156966))));
            }
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            return t$156967;
        }
    }
    
    public static boolean containsInternal$P$O(final long i0, final long i1, final long i2, final x10.regionarray.RectRegion RectRegion) {
        return RectRegion.containsInternal$O((long)(i0), (long)(i1), (long)(i2));
    }
    
    
    //#line 289 "x10/regionarray/RectRegion.x10"
    private boolean containsInternal$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 290 "x10/regionarray/RectRegion.x10"
        boolean t$156970 = true;
        
        //#line 290 "x10/regionarray/RectRegion.x10"
        if (t$156970) {
            
            //#line 290 "x10/regionarray/RectRegion.x10"
            t$156970 = this.zeroBased;
        }
        
        //#line 290 "x10/regionarray/RectRegion.x10"
        if (t$156970) {
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            final long t$156972 = ((long)(((long)(i0))));
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            final long t$156971 = this.max0;
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            final long t$156973 = ((long)(((long)(t$156971))));
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            boolean t$156977 = x10.runtime.impl.java.ULongUtils.le(t$156972, ((long)(t$156973)));
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            if (t$156977) {
                
                //#line 292 "x10/regionarray/RectRegion.x10"
                final long t$156975 = ((long)(((long)(i1))));
                
                //#line 292 "x10/regionarray/RectRegion.x10"
                final long t$156974 = this.max1;
                
                //#line 292 "x10/regionarray/RectRegion.x10"
                final long t$156976 = ((long)(((long)(t$156974))));
                
                //#line 291 "x10/regionarray/RectRegion.x10"
                t$156977 = x10.runtime.impl.java.ULongUtils.le(t$156975, ((long)(t$156976)));
            }
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            boolean t$156981 = t$156977;
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            if (t$156977) {
                
                //#line 293 "x10/regionarray/RectRegion.x10"
                final long t$156979 = ((long)(((long)(i2))));
                
                //#line 293 "x10/regionarray/RectRegion.x10"
                final long t$156978 = this.max2;
                
                //#line 293 "x10/regionarray/RectRegion.x10"
                final long t$156980 = ((long)(((long)(t$156978))));
                
                //#line 291 "x10/regionarray/RectRegion.x10"
                t$156981 = x10.runtime.impl.java.ULongUtils.le(t$156979, ((long)(t$156980)));
            }
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            boolean t$156985 = t$156981;
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            if (t$156981) {
                
                //#line 294 "x10/regionarray/RectRegion.x10"
                final long t$156983 = ((long)(((long)(i3))));
                
                //#line 294 "x10/regionarray/RectRegion.x10"
                final long t$156982 = this.max3;
                
                //#line 294 "x10/regionarray/RectRegion.x10"
                final long t$156984 = ((long)(((long)(t$156982))));
                
                //#line 291 "x10/regionarray/RectRegion.x10"
                t$156985 = x10.runtime.impl.java.ULongUtils.le(t$156983, ((long)(t$156984)));
            }
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            return t$156985;
        } else {
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            final long t$156987 = this.min0;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$156989 = ((i0) >= (((long)(t$156987))));
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$156989) {
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                final long t$156988 = this.max0;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$156989 = ((i0) <= (((long)(t$156988))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$156991 = t$156989;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$156989) {
                
                //#line 297 "x10/regionarray/RectRegion.x10"
                final long t$156990 = this.min1;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$156991 = ((i1) >= (((long)(t$156990))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$156993 = t$156991;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$156991) {
                
                //#line 297 "x10/regionarray/RectRegion.x10"
                final long t$156992 = this.max1;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$156993 = ((i1) <= (((long)(t$156992))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$156995 = t$156993;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$156993) {
                
                //#line 298 "x10/regionarray/RectRegion.x10"
                final long t$156994 = this.min2;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$156995 = ((i2) >= (((long)(t$156994))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$156997 = t$156995;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$156995) {
                
                //#line 298 "x10/regionarray/RectRegion.x10"
                final long t$156996 = this.max2;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$156997 = ((i2) <= (((long)(t$156996))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$156999 = t$156997;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$156997) {
                
                //#line 299 "x10/regionarray/RectRegion.x10"
                final long t$156998 = this.min3;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$156999 = ((i3) >= (((long)(t$156998))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$157001 = t$156999;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$156999) {
                
                //#line 299 "x10/regionarray/RectRegion.x10"
                final long t$157000 = this.max3;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$157001 = ((i3) <= (((long)(t$157000))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            return t$157001;
        }
    }
    
    public static boolean containsInternal$P$O(final long i0, final long i1, final long i2, final long i3, final x10.regionarray.RectRegion RectRegion) {
        return RectRegion.containsInternal$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
    }
    
    
    //#line 308 "x10/regionarray/RectRegion.x10"
    /**
     * Return a PolyRegion with the same set of points as this region. This permits
     * general algorithms for intersection, restriction etc to be applied to RectRegion's.
     */
    public x10.regionarray.Region toPolyRegion() {
        
        //#line 309 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.Region t$157004 = ((x10.regionarray.Region)(this.polyRep));
        
        //#line 309 "x10/regionarray/RectRegion.x10"
        final boolean t$157019 = ((t$157004) == (null));
        
        //#line 309 "x10/regionarray/RectRegion.x10"
        if (t$157019) {
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final long t$157006 = this.rank;
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final x10.core.fun.Fun_0_1 t$157007 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$224(this)));
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final x10.core.Rail t$157011 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157006)), ((x10.core.fun.Fun_0_1)(t$157007)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final long t$157009 = this.rank;
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final x10.core.fun.Fun_0_1 t$157010 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$225(this)));
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final x10.core.Rail t$157012 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157009)), ((x10.core.fun.Fun_0_1)(t$157010)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.Region t$157013 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangularPoly__0$1x10$lang$Long$2__1$1x10$lang$Long$2(((x10.core.Rail)(t$157011)), ((x10.core.Rail)(t$157012)))));
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.Region t$144915 = ((x10.regionarray.Region)
                                                      t$157013);
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final long t$157014 = t$144915.rank;
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final long t$157015 = x10.regionarray.RectRegion.this.rank;
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final boolean t$157016 = ((long) t$157014) == ((long) t$157015);
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final boolean t$157018 = !(t$157016);
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            if (t$157018) {
                
                //#line 310 "x10/regionarray/RectRegion.x10"
                final x10.lang.FailedDynamicCheckException t$157017 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.RectRegion).rank}");
                
                //#line 310 "x10/regionarray/RectRegion.x10"
                throw t$157017;
            }
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            this.polyRep = ((x10.regionarray.Region)(t$144915));
        }
        
        //#line 313 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.Region t$157020 = ((x10.regionarray.Region)(this.polyRep));
        
        //#line 313 "x10/regionarray/RectRegion.x10"
        return t$157020;
    }
    
    
    //#line 317 "x10/regionarray/RectRegion.x10"
    public x10.regionarray.Region intersection(final x10.regionarray.Region that) {
        
        //#line 318 "x10/regionarray/RectRegion.x10"
        final boolean t$157076 = that.isEmpty$O();
        
        //#line 318 "x10/regionarray/RectRegion.x10"
        if (t$157076) {
            
            //#line 319 "x10/regionarray/RectRegion.x10"
            return that;
        } else {
            
            //#line 320 "x10/regionarray/RectRegion.x10"
            final boolean t$157075 = x10.regionarray.FullRegion.$RTT.isInstance(that);
            
            //#line 320 "x10/regionarray/RectRegion.x10"
            if (t$157075) {
                
                //#line 321 "x10/regionarray/RectRegion.x10"
                return this;
            } else {
                
                //#line 322 "x10/regionarray/RectRegion.x10"
                final boolean t$157074 = x10.regionarray.RectRegion.$RTT.isInstance(that);
                
                //#line 322 "x10/regionarray/RectRegion.x10"
                if (t$157074) {
                    
                    //#line 323 "x10/regionarray/RectRegion.x10"
                    final x10.regionarray.RectRegion this$156522 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
                    
                    //#line 223 . "x10/regionarray/RectRegion.x10"
                    x10.core.fun.Fun_0_1 ret$156523 =  null;
                    
                    //#line 223 . "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$157396 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$226(this$156522)));
                    
                    //#line 223 . "x10/regionarray/RectRegion.x10"
                    ret$156523 = ((x10.core.fun.Fun_0_1)(t$157396));
                    
                    //#line 323 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 thatMin = ret$156523;
                    
                    //#line 324 "x10/regionarray/RectRegion.x10"
                    final x10.regionarray.RectRegion this$156526 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
                    
                    //#line 224 . "x10/regionarray/RectRegion.x10"
                    x10.core.fun.Fun_0_1 ret$156527 =  null;
                    
                    //#line 224 . "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$157399 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$227(this$156526)));
                    
                    //#line 224 . "x10/regionarray/RectRegion.x10"
                    ret$156527 = ((x10.core.fun.Fun_0_1)(t$157399));
                    
                    //#line 324 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 thatMax = ret$156527;
                    
                    //#line 325 "x10/regionarray/RectRegion.x10"
                    final long t$157028 = this.rank;
                    
                    //#line 325 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$157029 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$228(this, thatMin, (x10.regionarray.RectRegion.$Closure$228.__1$1x10$lang$Long$3x10$lang$Long$2) null)));
                    
                    //#line 325 "x10/regionarray/RectRegion.x10"
                    final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157028)), ((x10.core.fun.Fun_0_1)(t$157029)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                    
                    //#line 326 "x10/regionarray/RectRegion.x10"
                    final long t$157033 = this.rank;
                    
                    //#line 326 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$157034 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$229(this, thatMax, (x10.regionarray.RectRegion.$Closure$229.__1$1x10$lang$Long$3x10$lang$Long$2) null)));
                    
                    //#line 326 "x10/regionarray/RectRegion.x10"
                    final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157033)), ((x10.core.fun.Fun_0_1)(t$157034)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                    
                    //#line 327 "x10/regionarray/RectRegion.x10"
                    final long t$157402 = ((x10.core.Rail<x10.core.Long>)newMin).size;
                    
                    //#line 327 "x10/regionarray/RectRegion.x10"
                    final long i$145515max$157403 = ((t$157402) - (((long)(1L))));
                    
                    //#line 327 "x10/regionarray/RectRegion.x10"
                    long i$157393 = 0L;
                    {
                        
                        //#line 327 "x10/regionarray/RectRegion.x10"
                        final long[] newMax$value$157497 = ((long[])newMax.value);
                        
                        //#line 327 "x10/regionarray/RectRegion.x10"
                        final long[] newMin$value$157498 = ((long[])newMin.value);
                        
                        //#line 327 "x10/regionarray/RectRegion.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 327 "x10/regionarray/RectRegion.x10"
                            final boolean t$157395 = ((i$157393) <= (((long)(i$145515max$157403))));
                            
                            //#line 327 "x10/regionarray/RectRegion.x10"
                            if (!(t$157395)) {
                                
                                //#line 327 "x10/regionarray/RectRegion.x10"
                                break;
                            }
                            
                            //#line 328 "x10/regionarray/RectRegion.x10"
                            final long t$157384 = ((long)newMax$value$157497[(int)i$157393]);
                            
                            //#line 328 "x10/regionarray/RectRegion.x10"
                            final long t$157385 = ((long)newMin$value$157498[(int)i$157393]);
                            
                            //#line 328 "x10/regionarray/RectRegion.x10"
                            final boolean t$157386 = ((t$157384) < (((long)(t$157385))));
                            
                            //#line 328 "x10/regionarray/RectRegion.x10"
                            if (t$157386) {
                                
                                //#line 328 "x10/regionarray/RectRegion.x10"
                                final long rank$157387 = this.rank;
                                
                                //#line 60 . "x10/regionarray/Region.x10"
                                final x10.regionarray.EmptyRegion alloc$157388 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
                                
                                //#line 60 . "x10/regionarray/Region.x10"
                                alloc$157388.x10$regionarray$EmptyRegion$$init$S(((long)(rank$157387)));
                                
                                //#line 60 . "x10/regionarray/Region.x10"
                                final x10.regionarray.Region t$157389 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                                    alloc$157388)));
                                
                                //#line 328 "x10/regionarray/RectRegion.x10"
                                return t$157389;
                            }
                            
                            //#line 327 "x10/regionarray/RectRegion.x10"
                            final long t$157392 = ((i$157393) + (((long)(1L))));
                            
                            //#line 327 "x10/regionarray/RectRegion.x10"
                            i$157393 = t$157392;
                        }
                    }
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    final x10.regionarray.RectRegion alloc$145413 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    alloc$145413.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    final x10.regionarray.Region t$144933 = ((x10.regionarray.Region)
                                                              alloc$145413);
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    final long t$157045 = t$144933.rank;
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    final long t$157046 = x10.regionarray.RectRegion.this.rank;
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    final boolean t$157047 = ((long) t$157045) == ((long) t$157046);
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    final boolean t$157049 = !(t$157047);
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    if (t$157049) {
                        
                        //#line 330 "x10/regionarray/RectRegion.x10"
                        final x10.lang.FailedDynamicCheckException t$157048 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.RectRegion).rank}");
                        
                        //#line 330 "x10/regionarray/RectRegion.x10"
                        throw t$157048;
                    }
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    return t$144933;
                } else {
                    
                    //#line 331 "x10/regionarray/RectRegion.x10"
                    final boolean t$157073 = x10.regionarray.RectRegion1D.$RTT.isInstance(that);
                    
                    //#line 331 "x10/regionarray/RectRegion.x10"
                    if (t$157073) {
                        
                        //#line 332 "x10/regionarray/RectRegion.x10"
                        final long t$157050 = this.min$O((long)(0L));
                        
                        //#line 332 "x10/regionarray/RectRegion.x10"
                        final long t$157051 = that.min$O((long)(0L));
                        
                        //#line 332 "x10/regionarray/RectRegion.x10"
                        final long newMin = java.lang.Math.max(((long)(t$157050)),((long)(t$157051)));
                        
                        //#line 333 "x10/regionarray/RectRegion.x10"
                        final long t$157052 = this.max$O((long)(0L));
                        
                        //#line 333 "x10/regionarray/RectRegion.x10"
                        final long t$157053 = that.max$O((long)(0L));
                        
                        //#line 333 "x10/regionarray/RectRegion.x10"
                        final long newMax = java.lang.Math.min(((long)(t$157052)),((long)(t$157053)));
                        
                        //#line 334 "x10/regionarray/RectRegion.x10"
                        final boolean t$157060 = ((newMax) < (((long)(newMin))));
                        
                        //#line 334 "x10/regionarray/RectRegion.x10"
                        if (t$157060) {
                            
                            //#line 60 . "x10/regionarray/Region.x10"
                            final x10.regionarray.EmptyRegion alloc$156533 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
                            
                            //#line 60 . "x10/regionarray/Region.x10"
                            alloc$156533.x10$regionarray$EmptyRegion$$init$S(((long)(1L)));
                            
                            //#line 60 . "x10/regionarray/Region.x10"
                            final x10.regionarray.Region t$157054 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                                alloc$156533)));
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            final x10.regionarray.Region t$144942 = ((x10.regionarray.Region)
                                                                      t$157054);
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            final long t$157055 = t$144942.rank;
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            final long t$157056 = x10.regionarray.RectRegion.this.rank;
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            final boolean t$157057 = ((long) t$157055) == ((long) t$157056);
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            final boolean t$157059 = !(t$157057);
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            if (t$157059) {
                                
                                //#line 334 "x10/regionarray/RectRegion.x10"
                                final x10.lang.FailedDynamicCheckException t$157058 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.RectRegion).rank}");
                                
                                //#line 334 "x10/regionarray/RectRegion.x10"
                                throw t$157058;
                            }
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            return t$144942;
                        }
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.RectRegion1D alloc$145414 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        alloc$145414.x10$regionarray$RectRegion1D$$init$S(((long)(newMin)), ((long)(newMax)));
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$144944 = ((x10.regionarray.Region)
                                                                  alloc$145414);
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        final long t$157061 = t$144944.rank;
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        final long t$157062 = x10.regionarray.RectRegion.this.rank;
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        final boolean t$157063 = ((long) t$157061) == ((long) t$157062);
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        final boolean t$157065 = !(t$157063);
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        if (t$157065) {
                            
                            //#line 335 "x10/regionarray/RectRegion.x10"
                            final x10.lang.FailedDynamicCheckException t$157064 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.RectRegion).rank}");
                            
                            //#line 335 "x10/regionarray/RectRegion.x10"
                            throw t$157064;
                        }
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        return t$144944;
                    } else {
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$157066 = ((x10.regionarray.Region)(this.toPolyRegion()));
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$144946 = ((x10.regionarray.Region)
                                                                  t$157066);
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final long t$157067 = t$144946.rank;
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final long t$157068 = x10.regionarray.RectRegion.this.rank;
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final boolean t$157069 = ((long) t$157067) == ((long) t$157068);
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final boolean t$157071 = !(t$157069);
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        if (t$157071) {
                            
                            //#line 338 "x10/regionarray/RectRegion.x10"
                            final x10.lang.FailedDynamicCheckException t$157070 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.RectRegion).rank}");
                            
                            //#line 338 "x10/regionarray/RectRegion.x10"
                            throw t$157070;
                        }
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$157072 = ((x10.regionarray.Region)(t$144946.intersection(((x10.regionarray.Region)(that)))));
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        return t$157072;
                    }
                }
            }
        }
    }
    
    
    //#line 344 "x10/regionarray/RectRegion.x10"
    public x10.regionarray.Region product(final x10.regionarray.Region that) {
        
        //#line 345 "x10/regionarray/RectRegion.x10"
        final boolean t$157133 = that.isEmpty$O();
        
        //#line 345 "x10/regionarray/RectRegion.x10"
        if (t$157133) {
            
            //#line 346 "x10/regionarray/RectRegion.x10"
            final long t$157077 = this.rank;
            
            //#line 346 "x10/regionarray/RectRegion.x10"
            final long t$157078 = that.rank;
            
            //#line 346 "x10/regionarray/RectRegion.x10"
            final long rank$156535 = ((t$157077) + (((long)(t$157078))));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.EmptyRegion alloc$156536 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            alloc$156536.x10$regionarray$EmptyRegion$$init$S(((long)(rank$156535)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$157079 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$156536)));
            
            //#line 346 "x10/regionarray/RectRegion.x10"
            return t$157079;
        } else {
            
            //#line 347 "x10/regionarray/RectRegion.x10"
            final boolean t$157132 = x10.regionarray.RectRegion.$RTT.isInstance(that);
            
            //#line 347 "x10/regionarray/RectRegion.x10"
            if (t$157132) {
                
                //#line 348 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.RectRegion this$156539 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                x10.core.fun.Fun_0_1 ret$156540 =  null;
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$157404 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$230(this$156539)));
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                ret$156540 = ((x10.core.fun.Fun_0_1)(t$157404));
                
                //#line 348 "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 thatMin = ret$156540;
                
                //#line 349 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.RectRegion this$156543 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                x10.core.fun.Fun_0_1 ret$156544 =  null;
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$157407 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$231(this$156543)));
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                ret$156544 = ((x10.core.fun.Fun_0_1)(t$157407));
                
                //#line 349 "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 thatMax = ret$156544;
                
                //#line 350 "x10/regionarray/RectRegion.x10"
                final long t$157084 = this.rank;
                
                //#line 350 "x10/regionarray/RectRegion.x10"
                final long t$157085 = that.rank;
                
                //#line 350 "x10/regionarray/RectRegion.x10"
                final long k = ((t$157084) + (((long)(t$157085))));
                
                //#line 351 "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$157092 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$232(this, this.rank, thatMin, (x10.regionarray.RectRegion.$Closure$232.__2$1x10$lang$Long$3x10$lang$Long$2) null)));
                
                //#line 351 "x10/regionarray/RectRegion.x10"
                final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157092)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                
                //#line 352 "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$157099 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$233(this, this.rank, thatMax, (x10.regionarray.RectRegion.$Closure$233.__2$1x10$lang$Long$3x10$lang$Long$2) null)));
                
                //#line 352 "x10/regionarray/RectRegion.x10"
                final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157099)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                
                //#line 353 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.RectRegion alloc$145415 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
                
                //#line 353 "x10/regionarray/RectRegion.x10"
                alloc$145415.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
                
                //#line 353 "x10/regionarray/RectRegion.x10"
                return alloc$145415;
            } else {
                
                //#line 354 "x10/regionarray/RectRegion.x10"
                final boolean t$157131 = x10.regionarray.RectRegion1D.$RTT.isInstance(that);
                
                //#line 354 "x10/regionarray/RectRegion.x10"
                if (t$157131) {
                    
                    //#line 355 "x10/regionarray/RectRegion.x10"
                    final long thatMin = that.min$O((long)(0L));
                    
                    //#line 356 "x10/regionarray/RectRegion.x10"
                    final long thatMax = that.max$O((long)(0L));
                    
                    //#line 357 "x10/regionarray/RectRegion.x10"
                    final long t$157100 = this.rank;
                    
                    //#line 357 "x10/regionarray/RectRegion.x10"
                    final long k = ((t$157100) + (((long)(1L))));
                    
                    //#line 358 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$157105 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$234(this, this.rank, thatMin)));
                    
                    //#line 358 "x10/regionarray/RectRegion.x10"
                    final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157105)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                    
                    //#line 359 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$157110 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$235(this, this.rank, thatMax)));
                    
                    //#line 359 "x10/regionarray/RectRegion.x10"
                    final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157110)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                    
                    //#line 360 "x10/regionarray/RectRegion.x10"
                    final x10.regionarray.RectRegion alloc$145416 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
                    
                    //#line 360 "x10/regionarray/RectRegion.x10"
                    alloc$145416.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
                    
                    //#line 360 "x10/regionarray/RectRegion.x10"
                    return alloc$145416;
                } else {
                    
                    //#line 361 "x10/regionarray/RectRegion.x10"
                    final boolean t$157130 = x10.regionarray.FullRegion.$RTT.isInstance(that);
                    
                    //#line 361 "x10/regionarray/RectRegion.x10"
                    if (t$157130) {
                        
                        //#line 362 "x10/regionarray/RectRegion.x10"
                        final long t$157111 = this.rank;
                        
                        //#line 362 "x10/regionarray/RectRegion.x10"
                        final long t$157112 = that.rank;
                        
                        //#line 362 "x10/regionarray/RectRegion.x10"
                        final long k = ((t$157111) + (((long)(t$157112))));
                        
                        //#line 363 "x10/regionarray/RectRegion.x10"
                        final x10.core.fun.Fun_0_1 t$157117 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$236(this, this.rank)));
                        
                        //#line 363 "x10/regionarray/RectRegion.x10"
                        final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157117)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                        
                        //#line 364 "x10/regionarray/RectRegion.x10"
                        final x10.core.fun.Fun_0_1 t$157122 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$237(this, this.rank)));
                        
                        //#line 364 "x10/regionarray/RectRegion.x10"
                        final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157122)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                        
                        //#line 365 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.RectRegion alloc$145417 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
                        
                        //#line 365 "x10/regionarray/RectRegion.x10"
                        alloc$145417.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
                        
                        //#line 365 "x10/regionarray/RectRegion.x10"
                        return alloc$145417;
                    } else {
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$157123 = ((x10.regionarray.Region)(this.toPolyRegion()));
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$145032 = ((x10.regionarray.Region)
                                                                  t$157123);
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final long t$157124 = t$145032.rank;
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final long t$157125 = x10.regionarray.RectRegion.this.rank;
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final boolean t$157126 = ((long) t$157124) == ((long) t$157125);
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final boolean t$157128 = !(t$157126);
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        if (t$157128) {
                            
                            //#line 367 "x10/regionarray/RectRegion.x10"
                            final x10.lang.FailedDynamicCheckException t$157127 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.RectRegion).rank}");
                            
                            //#line 367 "x10/regionarray/RectRegion.x10"
                            throw t$157127;
                        }
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$157129 = ((x10.regionarray.Region)(t$145032.product(((x10.regionarray.Region)(that)))));
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        return t$157129;
                    }
                }
            }
        }
    }
    
    
    //#line 371 "x10/regionarray/RectRegion.x10"
    public x10.regionarray.Region translate(final x10.lang.Point v) {
        
        //#line 372 "x10/regionarray/RectRegion.x10"
        final long t$157137 = this.rank;
        
        //#line 372 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157138 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$238(this, v)));
        
        //#line 372 "x10/regionarray/RectRegion.x10"
        final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157137)), ((x10.core.fun.Fun_0_1)(t$157138)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 373 "x10/regionarray/RectRegion.x10"
        final long t$157142 = this.rank;
        
        //#line 373 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157143 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$239(this, v)));
        
        //#line 373 "x10/regionarray/RectRegion.x10"
        final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157142)), ((x10.core.fun.Fun_0_1)(t$157143)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion alloc$145418 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        alloc$145418.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.Region t$145048 = ((x10.regionarray.Region)
                                                  alloc$145418);
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        final boolean t$157144 = t$145048.rect;
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        boolean t$157147 = ((boolean) t$157144) == ((boolean) true);
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        if (t$157147) {
            
            //#line 374 "x10/regionarray/RectRegion.x10"
            final long t$157145 = t$145048.rank;
            
            //#line 374 "x10/regionarray/RectRegion.x10"
            final long t$157146 = x10.regionarray.RectRegion.this.rank;
            
            //#line 374 "x10/regionarray/RectRegion.x10"
            t$157147 = ((long) t$157145) == ((long) t$157146);
        }
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        final boolean t$157150 = !(t$157147);
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        if (t$157150) {
            
            //#line 374 "x10/regionarray/RectRegion.x10"
            final x10.lang.FailedDynamicCheckException t$157149 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==this(:x10.regionarray.RectRegion).rank}");
            
            //#line 374 "x10/regionarray/RectRegion.x10"
            throw t$157149;
        }
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        return t$145048;
    }
    
    
    //#line 377 "x10/regionarray/RectRegion.x10"
    public x10.regionarray.Region projection(final long axis) {
        
        //#line 378 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion alloc$145419 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 378 "x10/regionarray/RectRegion.x10"
        final long min$156546 = this.min$O((long)(axis));
        
        //#line 378 "x10/regionarray/RectRegion.x10"
        final long max$156547 = this.max$O((long)(axis));
        
        //#line 105 . "x10/regionarray/RectRegion.x10"
        final boolean z$157411 = ((long) min$156546) == ((long) 0L);
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$145419.rank = 1L;
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$145419.rect = true;
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$145419.zeroBased = z$157411;
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$145419.rail = z$157411;
        
        //#line 21 .. "x10/regionarray/RectRegion.x10"
        alloc$145419.polyRep = null;
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        final long t$157412 = java.lang.Long.MIN_VALUE;
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        boolean t$157413 = ((long) min$156546) == ((long) t$157412);
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        if (t$157413) {
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            final long t$157414 = java.lang.Long.MAX_VALUE;
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            t$157413 = ((long) max$156547) == ((long) t$157414);
        }
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        long t$157416 =  0;
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        if (t$157413) {
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            t$157416 = -1L;
        } else {
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            final long t$157417 = ((max$156547) - (((long)(min$156546))));
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            t$157416 = ((t$157417) + (((long)(1L))));
        }
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        alloc$145419.size = t$157416;
        
        //#line 108 . "x10/regionarray/RectRegion.x10"
        alloc$145419.min0 = min$156546;
        
        //#line 109 . "x10/regionarray/RectRegion.x10"
        alloc$145419.max0 = max$156547;
        
        //#line 111 . "x10/regionarray/RectRegion.x10"
        final long t$157419 = alloc$145419.min3 = 0L;
        
        //#line 111 . "x10/regionarray/RectRegion.x10"
        final long t$157420 = alloc$145419.min2 = t$157419;
        
        //#line 111 . "x10/regionarray/RectRegion.x10"
        alloc$145419.min1 = t$157420;
        
        //#line 112 . "x10/regionarray/RectRegion.x10"
        final long t$157421 = alloc$145419.max3 = 0L;
        
        //#line 112 . "x10/regionarray/RectRegion.x10"
        final long t$157422 = alloc$145419.max2 = t$157421;
        
        //#line 112 . "x10/regionarray/RectRegion.x10"
        alloc$145419.max1 = t$157422;
        
        //#line 113 . "x10/regionarray/RectRegion.x10"
        alloc$145419.mins = null;
        
        //#line 114 . "x10/regionarray/RectRegion.x10"
        alloc$145419.maxs = null;
        
        //#line 378 "x10/regionarray/RectRegion.x10"
        return alloc$145419;
    }
    
    
    //#line 381 "x10/regionarray/RectRegion.x10"
    public x10.regionarray.Region eliminate(final long axis) {
        
        //#line 382 "x10/regionarray/RectRegion.x10"
        final long t$157162 = this.rank;
        
        //#line 382 "x10/regionarray/RectRegion.x10"
        final long k = ((t$157162) - (((long)(1L))));
        
        //#line 383 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157167 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$240(this, axis)));
        
        //#line 383 "x10/regionarray/RectRegion.x10"
        final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157167)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 384 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157172 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$241(this, axis)));
        
        //#line 384 "x10/regionarray/RectRegion.x10"
        final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157172)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 385 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion alloc$145420 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 385 "x10/regionarray/RectRegion.x10"
        alloc$145420.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 385 "x10/regionarray/RectRegion.x10"
        return alloc$145420;
    }
    
    
    //#line 389 "x10/regionarray/RectRegion.x10"
    @x10.runtime.impl.java.X10Generated
    public static class RRIterator extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<RRIterator> $RTT = 
            x10.rtt.NamedType.<RRIterator> make("x10.regionarray.RectRegion.RRIterator",
                                                RRIterator.class,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                                });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.RRIterator $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur = $deserializer.readObject();
            $_obj.done = $deserializer.readBoolean();
            $_obj.max = $deserializer.readObject();
            $_obj.min = $deserializer.readObject();
            $_obj.myRank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.RRIterator $_obj = new x10.regionarray.RectRegion.RRIterator((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur);
            $serializer.write(this.done);
            $serializer.write(this.max);
            $serializer.write(this.min);
            $serializer.write(this.myRank);
            
        }
        
        // constructor just for allocation
        public RRIterator(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.lang.Point next$G() {
            return next();
        }
        
        
        // properties
        
        //#line 389 "x10/regionarray/RectRegion.x10"
        public long myRank;
        
    
        
        //#line 390 "x10/regionarray/RectRegion.x10"
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> min;
        
        //#line 391 "x10/regionarray/RectRegion.x10"
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> max;
        
        //#line 392 "x10/regionarray/RectRegion.x10"
        public boolean done;
        
        //#line 393 "x10/regionarray/RectRegion.x10"
        public x10.core.Rail<x10.core.Long> cur;
        
        
        //#line 395 "x10/regionarray/RectRegion.x10"
        // creation method for java code (1-phase java constructor)
        public RRIterator(final x10.regionarray.RectRegion rr) {
            this((java.lang.System[]) null);
            x10$regionarray$RectRegion$RRIterator$$init$S(rr);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.RectRegion.RRIterator x10$regionarray$RectRegion$RRIterator$$init$S(final x10.regionarray.RectRegion rr) {
             {
                
                //#line 396 "x10/regionarray/RectRegion.x10"
                final long t$157423 = rr.rank;
                
                //#line 396 "x10/regionarray/RectRegion.x10"
                this.myRank = t$157423;
                
                
                //#line 389 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.RectRegion.RRIterator this$157424 = this;
                
                //#line 389 "x10/regionarray/RectRegion.x10"
                this$157424.done = false;
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                x10.core.fun.Fun_0_1 ret$156559 =  null;
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$157425 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.RRIterator.$Closure$217(rr)));
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                ret$156559 = ((x10.core.fun.Fun_0_1)(t$157425));
                
                //#line 397 "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t = ret$156559;
                
                //#line 398 "x10/regionarray/RectRegion.x10"
                this.min = ((x10.core.fun.Fun_0_1)(ret$156559));
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                x10.core.fun.Fun_0_1 ret$156562 =  null;
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$157428 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.RRIterator.$Closure$218(rr)));
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                ret$156562 = ((x10.core.fun.Fun_0_1)(t$157428));
                
                //#line 399 "x10/regionarray/RectRegion.x10"
                this.max = ((x10.core.fun.Fun_0_1)(ret$156562));
                
                //#line 400 "x10/regionarray/RectRegion.x10"
                final long t$157179 = rr.size;
                
                //#line 400 "x10/regionarray/RectRegion.x10"
                final boolean t$157180 = ((long) t$157179) == ((long) 0L);
                
                //#line 400 "x10/regionarray/RectRegion.x10"
                this.done = t$157180;
                
                //#line 401 "x10/regionarray/RectRegion.x10"
                final long t$157182 = this.myRank;
                
                //#line 401 "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$157183 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.RRIterator.$Closure$219(t, (x10.regionarray.RectRegion.RRIterator.$Closure$219.__0$1x10$lang$Long$3x10$lang$Long$2) null)));
                
                //#line 401 "x10/regionarray/RectRegion.x10"
                final x10.core.Rail t$157184 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157182)), ((x10.core.fun.Fun_0_1)(t$157183)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                
                //#line 401 "x10/regionarray/RectRegion.x10"
                this.cur = ((x10.core.Rail)(t$157184));
            }
            return this;
        }
        
        
        
        //#line 404 "x10/regionarray/RectRegion.x10"
        public boolean hasNext$O() {
            
            //#line 404 "x10/regionarray/RectRegion.x10"
            final boolean t$157185 = this.done;
            
            //#line 404 "x10/regionarray/RectRegion.x10"
            final boolean t$157186 = !(t$157185);
            
            //#line 404 "x10/regionarray/RectRegion.x10"
            return t$157186;
        }
        
        
        //#line 406 "x10/regionarray/RectRegion.x10"
        public x10.lang.Point next() {
            
            //#line 407 "x10/regionarray/RectRegion.x10"
            final x10.core.Rail t$157187 = ((x10.core.Rail)(this.cur));
            
            //#line 407 "x10/regionarray/RectRegion.x10"
            final x10.lang.Point ans = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(t$157187)))));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final x10.core.Rail t$157189 = ((x10.core.Rail)(this.cur));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final long t$157188 = this.myRank;
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final long t$157190 = ((t$157188) - (((long)(1L))));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final long t$157194 = ((long[])t$157189.value)[(int)t$157190];
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final x10.core.fun.Fun_0_1 t$157192 = ((x10.core.fun.Fun_0_1)(this.max));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final long t$157191 = this.myRank;
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final long t$157193 = ((t$157191) - (((long)(1L))));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final long t$157195 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$157192).$apply(x10.core.Long.$box(t$157193), x10.rtt.Types.LONG));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final boolean t$157236 = ((t$157194) < (((long)(t$157195))));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            if (t$157236) {
                
                //#line 409 "x10/regionarray/RectRegion.x10"
                final x10.core.Rail a$145115 = ((x10.core.Rail)(this.cur));
                
                //#line 409 "x10/regionarray/RectRegion.x10"
                final long t$157196 = this.myRank;
                
                //#line 409 "x10/regionarray/RectRegion.x10"
                final long i0$145116 = ((t$157196) - (((long)(1L))));
                
                //#line 409 "x10/regionarray/RectRegion.x10"
                final long t$157197 = ((long[])a$145115.value)[(int)i0$145116];
                
                //#line 409 "x10/regionarray/RectRegion.x10"
                final long r$145124 = ((t$157197) + (((long)(1L))));
                
                //#line 409 "x10/regionarray/RectRegion.x10"
                ((long[])a$145115.value)[(int)i0$145116] = r$145124;
            } else {
                
                //#line 411 "x10/regionarray/RectRegion.x10"
                final long t$157198 = this.myRank;
                
                //#line 411 "x10/regionarray/RectRegion.x10"
                final boolean t$157235 = ((long) t$157198) == ((long) 1L);
                
                //#line 411 "x10/regionarray/RectRegion.x10"
                if (t$157235) {
                    
                    //#line 412 "x10/regionarray/RectRegion.x10"
                    this.done = true;
                } else {
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final x10.core.Rail t$157203 = ((x10.core.Rail)(this.cur));
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final long t$157199 = this.myRank;
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final long t$157204 = ((t$157199) - (((long)(1L))));
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$157201 = ((x10.core.fun.Fun_0_1)(this.min));
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final long t$157200 = this.myRank;
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final long t$157202 = ((t$157200) - (((long)(1L))));
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final long t$157205 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$157201).$apply(x10.core.Long.$box(t$157202), x10.rtt.Types.LONG));
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    ((long[])t$157203.value)[(int)t$157204] = t$157205;
                    
                    //#line 416 "x10/regionarray/RectRegion.x10"
                    final x10.core.Rail a$145148 = ((x10.core.Rail)(this.cur));
                    
                    //#line 416 "x10/regionarray/RectRegion.x10"
                    final long t$157206 = this.myRank;
                    
                    //#line 416 "x10/regionarray/RectRegion.x10"
                    final long i0$145149 = ((t$157206) - (((long)(2L))));
                    
                    //#line 416 "x10/regionarray/RectRegion.x10"
                    final long t$157207 = ((long[])a$145148.value)[(int)i0$145149];
                    
                    //#line 416 "x10/regionarray/RectRegion.x10"
                    final long r$145157 = ((t$157207) + (((long)(1L))));
                    
                    //#line 416 "x10/regionarray/RectRegion.x10"
                    ((long[])a$145148.value)[(int)i0$145149] = r$145157;
                    
                    //#line 417 "x10/regionarray/RectRegion.x10"
                    final long t$157208 = this.myRank;
                    
                    //#line 417 "x10/regionarray/RectRegion.x10"
                    long carryRank = ((t$157208) - (((long)(2L))));
                    
                    //#line 418 "x10/regionarray/RectRegion.x10"
                    while (true) {
                        
                        //#line 418 "x10/regionarray/RectRegion.x10"
                        boolean t$157216 = ((carryRank) > (((long)(0L))));
                        
                        //#line 418 "x10/regionarray/RectRegion.x10"
                        if (t$157216) {
                            
                            //#line 418 "x10/regionarray/RectRegion.x10"
                            final x10.core.Rail t$157210 = ((x10.core.Rail)(this.cur));
                            
                            //#line 418 "x10/regionarray/RectRegion.x10"
                            final long t$157214 = ((long[])t$157210.value)[(int)carryRank];
                            
                            //#line 418 "x10/regionarray/RectRegion.x10"
                            final x10.core.fun.Fun_0_1 t$157212 = ((x10.core.fun.Fun_0_1)(this.max));
                            
                            //#line 418 "x10/regionarray/RectRegion.x10"
                            final long t$157215 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$157212).$apply(x10.core.Long.$box(carryRank), x10.rtt.Types.LONG));
                            
                            //#line 418 "x10/regionarray/RectRegion.x10"
                            t$157216 = ((t$157214) > (((long)(t$157215))));
                        }
                        
                        //#line 418 "x10/regionarray/RectRegion.x10"
                        if (!(t$157216)) {
                            
                            //#line 418 "x10/regionarray/RectRegion.x10"
                            break;
                        }
                        
                        //#line 419 "x10/regionarray/RectRegion.x10"
                        final x10.core.Rail t$157431 = ((x10.core.Rail)(this.cur));
                        
                        //#line 419 "x10/regionarray/RectRegion.x10"
                        final x10.core.fun.Fun_0_1 t$157433 = ((x10.core.fun.Fun_0_1)(this.min));
                        
                        //#line 419 "x10/regionarray/RectRegion.x10"
                        final long t$157435 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$157433).$apply(x10.core.Long.$box(carryRank), x10.rtt.Types.LONG));
                        
                        //#line 419 "x10/regionarray/RectRegion.x10"
                        ((long[])t$157431.value)[(int)carryRank] = t$157435;
                        
                        //#line 420 "x10/regionarray/RectRegion.x10"
                        final x10.core.Rail a$157436 = ((x10.core.Rail)(this.cur));
                        
                        //#line 420 "x10/regionarray/RectRegion.x10"
                        final long t$157438 = ((long)(((int)(1))));
                        
                        //#line 420 "x10/regionarray/RectRegion.x10"
                        final long i$157439 = ((carryRank) - (((long)(t$157438))));
                        
                        //#line 420 "x10/regionarray/RectRegion.x10"
                        final long t$157440 = ((long[])a$157436.value)[(int)i$157439];
                        
                        //#line 420 "x10/regionarray/RectRegion.x10"
                        final long r$157441 = ((t$157440) + (((long)(1L))));
                        
                        //#line 420 "x10/regionarray/RectRegion.x10"
                        ((long[])a$157436.value)[(int)i$157439] = r$157441;
                        
                        //#line 421 "x10/regionarray/RectRegion.x10"
                        final long t$157443 = ((carryRank) - (((long)(1L))));
                        
                        //#line 421 "x10/regionarray/RectRegion.x10"
                        carryRank = t$157443;
                    }
                    
                    //#line 423 "x10/regionarray/RectRegion.x10"
                    boolean t$157233 = ((long) carryRank) == ((long) 0L);
                    
                    //#line 423 "x10/regionarray/RectRegion.x10"
                    if (t$157233) {
                        
                        //#line 423 "x10/regionarray/RectRegion.x10"
                        final x10.core.Rail t$157229 = ((x10.core.Rail)(this.cur));
                        
                        //#line 423 "x10/regionarray/RectRegion.x10"
                        final long t$157231 = ((long[])t$157229.value)[(int)0L];
                        
                        //#line 423 "x10/regionarray/RectRegion.x10"
                        final x10.core.fun.Fun_0_1 t$157230 = ((x10.core.fun.Fun_0_1)(this.max));
                        
                        //#line 423 "x10/regionarray/RectRegion.x10"
                        final long t$157232 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$157230).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                        
                        //#line 423 "x10/regionarray/RectRegion.x10"
                        t$157233 = ((t$157231) > (((long)(t$157232))));
                    }
                    
                    //#line 423 "x10/regionarray/RectRegion.x10"
                    if (t$157233) {
                        
                        //#line 424 "x10/regionarray/RectRegion.x10"
                        this.done = true;
                    }
                }
            }
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            final x10.lang.Point t$145212 = ((x10.lang.Point)
                                              ans);
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            final long t$157237 = t$145212.rank;
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            final long t$157238 = x10.regionarray.RectRegion.RRIterator.this.myRank;
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            final boolean t$157239 = ((long) t$157237) == ((long) t$157238);
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            final boolean t$157241 = !(t$157239);
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            if (t$157241) {
                
                //#line 428 "x10/regionarray/RectRegion.x10"
                final x10.lang.FailedDynamicCheckException t$157240 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==this(:x10.regionarray.RectRegion.RRIterator).myRank}");
                
                //#line 428 "x10/regionarray/RectRegion.x10"
                throw t$157240;
            }
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            return t$145212;
        }
        
        
        //#line 389 "x10/regionarray/RectRegion.x10"
        final public x10.regionarray.RectRegion.RRIterator x10$regionarray$RectRegion$RRIterator$$this$x10$regionarray$RectRegion$RRIterator() {
            
            //#line 389 "x10/regionarray/RectRegion.x10"
            return x10.regionarray.RectRegion.RRIterator.this;
        }
        
        
        //#line 389 "x10/regionarray/RectRegion.x10"
        final public void __fieldInitializers_x10_regionarray_RectRegion_RRIterator() {
            
            //#line 389 "x10/regionarray/RectRegion.x10"
            this.done = false;
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$217 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$217> $RTT = 
                x10.rtt.StaticFunType.<$Closure$217> make($Closure$217.class,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                          });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.RRIterator.$Closure$217 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.rr = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.regionarray.RectRegion.RRIterator.$Closure$217 $_obj = new x10.regionarray.RectRegion.RRIterator.$Closure$217((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.rr);
                
            }
            
            // constructor just for allocation
            public $Closure$217(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
                return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
                return $apply$O(x10.core.Long.$unbox(a1));
                
            }
            
            
        
            
            public long $apply$O(final long i$157426) {
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                final long t$157427 = this.rr.min$O((long)(i$157426));
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                return t$157427;
            }
            
            public x10.regionarray.RectRegion rr;
            
            public $Closure$217(final x10.regionarray.RectRegion rr) {
                 {
                    this.rr = rr;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$218 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$218> $RTT = 
                x10.rtt.StaticFunType.<$Closure$218> make($Closure$218.class,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                          });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.RRIterator.$Closure$218 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.rr = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.regionarray.RectRegion.RRIterator.$Closure$218 $_obj = new x10.regionarray.RectRegion.RRIterator.$Closure$218((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.rr);
                
            }
            
            // constructor just for allocation
            public $Closure$218(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
                return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
                return $apply$O(x10.core.Long.$unbox(a1));
                
            }
            
            
        
            
            public long $apply$O(final long i$157429) {
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                final long t$157430 = this.rr.max$O((long)(i$157429));
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                return t$157430;
            }
            
            public x10.regionarray.RectRegion rr;
            
            public $Closure$218(final x10.regionarray.RectRegion rr) {
                 {
                    this.rr = rr;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$219 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$219> $RTT = 
                x10.rtt.StaticFunType.<$Closure$219> make($Closure$219.class,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                          });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.RRIterator.$Closure$219 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.t = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.regionarray.RectRegion.RRIterator.$Closure$219 $_obj = new x10.regionarray.RectRegion.RRIterator.$Closure$219((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.t);
                
            }
            
            // constructor just for allocation
            public $Closure$219(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
                return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
                return $apply$O(x10.core.Long.$unbox(a1));
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public long $apply$O(final long l) {
                
                //#line 401 "x10/regionarray/RectRegion.x10"
                final long t$157181 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.t).$apply(x10.core.Long.$box(l), x10.rtt.Types.LONG));
                
                //#line 401 "x10/regionarray/RectRegion.x10"
                return t$157181;
            }
            
            public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> t;
            
            public $Closure$219(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> t, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.t = ((x10.core.fun.Fun_0_1)(t));
                }
            }
            
        }
        
    }
    
    
    
    //#line 431 "x10/regionarray/RectRegion.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 432 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion.RRIterator alloc$145421 = ((x10.regionarray.RectRegion.RRIterator)(new x10.regionarray.RectRegion.RRIterator((java.lang.System[]) null)));
        
        //#line 432 "x10/regionarray/RectRegion.x10"
        alloc$145421.x10$regionarray$RectRegion$RRIterator$$init$S(((x10.regionarray.RectRegion)(this)));
        
        //#line 432 "x10/regionarray/RectRegion.x10"
        return alloc$145421;
    }
    
    
    //#line 436 "x10/regionarray/RectRegion.x10"
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 437 "x10/regionarray/RectRegion.x10"
        final boolean t$157242 = x10.rtt.Equality.equalsequals((this),(thatObj));
        
        //#line 437 "x10/regionarray/RectRegion.x10"
        if (t$157242) {
            
            //#line 437 "x10/regionarray/RectRegion.x10"
            return true;
        }
        
        //#line 438 "x10/regionarray/RectRegion.x10"
        final boolean t$157243 = x10.regionarray.Region.$RTT.isInstance(thatObj);
        
        //#line 438 "x10/regionarray/RectRegion.x10"
        final boolean t$157244 = !(t$157243);
        
        //#line 438 "x10/regionarray/RectRegion.x10"
        if (t$157244) {
            
            //#line 438 "x10/regionarray/RectRegion.x10"
            return false;
        }
        
        //#line 439 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.Region that = x10.rtt.Types.<x10.regionarray.Region> cast(thatObj,x10.regionarray.Region.$RTT);
        
        //#line 442 "x10/regionarray/RectRegion.x10"
        final boolean t$157245 = x10.regionarray.RectRegion.$RTT.isInstance(that);
        
        //#line 442 "x10/regionarray/RectRegion.x10"
        final boolean t$157247 = !(t$157245);
        
        //#line 442 "x10/regionarray/RectRegion.x10"
        if (t$157247) {
            
            //#line 443 "x10/regionarray/RectRegion.x10"
            final boolean t$157246 = super.equals(((java.lang.Object)(that)));
            
            //#line 443 "x10/regionarray/RectRegion.x10"
            return t$157246;
        }
        
        //#line 446 "x10/regionarray/RectRegion.x10"
        final long t$157248 = this.rank;
        
        //#line 446 "x10/regionarray/RectRegion.x10"
        final long t$157249 = that.rank;
        
        //#line 446 "x10/regionarray/RectRegion.x10"
        final boolean t$157250 = ((long) t$157248) != ((long) t$157249);
        
        //#line 446 "x10/regionarray/RectRegion.x10"
        if (t$157250) {
            
            //#line 447 "x10/regionarray/RectRegion.x10"
            return false;
        }
        
        //#line 450 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$156565 = ((x10.regionarray.RectRegion)(this));
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        x10.core.fun.Fun_0_1 ret$156566 =  null;
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157456 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$242(this$156565)));
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        ret$156566 = ((x10.core.fun.Fun_0_1)(t$157456));
        
        //#line 450 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 thisMin = ret$156566;
        
        //#line 451 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$156569 = ((x10.regionarray.RectRegion)(this));
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        x10.core.fun.Fun_0_1 ret$156570 =  null;
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157459 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$243(this$156569)));
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        ret$156570 = ((x10.core.fun.Fun_0_1)(t$157459));
        
        //#line 451 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 thisMax = ret$156570;
        
        //#line 452 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$156573 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        x10.core.fun.Fun_0_1 ret$156574 =  null;
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157462 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$244(this$156573)));
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        ret$156574 = ((x10.core.fun.Fun_0_1)(t$157462));
        
        //#line 452 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 thatMin = ret$156574;
        
        //#line 453 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$156577 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        x10.core.fun.Fun_0_1 ret$156578 =  null;
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157465 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$245(this$156577)));
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        ret$156578 = ((x10.core.fun.Fun_0_1)(t$157465));
        
        //#line 456 "x10/regionarray/RectRegion.x10"
        final long t$157468 = this.rank;
        
        //#line 456 "x10/regionarray/RectRegion.x10"
        final long i$145533max$157469 = ((t$157468) - (((long)(1L))));
        
        //#line 456 "x10/regionarray/RectRegion.x10"
        long i$157453 = 0L;
        
        //#line 456 "x10/regionarray/RectRegion.x10"
        for (;
             true;
             ) {
            
            //#line 456 "x10/regionarray/RectRegion.x10"
            final boolean t$157455 = ((i$157453) <= (((long)(i$145533max$157469))));
            
            //#line 456 "x10/regionarray/RectRegion.x10"
            if (!(t$157455)) {
                
                //#line 456 "x10/regionarray/RectRegion.x10"
                break;
            }
            
            //#line 457 "x10/regionarray/RectRegion.x10"
            final long t$157444 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)thisMin).$apply(x10.core.Long.$box(i$157453), x10.rtt.Types.LONG));
            
            //#line 457 "x10/regionarray/RectRegion.x10"
            final long t$157445 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)thatMin).$apply(x10.core.Long.$box(i$157453), x10.rtt.Types.LONG));
            
            //#line 457 "x10/regionarray/RectRegion.x10"
            boolean t$157446 = ((long) t$157444) != ((long) t$157445);
            
            //#line 457 "x10/regionarray/RectRegion.x10"
            if (!(t$157446)) {
                
                //#line 457 "x10/regionarray/RectRegion.x10"
                final long t$157447 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)thisMax).$apply(x10.core.Long.$box(i$157453), x10.rtt.Types.LONG));
                
                //#line 457 "x10/regionarray/RectRegion.x10"
                final long t$157448 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)ret$156578).$apply(x10.core.Long.$box(i$157453), x10.rtt.Types.LONG));
                
                //#line 457 "x10/regionarray/RectRegion.x10"
                t$157446 = ((long) t$157447) != ((long) t$157448);
            }
            
            //#line 457 "x10/regionarray/RectRegion.x10"
            if (t$157446) {
                
                //#line 458 "x10/regionarray/RectRegion.x10"
                return false;
            }
            
            //#line 456 "x10/regionarray/RectRegion.x10"
            final long t$157452 = ((i$157453) + (((long)(1L))));
            
            //#line 456 "x10/regionarray/RectRegion.x10"
            i$157453 = t$157452;
        }
        
        //#line 460 "x10/regionarray/RectRegion.x10"
        return true;
    }
    
    
    //#line 463 "x10/regionarray/RectRegion.x10"
    public java.lang.String toString() {
        
        //#line 464 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$156581 = ((x10.regionarray.RectRegion)(this));
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        x10.core.fun.Fun_0_1 ret$156582 =  null;
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157486 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$246(this$156581)));
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        ret$156582 = ((x10.core.fun.Fun_0_1)(t$157486));
        
        //#line 464 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 thisMin = ret$156582;
        
        //#line 465 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$156585 = ((x10.regionarray.RectRegion)(this));
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        x10.core.fun.Fun_0_1 ret$156586 =  null;
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157489 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$247(this$156585)));
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        ret$156586 = ((x10.core.fun.Fun_0_1)(t$157489));
        
        //#line 466 "x10/regionarray/RectRegion.x10"
        java.lang.String s = "[";
        
        //#line 467 "x10/regionarray/RectRegion.x10"
        final long t$157492 = this.rank;
        
        //#line 467 "x10/regionarray/RectRegion.x10"
        final long i$145551max$157493 = ((t$157492) - (((long)(1L))));
        
        //#line 467 "x10/regionarray/RectRegion.x10"
        long i$157483 = 0L;
        
        //#line 467 "x10/regionarray/RectRegion.x10"
        for (;
             true;
             ) {
            
            //#line 467 "x10/regionarray/RectRegion.x10"
            final boolean t$157485 = ((i$157483) <= (((long)(i$145551max$157493))));
            
            //#line 467 "x10/regionarray/RectRegion.x10"
            if (!(t$157485)) {
                
                //#line 467 "x10/regionarray/RectRegion.x10"
                break;
            }
            
            //#line 468 "x10/regionarray/RectRegion.x10"
            final boolean t$157470 = ((i$157483) > (((long)(0L))));
            
            //#line 468 "x10/regionarray/RectRegion.x10"
            if (t$157470) {
                
                //#line 468 "x10/regionarray/RectRegion.x10"
                final java.lang.String t$157472 = ((s) + (","));
                
                //#line 468 "x10/regionarray/RectRegion.x10"
                s = ((java.lang.String)(t$157472));
            }
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            final long t$157474 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)thisMin).$apply(x10.core.Long.$box(i$157483), x10.rtt.Types.LONG));
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$157475 = (("") + ((x10.core.Long.$box(t$157474))));
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$157476 = ((t$157475) + (".."));
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            final long t$157477 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)ret$156586).$apply(x10.core.Long.$box(i$157483), x10.rtt.Types.LONG));
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$157478 = ((t$157476) + ((x10.core.Long.$box(t$157477))));
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$157479 = ((s) + (t$157478));
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            s = ((java.lang.String)(t$157479));
            
            //#line 467 "x10/regionarray/RectRegion.x10"
            final long t$157482 = ((i$157483) + (((long)(1L))));
            
            //#line 467 "x10/regionarray/RectRegion.x10"
            i$157483 = t$157482;
        }
        
        //#line 471 "x10/regionarray/RectRegion.x10"
        final java.lang.String t$157292 = ((s) + ("]"));
        
        //#line 471 "x10/regionarray/RectRegion.x10"
        s = ((java.lang.String)(t$157292));
        
        //#line 472 "x10/regionarray/RectRegion.x10"
        return s;
    }
    
    
    //#line 21 "x10/regionarray/RectRegion.x10"
    final public x10.regionarray.RectRegion x10$regionarray$RectRegion$$this$x10$regionarray$RectRegion() {
        
        //#line 21 "x10/regionarray/RectRegion.x10"
        return x10.regionarray.RectRegion.this;
    }
    
    
    //#line 21 "x10/regionarray/RectRegion.x10"
    final public void __fieldInitializers_x10_regionarray_RectRegion() {
        
        //#line 21 "x10/regionarray/RectRegion.x10"
        this.polyRep = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$220 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$220> $RTT = 
            x10.rtt.StaticFunType.<$Closure$220> make($Closure$220.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$220 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$220 $_obj = new x10.regionarray.RectRegion.$Closure$220((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$220(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 223 "x10/regionarray/RectRegion.x10"
            final long t$156849 = this.out$$.min$O((long)(i));
            
            //#line 223 "x10/regionarray/RectRegion.x10"
            return t$156849;
        }
        
        public x10.regionarray.RectRegion out$$;
        
        public $Closure$220(final x10.regionarray.RectRegion out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$221 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$221> $RTT = 
            x10.rtt.StaticFunType.<$Closure$221> make($Closure$221.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$221 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$221 $_obj = new x10.regionarray.RectRegion.$Closure$221((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$221(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 224 "x10/regionarray/RectRegion.x10"
            final long t$156851 = this.out$$.max$O((long)(i));
            
            //#line 224 "x10/regionarray/RectRegion.x10"
            return t$156851;
        }
        
        public x10.regionarray.RectRegion out$$;
        
        public $Closure$221(final x10.regionarray.RectRegion out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$222 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$222> $RTT = 
            x10.rtt.StaticFunType.<$Closure$222> make($Closure$222.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$222 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$156511 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$222 $_obj = new x10.regionarray.RectRegion.$Closure$222((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$156511);
            
        }
        
        // constructor just for allocation
        public $Closure$222(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$157363) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$157364 = this.this$156511.min$O((long)(i$157363));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$157364;
        }
        
        public x10.regionarray.RectRegion this$156511;
        
        public $Closure$222(final x10.regionarray.RectRegion this$156511) {
             {
                this.this$156511 = ((x10.regionarray.RectRegion)(this$156511));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$223 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$223> $RTT = 
            x10.rtt.StaticFunType.<$Closure$223> make($Closure$223.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$223 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$156515 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$223 $_obj = new x10.regionarray.RectRegion.$Closure$223((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$156515);
            
        }
        
        // constructor just for allocation
        public $Closure$223(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$157366) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$157367 = this.this$156515.max$O((long)(i$157366));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$157367;
        }
        
        public x10.regionarray.RectRegion this$156515;
        
        public $Closure$223(final x10.regionarray.RectRegion this$156515) {
             {
                this.this$156515 = ((x10.regionarray.RectRegion)(this$156515));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$224 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$224> $RTT = 
            x10.rtt.StaticFunType.<$Closure$224> make($Closure$224.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$224 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$224 $_obj = new x10.regionarray.RectRegion.$Closure$224((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$224(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final long t$157005 = this.out$$.min$O((long)(i));
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            return t$157005;
        }
        
        public x10.regionarray.RectRegion out$$;
        
        public $Closure$224(final x10.regionarray.RectRegion out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$225 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$225> $RTT = 
            x10.rtt.StaticFunType.<$Closure$225> make($Closure$225.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$225 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$225 $_obj = new x10.regionarray.RectRegion.$Closure$225((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$225(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final long t$157008 = this.out$$.max$O((long)(i));
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            return t$157008;
        }
        
        public x10.regionarray.RectRegion out$$;
        
        public $Closure$225(final x10.regionarray.RectRegion out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$226 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$226> $RTT = 
            x10.rtt.StaticFunType.<$Closure$226> make($Closure$226.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$226 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$156522 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$226 $_obj = new x10.regionarray.RectRegion.$Closure$226((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$156522);
            
        }
        
        // constructor just for allocation
        public $Closure$226(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$157397) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$157398 = this.this$156522.min$O((long)(i$157397));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$157398;
        }
        
        public x10.regionarray.RectRegion this$156522;
        
        public $Closure$226(final x10.regionarray.RectRegion this$156522) {
             {
                this.this$156522 = ((x10.regionarray.RectRegion)(this$156522));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$227 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$227> $RTT = 
            x10.rtt.StaticFunType.<$Closure$227> make($Closure$227.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$227 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$156526 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$227 $_obj = new x10.regionarray.RectRegion.$Closure$227((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$156526);
            
        }
        
        // constructor just for allocation
        public $Closure$227(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$157400) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$157401 = this.this$156526.max$O((long)(i$157400));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$157401;
        }
        
        public x10.regionarray.RectRegion this$156526;
        
        public $Closure$227(final x10.regionarray.RectRegion this$156526) {
             {
                this.this$156526 = ((x10.regionarray.RectRegion)(this$156526));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$228 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$228> $RTT = 
            x10.rtt.StaticFunType.<$Closure$228> make($Closure$228.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$228 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.thatMin = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$228 $_obj = new x10.regionarray.RectRegion.$Closure$228((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.thatMin);
            
        }
        
        // constructor just for allocation
        public $Closure$228(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 325 "x10/regionarray/RectRegion.x10"
            final long t$157025 = this.out$$.min$O((long)(i));
            
            //#line 325 "x10/regionarray/RectRegion.x10"
            final long t$157026 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.thatMin).$apply(x10.core.Long.$box(i), x10.rtt.Types.LONG));
            
            //#line 325 "x10/regionarray/RectRegion.x10"
            final long t$157027 = java.lang.Math.max(((long)(t$157025)),((long)(t$157026)));
            
            //#line 325 "x10/regionarray/RectRegion.x10"
            return t$157027;
        }
        
        public x10.regionarray.RectRegion out$$;
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMin;
        
        public $Closure$228(final x10.regionarray.RectRegion out$$, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMin, __1$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.out$$ = out$$;
                this.thatMin = ((x10.core.fun.Fun_0_1)(thatMin));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$229 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$229> $RTT = 
            x10.rtt.StaticFunType.<$Closure$229> make($Closure$229.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$229 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.thatMax = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$229 $_obj = new x10.regionarray.RectRegion.$Closure$229((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.thatMax);
            
        }
        
        // constructor just for allocation
        public $Closure$229(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 326 "x10/regionarray/RectRegion.x10"
            final long t$157030 = this.out$$.max$O((long)(i));
            
            //#line 326 "x10/regionarray/RectRegion.x10"
            final long t$157031 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.thatMax).$apply(x10.core.Long.$box(i), x10.rtt.Types.LONG));
            
            //#line 326 "x10/regionarray/RectRegion.x10"
            final long t$157032 = java.lang.Math.min(((long)(t$157030)),((long)(t$157031)));
            
            //#line 326 "x10/regionarray/RectRegion.x10"
            return t$157032;
        }
        
        public x10.regionarray.RectRegion out$$;
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMax;
        
        public $Closure$229(final x10.regionarray.RectRegion out$$, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMax, __1$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.out$$ = out$$;
                this.thatMax = ((x10.core.fun.Fun_0_1)(thatMax));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$230 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$230> $RTT = 
            x10.rtt.StaticFunType.<$Closure$230> make($Closure$230.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$230 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$156539 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$230 $_obj = new x10.regionarray.RectRegion.$Closure$230((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$156539);
            
        }
        
        // constructor just for allocation
        public $Closure$230(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$157405) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$157406 = this.this$156539.min$O((long)(i$157405));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$157406;
        }
        
        public x10.regionarray.RectRegion this$156539;
        
        public $Closure$230(final x10.regionarray.RectRegion this$156539) {
             {
                this.this$156539 = ((x10.regionarray.RectRegion)(this$156539));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$231 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$231> $RTT = 
            x10.rtt.StaticFunType.<$Closure$231> make($Closure$231.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$231 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$156543 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$231 $_obj = new x10.regionarray.RectRegion.$Closure$231((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$156543);
            
        }
        
        // constructor just for allocation
        public $Closure$231(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$157408) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$157409 = this.this$156543.max$O((long)(i$157408));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$157409;
        }
        
        public x10.regionarray.RectRegion this$156543;
        
        public $Closure$231(final x10.regionarray.RectRegion this$156543) {
             {
                this.this$156543 = ((x10.regionarray.RectRegion)(this$156543));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$232 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$232> $RTT = 
            x10.rtt.StaticFunType.<$Closure$232> make($Closure$232.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$232 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.thatMin = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$232 $_obj = new x10.regionarray.RectRegion.$Closure$232((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            $serializer.write(this.thatMin);
            
        }
        
        // constructor just for allocation
        public $Closure$232(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __2$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 351 "x10/regionarray/RectRegion.x10"
            final long t$157086 = this.rank;
            
            //#line 351 "x10/regionarray/RectRegion.x10"
            final boolean t$157089 = ((i) < (((long)(t$157086))));
            
            //#line 351 "x10/regionarray/RectRegion.x10"
            long t$157090 =  0;
            
            //#line 351 "x10/regionarray/RectRegion.x10"
            if (t$157089) {
                
                //#line 351 "x10/regionarray/RectRegion.x10"
                t$157090 = this.out$$.min$O((long)(i));
            } else {
                
                //#line 351 "x10/regionarray/RectRegion.x10"
                final long t$157087 = this.rank;
                
                //#line 351 "x10/regionarray/RectRegion.x10"
                final long t$157088 = ((i) - (((long)(t$157087))));
                
                //#line 351 "x10/regionarray/RectRegion.x10"
                t$157090 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.thatMin).$apply(x10.core.Long.$box(t$157088), x10.rtt.Types.LONG));
            }
            
            //#line 351 "x10/regionarray/RectRegion.x10"
            return t$157090;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long rank;
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMin;
        
        public $Closure$232(final x10.regionarray.RectRegion out$$, final long rank, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMin, __2$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.out$$ = out$$;
                this.rank = rank;
                this.thatMin = ((x10.core.fun.Fun_0_1)(thatMin));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$233 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$233> $RTT = 
            x10.rtt.StaticFunType.<$Closure$233> make($Closure$233.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$233 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.thatMax = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$233 $_obj = new x10.regionarray.RectRegion.$Closure$233((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            $serializer.write(this.thatMax);
            
        }
        
        // constructor just for allocation
        public $Closure$233(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __2$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 352 "x10/regionarray/RectRegion.x10"
            final long t$157093 = this.rank;
            
            //#line 352 "x10/regionarray/RectRegion.x10"
            final boolean t$157096 = ((i) < (((long)(t$157093))));
            
            //#line 352 "x10/regionarray/RectRegion.x10"
            long t$157097 =  0;
            
            //#line 352 "x10/regionarray/RectRegion.x10"
            if (t$157096) {
                
                //#line 352 "x10/regionarray/RectRegion.x10"
                t$157097 = this.out$$.max$O((long)(i));
            } else {
                
                //#line 352 "x10/regionarray/RectRegion.x10"
                final long t$157094 = this.rank;
                
                //#line 352 "x10/regionarray/RectRegion.x10"
                final long t$157095 = ((i) - (((long)(t$157094))));
                
                //#line 352 "x10/regionarray/RectRegion.x10"
                t$157097 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.thatMax).$apply(x10.core.Long.$box(t$157095), x10.rtt.Types.LONG));
            }
            
            //#line 352 "x10/regionarray/RectRegion.x10"
            return t$157097;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long rank;
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMax;
        
        public $Closure$233(final x10.regionarray.RectRegion out$$, final long rank, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMax, __2$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.out$$ = out$$;
                this.rank = rank;
                this.thatMax = ((x10.core.fun.Fun_0_1)(thatMax));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$234 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$234> $RTT = 
            x10.rtt.StaticFunType.<$Closure$234> make($Closure$234.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$234 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.thatMin = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$234 $_obj = new x10.regionarray.RectRegion.$Closure$234((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            $serializer.write(this.thatMin);
            
        }
        
        // constructor just for allocation
        public $Closure$234(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 358 "x10/regionarray/RectRegion.x10"
            final long t$157101 = this.rank;
            
            //#line 358 "x10/regionarray/RectRegion.x10"
            final boolean t$157102 = ((i) < (((long)(t$157101))));
            
            //#line 358 "x10/regionarray/RectRegion.x10"
            long t$157103 =  0;
            
            //#line 358 "x10/regionarray/RectRegion.x10"
            if (t$157102) {
                
                //#line 358 "x10/regionarray/RectRegion.x10"
                t$157103 = this.out$$.min$O((long)(i));
            } else {
                
                //#line 358 "x10/regionarray/RectRegion.x10"
                t$157103 = this.thatMin;
            }
            
            //#line 358 "x10/regionarray/RectRegion.x10"
            return t$157103;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long rank;
        public long thatMin;
        
        public $Closure$234(final x10.regionarray.RectRegion out$$, final long rank, final long thatMin) {
             {
                this.out$$ = out$$;
                this.rank = rank;
                this.thatMin = thatMin;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$235 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$235> $RTT = 
            x10.rtt.StaticFunType.<$Closure$235> make($Closure$235.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$235 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.thatMax = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$235 $_obj = new x10.regionarray.RectRegion.$Closure$235((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            $serializer.write(this.thatMax);
            
        }
        
        // constructor just for allocation
        public $Closure$235(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 359 "x10/regionarray/RectRegion.x10"
            final long t$157106 = this.rank;
            
            //#line 359 "x10/regionarray/RectRegion.x10"
            final boolean t$157107 = ((i) < (((long)(t$157106))));
            
            //#line 359 "x10/regionarray/RectRegion.x10"
            long t$157108 =  0;
            
            //#line 359 "x10/regionarray/RectRegion.x10"
            if (t$157107) {
                
                //#line 359 "x10/regionarray/RectRegion.x10"
                t$157108 = this.out$$.max$O((long)(i));
            } else {
                
                //#line 359 "x10/regionarray/RectRegion.x10"
                t$157108 = this.thatMax;
            }
            
            //#line 359 "x10/regionarray/RectRegion.x10"
            return t$157108;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long rank;
        public long thatMax;
        
        public $Closure$235(final x10.regionarray.RectRegion out$$, final long rank, final long thatMax) {
             {
                this.out$$ = out$$;
                this.rank = rank;
                this.thatMax = thatMax;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$236 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$236> $RTT = 
            x10.rtt.StaticFunType.<$Closure$236> make($Closure$236.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$236 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$236 $_obj = new x10.regionarray.RectRegion.$Closure$236((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            
        }
        
        // constructor just for allocation
        public $Closure$236(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 363 "x10/regionarray/RectRegion.x10"
            final long t$157113 = this.rank;
            
            //#line 363 "x10/regionarray/RectRegion.x10"
            final boolean t$157114 = ((i) < (((long)(t$157113))));
            
            //#line 363 "x10/regionarray/RectRegion.x10"
            long t$157115 =  0;
            
            //#line 363 "x10/regionarray/RectRegion.x10"
            if (t$157114) {
                
                //#line 363 "x10/regionarray/RectRegion.x10"
                t$157115 = this.out$$.min$O((long)(i));
            } else {
                
                //#line 363 "x10/regionarray/RectRegion.x10"
                t$157115 = java.lang.Long.MIN_VALUE;
            }
            
            //#line 363 "x10/regionarray/RectRegion.x10"
            return t$157115;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long rank;
        
        public $Closure$236(final x10.regionarray.RectRegion out$$, final long rank) {
             {
                this.out$$ = out$$;
                this.rank = rank;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$237 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$237> $RTT = 
            x10.rtt.StaticFunType.<$Closure$237> make($Closure$237.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$237 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$237 $_obj = new x10.regionarray.RectRegion.$Closure$237((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            
        }
        
        // constructor just for allocation
        public $Closure$237(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 364 "x10/regionarray/RectRegion.x10"
            final long t$157118 = this.rank;
            
            //#line 364 "x10/regionarray/RectRegion.x10"
            final boolean t$157119 = ((i) < (((long)(t$157118))));
            
            //#line 364 "x10/regionarray/RectRegion.x10"
            long t$157120 =  0;
            
            //#line 364 "x10/regionarray/RectRegion.x10"
            if (t$157119) {
                
                //#line 364 "x10/regionarray/RectRegion.x10"
                t$157120 = this.out$$.max$O((long)(i));
            } else {
                
                //#line 364 "x10/regionarray/RectRegion.x10"
                t$157120 = java.lang.Long.MAX_VALUE;
            }
            
            //#line 364 "x10/regionarray/RectRegion.x10"
            return t$157120;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long rank;
        
        public $Closure$237(final x10.regionarray.RectRegion out$$, final long rank) {
             {
                this.out$$ = out$$;
                this.rank = rank;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$238 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$238> $RTT = 
            x10.rtt.StaticFunType.<$Closure$238> make($Closure$238.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$238 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.v = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$238 $_obj = new x10.regionarray.RectRegion.$Closure$238((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$238(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 372 "x10/regionarray/RectRegion.x10"
            final long t$157134 = this.out$$.min$O((long)(i));
            
            //#line 372 "x10/regionarray/RectRegion.x10"
            final long t$157135 = this.v.$apply$O((long)(i));
            
            //#line 372 "x10/regionarray/RectRegion.x10"
            final long t$157136 = ((t$157134) + (((long)(t$157135))));
            
            //#line 372 "x10/regionarray/RectRegion.x10"
            return t$157136;
        }
        
        public x10.regionarray.RectRegion out$$;
        public x10.lang.Point v;
        
        public $Closure$238(final x10.regionarray.RectRegion out$$, final x10.lang.Point v) {
             {
                this.out$$ = out$$;
                this.v = ((x10.lang.Point)(v));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$239 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$239> $RTT = 
            x10.rtt.StaticFunType.<$Closure$239> make($Closure$239.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$239 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.v = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$239 $_obj = new x10.regionarray.RectRegion.$Closure$239((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$239(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 373 "x10/regionarray/RectRegion.x10"
            final long t$157139 = this.out$$.max$O((long)(i));
            
            //#line 373 "x10/regionarray/RectRegion.x10"
            final long t$157140 = this.v.$apply$O((long)(i));
            
            //#line 373 "x10/regionarray/RectRegion.x10"
            final long t$157141 = ((t$157139) + (((long)(t$157140))));
            
            //#line 373 "x10/regionarray/RectRegion.x10"
            return t$157141;
        }
        
        public x10.regionarray.RectRegion out$$;
        public x10.lang.Point v;
        
        public $Closure$239(final x10.regionarray.RectRegion out$$, final x10.lang.Point v) {
             {
                this.out$$ = out$$;
                this.v = ((x10.lang.Point)(v));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$240 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$240> $RTT = 
            x10.rtt.StaticFunType.<$Closure$240> make($Closure$240.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$240 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.axis = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$240 $_obj = new x10.regionarray.RectRegion.$Closure$240((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.axis);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$240(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 383 "x10/regionarray/RectRegion.x10"
            final boolean t$157164 = ((i) < (((long)(this.axis))));
            
            //#line 383 "x10/regionarray/RectRegion.x10"
            long t$157165 =  0;
            
            //#line 383 "x10/regionarray/RectRegion.x10"
            if (t$157164) {
                
                //#line 383 "x10/regionarray/RectRegion.x10"
                t$157165 = this.out$$.min$O((long)(i));
            } else {
                
                //#line 383 "x10/regionarray/RectRegion.x10"
                final long t$157163 = ((i) + (((long)(1L))));
                
                //#line 383 "x10/regionarray/RectRegion.x10"
                t$157165 = this.out$$.min$O((long)(t$157163));
            }
            
            //#line 383 "x10/regionarray/RectRegion.x10"
            return t$157165;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long axis;
        
        public $Closure$240(final x10.regionarray.RectRegion out$$, final long axis) {
             {
                this.out$$ = out$$;
                this.axis = axis;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$241 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$241> $RTT = 
            x10.rtt.StaticFunType.<$Closure$241> make($Closure$241.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$241 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.axis = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$241 $_obj = new x10.regionarray.RectRegion.$Closure$241((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.axis);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$241(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 384 "x10/regionarray/RectRegion.x10"
            final boolean t$157169 = ((i) < (((long)(this.axis))));
            
            //#line 384 "x10/regionarray/RectRegion.x10"
            long t$157170 =  0;
            
            //#line 384 "x10/regionarray/RectRegion.x10"
            if (t$157169) {
                
                //#line 384 "x10/regionarray/RectRegion.x10"
                t$157170 = this.out$$.max$O((long)(i));
            } else {
                
                //#line 384 "x10/regionarray/RectRegion.x10"
                final long t$157168 = ((i) + (((long)(1L))));
                
                //#line 384 "x10/regionarray/RectRegion.x10"
                t$157170 = this.out$$.max$O((long)(t$157168));
            }
            
            //#line 384 "x10/regionarray/RectRegion.x10"
            return t$157170;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long axis;
        
        public $Closure$241(final x10.regionarray.RectRegion out$$, final long axis) {
             {
                this.out$$ = out$$;
                this.axis = axis;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$242 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$242> $RTT = 
            x10.rtt.StaticFunType.<$Closure$242> make($Closure$242.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$242 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$156565 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$242 $_obj = new x10.regionarray.RectRegion.$Closure$242((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$156565);
            
        }
        
        // constructor just for allocation
        public $Closure$242(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$157457) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$157458 = this.this$156565.min$O((long)(i$157457));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$157458;
        }
        
        public x10.regionarray.RectRegion this$156565;
        
        public $Closure$242(final x10.regionarray.RectRegion this$156565) {
             {
                this.this$156565 = ((x10.regionarray.RectRegion)(this$156565));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$243 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$243> $RTT = 
            x10.rtt.StaticFunType.<$Closure$243> make($Closure$243.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$243 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$156569 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$243 $_obj = new x10.regionarray.RectRegion.$Closure$243((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$156569);
            
        }
        
        // constructor just for allocation
        public $Closure$243(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$157460) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$157461 = this.this$156569.max$O((long)(i$157460));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$157461;
        }
        
        public x10.regionarray.RectRegion this$156569;
        
        public $Closure$243(final x10.regionarray.RectRegion this$156569) {
             {
                this.this$156569 = ((x10.regionarray.RectRegion)(this$156569));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$244 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$244> $RTT = 
            x10.rtt.StaticFunType.<$Closure$244> make($Closure$244.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$244 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$156573 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$244 $_obj = new x10.regionarray.RectRegion.$Closure$244((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$156573);
            
        }
        
        // constructor just for allocation
        public $Closure$244(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$157463) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$157464 = this.this$156573.min$O((long)(i$157463));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$157464;
        }
        
        public x10.regionarray.RectRegion this$156573;
        
        public $Closure$244(final x10.regionarray.RectRegion this$156573) {
             {
                this.this$156573 = ((x10.regionarray.RectRegion)(this$156573));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$245 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$245> $RTT = 
            x10.rtt.StaticFunType.<$Closure$245> make($Closure$245.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$245 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$156577 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$245 $_obj = new x10.regionarray.RectRegion.$Closure$245((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$156577);
            
        }
        
        // constructor just for allocation
        public $Closure$245(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$157466) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$157467 = this.this$156577.max$O((long)(i$157466));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$157467;
        }
        
        public x10.regionarray.RectRegion this$156577;
        
        public $Closure$245(final x10.regionarray.RectRegion this$156577) {
             {
                this.this$156577 = ((x10.regionarray.RectRegion)(this$156577));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$246 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$246> $RTT = 
            x10.rtt.StaticFunType.<$Closure$246> make($Closure$246.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$246 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$156581 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$246 $_obj = new x10.regionarray.RectRegion.$Closure$246((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$156581);
            
        }
        
        // constructor just for allocation
        public $Closure$246(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$157487) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$157488 = this.this$156581.min$O((long)(i$157487));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$157488;
        }
        
        public x10.regionarray.RectRegion this$156581;
        
        public $Closure$246(final x10.regionarray.RectRegion this$156581) {
             {
                this.this$156581 = ((x10.regionarray.RectRegion)(this$156581));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$247 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$247> $RTT = 
            x10.rtt.StaticFunType.<$Closure$247> make($Closure$247.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$247 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$156585 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$247 $_obj = new x10.regionarray.RectRegion.$Closure$247((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$156585);
            
        }
        
        // constructor just for allocation
        public $Closure$247(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$157490) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$157491 = this.this$156585.max$O((long)(i$157490));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$157491;
        }
        
        public x10.regionarray.RectRegion this$156585;
        
        public $Closure$247(final x10.regionarray.RectRegion this$156585) {
             {
                this.this$156585 = ((x10.regionarray.RectRegion)(this$156585));
            }
        }
        
    }
    
    
    public boolean x10$regionarray$Region$equals$S$O(final java.lang.Object a0) {
        return super.equals(((java.lang.Object)(a0)));
    }
}

