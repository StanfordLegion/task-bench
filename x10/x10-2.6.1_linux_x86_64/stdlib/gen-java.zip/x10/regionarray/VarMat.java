package x10.regionarray;

@x10.runtime.impl.java.X10Generated
final public class VarMat extends x10.regionarray.Mat<x10.regionarray.VarRow> implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<VarMat> $RTT = 
        x10.rtt.NamedType.<VarMat> make("x10.regionarray.VarMat",
                                        VarMat.class,
                                        new x10.rtt.Type[] {
                                            x10.rtt.ParameterizedType.make(x10.regionarray.Mat.$RTT, x10.regionarray.VarRow.$RTT)
                                        });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.VarMat $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Mat.$_deserialize_body($_obj, $deserializer);
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.VarMat $_obj = new x10.regionarray.VarMat((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        
    }
    
    // constructor just for allocation
    public VarMat(final java.lang.System[] $dummy) {
        super($dummy, x10.regionarray.VarRow.$RTT);
        
    }
    
    // bridge for inherited method public x10.regionarray.Mat[T].operator()(i:x10.lang.Int){}:T
    public x10.regionarray.VarRow $apply(int a1){
        return super.$apply$G((a1));
    }
    
    // synthetic type for parameter mangling
    public static final class __1$1x10$regionarray$VarRow$2 {}
    // synthetic type for parameter mangling
    public static final class __2$1x10$lang$Int$3x10$regionarray$VarRow$2 {}
    // synthetic type for parameter mangling
    public static final class __2$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 {}
    

    
    
    //#line 16 "x10/regionarray/VarMat.x10"
    // creation method for java code (1-phase java constructor)
    public VarMat(final int cols, final x10.core.Rail<x10.regionarray.VarRow> mat, __1$1x10$regionarray$VarRow$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$VarMat$$init$S(cols, mat, (x10.regionarray.VarMat.__1$1x10$regionarray$VarRow$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.VarMat x10$regionarray$VarMat$$init$S(final int cols, final x10.core.Rail<x10.regionarray.VarRow> mat, __1$1x10$regionarray$VarRow$2 $dummy) {
         {
            
            //#line 17 "x10/regionarray/VarMat.x10"
            final x10.regionarray.Mat this$158585 = ((x10.regionarray.Mat)(this));
            
            //#line 17 "x10/regionarray/VarMat.x10"
            final long t$158598 = ((x10.core.Rail<x10.regionarray.VarRow>)mat).size;
            
            //#line 17 "x10/regionarray/VarMat.x10"
            final int rows$158582 = ((int)(long)(((long)(t$158598))));
            
            //#line 22 . "x10/regionarray/Mat.x10"
            ((x10.regionarray.Mat<x10.regionarray.VarRow>)this$158585).rows = rows$158582;
            
            //#line 22 . "x10/regionarray/Mat.x10"
            ((x10.regionarray.Mat<x10.regionarray.VarRow>)this$158585).cols = cols;
            
            //#line 23 . "x10/regionarray/Mat.x10"
            ((x10.regionarray.Mat<x10.regionarray.VarRow>)this$158585).mat = ((x10.core.Rail)(mat));
            
            //#line 16 "x10/regionarray/VarMat.x10"
            
        }
        return this;
    }
    
    
    
    //#line 20 "x10/regionarray/VarMat.x10"
    // creation method for java code (1-phase java constructor)
    public VarMat(final int rows, final int cols, final x10.core.fun.Fun_0_1<x10.core.Int,x10.regionarray.VarRow> init, __2$1x10$lang$Int$3x10$regionarray$VarRow$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$VarMat$$init$S(rows, cols, init, (x10.regionarray.VarMat.__2$1x10$lang$Int$3x10$regionarray$VarRow$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.VarMat x10$regionarray$VarMat$$init$S(final int rows, final int cols, final x10.core.fun.Fun_0_1<x10.core.Int,x10.regionarray.VarRow> init, __2$1x10$lang$Int$3x10$regionarray$VarRow$2 $dummy) {
         {
            
            //#line 21 "x10/regionarray/VarMat.x10"
            final x10.regionarray.Mat this$158593 = ((x10.regionarray.Mat)(this));
            
            //#line 21 "x10/regionarray/VarMat.x10"
            final int rows$158590 = rows;
            
            //#line 21 "x10/regionarray/VarMat.x10"
            final int cols$158591 = cols;
            
            //#line 21 "x10/regionarray/VarMat.x10"
            final long t$158601 = ((long)(((int)(rows))));
            
            //#line 21 "x10/regionarray/VarMat.x10"
            final x10.core.fun.Fun_0_1 t$158602 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.VarMat.$Closure$258(init, (x10.regionarray.VarMat.$Closure$258.__0$1x10$lang$Int$3x10$regionarray$VarRow$2) null)));
            
            //#line 21 "x10/regionarray/VarMat.x10"
            final x10.core.Rail mat$158592 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.VarRow>(x10.regionarray.VarRow.$RTT, t$158601, ((x10.core.fun.Fun_0_1)(t$158602)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 22 . "x10/regionarray/Mat.x10"
            ((x10.regionarray.Mat<x10.regionarray.VarRow>)this$158593).rows = rows$158590;
            
            //#line 22 . "x10/regionarray/Mat.x10"
            ((x10.regionarray.Mat<x10.regionarray.VarRow>)this$158593).cols = cols$158591;
            
            //#line 23 . "x10/regionarray/Mat.x10"
            ((x10.regionarray.Mat<x10.regionarray.VarRow>)this$158593).mat = ((x10.core.Rail)(mat$158592));
            
            //#line 20 "x10/regionarray/VarMat.x10"
            
        }
        return this;
    }
    
    
    
    //#line 24 "x10/regionarray/VarMat.x10"
    // creation method for java code (1-phase java constructor)
    public VarMat(final int rows, final int cols, final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init, __2$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$VarMat$$init$S(rows, cols, init, (x10.regionarray.VarMat.__2$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.VarMat x10$regionarray$VarMat$$init$S(final int rows, final int cols, final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init, __2$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
         {
            
            //#line 25 "x10/regionarray/VarMat.x10"
            final x10.core.fun.Fun_0_1 t$158605 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.VarMat.$Closure$260(init, cols, (x10.regionarray.VarMat.$Closure$260.__0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2) null)));
            
            //#line 25 "x10/regionarray/VarMat.x10"
            /*this.*/x10$regionarray$VarMat$$init$S(((int)(rows)), ((int)(cols)), ((x10.core.fun.Fun_0_1)(t$158605)), (x10.regionarray.VarMat.__2$1x10$lang$Int$3x10$regionarray$VarRow$2) null);
        }
        return this;
    }
    
    
    
    //#line 28 "x10/regionarray/VarMat.x10"
    // creation method for java code (1-phase java constructor)
    public VarMat(final int rows, final int cols) {
        this((java.lang.System[]) null);
        x10$regionarray$VarMat$$init$S(rows, cols);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.VarMat x10$regionarray$VarMat$$init$S(final int rows, final int cols) {
         {
            
            //#line 29 "x10/regionarray/VarMat.x10"
            final x10.core.fun.Fun_0_1 t$158606 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.VarMat.$Closure$261(cols)));
            
            //#line 29 "x10/regionarray/VarMat.x10"
            /*this.*/x10$regionarray$VarMat$$init$S(((int)(rows)), ((int)(cols)), ((x10.core.fun.Fun_0_1)(t$158606)), (x10.regionarray.VarMat.__2$1x10$lang$Int$3x10$regionarray$VarRow$2) null);
        }
        return this;
    }
    
    
    
    //#line 14 "x10/regionarray/VarMat.x10"
    final public x10.regionarray.VarMat x10$regionarray$VarMat$$this$x10$regionarray$VarMat() {
        
        //#line 14 "x10/regionarray/VarMat.x10"
        return x10.regionarray.VarMat.this;
    }
    
    
    //#line 14 "x10/regionarray/VarMat.x10"
    final public void __fieldInitializers_x10_regionarray_VarMat() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$258 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$258> $RTT = 
            x10.rtt.StaticFunType.<$Closure$258> make($Closure$258.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.regionarray.VarRow.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.VarMat.$Closure$258 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.VarMat.$Closure$258 $_obj = new x10.regionarray.VarMat.$Closure$258((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$258(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$3x10$regionarray$VarRow$2 {}
        
    
        
        public x10.regionarray.VarRow $apply(final long i) {
            
            //#line 21 "x10/regionarray/VarMat.x10"
            final int t$158599 = ((int)(long)(((long)(i))));
            
            //#line 21 "x10/regionarray/VarMat.x10"
            final x10.regionarray.VarRow t$158600 = ((x10.regionarray.VarRow)
                                                      ((x10.core.fun.Fun_0_1<x10.core.Int,x10.regionarray.VarRow>)this.init).$apply(x10.core.Int.$box(t$158599), x10.rtt.Types.INT));
            
            //#line 21 "x10/regionarray/VarMat.x10"
            return t$158600;
        }
        
        public x10.core.fun.Fun_0_1<x10.core.Int,x10.regionarray.VarRow> init;
        
        public $Closure$258(final x10.core.fun.Fun_0_1<x10.core.Int,x10.regionarray.VarRow> init, __0$1x10$lang$Int$3x10$regionarray$VarRow$2 $dummy) {
             {
                this.init = ((x10.core.fun.Fun_0_1)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$259 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$259> $RTT = 
            x10.rtt.StaticFunType.<$Closure$259> make($Closure$259.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.VarMat.$Closure$259 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.i = $deserializer.readInt();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.VarMat.$Closure$259 $_obj = new x10.regionarray.VarMat.$Closure$259((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.i);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$259(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Int.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Int.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 {}
        
    
        
        public int $apply$O(final int j$158610) {
            
            //#line 25 "x10/regionarray/VarMat.x10"
            final int t$158611 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int>)this.init).$apply(x10.core.Int.$box(this.i), x10.rtt.Types.INT, x10.core.Int.$box(j$158610), x10.rtt.Types.INT));
            
            //#line 25 "x10/regionarray/VarMat.x10"
            return t$158611;
        }
        
        public x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init;
        public int i;
        
        public $Closure$259(final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init, final int i, __0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
             {
                this.init = ((x10.core.fun.Fun_0_2)(init));
                this.i = i;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$260 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$260> $RTT = 
            x10.rtt.StaticFunType.<$Closure$260> make($Closure$260.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.regionarray.VarRow.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.VarMat.$Closure$260 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cols = $deserializer.readInt();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.VarMat.$Closure$260 $_obj = new x10.regionarray.VarMat.$Closure$260((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cols);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$260(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Int.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 {}
        
    
        
        public x10.regionarray.VarRow $apply(final int i) {
            
            //#line 25 "x10/regionarray/VarMat.x10"
            final x10.regionarray.VarRow alloc$155218 = ((x10.regionarray.VarRow)(new x10.regionarray.VarRow((java.lang.System[]) null)));
            
            //#line 25 "x10/regionarray/VarMat.x10"
            final x10.core.fun.Fun_0_1 t$158609 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.VarMat.$Closure$259(((x10.core.fun.Fun_0_2)(this.init)), i, (x10.regionarray.VarMat.$Closure$259.__0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2) null)));
            
            //#line 25 "x10/regionarray/VarMat.x10"
            alloc$155218.x10$regionarray$VarRow$$init$S(this.cols, ((x10.core.fun.Fun_0_1)(t$158609)), (x10.regionarray.VarRow.__1$1x10$lang$Int$3x10$lang$Int$2) null);
            
            //#line 25 "x10/regionarray/VarMat.x10"
            return alloc$155218;
        }
        
        public x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init;
        public int cols;
        
        public $Closure$260(final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init, final int cols, __0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
             {
                this.init = ((x10.core.fun.Fun_0_2)(init));
                this.cols = cols;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$261 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$261> $RTT = 
            x10.rtt.StaticFunType.<$Closure$261> make($Closure$261.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.regionarray.VarRow.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.VarMat.$Closure$261 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cols = $deserializer.readInt();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.VarMat.$Closure$261 $_obj = new x10.regionarray.VarMat.$Closure$261((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cols);
            
        }
        
        // constructor just for allocation
        public $Closure$261(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Int.$unbox(a1));
            
        }
        
        
    
        
        public x10.regionarray.VarRow $apply(final int id$242) {
            
            //#line 29 "x10/regionarray/VarMat.x10"
            final x10.regionarray.VarRow alloc$155219 = ((x10.regionarray.VarRow)(new x10.regionarray.VarRow((java.lang.System[]) null)));
            
            //#line 29 "x10/regionarray/VarMat.x10"
            alloc$155219.x10$regionarray$VarRow$$init$S(this.cols);
            
            //#line 29 "x10/regionarray/VarMat.x10"
            return alloc$155219;
        }
        
        public int cols;
        
        public $Closure$261(final int cols) {
             {
                this.cols = cols;
            }
        }
        
    }
    
}

