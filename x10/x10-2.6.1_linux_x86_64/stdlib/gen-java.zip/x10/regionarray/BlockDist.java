package x10.regionarray;


/**
 * <p>A BlockDist divides the coordinates along one axis
 * of its Region in a block fashion and distributes them
 * as evenly as possible to the places in its PlaceGroup.</p>
 * 
 * It caches the region for the current place as a transient field.
 * This makes the initial access to this information somewhat slow,
 * but optimizes the wire-transfer size of the Dist object. 
 * This appears to be the appropriate tradeoff, since Dist objects
 * are frequently serialized and usually the restriction operation is 
 * applied to get the Region for here, not for other places.
 */
@x10.runtime.impl.java.X10Generated
final public class BlockDist extends x10.regionarray.Dist implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<BlockDist> $RTT = 
        x10.rtt.NamedType.<BlockDist> make("x10.regionarray.BlockDist",
                                           BlockDist.class,
                                           new x10.rtt.Type[] {
                                               x10.regionarray.Dist.$RTT
                                           });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDist $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Dist.$_deserialize_body($_obj, $deserializer);
        $_obj.axis = $deserializer.readLong();
        $_obj.pg = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.BlockDist $_obj = new x10.regionarray.BlockDist((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.axis);
        $serializer.write(this.pg);
        
    }
    
    // constructor just for allocation
    public BlockDist(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 33 "x10/regionarray/BlockDist.x10"
    /**
     * The place group for this distribution
     */
    public x10.lang.PlaceGroup pg;
    
    //#line 38 "x10/regionarray/BlockDist.x10"
    /**
     * The axis along which the region is being distributed
     */
    public long axis;
    
    //#line 43 "x10/regionarray/BlockDist.x10"
    /**
     * Cached restricted region for the current place.
     */
    public transient x10.regionarray.Region regionForHere;
    
    
    //#line 46 "x10/regionarray/BlockDist.x10"
    // creation method for java code (1-phase java constructor)
    public BlockDist(final x10.regionarray.Region r, final long axis, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null);
        x10$regionarray$BlockDist$$init$S(r, axis, pg);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.BlockDist x10$regionarray$BlockDist$$init$S(final x10.regionarray.Region r, final long axis, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 47 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Dist this$147805 = ((x10.regionarray.Dist)(this));
            
            //#line 548 . "x10/regionarray/Dist.x10"
            this$147805.region = r;
            
            //#line 46 "x10/regionarray/BlockDist.x10"
            
            
            //#line 28 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.BlockDist this$148243 = this;
            
            //#line 28 "x10/regionarray/BlockDist.x10"
            this$148243.regionForHere = null;
            
            //#line 48 "x10/regionarray/BlockDist.x10"
            this.axis = axis;
            
            //#line 49 "x10/regionarray/BlockDist.x10"
            this.pg = ((x10.lang.PlaceGroup)(pg));
        }
        return this;
    }
    
    
    
    //#line 60 "x10/regionarray/BlockDist.x10"
    /**
     * The key algorithm for this class.
     * Compute the region for the given place by doing region algebra.
     *
     * Assumption: Caller has done error checking to ensure that place is 
     *   actually a member of pg.
     */
    private x10.regionarray.Region blockRegionForPlace(final x10.lang.Place place) {
        
        //#line 61 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148089 = ((x10.regionarray.Region)(this.region));
        
        //#line 61 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region b = ((x10.regionarray.Region)(t$148089.boundingBox()));
        
        //#line 62 "x10/regionarray/BlockDist.x10"
        final long t$148090 = this.axis;
        
        //#line 62 "x10/regionarray/BlockDist.x10"
        final long min = b.min$O((long)(t$148090));
        
        //#line 63 "x10/regionarray/BlockDist.x10"
        final long t$148091 = this.axis;
        
        //#line 63 "x10/regionarray/BlockDist.x10"
        final long max = b.max$O((long)(t$148091));
        
        //#line 64 "x10/regionarray/BlockDist.x10"
        final x10.lang.PlaceGroup t$148092 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 64 "x10/regionarray/BlockDist.x10"
        final long t$148093 = t$148092.numPlaces$O();
        
        //#line 64 "x10/regionarray/BlockDist.x10"
        final long P = t$148093;
        
        //#line 65 "x10/regionarray/BlockDist.x10"
        final long t$148094 = ((max) - (((long)(min))));
        
        //#line 65 "x10/regionarray/BlockDist.x10"
        final long numElems = ((t$148094) + (((long)(1L))));
        
        //#line 66 "x10/regionarray/BlockDist.x10"
        final long blockSize = ((numElems) / (((long)(P))));
        
        //#line 67 "x10/regionarray/BlockDist.x10"
        final long t$148095 = ((P) * (((long)(blockSize))));
        
        //#line 67 "x10/regionarray/BlockDist.x10"
        final long leftOver = ((numElems) - (((long)(t$148095))));
        
        //#line 68 "x10/regionarray/BlockDist.x10"
        final x10.lang.PlaceGroup t$148096 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 68 "x10/regionarray/BlockDist.x10"
        final long t$148097 = t$148096.indexOf$O(((x10.lang.Place)(place)));
        
        //#line 68 "x10/regionarray/BlockDist.x10"
        final long i = t$148097;
        
        //#line 69 "x10/regionarray/BlockDist.x10"
        final long t$148098 = ((blockSize) * (((long)(i))));
        
        //#line 69 "x10/regionarray/BlockDist.x10"
        final long t$148101 = ((min) + (((long)(t$148098))));
        
        //#line 69 "x10/regionarray/BlockDist.x10"
        final boolean t$148099 = ((i) < (((long)(leftOver))));
        
        //#line 69 "x10/regionarray/BlockDist.x10"
        long t$148100 =  0;
        
        //#line 69 "x10/regionarray/BlockDist.x10"
        if (t$148099) {
            
            //#line 69 "x10/regionarray/BlockDist.x10"
            t$148100 = i;
        } else {
            
            //#line 69 "x10/regionarray/BlockDist.x10"
            t$148100 = leftOver;
        }
        
        //#line 69 "x10/regionarray/BlockDist.x10"
        final long low = ((t$148101) + (((long)(t$148100))));
        
        //#line 70 "x10/regionarray/BlockDist.x10"
        final long t$148105 = ((low) + (((long)(blockSize))));
        
        //#line 70 "x10/regionarray/BlockDist.x10"
        final boolean t$148103 = ((i) < (((long)(leftOver))));
        
        //#line 70 "x10/regionarray/BlockDist.x10"
        long t$148104 =  0;
        
        //#line 70 "x10/regionarray/BlockDist.x10"
        if (t$148103) {
            
            //#line 70 "x10/regionarray/BlockDist.x10"
            t$148104 = 0L;
        } else {
            
            //#line 70 "x10/regionarray/BlockDist.x10"
            t$148104 = -1L;
        }
        
        //#line 70 "x10/regionarray/BlockDist.x10"
        final long hi = ((t$148105) + (((long)(t$148104))));
        
        //#line 72 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148107 = ((x10.regionarray.Region)(this.region));
        
        //#line 72 "x10/regionarray/BlockDist.x10"
        final boolean t$148148 = x10.regionarray.RectRegion.$RTT.isInstance(t$148107);
        
        //#line 72 "x10/regionarray/BlockDist.x10"
        if (t$148148) {
            
            //#line 74 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Dist this$147810 = ((x10.regionarray.Dist)
                                                       this);
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$148108 = ((x10.regionarray.Region)(this$147810.region));
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final long t$148111 = t$148108.rank;
            
            //#line 74 "x10/regionarray/BlockDist.x10"
            final x10.core.fun.Fun_0_1 t$148112 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDist.$Closure$164(this, this.region)));
            
            //#line 74 "x10/regionarray/BlockDist.x10"
            final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148111)), ((x10.core.fun.Fun_0_1)(t$148112)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 75 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Dist this$147812 = ((x10.regionarray.Dist)
                                                       this);
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$148113 = ((x10.regionarray.Region)(this$147812.region));
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final long t$148116 = t$148113.rank;
            
            //#line 75 "x10/regionarray/BlockDist.x10"
            final x10.core.fun.Fun_0_1 t$148117 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDist.$Closure$165(this, this.region)));
            
            //#line 75 "x10/regionarray/BlockDist.x10"
            final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148116)), ((x10.core.fun.Fun_0_1)(t$148117)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 76 "x10/regionarray/BlockDist.x10"
            final long t$148118 = this.axis;
            
            //#line 76 "x10/regionarray/BlockDist.x10"
            ((long[])newMin.value)[(int)t$148118] = low;
            
            //#line 77 "x10/regionarray/BlockDist.x10"
            final long t$148119 = this.axis;
            
            //#line 77 "x10/regionarray/BlockDist.x10"
            ((long[])newMax.value)[(int)t$148119] = hi;
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.RectRegion alloc$147799 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            alloc$147799.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$147688 = ((x10.regionarray.Region)
                                                      alloc$147799);
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final long t$148121 = t$147688.rank;
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148120 = ((x10.regionarray.Region)(x10.regionarray.BlockDist.this.region));
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final long t$148122 = t$148120.rank;
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final boolean t$148123 = ((long) t$148121) == ((long) t$148122);
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final boolean t$148125 = !(t$148123);
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            if (t$148125) {
                
                //#line 78 "x10/regionarray/BlockDist.x10"
                final x10.lang.FailedDynamicCheckException t$148124 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.BlockDist).region.rank}");
                
                //#line 78 "x10/regionarray/BlockDist.x10"
                throw t$148124;
            }
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            return t$147688;
        } else {
            
            //#line 79 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148126 = ((x10.regionarray.Region)(this.region));
            
            //#line 79 "x10/regionarray/BlockDist.x10"
            final boolean t$148147 = x10.regionarray.RectRegion1D.$RTT.isInstance(t$148126);
            
            //#line 79 "x10/regionarray/BlockDist.x10"
            if (t$148147) {
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.RectRegion1D alloc$147800 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                alloc$147800.x10$regionarray$RectRegion1D$$init$S(((long)(low)), ((long)(hi)));
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$147690 = ((x10.regionarray.Region)
                                                          alloc$147800);
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final long t$148128 = t$147690.rank;
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148127 = ((x10.regionarray.Region)(x10.regionarray.BlockDist.this.region));
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final long t$148129 = t$148127.rank;
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final boolean t$148130 = ((long) t$148128) == ((long) t$148129);
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final boolean t$148132 = !(t$148130);
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                if (t$148132) {
                    
                    //#line 80 "x10/regionarray/BlockDist.x10"
                    final x10.lang.FailedDynamicCheckException t$148131 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.BlockDist).region.rank}");
                    
                    //#line 80 "x10/regionarray/BlockDist.x10"
                    throw t$148131;
                }
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                return t$147690;
            } else {
                
                //#line 83 "x10/regionarray/BlockDist.x10"
                final long rank$147814 = this.axis;
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$147815 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$147815.x10$regionarray$FullRegion$$init$S(((long)(rank$147814)));
                
                //#line 83 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region r1 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                              alloc$147815)));
                
                //#line 279 . "x10/regionarray/Region.x10"
                final x10.regionarray.RectRegion1D alloc$147819 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
                
                //#line 279 . "x10/regionarray/Region.x10"
                alloc$147819.x10$regionarray$RectRegion1D$$init$S(low, hi);
                
                //#line 84 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region r2 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                              alloc$147819)));
                
                //#line 85 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148133 = ((x10.regionarray.Region)(this.region));
                
                //#line 85 "x10/regionarray/BlockDist.x10"
                final long t$148134 = t$148133.rank;
                
                //#line 85 "x10/regionarray/BlockDist.x10"
                final long t$148135 = this.axis;
                
                //#line 85 "x10/regionarray/BlockDist.x10"
                final long t$148136 = ((t$148134) - (((long)(t$148135))));
                
                //#line 85 "x10/regionarray/BlockDist.x10"
                final long rank$147821 = ((t$148136) - (((long)(1L))));
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$147822 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$147822.x10$regionarray$FullRegion$$init$S(((long)(rank$147821)));
                
                //#line 85 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region r3 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                              alloc$147822)));
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148137 = ((x10.regionarray.Region)(r1.product(((x10.regionarray.Region)(r2)))));
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148138 = ((x10.regionarray.Region)(t$148137.product(((x10.regionarray.Region)(r3)))));
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$147706 = ((x10.regionarray.Region)
                                                          t$148138);
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final long t$148140 = t$147706.rank;
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148139 = ((x10.regionarray.Region)(x10.regionarray.BlockDist.this.region));
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final long t$148141 = t$148139.rank;
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final boolean t$148142 = ((long) t$148140) == ((long) t$148141);
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final boolean t$148144 = !(t$148142);
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                if (t$148144) {
                    
                    //#line 86 "x10/regionarray/BlockDist.x10"
                    final x10.lang.FailedDynamicCheckException t$148143 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.BlockDist).region.rank}");
                    
                    //#line 86 "x10/regionarray/BlockDist.x10"
                    throw t$148143;
                }
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148145 = ((x10.regionarray.Region)(this.region));
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148146 = ((x10.regionarray.Region)(t$147706.intersection(((x10.regionarray.Region)(t$148145)))));
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                return t$148146;
            }
        }
    }
    
    public static x10.regionarray.Region blockRegionForPlace$P(final x10.lang.Place place, final x10.regionarray.BlockDist BlockDist) {
        return BlockDist.blockRegionForPlace(((x10.lang.Place)(place)));
    }
    
    
    //#line 97 "x10/regionarray/BlockDist.x10"
    /**
     * Given an index into the "axis dimension" determine which place it 
     * is mapped to.
     *
     * Assumption: Caller has done error checking to ensure that index is 
     *   actually within the bounds of the axis dimension.
     */
    private x10.lang.Place mapIndexToPlace(final long index) {
        
        //#line 98 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148149 = ((x10.regionarray.Region)(this.region));
        
        //#line 98 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region bb = ((x10.regionarray.Region)(t$148149.boundingBox()));
        
        //#line 99 "x10/regionarray/BlockDist.x10"
        final long t$148150 = this.axis;
        
        //#line 99 "x10/regionarray/BlockDist.x10"
        final long min = bb.min$O((long)(t$148150));
        
        //#line 100 "x10/regionarray/BlockDist.x10"
        final long t$148151 = this.axis;
        
        //#line 100 "x10/regionarray/BlockDist.x10"
        final long max = bb.max$O((long)(t$148151));
        
        //#line 101 "x10/regionarray/BlockDist.x10"
        final x10.lang.PlaceGroup t$148152 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 101 "x10/regionarray/BlockDist.x10"
        final long P = t$148152.numPlaces$O();
        
        //#line 102 "x10/regionarray/BlockDist.x10"
        final long t$148153 = ((max) - (((long)(min))));
        
        //#line 102 "x10/regionarray/BlockDist.x10"
        final long numElems = ((t$148153) + (((long)(1L))));
        
        //#line 103 "x10/regionarray/BlockDist.x10"
        final long blockSize = ((numElems) / (((long)(P))));
        
        //#line 104 "x10/regionarray/BlockDist.x10"
        final long t$148154 = ((P) * (((long)(blockSize))));
        
        //#line 104 "x10/regionarray/BlockDist.x10"
        final long leftOver = ((numElems) - (((long)(t$148154))));
        
        //#line 105 "x10/regionarray/BlockDist.x10"
        final long normalizedIndex = ((index) - (((long)(min))));
        
        //#line 107 "x10/regionarray/BlockDist.x10"
        final long t$148155 = ((blockSize) + (((long)(1L))));
        
        //#line 107 "x10/regionarray/BlockDist.x10"
        final long nominalPlace = ((normalizedIndex) / (((long)(t$148155))));
        
        //#line 108 "x10/regionarray/BlockDist.x10"
        final boolean t$148165 = ((nominalPlace) < (((long)(leftOver))));
        
        //#line 108 "x10/regionarray/BlockDist.x10"
        if (t$148165) {
            
            //#line 109 "x10/regionarray/BlockDist.x10"
            final x10.lang.PlaceGroup t$148156 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 109 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148157 = t$148156.$apply((long)(nominalPlace));
            
            //#line 109 "x10/regionarray/BlockDist.x10"
            return t$148157;
        } else {
            
            //#line 111 "x10/regionarray/BlockDist.x10"
            final long indexFromTop = ((max) - (((long)(index))));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final x10.lang.PlaceGroup t$148162 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final x10.lang.PlaceGroup t$148158 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final long t$148159 = t$148158.numPlaces$O();
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final long t$148160 = ((t$148159) - (((long)(1L))));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final long t$148161 = ((indexFromTop) / (((long)(blockSize))));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final long t$148163 = ((t$148160) - (((long)(t$148161))));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148164 = t$148162.$apply((long)(t$148163));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            return t$148164;
        }
    }
    
    public static x10.lang.Place mapIndexToPlace$P(final long index, final x10.regionarray.BlockDist BlockDist) {
        return BlockDist.mapIndexToPlace((long)(index));
    }
    
    
    //#line 117 "x10/regionarray/BlockDist.x10"
    public x10.lang.PlaceGroup places() {
        
        //#line 117 "x10/regionarray/BlockDist.x10"
        final x10.lang.PlaceGroup t$148166 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 117 "x10/regionarray/BlockDist.x10"
        return t$148166;
    }
    
    
    //#line 119 "x10/regionarray/BlockDist.x10"
    public long numPlaces$O() {
        
        //#line 119 "x10/regionarray/BlockDist.x10"
        final x10.lang.PlaceGroup t$148167 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 119 "x10/regionarray/BlockDist.x10"
        final long t$148168 = t$148167.numPlaces$O();
        
        //#line 119 "x10/regionarray/BlockDist.x10"
        return t$148168;
    }
    
    
    //#line 121 "x10/regionarray/BlockDist.x10"
    public x10.lang.Iterable regions() {
        
        //#line 122 "x10/regionarray/BlockDist.x10"
        final x10.lang.PlaceGroup t$148169 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 122 "x10/regionarray/BlockDist.x10"
        final long t$148173 = t$148169.numPlaces$O();
        
        //#line 122 "x10/regionarray/BlockDist.x10"
        final x10.core.fun.Fun_0_1 t$148174 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDist.$Closure$166(this, this.pg)));
        
        //#line 122 "x10/regionarray/BlockDist.x10"
        final x10.core.Rail t$148175 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.Region>(x10.regionarray.Region.$RTT, t$148173, ((x10.core.fun.Fun_0_1)(t$148174)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 122 "x10/regionarray/BlockDist.x10"
        return t$148175;
    }
    
    
    //#line 125 "x10/regionarray/BlockDist.x10"
    public x10.regionarray.Region get(final x10.lang.Place p) {
        
        //#line 126 "x10/regionarray/BlockDist.x10"
        final boolean t$148181 = x10.rtt.Equality.equalsequals((p),(x10.x10rt.X10RT.here()));
        
        //#line 126 "x10/regionarray/BlockDist.x10"
        if (t$148181) {
            
            //#line 127 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148176 = ((x10.regionarray.Region)(this.regionForHere));
            
            //#line 127 "x10/regionarray/BlockDist.x10"
            final boolean t$148178 = ((t$148176) == (null));
            
            //#line 127 "x10/regionarray/BlockDist.x10"
            if (t$148178) {
                
                //#line 128 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148177 = ((x10.regionarray.Region)(this.blockRegionForPlace(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 128 "x10/regionarray/BlockDist.x10"
                this.regionForHere = ((x10.regionarray.Region)(t$148177));
            }
            
            //#line 130 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148179 = ((x10.regionarray.Region)(this.regionForHere));
            
            //#line 130 "x10/regionarray/BlockDist.x10"
            return t$148179;
        } else {
            
            //#line 132 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148180 = ((x10.regionarray.Region)(this.blockRegionForPlace(((x10.lang.Place)(p)))));
            
            //#line 132 "x10/regionarray/BlockDist.x10"
            return t$148180;
        }
    }
    
    
    //#line 136 "x10/regionarray/BlockDist.x10"
    public boolean containsLocally$O(final x10.lang.Point p) {
        
        //#line 136 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148182 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
        
        //#line 136 "x10/regionarray/BlockDist.x10"
        final boolean t$148183 = t$148182.contains$O(((x10.lang.Point)(p)));
        
        //#line 136 "x10/regionarray/BlockDist.x10"
        return t$148183;
    }
    
    
    //#line 140 "x10/regionarray/BlockDist.x10"
    public x10.regionarray.Region $apply(final x10.lang.Place p) {
        
        //#line 140 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148184 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(p)))));
        
        //#line 140 "x10/regionarray/BlockDist.x10"
        return t$148184;
    }
    
    
    //#line 142 "x10/regionarray/BlockDist.x10"
    public x10.lang.Place $apply(final x10.lang.Point pt) {
        
        //#line 143 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148185 = ((x10.regionarray.Region)(this.region));
        
        //#line 143 "x10/regionarray/BlockDist.x10"
        final boolean t$148186 = t$148185.contains$O(((x10.lang.Point)(pt)));
        
        //#line 143 "x10/regionarray/BlockDist.x10"
        final boolean t$148187 = !(t$148186);
        
        //#line 143 "x10/regionarray/BlockDist.x10"
        if (t$148187) {
            
            //#line 143 "x10/regionarray/BlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError(((x10.lang.Point)(pt)));
        }
        
        //#line 144 "x10/regionarray/BlockDist.x10"
        final long t$148188 = this.axis;
        
        //#line 144 "x10/regionarray/BlockDist.x10"
        final long t$148189 = pt.$apply$O((long)(t$148188));
        
        //#line 144 "x10/regionarray/BlockDist.x10"
        final x10.lang.Place t$148190 = this.mapIndexToPlace((long)(t$148189));
        
        //#line 144 "x10/regionarray/BlockDist.x10"
        return t$148190;
    }
    
    
    //#line 147 "x10/regionarray/BlockDist.x10"
    public x10.lang.Place $apply(final long i0) {
        
        //#line 148 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148193 = ((x10.regionarray.Region)(this.region));
        
        //#line 148 "x10/regionarray/BlockDist.x10"
        final boolean t$148194 = t$148193.contains$O((long)(i0));
        
        //#line 148 "x10/regionarray/BlockDist.x10"
        final boolean t$148195 = !(t$148194);
        
        //#line 148 "x10/regionarray/BlockDist.x10"
        if (t$148195) {
            
            //#line 148 "x10/regionarray/BlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0));
        }
        
        //#line 149 "x10/regionarray/BlockDist.x10"
        final x10.lang.Place t$148196 = this.mapIndexToPlace((long)(i0));
        
        //#line 149 "x10/regionarray/BlockDist.x10"
        return t$148196;
    }
    
    
    //#line 152 "x10/regionarray/BlockDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1) {
        
        //#line 153 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148199 = ((x10.regionarray.Region)(this.region));
        
        //#line 153 "x10/regionarray/BlockDist.x10"
        final boolean t$148200 = t$148199.contains$O((long)(i0), (long)(i1));
        
        //#line 153 "x10/regionarray/BlockDist.x10"
        final boolean t$148201 = !(t$148200);
        
        //#line 153 "x10/regionarray/BlockDist.x10"
        if (t$148201) {
            
            //#line 153 "x10/regionarray/BlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1));
        }
        
        //#line 154 "x10/regionarray/BlockDist.x10"
        final long t$148202 = this.axis;
        
        //#line 154 "x10/regionarray/BlockDist.x10"
        final boolean t$148203 = ((long) t$148202) == ((long) 0L);
        
        //#line 154 "x10/regionarray/BlockDist.x10"
        x10.lang.Place t$148204 =  null;
        
        //#line 154 "x10/regionarray/BlockDist.x10"
        if (t$148203) {
            
            //#line 154 "x10/regionarray/BlockDist.x10"
            t$148204 = this.mapIndexToPlace((long)(i0));
        } else {
            
            //#line 154 "x10/regionarray/BlockDist.x10"
            t$148204 = this.mapIndexToPlace((long)(i1));
        }
        
        //#line 154 "x10/regionarray/BlockDist.x10"
        return t$148204;
    }
    
    
    //#line 157 "x10/regionarray/BlockDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2) {
        
        //#line 158 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148208 = ((x10.regionarray.Region)(this.region));
        
        //#line 158 "x10/regionarray/BlockDist.x10"
        final boolean t$148209 = t$148208.contains$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 158 "x10/regionarray/BlockDist.x10"
        final boolean t$148210 = !(t$148209);
        
        //#line 158 "x10/regionarray/BlockDist.x10"
        if (t$148210) {
            
            //#line 158 "x10/regionarray/BlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 159 "x10/regionarray/BlockDist.x10"
        final long t$148211 = this.axis;
        
        //#line 159 "x10/regionarray/BlockDist.x10"
        final boolean t$148213 = ((long) t$148211) == ((long) 0L);
        
        //#line 159 "x10/regionarray/BlockDist.x10"
        if (t$148213) {
            
            //#line 159 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148212 = this.mapIndexToPlace((long)(i0));
            
            //#line 159 "x10/regionarray/BlockDist.x10"
            return t$148212;
        }
        
        //#line 160 "x10/regionarray/BlockDist.x10"
        final long t$148214 = this.axis;
        
        //#line 160 "x10/regionarray/BlockDist.x10"
        final boolean t$148216 = ((long) t$148214) == ((long) 1L);
        
        //#line 160 "x10/regionarray/BlockDist.x10"
        if (t$148216) {
            
            //#line 160 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148215 = this.mapIndexToPlace((long)(i1));
            
            //#line 160 "x10/regionarray/BlockDist.x10"
            return t$148215;
        }
        
        //#line 161 "x10/regionarray/BlockDist.x10"
        final x10.lang.Place t$148217 = this.mapIndexToPlace((long)(i2));
        
        //#line 161 "x10/regionarray/BlockDist.x10"
        return t$148217;
    }
    
    
    //#line 164 "x10/regionarray/BlockDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 165 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148220 = ((x10.regionarray.Region)(this.region));
        
        //#line 165 "x10/regionarray/BlockDist.x10"
        final boolean t$148221 = t$148220.contains$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 165 "x10/regionarray/BlockDist.x10"
        final boolean t$148222 = !(t$148221);
        
        //#line 165 "x10/regionarray/BlockDist.x10"
        if (t$148222) {
            
            //#line 165 "x10/regionarray/BlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        }
        
        //#line 166 "x10/regionarray/BlockDist.x10"
        final long t$148223 = this.axis;
        
        //#line 166 "x10/regionarray/BlockDist.x10"
        final boolean t$148225 = ((long) t$148223) == ((long) 0L);
        
        //#line 166 "x10/regionarray/BlockDist.x10"
        if (t$148225) {
            
            //#line 166 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148224 = this.mapIndexToPlace((long)(i0));
            
            //#line 166 "x10/regionarray/BlockDist.x10"
            return t$148224;
        }
        
        //#line 167 "x10/regionarray/BlockDist.x10"
        final long t$148226 = this.axis;
        
        //#line 167 "x10/regionarray/BlockDist.x10"
        final boolean t$148228 = ((long) t$148226) == ((long) 1L);
        
        //#line 167 "x10/regionarray/BlockDist.x10"
        if (t$148228) {
            
            //#line 167 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148227 = this.mapIndexToPlace((long)(i1));
            
            //#line 167 "x10/regionarray/BlockDist.x10"
            return t$148227;
        }
        
        //#line 168 "x10/regionarray/BlockDist.x10"
        final long t$148229 = this.axis;
        
        //#line 168 "x10/regionarray/BlockDist.x10"
        final boolean t$148231 = ((long) t$148229) == ((long) 2L);
        
        //#line 168 "x10/regionarray/BlockDist.x10"
        if (t$148231) {
            
            //#line 168 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148230 = this.mapIndexToPlace((long)(i2));
            
            //#line 168 "x10/regionarray/BlockDist.x10"
            return t$148230;
        }
        
        //#line 169 "x10/regionarray/BlockDist.x10"
        final x10.lang.Place t$148232 = this.mapIndexToPlace((long)(i3));
        
        //#line 169 "x10/regionarray/BlockDist.x10"
        return t$148232;
    }
    
    
    //#line 172 "x10/regionarray/BlockDist.x10"
    public x10.regionarray.Dist restriction(final x10.regionarray.Region r) {
        
        //#line 173 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.WrappedDistRegionRestricted alloc$147801 = ((x10.regionarray.WrappedDistRegionRestricted)(new x10.regionarray.WrappedDistRegionRestricted((java.lang.System[]) null)));
        
        //#line 173 "x10/regionarray/BlockDist.x10"
        alloc$147801.x10$regionarray$WrappedDistRegionRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.regionarray.Region)(r)));
        
        //#line 173 "x10/regionarray/BlockDist.x10"
        return alloc$147801;
    }
    
    
    //#line 176 "x10/regionarray/BlockDist.x10"
    public x10.regionarray.Dist restriction(final x10.lang.Place p) {
        
        //#line 177 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.WrappedDistPlaceRestricted alloc$147802 = ((x10.regionarray.WrappedDistPlaceRestricted)(new x10.regionarray.WrappedDistPlaceRestricted((java.lang.System[]) null)));
        
        //#line 177 "x10/regionarray/BlockDist.x10"
        alloc$147802.x10$regionarray$WrappedDistPlaceRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.lang.Place)(p)));
        
        //#line 177 "x10/regionarray/BlockDist.x10"
        return alloc$147802;
    }
    
    
    //#line 180 "x10/regionarray/BlockDist.x10"
    public x10.regionarray.BlockDistGhostManager getLocalGhostManager(final long ghostWidth, final boolean periodic) {
        
        //#line 181 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.BlockDistGhostManager alloc$147803 = ((x10.regionarray.BlockDistGhostManager)(new x10.regionarray.BlockDistGhostManager((java.lang.System[]) null)));
        
        //#line 181 "x10/regionarray/BlockDist.x10"
        alloc$147803.x10$regionarray$BlockDistGhostManager$$init$S(((long)(ghostWidth)), ((x10.regionarray.BlockDist)(this)), ((boolean)(periodic)));
        
        //#line 181 "x10/regionarray/BlockDist.x10"
        return alloc$147803;
    }
    
    
    //#line 184 "x10/regionarray/BlockDist.x10"
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 185 "x10/regionarray/BlockDist.x10"
        final boolean t$148233 = x10.rtt.Equality.equalsequals((this),(thatObj));
        
        //#line 185 "x10/regionarray/BlockDist.x10"
        if (t$148233) {
            
            //#line 185 "x10/regionarray/BlockDist.x10"
            return true;
        }
        
        //#line 186 "x10/regionarray/BlockDist.x10"
        final boolean t$148234 = x10.regionarray.BlockDist.$RTT.isInstance(thatObj);
        
        //#line 186 "x10/regionarray/BlockDist.x10"
        final boolean t$148236 = !(t$148234);
        
        //#line 186 "x10/regionarray/BlockDist.x10"
        if (t$148236) {
            
            //#line 186 "x10/regionarray/BlockDist.x10"
            final boolean t$148235 = super.equals(((java.lang.Object)(thatObj)));
            
            //#line 186 "x10/regionarray/BlockDist.x10"
            return t$148235;
        }
        
        //#line 187 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.BlockDist that = ((x10.regionarray.BlockDist)(x10.rtt.Types.<x10.regionarray.BlockDist> cast(thatObj,x10.regionarray.BlockDist.$RTT)));
        
        //#line 188 "x10/regionarray/BlockDist.x10"
        final long t$148237 = this.axis;
        
        //#line 188 "x10/regionarray/BlockDist.x10"
        final long t$148238 = that.axis;
        
        //#line 188 "x10/regionarray/BlockDist.x10"
        boolean t$148241 = x10.rtt.Equality.equalsequals(t$148237, ((long)(t$148238)));
        
        //#line 188 "x10/regionarray/BlockDist.x10"
        if (t$148241) {
            
            //#line 188 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148239 = ((x10.regionarray.Region)(this.region));
            
            //#line 188 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148240 = ((x10.regionarray.Region)(that.region));
            
            //#line 188 "x10/regionarray/BlockDist.x10"
            t$148241 = t$148239.equals(((java.lang.Object)(t$148240)));
        }
        
        //#line 188 "x10/regionarray/BlockDist.x10"
        return t$148241;
    }
    
    
    //#line 28 "x10/regionarray/BlockDist.x10"
    final public x10.regionarray.BlockDist x10$regionarray$BlockDist$$this$x10$regionarray$BlockDist() {
        
        //#line 28 "x10/regionarray/BlockDist.x10"
        return x10.regionarray.BlockDist.this;
    }
    
    
    //#line 28 "x10/regionarray/BlockDist.x10"
    final public void __fieldInitializers_x10_regionarray_BlockDist() {
        
        //#line 28 "x10/regionarray/BlockDist.x10"
        this.regionForHere = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$164 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$164> $RTT = 
            x10.rtt.StaticFunType.<$Closure$164> make($Closure$164.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDist.$Closure$164 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.region = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDist.$Closure$164 $_obj = new x10.regionarray.BlockDist.$Closure$164((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.region);
            
        }
        
        // constructor just for allocation
        public $Closure$164(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 74 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148109 = ((x10.regionarray.Region)(this.region));
            
            //#line 74 "x10/regionarray/BlockDist.x10"
            final long t$148110 = t$148109.min$O((long)(i));
            
            //#line 74 "x10/regionarray/BlockDist.x10"
            return t$148110;
        }
        
        public x10.regionarray.BlockDist out$$;
        public x10.regionarray.Region region;
        
        public $Closure$164(final x10.regionarray.BlockDist out$$, final x10.regionarray.Region region) {
             {
                this.out$$ = out$$;
                this.region = ((x10.regionarray.Region)(region));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$165 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$165> $RTT = 
            x10.rtt.StaticFunType.<$Closure$165> make($Closure$165.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDist.$Closure$165 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.region = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDist.$Closure$165 $_obj = new x10.regionarray.BlockDist.$Closure$165((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.region);
            
        }
        
        // constructor just for allocation
        public $Closure$165(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 75 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148114 = ((x10.regionarray.Region)(this.region));
            
            //#line 75 "x10/regionarray/BlockDist.x10"
            final long t$148115 = t$148114.max$O((long)(i));
            
            //#line 75 "x10/regionarray/BlockDist.x10"
            return t$148115;
        }
        
        public x10.regionarray.BlockDist out$$;
        public x10.regionarray.Region region;
        
        public $Closure$165(final x10.regionarray.BlockDist out$$, final x10.regionarray.Region region) {
             {
                this.out$$ = out$$;
                this.region = ((x10.regionarray.Region)(region));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$166 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$166> $RTT = 
            x10.rtt.StaticFunType.<$Closure$166> make($Closure$166.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.regionarray.Region.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDist.$Closure$166 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDist.$Closure$166 $_obj = new x10.regionarray.BlockDist.$Closure$166((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$166(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.regionarray.Region $apply(final long i) {
            
            //#line 122 "x10/regionarray/BlockDist.x10"
            final x10.lang.PlaceGroup t$148170 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 122 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148171 = t$148170.$apply((long)(i));
            
            //#line 122 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148172 = ((x10.regionarray.Region)(this.out$$.blockRegionForPlace(((x10.lang.Place)(t$148171)))));
            
            //#line 122 "x10/regionarray/BlockDist.x10"
            return t$148172;
        }
        
        public x10.regionarray.BlockDist out$$;
        public x10.lang.PlaceGroup pg;
        
        public $Closure$166(final x10.regionarray.BlockDist out$$, final x10.lang.PlaceGroup pg) {
             {
                this.out$$ = out$$;
                this.pg = ((x10.lang.PlaceGroup)(pg));
            }
        }
        
    }
    
    
    public boolean x10$regionarray$Dist$equals$S$O(final java.lang.Object a0) {
        return super.equals(((java.lang.Object)(a0)));
    }
}

