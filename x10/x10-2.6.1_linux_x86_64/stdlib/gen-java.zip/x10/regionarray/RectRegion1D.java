package x10.regionarray;


/**
 * A RectRegion1D is a finite dense rectangular region of rank 1.
 * This is a space-optimized implementation of the more general
 * RectRegion class intended primarily to reduce the memory
 * overhead and serialization cost of Array meta-data.
 */
@x10.runtime.impl.java.X10Generated
final public class RectRegion1D extends x10.regionarray.Region implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<RectRegion1D> $RTT = 
        x10.rtt.NamedType.<RectRegion1D> make("x10.regionarray.RectRegion1D",
                                              RectRegion1D.class,
                                              new x10.rtt.Type[] {
                                                  x10.regionarray.Region.$RTT
                                              });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion1D $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Region.$_deserialize_body($_obj, $deserializer);
        $_obj.max = $deserializer.readLong();
        $_obj.min = $deserializer.readLong();
        $_obj.size = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.RectRegion1D $_obj = new x10.regionarray.RectRegion1D((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.max);
        $serializer.write(this.min);
        $serializer.write(this.size);
        
    }
    
    // constructor just for allocation
    public RectRegion1D(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 23 "x10/regionarray/RectRegion1D.x10"
    public long size;
    
    //#line 24 "x10/regionarray/RectRegion1D.x10"
    public long min;
    
    //#line 25 "x10/regionarray/RectRegion1D.x10"
    public long max;
    
    
    //#line 30 "x10/regionarray/RectRegion1D.x10"
    /**
     * Create a 1-dim region min..max.
     */
    // creation method for java code (1-phase java constructor)
    public RectRegion1D(final long minArg, final long maxArg) {
        this((java.lang.System[]) null);
        x10$regionarray$RectRegion1D$$init$S(minArg, maxArg);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.RectRegion1D x10$regionarray$RectRegion1D$$init$S(final long minArg, final long maxArg) {
         {
            
            //#line 31 "x10/regionarray/RectRegion1D.x10"
            final x10.regionarray.Region this$157503 = ((x10.regionarray.Region)(this));
            
            //#line 31 "x10/regionarray/RectRegion1D.x10"
            final boolean z$157501 = ((long) minArg) == ((long) 0L);
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$157503.rank = 1L;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$157503.rect = true;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$157503.zeroBased = z$157501;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$157503.rail = z$157501;
            
            //#line 30 "x10/regionarray/RectRegion1D.x10"
            
            
            //#line 34 "x10/regionarray/RectRegion1D.x10"
            final long t$157538 = ((maxArg) - (((long)(minArg))));
            
            //#line 34 "x10/regionarray/RectRegion1D.x10"
            final long s = ((t$157538) + (((long)(1L))));
            
            //#line 35 "x10/regionarray/RectRegion1D.x10"
            final long t$157539 = java.lang.Long.MIN_VALUE;
            
            //#line 35 "x10/regionarray/RectRegion1D.x10"
            boolean t$157541 = ((long) minArg) == ((long) t$157539);
            
            //#line 35 "x10/regionarray/RectRegion1D.x10"
            if (t$157541) {
                
                //#line 35 "x10/regionarray/RectRegion1D.x10"
                final long t$157540 = java.lang.Long.MAX_VALUE;
                
                //#line 35 "x10/regionarray/RectRegion1D.x10"
                t$157541 = ((long) maxArg) == ((long) t$157540);
            }
            
            //#line 35 "x10/regionarray/RectRegion1D.x10"
            if (t$157541) {
                
                //#line 36 "x10/regionarray/RectRegion1D.x10"
                this.size = -1L;
            } else {
                
                //#line 38 "x10/regionarray/RectRegion1D.x10"
                final boolean t$157542 = ((s) > (((long)(0L))));
                
                //#line 38 "x10/regionarray/RectRegion1D.x10"
                long t$157543 =  0;
                
                //#line 38 "x10/regionarray/RectRegion1D.x10"
                if (t$157542) {
                    
                    //#line 38 "x10/regionarray/RectRegion1D.x10"
                    t$157543 = s;
                } else {
                    
                    //#line 38 "x10/regionarray/RectRegion1D.x10"
                    t$157543 = 0L;
                }
                
                //#line 38 "x10/regionarray/RectRegion1D.x10"
                this.size = t$157543;
            }
            
            //#line 40 "x10/regionarray/RectRegion1D.x10"
            this.min = minArg;
            
            //#line 41 "x10/regionarray/RectRegion1D.x10"
            this.max = maxArg;
        }
        return this;
    }
    
    
    
    //#line 50 "x10/regionarray/RectRegion1D.x10"
    /**
     * Create a 1-dim region 0..max.
     * Separate constructor so the constraint solver can correctly determine
     * statically that the zeroBased and rail properties are true for all regions
     * made via this constructor.
     */
    // creation method for java code (1-phase java constructor)
    public RectRegion1D(final long maxArg) {
        this((java.lang.System[]) null);
        x10$regionarray$RectRegion1D$$init$S(maxArg);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.RectRegion1D x10$regionarray$RectRegion1D$$init$S(final long maxArg) {
         {
            
            //#line 51 "x10/regionarray/RectRegion1D.x10"
            final x10.regionarray.Region this$157509 = ((x10.regionarray.Region)(this));
            
            //#line 51 "x10/regionarray/RectRegion1D.x10"
            final long t$157546 = ((long)(((int)(1))));
            
            //#line 51 "x10/regionarray/RectRegion1D.x10"
            final long t$138357 = t$157546;
            
            //#line 51 "x10/regionarray/RectRegion1D.x10"
            final boolean t$157547 = ((long) t$138357) == ((long) 1L);
            
            //#line 51 "x10/regionarray/RectRegion1D.x10"
            final boolean t$157549 = !(t$157547);
            
            //#line 51 "x10/regionarray/RectRegion1D.x10"
            if (t$157549) {
                
                //#line 51 "x10/regionarray/RectRegion1D.x10"
                final x10.lang.FailedDynamicCheckException t$157548 = new x10.lang.FailedDynamicCheckException("x10.lang.Long{self==1L}");
                
                //#line 51 "x10/regionarray/RectRegion1D.x10"
                throw t$157548;
            }
            
            //#line 566 . "x10/regionarray/Region.x10"
            this$157509.rank = t$138357;
            
            //#line 566 . "x10/regionarray/Region.x10"
            this$157509.rect = true;
            
            //#line 566 . "x10/regionarray/Region.x10"
            this$157509.zeroBased = true;
            
            //#line 566 . "x10/regionarray/Region.x10"
            this$157509.rail = true;
            
            //#line 50 "x10/regionarray/RectRegion1D.x10"
            
            
            //#line 53 "x10/regionarray/RectRegion1D.x10"
            final long t$157550 = ((maxArg) + (((long)(1L))));
            
            //#line 53 "x10/regionarray/RectRegion1D.x10"
            this.size = t$157550;
            
            //#line 54 "x10/regionarray/RectRegion1D.x10"
            this.min = 0L;
            
            //#line 55 "x10/regionarray/RectRegion1D.x10"
            this.max = maxArg;
        }
        return this;
    }
    
    
    
    //#line 58 "x10/regionarray/RectRegion1D.x10"
    public long size$O() {
        
        //#line 59 "x10/regionarray/RectRegion1D.x10"
        final long t$157551 = this.size;
        
        //#line 59 "x10/regionarray/RectRegion1D.x10"
        final boolean t$157553 = ((t$157551) < (((long)(0L))));
        
        //#line 59 "x10/regionarray/RectRegion1D.x10"
        if (t$157553) {
            
            //#line 59 "x10/regionarray/RectRegion1D.x10"
            final x10.regionarray.UnboundedRegionException t$157552 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)("size exceeds capacity of long")))));
            
            //#line 59 "x10/regionarray/RectRegion1D.x10"
            throw t$157552;
        }
        
        //#line 60 "x10/regionarray/RectRegion1D.x10"
        final long t$157554 = this.size;
        
        //#line 60 "x10/regionarray/RectRegion1D.x10"
        return t$157554;
    }
    
    
    //#line 63 "x10/regionarray/RectRegion1D.x10"
    public boolean isConvex$O() {
        
        //#line 63 "x10/regionarray/RectRegion1D.x10"
        return true;
    }
    
    
    //#line 65 "x10/regionarray/RectRegion1D.x10"
    public boolean isEmpty$O() {
        
        //#line 65 "x10/regionarray/RectRegion1D.x10"
        final long t$157555 = this.size;
        
        //#line 65 "x10/regionarray/RectRegion1D.x10"
        final boolean t$157556 = ((long) t$157555) == ((long) 0L);
        
        //#line 65 "x10/regionarray/RectRegion1D.x10"
        return t$157556;
    }
    
    
    //#line 67 "x10/regionarray/RectRegion1D.x10"
    public long indexOf$O(final x10.lang.Point pt) {
        
        //#line 68 "x10/regionarray/RectRegion1D.x10"
        final boolean t$157557 = this.contains$O(((x10.lang.Point)(pt)));
        
        //#line 68 "x10/regionarray/RectRegion1D.x10"
        final boolean t$157558 = !(t$157557);
        
        //#line 68 "x10/regionarray/RectRegion1D.x10"
        if (t$157558) {
            
            //#line 68 "x10/regionarray/RectRegion1D.x10"
            return -1L;
        }
        
        //#line 69 "x10/regionarray/RectRegion1D.x10"
        final long t$157559 = pt.$apply$O((long)(0L));
        
        //#line 69 "x10/regionarray/RectRegion1D.x10"
        final long t$157560 = this.min;
        
        //#line 69 "x10/regionarray/RectRegion1D.x10"
        final long t$157561 = ((t$157559) - (((long)(t$157560))));
        
        //#line 69 "x10/regionarray/RectRegion1D.x10"
        return t$157561;
    }
    
    
    //#line 72 "x10/regionarray/RectRegion1D.x10"
    public long indexOf$O(final long i0) {
        
        //#line 73 "x10/regionarray/RectRegion1D.x10"
        final boolean t$157574 = this.zeroBased;
        
        //#line 73 "x10/regionarray/RectRegion1D.x10"
        if (t$157574) {
            
            //#line 74 "x10/regionarray/RectRegion1D.x10"
            final x10.regionarray.RectRegion1D this$157515 = ((x10.regionarray.RectRegion1D)(this));
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            final long t$157562 = this$157515.min;
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            boolean t$157564 = ((i0) >= (((long)(t$157562))));
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            if (t$157564) {
                
                //#line 122 . "x10/regionarray/RectRegion1D.x10"
                final long t$157563 = this$157515.max;
                
                //#line 122 . "x10/regionarray/RectRegion1D.x10"
                t$157564 = ((i0) <= (((long)(t$157563))));
            }
            
            //#line 74 "x10/regionarray/RectRegion1D.x10"
            final boolean t$157566 = !(t$157564);
            
            //#line 74 "x10/regionarray/RectRegion1D.x10"
            if (t$157566) {
                
                //#line 74 "x10/regionarray/RectRegion1D.x10"
                return -1L;
            }
            
            //#line 75 "x10/regionarray/RectRegion1D.x10"
            return i0;
        } else {
            
            //#line 77 "x10/regionarray/RectRegion1D.x10"
            final x10.regionarray.RectRegion1D this$157518 = ((x10.regionarray.RectRegion1D)(this));
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            final long t$157567 = this$157518.min;
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            boolean t$157569 = ((i0) >= (((long)(t$157567))));
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            if (t$157569) {
                
                //#line 122 . "x10/regionarray/RectRegion1D.x10"
                final long t$157568 = this$157518.max;
                
                //#line 122 . "x10/regionarray/RectRegion1D.x10"
                t$157569 = ((i0) <= (((long)(t$157568))));
            }
            
            //#line 77 "x10/regionarray/RectRegion1D.x10"
            final boolean t$157571 = !(t$157569);
            
            //#line 77 "x10/regionarray/RectRegion1D.x10"
            if (t$157571) {
                
                //#line 77 "x10/regionarray/RectRegion1D.x10"
                return -1L;
            }
            
            //#line 78 "x10/regionarray/RectRegion1D.x10"
            final long t$157572 = this.min;
            
            //#line 78 "x10/regionarray/RectRegion1D.x10"
            final long t$157573 = ((i0) - (((long)(t$157572))));
            
            //#line 78 "x10/regionarray/RectRegion1D.x10"
            return t$157573;
        }
    }
    
    
    //#line 82 "x10/regionarray/RectRegion1D.x10"
    public long indexOf$O(final long i0, final long i1) {
        
        //#line 82 "x10/regionarray/RectRegion1D.x10"
        return -1L;
    }
    
    
    //#line 84 "x10/regionarray/RectRegion1D.x10"
    public long indexOf$O(final long i0, final long i1, final long i2) {
        
        //#line 84 "x10/regionarray/RectRegion1D.x10"
        return -1L;
    }
    
    
    //#line 86 "x10/regionarray/RectRegion1D.x10"
    public long indexOf$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 86 "x10/regionarray/RectRegion1D.x10"
        return -1L;
    }
    
    
    //#line 89 "x10/regionarray/RectRegion1D.x10"
    public long min$O(final long i) {
        
        //#line 90 "x10/regionarray/RectRegion1D.x10"
        final boolean t$157579 = ((long) i) != ((long) 0L);
        
        //#line 90 "x10/regionarray/RectRegion1D.x10"
        if (t$157579) {
            
            //#line 90 "x10/regionarray/RectRegion1D.x10"
            final java.lang.String t$157575 = (("min: ") + ((x10.core.Long.$box(i))));
            
            //#line 90 "x10/regionarray/RectRegion1D.x10"
            final java.lang.String t$157576 = ((t$157575) + (" is not a valid rank for "));
            
            //#line 90 "x10/regionarray/RectRegion1D.x10"
            final java.lang.String t$157577 = ((t$157576) + (this));
            
            //#line 90 "x10/regionarray/RectRegion1D.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$157578 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$157577)));
            
            //#line 90 "x10/regionarray/RectRegion1D.x10"
            throw t$157578;
        }
        
        //#line 91 "x10/regionarray/RectRegion1D.x10"
        final long t$157580 = this.min;
        
        //#line 91 "x10/regionarray/RectRegion1D.x10"
        return t$157580;
    }
    
    
    //#line 94 "x10/regionarray/RectRegion1D.x10"
    public long max$O(final long i) {
        
        //#line 95 "x10/regionarray/RectRegion1D.x10"
        final boolean t$157585 = ((long) i) != ((long) 0L);
        
        //#line 95 "x10/regionarray/RectRegion1D.x10"
        if (t$157585) {
            
            //#line 95 "x10/regionarray/RectRegion1D.x10"
            final java.lang.String t$157581 = (("max: ") + ((x10.core.Long.$box(i))));
            
            //#line 95 "x10/regionarray/RectRegion1D.x10"
            final java.lang.String t$157582 = ((t$157581) + (" is not a valid rank for "));
            
            //#line 95 "x10/regionarray/RectRegion1D.x10"
            final java.lang.String t$157583 = ((t$157582) + (this));
            
            //#line 95 "x10/regionarray/RectRegion1D.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$157584 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$157583)));
            
            //#line 95 "x10/regionarray/RectRegion1D.x10"
            throw t$157584;
        }
        
        //#line 96 "x10/regionarray/RectRegion1D.x10"
        final long t$157586 = this.max;
        
        //#line 96 "x10/regionarray/RectRegion1D.x10"
        return t$157586;
    }
    
    
    //#line 104 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region computeBoundingBox() {
        
        //#line 104 "x10/regionarray/RectRegion1D.x10"
        return this;
    }
    
    
    //#line 106 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.RectRegion toRectRegion() {
        
        //#line 106 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion alloc$138684 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 106 "x10/regionarray/RectRegion1D.x10"
        final long min$157520 = this.min;
        
        //#line 106 "x10/regionarray/RectRegion1D.x10"
        final long max$157521 = this.max;
        
        //#line 105 . "x10/regionarray/RectRegion.x10"
        final boolean z$157652 = ((long) min$157520) == ((long) 0L);
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$138684.rank = 1L;
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$138684.rect = true;
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$138684.zeroBased = z$157652;
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$138684.rail = z$157652;
        
        //#line 21 .. "x10/regionarray/RectRegion.x10"
        alloc$138684.polyRep = null;
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        final long t$157653 = java.lang.Long.MIN_VALUE;
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        boolean t$157654 = ((long) min$157520) == ((long) t$157653);
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        if (t$157654) {
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            final long t$157655 = java.lang.Long.MAX_VALUE;
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            t$157654 = ((long) max$157521) == ((long) t$157655);
        }
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        long t$157657 =  0;
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        if (t$157654) {
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            t$157657 = -1L;
        } else {
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            final long t$157658 = ((max$157521) - (((long)(min$157520))));
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            t$157657 = ((t$157658) + (((long)(1L))));
        }
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        alloc$138684.size = t$157657;
        
        //#line 108 . "x10/regionarray/RectRegion.x10"
        alloc$138684.min0 = min$157520;
        
        //#line 109 . "x10/regionarray/RectRegion.x10"
        alloc$138684.max0 = max$157521;
        
        //#line 111 . "x10/regionarray/RectRegion.x10"
        final long t$157660 = alloc$138684.min3 = 0L;
        
        //#line 111 . "x10/regionarray/RectRegion.x10"
        final long t$157661 = alloc$138684.min2 = t$157660;
        
        //#line 111 . "x10/regionarray/RectRegion.x10"
        alloc$138684.min1 = t$157661;
        
        //#line 112 . "x10/regionarray/RectRegion.x10"
        final long t$157662 = alloc$138684.max3 = 0L;
        
        //#line 112 . "x10/regionarray/RectRegion.x10"
        final long t$157663 = alloc$138684.max2 = t$157662;
        
        //#line 112 . "x10/regionarray/RectRegion.x10"
        alloc$138684.max1 = t$157663;
        
        //#line 113 . "x10/regionarray/RectRegion.x10"
        alloc$138684.mins = null;
        
        //#line 114 . "x10/regionarray/RectRegion.x10"
        alloc$138684.maxs = null;
        
        //#line 106 "x10/regionarray/RectRegion1D.x10"
        return alloc$138684;
    }
    
    
    //#line 108 "x10/regionarray/RectRegion1D.x10"
    public x10.core.fun.Fun_0_1 min() {
        
        //#line 108 "x10/regionarray/RectRegion1D.x10"
        final x10.core.fun.Fun_0_1 t$157599 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion1D.$Closure$248(this)));
        
        //#line 108 "x10/regionarray/RectRegion1D.x10"
        return t$157599;
    }
    
    
    //#line 109 "x10/regionarray/RectRegion1D.x10"
    public x10.core.fun.Fun_0_1 max() {
        
        //#line 109 "x10/regionarray/RectRegion1D.x10"
        final x10.core.fun.Fun_0_1 t$157601 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion1D.$Closure$249(this)));
        
        //#line 109 "x10/regionarray/RectRegion1D.x10"
        return t$157601;
    }
    
    
    //#line 111 "x10/regionarray/RectRegion1D.x10"
    public boolean contains$O(final x10.regionarray.Region that) {
        
        //#line 112 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion t$157602 = ((x10.regionarray.RectRegion)(this.toRectRegion()));
        
        //#line 112 "x10/regionarray/RectRegion1D.x10"
        final boolean t$157603 = t$157602.contains$O(((x10.regionarray.Region)(that)));
        
        //#line 112 "x10/regionarray/RectRegion1D.x10"
        return t$157603;
    }
    
    
    //#line 115 "x10/regionarray/RectRegion1D.x10"
    public boolean contains$O(final x10.lang.Point p) {
        
        //#line 116 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion t$157604 = ((x10.regionarray.RectRegion)(this.toRectRegion()));
        
        //#line 116 "x10/regionarray/RectRegion1D.x10"
        final boolean t$157605 = t$157604.contains$O(((x10.lang.Point)(p)));
        
        //#line 116 "x10/regionarray/RectRegion1D.x10"
        return t$157605;
    }
    
    
    //#line 119 "x10/regionarray/RectRegion1D.x10"
    public boolean contains$O(final long i0) {
        
        //#line 119 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion1D this$157531 = ((x10.regionarray.RectRegion1D)(this));
        
        //#line 122 . "x10/regionarray/RectRegion1D.x10"
        final long t$157606 = this$157531.min;
        
        //#line 122 . "x10/regionarray/RectRegion1D.x10"
        boolean t$157608 = ((i0) >= (((long)(t$157606))));
        
        //#line 122 . "x10/regionarray/RectRegion1D.x10"
        if (t$157608) {
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            final long t$157607 = this$157531.max;
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            t$157608 = ((i0) <= (((long)(t$157607))));
        }
        
        //#line 119 "x10/regionarray/RectRegion1D.x10"
        return t$157608;
    }
    
    
    //#line 121 "x10/regionarray/RectRegion1D.x10"
    private boolean containsInternal$O(final long i0) {
        
        //#line 122 "x10/regionarray/RectRegion1D.x10"
        final long t$157610 = this.min;
        
        //#line 122 "x10/regionarray/RectRegion1D.x10"
        boolean t$157612 = ((i0) >= (((long)(t$157610))));
        
        //#line 122 "x10/regionarray/RectRegion1D.x10"
        if (t$157612) {
            
            //#line 122 "x10/regionarray/RectRegion1D.x10"
            final long t$157611 = this.max;
            
            //#line 122 "x10/regionarray/RectRegion1D.x10"
            t$157612 = ((i0) <= (((long)(t$157611))));
        }
        
        //#line 122 "x10/regionarray/RectRegion1D.x10"
        return t$157612;
    }
    
    public static boolean containsInternal$P$O(final long i0, final x10.regionarray.RectRegion1D RectRegion1D) {
        return RectRegion1D.containsInternal$O((long)(i0));
    }
    
    
    //#line 125 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region toPolyRegion() {
        
        //#line 126 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion t$157614 = ((x10.regionarray.RectRegion)(this.toRectRegion()));
        
        //#line 126 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.Region t$157615 = ((x10.regionarray.Region)(t$157614.toPolyRegion()));
        
        //#line 126 "x10/regionarray/RectRegion1D.x10"
        return t$157615;
    }
    
    
    //#line 129 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region intersection(final x10.regionarray.Region that) {
        
        //#line 130 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion t$157616 = ((x10.regionarray.RectRegion)(this.toRectRegion()));
        
        //#line 130 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.Region t$157617 = ((x10.regionarray.Region)(t$157616.intersection(((x10.regionarray.Region)(that)))));
        
        //#line 130 "x10/regionarray/RectRegion1D.x10"
        return t$157617;
    }
    
    
    //#line 134 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region product(final x10.regionarray.Region that) {
        
        //#line 135 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion t$157618 = ((x10.regionarray.RectRegion)(this.toRectRegion()));
        
        //#line 135 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.Region t$157619 = ((x10.regionarray.Region)(t$157618.product(((x10.regionarray.Region)(that)))));
        
        //#line 135 "x10/regionarray/RectRegion1D.x10"
        return t$157619;
    }
    
    
    //#line 138 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region translate(final x10.lang.Point v) {
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion1D alloc$138685 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final long t$157664 = this.min;
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final long t$157665 = v.$apply$O((long)(0L));
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final long t$157666 = ((t$157664) + (((long)(t$157665))));
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final long t$157667 = this.max;
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final long t$157668 = v.$apply$O((long)(0L));
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final long t$157669 = ((t$157667) + (((long)(t$157668))));
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        alloc$138685.x10$regionarray$RectRegion1D$$init$S(t$157666, t$157669);
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        return alloc$138685;
    }
    
    
    //#line 142 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region projection(final long axis) {
        
        //#line 143 "x10/regionarray/RectRegion1D.x10"
        final boolean t$157626 = ((long) axis) == ((long) 0L);
        
        //#line 143 "x10/regionarray/RectRegion1D.x10"
        if (t$157626) {
            
            //#line 143 "x10/regionarray/RectRegion1D.x10"
            return this;
        }
        
        //#line 144 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$157627 = (("projection: ") + ((x10.core.Long.$box(axis))));
        
        //#line 144 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$157628 = ((t$157627) + (" is not a valid rank for "));
        
        //#line 144 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$157629 = ((t$157628) + (this));
        
        //#line 144 "x10/regionarray/RectRegion1D.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$157630 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$157629)));
        
        //#line 144 "x10/regionarray/RectRegion1D.x10"
        throw t$157630;
    }
    
    
    //#line 147 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region eliminate(final long axis) {
        
        //#line 148 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion t$157631 = ((x10.regionarray.RectRegion)(this.toRectRegion()));
        
        //#line 148 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.Region t$157632 = ((x10.regionarray.Region)(t$157631.eliminate((long)(axis))));
        
        //#line 148 "x10/regionarray/RectRegion1D.x10"
        return t$157632;
    }
    
    
    //#line 151 "x10/regionarray/RectRegion1D.x10"
    @x10.runtime.impl.java.X10Generated
    public static class RRIterator extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<RRIterator> $RTT = 
            x10.rtt.NamedType.<RRIterator> make("x10.regionarray.RectRegion1D.RRIterator",
                                                RRIterator.class,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                                });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion1D.RRIterator $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur = $deserializer.readLong();
            $_obj.max = $deserializer.readLong();
            $_obj.min = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion1D.RRIterator $_obj = new x10.regionarray.RectRegion1D.RRIterator((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur);
            $serializer.write(this.max);
            $serializer.write(this.min);
            
        }
        
        // constructor just for allocation
        public RRIterator(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.lang.Point next$G() {
            return next();
        }
        
        
    
        
        //#line 152 "x10/regionarray/RectRegion1D.x10"
        public long min;
        
        //#line 153 "x10/regionarray/RectRegion1D.x10"
        public long max;
        
        //#line 154 "x10/regionarray/RectRegion1D.x10"
        public long cur;
        
        
        //#line 156 "x10/regionarray/RectRegion1D.x10"
        // creation method for java code (1-phase java constructor)
        public RRIterator(final x10.regionarray.RectRegion1D rr) {
            this((java.lang.System[]) null);
            x10$regionarray$RectRegion1D$RRIterator$$init$S(rr);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.RectRegion1D.RRIterator x10$regionarray$RectRegion1D$RRIterator$$init$S(final x10.regionarray.RectRegion1D rr) {
             {
                
                //#line 156 "x10/regionarray/RectRegion1D.x10"
                
                
                //#line 151 "x10/regionarray/RectRegion1D.x10"
                final x10.regionarray.RectRegion1D.RRIterator this$157670 = this;
                
                //#line 151 "x10/regionarray/RectRegion1D.x10"
                this$157670.cur = 0L;
                
                //#line 157 "x10/regionarray/RectRegion1D.x10"
                final long t$157633 = rr.min;
                
                //#line 157 "x10/regionarray/RectRegion1D.x10"
                this.min = t$157633;
                
                //#line 158 "x10/regionarray/RectRegion1D.x10"
                final long t$157634 = rr.max;
                
                //#line 158 "x10/regionarray/RectRegion1D.x10"
                this.max = t$157634;
                
                //#line 159 "x10/regionarray/RectRegion1D.x10"
                final long t$157635 = this.min;
                
                //#line 159 "x10/regionarray/RectRegion1D.x10"
                this.cur = t$157635;
            }
            return this;
        }
        
        
        
        //#line 162 "x10/regionarray/RectRegion1D.x10"
        public boolean hasNext$O() {
            
            //#line 162 "x10/regionarray/RectRegion1D.x10"
            final long t$157636 = this.cur;
            
            //#line 162 "x10/regionarray/RectRegion1D.x10"
            final long t$157637 = this.max;
            
            //#line 162 "x10/regionarray/RectRegion1D.x10"
            final boolean t$157638 = ((t$157636) <= (((long)(t$157637))));
            
            //#line 162 "x10/regionarray/RectRegion1D.x10"
            return t$157638;
        }
        
        
        //#line 164 "x10/regionarray/RectRegion1D.x10"
        public x10.lang.Point next() {
            
            //#line 165 "x10/regionarray/RectRegion1D.x10"
            final long t$157639 = this.cur;
            
            //#line 165 "x10/regionarray/RectRegion1D.x10"
            final long t$157640 = ((t$157639) + (((long)(1L))));
            
            //#line 165 "x10/regionarray/RectRegion1D.x10"
            final long t$157641 = this.cur = t$157640;
            
            //#line 165 "x10/regionarray/RectRegion1D.x10"
            final long i$157535 = ((t$157641) - (((long)(1L))));
            
            //#line 151 . "x10/lang/Point.x10"
            final x10.lang.Point alloc$157536 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 151 . "x10/lang/Point.x10"
            alloc$157536.x10$lang$Point$$init$S(((long)(i$157535)));
            
            //#line 165 "x10/regionarray/RectRegion1D.x10"
            return alloc$157536;
        }
        
        
        //#line 151 "x10/regionarray/RectRegion1D.x10"
        final public x10.regionarray.RectRegion1D.RRIterator x10$regionarray$RectRegion1D$RRIterator$$this$x10$regionarray$RectRegion1D$RRIterator() {
            
            //#line 151 "x10/regionarray/RectRegion1D.x10"
            return x10.regionarray.RectRegion1D.RRIterator.this;
        }
        
        
        //#line 151 "x10/regionarray/RectRegion1D.x10"
        final public void __fieldInitializers_x10_regionarray_RectRegion1D_RRIterator() {
            
            //#line 151 "x10/regionarray/RectRegion1D.x10"
            this.cur = 0L;
        }
    }
    
    
    
    //#line 169 "x10/regionarray/RectRegion1D.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 170 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion1D.RRIterator alloc$138686 = ((x10.regionarray.RectRegion1D.RRIterator)(new x10.regionarray.RectRegion1D.RRIterator((java.lang.System[]) null)));
        
        //#line 170 "x10/regionarray/RectRegion1D.x10"
        alloc$138686.x10$regionarray$RectRegion1D$RRIterator$$init$S(((x10.regionarray.RectRegion1D)(this)));
        
        //#line 170 "x10/regionarray/RectRegion1D.x10"
        return alloc$138686;
    }
    
    
    //#line 173 "x10/regionarray/RectRegion1D.x10"
    public java.lang.String toString() {
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        final long t$157642 = this.min;
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$157643 = (("[") + ((x10.core.Long.$box(t$157642))));
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$157644 = ((t$157643) + (".."));
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        final long t$157645 = this.max;
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$157646 = ((t$157644) + ((x10.core.Long.$box(t$157645))));
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$157647 = ((t$157646) + ("]"));
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        return t$157647;
    }
    
    
    //#line 22 "x10/regionarray/RectRegion1D.x10"
    final public x10.regionarray.RectRegion1D x10$regionarray$RectRegion1D$$this$x10$regionarray$RectRegion1D() {
        
        //#line 22 "x10/regionarray/RectRegion1D.x10"
        return x10.regionarray.RectRegion1D.this;
    }
    
    
    //#line 22 "x10/regionarray/RectRegion1D.x10"
    final public void __fieldInitializers_x10_regionarray_RectRegion1D() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$248 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$248> $RTT = 
            x10.rtt.StaticFunType.<$Closure$248> make($Closure$248.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion1D.$Closure$248 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion1D.$Closure$248 $_obj = new x10.regionarray.RectRegion1D.$Closure$248((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$248(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 108 "x10/regionarray/RectRegion1D.x10"
            final long t$157598 = this.out$$.min$O((long)(i));
            
            //#line 108 "x10/regionarray/RectRegion1D.x10"
            return t$157598;
        }
        
        public x10.regionarray.RectRegion1D out$$;
        
        public $Closure$248(final x10.regionarray.RectRegion1D out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$249 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$249> $RTT = 
            x10.rtt.StaticFunType.<$Closure$249> make($Closure$249.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion1D.$Closure$249 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion1D.$Closure$249 $_obj = new x10.regionarray.RectRegion1D.$Closure$249((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$249(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 109 "x10/regionarray/RectRegion1D.x10"
            final long t$157600 = this.out$$.max$O((long)(i));
            
            //#line 109 "x10/regionarray/RectRegion1D.x10"
            return t$157600;
        }
        
        public x10.regionarray.RectRegion1D out$$;
        
        public $Closure$249(final x10.regionarray.RectRegion1D out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
}

