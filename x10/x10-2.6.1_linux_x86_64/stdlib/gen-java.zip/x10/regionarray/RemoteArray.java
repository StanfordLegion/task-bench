package x10.regionarray;

/**
 * A class that encapsulates sufficient information about a remote
 * array to enable DMA operations via Array.copyTo and Array.copyFrom
 * to be performed on the encapsulated Array.<p>
 * 
 * The following relationships will always be true, but are not statically expressible
 * due to limitations of the current implementations of constrained types in X10.
 * <pre>
 * this.region.equals(at (array.home) (this.array)().region)
 * this.size == (at (array.home) (this.array)().size)
 * rawData.home == this.array.home;
 * at (rawData.home) { (this.rawData)() == (this.array)().raw() }
 * </pre>
 */
@x10.runtime.impl.java.X10Generated
final public class RemoteArray<$T> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<RemoteArray> $RTT = 
        x10.rtt.NamedType.<RemoteArray> make("x10.regionarray.RemoteArray",
                                             RemoteArray.class,
                                             1);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RemoteArray<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.array = $deserializer.readObject();
        $_obj.rawData = $deserializer.readObject();
        $_obj.region = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.RemoteArray $_obj = new x10.regionarray.RemoteArray((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.array);
        $serializer.write(this.rawData);
        $serializer.write(this.region);
        $serializer.write(this.size);
        
    }
    
    // constructor just for allocation
    public RemoteArray(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.regionarray.RemoteArray.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final RemoteArray $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$regionarray$RemoteArray$$T$2 {}
    
    // properties
    
    //#line 32 "x10/regionarray/RemoteArray.x10"
    /**
         * The Region of the remote array
         */
    public x10.regionarray.Region region;
    
    //#line 36 "x10/regionarray/RemoteArray.x10"
    /**
         * The size of the remote array.
         */
    public long size;
    
    //#line 40 "x10/regionarray/RemoteArray.x10"
    /**
         * The GlobalRef to the remote array.
         */
    public x10.core.GlobalRef<x10.regionarray.Array<$T>> array;
    

    
    //#line 47 "x10/regionarray/RemoteArray.x10"
    /**
     * Caches a remote reference to the backing storage for the remote array
     * to enable DMA operations to be initiated remotely.  
     */
    public x10.lang.GlobalRail<$T> rawData;
    
    
    //#line 52 "x10/regionarray/RemoteArray.x10"
    /**
     * The rank of the RemoteArray is equal to region.rank
     */
    final public long rank$O() {
        
        //#line 52 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Region t$158179 = ((x10.regionarray.Region)(this.region));
        
        //#line 52 "x10/regionarray/RemoteArray.x10"
        final long t$158180 = t$158179.rank;
        
        //#line 52 "x10/regionarray/RemoteArray.x10"
        return t$158180;
    }
    
    
    //#line 57 "x10/regionarray/RemoteArray.x10"
    /**
     * The home location of the RemoteArray is equal to array.home
     */
    final public x10.lang.Place home() {
        
        //#line 57 "x10/regionarray/RemoteArray.x10"
        final x10.core.GlobalRef t$158181 = ((x10.core.GlobalRef)(this.array));
        
        //#line 57 "x10/regionarray/RemoteArray.x10"
        final x10.lang.Place t$158182 = ((x10.lang.Place)((t$158181).home));
        
        //#line 57 "x10/regionarray/RemoteArray.x10"
        return t$158182;
    }
    
    
    //#line 63 "x10/regionarray/RemoteArray.x10"
    /**
     * Create a RemoteArray wrapping the argument local Array.
     * @param a The array object to make accessible remotely.
     */
    // creation method for java code (1-phase java constructor)
    public RemoteArray(final x10.rtt.Type $T, final x10.regionarray.Array<$T> a, __0$1x10$regionarray$RemoteArray$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$RemoteArray$$init$S(a, (x10.regionarray.RemoteArray.__0$1x10$regionarray$RemoteArray$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.RemoteArray<$T> x10$regionarray$RemoteArray$$init$S(final x10.regionarray.Array<$T> a, __0$1x10$regionarray$RemoteArray$$T$2 $dummy) {
         {
            
            //#line 64 "x10/regionarray/RemoteArray.x10"
            final x10.regionarray.Region t$158310 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)a).region));
            
            //#line 64 "x10/regionarray/RemoteArray.x10"
            final long t$158311 = ((x10.regionarray.Array<$T>)a).size;
            
            //#line 64 "x10/regionarray/RemoteArray.x10"
            final x10.core.GlobalRef t$158312 = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.regionarray.Array<$T>>(x10.rtt.ParameterizedType.make(x10.regionarray.Array.$RTT, $T), ((x10.regionarray.Array)(a)), (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
            
            //#line 64 "x10/regionarray/RemoteArray.x10"
            this.region = t$158310;
            this.size = t$158311;
            this.array = t$158312;
            
            
            //#line 65 "x10/regionarray/RemoteArray.x10"
            final x10.lang.GlobalRail alloc$158140 = ((x10.lang.GlobalRail)(new x10.lang.GlobalRail<$T>((java.lang.System[]) null, $T)));
            
            //#line 115 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$158314 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)a).raw));
            
            //#line 65 "x10/regionarray/RemoteArray.x10"
            alloc$158140.x10$lang$GlobalRail$$init$S(((x10.core.Rail)(t$158314)), (x10.lang.GlobalRail.__0$1x10$lang$GlobalRail$$T$2) null);
            
            //#line 65 "x10/regionarray/RemoteArray.x10"
            ((x10.regionarray.RemoteArray<$T>)this).rawData = ((x10.lang.GlobalRail)(alloc$158140));
        }
        return this;
    }
    
    
    
    //#line 79 "x10/regionarray/RemoteArray.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * Only applies to one-dimensional arrays.
     * Can only  be called where <code>here == array.home</code>. 
     * Functionally equivalent to indexing the array via a one-dimensional point.
     * 
     * @param i0 the given index in the first dimension
     * @return the element of this array corresponding to the given index.
     * @see #operator(Point)
     * @see #set(T, Int)
     */
    public $T $apply$G(final int i) {
        
        //#line 79 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Array this$158147 = ((x10.regionarray.Array)(((x10.regionarray.Array<$T>)
                                                                             this.$apply())));
        
        //#line 79 "x10/regionarray/RemoteArray.x10"
        final long i$158146 = ((long)(((int)(i))));
        
        //#line 442 . "x10/regionarray/Array.x10"
        $T ret$158148 =  null;
        
        //#line 443 . "x10/regionarray/Array.x10"
        __ret$158149: {
            
            //#line 444 . "x10/regionarray/Array.x10"
            final boolean t$158200 = ((x10.regionarray.Array<$T>)this$158147).rail;
            //#line 444 . "x10/regionarray/Array.x10"
            if (t$158200) {
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$158191 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158147).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final $T t$158192 = (($T)(((x10.core.Rail<$T>)t$158191).$apply$G((long)(i$158146))));
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$158148 = (($T)(t$158192));
                
                //#line 446 . "x10/regionarray/Array.x10"
                break __ret$158149;
            } else {
                
                //#line 448 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$158193 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$158147).region));
                
                //#line 448 . "x10/regionarray/Array.x10"
                final boolean t$158194 = t$158193.contains$O((long)(i$158146));
                
                //#line 448 . "x10/regionarray/Array.x10"
                final boolean t$158195 = !(t$158194);
                
                //#line 448 . "x10/regionarray/Array.x10"
                if (t$158195) {
                    
                    //#line 449 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError$P((long)(i$158146));
                }
                
                //#line 451 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$158197 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158147).raw));
                
                //#line 451 . "x10/regionarray/Array.x10"
                final long t$158196 = ((x10.regionarray.Array<$T>)this$158147).layout_min0;
                
                //#line 451 . "x10/regionarray/Array.x10"
                final long t$158198 = ((i$158146) - (((long)(t$158196))));
                
                //#line 451 . "x10/regionarray/Array.x10"
                final $T t$158199 = (($T)(((x10.core.Rail<$T>)t$158197).$apply$G((long)(t$158198))));
                
                //#line 451 . "x10/regionarray/Array.x10"
                ret$158148 = (($T)(t$158199));
                
                //#line 451 . "x10/regionarray/Array.x10"
                break __ret$158149;
            }
        }
        
        //#line 79 "x10/regionarray/RemoteArray.x10"
        return ret$158148;
    }
    
    
    //#line 91 "x10/regionarray/RemoteArray.x10"
    /**
     * Return the element of this array corresponding to the given point.
     * The rank of the given point has to be the same as the rank of this array.
     * Can only  be called where <code>here == array.home</code>. 
     * 
     * @param pt the given point
     * @return the element of this array corresponding to the given point.
     * @see #operator(Int)
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point p) {
        
        //#line 91 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Array this$158151 = ((x10.regionarray.Array)(((x10.regionarray.Array<$T>)
                                                                             this.$apply())));
        
        //#line 524 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$158204 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$158151).region));
        
        //#line 524 . "x10/regionarray/Array.x10"
        final boolean t$158205 = t$158204.contains$O(((x10.lang.Point)(p)));
        
        //#line 524 . "x10/regionarray/Array.x10"
        final boolean t$158206 = !(t$158205);
        
        //#line 524 . "x10/regionarray/Array.x10"
        if (t$158206) {
            
            //#line 525 . "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError$P(((x10.lang.Point)(p)));
        }
        
        //#line 527 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$158239 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158151).raw));
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        final long t$158207 = ((long)(((int)(0))));
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        final long t$158208 = p.$apply$O((long)(t$158207));
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        final long t$158209 = ((x10.regionarray.Array<$T>)this$158151).layout_min0;
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        long offset$158154 = ((t$158208) - (((long)(t$158209))));
        
        //#line 1316 .. "x10/regionarray/Array.x10"
        final long t$158210 = p.rank;
        
        //#line 1316 .. "x10/regionarray/Array.x10"
        final boolean t$158238 = ((t$158210) > (((long)(1L))));
        
        //#line 1316 .. "x10/regionarray/Array.x10"
        if (t$158238) {
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158212 = ((x10.regionarray.Array<$T>)this$158151).layout_stride1;
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158213 = ((offset$158154) * (((long)(t$158212))));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158214 = p.$apply$O((long)(1L));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158215 = ((t$158213) + (((long)(t$158214))));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158216 = ((x10.regionarray.Array<$T>)this$158151).layout_min1;
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158217 = ((t$158215) - (((long)(t$158216))));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            offset$158154 = t$158217;
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            final long t$158335 = p.rank;
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            final long i$138093max$158336 = ((t$158335) - (((long)(1L))));
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            long i$158332 = 2L;
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final boolean t$158334 = ((i$158332) <= (((long)(i$138093max$158336))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                if (!(t$158334)) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final x10.core.Rail t$158316 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158151).layout));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158317 = ((i$158332) - (((long)(2L))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158318 = ((2L) * (((long)(t$158317))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158319 = ((long[])t$158316.value)[(int)t$158318];
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158320 = ((offset$158154) * (((long)(t$158319))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158321 = p.$apply$O((long)(i$158332));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158322 = ((t$158320) + (((long)(t$158321))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final x10.core.Rail t$158323 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158151).layout));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158324 = ((i$158332) - (((long)(2L))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158325 = ((2L) * (((long)(t$158324))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158326 = ((t$158325) + (((long)(1L))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158327 = ((long[])t$158323.value)[(int)t$158326];
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158328 = ((t$158322) - (((long)(t$158327))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                offset$158154 = t$158328;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$158331 = ((i$158332) + (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                i$158332 = t$158331;
            }
        }
        
        //#line 527 . "x10/regionarray/Array.x10"
        final $T t$158241 = (($T)(((x10.core.Rail<$T>)t$158239).$apply$G((long)(offset$158154))));
        
        //#line 91 "x10/regionarray/RemoteArray.x10"
        return t$158241;
    }
    
    
    //#line 106 "x10/regionarray/RemoteArray.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * Only applies to one-dimensional arrays.
     * Can only  be called where <code>here == array.home</code>. 
     * Functionally equivalent to setting the array via a one-dimensional point.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Int)
     * @see #set(T, Point)
     */
    public $T $set__1x10$regionarray$RemoteArray$$T$G(final int i, final $T v) {
        
        //#line 106 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Array this$158164 = ((x10.regionarray.Array)(((x10.regionarray.Array<$T>)
                                                                             this.$apply())));
        
        //#line 106 "x10/regionarray/RemoteArray.x10"
        final long i$158162 = ((long)(((int)(i))));
        
        //#line 545 . "x10/regionarray/Array.x10"
        final boolean t$158253 = ((x10.regionarray.Array<$T>)this$158164).rail;
        
        //#line 545 . "x10/regionarray/Array.x10"
        if (t$158253) {
            
            //#line 547 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$158246 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158164).raw));
            
            //#line 547 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$T>)t$158246).$set__1x10$lang$Rail$$T$G((long)(i$158162), (($T)(v)));
        } else {
            
            //#line 549 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$158247 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$158164).region));
            
            //#line 549 . "x10/regionarray/Array.x10"
            final boolean t$158248 = t$158247.contains$O((long)(i$158162));
            
            //#line 549 . "x10/regionarray/Array.x10"
            final boolean t$158249 = !(t$158248);
            
            //#line 549 . "x10/regionarray/Array.x10"
            if (t$158249) {
                
                //#line 550 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError$P((long)(i$158162));
            }
            
            //#line 552 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$158251 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158164).raw));
            
            //#line 552 . "x10/regionarray/Array.x10"
            final long t$158250 = ((x10.regionarray.Array<$T>)this$158164).layout_min0;
            
            //#line 552 . "x10/regionarray/Array.x10"
            final long t$158252 = ((i$158162) - (((long)(t$158250))));
            
            //#line 552 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$T>)t$158251).$set__1x10$lang$Rail$$T$G((long)(t$158252), (($T)(v)));
        }
        
        //#line 106 "x10/regionarray/RemoteArray.x10"
        return (($T)
                 v);
    }
    
    
    //#line 120 "x10/regionarray/RemoteArray.x10"
    /**
     * Set the element of this array corresponding to the given point to the given value.
     * Return the new value of the element.
     * The rank of the given point has to be the same as the rank of this array.
     * Can only  be called where <code>here == array.home</code>. 
     * 
     * @param v the given value
     * @param p the given point
     * @return the new value of the element of this array corresponding to the given point.
     * @see #operator(Point)
     * @see #set(T, Int)
     */
    public $T $set__1x10$regionarray$RemoteArray$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 121 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Array this$158170 = ((x10.regionarray.Array)(((x10.regionarray.Array<$T>)
                                                                             this.$apply())));
        
        //#line 637 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$158256 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$158170).region));
        
        //#line 637 . "x10/regionarray/Array.x10"
        final boolean t$158257 = t$158256.contains$O(((x10.lang.Point)(p)));
        
        //#line 637 . "x10/regionarray/Array.x10"
        final boolean t$158258 = !(t$158257);
        
        //#line 637 . "x10/regionarray/Array.x10"
        if (t$158258) {
            
            //#line 638 . "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError$P(((x10.lang.Point)(p)));
        }
        
        //#line 640 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$158291 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158170).raw));
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        final long t$158259 = ((long)(((int)(0))));
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        final long t$158260 = p.$apply$O((long)(t$158259));
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        final long t$158261 = ((x10.regionarray.Array<$T>)this$158170).layout_min0;
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        long offset$158173 = ((t$158260) - (((long)(t$158261))));
        
        //#line 1316 .. "x10/regionarray/Array.x10"
        final long t$158262 = p.rank;
        
        //#line 1316 .. "x10/regionarray/Array.x10"
        final boolean t$158290 = ((t$158262) > (((long)(1L))));
        
        //#line 1316 .. "x10/regionarray/Array.x10"
        if (t$158290) {
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158264 = ((x10.regionarray.Array<$T>)this$158170).layout_stride1;
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158265 = ((offset$158173) * (((long)(t$158264))));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158266 = p.$apply$O((long)(1L));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158267 = ((t$158265) + (((long)(t$158266))));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158268 = ((x10.regionarray.Array<$T>)this$158170).layout_min1;
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158269 = ((t$158267) - (((long)(t$158268))));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            offset$158173 = t$158269;
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            final long t$158357 = p.rank;
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            final long i$138093max$158358 = ((t$158357) - (((long)(1L))));
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            long i$158354 = 2L;
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final boolean t$158356 = ((i$158354) <= (((long)(i$138093max$158358))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                if (!(t$158356)) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final x10.core.Rail t$158338 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158170).layout));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158339 = ((i$158354) - (((long)(2L))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158340 = ((2L) * (((long)(t$158339))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158341 = ((long[])t$158338.value)[(int)t$158340];
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158342 = ((offset$158173) * (((long)(t$158341))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158343 = p.$apply$O((long)(i$158354));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158344 = ((t$158342) + (((long)(t$158343))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final x10.core.Rail t$158345 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158170).layout));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158346 = ((i$158354) - (((long)(2L))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158347 = ((2L) * (((long)(t$158346))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158348 = ((t$158347) + (((long)(1L))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158349 = ((long[])t$158345.value)[(int)t$158348];
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158350 = ((t$158344) - (((long)(t$158349))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                offset$158173 = t$158350;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$158353 = ((i$158354) + (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                i$158354 = t$158353;
            }
        }
        
        //#line 640 . "x10/regionarray/Array.x10"
        ((x10.core.Rail<$T>)t$158291).$set__1x10$lang$Rail$$T$G((long)(offset$158173), (($T)(v)));
        
        //#line 121 "x10/regionarray/RemoteArray.x10"
        return (($T)
                 v);
    }
    
    
    //#line 128 "x10/regionarray/RemoteArray.x10"
    /**
     * Access the Array that is encapsulated by this RemoteArray. 
     * Can only  be called where <code>here == array.home</code>. 
     */
    public x10.regionarray.Array $apply() {
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final x10.core.GlobalRef t$158295 = ((x10.core.GlobalRef)(this.array));
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Array t$158296 = (((x10.core.GlobalRef<x10.regionarray.Array<$T>>)(t$158295))).$apply$G();
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Array t$158138 = ((x10.regionarray.Array<$T>)
                                                 t$158296);
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final long t$158298 = ((x10.regionarray.Array<$T>)t$158138).rank;
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Region t$158297 = ((x10.regionarray.Region)(x10.regionarray.RemoteArray.this.region));
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final long t$158299 = t$158297.rank;
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final boolean t$158300 = ((long) t$158298) == ((long) t$158299);
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final boolean t$158302 = !(t$158300);
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        if (t$158302) {
            
            //#line 128 "x10/regionarray/RemoteArray.x10"
            final x10.lang.FailedDynamicCheckException t$158301 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Array[T]{self.rank==this(:x10.regionarray.RemoteArray).region.rank}");
            
            //#line 128 "x10/regionarray/RemoteArray.x10"
            throw t$158301;
        }
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        return t$158138;
    }
    
    
    //#line 130 "x10/regionarray/RemoteArray.x10"
    public boolean equals(final java.lang.Object other) {
        
        //#line 131 "x10/regionarray/RemoteArray.x10"
        final boolean t$158303 = x10.regionarray.RemoteArray.$RTT.isInstance(other, $T);
        
        //#line 131 "x10/regionarray/RemoteArray.x10"
        final boolean t$158304 = !(t$158303);
        
        //#line 131 "x10/regionarray/RemoteArray.x10"
        if (t$158304) {
            
            //#line 131 "x10/regionarray/RemoteArray.x10"
            return false;
        }
        
        //#line 132 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.RemoteArray oRA = ((x10.regionarray.RemoteArray)(x10.rtt.Types.<x10.regionarray.RemoteArray<$T>> cast(other,x10.rtt.ParameterizedType.make(x10.regionarray.RemoteArray.$RTT, $T))));
        
        //#line 133 "x10/regionarray/RemoteArray.x10"
        final x10.core.GlobalRef t$158305 = ((x10.core.GlobalRef)(((x10.regionarray.RemoteArray<$T>)oRA).array));
        
        //#line 133 "x10/regionarray/RemoteArray.x10"
        final x10.core.GlobalRef t$158306 = ((x10.core.GlobalRef)(this.array));
        
        //#line 133 "x10/regionarray/RemoteArray.x10"
        final boolean t$158307 = (((x10.core.GlobalRef<x10.regionarray.Array<$T>>)(t$158305))).equals(t$158306);
        
        //#line 133 "x10/regionarray/RemoteArray.x10"
        return t$158307;
    }
    
    
    //#line 136 "x10/regionarray/RemoteArray.x10"
    public int hashCode() {
        
        //#line 136 "x10/regionarray/RemoteArray.x10"
        final x10.core.GlobalRef t$158308 = ((x10.core.GlobalRef)(this.array));
        
        //#line 136 "x10/regionarray/RemoteArray.x10"
        final int t$158309 = (((x10.core.GlobalRef<x10.regionarray.Array<$T>>)(t$158308))).hashCode();
        
        //#line 136 "x10/regionarray/RemoteArray.x10"
        return t$158309;
    }
    
    
    //#line 28 "x10/regionarray/RemoteArray.x10"
    final public x10.regionarray.RemoteArray x10$regionarray$RemoteArray$$this$x10$regionarray$RemoteArray() {
        
        //#line 28 "x10/regionarray/RemoteArray.x10"
        return x10.regionarray.RemoteArray.this;
    }
    
    
    //#line 28 "x10/regionarray/RemoteArray.x10"
    final public void __fieldInitializers_x10_regionarray_RemoteArray() {
        
    }
}

