package x10.regionarray;


/**
 * A Region(rank) represents a set of points of class Point(rank). The
 * Region class defines a set of static factory methods for
 * constructing regions. There are properties and methods for
 * accessing basic information about of a region, such as its bounding
 * box, its size, whether or not it is convex, whether or not it is
 * empty. There are a set of methods for supporting algebraic
 * operations on regions, such as intersection, union, difference, and
 * so on. The set of points in a region may be iterated over.
 */
@x10.runtime.impl.java.X10Generated
abstract public class Region extends x10.core.Ref implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Region> $RTT = 
        x10.rtt.NamedType.<Region> make("x10.regionarray.Region",
                                        Region.class,
                                        new x10.rtt.Type[] {
                                            x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.lang.Point.$RTT)
                                        });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.rail = $deserializer.readBoolean();
        $_obj.rank = $deserializer.readLong();
        $_obj.rect = $deserializer.readBoolean();
        $_obj.zeroBased = $deserializer.readBoolean();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.rail);
        $serializer.write(this.rank);
        $serializer.write(this.rect);
        $serializer.write(this.zeroBased);
        
    }
    
    // constructor just for allocation
    public Region(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 30 "x10/regionarray/Region.x10"
    /**
     * The rank of this region.
     */
    public long rank;
    
    //#line 36 "x10/regionarray/Region.x10"
    /**
     * Is the region rectangular?
     * A rectangular region is defined to be region such that every point contained
     * in the bounding box of the region is a point in the region.
     */
    public boolean rect;
    
    //#line 41 "x10/regionarray/Region.x10"
    /**
     * Is the region zero-based?
     * A region is zero based if for each dimension the min value is 0.
     */
    public boolean zeroBased;
    
    //#line 45 "x10/regionarray/Region.x10"
    /**
     * Is the region rank 1, rectangular, and zero-based?
     */
    public boolean rail;
    

    
    
    //#line 47 "x10/regionarray/Region.x10"
    final public long rank$O() {
        
        //#line 47 "x10/regionarray/Region.x10"
        final long t$157719 = this.rank;
        
        //#line 47 "x10/regionarray/Region.x10"
        return t$157719;
    }
    
    
    //#line 48 "x10/regionarray/Region.x10"
    final public boolean rect$O() {
        
        //#line 48 "x10/regionarray/Region.x10"
        final boolean t$157720 = this.rect;
        
        //#line 48 "x10/regionarray/Region.x10"
        return t$157720;
    }
    
    
    //#line 49 "x10/regionarray/Region.x10"
    final public boolean zeroBased$O() {
        
        //#line 49 "x10/regionarray/Region.x10"
        final boolean t$157721 = this.zeroBased;
        
        //#line 49 "x10/regionarray/Region.x10"
        return t$157721;
    }
    
    
    //#line 50 "x10/regionarray/Region.x10"
    final public boolean rail$O() {
        
        //#line 50 "x10/regionarray/Region.x10"
        final boolean t$157722 = this.rail;
        
        //#line 50 "x10/regionarray/Region.x10"
        return t$157722;
    }
    
    
    //#line 60 "x10/regionarray/Region.x10"
    /**
     * Construct an empty region of the specified rank.
     */
    public static x10.regionarray.Region makeEmpty(final long rank) {
        
        //#line 60 "x10/regionarray/Region.x10"
        final x10.regionarray.EmptyRegion alloc$138271 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
        
        //#line 60 "x10/regionarray/Region.x10"
        alloc$138271.x10$regionarray$EmptyRegion$$init$S(((long)(rank)));
        
        //#line 60 "x10/regionarray/Region.x10"
        return alloc$138271;
    }
    
    
    //#line 66 "x10/regionarray/Region.x10"
    /**
     * Construct an unbounded region of a given rank that contains all
     * points of that rank.
     */
    public static x10.regionarray.Region makeFull(final long rank) {
        
        //#line 66 "x10/regionarray/Region.x10"
        final x10.regionarray.FullRegion alloc$138272 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
        
        //#line 66 "x10/regionarray/Region.x10"
        alloc$138272.x10$regionarray$FullRegion$$init$S(((long)(rank)));
        
        //#line 66 "x10/regionarray/Region.x10"
        return alloc$138272;
    }
    
    
    //#line 72 "x10/regionarray/Region.x10"
    /**
     * Construct a region of rank 0 that contains the single point of
     * rank 0. Useful as the identity region under Cartesian product.
     */
    public static x10.regionarray.Region makeUnit() {
        
        //#line 72 "x10/regionarray/Region.x10"
        final x10.regionarray.FullRegion alloc$138273 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
        
        //#line 72 "x10/regionarray/Region.x10"
        alloc$138273.x10$regionarray$FullRegion$$init$S(((long)(0L)));
        
        //#line 72 "x10/regionarray/Region.x10"
        return alloc$138273;
    }
    
    
    //#line 79 "x10/regionarray/Region.x10"
    /**
     * Construct an unbounded halfspace region of rank normal.rank
     * that consists of all points p satisfying dot(p,normal) + k <= 0.
     */
    public static x10.regionarray.Region makeHalfspace(final x10.lang.Point normal, final long k) {
        
        //#line 80 "x10/regionarray/Region.x10"
        final long rank = normal.rank;
        
        //#line 81 "x10/regionarray/Region.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 81 "x10/regionarray/Region.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(rank)));
        
        //#line 82 "x10/regionarray/Region.x10"
        final x10.regionarray.PolyRow r = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
        
        //#line 82 "x10/regionarray/Region.x10"
        final int t$158008 = ((int)(long)(((long)(k))));
        
        //#line 82 "x10/regionarray/Region.x10"
        r.x10$regionarray$PolyRow$$init$S(((x10.lang.Point)(normal)), t$158008);
        
        //#line 83 "x10/regionarray/Region.x10"
        pmb.add(((x10.regionarray.Row)(r)));
        
        //#line 84 "x10/regionarray/Region.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 85 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157724 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 85 "x10/regionarray/Region.x10"
        return t$157724;
    }
    
    
    //#line 103 "x10/regionarray/Region.x10"
    /**
     * Returns a PolyRegion that represents the rectangular region with smallest point minArg and largest point
     * maxArg. 
     * <p> Most users of the Region API should call makeRectangular which will return a 
     * RectRegion. Methods on RectRegion automatically construct a PolyRegion (by calling makeRectangularPoly) 
     * if they need to implement operations (such as intersection, product etc) that are difficult to define
     * on a RectRegion's representation.
     * @param minArg:Rail[Long] -- specifies the smallest point in the region
     * @param maxArg:Rail[Long] -- specifies the largest point in the region (must have the same rank as minArg
     * @return A Region of rank minarg.length 
     */
    public static x10.regionarray.Region makeRectangularPoly__0$1x10$lang$Long$2__1$1x10$lang$Long$2(final x10.core.Rail<x10.core.Long> minArg, final x10.core.Rail<x10.core.Long> maxArg) {
        
        //#line 104 "x10/regionarray/Region.x10"
        final long t$157725 = ((x10.core.Rail<x10.core.Long>)minArg).size;
        
        //#line 104 "x10/regionarray/Region.x10"
        final long t$157726 = ((x10.core.Rail<x10.core.Long>)maxArg).size;
        
        //#line 104 "x10/regionarray/Region.x10"
        final boolean t$157734 = ((long) t$157725) != ((long) t$157726);
        
        //#line 104 "x10/regionarray/Region.x10"
        if (t$157734) {
            
            //#line 104 "x10/regionarray/Region.x10"
            final long t$157727 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 104 "x10/regionarray/Region.x10"
            final java.lang.String t$157728 = (("min and max not equal size (") + ((x10.core.Long.$box(t$157727))));
            
            //#line 104 "x10/regionarray/Region.x10"
            final java.lang.String t$157729 = ((t$157728) + (" != "));
            
            //#line 104 "x10/regionarray/Region.x10"
            final long t$157730 = ((x10.core.Rail<x10.core.Long>)maxArg).size;
            
            //#line 104 "x10/regionarray/Region.x10"
            final java.lang.String t$157731 = ((t$157729) + ((x10.core.Long.$box(t$157730))));
            
            //#line 104 "x10/regionarray/Region.x10"
            final java.lang.String t$157732 = ((t$157731) + (")"));
            
            //#line 104 "x10/regionarray/Region.x10"
            final java.lang.IllegalArgumentException t$157733 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException(t$157732)));
            
            //#line 104 "x10/regionarray/Region.x10"
            throw t$157733;
        }
        
        //#line 105 "x10/regionarray/Region.x10"
        final long rank = ((x10.core.Rail<x10.core.Long>)minArg).size;
        
        //#line 106 "x10/regionarray/Region.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 106 "x10/regionarray/Region.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(rank)));
        
        //#line 107 "x10/regionarray/Region.x10"
        final long i$138293max$158040 = ((rank) - (((long)(1L))));
        
        //#line 107 "x10/regionarray/Region.x10"
        long i$158037 = 0L;
        {
            
            //#line 107 "x10/regionarray/Region.x10"
            final long[] minArg$value$158136 = ((long[])minArg.value);
            
            //#line 107 "x10/regionarray/Region.x10"
            final long[] maxArg$value$158137 = ((long[])maxArg.value);
            
            //#line 107 "x10/regionarray/Region.x10"
            for (;
                 true;
                 ) {
                
                //#line 107 "x10/regionarray/Region.x10"
                final boolean t$158039 = ((i$158037) <= (((long)(i$138293max$158040))));
                
                //#line 107 "x10/regionarray/Region.x10"
                if (!(t$158039)) {
                    
                    //#line 107 "x10/regionarray/Region.x10"
                    break;
                }
                
                //#line 107 "x10/regionarray/Region.x10"
                final long i$158034 = i$158037;
                
                //#line 108 "x10/regionarray/Region.x10"
                final long t$158026 = ((long)minArg$value$158136[(int)i$158037]);
                
                //#line 108 "x10/regionarray/Region.x10"
                final long t$158027 = java.lang.Long.MIN_VALUE;
                
                //#line 108 "x10/regionarray/Region.x10"
                final boolean t$158028 = ((t$158026) > (((long)(t$158027))));
                
                //#line 108 "x10/regionarray/Region.x10"
                if (t$158028) {
                    
                    //#line 110 "x10/regionarray/Region.x10"
                    final x10.regionarray.PolyRow r$158029 = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
                    
                    //#line 110 "x10/regionarray/Region.x10"
                    final x10.core.fun.Fun_0_1 t$158009 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.Region.$Closure$250(i$158034)));
                    
                    //#line 110 "x10/regionarray/Region.x10"
                    final x10.lang.Point t$158014 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(rank), ((x10.core.fun.Fun_0_1)(t$158009)))));
                    
                    //#line 110 "x10/regionarray/Region.x10"
                    final long t$158015 = ((long)minArg$value$158136[(int)i$158034]);
                    
                    //#line 110 "x10/regionarray/Region.x10"
                    final int t$158016 = ((int)(long)(((long)(t$158015))));
                    
                    //#line 110 "x10/regionarray/Region.x10"
                    r$158029.x10$regionarray$PolyRow$$init$S(((x10.lang.Point)(t$158014)), t$158016);
                    
                    //#line 111 "x10/regionarray/Region.x10"
                    pmb.add(((x10.regionarray.Row)(r$158029)));
                }
                
                //#line 113 "x10/regionarray/Region.x10"
                final long t$158030 = ((long)maxArg$value$158137[(int)i$158034]);
                
                //#line 113 "x10/regionarray/Region.x10"
                final long t$158031 = java.lang.Long.MAX_VALUE;
                
                //#line 113 "x10/regionarray/Region.x10"
                final boolean t$158032 = ((t$158030) < (((long)(t$158031))));
                
                //#line 113 "x10/regionarray/Region.x10"
                if (t$158032) {
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    final x10.regionarray.PolyRow s$158033 = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    final x10.core.fun.Fun_0_1 t$158017 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.Region.$Closure$251(i$158034)));
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    final x10.lang.Point t$158022 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(rank), ((x10.core.fun.Fun_0_1)(t$158017)))));
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    final long t$158023 = ((long)maxArg$value$158137[(int)i$158034]);
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    final int t$158024 = ((int)(long)(((long)(t$158023))));
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    final int t$158025 = (-(t$158024));
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    s$158033.x10$regionarray$PolyRow$$init$S(((x10.lang.Point)(t$158022)), t$158025);
                    
                    //#line 116 "x10/regionarray/Region.x10"
                    pmb.add(((x10.regionarray.Row)(s$158033)));
                }
                
                //#line 107 "x10/regionarray/Region.x10"
                final long t$158036 = ((i$158037) + (((long)(1L))));
                
                //#line 107 "x10/regionarray/Region.x10"
                i$158037 = t$158036;
            }
        }
        
        //#line 119 "x10/regionarray/Region.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 120 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157761 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 120 "x10/regionarray/Region.x10"
        return t$157761;
    }
    
    
    //#line 127 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular region whose bounds are specified as
     * rails of longs.
     */
    public static x10.regionarray.Region makeRectangular__0$1x10$lang$Long$2__1$1x10$lang$Long$2(final x10.core.Rail<x10.core.Long> minArg, final x10.core.Rail<x10.core.Long> maxArg) {
        
        //#line 128 "x10/regionarray/Region.x10"
        final long t$157762 = ((x10.core.Rail<x10.core.Long>)minArg).size;
        
        //#line 128 "x10/regionarray/Region.x10"
        final boolean t$157776 = ((long) t$157762) == ((long) 1L);
        
        //#line 128 "x10/regionarray/Region.x10"
        if (t$157776) {
            
            //#line 130 "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$138274 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 130 "x10/regionarray/Region.x10"
            final long t$158041 = ((long[])minArg.value)[(int)0L];
            
            //#line 130 "x10/regionarray/Region.x10"
            final long t$158042 = ((long[])maxArg.value)[(int)0L];
            
            //#line 130 "x10/regionarray/Region.x10"
            alloc$138274.x10$regionarray$RectRegion1D$$init$S(t$158041, t$158042);
            
            //#line 130 "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$138250 = ((x10.regionarray.Region)
                                                      alloc$138274);
            
            //#line 130 "x10/regionarray/Region.x10"
            final boolean t$157765 = t$138250.rect;
            
            //#line 130 "x10/regionarray/Region.x10"
            boolean t$157768 = ((boolean) t$157765) == ((boolean) true);
            
            //#line 130 "x10/regionarray/Region.x10"
            if (t$157768) {
                
                //#line 130 "x10/regionarray/Region.x10"
                final long t$157766 = t$138250.rank;
                
                //#line 130 "x10/regionarray/Region.x10"
                final long t$157767 = ((x10.core.Rail<x10.core.Long>)minArg).size;
                
                //#line 130 "x10/regionarray/Region.x10"
                t$157768 = ((long) t$157766) == ((long) t$157767);
            }
            
            //#line 130 "x10/regionarray/Region.x10"
            final boolean t$157771 = !(t$157768);
            
            //#line 130 "x10/regionarray/Region.x10"
            if (t$157771) {
                
                //#line 130 "x10/regionarray/Region.x10"
                final x10.lang.FailedDynamicCheckException t$157770 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==minArg.size}");
                
                //#line 130 "x10/regionarray/Region.x10"
                throw t$157770;
            }
            
            //#line 130 "x10/regionarray/Region.x10"
            return t$138250;
        } else {
            
            //#line 132 "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion alloc$138275 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
            
            //#line 132 "x10/regionarray/Region.x10"
            final long t$158043 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 132 "x10/regionarray/Region.x10"
            final x10.core.Rail t$158044 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$158043)), ((x10.core.fun.Fun_0_1)(minArg)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 132 "x10/regionarray/Region.x10"
            final long t$158045 = ((x10.core.Rail<x10.core.Long>)maxArg).size;
            
            //#line 132 "x10/regionarray/Region.x10"
            final x10.core.Rail t$158046 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$158045)), ((x10.core.fun.Fun_0_1)(maxArg)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 132 "x10/regionarray/Region.x10"
            alloc$138275.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158044)), ((x10.core.Rail)(t$158046)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
            
            //#line 132 "x10/regionarray/Region.x10"
            return alloc$138275;
        }
    }
    
    
    //#line 139 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular region from a Rail of IntRange that represent the min/max of each dimension.
     */
    public static x10.regionarray.Region makeRectangular__0$1x10$lang$IntRange$2(final x10.core.Rail<x10.lang.IntRange> ranges) {
        
        //#line 140 "x10/regionarray/Region.x10"
        final long t$157777 = ((x10.core.Rail<x10.lang.IntRange>)ranges).size;
        
        //#line 140 "x10/regionarray/Region.x10"
        final boolean t$157801 = ((long) t$157777) == ((long) 1L);
        
        //#line 140 "x10/regionarray/Region.x10"
        if (t$157801) {
            
            //#line 142 "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$138276 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 142 "x10/regionarray/Region.x10"
            final x10.lang.IntRange t$158047 = ((x10.lang.IntRange[])ranges.value)[(int)0L];
            
            //#line 142 "x10/regionarray/Region.x10"
            final int t$158048 = t$158047.min;
            
            //#line 142 "x10/regionarray/Region.x10"
            final long t$158049 = ((long)(((int)(t$158048))));
            
            //#line 142 "x10/regionarray/Region.x10"
            final x10.lang.IntRange t$158050 = ((x10.lang.IntRange[])ranges.value)[(int)0L];
            
            //#line 142 "x10/regionarray/Region.x10"
            final int t$158051 = t$158050.max;
            
            //#line 142 "x10/regionarray/Region.x10"
            final long t$158052 = ((long)(((int)(t$158051))));
            
            //#line 142 "x10/regionarray/Region.x10"
            alloc$138276.x10$regionarray$RectRegion1D$$init$S(t$158049, t$158052);
            
            //#line 142 "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$138252 = ((x10.regionarray.Region)
                                                      alloc$138276);
            
            //#line 142 "x10/regionarray/Region.x10"
            final boolean t$157784 = t$138252.rect;
            
            //#line 142 "x10/regionarray/Region.x10"
            boolean t$157787 = ((boolean) t$157784) == ((boolean) true);
            
            //#line 142 "x10/regionarray/Region.x10"
            if (t$157787) {
                
                //#line 142 "x10/regionarray/Region.x10"
                final long t$157785 = t$138252.rank;
                
                //#line 142 "x10/regionarray/Region.x10"
                final long t$157786 = ((x10.core.Rail<x10.lang.IntRange>)ranges).size;
                
                //#line 142 "x10/regionarray/Region.x10"
                t$157787 = ((long) t$157785) == ((long) t$157786);
            }
            
            //#line 142 "x10/regionarray/Region.x10"
            final boolean t$157790 = !(t$157787);
            
            //#line 142 "x10/regionarray/Region.x10"
            if (t$157790) {
                
                //#line 142 "x10/regionarray/Region.x10"
                final x10.lang.FailedDynamicCheckException t$157789 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==ranges.size}");
                
                //#line 142 "x10/regionarray/Region.x10"
                throw t$157789;
            }
            
            //#line 142 "x10/regionarray/Region.x10"
            return t$138252;
        } else {
            
            //#line 144 "x10/regionarray/Region.x10"
            final long t$157794 = ((x10.core.Rail<x10.lang.IntRange>)ranges).size;
            
            //#line 144 "x10/regionarray/Region.x10"
            final x10.core.fun.Fun_0_1 t$157795 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.Region.$Closure$252(ranges, (x10.regionarray.Region.$Closure$252.__0$1x10$lang$IntRange$2) null)));
            
            //#line 144 "x10/regionarray/Region.x10"
            final x10.core.Rail mins = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157794)), ((x10.core.fun.Fun_0_1)(t$157795)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 145 "x10/regionarray/Region.x10"
            final long t$157799 = ((x10.core.Rail<x10.lang.IntRange>)ranges).size;
            
            //#line 145 "x10/regionarray/Region.x10"
            final x10.core.fun.Fun_0_1 t$157800 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.Region.$Closure$253(ranges, (x10.regionarray.Region.$Closure$253.__0$1x10$lang$IntRange$2) null)));
            
            //#line 145 "x10/regionarray/Region.x10"
            final x10.core.Rail maxs = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157799)), ((x10.core.fun.Fun_0_1)(t$157800)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 146 "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion alloc$138277 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
            
            //#line 146 "x10/regionarray/Region.x10"
            alloc$138277.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(mins)), ((x10.core.Rail)(maxs)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
            
            //#line 146 "x10/regionarray/Region.x10"
            return alloc$138277;
        }
    }
    
    
    //#line 152 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular region from a Rail of IntRange that represent the min/max of each dimension.
     */
    public static x10.regionarray.Region make__0$1x10$lang$IntRange$2(final x10.core.Rail<x10.lang.IntRange> ranges) {
        
        //#line 152 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157802 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$IntRange$2(((x10.core.Rail)(ranges)))));
        
        //#line 152 "x10/regionarray/Region.x10"
        return t$157802;
    }
    
    
    //#line 157 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular region from a Rail of LongRange that represent the min/max of each dimension.
     */
    public static x10.regionarray.Region makeRectangular__0$1x10$lang$LongRange$2(final x10.core.Rail<x10.lang.LongRange> ranges) {
        
        //#line 158 "x10/regionarray/Region.x10"
        final long t$157803 = ((x10.core.Rail<x10.lang.LongRange>)ranges).size;
        
        //#line 158 "x10/regionarray/Region.x10"
        final boolean t$157823 = ((long) t$157803) == ((long) 1L);
        
        //#line 158 "x10/regionarray/Region.x10"
        if (t$157823) {
            
            //#line 160 "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$138278 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 160 "x10/regionarray/Region.x10"
            final x10.lang.LongRange t$158053 = ((x10.lang.LongRange[])ranges.value)[(int)0L];
            
            //#line 160 "x10/regionarray/Region.x10"
            final long t$158054 = t$158053.min;
            
            //#line 160 "x10/regionarray/Region.x10"
            final x10.lang.LongRange t$158055 = ((x10.lang.LongRange[])ranges.value)[(int)0L];
            
            //#line 160 "x10/regionarray/Region.x10"
            final long t$158056 = t$158055.max;
            
            //#line 160 "x10/regionarray/Region.x10"
            alloc$138278.x10$regionarray$RectRegion1D$$init$S(t$158054, t$158056);
            
            //#line 160 "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$138254 = ((x10.regionarray.Region)
                                                      alloc$138278);
            
            //#line 160 "x10/regionarray/Region.x10"
            final boolean t$157808 = t$138254.rect;
            
            //#line 160 "x10/regionarray/Region.x10"
            boolean t$157811 = ((boolean) t$157808) == ((boolean) true);
            
            //#line 160 "x10/regionarray/Region.x10"
            if (t$157811) {
                
                //#line 160 "x10/regionarray/Region.x10"
                final long t$157809 = t$138254.rank;
                
                //#line 160 "x10/regionarray/Region.x10"
                final long t$157810 = ((x10.core.Rail<x10.lang.LongRange>)ranges).size;
                
                //#line 160 "x10/regionarray/Region.x10"
                t$157811 = ((long) t$157809) == ((long) t$157810);
            }
            
            //#line 160 "x10/regionarray/Region.x10"
            final boolean t$157814 = !(t$157811);
            
            //#line 160 "x10/regionarray/Region.x10"
            if (t$157814) {
                
                //#line 160 "x10/regionarray/Region.x10"
                final x10.lang.FailedDynamicCheckException t$157813 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==ranges.size}");
                
                //#line 160 "x10/regionarray/Region.x10"
                throw t$157813;
            }
            
            //#line 160 "x10/regionarray/Region.x10"
            return t$138254;
        } else {
            
            //#line 162 "x10/regionarray/Region.x10"
            final long t$157817 = ((x10.core.Rail<x10.lang.LongRange>)ranges).size;
            
            //#line 162 "x10/regionarray/Region.x10"
            final x10.core.fun.Fun_0_1 t$157818 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.Region.$Closure$254(ranges, (x10.regionarray.Region.$Closure$254.__0$1x10$lang$LongRange$2) null)));
            
            //#line 162 "x10/regionarray/Region.x10"
            final x10.core.Rail mins = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157817)), ((x10.core.fun.Fun_0_1)(t$157818)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 163 "x10/regionarray/Region.x10"
            final long t$157821 = ((x10.core.Rail<x10.lang.LongRange>)ranges).size;
            
            //#line 163 "x10/regionarray/Region.x10"
            final x10.core.fun.Fun_0_1 t$157822 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.Region.$Closure$255(ranges, (x10.regionarray.Region.$Closure$255.__0$1x10$lang$LongRange$2) null)));
            
            //#line 163 "x10/regionarray/Region.x10"
            final x10.core.Rail maxs = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157821)), ((x10.core.fun.Fun_0_1)(t$157822)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 164 "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion alloc$138279 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
            
            //#line 164 "x10/regionarray/Region.x10"
            alloc$138279.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(mins)), ((x10.core.Rail)(maxs)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
            
            //#line 164 "x10/regionarray/Region.x10"
            return alloc$138279;
        }
    }
    
    
    //#line 170 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular region from a Rail of LongRange that represent the min/max of each dimension.
     */
    public static x10.regionarray.Region make__0$1x10$lang$LongRange$2(final x10.core.Rail<x10.lang.LongRange> ranges) {
        
        //#line 170 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157824 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$LongRange$2(((x10.core.Rail)(ranges)))));
        
        //#line 170 "x10/regionarray/Region.x10"
        return t$157824;
    }
    
    
    //#line 175 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 1 region from an IntRange
     */
    public static x10.regionarray.Region make(final x10.lang.IntRange r) {
        
        //#line 175 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$138280 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 175 "x10/regionarray/Region.x10"
        final int t$158057 = r.min;
        
        //#line 175 "x10/regionarray/Region.x10"
        final long t$158058 = ((long)(((int)(t$158057))));
        
        //#line 175 "x10/regionarray/Region.x10"
        final int t$158059 = r.max;
        
        //#line 175 "x10/regionarray/Region.x10"
        final long t$158060 = ((long)(((int)(t$158059))));
        
        //#line 175 "x10/regionarray/Region.x10"
        alloc$138280.x10$regionarray$RectRegion1D$$init$S(t$158058, t$158060);
        
        //#line 175 "x10/regionarray/Region.x10"
        return alloc$138280;
    }
    
    
    //#line 179 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 1 region from an IntRange
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.IntRange r) {
        
        //#line 179 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$138281 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 179 "x10/regionarray/Region.x10"
        final int t$158061 = r.min;
        
        //#line 179 "x10/regionarray/Region.x10"
        final long t$158062 = ((long)(((int)(t$158061))));
        
        //#line 179 "x10/regionarray/Region.x10"
        final int t$158063 = r.max;
        
        //#line 179 "x10/regionarray/Region.x10"
        final long t$158064 = ((long)(((int)(t$158063))));
        
        //#line 179 "x10/regionarray/Region.x10"
        alloc$138281.x10$regionarray$RectRegion1D$$init$S(t$158062, t$158064);
        
        //#line 179 "x10/regionarray/Region.x10"
        return alloc$138281;
    }
    
    
    //#line 184 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 1 region from a LongRange
     */
    public static x10.regionarray.Region make(final x10.lang.LongRange r) {
        
        //#line 184 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$138282 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 184 "x10/regionarray/Region.x10"
        final long t$158065 = r.min;
        
        //#line 184 "x10/regionarray/Region.x10"
        final long t$158066 = r.max;
        
        //#line 184 "x10/regionarray/Region.x10"
        alloc$138282.x10$regionarray$RectRegion1D$$init$S(((long)(t$158065)), ((long)(t$158066)));
        
        //#line 184 "x10/regionarray/Region.x10"
        return alloc$138282;
    }
    
    
    //#line 188 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 1 region from a LongRange
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.LongRange r) {
        
        //#line 188 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$138283 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 188 "x10/regionarray/Region.x10"
        final long t$158067 = r.min;
        
        //#line 188 "x10/regionarray/Region.x10"
        final long t$158068 = r.max;
        
        //#line 188 "x10/regionarray/Region.x10"
        alloc$138283.x10$regionarray$RectRegion1D$$init$S(((long)(t$158067)), ((long)(t$158068)));
        
        //#line 188 "x10/regionarray/Region.x10"
        return alloc$138283;
    }
    
    
    //#line 193 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 2 region from a pair of IntRanges
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.IntRange r1, final x10.lang.IntRange r2) {
        
        //#line 194 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion alloc$138284 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 194 "x10/regionarray/Region.x10"
        final int t$158069 = r1.min;
        
        //#line 194 "x10/regionarray/Region.x10"
        final long t$158070 = ((long)(((int)(t$158069))));
        
        //#line 194 "x10/regionarray/Region.x10"
        final int t$158071 = r2.min;
        
        //#line 194 "x10/regionarray/Region.x10"
        final long t$158072 = ((long)(((int)(t$158071))));
        
        //#line 194 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158073 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158070, t$158072})));
        
        //#line 195 "x10/regionarray/Region.x10"
        final int t$158074 = r1.max;
        
        //#line 195 "x10/regionarray/Region.x10"
        final long t$158075 = ((long)(((int)(t$158074))));
        
        //#line 195 "x10/regionarray/Region.x10"
        final int t$158076 = r2.max;
        
        //#line 195 "x10/regionarray/Region.x10"
        final long t$158077 = ((long)(((int)(t$158076))));
        
        //#line 195 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158078 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158075, t$158077})));
        
        //#line 194 "x10/regionarray/Region.x10"
        alloc$138284.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158073)), ((x10.core.Rail)(t$158078)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 194 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138256 = ((x10.regionarray.Region)
                                                  alloc$138284);
        
        //#line 195 "x10/regionarray/Region.x10"
        final boolean t$157847 = t$138256.rect;
        
        //#line 195 "x10/regionarray/Region.x10"
        boolean t$157849 = ((boolean) t$157847) == ((boolean) true);
        
        //#line 195 "x10/regionarray/Region.x10"
        if (t$157849) {
            
            //#line 195 "x10/regionarray/Region.x10"
            final long t$157848 = t$138256.rank;
            
            //#line 195 "x10/regionarray/Region.x10"
            t$157849 = ((long) t$157848) == ((long) 2L);
        }
        
        //#line 194 "x10/regionarray/Region.x10"
        final boolean t$157852 = !(t$157849);
        
        //#line 194 "x10/regionarray/Region.x10"
        if (t$157852) {
            
            //#line 194 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$157851 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==2L}");
            
            //#line 194 "x10/regionarray/Region.x10"
            throw t$157851;
        }
        
        //#line 194 "x10/regionarray/Region.x10"
        return t$138256;
    }
    
    
    //#line 200 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 2 region from a pair of IntRanges
     */
    public static x10.regionarray.Region make(final x10.lang.IntRange r1, final x10.lang.IntRange r2) {
        
        //#line 200 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157853 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular(((x10.lang.IntRange)(r1)), ((x10.lang.IntRange)(r2)))));
        
        //#line 200 "x10/regionarray/Region.x10"
        return t$157853;
    }
    
    
    //#line 205 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 2 region from a pair of LongRanges
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.LongRange r1, final x10.lang.LongRange r2) {
        
        //#line 206 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion alloc$138285 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 206 "x10/regionarray/Region.x10"
        final long t$158079 = r1.min;
        
        //#line 206 "x10/regionarray/Region.x10"
        final long t$158080 = r2.min;
        
        //#line 206 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158081 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158079, t$158080})));
        
        //#line 206 "x10/regionarray/Region.x10"
        final long t$158082 = r1.max;
        
        //#line 206 "x10/regionarray/Region.x10"
        final long t$158083 = r2.max;
        
        //#line 206 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158084 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158082, t$158083})));
        
        //#line 206 "x10/regionarray/Region.x10"
        alloc$138285.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158081)), ((x10.core.Rail)(t$158084)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 206 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138258 = ((x10.regionarray.Region)
                                                  alloc$138285);
        
        //#line 206 "x10/regionarray/Region.x10"
        final boolean t$157860 = t$138258.rect;
        
        //#line 206 "x10/regionarray/Region.x10"
        boolean t$157862 = ((boolean) t$157860) == ((boolean) true);
        
        //#line 206 "x10/regionarray/Region.x10"
        if (t$157862) {
            
            //#line 206 "x10/regionarray/Region.x10"
            final long t$157861 = t$138258.rank;
            
            //#line 206 "x10/regionarray/Region.x10"
            t$157862 = ((long) t$157861) == ((long) 2L);
        }
        
        //#line 206 "x10/regionarray/Region.x10"
        final boolean t$157865 = !(t$157862);
        
        //#line 206 "x10/regionarray/Region.x10"
        if (t$157865) {
            
            //#line 206 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$157864 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==2L}");
            
            //#line 206 "x10/regionarray/Region.x10"
            throw t$157864;
        }
        
        //#line 206 "x10/regionarray/Region.x10"
        return t$138258;
    }
    
    
    //#line 211 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 2 region from a pair of LongRanges
     */
    public static x10.regionarray.Region make(final x10.lang.LongRange r1, final x10.lang.LongRange r2) {
        
        //#line 211 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157866 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular(((x10.lang.LongRange)(r1)), ((x10.lang.LongRange)(r2)))));
        
        //#line 211 "x10/regionarray/Region.x10"
        return t$157866;
    }
    
    
    //#line 216 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 3 region from a triple of IntRanges
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.IntRange r1, final x10.lang.IntRange r2, final x10.lang.IntRange r3) {
        
        //#line 217 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion alloc$138286 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 217 "x10/regionarray/Region.x10"
        final int t$158085 = r1.min;
        
        //#line 217 "x10/regionarray/Region.x10"
        final long t$158086 = ((long)(((int)(t$158085))));
        
        //#line 217 "x10/regionarray/Region.x10"
        final int t$158087 = r2.min;
        
        //#line 217 "x10/regionarray/Region.x10"
        final long t$158088 = ((long)(((int)(t$158087))));
        
        //#line 217 "x10/regionarray/Region.x10"
        final int t$158089 = r3.min;
        
        //#line 217 "x10/regionarray/Region.x10"
        final long t$158090 = ((long)(((int)(t$158089))));
        
        //#line 217 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158091 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158086, t$158088, t$158090})));
        
        //#line 218 "x10/regionarray/Region.x10"
        final int t$158092 = r1.max;
        
        //#line 218 "x10/regionarray/Region.x10"
        final long t$158093 = ((long)(((int)(t$158092))));
        
        //#line 218 "x10/regionarray/Region.x10"
        final int t$158094 = r2.max;
        
        //#line 218 "x10/regionarray/Region.x10"
        final long t$158095 = ((long)(((int)(t$158094))));
        
        //#line 218 "x10/regionarray/Region.x10"
        final int t$158096 = r3.max;
        
        //#line 218 "x10/regionarray/Region.x10"
        final long t$158097 = ((long)(((int)(t$158096))));
        
        //#line 218 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158098 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158093, t$158095, t$158097})));
        
        //#line 217 "x10/regionarray/Region.x10"
        alloc$138286.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158091)), ((x10.core.Rail)(t$158098)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 217 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138260 = ((x10.regionarray.Region)
                                                  alloc$138286);
        
        //#line 218 "x10/regionarray/Region.x10"
        final boolean t$157881 = t$138260.rect;
        
        //#line 218 "x10/regionarray/Region.x10"
        boolean t$157883 = ((boolean) t$157881) == ((boolean) true);
        
        //#line 218 "x10/regionarray/Region.x10"
        if (t$157883) {
            
            //#line 218 "x10/regionarray/Region.x10"
            final long t$157882 = t$138260.rank;
            
            //#line 218 "x10/regionarray/Region.x10"
            t$157883 = ((long) t$157882) == ((long) 3L);
        }
        
        //#line 217 "x10/regionarray/Region.x10"
        final boolean t$157886 = !(t$157883);
        
        //#line 217 "x10/regionarray/Region.x10"
        if (t$157886) {
            
            //#line 217 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$157885 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==3L}");
            
            //#line 217 "x10/regionarray/Region.x10"
            throw t$157885;
        }
        
        //#line 217 "x10/regionarray/Region.x10"
        return t$138260;
    }
    
    
    //#line 223 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 3 region from a triple of IntRanges
     */
    public static x10.regionarray.Region make(final x10.lang.IntRange r1, final x10.lang.IntRange r2, final x10.lang.IntRange r3) {
        
        //#line 224 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157887 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular(((x10.lang.IntRange)(r1)), ((x10.lang.IntRange)(r2)), ((x10.lang.IntRange)(r3)))));
        
        //#line 224 "x10/regionarray/Region.x10"
        return t$157887;
    }
    
    
    //#line 230 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 3 region from a triple of LongRanges
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.LongRange r1, final x10.lang.LongRange r2, final x10.lang.LongRange r3) {
        
        //#line 231 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion alloc$138287 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 231 "x10/regionarray/Region.x10"
        final long t$158099 = r1.min;
        
        //#line 231 "x10/regionarray/Region.x10"
        final long t$158100 = r2.min;
        
        //#line 231 "x10/regionarray/Region.x10"
        final long t$158101 = r3.min;
        
        //#line 231 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158102 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158099, t$158100, t$158101})));
        
        //#line 231 "x10/regionarray/Region.x10"
        final long t$158103 = r1.max;
        
        //#line 231 "x10/regionarray/Region.x10"
        final long t$158104 = r2.max;
        
        //#line 231 "x10/regionarray/Region.x10"
        final long t$158105 = r3.max;
        
        //#line 231 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158106 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158103, t$158104, t$158105})));
        
        //#line 231 "x10/regionarray/Region.x10"
        alloc$138287.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158102)), ((x10.core.Rail)(t$158106)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 231 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138262 = ((x10.regionarray.Region)
                                                  alloc$138287);
        
        //#line 231 "x10/regionarray/Region.x10"
        final boolean t$157896 = t$138262.rect;
        
        //#line 231 "x10/regionarray/Region.x10"
        boolean t$157898 = ((boolean) t$157896) == ((boolean) true);
        
        //#line 231 "x10/regionarray/Region.x10"
        if (t$157898) {
            
            //#line 231 "x10/regionarray/Region.x10"
            final long t$157897 = t$138262.rank;
            
            //#line 231 "x10/regionarray/Region.x10"
            t$157898 = ((long) t$157897) == ((long) 3L);
        }
        
        //#line 231 "x10/regionarray/Region.x10"
        final boolean t$157901 = !(t$157898);
        
        //#line 231 "x10/regionarray/Region.x10"
        if (t$157901) {
            
            //#line 231 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$157900 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==3L}");
            
            //#line 231 "x10/regionarray/Region.x10"
            throw t$157900;
        }
        
        //#line 231 "x10/regionarray/Region.x10"
        return t$138262;
    }
    
    
    //#line 236 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 3 region from a triple of LongRanges
     */
    public static x10.regionarray.Region make(final x10.lang.LongRange r1, final x10.lang.LongRange r2, final x10.lang.LongRange r3) {
        
        //#line 237 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157902 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular(((x10.lang.LongRange)(r1)), ((x10.lang.LongRange)(r2)), ((x10.lang.LongRange)(r3)))));
        
        //#line 237 "x10/regionarray/Region.x10"
        return t$157902;
    }
    
    
    //#line 243 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 4 region from four IntRanges
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.IntRange r1, final x10.lang.IntRange r2, final x10.lang.IntRange r3, final x10.lang.IntRange r4) {
        
        //#line 244 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion alloc$138288 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 244 "x10/regionarray/Region.x10"
        final int t$158107 = r1.min;
        
        //#line 244 "x10/regionarray/Region.x10"
        final long t$158108 = ((long)(((int)(t$158107))));
        
        //#line 244 "x10/regionarray/Region.x10"
        final int t$158109 = r2.min;
        
        //#line 244 "x10/regionarray/Region.x10"
        final long t$158110 = ((long)(((int)(t$158109))));
        
        //#line 244 "x10/regionarray/Region.x10"
        final int t$158111 = r3.min;
        
        //#line 244 "x10/regionarray/Region.x10"
        final long t$158112 = ((long)(((int)(t$158111))));
        
        //#line 244 "x10/regionarray/Region.x10"
        final int t$158113 = r4.min;
        
        //#line 244 "x10/regionarray/Region.x10"
        final long t$158114 = ((long)(((int)(t$158113))));
        
        //#line 244 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158115 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158108, t$158110, t$158112, t$158114})));
        
        //#line 245 "x10/regionarray/Region.x10"
        final int t$158116 = r1.max;
        
        //#line 245 "x10/regionarray/Region.x10"
        final long t$158117 = ((long)(((int)(t$158116))));
        
        //#line 245 "x10/regionarray/Region.x10"
        final int t$158118 = r2.max;
        
        //#line 245 "x10/regionarray/Region.x10"
        final long t$158119 = ((long)(((int)(t$158118))));
        
        //#line 245 "x10/regionarray/Region.x10"
        final int t$158120 = r3.max;
        
        //#line 245 "x10/regionarray/Region.x10"
        final long t$158121 = ((long)(((int)(t$158120))));
        
        //#line 245 "x10/regionarray/Region.x10"
        final int t$158122 = r4.max;
        
        //#line 245 "x10/regionarray/Region.x10"
        final long t$158123 = ((long)(((int)(t$158122))));
        
        //#line 245 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158124 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158117, t$158119, t$158121, t$158123})));
        
        //#line 244 "x10/regionarray/Region.x10"
        alloc$138288.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158115)), ((x10.core.Rail)(t$158124)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 244 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138264 = ((x10.regionarray.Region)
                                                  alloc$138288);
        
        //#line 245 "x10/regionarray/Region.x10"
        final boolean t$157921 = t$138264.rect;
        
        //#line 245 "x10/regionarray/Region.x10"
        boolean t$157923 = ((boolean) t$157921) == ((boolean) true);
        
        //#line 245 "x10/regionarray/Region.x10"
        if (t$157923) {
            
            //#line 245 "x10/regionarray/Region.x10"
            final long t$157922 = t$138264.rank;
            
            //#line 245 "x10/regionarray/Region.x10"
            t$157923 = ((long) t$157922) == ((long) 4L);
        }
        
        //#line 244 "x10/regionarray/Region.x10"
        final boolean t$157926 = !(t$157923);
        
        //#line 244 "x10/regionarray/Region.x10"
        if (t$157926) {
            
            //#line 244 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$157925 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==4L}");
            
            //#line 244 "x10/regionarray/Region.x10"
            throw t$157925;
        }
        
        //#line 244 "x10/regionarray/Region.x10"
        return t$138264;
    }
    
    
    //#line 250 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 4 region from four IntRanges
     */
    public static x10.regionarray.Region make(final x10.lang.IntRange r1, final x10.lang.IntRange r2, final x10.lang.IntRange r3, final x10.lang.IntRange r4) {
        
        //#line 251 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157927 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular(((x10.lang.IntRange)(r1)), ((x10.lang.IntRange)(r2)), ((x10.lang.IntRange)(r3)), ((x10.lang.IntRange)(r4)))));
        
        //#line 251 "x10/regionarray/Region.x10"
        return t$157927;
    }
    
    
    //#line 257 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 4 region from four LongRanges
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.LongRange r1, final x10.lang.LongRange r2, final x10.lang.LongRange r3, final x10.lang.LongRange r4) {
        
        //#line 258 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion alloc$138289 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158125 = r1.min;
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158126 = r2.min;
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158127 = r3.min;
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158128 = r4.min;
        
        //#line 258 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158129 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158125, t$158126, t$158127, t$158128})));
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158130 = r1.max;
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158131 = r2.max;
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158132 = r3.max;
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158133 = r4.max;
        
        //#line 258 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158134 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158130, t$158131, t$158132, t$158133})));
        
        //#line 258 "x10/regionarray/Region.x10"
        alloc$138289.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158129)), ((x10.core.Rail)(t$158134)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 258 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138266 = ((x10.regionarray.Region)
                                                  alloc$138289);
        
        //#line 258 "x10/regionarray/Region.x10"
        final boolean t$157938 = t$138266.rect;
        
        //#line 258 "x10/regionarray/Region.x10"
        boolean t$157940 = ((boolean) t$157938) == ((boolean) true);
        
        //#line 258 "x10/regionarray/Region.x10"
        if (t$157940) {
            
            //#line 258 "x10/regionarray/Region.x10"
            final long t$157939 = t$138266.rank;
            
            //#line 258 "x10/regionarray/Region.x10"
            t$157940 = ((long) t$157939) == ((long) 4L);
        }
        
        //#line 258 "x10/regionarray/Region.x10"
        final boolean t$157943 = !(t$157940);
        
        //#line 258 "x10/regionarray/Region.x10"
        if (t$157943) {
            
            //#line 258 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$157942 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==4L}");
            
            //#line 258 "x10/regionarray/Region.x10"
            throw t$157942;
        }
        
        //#line 258 "x10/regionarray/Region.x10"
        return t$138266;
    }
    
    
    //#line 263 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 4 region from four LongRanges
     */
    public static x10.regionarray.Region make(final x10.lang.LongRange r1, final x10.lang.LongRange r2, final x10.lang.LongRange r3, final x10.lang.LongRange r4) {
        
        //#line 264 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157944 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular(((x10.lang.LongRange)(r1)), ((x10.lang.LongRange)(r2)), ((x10.lang.LongRange)(r3)), ((x10.lang.LongRange)(r4)))));
        
        //#line 264 "x10/regionarray/Region.x10"
        return t$157944;
    }
    
    
    //#line 273 "x10/regionarray/Region.x10"
    /**
     * Construct a rank-1 rectangular region with the specified bounds.
     */
    public static x10.regionarray.Region makeRectangular(final long min, final long max) {
        
        //#line 274 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$138290 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 274 "x10/regionarray/Region.x10"
        alloc$138290.x10$regionarray$RectRegion1D$$init$S(((long)(min)), ((long)(max)));
        
        //#line 274 "x10/regionarray/Region.x10"
        return alloc$138290;
    }
    
    
    //#line 279 "x10/regionarray/Region.x10"
    /**
     * Construct a rank-1 rectangular region with the specified bounds.
     */
    public static x10.regionarray.Region make(final long min, final long max) {
        
        //#line 279 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$138291 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 279 "x10/regionarray/Region.x10"
        alloc$138291.x10$regionarray$RectRegion1D$$init$S(((long)(min)), ((long)(max)));
        
        //#line 279 "x10/regionarray/Region.x10"
        return alloc$138291;
    }
    
    
    //#line 293 "x10/regionarray/Region.x10"
    /**
     * Construct a banded region of the given size, with the specified
     * number of diagonals above and below the main diagonal
     * (inclusive of the main diagonal).
     * @param size -- number of elements in the banded region
     * @param upper -- the number of diagonals in the band, above the main diagonal
     * @param lower -- the number of diagonals in the band, below the main diagonal
     */
    public static x10.regionarray.Region makeBanded(final long size, final long upper, final long lower) {
        
        //#line 294 "x10/regionarray/Region.x10"
        final int size$157671 = ((int)(long)(((long)(size))));
        
        //#line 294 "x10/regionarray/Region.x10"
        final int upper$157672 = ((int)(long)(((long)(upper))));
        
        //#line 294 "x10/regionarray/Region.x10"
        final int lower$157673 = ((int)(long)(((long)(lower))));
        
        //#line 260 . "x10/regionarray/PolyRegion.x10"
        final int t$157945 = ((size$157671) - (((int)(1))));
        
        //#line 260 . "x10/regionarray/PolyRegion.x10"
        final int t$157946 = ((size$157671) - (((int)(1))));
        
        //#line 260 . "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$157947 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.makeBanded((int)(0), (int)(0), (int)(t$157945), (int)(t$157946), (int)(upper$157672), (int)(lower$157673))));
        
        //#line 294 "x10/regionarray/Region.x10"
        return t$157947;
    }
    
    
    //#line 300 "x10/regionarray/Region.x10"
    /**
     * Construct a banded region of the given size that includes only
     * the main diagonal.
     */
    public static x10.regionarray.Region makeBanded(final long size) {
        
        //#line 300 "x10/regionarray/Region.x10"
        final int t$157948 = ((int)(long)(((long)(size))));
        
        //#line 300 "x10/regionarray/Region.x10"
        final long t$157949 = ((long)(((int)(t$157948))));
        
        //#line 300 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157950 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.makeBanded((long)(t$157949), (long)(1L), (long)(1L))));
        
        //#line 300 "x10/regionarray/Region.x10"
        return t$157950;
    }
    
    
    //#line 306 "x10/regionarray/Region.x10"
    /**
     * Construct an upper triangular region of the given size.
     */
    public static x10.regionarray.Region makeUpperTriangular(final long size) {
        
        //#line 306 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157951 = ((x10.regionarray.Region)(x10.regionarray.Region.makeUpperTriangular((long)(0L), (long)(0L), (long)(size))));
        
        //#line 306 "x10/regionarray/Region.x10"
        return t$157951;
    }
    
    
    //#line 312 "x10/regionarray/Region.x10"
    /**
     * Construct an upper triangular region of the given size with the
     * given lower bounds.
     */
    public static x10.regionarray.Region makeUpperTriangular(final long rowMin, final long colMin, final long size) {
        
        //#line 313 "x10/regionarray/Region.x10"
        final int t$157952 = ((int)(long)(((long)(rowMin))));
        
        //#line 313 "x10/regionarray/Region.x10"
        final int t$157953 = ((int)(long)(((long)(colMin))));
        
        //#line 313 "x10/regionarray/Region.x10"
        final int t$157954 = ((int)(long)(((long)(size))));
        
        //#line 313 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157955 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.makeUpperTriangular2((int)(t$157952), (int)(t$157953), (int)(t$157954))));
        
        //#line 313 "x10/regionarray/Region.x10"
        return t$157955;
    }
    
    
    //#line 318 "x10/regionarray/Region.x10"
    /**
     * Construct a lower triangular region of the given size.
     */
    public static x10.regionarray.Region makeLowerTriangular(final long size) {
        
        //#line 318 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157956 = ((x10.regionarray.Region)(x10.regionarray.Region.makeLowerTriangular((long)(0L), (long)(0L), (long)(size))));
        
        //#line 318 "x10/regionarray/Region.x10"
        return t$157956;
    }
    
    
    //#line 324 "x10/regionarray/Region.x10"
    /**
     * Construct an lower triangular region of the given size with the
     * given lower bounds.
     */
    public static x10.regionarray.Region makeLowerTriangular(final long rowMin, final long colMin, final long size) {
        
        //#line 325 "x10/regionarray/Region.x10"
        final int t$157957 = ((int)(long)(((long)(rowMin))));
        
        //#line 325 "x10/regionarray/Region.x10"
        final int t$157958 = ((int)(long)(((long)(colMin))));
        
        //#line 325 "x10/regionarray/Region.x10"
        final int t$157959 = ((int)(long)(((long)(size))));
        
        //#line 325 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157960 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.makeLowerTriangular2((int)(t$157957), (int)(t$157958), (int)(t$157959))));
        
        //#line 325 "x10/regionarray/Region.x10"
        return t$157960;
    }
    
    
    //#line 335 "x10/regionarray/Region.x10"
    /**
     * Returns the number of points in this region.
     */
    abstract public long size$O();
    
    
    //#line 340 "x10/regionarray/Region.x10"
    /**
     * Returns true iff this region is convex.
     */
    abstract public boolean isConvex$O();
    
    
    //#line 345 "x10/regionarray/Region.x10"
    /**
     * Returns true iff this region is empty.
     */
    abstract public boolean isEmpty$O();
    
    
    //#line 360 "x10/regionarray/Region.x10"
    /**
     * Returns the index of the argument point in the lexograpically ordered
     * enumeration of all Points in this region.  Will return -1 to indicate 
     * that the argument point is not included in this region.  If the argument
     * point is contained in this region, then a value between 0 and size-1
     * will be returned.  The primary usage of indexOf is in the context of 
     * Arrays, where it enables the conversion from "logical" indicies 
     * specified in Points into lower level indices specified by Ints that
     * can be used in primitive operations such as copyTo and in interfacing
     * to native code.  Often indexOf will be used in conjuntion with the 
     * raw() method of Array or DistArray.
     */
    abstract public long indexOf$O(final x10.lang.Point p);
    
    
    //#line 362 "x10/regionarray/Region.x10"
    public long indexOf$O(final long i0) {
        
        //#line 151 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$157676 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 151 . "x10/lang/Point.x10"
        alloc$157676.x10$lang$Point$$init$S(i0);
        
        //#line 362 "x10/regionarray/Region.x10"
        final long t$157961 = this.indexOf$O(((x10.lang.Point)(alloc$157676)));
        
        //#line 362 "x10/regionarray/Region.x10"
        return t$157961;
    }
    
    
    //#line 363 "x10/regionarray/Region.x10"
    public long indexOf$O(final long i0, final long i1) {
        
        //#line 152 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$157680 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 152 . "x10/lang/Point.x10"
        alloc$157680.x10$lang$Point$$init$S(i0, i1);
        
        //#line 363 "x10/regionarray/Region.x10"
        final long t$157962 = this.indexOf$O(((x10.lang.Point)(alloc$157680)));
        
        //#line 363 "x10/regionarray/Region.x10"
        return t$157962;
    }
    
    
    //#line 364 "x10/regionarray/Region.x10"
    public long indexOf$O(final long i0, final long i1, final long i2) {
        
        //#line 153 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$157685 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 153 . "x10/lang/Point.x10"
        alloc$157685.x10$lang$Point$$init$S(i0, i1, i2);
        
        //#line 364 "x10/regionarray/Region.x10"
        final long t$157963 = this.indexOf$O(((x10.lang.Point)(alloc$157685)));
        
        //#line 364 "x10/regionarray/Region.x10"
        return t$157963;
    }
    
    
    //#line 365 "x10/regionarray/Region.x10"
    public long indexOf$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 154 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$157691 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 154 . "x10/lang/Point.x10"
        alloc$157691.x10$lang$Point$$init$S(i0, i1, i2, i3);
        
        //#line 365 "x10/regionarray/Region.x10"
        final long t$157964 = this.indexOf$O(((x10.lang.Point)(alloc$157691)));
        
        //#line 365 "x10/regionarray/Region.x10"
        return t$157964;
    }
    
    
    //#line 376 "x10/regionarray/Region.x10"
    /**
     * The bounding box of a region r is the smallest rectangular region
     * that contains all the points of r.
     */
    public x10.regionarray.Region boundingBox() {
        
        //#line 376 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157965 = ((x10.regionarray.Region)(this.computeBoundingBox()));
        
        //#line 376 "x10/regionarray/Region.x10"
        return t$157965;
    }
    
    
    //#line 379 "x10/regionarray/Region.x10"
    abstract public x10.regionarray.Region computeBoundingBox();
    
    
    //#line 385 "x10/regionarray/Region.x10"
    /**
     * Returns a function that can be used to access the lower bounds 
     * of the bounding box of the region. 
     */
    abstract public x10.core.fun.Fun_0_1 min();
    
    
    //#line 391 "x10/regionarray/Region.x10"
    /**
     * Returns a function that can be used to access the upper bounds 
     * of the bounding box of the region. 
     */
    abstract public x10.core.fun.Fun_0_1 max();
    
    
    //#line 397 "x10/regionarray/Region.x10"
    /**
     * Returns the lower bound of the bounding box of the region along
     * the ith axis.
     */
    public long min$O(final long i) {
        
        //#line 397 "x10/regionarray/Region.x10"
        final x10.core.fun.Fun_0_1 t$157966 = this.min();
        
        //#line 397 "x10/regionarray/Region.x10"
        final long t$157967 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$157966).$apply(x10.core.Long.$box(i), x10.rtt.Types.LONG));
        
        //#line 397 "x10/regionarray/Region.x10"
        return t$157967;
    }
    
    
    //#line 403 "x10/regionarray/Region.x10"
    /**
     * Returns the upper bound of the bounding box of the region along
     * the ith axis.
     */
    public long max$O(final long i) {
        
        //#line 403 "x10/regionarray/Region.x10"
        final x10.core.fun.Fun_0_1 t$157968 = this.max();
        
        //#line 403 "x10/regionarray/Region.x10"
        final long t$157969 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$157968).$apply(x10.core.Long.$box(i), x10.rtt.Types.LONG));
        
        //#line 403 "x10/regionarray/Region.x10"
        return t$157969;
    }
    
    
    //#line 408 "x10/regionarray/Region.x10"
    /**
     * Returns the smallest point in the bounding box of the region
     */
    public x10.lang.Point minPoint() {
        
        //#line 408 "x10/regionarray/Region.x10"
        final long t$157970 = this.rank;
        
        //#line 408 "x10/regionarray/Region.x10"
        final x10.core.fun.Fun_0_1 t$157971 = this.min();
        
        //#line 408 "x10/regionarray/Region.x10"
        final x10.lang.Point t$157972 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$157970), ((x10.core.fun.Fun_0_1)(t$157971)))));
        
        //#line 408 "x10/regionarray/Region.x10"
        return t$157972;
    }
    
    
    //#line 413 "x10/regionarray/Region.x10"
    /**
     * Returns the largest point in the bounding box of the region
     */
    public x10.lang.Point maxPoint() {
        
        //#line 413 "x10/regionarray/Region.x10"
        final long t$157973 = this.rank;
        
        //#line 413 "x10/regionarray/Region.x10"
        final x10.core.fun.Fun_0_1 t$157974 = this.max();
        
        //#line 413 "x10/regionarray/Region.x10"
        final x10.lang.Point t$157975 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$157973), ((x10.core.fun.Fun_0_1)(t$157974)))));
        
        //#line 413 "x10/regionarray/Region.x10"
        return t$157975;
    }
    
    
    //#line 450 "x10/regionarray/Region.x10"
    /**
     * Returns the intersection of two regions: a region that contains all
     * points that are in both this region and that region.
     * 
     */
    abstract public x10.regionarray.Region intersection(final x10.regionarray.Region that);
    
    
    //#line 464 "x10/regionarray/Region.x10"
    /**
     * Returns true iff this region has no points in common with that
     * region.
     */
    public boolean disjoint$O(final x10.regionarray.Region that) {
        
        //#line 464 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157976 = ((x10.regionarray.Region)(this.intersection(((x10.regionarray.Region)(that)))));
        
        //#line 464 "x10/regionarray/Region.x10"
        final boolean t$157977 = t$157976.isEmpty$O();
        
        //#line 464 "x10/regionarray/Region.x10"
        return t$157977;
    }
    
    
    //#line 475 "x10/regionarray/Region.x10"
    /**
     * Returns the Cartesian product of two regions. The Cartesian
     * product has rank <code>this.rank+that.rank</code>. For every point <code>p</code> in the
     * Cartesian product, the first <code>this.rank</code> coordinates of <code>p</code> are a
     * point in this region, while the last <code>that.rank</code> coordinates of p
     * are a point in that region.
     */
    abstract public x10.regionarray.Region product(final x10.regionarray.Region that);
    
    
    //#line 483 "x10/regionarray/Region.x10"
    /**
     * Returns the region shifted by a Point (vector). The Point has
     * to have the same rank as the region. A point p+v is in 
     * <code>translate(v)</code> iff <code>p</code> is in <code>this</code>. 
     */
    abstract public x10.regionarray.Region translate(final x10.lang.Point v);
    
    
    //#line 492 "x10/regionarray/Region.x10"
    /**
     * Returns the projection of a region onto the specified axis. The
     * projection is a rank-1 region such that for every point <code>[i]</code> in
     * the projection, there is some point <code>p</code> in this region such that
     * <code>p(axis)==i</code>.
     */
    abstract public x10.regionarray.Region projection(final long axis);
    
    
    //#line 500 "x10/regionarray/Region.x10"
    /**
     * Returns the projection of a region onto all axes but the
     * specified axis.
     */
    abstract public x10.regionarray.Region eliminate(final long axis);
    
    
    //#line 511 "x10/regionarray/Region.x10"
    /**
     * Return an iterator for this region. Normally accessed using the
     * syntax
     *
     *    for (p:Point in r)
     *        ... p ...
     */
    abstract public x10.lang.Iterator iterator();
    
    
    //#line 519 "x10/regionarray/Region.x10"
    public x10.regionarray.Region $and(final x10.regionarray.Region that) {
        
        //#line 519 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157978 = ((x10.regionarray.Region)(this.intersection(((x10.regionarray.Region)(that)))));
        
        //#line 519 "x10/regionarray/Region.x10"
        return t$157978;
    }
    
    
    //#line 523 "x10/regionarray/Region.x10"
    public x10.regionarray.Region $times(final x10.regionarray.Region that) {
        
        //#line 523 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157979 = ((x10.regionarray.Region)(this.product(((x10.regionarray.Region)(that)))));
        
        //#line 523 "x10/regionarray/Region.x10"
        return t$157979;
    }
    
    
    //#line 525 "x10/regionarray/Region.x10"
    public x10.regionarray.Region $plus(final x10.lang.Point v) {
        
        //#line 525 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157980 = ((x10.regionarray.Region)(this.translate(((x10.lang.Point)(v)))));
        
        //#line 525 "x10/regionarray/Region.x10"
        return t$157980;
    }
    
    
    //#line 526 "x10/regionarray/Region.x10"
    public x10.regionarray.Region $inv_plus(final x10.lang.Point v) {
        
        //#line 526 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157981 = ((x10.regionarray.Region)(this.translate(((x10.lang.Point)(v)))));
        
        //#line 526 "x10/regionarray/Region.x10"
        return t$157981;
    }
    
    
    //#line 527 "x10/regionarray/Region.x10"
    public x10.regionarray.Region $minus(final x10.lang.Point v) {
        
        //#line 527 "x10/regionarray/Region.x10"
        final x10.lang.Point t$157982 = ((x10.lang.Point)(v.$minus()));
        
        //#line 527 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$157983 = ((x10.regionarray.Region)(this.translate(((x10.lang.Point)(t$157982)))));
        
        //#line 527 "x10/regionarray/Region.x10"
        return t$157983;
    }
    
    
    //#line 534 "x10/regionarray/Region.x10"
    public boolean equals(final java.lang.Object that) {
        
        //#line 535 "x10/regionarray/Region.x10"
        final boolean t$157984 = x10.rtt.Equality.equalsequals((this),(that));
        
        //#line 535 "x10/regionarray/Region.x10"
        if (t$157984) {
            
            //#line 535 "x10/regionarray/Region.x10"
            return true;
        }
        
        //#line 536 "x10/regionarray/Region.x10"
        final boolean t$157985 = x10.regionarray.Region.$RTT.isInstance(that);
        
        //#line 536 "x10/regionarray/Region.x10"
        final boolean t$157986 = !(t$157985);
        
        //#line 536 "x10/regionarray/Region.x10"
        if (t$157986) {
            
            //#line 536 "x10/regionarray/Region.x10"
            return false;
        }
        
        //#line 537 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t1 = ((x10.regionarray.Region)(x10.rtt.Types.<x10.regionarray.Region> cast(that,x10.regionarray.Region.$RTT)));
        
        //#line 538 "x10/regionarray/Region.x10"
        final long t$157987 = this.rank;
        
        //#line 538 "x10/regionarray/Region.x10"
        final long t$157988 = t1.rank;
        
        //#line 538 "x10/regionarray/Region.x10"
        final boolean t$157989 = ((long) t$157987) != ((long) t$157988);
        
        //#line 538 "x10/regionarray/Region.x10"
        if (t$157989) {
            
            //#line 538 "x10/regionarray/Region.x10"
            return false;
        }
        
        //#line 539 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138269 = ((x10.regionarray.Region)
                                                  t1);
        
        //#line 539 "x10/regionarray/Region.x10"
        final long t$157990 = t$138269.rank;
        
        //#line 539 "x10/regionarray/Region.x10"
        final long t$157991 = x10.regionarray.Region.this.rank;
        
        //#line 539 "x10/regionarray/Region.x10"
        final boolean t$157992 = ((long) t$157990) == ((long) t$157991);
        
        //#line 539 "x10/regionarray/Region.x10"
        final boolean t$157994 = !(t$157992);
        
        //#line 539 "x10/regionarray/Region.x10"
        if (t$157994) {
            
            //#line 539 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$157993 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.Region).rank}");
            
            //#line 539 "x10/regionarray/Region.x10"
            throw t$157993;
        }
        
        //#line 540 "x10/regionarray/Region.x10"
        boolean t$157995 = this.contains$O(((x10.regionarray.Region)(t$138269)));
        
        //#line 540 "x10/regionarray/Region.x10"
        if (t$157995) {
            
            //#line 540 "x10/regionarray/Region.x10"
            t$157995 = t$138269.contains$O(((x10.regionarray.Region)(this)));
        }
        
        //#line 540 "x10/regionarray/Region.x10"
        return t$157995;
    }
    
    
    //#line 543 "x10/regionarray/Region.x10"
    abstract public boolean contains$O(final x10.regionarray.Region that);
    
    
    //#line 546 "x10/regionarray/Region.x10"
    abstract public boolean contains$O(final x10.lang.Point p);
    
    
    //#line 548 "x10/regionarray/Region.x10"
    public boolean contains$O(final long i) {
        
        //#line 151 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$157694 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 151 . "x10/lang/Point.x10"
        alloc$157694.x10$lang$Point$$init$S(i);
        
        //#line 548 "x10/regionarray/Region.x10"
        final boolean t$157998 = this.contains$O(((x10.lang.Point)(alloc$157694)));
        
        //#line 548 "x10/regionarray/Region.x10"
        return t$157998;
    }
    
    
    //#line 550 "x10/regionarray/Region.x10"
    public boolean contains$O(final long i0, final long i1) {
        
        //#line 152 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$157698 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 152 . "x10/lang/Point.x10"
        alloc$157698.x10$lang$Point$$init$S(i0, i1);
        
        //#line 550 "x10/regionarray/Region.x10"
        final boolean t$158000 = this.contains$O(((x10.lang.Point)(alloc$157698)));
        
        //#line 550 "x10/regionarray/Region.x10"
        return t$158000;
    }
    
    
    //#line 552 "x10/regionarray/Region.x10"
    public boolean contains$O(final long i0, final long i1, final long i2) {
        
        //#line 153 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$157703 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 153 . "x10/lang/Point.x10"
        alloc$157703.x10$lang$Point$$init$S(i0, i1, i2);
        
        //#line 552 "x10/regionarray/Region.x10"
        final boolean t$158002 = this.contains$O(((x10.lang.Point)(alloc$157703)));
        
        //#line 552 "x10/regionarray/Region.x10"
        return t$158002;
    }
    
    
    //#line 554 "x10/regionarray/Region.x10"
    public boolean contains$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 154 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$157709 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 154 . "x10/lang/Point.x10"
        alloc$157709.x10$lang$Point$$init$S(i0, i1, i2, i3);
        
        //#line 554 "x10/regionarray/Region.x10"
        final boolean t$158004 = this.contains$O(((x10.lang.Point)(alloc$157709)));
        
        //#line 554 "x10/regionarray/Region.x10"
        return t$158004;
    }
    
    
    //#line 556 "x10/regionarray/Region.x10"
    
    // constructor for non-virtual call
    final public x10.regionarray.Region x10$regionarray$Region$$init$S(final long r, final boolean t, final boolean z) {
         {
            
            //#line 557 "x10/regionarray/Region.x10"
            boolean t$158005 = ((long) r) == ((long) 1L);
            
            //#line 557 "x10/regionarray/Region.x10"
            if (t$158005) {
                
                //#line 557 "x10/regionarray/Region.x10"
                t$158005 = t;
            }
            
            //#line 557 "x10/regionarray/Region.x10"
            boolean t$158006 = t$158005;
            
            //#line 557 "x10/regionarray/Region.x10"
            if (t$158005) {
                
                //#line 557 "x10/regionarray/Region.x10"
                t$158006 = z;
            }
            
            //#line 558 "x10/regionarray/Region.x10"
            this.rank = r;
            this.rect = t;
            this.zeroBased = z;
            this.rail = t$158006;
            
        }
        return this;
    }
    
    
    
    //#line 565 "x10/regionarray/Region.x10"
    
    // constructor for non-virtual call
    final public x10.regionarray.Region x10$regionarray$Region$$init$S(final long r) {
         {
            
            //#line 566 "x10/regionarray/Region.x10"
            this.rank = r;
            this.rect = true;
            this.zeroBased = true;
            this.rail = true;
            
        }
        return this;
    }
    
    
    
    //#line 575 "x10/regionarray/Region.x10"
    /**
     * Constructs a distribution over this region that maps
     * every point in the region to the specified place.
     * @param p the given place
     * @return a "constant" distribution over this region that maps to p.
     */
    public x10.regionarray.Dist $arrow(final x10.lang.Place p) {
        
        //#line 575 "x10/regionarray/Region.x10"
        final x10.regionarray.Region r$157715 = ((x10.regionarray.Region)(this));
        
        //#line 171 . "x10/regionarray/Dist.x10"
        final x10.regionarray.ConstantDist alloc$157717 = ((x10.regionarray.ConstantDist)(new x10.regionarray.ConstantDist((java.lang.System[]) null)));
        
        //#line 171 . "x10/regionarray/Dist.x10"
        alloc$157717.x10$regionarray$ConstantDist$$init$S(((x10.regionarray.Region)(r$157715)), p);
        
        //#line 171 . "x10/regionarray/Dist.x10"
        final x10.regionarray.Dist t$158007 = ((x10.regionarray.Dist)(((x10.regionarray.Dist)
                                                                        alloc$157717)));
        
        //#line 575 "x10/regionarray/Region.x10"
        return t$158007;
    }
    
    
    //#line 26 "x10/regionarray/Region.x10"
    final public x10.regionarray.Region x10$regionarray$Region$$this$x10$regionarray$Region() {
        
        //#line 26 "x10/regionarray/Region.x10"
        return x10.regionarray.Region.this;
    }
    
    
    //#line 26 "x10/regionarray/Region.x10"
    final public void __fieldInitializers_x10_regionarray_Region() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$250 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$250> $RTT = 
            x10.rtt.StaticFunType.<$Closure$250> make($Closure$250.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region.$Closure$250 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.i$158034 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Region.$Closure$250 $_obj = new x10.regionarray.Region.$Closure$250((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.i$158034);
            
        }
        
        // constructor just for allocation
        public $Closure$250(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long j$158010) {
            
            //#line 110 "x10/regionarray/Region.x10"
            final boolean t$158011 = ((long) this.i$158034) == ((long) j$158010);
            
            //#line 110 "x10/regionarray/Region.x10"
            long t$158012 =  0;
            
            //#line 110 "x10/regionarray/Region.x10"
            if (t$158011) {
                
                //#line 110 "x10/regionarray/Region.x10"
                t$158012 = -1L;
            } else {
                
                //#line 110 "x10/regionarray/Region.x10"
                t$158012 = 0L;
            }
            
            //#line 110 "x10/regionarray/Region.x10"
            return t$158012;
        }
        
        public long i$158034;
        
        public $Closure$250(final long i$158034) {
             {
                this.i$158034 = i$158034;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$251 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$251> $RTT = 
            x10.rtt.StaticFunType.<$Closure$251> make($Closure$251.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region.$Closure$251 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.i$158034 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Region.$Closure$251 $_obj = new x10.regionarray.Region.$Closure$251((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.i$158034);
            
        }
        
        // constructor just for allocation
        public $Closure$251(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long j$158018) {
            
            //#line 115 "x10/regionarray/Region.x10"
            final boolean t$158019 = ((long) this.i$158034) == ((long) j$158018);
            
            //#line 115 "x10/regionarray/Region.x10"
            long t$158020 =  0;
            
            //#line 115 "x10/regionarray/Region.x10"
            if (t$158019) {
                
                //#line 115 "x10/regionarray/Region.x10"
                t$158020 = 1L;
            } else {
                
                //#line 115 "x10/regionarray/Region.x10"
                t$158020 = 0L;
            }
            
            //#line 115 "x10/regionarray/Region.x10"
            return t$158020;
        }
        
        public long i$158034;
        
        public $Closure$251(final long i$158034) {
             {
                this.i$158034 = i$158034;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$252 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$252> $RTT = 
            x10.rtt.StaticFunType.<$Closure$252> make($Closure$252.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region.$Closure$252 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.ranges = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Region.$Closure$252 $_obj = new x10.regionarray.Region.$Closure$252((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.ranges);
            
        }
        
        // constructor just for allocation
        public $Closure$252(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$IntRange$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 144 "x10/regionarray/Region.x10"
            final x10.lang.IntRange t$157791 = ((x10.lang.IntRange[])this.ranges.value)[(int)i];
            
            //#line 144 "x10/regionarray/Region.x10"
            final int t$157792 = t$157791.min;
            
            //#line 144 "x10/regionarray/Region.x10"
            final long t$157793 = ((long)(((int)(t$157792))));
            
            //#line 144 "x10/regionarray/Region.x10"
            return t$157793;
        }
        
        public x10.core.Rail<x10.lang.IntRange> ranges;
        
        public $Closure$252(final x10.core.Rail<x10.lang.IntRange> ranges, __0$1x10$lang$IntRange$2 $dummy) {
             {
                this.ranges = ((x10.core.Rail)(ranges));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$253 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$253> $RTT = 
            x10.rtt.StaticFunType.<$Closure$253> make($Closure$253.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region.$Closure$253 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.ranges = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Region.$Closure$253 $_obj = new x10.regionarray.Region.$Closure$253((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.ranges);
            
        }
        
        // constructor just for allocation
        public $Closure$253(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$IntRange$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 145 "x10/regionarray/Region.x10"
            final x10.lang.IntRange t$157796 = ((x10.lang.IntRange[])this.ranges.value)[(int)i];
            
            //#line 145 "x10/regionarray/Region.x10"
            final int t$157797 = t$157796.max;
            
            //#line 145 "x10/regionarray/Region.x10"
            final long t$157798 = ((long)(((int)(t$157797))));
            
            //#line 145 "x10/regionarray/Region.x10"
            return t$157798;
        }
        
        public x10.core.Rail<x10.lang.IntRange> ranges;
        
        public $Closure$253(final x10.core.Rail<x10.lang.IntRange> ranges, __0$1x10$lang$IntRange$2 $dummy) {
             {
                this.ranges = ((x10.core.Rail)(ranges));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$254 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$254> $RTT = 
            x10.rtt.StaticFunType.<$Closure$254> make($Closure$254.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region.$Closure$254 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.ranges = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Region.$Closure$254 $_obj = new x10.regionarray.Region.$Closure$254((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.ranges);
            
        }
        
        // constructor just for allocation
        public $Closure$254(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$LongRange$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 162 "x10/regionarray/Region.x10"
            final x10.lang.LongRange t$157815 = ((x10.lang.LongRange[])this.ranges.value)[(int)i];
            
            //#line 162 "x10/regionarray/Region.x10"
            final long t$157816 = t$157815.min;
            
            //#line 162 "x10/regionarray/Region.x10"
            return t$157816;
        }
        
        public x10.core.Rail<x10.lang.LongRange> ranges;
        
        public $Closure$254(final x10.core.Rail<x10.lang.LongRange> ranges, __0$1x10$lang$LongRange$2 $dummy) {
             {
                this.ranges = ((x10.core.Rail)(ranges));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$255 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$255> $RTT = 
            x10.rtt.StaticFunType.<$Closure$255> make($Closure$255.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region.$Closure$255 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.ranges = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Region.$Closure$255 $_obj = new x10.regionarray.Region.$Closure$255((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.ranges);
            
        }
        
        // constructor just for allocation
        public $Closure$255(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$LongRange$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 163 "x10/regionarray/Region.x10"
            final x10.lang.LongRange t$157819 = ((x10.lang.LongRange[])this.ranges.value)[(int)i];
            
            //#line 163 "x10/regionarray/Region.x10"
            final long t$157820 = t$157819.max;
            
            //#line 163 "x10/regionarray/Region.x10"
            return t$157820;
        }
        
        public x10.core.Rail<x10.lang.LongRange> ranges;
        
        public $Closure$255(final x10.core.Rail<x10.lang.LongRange> ranges, __0$1x10$lang$LongRange$2 $dummy) {
             {
                this.ranges = ((x10.core.Rail)(ranges));
            }
        }
        
    }
    
}



