package x10.regionarray;


/**
 * <p>An array defines a mapping from {@link Point}s to data values of some type T.
 * The Points in the Array's domain are defined by specifying a {@link Region}
 * over which the Array is defined.  Attempting to access a data value
 * at a Point not included in the Array's Region will result in a 
 * {@link ArrayIndexOutOfBoundsException} being raised.</p>
 * 
 * <p>All of the data in an Array is stored in a single Place, the 
 * Array's object home.  Data values may only be accessed at
 * the Array's home place.</p>
 * 
 * <p>The Array implementation is optimized for relatively dense 
 * region of points. In particular, to compute the storage required
 * to store an array instance's data, the array's Region is asked
 * for its bounding box (n-dimensional box such that all points in
 * the Region are contained within the bounding box). Backing storage 
 * is allocated for every Point in the bounding box of the array's Region.
 * Using the Array with partially defined Regions (ie, Regions that do 
 * not include every point in the Region's bounding box) is supported
 * and will operate as expected, however if the Region is sparse and large
 * there will be significant space overheads incurred for defining an Array
 * over the Region.  In future versions of X10, we may support a more 
 * space efficient implementation of Arrays over sparse regions, but 
 * such an implementation is not yet available as part of the x10.regionarray package.</p>
 * 
 * <p>The closely related class {@link DistArray} is used to define 
 * distributed arrays where the data values for the Points in the 
 * array's domain are distributed over multiple places.</p>
 * 
 * @see Point
 * @see Region
 * @see DistArray
 */
@x10.runtime.impl.java.X10Generated
final public class Array<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Array> $RTT = 
        x10.rtt.NamedType.<Array> make("x10.regionarray.Array",
                                       Array.class,
                                       1,
                                       new x10.rtt.Type[] {
                                           x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.lang.Point.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                           x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.lang.Point.$RTT)
                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.layout = $deserializer.readObject();
        $_obj.layout_min0 = $deserializer.readLong();
        $_obj.layout_min1 = $deserializer.readLong();
        $_obj.layout_stride1 = $deserializer.readLong();
        $_obj.rail = $deserializer.readBoolean();
        $_obj.rank = $deserializer.readLong();
        $_obj.raw = $deserializer.readObject();
        $_obj.rect = $deserializer.readBoolean();
        $_obj.region = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        $_obj.zeroBased = $deserializer.readBoolean();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Array $_obj = new x10.regionarray.Array((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.layout);
        $serializer.write(this.layout_min0);
        $serializer.write(this.layout_min1);
        $serializer.write(this.layout_stride1);
        $serializer.write(this.rail);
        $serializer.write(this.rank);
        $serializer.write(this.raw);
        $serializer.write(this.rect);
        $serializer.write(this.region);
        $serializer.write(this.size);
        $serializer.write(this.zeroBased);
        
    }
    
    // constructor just for allocation
    public Array(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.regionarray.Array.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $apply$G((x10.lang.Point)a1);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final Array $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Point$3x10$regionarray$Array$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1x10$regionarray$Array$$T {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$regionarray$Array$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __0$1x10$regionarray$Array$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Long$3x10$regionarray$Array$$T$2 {}
    
    // properties
    
    //#line 59 "x10/regionarray/Array.x10"
    /**
         * The region of this array.
         */
    public x10.regionarray.Region region;
    
    //#line 64 "x10/regionarray/Array.x10"
    /**
         * The rank of this array.
         */
    public long rank;
    
    //#line 69 "x10/regionarray/Array.x10"
    /**
         * Is this array defined over a rectangular region?  
         */
    public boolean rect;
    
    //#line 74 "x10/regionarray/Array.x10"
    /**
         * Is this array's region zero-based?
         */
    public boolean zeroBased;
    
    //#line 79 "x10/regionarray/Array.x10"
    /**
         * Is this array's region a "rail" (one-dimensional, rect, and zero-based)?
         */
    public boolean rail;
    
    //#line 85 "x10/regionarray/Array.x10"
    /**
         * The number of points/data values in the array.
         * Will always be equal to region.size(), but cached here to make it available as a property.
         */
    public long size;
    

    
    //#line 97 "x10/regionarray/Array.x10"
    /**
     * The backing storage for the array's elements
     */
    public x10.core.Rail<$T> raw;
    
    
    //#line 115 "x10/regionarray/Array.x10"
    /**
     * Return the Rail[T] that is providing the backing storage for the array.
     * This method is primarily intended to be used to interface with native libraries 
     * (eg BLAS, ESSL). <p>
     * 
     * This method should be used sparingly, since it may make client code dependent on the layout
     * algorithm used to map Points in the Array's Region to indicies in the backing Rail.
     * The specifics of this mapping are unspecified, although it would be reasonable to assume that
     * if the rect property is true, then every element of the backing Rail[T] actually
     * contatins a valid element of T.  Furthermore, for a multi-dimensional array it is currently true
     * (and likely to remain true) that the layout used is a row-major layout (like C, unlike Fortran)
     * and is compatible with the layout expected by platform BLAS libraries that operate on row-major
     * C arrays.
     * 
     * @return the Rail[T] that is the backing storage for the Array object.
     */
    public x10.core.Rail raw() {
        
        //#line 115 "x10/regionarray/Array.x10"
        final x10.core.Rail t$139114 = ((x10.core.Rail)(this.raw));
        
        //#line 115 "x10/regionarray/Array.x10"
        return t$139114;
    }
    
    
    //#line 122 "x10/regionarray/Array.x10"
    /**
     * Construct an Array over the region reg whose elements are zero-initialized.
     * 
     * @param reg The region over which to construct the array.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.regionarray.Region reg) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(reg);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.regionarray.Region reg) {
         {
            
            //#line 124 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140978 = ((x10.regionarray.Region)
                                                      reg);
            
            //#line 124 "x10/regionarray/Array.x10"
            final boolean t$140979 = ((t$140978) != (null));
            
            //#line 124 "x10/regionarray/Array.x10"
            final boolean t$140980 = !(t$140979);
            
            //#line 124 "x10/regionarray/Array.x10"
            if (t$140980) {
                
                //#line 124 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$140981 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 124 "x10/regionarray/Array.x10"
                throw t$140981;
            }
            
            //#line 124 "x10/regionarray/Array.x10"
            final long t$140982 = reg.rank;
            
            //#line 124 "x10/regionarray/Array.x10"
            final boolean t$140983 = reg.rect;
            
            //#line 124 "x10/regionarray/Array.x10"
            final boolean t$140984 = reg.zeroBased;
            
            //#line 124 "x10/regionarray/Array.x10"
            final boolean t$140985 = reg.rail;
            
            //#line 124 "x10/regionarray/Array.x10"
            final long t$140986 = reg.size$O();
            
            //#line 124 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(t$140978));
            this.rank = t$140982;
            this.rect = t$140983;
            this.zeroBased = t$140984;
            this.rail = t$140985;
            this.size = t$140986;
            
            
            //#line 125 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 125 "x10/regionarray/Array.x10"
            crh.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg)));
            
            //#line 126 "x10/regionarray/Array.x10"
            final long t$139123 = crh.min0;
            
            //#line 126 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139123;
            
            //#line 127 "x10/regionarray/Array.x10"
            final long t$139124 = crh.stride1;
            
            //#line 127 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139124;
            
            //#line 128 "x10/regionarray/Array.x10"
            final long t$139125 = crh.min1;
            
            //#line 128 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min1 = t$139125;
            
            //#line 129 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139126 = ((x10.core.Rail)(crh.layout));
            
            //#line 129 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = ((x10.core.Rail)(t$139126));
            
            //#line 130 "x10/regionarray/Array.x10"
            final long n = crh.size;
            
            //#line 131 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139127 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(n)))));
            
            //#line 131 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$139127));
        }
        return this;
    }
    
    
    
    //#line 140 "x10/regionarray/Array.x10"
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final boolean zeroed, final x10.regionarray.Region reg) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(zeroed, reg);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final boolean zeroed, final x10.regionarray.Region reg) {
         {
            
            //#line 142 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140988 = ((x10.regionarray.Region)
                                                      reg);
            
            //#line 142 "x10/regionarray/Array.x10"
            final boolean t$140989 = ((t$140988) != (null));
            
            //#line 142 "x10/regionarray/Array.x10"
            final boolean t$140990 = !(t$140989);
            
            //#line 142 "x10/regionarray/Array.x10"
            if (t$140990) {
                
                //#line 142 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$140991 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 142 "x10/regionarray/Array.x10"
                throw t$140991;
            }
            
            //#line 142 "x10/regionarray/Array.x10"
            final long t$140992 = reg.rank;
            
            //#line 142 "x10/regionarray/Array.x10"
            final boolean t$140993 = reg.rect;
            
            //#line 142 "x10/regionarray/Array.x10"
            final boolean t$140994 = reg.zeroBased;
            
            //#line 142 "x10/regionarray/Array.x10"
            final boolean t$140995 = reg.rail;
            
            //#line 142 "x10/regionarray/Array.x10"
            final long t$140996 = reg.size$O();
            
            //#line 142 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(t$140988));
            this.rank = t$140992;
            this.rect = t$140993;
            this.zeroBased = t$140994;
            this.rail = t$140995;
            this.size = t$140996;
            
            
            //#line 143 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 143 "x10/regionarray/Array.x10"
            crh.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg)));
            
            //#line 144 "x10/regionarray/Array.x10"
            final long t$139136 = crh.min0;
            
            //#line 144 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139136;
            
            //#line 145 "x10/regionarray/Array.x10"
            final long t$139137 = crh.stride1;
            
            //#line 145 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139137;
            
            //#line 146 "x10/regionarray/Array.x10"
            final long t$139138 = crh.min1;
            
            //#line 146 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min1 = t$139138;
            
            //#line 147 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139139 = ((x10.core.Rail)(crh.layout));
            
            //#line 147 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = ((x10.core.Rail)(t$139139));
            
            //#line 148 "x10/regionarray/Array.x10"
            final long n = crh.size;
            
            //#line 149 "x10/regionarray/Array.x10"
            if (zeroed) {
                
                //#line 150 "x10/regionarray/Array.x10"
                final x10.core.Rail t$139140 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(n)))));
                
                //#line 150 "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$139140));
            } else {
                
                //#line 152 "x10/regionarray/Array.x10"
                final x10.core.Rail t$139141 = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(n)), false)));
                
                //#line 152 "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$139141));
            }
        }
        return this;
    }
    
    
    
    //#line 172 "x10/regionarray/Array.x10"
    /**
     * Construct an Array over the region reg whose
     * values are initialized as specified by the init function.
     * The function will be evaluated exactly once for each point
     * in reg in an arbitrary order to 
     * compute the initial value for each array element.</p>
     * 
     * It is unspecified whether the function evaluations will
     * be done sequentially for each point by the current activity 
     * or concurrently for disjoint sets of points by one or more 
     * child activities. 
     * 
     * @param reg The region over which to construct the array.
     * @param init The function to use to initialize the array.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.regionarray.Region reg, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init, __1$1x10$lang$Point$3x10$regionarray$Array$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(reg, init, (x10.regionarray.Array.__1$1x10$lang$Point$3x10$regionarray$Array$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.regionarray.Region reg, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init, __1$1x10$lang$Point$3x10$regionarray$Array$$T$2 $dummy) {
         {
            
            //#line 174 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140998 = ((x10.regionarray.Region)
                                                      reg);
            
            //#line 174 "x10/regionarray/Array.x10"
            final boolean t$140999 = ((t$140998) != (null));
            
            //#line 174 "x10/regionarray/Array.x10"
            final boolean t$141000 = !(t$140999);
            
            //#line 174 "x10/regionarray/Array.x10"
            if (t$141000) {
                
                //#line 174 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141001 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 174 "x10/regionarray/Array.x10"
                throw t$141001;
            }
            
            //#line 174 "x10/regionarray/Array.x10"
            final long t$141002 = reg.rank;
            
            //#line 174 "x10/regionarray/Array.x10"
            final boolean t$141003 = reg.rect;
            
            //#line 174 "x10/regionarray/Array.x10"
            final boolean t$141004 = reg.zeroBased;
            
            //#line 174 "x10/regionarray/Array.x10"
            final boolean t$141005 = reg.rail;
            
            //#line 174 "x10/regionarray/Array.x10"
            final long t$141006 = reg.size$O();
            
            //#line 174 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(t$140998));
            this.rank = t$141002;
            this.rect = t$141003;
            this.zeroBased = t$141004;
            this.rail = t$141005;
            this.size = t$141006;
            
            
            //#line 175 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 175 "x10/regionarray/Array.x10"
            crh.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg)));
            
            //#line 176 "x10/regionarray/Array.x10"
            final long t$139150 = crh.min0;
            
            //#line 176 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139150;
            
            //#line 177 "x10/regionarray/Array.x10"
            final long t$139151 = crh.stride1;
            
            //#line 177 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139151;
            
            //#line 178 "x10/regionarray/Array.x10"
            final long t$139152 = crh.min1;
            
            //#line 178 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min1 = t$139152;
            
            //#line 179 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139153 = ((x10.core.Rail)(crh.layout));
            
            //#line 179 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = ((x10.core.Rail)(t$139153));
            
            //#line 180 "x10/regionarray/Array.x10"
            final long n = crh.size;
            
            //#line 181 "x10/regionarray/Array.x10"
            final x10.core.Rail r = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(n)), false)));
            
            //#line 182 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$141048 = reg.iterator();
            
            //#line 182 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 182 "x10/regionarray/Array.x10"
                final boolean t$141049 = ((x10.lang.Iterator<x10.lang.Point>)p$141048).hasNext$O();
                
                //#line 182 "x10/regionarray/Array.x10"
                if (!(t$141049)) {
                    
                    //#line 182 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 182 "x10/regionarray/Array.x10"
                final x10.lang.Point p$141029 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$141048).next$G()));
                
                //#line 183 "x10/regionarray/Array.x10"
                final x10.regionarray.Array this$141030 = ((x10.regionarray.Array)(this));
                
                //#line 1315 . "x10/regionarray/Array.x10"
                final long t$141032 = ((long)(((int)(0))));
                
                //#line 1315 . "x10/regionarray/Array.x10"
                final long t$141033 = p$141029.$apply$O((long)(t$141032));
                
                //#line 1315 . "x10/regionarray/Array.x10"
                final long t$141034 = ((x10.regionarray.Array<$T>)this$141030).layout_min0;
                
                //#line 1315 . "x10/regionarray/Array.x10"
                long offset$141035 = ((t$141033) - (((long)(t$141034))));
                
                //#line 1316 . "x10/regionarray/Array.x10"
                final long t$141036 = p$141029.rank;
                
                //#line 1316 . "x10/regionarray/Array.x10"
                final boolean t$141037 = ((t$141036) > (((long)(1L))));
                
                //#line 1316 . "x10/regionarray/Array.x10"
                if (t$141037) {
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141039 = ((x10.regionarray.Array<$T>)this$141030).layout_stride1;
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141040 = ((offset$141035) * (((long)(t$141039))));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141041 = p$141029.$apply$O((long)(1L));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141042 = ((t$141040) + (((long)(t$141041))));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141043 = ((x10.regionarray.Array<$T>)this$141030).layout_min1;
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141044 = ((t$141042) - (((long)(t$141043))));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    offset$141035 = t$141044;
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    final long t$141027 = p$141029.rank;
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    final long i$138093max$141028 = ((t$141027) - (((long)(1L))));
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    long i$141024 = 2L;
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        final boolean t$141026 = ((i$141024) <= (((long)(i$138093max$141028))));
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        if (!(t$141026)) {
                            
                            //#line 1318 . "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141008 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141030).layout));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141009 = ((i$141024) - (((long)(2L))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141010 = ((2L) * (((long)(t$141009))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141011 = ((long[])t$141008.value)[(int)t$141010];
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141012 = ((offset$141035) * (((long)(t$141011))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141013 = p$141029.$apply$O((long)(i$141024));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141014 = ((t$141012) + (((long)(t$141013))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141015 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141030).layout));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141016 = ((i$141024) - (((long)(2L))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141017 = ((2L) * (((long)(t$141016))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141018 = ((t$141017) + (((long)(1L))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141019 = ((long[])t$141015.value)[(int)t$141018];
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141020 = ((t$141014) - (((long)(t$141019))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        offset$141035 = t$141020;
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        final long t$141023 = ((i$141024) + (((long)(1L))));
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        i$141024 = t$141023;
                    }
                }
                
                //#line 183 "x10/regionarray/Array.x10"
                final $T t$141046 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<x10.lang.Point,$T>)init).$apply(p$141029, x10.lang.Point.$RTT))));
                
                //#line 183 "x10/regionarray/Array.x10"
                ((x10.core.Rail<$T>)r).$set__1x10$lang$Rail$$T$G((long)(offset$141035), (($T)(t$141046)));
            }
            
            //#line 185 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(r));
        }
        return this;
    }
    
    
    
    //#line 195 "x10/regionarray/Array.x10"
    /**
     * Construct an Array over the region reg whose
     * values are initialized to be init.
     * 
     * @param reg The region over which to construct the array.
     * @param init The function to use to initialize the array.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.regionarray.Region reg, final $T init, __1x10$regionarray$Array$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(reg, init, (x10.regionarray.Array.__1x10$regionarray$Array$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.regionarray.Region reg, final $T init, __1x10$regionarray$Array$$T $dummy) {
         {
            
            //#line 197 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141050 = ((x10.regionarray.Region)
                                                      reg);
            
            //#line 197 "x10/regionarray/Array.x10"
            final boolean t$141051 = ((t$141050) != (null));
            
            //#line 197 "x10/regionarray/Array.x10"
            final boolean t$141052 = !(t$141051);
            
            //#line 197 "x10/regionarray/Array.x10"
            if (t$141052) {
                
                //#line 197 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141053 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 197 "x10/regionarray/Array.x10"
                throw t$141053;
            }
            
            //#line 197 "x10/regionarray/Array.x10"
            final long t$141054 = reg.rank;
            
            //#line 197 "x10/regionarray/Array.x10"
            final boolean t$141055 = reg.rect;
            
            //#line 197 "x10/regionarray/Array.x10"
            final boolean t$141056 = reg.zeroBased;
            
            //#line 197 "x10/regionarray/Array.x10"
            final boolean t$141057 = reg.rail;
            
            //#line 197 "x10/regionarray/Array.x10"
            final long t$141058 = reg.size$O();
            
            //#line 197 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(t$141050));
            this.rank = t$141054;
            this.rect = t$141055;
            this.zeroBased = t$141056;
            this.rail = t$141057;
            this.size = t$141058;
            
            
            //#line 199 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 199 "x10/regionarray/Array.x10"
            crh.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg)));
            
            //#line 200 "x10/regionarray/Array.x10"
            final long t$139198 = crh.min0;
            
            //#line 200 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139198;
            
            //#line 201 "x10/regionarray/Array.x10"
            final long t$139199 = crh.stride1;
            
            //#line 201 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139199;
            
            //#line 202 "x10/regionarray/Array.x10"
            final long t$139200 = crh.min1;
            
            //#line 202 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min1 = t$139200;
            
            //#line 203 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139201 = ((x10.core.Rail)(crh.layout));
            
            //#line 203 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = ((x10.core.Rail)(t$139201));
            
            //#line 204 "x10/regionarray/Array.x10"
            final long n = crh.size;
            
            //#line 205 "x10/regionarray/Array.x10"
            final x10.core.Rail r = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(n)), false)));
            
            //#line 206 "x10/regionarray/Array.x10"
            final boolean t$139242 = reg.rect;
            
            //#line 206 "x10/regionarray/Array.x10"
            if (t$139242) {
                
                //#line 209 "x10/regionarray/Array.x10"
                final long i$137869max$137871 = ((x10.core.Rail<$T>)r).size;
                
                //#line 209 "x10/regionarray/Array.x10"
                long i$141062 = 0L;
                
                //#line 209 "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 209 "x10/regionarray/Array.x10"
                    final boolean t$141064 = ((i$141062) < (((long)(i$137869max$137871))));
                    
                    //#line 209 "x10/regionarray/Array.x10"
                    if (!(t$141064)) {
                        
                        //#line 209 "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 210 "x10/regionarray/Array.x10"
                    ((x10.core.Rail<$T>)r).$set__1x10$lang$Rail$$T$G((long)(i$141062), (($T)(init)));
                    
                    //#line 209 "x10/regionarray/Array.x10"
                    final long t$141061 = ((i$141062) + (((long)(1L))));
                    
                    //#line 209 "x10/regionarray/Array.x10"
                    i$141062 = t$141061;
                }
            } else {
                
                //#line 213 "x10/regionarray/Array.x10"
                final x10.lang.Iterator p$137888 = reg.iterator();
                
                //#line 213 "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 213 "x10/regionarray/Array.x10"
                    final boolean t$139241 = ((x10.lang.Iterator<x10.lang.Point>)p$137888).hasNext$O();
                    
                    //#line 213 "x10/regionarray/Array.x10"
                    if (!(t$139241)) {
                        
                        //#line 213 "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 213 "x10/regionarray/Array.x10"
                    final x10.lang.Point p$141087 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$137888).next$G()));
                    
                    //#line 214 "x10/regionarray/Array.x10"
                    final x10.regionarray.Array this$141088 = ((x10.regionarray.Array)(this));
                    
                    //#line 1315 . "x10/regionarray/Array.x10"
                    final long t$141090 = ((long)(((int)(0))));
                    
                    //#line 1315 . "x10/regionarray/Array.x10"
                    final long t$141091 = p$141087.$apply$O((long)(t$141090));
                    
                    //#line 1315 . "x10/regionarray/Array.x10"
                    final long t$141092 = ((x10.regionarray.Array<$T>)this$141088).layout_min0;
                    
                    //#line 1315 . "x10/regionarray/Array.x10"
                    long offset$141093 = ((t$141091) - (((long)(t$141092))));
                    
                    //#line 1316 . "x10/regionarray/Array.x10"
                    final long t$141094 = p$141087.rank;
                    
                    //#line 1316 . "x10/regionarray/Array.x10"
                    final boolean t$141095 = ((t$141094) > (((long)(1L))));
                    
                    //#line 1316 . "x10/regionarray/Array.x10"
                    if (t$141095) {
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        final long t$141097 = ((x10.regionarray.Array<$T>)this$141088).layout_stride1;
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        final long t$141098 = ((offset$141093) * (((long)(t$141097))));
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        final long t$141099 = p$141087.$apply$O((long)(1L));
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        final long t$141100 = ((t$141098) + (((long)(t$141099))));
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        final long t$141101 = ((x10.regionarray.Array<$T>)this$141088).layout_min1;
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        final long t$141102 = ((t$141100) - (((long)(t$141101))));
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        offset$141093 = t$141102;
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        final long t$141085 = p$141087.rank;
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        final long i$138093max$141086 = ((t$141085) - (((long)(1L))));
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        long i$141082 = 2L;
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 1318 . "x10/regionarray/Array.x10"
                            final boolean t$141084 = ((i$141082) <= (((long)(i$138093max$141086))));
                            
                            //#line 1318 . "x10/regionarray/Array.x10"
                            if (!(t$141084)) {
                                
                                //#line 1318 . "x10/regionarray/Array.x10"
                                break;
                            }
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final x10.core.Rail t$141066 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141088).layout));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141067 = ((i$141082) - (((long)(2L))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141068 = ((2L) * (((long)(t$141067))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141069 = ((long[])t$141066.value)[(int)t$141068];
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141070 = ((offset$141093) * (((long)(t$141069))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141071 = p$141087.$apply$O((long)(i$141082));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141072 = ((t$141070) + (((long)(t$141071))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final x10.core.Rail t$141073 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141088).layout));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141074 = ((i$141082) - (((long)(2L))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141075 = ((2L) * (((long)(t$141074))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141076 = ((t$141075) + (((long)(1L))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141077 = ((long[])t$141073.value)[(int)t$141076];
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141078 = ((t$141072) - (((long)(t$141077))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            offset$141093 = t$141078;
                            
                            //#line 1318 . "x10/regionarray/Array.x10"
                            final long t$141081 = ((i$141082) + (((long)(1L))));
                            
                            //#line 1318 . "x10/regionarray/Array.x10"
                            i$141082 = t$141081;
                        }
                    }
                    
                    //#line 214 "x10/regionarray/Array.x10"
                    ((x10.core.Rail<$T>)r).$set__1x10$lang$Rail$$T$G((long)(offset$141093), (($T)(init)));
                }
            }
            
            //#line 217 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(r));
        }
        return this;
    }
    
    
    
    //#line 231 "x10/regionarray/Array.x10"
    /**
     * Construct an Array view of a backing Rail
     * using the argument region to define how to map Points into
     * offsets in the backingStorage.  The size of the Rail
     * must be at least as large as the number of points in the boundingBox
     * of the given Region.
     * 
     * @param reg The region over which to define the array.
     * @param backingStore The backing storage for the array data.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.regionarray.Region reg, final x10.core.Rail<$T> backingStore, __1$1x10$regionarray$Array$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(reg, backingStore, (x10.regionarray.Array.__1$1x10$regionarray$Array$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.regionarray.Region reg, final x10.core.Rail<$T> backingStore, __1$1x10$regionarray$Array$$T$2 $dummy) {
         {
            
            //#line 233 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141105 = ((x10.regionarray.Region)
                                                      reg);
            
            //#line 233 "x10/regionarray/Array.x10"
            final boolean t$141106 = ((t$141105) != (null));
            
            //#line 233 "x10/regionarray/Array.x10"
            final boolean t$141107 = !(t$141106);
            
            //#line 233 "x10/regionarray/Array.x10"
            if (t$141107) {
                
                //#line 233 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141108 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 233 "x10/regionarray/Array.x10"
                throw t$141108;
            }
            
            //#line 233 "x10/regionarray/Array.x10"
            final long t$141109 = reg.rank;
            
            //#line 233 "x10/regionarray/Array.x10"
            final boolean t$141110 = reg.rect;
            
            //#line 233 "x10/regionarray/Array.x10"
            final boolean t$141111 = reg.zeroBased;
            
            //#line 233 "x10/regionarray/Array.x10"
            final boolean t$141112 = reg.rail;
            
            //#line 233 "x10/regionarray/Array.x10"
            final long t$141113 = reg.size$O();
            
            //#line 233 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(t$141105));
            this.rank = t$141109;
            this.rect = t$141110;
            this.zeroBased = t$141111;
            this.rail = t$141112;
            this.size = t$141113;
            
            
            //#line 235 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 235 "x10/regionarray/Array.x10"
            crh.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg)));
            
            //#line 236 "x10/regionarray/Array.x10"
            final long t$139251 = crh.min0;
            
            //#line 236 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139251;
            
            //#line 237 "x10/regionarray/Array.x10"
            final long t$139252 = crh.stride1;
            
            //#line 237 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139252;
            
            //#line 238 "x10/regionarray/Array.x10"
            final long t$139253 = crh.min1;
            
            //#line 238 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min1 = t$139253;
            
            //#line 239 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139254 = ((x10.core.Rail)(crh.layout));
            
            //#line 239 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = ((x10.core.Rail)(t$139254));
            
            //#line 240 "x10/regionarray/Array.x10"
            final long n = crh.size;
            
            //#line 241 "x10/regionarray/Array.x10"
            final long t$139255 = ((x10.core.Rail<$T>)backingStore).size;
            
            //#line 241 "x10/regionarray/Array.x10"
            final boolean t$139257 = ((n) > (((long)(t$139255))));
            
            //#line 241 "x10/regionarray/Array.x10"
            if (t$139257) {
                
                //#line 242 "x10/regionarray/Array.x10"
                final java.lang.IllegalArgumentException t$139256 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("backingStore too small")));
                
                //#line 242 "x10/regionarray/Array.x10"
                throw t$139256;
            }
            
            //#line 244 "x10/regionarray/Array.x10"
            final x10.core.Rail t$136003 = ((x10.core.Rail<$T>)
                                             backingStore);
            
            //#line 244 "x10/regionarray/Array.x10"
            final boolean t$139258 = ((t$136003) != (null));
            
            //#line 244 "x10/regionarray/Array.x10"
            final boolean t$139260 = !(t$139258);
            
            //#line 244 "x10/regionarray/Array.x10"
            if (t$139260) {
                
                //#line 244 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$139259 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self!=null}");
                
                //#line 244 "x10/regionarray/Array.x10"
                throw t$139259;
            }
            
            //#line 244 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$136003));
        }
        return this;
    }
    
    
    
    //#line 253 "x10/regionarray/Array.x10"
    /**
     * Construct an Array view of a backing Rail
     * using the region 0..(backingStore.size-1)
     * 
     * @param backingStore The backing storage for the array data.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.core.Rail<$T> backingStore, __0$1x10$regionarray$Array$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(backingStore, (x10.regionarray.Array.__0$1x10$regionarray$Array$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.core.Rail<$T> backingStore, __0$1x10$regionarray$Array$$T$2 $dummy) {
         {
            
            //#line 255 "x10/regionarray/Array.x10"
            final long s = ((x10.core.Rail<$T>)backingStore).size;
            
            //#line 256 "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 256 "x10/regionarray/Array.x10"
            final long t$141115 = ((s) - (((long)(1L))));
            
            //#line 256 "x10/regionarray/Array.x10"
            myReg.x10$regionarray$RectRegion1D$$init$S(t$141115);
            
            //#line 257 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(myReg));
            this.rank = 1L;
            this.rect = true;
            this.zeroBased = true;
            this.rail = true;
            this.size = s;
            
            
            //#line 259 "x10/regionarray/Array.x10"
            final long t$139262 = ((x10.regionarray.Array<$T>)this).layout_min1 = 0L;
            
            //#line 259 "x10/regionarray/Array.x10"
            final long t$139263 = ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139262;
            
            //#line 259 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139263;
            
            //#line 260 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = null;
            
            //#line 261 "x10/regionarray/Array.x10"
            final x10.core.Rail t$136012 = ((x10.core.Rail<$T>)
                                             backingStore);
            
            //#line 261 "x10/regionarray/Array.x10"
            final boolean t$139264 = ((t$136012) != (null));
            
            //#line 261 "x10/regionarray/Array.x10"
            final boolean t$139266 = !(t$139264);
            
            //#line 261 "x10/regionarray/Array.x10"
            if (t$139266) {
                
                //#line 261 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$139265 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self!=null}");
                
                //#line 261 "x10/regionarray/Array.x10"
                throw t$139265;
            }
            
            //#line 261 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$136012));
        }
        return this;
    }
    
    
    
    //#line 268 "x10/regionarray/Array.x10"
    /**
     * Construct Array over the region 0..(size-1) whose elements are zero-initialized.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final long size) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(size);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final long size) {
         {
            
            //#line 270 "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 "x10/regionarray/Array.x10"
            final long t$141117 = ((size) - (((long)(1L))));
            
            //#line 270 "x10/regionarray/Array.x10"
            myReg.x10$regionarray$RectRegion1D$$init$S(t$141117);
            
            //#line 271 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(myReg));
            this.rank = 1L;
            this.rect = true;
            this.zeroBased = true;
            this.rail = true;
            this.size = size;
            
            
            //#line 273 "x10/regionarray/Array.x10"
            final long t$139268 = ((x10.regionarray.Array<$T>)this).layout_min1 = 0L;
            
            //#line 273 "x10/regionarray/Array.x10"
            final long t$139269 = ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139268;
            
            //#line 273 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139269;
            
            //#line 274 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = null;
            
            //#line 275 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139270 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(size)))));
            
            //#line 275 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$139270));
        }
        return this;
    }
    
    
    
    //#line 282 "x10/regionarray/Array.x10"
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final boolean zeroed, final long size) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(zeroed, size);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final boolean zeroed, final long size) {
         {
            
            //#line 284 "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 284 "x10/regionarray/Array.x10"
            final long t$141119 = ((size) - (((long)(1L))));
            
            //#line 284 "x10/regionarray/Array.x10"
            myReg.x10$regionarray$RectRegion1D$$init$S(t$141119);
            
            //#line 285 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(myReg));
            this.rank = 1L;
            this.rect = true;
            this.zeroBased = true;
            this.rail = true;
            this.size = size;
            
            
            //#line 287 "x10/regionarray/Array.x10"
            final long t$139272 = ((x10.regionarray.Array<$T>)this).layout_min1 = 0L;
            
            //#line 287 "x10/regionarray/Array.x10"
            final long t$139273 = ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139272;
            
            //#line 287 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139273;
            
            //#line 288 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = null;
            
            //#line 289 "x10/regionarray/Array.x10"
            if (zeroed) {
                
                //#line 290 "x10/regionarray/Array.x10"
                final x10.core.Rail t$139274 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(size)))));
                
                //#line 290 "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$139274));
            } else {
                
                //#line 292 "x10/regionarray/Array.x10"
                final x10.core.Rail t$139275 = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(size)), false)));
                
                //#line 292 "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$139275));
            }
        }
        return this;
    }
    
    
    
    //#line 312 "x10/regionarray/Array.x10"
    /**
     * Construct Array over the region 0..(size-1) whose
     * values are initialized as specified by the init function.
     * The function will be evaluated exactly once for each point
     * in reg in an arbitrary order to 
     * compute the initial value for each array element.</p>
     * 
     * It is unspecified whether the function evaluations will
     * be done sequentially for each point by the current activity 
     * or concurrently for disjoint sets of points by one or more 
     * child activities. 
     * 
     * 
     * @param reg The region over which to construct the array.
     * @param init The function to use to initialize the array.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final long size, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __1$1x10$lang$Long$3x10$regionarray$Array$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(size, init, (x10.regionarray.Array.__1$1x10$lang$Long$3x10$regionarray$Array$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final long size, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __1$1x10$lang$Long$3x10$regionarray$Array$$T$2 $dummy) {
         {
            
            //#line 314 "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 314 "x10/regionarray/Array.x10"
            final long t$141128 = ((size) - (((long)(1L))));
            
            //#line 314 "x10/regionarray/Array.x10"
            myReg.x10$regionarray$RectRegion1D$$init$S(t$141128);
            
            //#line 315 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(myReg));
            this.rank = 1L;
            this.rect = true;
            this.zeroBased = true;
            this.rail = true;
            this.size = size;
            
            
            //#line 317 "x10/regionarray/Array.x10"
            final long t$139277 = ((x10.regionarray.Array<$T>)this).layout_min1 = 0L;
            
            //#line 317 "x10/regionarray/Array.x10"
            final long t$139278 = ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139277;
            
            //#line 317 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139278;
            
            //#line 318 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = null;
            
            //#line 319 "x10/regionarray/Array.x10"
            final x10.core.Rail r = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(size)), false)));
            
            //#line 320 "x10/regionarray/Array.x10"
            final long i$137890max$141130 = ((size) - (((long)(1L))));
            
            //#line 320 "x10/regionarray/Array.x10"
            long i$141125 = 0L;
            
            //#line 320 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 320 "x10/regionarray/Array.x10"
                final boolean t$141127 = ((i$141125) <= (((long)(i$137890max$141130))));
                
                //#line 320 "x10/regionarray/Array.x10"
                if (!(t$141127)) {
                    
                    //#line 320 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 321 "x10/regionarray/Array.x10"
                final $T t$141121 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)init).$apply(x10.core.Long.$box(i$141125), x10.rtt.Types.LONG))));
                
                //#line 321 "x10/regionarray/Array.x10"
                ((x10.core.Rail<$T>)r).$set__1x10$lang$Rail$$T$G((long)(i$141125), (($T)(t$141121)));
                
                //#line 320 "x10/regionarray/Array.x10"
                final long t$141124 = ((i$141125) + (((long)(1L))));
                
                //#line 320 "x10/regionarray/Array.x10"
                i$141125 = t$141124;
            }
            
            //#line 323 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(r));
        }
        return this;
    }
    
    
    
    //#line 333 "x10/regionarray/Array.x10"
    /**
     * Construct Array over the region 0..(size-1) whose
     * values are initialized to be init
     * 
     * @param reg The region over which to construct the array.
     * @param init The function to use to initialize the array.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final long size, final $T init, __1x10$regionarray$Array$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(size, init, (x10.regionarray.Array.__1x10$regionarray$Array$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final long size, final $T init, __1x10$regionarray$Array$$T $dummy) {
         {
            
            //#line 335 "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 335 "x10/regionarray/Array.x10"
            final long t$141137 = ((size) - (((long)(1L))));
            
            //#line 335 "x10/regionarray/Array.x10"
            myReg.x10$regionarray$RectRegion1D$$init$S(t$141137);
            
            //#line 336 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(myReg));
            this.rank = 1L;
            this.rect = true;
            this.zeroBased = true;
            this.rail = true;
            this.size = size;
            
            
            //#line 338 "x10/regionarray/Array.x10"
            final long t$139286 = ((x10.regionarray.Array<$T>)this).layout_min1 = 0L;
            
            //#line 338 "x10/regionarray/Array.x10"
            final long t$139287 = ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139286;
            
            //#line 338 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139287;
            
            //#line 339 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = null;
            
            //#line 340 "x10/regionarray/Array.x10"
            final x10.core.Rail r = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(size)), false)));
            
            //#line 341 "x10/regionarray/Array.x10"
            final long i$137908max$141139 = ((size) - (((long)(1L))));
            
            //#line 341 "x10/regionarray/Array.x10"
            long i$141134 = 0L;
            
            //#line 341 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 341 "x10/regionarray/Array.x10"
                final boolean t$141136 = ((i$141134) <= (((long)(i$137908max$141139))));
                
                //#line 341 "x10/regionarray/Array.x10"
                if (!(t$141136)) {
                    
                    //#line 341 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 342 "x10/regionarray/Array.x10"
                ((x10.core.Rail<$T>)r).$set__1x10$lang$Rail$$T$G((long)(i$141134), (($T)(init)));
                
                //#line 341 "x10/regionarray/Array.x10"
                final long t$141133 = ((i$141134) + (((long)(1L))));
                
                //#line 341 "x10/regionarray/Array.x10"
                i$141134 = t$141133;
            }
            
            //#line 344 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(r));
        }
        return this;
    }
    
    
    
    //#line 353 "x10/regionarray/Array.x10"
    /**
     * Construct a copy of the given Array.
     * 
     * @param init The array to copy.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.regionarray.Array<$T> init, __0$1x10$regionarray$Array$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(init, (x10.regionarray.Array.__0$1x10$regionarray$Array$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.regionarray.Array<$T> init, __0$1x10$regionarray$Array$$T$2 $dummy) {
         {
            
            //#line 355 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141140 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)init).region));
            
            //#line 355 "x10/regionarray/Array.x10"
            final long t$141141 = ((x10.regionarray.Array<$T>)init).rank;
            
            //#line 355 "x10/regionarray/Array.x10"
            final boolean t$141142 = ((x10.regionarray.Array<$T>)init).rect;
            
            //#line 355 "x10/regionarray/Array.x10"
            final boolean t$141143 = ((x10.regionarray.Array<$T>)init).zeroBased;
            
            //#line 355 "x10/regionarray/Array.x10"
            final boolean t$141144 = ((x10.regionarray.Array<$T>)init).rail;
            
            //#line 355 "x10/regionarray/Array.x10"
            final long t$141145 = ((x10.regionarray.Array<$T>)init).size;
            
            //#line 355 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(t$141140));
            this.rank = t$141141;
            this.rect = t$141142;
            this.zeroBased = t$141143;
            this.rail = t$141144;
            this.size = t$141145;
            
            
            //#line 356 "x10/regionarray/Array.x10"
            final long t$139299 = ((x10.regionarray.Array<$T>)init).layout_min0;
            
            //#line 356 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139299;
            
            //#line 357 "x10/regionarray/Array.x10"
            final long t$139300 = ((x10.regionarray.Array<$T>)init).layout_stride1;
            
            //#line 357 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139300;
            
            //#line 358 "x10/regionarray/Array.x10"
            final long t$139301 = ((x10.regionarray.Array<$T>)init).layout_min1;
            
            //#line 358 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min1 = t$139301;
            
            //#line 359 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139302 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)init).layout));
            
            //#line 359 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = ((x10.core.Rail)(t$139302));
            
            //#line 360 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139303 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)init).raw));
            
            //#line 360 "x10/regionarray/Array.x10"
            final long t$139304 = ((x10.core.Rail<$T>)t$139303).size;
            
            //#line 360 "x10/regionarray/Array.x10"
            final x10.core.Rail r = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$139304)), false)));
            
            //#line 361 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139305 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)init).raw));
            
            //#line 361 "x10/regionarray/Array.x10"
            final long t$139306 = ((x10.core.Rail<$T>)r).size;
            
            //#line 361 "x10/regionarray/Array.x10"
            x10.core.Rail.<$T> copy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$139305)), (long)(0L), ((x10.core.Rail)(r)), (long)(0L), (long)(t$139306));
            
            //#line 362 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(r));
        }
        return this;
    }
    
    
    
    //#line 371 "x10/regionarray/Array.x10"
    /**
     * Construct a copy of the given RemoteArray.
     * 
     * @param init The remote array to copy.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.regionarray.RemoteArray<$T> init, __0$1x10$regionarray$Array$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(init, (x10.regionarray.Array.__0$1x10$regionarray$Array$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.regionarray.RemoteArray<$T> init, __0$1x10$regionarray$Array$$T$2 $dummy) {
         {
            
            //#line 373 "x10/regionarray/Array.x10"
            final x10.regionarray.Array this$138701 = ((x10.regionarray.Array)(this));
            
            //#line 373 "x10/regionarray/Array.x10"
            final x10.core.GlobalRef t$139307 = ((x10.core.GlobalRef)(((x10.regionarray.RemoteArray<$T>)init).array));
            
            //#line 373 "x10/regionarray/Array.x10"
            final x10.regionarray.Array init$138699 = ((x10.regionarray.Array)((((x10.core.GlobalRef<x10.regionarray.Array<$T>>)(t$139307))).$apply$G()));
            
            //#line 355 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141147 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)init$138699).region));
            
            //#line 355 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$138701).region = ((x10.regionarray.Region)(t$141147));
            
            //#line 355 . "x10/regionarray/Array.x10"
            final long t$141148 = ((x10.regionarray.Array<$T>)init$138699).rank;
            
            //#line 355 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$138701).rank = t$141148;
            
            //#line 355 . "x10/regionarray/Array.x10"
            final boolean t$141149 = ((x10.regionarray.Array<$T>)init$138699).rect;
            
            //#line 355 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$138701).rect = t$141149;
            
            //#line 355 . "x10/regionarray/Array.x10"
            final boolean t$141150 = ((x10.regionarray.Array<$T>)init$138699).zeroBased;
            
            //#line 355 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$138701).zeroBased = t$141150;
            
            //#line 355 . "x10/regionarray/Array.x10"
            final boolean t$141151 = ((x10.regionarray.Array<$T>)init$138699).rail;
            
            //#line 355 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$138701).rail = t$141151;
            
            //#line 355 . "x10/regionarray/Array.x10"
            final long t$141152 = ((x10.regionarray.Array<$T>)init$138699).size;
            
            //#line 355 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$138701).size = t$141152;
            
            //#line 356 . "x10/regionarray/Array.x10"
            final long t$141153 = ((x10.regionarray.Array<$T>)init$138699).layout_min0;
            
            //#line 356 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$138701).layout_min0 = t$141153;
            
            //#line 357 . "x10/regionarray/Array.x10"
            final long t$141154 = ((x10.regionarray.Array<$T>)init$138699).layout_stride1;
            
            //#line 357 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$138701).layout_stride1 = t$141154;
            
            //#line 358 . "x10/regionarray/Array.x10"
            final long t$141155 = ((x10.regionarray.Array<$T>)init$138699).layout_min1;
            
            //#line 358 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$138701).layout_min1 = t$141155;
            
            //#line 359 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$141156 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)init$138699).layout));
            
            //#line 359 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$138701).layout = ((x10.core.Rail)(t$141156));
            
            //#line 360 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$141157 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)init$138699).raw));
            
            //#line 360 . "x10/regionarray/Array.x10"
            final long t$141158 = ((x10.core.Rail<$T>)t$141157).size;
            
            //#line 360 . "x10/regionarray/Array.x10"
            final x10.core.Rail r$141159 = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$141158)), false)));
            
            //#line 361 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$141160 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)init$138699).raw));
            
            //#line 361 . "x10/regionarray/Array.x10"
            final long t$141161 = ((x10.core.Rail<$T>)r$141159).size;
            
            //#line 361 . "x10/regionarray/Array.x10"
            x10.core.Rail.<$T> copy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$141160)), (long)(0L), ((x10.core.Rail)(r$141159)), (long)(0L), (long)(t$141161));
            
            //#line 362 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$138701).raw = ((x10.core.Rail)(r$141159));
        }
        return this;
    }
    
    
    
    //#line 381 "x10/regionarray/Array.x10"
    /**
     * Return the string representation of this array.
     * 
     * @return the string representation of this array.
     */
    public java.lang.String toString() {
        
        //#line 382 "x10/regionarray/Array.x10"
        final boolean t$139342 = this.rail;
        
        //#line 382 "x10/regionarray/Array.x10"
        if (t$139342) {
            
            //#line 383 "x10/regionarray/Array.x10"
            final x10.util.StringBuilder sb = ((x10.util.StringBuilder)(new x10.util.StringBuilder((java.lang.System[]) null)));
            
            //#line 383 "x10/regionarray/Array.x10"
            sb.x10$util$StringBuilder$$init$S();
            
            //#line 384 "x10/regionarray/Array.x10"
            sb.add(((java.lang.String)("[")));
            
            //#line 385 "x10/regionarray/Array.x10"
            final long t$139322 = this.size;
            
            //#line 385 "x10/regionarray/Array.x10"
            final long sz = java.lang.Math.min(((long)(t$139322)),((long)(10L)));
            
            //#line 386 "x10/regionarray/Array.x10"
            final long i$137926max$141172 = ((sz) - (((long)(1L))));
            
            //#line 386 "x10/regionarray/Array.x10"
            long i$141169 = 0L;
            
            //#line 386 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 386 "x10/regionarray/Array.x10"
                final boolean t$141171 = ((i$141169) <= (((long)(i$137926max$141172))));
                
                //#line 386 "x10/regionarray/Array.x10"
                if (!(t$141171)) {
                    
                    //#line 386 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 387 "x10/regionarray/Array.x10"
                final boolean t$141162 = ((i$141169) > (((long)(0L))));
                
                //#line 387 "x10/regionarray/Array.x10"
                if (t$141162) {
                    
                    //#line 387 "x10/regionarray/Array.x10"
                    sb.add(((java.lang.String)(",")));
                }
                
                //#line 388 "x10/regionarray/Array.x10"
                final x10.core.Rail t$141163 = ((x10.core.Rail)(this.raw));
                
                //#line 388 "x10/regionarray/Array.x10"
                final $T t$141164 = (($T)(((x10.core.Rail<$T>)t$141163).$apply$G((long)(i$141169))));
                
                //#line 388 "x10/regionarray/Array.x10"
                final java.lang.String t$141165 = (("") + (t$141164));
                
                //#line 388 "x10/regionarray/Array.x10"
                sb.add(((java.lang.String)(t$141165)));
                
                //#line 386 "x10/regionarray/Array.x10"
                final long t$141168 = ((i$141169) + (((long)(1L))));
                
                //#line 386 "x10/regionarray/Array.x10"
                i$141169 = t$141168;
            }
            
            //#line 390 "x10/regionarray/Array.x10"
            final long t$139332 = this.size;
            
            //#line 390 "x10/regionarray/Array.x10"
            final boolean t$139337 = ((sz) < (((long)(t$139332))));
            
            //#line 390 "x10/regionarray/Array.x10"
            if (t$139337) {
                
                //#line 390 "x10/regionarray/Array.x10"
                final long t$139333 = this.size;
                
                //#line 390 "x10/regionarray/Array.x10"
                final long t$139334 = ((t$139333) - (((long)(sz))));
                
                //#line 390 "x10/regionarray/Array.x10"
                final java.lang.String t$139335 = (("...(omitted ") + ((x10.core.Long.$box(t$139334))));
                
                //#line 390 "x10/regionarray/Array.x10"
                final java.lang.String t$139336 = ((t$139335) + (" elements)"));
                
                //#line 390 "x10/regionarray/Array.x10"
                sb.add(((java.lang.String)(t$139336)));
            }
            
            //#line 391 "x10/regionarray/Array.x10"
            sb.add(((java.lang.String)("]")));
            
            //#line 392 "x10/regionarray/Array.x10"
            final java.lang.String t$139338 = sb.toString();
            
            //#line 392 "x10/regionarray/Array.x10"
            return t$139338;
        } else {
            
            //#line 394 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$139339 = ((x10.regionarray.Region)(this.region));
            
            //#line 394 "x10/regionarray/Array.x10"
            final java.lang.String t$139340 = (("Array(") + (t$139339));
            
            //#line 394 "x10/regionarray/Array.x10"
            final java.lang.String t$139341 = ((t$139340) + (")"));
            
            //#line 394 "x10/regionarray/Array.x10"
            return t$139341;
        }
    }
    
    
    //#line 404 "x10/regionarray/Array.x10"
    /**
     * Return an iterator over the points in the region of this array.
     * 
     * @return an iterator over the points in the region of this array.
     * @see x10.lang.Iterable[T]#iterator()
     */
    public x10.lang.Iterator iterator() {
        
        //#line 404 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$139343 = ((x10.regionarray.Region)(this.region));
        
        //#line 404 "x10/regionarray/Array.x10"
        final x10.lang.Iterator t$139344 = t$139343.iterator();
        
        //#line 404 "x10/regionarray/Array.x10"
        return t$139344;
    }
    
    
    //#line 412 "x10/regionarray/Array.x10"
    /**
     * Return an Iterable[T] that can construct iterators 
     * over this array.<p>
     * @return an Iterable[T] over this array.
     */
    public x10.lang.Iterable values() {
        
        //#line 413 "x10/regionarray/Array.x10"
        final boolean t$139345 = this.rect;
        
        //#line 413 "x10/regionarray/Array.x10"
        if (t$139345) {
            
            //#line 414 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.Anonymous$14235 alloc$137859 = ((x10.regionarray.Array.Anonymous$14235)(new x10.regionarray.Array.Anonymous$14235<$T>((java.lang.System[]) null, $T)));
            
            //#line 414 "x10/regionarray/Array.x10"
            final x10.regionarray.Array out$138704 = ((x10.regionarray.Array)(this));
            
            //#line 55 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array.Anonymous$14235<$T>)alloc$137859).out$ = out$138704;
            
            //#line 414 "x10/regionarray/Array.x10"
            return alloc$137859;
        } else {
            
            //#line 422 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.Anonymous$14520 alloc$137860 = ((x10.regionarray.Array.Anonymous$14520)(new x10.regionarray.Array.Anonymous$14520<$T>((java.lang.System[]) null, $T)));
            
            //#line 422 "x10/regionarray/Array.x10"
            final x10.regionarray.Array out$138706 = ((x10.regionarray.Array)(this));
            
            //#line 55 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array.Anonymous$14520<$T>)alloc$137860).out$ = out$138706;
            
            //#line 422 "x10/regionarray/Array.x10"
            return alloc$137860;
        }
    }
    
    
    //#line 442 "x10/regionarray/Array.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * Only applies to one-dimensional arrays.
     * Functionally equivalent to indexing the array via a one-dimensional point.
     * 
     * @param i0 the given index in the first dimension
     * @return the element of this array corresponding to the given index.
     * @see #operator(Point)
     * @see #set(T, Long)
     */
    public $T $apply$G(final long i0) {
        
        //#line 444 "x10/regionarray/Array.x10"
        final boolean t$139355 = this.rail;
        
        //#line 444 "x10/regionarray/Array.x10"
        if (t$139355) {
            
            //#line 446 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139346 = ((x10.core.Rail)(this.raw));
            
            //#line 446 "x10/regionarray/Array.x10"
            final $T t$139347 = (($T)(((x10.core.Rail<$T>)t$139346).$apply$G((long)(i0))));
            
            //#line 446 "x10/regionarray/Array.x10"
            return t$139347;
        } else {
            
            //#line 448 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$139348 = ((x10.regionarray.Region)(this.region));
            
            //#line 448 "x10/regionarray/Array.x10"
            final boolean t$139349 = t$139348.contains$O((long)(i0));
            
            //#line 448 "x10/regionarray/Array.x10"
            final boolean t$139350 = !(t$139349);
            
            //#line 448 "x10/regionarray/Array.x10"
            if (t$139350) {
                
                //#line 449 "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError((long)(i0));
            }
            
            //#line 451 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139352 = ((x10.core.Rail)(this.raw));
            
            //#line 451 "x10/regionarray/Array.x10"
            final long t$139351 = this.layout_min0;
            
            //#line 451 "x10/regionarray/Array.x10"
            final long t$139353 = ((i0) - (((long)(t$139351))));
            
            //#line 451 "x10/regionarray/Array.x10"
            final $T t$139354 = (($T)(((x10.core.Rail<$T>)t$139352).$apply$G((long)(t$139353))));
            
            //#line 451 "x10/regionarray/Array.x10"
            return t$139354;
        }
    }
    
    
    //#line 466 "x10/regionarray/Array.x10"
    /**
     * Return the element of this array corresponding to the given pair of indices.
     * Only applies to two-dimensional arrays.
     * Functionally equivalent to indexing the array via a two-dimensional point.
     * 
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @return the element of this array corresponding to the given pair of indices.
     * @see #operator(Point)
     * @see #set(T, Long, Long)
     */
    public $T $apply$G(final long i0, final long i1) {
        
        //#line 467 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$139356 = ((x10.regionarray.Region)(this.region));
        
        //#line 467 "x10/regionarray/Array.x10"
        final boolean t$139357 = t$139356.contains$O((long)(i0), (long)(i1));
        
        //#line 467 "x10/regionarray/Array.x10"
        final boolean t$139358 = !(t$139357);
        
        //#line 467 "x10/regionarray/Array.x10"
        if (t$139358) {
            
            //#line 468 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1));
        }
        
        //#line 470 "x10/regionarray/Array.x10"
        final long t$139359 = this.layout_min0;
        
        //#line 470 "x10/regionarray/Array.x10"
        long offset = ((i0) - (((long)(t$139359))));
        
        //#line 471 "x10/regionarray/Array.x10"
        final long t$139361 = this.layout_stride1;
        
        //#line 471 "x10/regionarray/Array.x10"
        final long t$139362 = ((offset) * (((long)(t$139361))));
        
        //#line 471 "x10/regionarray/Array.x10"
        final long t$139363 = ((t$139362) + (((long)(i1))));
        
        //#line 471 "x10/regionarray/Array.x10"
        final long t$139364 = this.layout_min1;
        
        //#line 471 "x10/regionarray/Array.x10"
        final long t$139365 = ((t$139363) - (((long)(t$139364))));
        
        //#line 471 "x10/regionarray/Array.x10"
        offset = t$139365;
        
        //#line 472 "x10/regionarray/Array.x10"
        final x10.core.Rail t$139366 = ((x10.core.Rail)(this.raw));
        
        //#line 472 "x10/regionarray/Array.x10"
        final $T t$139368 = (($T)(((x10.core.Rail<$T>)t$139366).$apply$G((long)(offset))));
        
        //#line 472 "x10/regionarray/Array.x10"
        return t$139368;
    }
    
    
    //#line 487 "x10/regionarray/Array.x10"
    /**
     * Return the element of this array corresponding to the given triple of indices.
     * Only applies to three-dimensional arrays.
     * Functionally equivalent to indexing the array via a three-dimensional point.
     * 
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @return the element of this array corresponding to the given triple of indices.
     * @see #operator(Point)
     * @see #set(T, Long, Long, Long)
     */
    public $T $apply$G(final long i0, final long i1, final long i2) {
        
        //#line 488 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$139369 = ((x10.regionarray.Region)(this.region));
        
        //#line 488 "x10/regionarray/Array.x10"
        final boolean t$139370 = t$139369.contains$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 488 "x10/regionarray/Array.x10"
        final boolean t$139371 = !(t$139370);
        
        //#line 488 "x10/regionarray/Array.x10"
        if (t$139371) {
            
            //#line 489 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 491 "x10/regionarray/Array.x10"
        final x10.core.Rail t$139387 = ((x10.core.Rail)(this.raw));
        
        //#line 491 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$138712 = ((x10.regionarray.Array)(this));
        
        //#line 1300 . "x10/regionarray/Array.x10"
        final long t$139372 = ((x10.regionarray.Array<$T>)this$138712).layout_min0;
        
        //#line 1300 . "x10/regionarray/Array.x10"
        long offset$138711 = ((i0) - (((long)(t$139372))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$139374 = ((x10.regionarray.Array<$T>)this$138712).layout_stride1;
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$139375 = ((offset$138711) * (((long)(t$139374))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$139376 = ((t$139375) + (((long)(i1))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$139377 = ((x10.regionarray.Array<$T>)this$138712).layout_min1;
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$139378 = ((t$139376) - (((long)(t$139377))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        offset$138711 = t$139378;
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$139379 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138712).layout));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$139381 = ((long[])t$139379.value)[(int)0L];
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$139382 = ((offset$138711) * (((long)(t$139381))));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$139384 = ((t$139382) + (((long)(i2))));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$139383 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138712).layout));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$139385 = ((long[])t$139383.value)[(int)1L];
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$139386 = ((t$139384) - (((long)(t$139385))));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        offset$138711 = t$139386;
        
        //#line 491 "x10/regionarray/Array.x10"
        final $T t$139389 = (($T)(((x10.core.Rail<$T>)t$139387).$apply$G((long)(offset$138711))));
        
        //#line 491 "x10/regionarray/Array.x10"
        return t$139389;
    }
    
    
    //#line 507 "x10/regionarray/Array.x10"
    /**
     * Return the element of this array corresponding to the given quartet of indices.
     * Only applies to four-dimensional arrays.
     * Functionally equivalent to indexing the array via a four-dimensional point.
     * 
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @param i3 the given index in the fourth dimension
     * @return the element of this array corresponding to the given quartet of indices.
     * @see #operator(Point)
     * @see #set(T, Long, Long, Long, Long)
     */
    public $T $apply$G(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 508 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$139390 = ((x10.regionarray.Region)(this.region));
        
        //#line 508 "x10/regionarray/Array.x10"
        final boolean t$139391 = t$139390.contains$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 508 "x10/regionarray/Array.x10"
        final boolean t$139392 = !(t$139391);
        
        //#line 508 "x10/regionarray/Array.x10"
        if (t$139392) {
            
            //#line 509 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        }
        
        //#line 511 "x10/regionarray/Array.x10"
        final x10.core.Rail t$139416 = ((x10.core.Rail)(this.raw));
        
        //#line 511 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$138719 = ((x10.regionarray.Array)(this));
        
        //#line 1307 . "x10/regionarray/Array.x10"
        final long t$139393 = ((x10.regionarray.Array<$T>)this$138719).layout_min0;
        
        //#line 1307 . "x10/regionarray/Array.x10"
        long offset$138718 = ((i0) - (((long)(t$139393))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$139395 = ((x10.regionarray.Array<$T>)this$138719).layout_stride1;
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$139396 = ((offset$138718) * (((long)(t$139395))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$139397 = ((t$139396) + (((long)(i1))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$139398 = ((x10.regionarray.Array<$T>)this$138719).layout_min1;
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$139399 = ((t$139397) - (((long)(t$139398))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        offset$138718 = t$139399;
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$139400 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138719).layout));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$139402 = ((long[])t$139400.value)[(int)0L];
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$139403 = ((offset$138718) * (((long)(t$139402))));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$139405 = ((t$139403) + (((long)(i2))));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$139404 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138719).layout));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$139406 = ((long[])t$139404.value)[(int)1L];
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$139407 = ((t$139405) - (((long)(t$139406))));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        offset$138718 = t$139407;
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$139408 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138719).layout));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$139410 = ((long[])t$139408.value)[(int)2L];
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$139411 = ((offset$138718) * (((long)(t$139410))));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$139413 = ((t$139411) + (((long)(i3))));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$139412 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138719).layout));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$139414 = ((long[])t$139412.value)[(int)3L];
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$139415 = ((t$139413) - (((long)(t$139414))));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        offset$138718 = t$139415;
        
        //#line 511 "x10/regionarray/Array.x10"
        final $T t$139418 = (($T)(((x10.core.Rail<$T>)t$139416).$apply$G((long)(offset$138718))));
        
        //#line 511 "x10/regionarray/Array.x10"
        return t$139418;
    }
    
    
    //#line 523 "x10/regionarray/Array.x10"
    /**
     * Return the element of this array corresponding to the given point.
     * The rank of the given point has to be the same as the rank of this array.
     * 
     * @param pt the given point
     * @return the element of this array corresponding to the given point.
     * @see #operator(Long)
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point pt) {
        
        //#line 524 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$139419 = ((x10.regionarray.Region)(this.region));
        
        //#line 524 "x10/regionarray/Array.x10"
        final boolean t$139420 = t$139419.contains$O(((x10.lang.Point)(pt)));
        
        //#line 524 "x10/regionarray/Array.x10"
        final boolean t$139421 = !(t$139420);
        
        //#line 524 "x10/regionarray/Array.x10"
        if (t$139421) {
            
            //#line 525 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(pt)));
        }
        
        //#line 527 "x10/regionarray/Array.x10"
        final x10.core.Rail t$139454 = ((x10.core.Rail)(this.raw));
        
        //#line 527 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$138727 = ((x10.regionarray.Array)(this));
        
        //#line 1315 . "x10/regionarray/Array.x10"
        final long t$139422 = ((long)(((int)(0))));
        
        //#line 1315 . "x10/regionarray/Array.x10"
        final long t$139423 = pt.$apply$O((long)(t$139422));
        
        //#line 1315 . "x10/regionarray/Array.x10"
        final long t$139424 = ((x10.regionarray.Array<$T>)this$138727).layout_min0;
        
        //#line 1315 . "x10/regionarray/Array.x10"
        long offset$138722 = ((t$139423) - (((long)(t$139424))));
        
        //#line 1316 . "x10/regionarray/Array.x10"
        final long t$139425 = pt.rank;
        
        //#line 1316 . "x10/regionarray/Array.x10"
        final boolean t$139453 = ((t$139425) > (((long)(1L))));
        
        //#line 1316 . "x10/regionarray/Array.x10"
        if (t$139453) {
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$139427 = ((x10.regionarray.Array<$T>)this$138727).layout_stride1;
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$139428 = ((offset$138722) * (((long)(t$139427))));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$139429 = pt.$apply$O((long)(1L));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$139430 = ((t$139428) + (((long)(t$139429))));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$139431 = ((x10.regionarray.Array<$T>)this$138727).layout_min1;
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$139432 = ((t$139430) - (((long)(t$139431))));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            offset$138722 = t$139432;
            
            //#line 1318 . "x10/regionarray/Array.x10"
            final long t$141193 = pt.rank;
            
            //#line 1318 . "x10/regionarray/Array.x10"
            final long i$138093max$141194 = ((t$141193) - (((long)(1L))));
            
            //#line 1318 . "x10/regionarray/Array.x10"
            long i$141190 = 2L;
            
            //#line 1318 . "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1318 . "x10/regionarray/Array.x10"
                final boolean t$141192 = ((i$141190) <= (((long)(i$138093max$141194))));
                
                //#line 1318 . "x10/regionarray/Array.x10"
                if (!(t$141192)) {
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141174 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138727).layout));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141175 = ((i$141190) - (((long)(2L))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141176 = ((2L) * (((long)(t$141175))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141177 = ((long[])t$141174.value)[(int)t$141176];
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141178 = ((offset$138722) * (((long)(t$141177))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141179 = pt.$apply$O((long)(i$141190));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141180 = ((t$141178) + (((long)(t$141179))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141181 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138727).layout));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141182 = ((i$141190) - (((long)(2L))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141183 = ((2L) * (((long)(t$141182))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141184 = ((t$141183) + (((long)(1L))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141185 = ((long[])t$141181.value)[(int)t$141184];
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141186 = ((t$141180) - (((long)(t$141185))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                offset$138722 = t$141186;
                
                //#line 1318 . "x10/regionarray/Array.x10"
                final long t$141189 = ((i$141190) + (((long)(1L))));
                
                //#line 1318 . "x10/regionarray/Array.x10"
                i$141190 = t$141189;
            }
        }
        
        //#line 527 "x10/regionarray/Array.x10"
        final $T t$139456 = (($T)(((x10.core.Rail<$T>)t$139454).$apply$G((long)(offset$138722))));
        
        //#line 527 "x10/regionarray/Array.x10"
        return t$139456;
    }
    
    
    //#line 543 "x10/regionarray/Array.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * Only applies to one-dimensional arrays.
     * Functionally equivalent to setting the array via a one-dimensional point.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long)
     * @see #set(T, Point)
     */
    public $T $set__1x10$regionarray$Array$$T$G(final long i0, final $T v) {
        
        //#line 545 "x10/regionarray/Array.x10"
        final boolean t$139464 = this.rail;
        
        //#line 545 "x10/regionarray/Array.x10"
        if (t$139464) {
            
            //#line 547 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139457 = ((x10.core.Rail)(this.raw));
            
            //#line 547 "x10/regionarray/Array.x10"
            ((x10.core.Rail<$T>)t$139457).$set__1x10$lang$Rail$$T$G((long)(i0), (($T)(v)));
        } else {
            
            //#line 549 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$139458 = ((x10.regionarray.Region)(this.region));
            
            //#line 549 "x10/regionarray/Array.x10"
            final boolean t$139459 = t$139458.contains$O((long)(i0));
            
            //#line 549 "x10/regionarray/Array.x10"
            final boolean t$139460 = !(t$139459);
            
            //#line 549 "x10/regionarray/Array.x10"
            if (t$139460) {
                
                //#line 550 "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError((long)(i0));
            }
            
            //#line 552 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139462 = ((x10.core.Rail)(this.raw));
            
            //#line 552 "x10/regionarray/Array.x10"
            final long t$139461 = this.layout_min0;
            
            //#line 552 "x10/regionarray/Array.x10"
            final long t$139463 = ((i0) - (((long)(t$139461))));
            
            //#line 552 "x10/regionarray/Array.x10"
            ((x10.core.Rail<$T>)t$139462).$set__1x10$lang$Rail$$T$G((long)(t$139463), (($T)(v)));
        }
        
        //#line 554 "x10/regionarray/Array.x10"
        return v;
    }
    
    
    //#line 570 "x10/regionarray/Array.x10"
    /**
     * Set the element of this array corresponding to the given pair of indices to the given value.
     * Return the new value of the element.
     * Only applies to two-dimensional arrays.
     * Functionally equivalent to setting the array via a two-dimensional point.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @return the new value of the element of this array corresponding to the given pair of indices.
     * @see #operator(Long, Long)
     * @see #set(T, Point)
     */
    public $T $set__2x10$regionarray$Array$$T$G(final long i0, final long i1, final $T v) {
        
        //#line 571 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$139465 = ((x10.regionarray.Region)(this.region));
        
        //#line 571 "x10/regionarray/Array.x10"
        final boolean t$139466 = t$139465.contains$O((long)(i0), (long)(i1));
        
        //#line 571 "x10/regionarray/Array.x10"
        final boolean t$139467 = !(t$139466);
        
        //#line 571 "x10/regionarray/Array.x10"
        if (t$139467) {
            
            //#line 572 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1));
        }
        
        //#line 574 "x10/regionarray/Array.x10"
        final long t$139468 = this.layout_min0;
        
        //#line 574 "x10/regionarray/Array.x10"
        long offset = ((i0) - (((long)(t$139468))));
        
        //#line 575 "x10/regionarray/Array.x10"
        final long t$139470 = this.layout_stride1;
        
        //#line 575 "x10/regionarray/Array.x10"
        final long t$139471 = ((offset) * (((long)(t$139470))));
        
        //#line 575 "x10/regionarray/Array.x10"
        final long t$139472 = ((t$139471) + (((long)(i1))));
        
        //#line 575 "x10/regionarray/Array.x10"
        final long t$139473 = this.layout_min1;
        
        //#line 575 "x10/regionarray/Array.x10"
        final long t$139474 = ((t$139472) - (((long)(t$139473))));
        
        //#line 575 "x10/regionarray/Array.x10"
        offset = t$139474;
        
        //#line 576 "x10/regionarray/Array.x10"
        final x10.core.Rail t$139475 = ((x10.core.Rail)(this.raw));
        
        //#line 576 "x10/regionarray/Array.x10"
        ((x10.core.Rail<$T>)t$139475).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 577 "x10/regionarray/Array.x10"
        return v;
    }
    
    
    //#line 594 "x10/regionarray/Array.x10"
    /**
     * Set the element of this array corresponding to the given triple of indices to the given value.
     * Return the new value of the element.
     * Only applies to three-dimensional arrays.
     * Functionally equivalent to setting the array via a three-dimensional point.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @return the new value of the element of this array corresponding to the given triple of indices.
     * @see #operator(Long, Long, Long)
     * @see #set(T, Point)
     */
    public $T $set__3x10$regionarray$Array$$T$G(final long i0, final long i1, final long i2, final $T v) {
        
        //#line 595 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$139477 = ((x10.regionarray.Region)(this.region));
        
        //#line 595 "x10/regionarray/Array.x10"
        final boolean t$139478 = t$139477.contains$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 595 "x10/regionarray/Array.x10"
        final boolean t$139479 = !(t$139478);
        
        //#line 595 "x10/regionarray/Array.x10"
        if (t$139479) {
            
            //#line 596 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 598 "x10/regionarray/Array.x10"
        final x10.core.Rail t$139495 = ((x10.core.Rail)(this.raw));
        
        //#line 598 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$138733 = ((x10.regionarray.Array)(this));
        
        //#line 1300 . "x10/regionarray/Array.x10"
        final long t$139480 = ((x10.regionarray.Array<$T>)this$138733).layout_min0;
        
        //#line 1300 . "x10/regionarray/Array.x10"
        long offset$138732 = ((i0) - (((long)(t$139480))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$139482 = ((x10.regionarray.Array<$T>)this$138733).layout_stride1;
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$139483 = ((offset$138732) * (((long)(t$139482))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$139484 = ((t$139483) + (((long)(i1))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$139485 = ((x10.regionarray.Array<$T>)this$138733).layout_min1;
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$139486 = ((t$139484) - (((long)(t$139485))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        offset$138732 = t$139486;
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$139487 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138733).layout));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$139489 = ((long[])t$139487.value)[(int)0L];
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$139490 = ((offset$138732) * (((long)(t$139489))));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$139492 = ((t$139490) + (((long)(i2))));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$139491 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138733).layout));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$139493 = ((long[])t$139491.value)[(int)1L];
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$139494 = ((t$139492) - (((long)(t$139493))));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        offset$138732 = t$139494;
        
        //#line 598 "x10/regionarray/Array.x10"
        ((x10.core.Rail<$T>)t$139495).$set__1x10$lang$Rail$$T$G((long)(offset$138732), (($T)(v)));
        
        //#line 599 "x10/regionarray/Array.x10"
        return v;
    }
    
    
    //#line 617 "x10/regionarray/Array.x10"
    /**
     * Set the element of this array corresponding to the given quartet of indices to the given value.
     * Return the new value of the element.
     * Only applies to four-dimensional arrays.
     * Functionally equivalent to setting the array via a four-dimensional point.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @param i3 the given index in the fourth dimension
     * @return the new value of the element of this array corresponding to the given quartet of indices.
     * @see #operator(Long, Long, Long, Long)
     * @see #set(T, Point)
     */
    public $T $set__4x10$regionarray$Array$$T$G(final long i0, final long i1, final long i2, final long i3, final $T v) {
        
        //#line 618 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$139497 = ((x10.regionarray.Region)(this.region));
        
        //#line 618 "x10/regionarray/Array.x10"
        final boolean t$139498 = t$139497.contains$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 618 "x10/regionarray/Array.x10"
        final boolean t$139499 = !(t$139498);
        
        //#line 618 "x10/regionarray/Array.x10"
        if (t$139499) {
            
            //#line 619 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        }
        
        //#line 621 "x10/regionarray/Array.x10"
        final x10.core.Rail t$139523 = ((x10.core.Rail)(this.raw));
        
        //#line 621 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$138740 = ((x10.regionarray.Array)(this));
        
        //#line 1307 . "x10/regionarray/Array.x10"
        final long t$139500 = ((x10.regionarray.Array<$T>)this$138740).layout_min0;
        
        //#line 1307 . "x10/regionarray/Array.x10"
        long offset$138739 = ((i0) - (((long)(t$139500))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$139502 = ((x10.regionarray.Array<$T>)this$138740).layout_stride1;
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$139503 = ((offset$138739) * (((long)(t$139502))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$139504 = ((t$139503) + (((long)(i1))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$139505 = ((x10.regionarray.Array<$T>)this$138740).layout_min1;
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$139506 = ((t$139504) - (((long)(t$139505))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        offset$138739 = t$139506;
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$139507 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138740).layout));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$139509 = ((long[])t$139507.value)[(int)0L];
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$139510 = ((offset$138739) * (((long)(t$139509))));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$139512 = ((t$139510) + (((long)(i2))));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$139511 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138740).layout));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$139513 = ((long[])t$139511.value)[(int)1L];
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$139514 = ((t$139512) - (((long)(t$139513))));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        offset$138739 = t$139514;
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$139515 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138740).layout));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$139517 = ((long[])t$139515.value)[(int)2L];
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$139518 = ((offset$138739) * (((long)(t$139517))));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$139520 = ((t$139518) + (((long)(i3))));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$139519 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138740).layout));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$139521 = ((long[])t$139519.value)[(int)3L];
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$139522 = ((t$139520) - (((long)(t$139521))));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        offset$138739 = t$139522;
        
        //#line 621 "x10/regionarray/Array.x10"
        ((x10.core.Rail<$T>)t$139523).$set__1x10$lang$Rail$$T$G((long)(offset$138739), (($T)(v)));
        
        //#line 622 "x10/regionarray/Array.x10"
        return v;
    }
    
    
    //#line 636 "x10/regionarray/Array.x10"
    /**
     * Set the element of this array corresponding to the given point to the given value.
     * Return the new value of the element.
     * The rank of the given point has to be the same as the rank of this array.
     * 
     * @param v the given value
     * @param pt the given point
     * @return the new value of the element of this array corresponding to the given point.
     * @see #operator(Point)
     * @see #set(T, Long)
     */
    public $T $set__1x10$regionarray$Array$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 637 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$139525 = ((x10.regionarray.Region)(this.region));
        
        //#line 637 "x10/regionarray/Array.x10"
        final boolean t$139526 = t$139525.contains$O(((x10.lang.Point)(p)));
        
        //#line 637 "x10/regionarray/Array.x10"
        final boolean t$139527 = !(t$139526);
        
        //#line 637 "x10/regionarray/Array.x10"
        if (t$139527) {
            
            //#line 638 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p)));
        }
        
        //#line 640 "x10/regionarray/Array.x10"
        final x10.core.Rail t$139560 = ((x10.core.Rail)(this.raw));
        
        //#line 640 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$138748 = ((x10.regionarray.Array)(this));
        
        //#line 1315 . "x10/regionarray/Array.x10"
        final long t$139528 = ((long)(((int)(0))));
        
        //#line 1315 . "x10/regionarray/Array.x10"
        final long t$139529 = p.$apply$O((long)(t$139528));
        
        //#line 1315 . "x10/regionarray/Array.x10"
        final long t$139530 = ((x10.regionarray.Array<$T>)this$138748).layout_min0;
        
        //#line 1315 . "x10/regionarray/Array.x10"
        long offset$138743 = ((t$139529) - (((long)(t$139530))));
        
        //#line 1316 . "x10/regionarray/Array.x10"
        final long t$139531 = p.rank;
        
        //#line 1316 . "x10/regionarray/Array.x10"
        final boolean t$139559 = ((t$139531) > (((long)(1L))));
        
        //#line 1316 . "x10/regionarray/Array.x10"
        if (t$139559) {
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$139533 = ((x10.regionarray.Array<$T>)this$138748).layout_stride1;
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$139534 = ((offset$138743) * (((long)(t$139533))));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$139535 = p.$apply$O((long)(1L));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$139536 = ((t$139534) + (((long)(t$139535))));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$139537 = ((x10.regionarray.Array<$T>)this$138748).layout_min1;
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$139538 = ((t$139536) - (((long)(t$139537))));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            offset$138743 = t$139538;
            
            //#line 1318 . "x10/regionarray/Array.x10"
            final long t$141215 = p.rank;
            
            //#line 1318 . "x10/regionarray/Array.x10"
            final long i$138093max$141216 = ((t$141215) - (((long)(1L))));
            
            //#line 1318 . "x10/regionarray/Array.x10"
            long i$141212 = 2L;
            
            //#line 1318 . "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1318 . "x10/regionarray/Array.x10"
                final boolean t$141214 = ((i$141212) <= (((long)(i$138093max$141216))));
                
                //#line 1318 . "x10/regionarray/Array.x10"
                if (!(t$141214)) {
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141196 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138748).layout));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141197 = ((i$141212) - (((long)(2L))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141198 = ((2L) * (((long)(t$141197))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141199 = ((long[])t$141196.value)[(int)t$141198];
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141200 = ((offset$138743) * (((long)(t$141199))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141201 = p.$apply$O((long)(i$141212));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141202 = ((t$141200) + (((long)(t$141201))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141203 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138748).layout));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141204 = ((i$141212) - (((long)(2L))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141205 = ((2L) * (((long)(t$141204))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141206 = ((t$141205) + (((long)(1L))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141207 = ((long[])t$141203.value)[(int)t$141206];
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141208 = ((t$141202) - (((long)(t$141207))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                offset$138743 = t$141208;
                
                //#line 1318 . "x10/regionarray/Array.x10"
                final long t$141211 = ((i$141212) + (((long)(1L))));
                
                //#line 1318 . "x10/regionarray/Array.x10"
                i$141212 = t$141211;
            }
        }
        
        //#line 640 "x10/regionarray/Array.x10"
        ((x10.core.Rail<$T>)t$139560).$set__1x10$lang$Rail$$T$G((long)(offset$138743), (($T)(v)));
        
        //#line 641 "x10/regionarray/Array.x10"
        return v;
    }
    
    
    //#line 650 "x10/regionarray/Array.x10"
    /**
     * Fill all elements of the array to contain the argument value.
     * 
     * @param v the value with which to fill the array
     */
    public void fill__0x10$regionarray$Array$$T(final $T v) {
        
        //#line 651 "x10/regionarray/Array.x10"
        final boolean t$139600 = this.rect;
        
        //#line 651 "x10/regionarray/Array.x10"
        if (t$139600) {
            
            //#line 654 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139562 = ((x10.core.Rail)(this.raw));
            
            //#line 654 "x10/regionarray/Array.x10"
            ((x10.core.Rail<$T>)t$139562).fill__0x10$lang$Rail$$T((($T)(v)));
        } else {
            
            //#line 656 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$139564 = ((x10.regionarray.Region)(this.region));
            
            //#line 656 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$137944 = t$139564.iterator();
            
            //#line 656 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 656 "x10/regionarray/Array.x10"
                final boolean t$139599 = ((x10.lang.Iterator<x10.lang.Point>)p$137944).hasNext$O();
                
                //#line 656 "x10/regionarray/Array.x10"
                if (!(t$139599)) {
                    
                    //#line 656 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 656 "x10/regionarray/Array.x10"
                final x10.lang.Point p$141239 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$137944).next$G()));
                
                //#line 657 "x10/regionarray/Array.x10"
                final x10.core.Rail t$141240 = ((x10.core.Rail)(this.raw));
                
                //#line 657 "x10/regionarray/Array.x10"
                final x10.regionarray.Array this$141241 = ((x10.regionarray.Array)(this));
                
                //#line 1315 . "x10/regionarray/Array.x10"
                final long t$141243 = ((long)(((int)(0))));
                
                //#line 1315 . "x10/regionarray/Array.x10"
                final long t$141244 = p$141239.$apply$O((long)(t$141243));
                
                //#line 1315 . "x10/regionarray/Array.x10"
                final long t$141245 = ((x10.regionarray.Array<$T>)this$141241).layout_min0;
                
                //#line 1315 . "x10/regionarray/Array.x10"
                long offset$141246 = ((t$141244) - (((long)(t$141245))));
                
                //#line 1316 . "x10/regionarray/Array.x10"
                final long t$141247 = p$141239.rank;
                
                //#line 1316 . "x10/regionarray/Array.x10"
                final boolean t$141248 = ((t$141247) > (((long)(1L))));
                
                //#line 1316 . "x10/regionarray/Array.x10"
                if (t$141248) {
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141250 = ((x10.regionarray.Array<$T>)this$141241).layout_stride1;
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141251 = ((offset$141246) * (((long)(t$141250))));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141252 = p$141239.$apply$O((long)(1L));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141253 = ((t$141251) + (((long)(t$141252))));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141254 = ((x10.regionarray.Array<$T>)this$141241).layout_min1;
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141255 = ((t$141253) - (((long)(t$141254))));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    offset$141246 = t$141255;
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    final long t$141237 = p$141239.rank;
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    final long i$138093max$141238 = ((t$141237) - (((long)(1L))));
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    long i$141234 = 2L;
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        final boolean t$141236 = ((i$141234) <= (((long)(i$138093max$141238))));
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        if (!(t$141236)) {
                            
                            //#line 1318 . "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141218 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141241).layout));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141219 = ((i$141234) - (((long)(2L))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141220 = ((2L) * (((long)(t$141219))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141221 = ((long[])t$141218.value)[(int)t$141220];
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141222 = ((offset$141246) * (((long)(t$141221))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141223 = p$141239.$apply$O((long)(i$141234));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141224 = ((t$141222) + (((long)(t$141223))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141225 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141241).layout));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141226 = ((i$141234) - (((long)(2L))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141227 = ((2L) * (((long)(t$141226))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141228 = ((t$141227) + (((long)(1L))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141229 = ((long[])t$141225.value)[(int)t$141228];
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141230 = ((t$141224) - (((long)(t$141229))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        offset$141246 = t$141230;
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        final long t$141233 = ((i$141234) + (((long)(1L))));
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        i$141234 = t$141233;
                    }
                }
                
                //#line 657 "x10/regionarray/Array.x10"
                ((x10.core.Rail<$T>)t$141240).$set__1x10$lang$Rail$$T$G((long)(offset$141246), (($T)(v)));
            }
        }
    }
    
    
    //#line 667 "x10/regionarray/Array.x10"
    /**
     * Fill all elements of the array with the zero value of type T 
     * @see x10.lang.Zero.get[T]()
     */
    public void clear() {
        
        //#line 668 "x10/regionarray/Array.x10"
        final x10.core.Rail t$139602 = ((x10.core.Rail)(this.raw));
        
        //#line 668 "x10/regionarray/Array.x10"
        final x10.core.Rail t$139601 = ((x10.core.Rail)(this.raw));
        
        //#line 668 "x10/regionarray/Array.x10"
        final long t$139603 = ((x10.core.Rail<$T>)t$139601).size;
        
        //#line 668 "x10/regionarray/Array.x10"
        ((x10.core.Rail<$T>)t$139602).clear((long)(0L), (long)(t$139603));
    }
    
    
    //#line 684 "x10/regionarray/Array.x10"
    /**
     * Map the function onto the elements of this array
     * constructing a new result array such that for all points <code>p</code>
     * in <code>this.region</code>,
     * <code>result(p) == op(this(p))</code>.<p>
     * 
     * @param op the function to apply to each element of the array
     * @return a new array with the same region as this array where <code>result(p) == op(this(p))</code>
     * 
     * @see #reduce((U,T)=>U,U)
     * @see #scan((U,T)=>U,U)
     */
    public <$U>x10.regionarray.Array map__0$1x10$regionarray$Array$$T$3x10$regionarray$Array$$U$2(final x10.rtt.Type $U, final x10.core.fun.Fun_0_1 op) {
        
        //#line 685 "x10/regionarray/Array.x10"
        final x10.regionarray.Array alloc$137861 = ((x10.regionarray.Array)(new x10.regionarray.Array<$U>((java.lang.System[]) null, $U)));
        
        //#line 685 "x10/regionarray/Array.x10"
        final x10.regionarray.Region reg$138768 = ((x10.regionarray.Region)(this.region));
        
        //#line 174 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$141341 = ((x10.regionarray.Region)
                                                  reg$138768);
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$141342 = ((t$141341) != (null));
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$141343 = !(t$141342);
        
        //#line 174 . "x10/regionarray/Array.x10"
        if (t$141343) {
            
            //#line 174 . "x10/regionarray/Array.x10"
            final boolean t$141344 = true;
            
            //#line 174 . "x10/regionarray/Array.x10"
            if (t$141344) {
                
                //#line 174 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141345 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 174 . "x10/regionarray/Array.x10"
                throw t$141345;
            }
        }
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137861).region = ((x10.regionarray.Region)(t$141341));
        
        //#line 174 . "x10/regionarray/Array.x10"
        final long t$141346 = reg$138768.rank;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137861).rank = t$141346;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$141347 = reg$138768.rect;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137861).rect = t$141347;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$141348 = reg$138768.zeroBased;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137861).zeroBased = t$141348;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$141349 = reg$138768.rail;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137861).rail = t$141349;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final long t$141350 = reg$138768.size$O();
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137861).size = t$141350;
        
        //#line 175 . "x10/regionarray/Array.x10"
        final x10.regionarray.Array.LayoutHelper crh$141353 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
        
        //#line 175 . "x10/regionarray/Array.x10"
        crh$141353.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg$138768)));
        
        //#line 176 . "x10/regionarray/Array.x10"
        final long t$141354 = crh$141353.min0;
        
        //#line 176 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137861).layout_min0 = t$141354;
        
        //#line 177 . "x10/regionarray/Array.x10"
        final long t$141355 = crh$141353.stride1;
        
        //#line 177 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137861).layout_stride1 = t$141355;
        
        //#line 178 . "x10/regionarray/Array.x10"
        final long t$141356 = crh$141353.min1;
        
        //#line 178 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137861).layout_min1 = t$141356;
        
        //#line 179 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$141357 = ((x10.core.Rail)(crh$141353.layout));
        
        //#line 179 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137861).layout = ((x10.core.Rail)(t$141357));
        
        //#line 180 . "x10/regionarray/Array.x10"
        final long n$141358 = crh$141353.size;
        
        //#line 181 . "x10/regionarray/Array.x10"
        final x10.core.Rail r$141359 = ((x10.core.Rail)(x10.core.Rail.<$U>makeUnsafe($U, ((long)(n$141358)), false)));
        
        //#line 182 . "x10/regionarray/Array.x10"
        final x10.lang.Iterator p$141351 = reg$138768.iterator();
        
        //#line 182 . "x10/regionarray/Array.x10"
        for (;
             true;
             ) {
            
            //#line 182 . "x10/regionarray/Array.x10"
            final boolean t$141352 = ((x10.lang.Iterator<x10.lang.Point>)p$141351).hasNext$O();
            
            //#line 182 . "x10/regionarray/Array.x10"
            if (!(t$141352)) {
                
                //#line 182 . "x10/regionarray/Array.x10"
                break;
            }
            
            //#line 182 . "x10/regionarray/Array.x10"
            final x10.lang.Point p$141301 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$141351).next$G()));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141303 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141304 = p$141301.$apply$O((long)(t$141303));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141305 = ((x10.regionarray.Array<$U>)alloc$137861).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$141306 = ((t$141304) - (((long)(t$141305))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$141307 = p$141301.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$141308 = ((t$141307) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$141308) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141310 = ((x10.regionarray.Array<$U>)alloc$137861).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141311 = ((offset$141306) * (((long)(t$141310))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141312 = p$141301.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141313 = ((t$141311) + (((long)(t$141312))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141314 = ((x10.regionarray.Array<$U>)alloc$137861).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141315 = ((t$141313) - (((long)(t$141314))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$141306 = t$141315;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$141277 = p$141301.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138093max$141278 = ((t$141277) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$141274 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$141276 = ((i$141274) <= (((long)(i$138093max$141278))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$141276)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141258 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)alloc$137861).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141259 = ((i$141274) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141260 = ((2L) * (((long)(t$141259))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141261 = ((long[])t$141258.value)[(int)t$141260];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141262 = ((offset$141306) * (((long)(t$141261))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141263 = p$141301.$apply$O((long)(i$141274));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141264 = ((t$141262) + (((long)(t$141263))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141265 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)alloc$137861).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141266 = ((i$141274) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141267 = ((2L) * (((long)(t$141266))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141268 = ((t$141267) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141269 = ((long[])t$141265.value)[(int)t$141268];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141270 = ((t$141264) - (((long)(t$141269))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$141306 = t$141270;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141273 = ((i$141274) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$141274 = t$141273;
                }
            }
            
            //#line 685 .. "x10/regionarray/Array.x10"
            final x10.regionarray.Array this$141318 = ((x10.regionarray.Array)(this));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141320 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$141318).region));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final boolean t$141321 = t$141320.contains$O(((x10.lang.Point)(p$141301)));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final boolean t$141322 = !(t$141321);
            
            //#line 524 ... "x10/regionarray/Array.x10"
            if (t$141322) {
                
                //#line 525 ... "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141301)));
            }
            
            //#line 527 ... "x10/regionarray/Array.x10"
            final x10.core.Rail t$141323 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141318).raw));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$141325 = ((long)(((int)(0))));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$141326 = p$141301.$apply$O((long)(t$141325));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$141327 = ((x10.regionarray.Array<$T>)this$141318).layout_min0;
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            long offset$141328 = ((t$141326) - (((long)(t$141327))));
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            final long t$141329 = p$141301.rank;
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            final boolean t$141330 = ((t$141329) > (((long)(1L))));
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            if (t$141330) {
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141332 = ((x10.regionarray.Array<$T>)this$141318).layout_stride1;
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141333 = ((offset$141328) * (((long)(t$141332))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141334 = p$141301.$apply$O((long)(1L));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141335 = ((t$141333) + (((long)(t$141334))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141336 = ((x10.regionarray.Array<$T>)this$141318).layout_min1;
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141337 = ((t$141335) - (((long)(t$141336))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                offset$141328 = t$141337;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                final long t$141299 = p$141301.rank;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                final long i$138093max$141300 = ((t$141299) - (((long)(1L))));
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                long i$141296 = 2L;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    final boolean t$141298 = ((i$141296) <= (((long)(i$138093max$141300))));
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    if (!(t$141298)) {
                        
                        //#line 1318 .... "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141280 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141318).layout));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141281 = ((i$141296) - (((long)(2L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141282 = ((2L) * (((long)(t$141281))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141283 = ((long[])t$141280.value)[(int)t$141282];
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141284 = ((offset$141328) * (((long)(t$141283))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141285 = p$141301.$apply$O((long)(i$141296));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141286 = ((t$141284) + (((long)(t$141285))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141287 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141318).layout));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141288 = ((i$141296) - (((long)(2L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141289 = ((2L) * (((long)(t$141288))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141290 = ((t$141289) + (((long)(1L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141291 = ((long[])t$141287.value)[(int)t$141290];
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141292 = ((t$141286) - (((long)(t$141291))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    offset$141328 = t$141292;
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    final long t$141295 = ((i$141296) + (((long)(1L))));
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    i$141296 = t$141295;
                }
            }
            
            //#line 527 ... "x10/regionarray/Array.x10"
            final $T t$141339 = (($T)(((x10.core.Rail<$T>)t$141323).$apply$G((long)(offset$141328))));
            
            //#line 685 .. "x10/regionarray/Array.x10"
            final $U t$141340 = (($U)((($U)
                                        ((x10.core.fun.Fun_0_1<$T,$U>)op).$apply(t$141339, $T))));
            
            //#line 183 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$U>)r$141359).$set__1x10$lang$Rail$$T$G((long)(offset$141306), (($U)(t$141340)));
        }
        
        //#line 185 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137861).raw = ((x10.core.Rail)(r$141359));
        
        //#line 685 "x10/regionarray/Array.x10"
        return alloc$137861;
    }
    
    
    //#line 702 "x10/regionarray/Array.x10"
    /**
     * Map the given function onto the elements of this array
     * storing the results in the dst array such that for all points <code>p</code>
     * in <code>this.region</code>,
     * <code>dst(p) == op(this(p))</code>.<p>
     * 
     * @param dst the destination array for the results of the map operation
     * @param op the function to apply to each element of the array
     * @return dst after applying the map operation.
     * 
     * @see #reduce((U,T)=>U,U)
     * @see #scan((U,T)=>U,U)
     */
    public <$U>x10.regionarray.Array map__0$1x10$regionarray$Array$$U$2__1$1x10$regionarray$Array$$T$3x10$regionarray$Array$$U$2(final x10.rtt.Type $U, final x10.regionarray.Array dst, final x10.core.fun.Fun_0_1 op) {
        
        //#line 704 "x10/regionarray/Array.x10"
        final boolean t$139776 = this.rect;
        
        //#line 704 "x10/regionarray/Array.x10"
        if (t$139776) {
            
            //#line 708 "x10/regionarray/Array.x10"
            final x10.core.Rail src$138794 = ((x10.core.Rail)(this.raw));
            
            //#line 708 "x10/regionarray/Array.x10"
            final x10.core.Rail dst$138795 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).raw));
            
            //#line 180 . "x10/util/RailUtils.x10"
            final long i$97072max$141369 = ((x10.core.Rail<$T>)src$138794).size;
            
            //#line 180 . "x10/util/RailUtils.x10"
            long i$141365 = 0L;
            
            //#line 180 . "x10/util/RailUtils.x10"
            for (;
                 true;
                 ) {
                
                //#line 180 . "x10/util/RailUtils.x10"
                final boolean t$141367 = ((i$141365) < (((long)(i$97072max$141369))));
                
                //#line 180 . "x10/util/RailUtils.x10"
                if (!(t$141367)) {
                    
                    //#line 180 . "x10/util/RailUtils.x10"
                    break;
                }
                
                //#line 181 . "x10/util/RailUtils.x10"
                final $T t$141360 = (($T)(((x10.core.Rail<$T>)src$138794).$apply$G((long)(i$141365))));
                
                //#line 181 . "x10/util/RailUtils.x10"
                final $U t$141361 = (($U)((($U)
                                            ((x10.core.fun.Fun_0_1<$T,$U>)op).$apply(t$141360, $T))));
                
                //#line 181 . "x10/util/RailUtils.x10"
                ((x10.core.Rail<$U>)dst$138795).$set__1x10$lang$Rail$$T$G((long)(i$141365), (($U)(t$141361)));
                
                //#line 180 . "x10/util/RailUtils.x10"
                final long t$141364 = ((i$141365) + (((long)(1L))));
                
                //#line 180 . "x10/util/RailUtils.x10"
                i$141365 = t$141364;
            }
            
            //#line 709 "x10/regionarray/Array.x10"
            return dst;
        } else {
            
            //#line 711 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$139699 = ((x10.regionarray.Region)(this.region));
            
            //#line 711 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$137946 = t$139699.iterator();
            
            //#line 711 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 711 "x10/regionarray/Array.x10"
                final boolean t$139775 = ((x10.lang.Iterator<x10.lang.Point>)p$137946).hasNext$O();
                
                //#line 711 "x10/regionarray/Array.x10"
                if (!(t$139775)) {
                    
                    //#line 711 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 711 "x10/regionarray/Array.x10"
                final x10.lang.Point p$141414 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$137946).next$G()));
                
                //#line 712 "x10/regionarray/Array.x10"
                final x10.regionarray.Array this$141416 = ((x10.regionarray.Array)(this));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$141418 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$141416).region));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$141419 = t$141418.contains$O(((x10.lang.Point)(p$141414)));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$141420 = !(t$141419);
                
                //#line 524 . "x10/regionarray/Array.x10"
                if (t$141420) {
                    
                    //#line 525 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141414)));
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141421 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141416).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141423 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141424 = p$141414.$apply$O((long)(t$141423));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141425 = ((x10.regionarray.Array<$T>)this$141416).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$141426 = ((t$141424) - (((long)(t$141425))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$141427 = p$141414.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$141428 = ((t$141427) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$141428) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141430 = ((x10.regionarray.Array<$T>)this$141416).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141431 = ((offset$141426) * (((long)(t$141430))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141432 = p$141414.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141433 = ((t$141431) + (((long)(t$141432))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141434 = ((x10.regionarray.Array<$T>)this$141416).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141435 = ((t$141433) - (((long)(t$141434))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$141426 = t$141435;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141390 = p$141414.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138093max$141391 = ((t$141390) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$141387 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$141389 = ((i$141387) <= (((long)(i$138093max$141391))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$141389)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141371 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141416).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141372 = ((i$141387) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141373 = ((2L) * (((long)(t$141372))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141374 = ((long[])t$141371.value)[(int)t$141373];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141375 = ((offset$141426) * (((long)(t$141374))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141376 = p$141414.$apply$O((long)(i$141387));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141377 = ((t$141375) + (((long)(t$141376))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141378 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141416).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141379 = ((i$141387) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141380 = ((2L) * (((long)(t$141379))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141381 = ((t$141380) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141382 = ((long[])t$141378.value)[(int)t$141381];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141383 = ((t$141377) - (((long)(t$141382))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$141426 = t$141383;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$141386 = ((i$141387) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$141387 = t$141386;
                    }
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final $T t$141437 = (($T)(((x10.core.Rail<$T>)t$141421).$apply$G((long)(offset$141426))));
                
                //#line 712 "x10/regionarray/Array.x10"
                final $U v$141438 = (($U)((($U)
                                            ((x10.core.fun.Fun_0_1<$T,$U>)op).$apply(t$141437, $T))));
                
                //#line 637 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$141439 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)dst).region));
                
                //#line 637 . "x10/regionarray/Array.x10"
                final boolean t$141440 = t$141439.contains$O(((x10.lang.Point)(p$141414)));
                
                //#line 637 . "x10/regionarray/Array.x10"
                final boolean t$141441 = !(t$141440);
                
                //#line 637 . "x10/regionarray/Array.x10"
                if (t$141441) {
                    
                    //#line 638 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141414)));
                }
                
                //#line 640 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141442 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141444 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141445 = p$141414.$apply$O((long)(t$141444));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141446 = ((x10.regionarray.Array<$U>)dst).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$141447 = ((t$141445) - (((long)(t$141446))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$141448 = p$141414.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$141449 = ((t$141448) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$141449) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141451 = ((x10.regionarray.Array<$U>)dst).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141452 = ((offset$141447) * (((long)(t$141451))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141453 = p$141414.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141454 = ((t$141452) + (((long)(t$141453))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141455 = ((x10.regionarray.Array<$U>)dst).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141456 = ((t$141454) - (((long)(t$141455))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$141447 = t$141456;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141412 = p$141414.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138093max$141413 = ((t$141412) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$141409 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$141411 = ((i$141409) <= (((long)(i$138093max$141413))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$141411)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141393 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141394 = ((i$141409) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141395 = ((2L) * (((long)(t$141394))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141396 = ((long[])t$141393.value)[(int)t$141395];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141397 = ((offset$141447) * (((long)(t$141396))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141398 = p$141414.$apply$O((long)(i$141409));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141399 = ((t$141397) + (((long)(t$141398))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141400 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141401 = ((i$141409) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141402 = ((2L) * (((long)(t$141401))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141403 = ((t$141402) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141404 = ((long[])t$141400.value)[(int)t$141403];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141405 = ((t$141399) - (((long)(t$141404))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$141447 = t$141405;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$141408 = ((i$141409) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$141409 = t$141408;
                    }
                }
                
                //#line 640 . "x10/regionarray/Array.x10"
                ((x10.core.Rail<$U>)t$141442).$set__1x10$lang$Rail$$T$G((long)(offset$141447), (($U)(v$141438)));
            }
        }
        
        //#line 715 "x10/regionarray/Array.x10"
        return dst;
    }
    
    
    //#line 733 "x10/regionarray/Array.x10"
    /**
     * Map the given function onto the elements of this array for the subset
     * of points contained in the filter region such that for all points <code>p</code>
     * in <code>filter</code>,
     * <code>dst(p) == op(this(p))</code>.<p>
     * 
     * @param dst the destination array for the results of the map operation
     * @param filter the region to select the subset of points to include in the map
     * @param op the function to apply to each element of the array
     * @return dst after applying the map operation.
     * 
     * @see #reduce((U,T)=>U,U)
     * @see #scan((U,T)=>U,U)
     */
    public <$U>x10.regionarray.Array map__0$1x10$regionarray$Array$$U$2__2$1x10$regionarray$Array$$T$3x10$regionarray$Array$$U$2(final x10.rtt.Type $U, final x10.regionarray.Array dst, final x10.regionarray.Region filter, final x10.core.fun.Fun_0_1 op) {
        
        //#line 734 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$139777 = ((x10.regionarray.Region)(this.region));
        
        //#line 734 "x10/regionarray/Array.x10"
        final x10.regionarray.Region fregion = ((x10.regionarray.Region)(t$139777.$and(((x10.regionarray.Region)(filter)))));
        
        //#line 735 "x10/regionarray/Array.x10"
        final x10.lang.Iterator p$141546 = fregion.iterator();
        
        //#line 735 "x10/regionarray/Array.x10"
        for (;
             true;
             ) {
            
            //#line 735 "x10/regionarray/Array.x10"
            final boolean t$141547 = ((x10.lang.Iterator<x10.lang.Point>)p$141546).hasNext$O();
            
            //#line 735 "x10/regionarray/Array.x10"
            if (!(t$141547)) {
                
                //#line 735 "x10/regionarray/Array.x10"
                break;
            }
            
            //#line 735 "x10/regionarray/Array.x10"
            final x10.lang.Point p$141502 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$141546).next$G()));
            
            //#line 736 "x10/regionarray/Array.x10"
            final x10.regionarray.Array this$141504 = ((x10.regionarray.Array)(this));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141506 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$141504).region));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$141507 = t$141506.contains$O(((x10.lang.Point)(p$141502)));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$141508 = !(t$141507);
            
            //#line 524 . "x10/regionarray/Array.x10"
            if (t$141508) {
                
                //#line 525 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141502)));
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$141509 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141504).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141511 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141512 = p$141502.$apply$O((long)(t$141511));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141513 = ((x10.regionarray.Array<$T>)this$141504).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$141514 = ((t$141512) - (((long)(t$141513))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$141515 = p$141502.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$141516 = ((t$141515) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$141516) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141518 = ((x10.regionarray.Array<$T>)this$141504).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141519 = ((offset$141514) * (((long)(t$141518))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141520 = p$141502.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141521 = ((t$141519) + (((long)(t$141520))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141522 = ((x10.regionarray.Array<$T>)this$141504).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141523 = ((t$141521) - (((long)(t$141522))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$141514 = t$141523;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$141478 = p$141502.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138093max$141479 = ((t$141478) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$141475 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$141477 = ((i$141475) <= (((long)(i$138093max$141479))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$141477)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141459 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141504).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141460 = ((i$141475) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141461 = ((2L) * (((long)(t$141460))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141462 = ((long[])t$141459.value)[(int)t$141461];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141463 = ((offset$141514) * (((long)(t$141462))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141464 = p$141502.$apply$O((long)(i$141475));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141465 = ((t$141463) + (((long)(t$141464))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141466 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141504).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141467 = ((i$141475) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141468 = ((2L) * (((long)(t$141467))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141469 = ((t$141468) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141470 = ((long[])t$141466.value)[(int)t$141469];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141471 = ((t$141465) - (((long)(t$141470))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$141514 = t$141471;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141474 = ((i$141475) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$141475 = t$141474;
                }
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final $T t$141525 = (($T)(((x10.core.Rail<$T>)t$141509).$apply$G((long)(offset$141514))));
            
            //#line 736 "x10/regionarray/Array.x10"
            final $U v$141526 = (($U)((($U)
                                        ((x10.core.fun.Fun_0_1<$T,$U>)op).$apply(t$141525, $T))));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141527 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)dst).region));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final boolean t$141528 = t$141527.contains$O(((x10.lang.Point)(p$141502)));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final boolean t$141529 = !(t$141528);
            
            //#line 637 . "x10/regionarray/Array.x10"
            if (t$141529) {
                
                //#line 638 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141502)));
            }
            
            //#line 640 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$141530 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141532 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141533 = p$141502.$apply$O((long)(t$141532));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141534 = ((x10.regionarray.Array<$U>)dst).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$141535 = ((t$141533) - (((long)(t$141534))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$141536 = p$141502.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$141537 = ((t$141536) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$141537) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141539 = ((x10.regionarray.Array<$U>)dst).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141540 = ((offset$141535) * (((long)(t$141539))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141541 = p$141502.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141542 = ((t$141540) + (((long)(t$141541))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141543 = ((x10.regionarray.Array<$U>)dst).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141544 = ((t$141542) - (((long)(t$141543))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$141535 = t$141544;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$141500 = p$141502.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138093max$141501 = ((t$141500) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$141497 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$141499 = ((i$141497) <= (((long)(i$138093max$141501))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$141499)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141481 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141482 = ((i$141497) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141483 = ((2L) * (((long)(t$141482))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141484 = ((long[])t$141481.value)[(int)t$141483];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141485 = ((offset$141535) * (((long)(t$141484))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141486 = p$141502.$apply$O((long)(i$141497));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141487 = ((t$141485) + (((long)(t$141486))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141488 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141489 = ((i$141497) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141490 = ((2L) * (((long)(t$141489))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141491 = ((t$141490) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141492 = ((long[])t$141488.value)[(int)t$141491];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141493 = ((t$141487) - (((long)(t$141492))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$141535 = t$141493;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141496 = ((i$141497) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$141497 = t$141496;
                }
            }
            
            //#line 640 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$U>)t$141530).$set__1x10$lang$Rail$$T$G((long)(offset$141535), (($U)(v$141526)));
        }
        
        //#line 738 "x10/regionarray/Array.x10"
        return dst;
    }
    
    
    //#line 754 "x10/regionarray/Array.x10"
    /**
     * Map the given function onto the elements of this array
     * and the other src array, storing the results in a new result array 
     * such that for all points <code>p</code> in <code>this.region</code>,
     * <code>result(p) == op(this(p), src(p))</code>.<p>
     * 
     * @param src the other src array
     * @param op the function to apply to each element of the array
     * @return a new array with the same region as this array containing the result of the map
     * @see #reduce((U,T)=>U,U)
     * @see #scan((U,T)=>U,U)
     */
    public <$S, $U>x10.regionarray.Array map__0$1x10$regionarray$Array$$U$2__1$1x10$regionarray$Array$$T$3x10$regionarray$Array$$U$3x10$regionarray$Array$$S$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.Array src, final x10.core.fun.Fun_0_2 op) {
        
        //#line 755 "x10/regionarray/Array.x10"
        final x10.regionarray.Array alloc$137862 = ((x10.regionarray.Array)(new x10.regionarray.Array<$S>((java.lang.System[]) null, $S)));
        
        //#line 755 "x10/regionarray/Array.x10"
        final x10.regionarray.Region reg$138862 = ((x10.regionarray.Region)(this.region));
        
        //#line 174 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$141675 = ((x10.regionarray.Region)
                                                  reg$138862);
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$141676 = ((t$141675) != (null));
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$141677 = !(t$141676);
        
        //#line 174 . "x10/regionarray/Array.x10"
        if (t$141677) {
            
            //#line 174 . "x10/regionarray/Array.x10"
            final boolean t$141678 = true;
            
            //#line 174 . "x10/regionarray/Array.x10"
            if (t$141678) {
                
                //#line 174 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141679 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 174 . "x10/regionarray/Array.x10"
                throw t$141679;
            }
        }
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$137862).region = ((x10.regionarray.Region)(t$141675));
        
        //#line 174 . "x10/regionarray/Array.x10"
        final long t$141680 = reg$138862.rank;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$137862).rank = t$141680;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$141681 = reg$138862.rect;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$137862).rect = t$141681;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$141682 = reg$138862.zeroBased;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$137862).zeroBased = t$141682;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$141683 = reg$138862.rail;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$137862).rail = t$141683;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final long t$141684 = reg$138862.size$O();
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$137862).size = t$141684;
        
        //#line 175 . "x10/regionarray/Array.x10"
        final x10.regionarray.Array.LayoutHelper crh$141687 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
        
        //#line 175 . "x10/regionarray/Array.x10"
        crh$141687.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg$138862)));
        
        //#line 176 . "x10/regionarray/Array.x10"
        final long t$141688 = crh$141687.min0;
        
        //#line 176 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$137862).layout_min0 = t$141688;
        
        //#line 177 . "x10/regionarray/Array.x10"
        final long t$141689 = crh$141687.stride1;
        
        //#line 177 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$137862).layout_stride1 = t$141689;
        
        //#line 178 . "x10/regionarray/Array.x10"
        final long t$141690 = crh$141687.min1;
        
        //#line 178 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$137862).layout_min1 = t$141690;
        
        //#line 179 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$141691 = ((x10.core.Rail)(crh$141687.layout));
        
        //#line 179 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$137862).layout = ((x10.core.Rail)(t$141691));
        
        //#line 180 . "x10/regionarray/Array.x10"
        final long n$141692 = crh$141687.size;
        
        //#line 181 . "x10/regionarray/Array.x10"
        final x10.core.Rail r$141693 = ((x10.core.Rail)(x10.core.Rail.<$S>makeUnsafe($S, ((long)(n$141692)), false)));
        
        //#line 182 . "x10/regionarray/Array.x10"
        final x10.lang.Iterator p$141685 = reg$138862.iterator();
        
        //#line 182 . "x10/regionarray/Array.x10"
        for (;
             true;
             ) {
            
            //#line 182 . "x10/regionarray/Array.x10"
            final boolean t$141686 = ((x10.lang.Iterator<x10.lang.Point>)p$141685).hasNext$O();
            
            //#line 182 . "x10/regionarray/Array.x10"
            if (!(t$141686)) {
                
                //#line 182 . "x10/regionarray/Array.x10"
                break;
            }
            
            //#line 182 . "x10/regionarray/Array.x10"
            final x10.lang.Point p$141614 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$141685).next$G()));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141616 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141617 = p$141614.$apply$O((long)(t$141616));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141618 = ((x10.regionarray.Array<$S>)alloc$137862).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$141619 = ((t$141617) - (((long)(t$141618))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$141620 = p$141614.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$141621 = ((t$141620) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$141621) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141623 = ((x10.regionarray.Array<$S>)alloc$137862).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141624 = ((offset$141619) * (((long)(t$141623))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141625 = p$141614.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141626 = ((t$141624) + (((long)(t$141625))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141627 = ((x10.regionarray.Array<$S>)alloc$137862).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141628 = ((t$141626) - (((long)(t$141627))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$141619 = t$141628;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$141568 = p$141614.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138093max$141569 = ((t$141568) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$141565 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$141567 = ((i$141565) <= (((long)(i$138093max$141569))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$141567)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141549 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)alloc$137862).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141550 = ((i$141565) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141551 = ((2L) * (((long)(t$141550))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141552 = ((long[])t$141549.value)[(int)t$141551];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141553 = ((offset$141619) * (((long)(t$141552))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141554 = p$141614.$apply$O((long)(i$141565));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141555 = ((t$141553) + (((long)(t$141554))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141556 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)alloc$137862).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141557 = ((i$141565) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141558 = ((2L) * (((long)(t$141557))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141559 = ((t$141558) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141560 = ((long[])t$141556.value)[(int)t$141559];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141561 = ((t$141555) - (((long)(t$141560))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$141619 = t$141561;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141564 = ((i$141565) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$141565 = t$141564;
                }
            }
            
            //#line 755 .. "x10/regionarray/Array.x10"
            final x10.regionarray.Array this$141631 = ((x10.regionarray.Array)(this));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141633 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$141631).region));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final boolean t$141634 = t$141633.contains$O(((x10.lang.Point)(p$141614)));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final boolean t$141635 = !(t$141634);
            
            //#line 524 ... "x10/regionarray/Array.x10"
            if (t$141635) {
                
                //#line 525 ... "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141614)));
            }
            
            //#line 527 ... "x10/regionarray/Array.x10"
            final x10.core.Rail t$141636 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141631).raw));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$141638 = ((long)(((int)(0))));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$141639 = p$141614.$apply$O((long)(t$141638));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$141640 = ((x10.regionarray.Array<$T>)this$141631).layout_min0;
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            long offset$141641 = ((t$141639) - (((long)(t$141640))));
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            final long t$141642 = p$141614.rank;
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            final boolean t$141643 = ((t$141642) > (((long)(1L))));
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            if (t$141643) {
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141645 = ((x10.regionarray.Array<$T>)this$141631).layout_stride1;
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141646 = ((offset$141641) * (((long)(t$141645))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141647 = p$141614.$apply$O((long)(1L));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141648 = ((t$141646) + (((long)(t$141647))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141649 = ((x10.regionarray.Array<$T>)this$141631).layout_min1;
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141650 = ((t$141648) - (((long)(t$141649))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                offset$141641 = t$141650;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                final long t$141590 = p$141614.rank;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                final long i$138093max$141591 = ((t$141590) - (((long)(1L))));
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                long i$141587 = 2L;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    final boolean t$141589 = ((i$141587) <= (((long)(i$138093max$141591))));
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    if (!(t$141589)) {
                        
                        //#line 1318 .... "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141571 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141631).layout));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141572 = ((i$141587) - (((long)(2L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141573 = ((2L) * (((long)(t$141572))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141574 = ((long[])t$141571.value)[(int)t$141573];
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141575 = ((offset$141641) * (((long)(t$141574))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141576 = p$141614.$apply$O((long)(i$141587));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141577 = ((t$141575) + (((long)(t$141576))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141578 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141631).layout));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141579 = ((i$141587) - (((long)(2L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141580 = ((2L) * (((long)(t$141579))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141581 = ((t$141580) + (((long)(1L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141582 = ((long[])t$141578.value)[(int)t$141581];
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141583 = ((t$141577) - (((long)(t$141582))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    offset$141641 = t$141583;
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    final long t$141586 = ((i$141587) + (((long)(1L))));
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    i$141587 = t$141586;
                }
            }
            
            //#line 527 ... "x10/regionarray/Array.x10"
            final $T t$141652 = (($T)(((x10.core.Rail<$T>)t$141636).$apply$G((long)(offset$141641))));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141654 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)src).region));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final boolean t$141655 = t$141654.contains$O(((x10.lang.Point)(p$141614)));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final boolean t$141656 = !(t$141655);
            
            //#line 524 ... "x10/regionarray/Array.x10"
            if (t$141656) {
                
                //#line 525 ... "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141614)));
            }
            
            //#line 527 ... "x10/regionarray/Array.x10"
            final x10.core.Rail t$141657 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).raw));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$141659 = ((long)(((int)(0))));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$141660 = p$141614.$apply$O((long)(t$141659));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$141661 = ((x10.regionarray.Array<$U>)src).layout_min0;
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            long offset$141662 = ((t$141660) - (((long)(t$141661))));
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            final long t$141663 = p$141614.rank;
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            final boolean t$141664 = ((t$141663) > (((long)(1L))));
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            if (t$141664) {
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141666 = ((x10.regionarray.Array<$U>)src).layout_stride1;
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141667 = ((offset$141662) * (((long)(t$141666))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141668 = p$141614.$apply$O((long)(1L));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141669 = ((t$141667) + (((long)(t$141668))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141670 = ((x10.regionarray.Array<$U>)src).layout_min1;
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$141671 = ((t$141669) - (((long)(t$141670))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                offset$141662 = t$141671;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                final long t$141612 = p$141614.rank;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                final long i$138093max$141613 = ((t$141612) - (((long)(1L))));
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                long i$141609 = 2L;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    final boolean t$141611 = ((i$141609) <= (((long)(i$138093max$141613))));
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    if (!(t$141611)) {
                        
                        //#line 1318 .... "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141593 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).layout));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141594 = ((i$141609) - (((long)(2L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141595 = ((2L) * (((long)(t$141594))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141596 = ((long[])t$141593.value)[(int)t$141595];
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141597 = ((offset$141662) * (((long)(t$141596))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141598 = p$141614.$apply$O((long)(i$141609));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141599 = ((t$141597) + (((long)(t$141598))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141600 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).layout));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141601 = ((i$141609) - (((long)(2L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141602 = ((2L) * (((long)(t$141601))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141603 = ((t$141602) + (((long)(1L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141604 = ((long[])t$141600.value)[(int)t$141603];
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141605 = ((t$141599) - (((long)(t$141604))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    offset$141662 = t$141605;
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    final long t$141608 = ((i$141609) + (((long)(1L))));
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    i$141609 = t$141608;
                }
            }
            
            //#line 527 ... "x10/regionarray/Array.x10"
            final $U t$141673 = (($U)(((x10.core.Rail<$U>)t$141657).$apply$G((long)(offset$141662))));
            
            //#line 755 .. "x10/regionarray/Array.x10"
            final $S t$141674 = (($S)((($S)
                                        ((x10.core.fun.Fun_0_2<$T,$U,$S>)op).$apply(t$141652, $T, t$141673, $U))));
            
            //#line 183 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$S>)r$141693).$set__1x10$lang$Rail$$T$G((long)(offset$141619), (($S)(t$141674)));
        }
        
        //#line 185 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$137862).raw = ((x10.core.Rail)(r$141693));
        
        //#line 755 "x10/regionarray/Array.x10"
        return alloc$137862;
    }
    
    
    //#line 772 "x10/regionarray/Array.x10"
    /**
     * Map the given function onto the elements of this array
     * and the other src array, storing the results in the given dst array 
     * such that for all points <code>p</code> in <code>this.region</code>,
     * <code>dst(p) == op(this(p), src(p))</code>.<p>
     * 
     * @param dst the destination array for the map operation
     * @param src the second source array for the map operation
     * @param op the function to apply to each element of the array
     * @return destination after applying the map operation.
     * @see #reduce((U,T)=>U,U)
     * @see #scan((U,T)=>U,U)
     */
    public <$S, $U>x10.regionarray.Array map__0$1x10$regionarray$Array$$S$2__1$1x10$regionarray$Array$$U$2__2$1x10$regionarray$Array$$T$3x10$regionarray$Array$$U$3x10$regionarray$Array$$S$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.Array dst, final x10.regionarray.Array src, final x10.core.fun.Fun_0_2 op) {
        
        //#line 774 "x10/regionarray/Array.x10"
        boolean t$139982 = this.rect;
        
        //#line 774 "x10/regionarray/Array.x10"
        if (t$139982) {
            
            //#line 774 "x10/regionarray/Array.x10"
            final long t$139980 = this.size;
            
            //#line 774 "x10/regionarray/Array.x10"
            final long t$139981 = ((x10.regionarray.Array<$U>)src).size;
            
            //#line 774 "x10/regionarray/Array.x10"
            t$139982 = ((long) t$139980) == ((long) t$139981);
        }
        
        //#line 774 "x10/regionarray/Array.x10"
        if (t$139982) {
            
            //#line 778 "x10/regionarray/Array.x10"
            final x10.core.Rail src$138894 = ((x10.core.Rail)(this.raw));
            
            //#line 778 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139983 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).raw));
            
            //#line 778 "x10/regionarray/Array.x10"
            final x10.core.Rail t$136280 = ((x10.core.Rail<$U>)
                                             t$139983);
            
            //#line 778 "x10/regionarray/Array.x10"
            final long t$139985 = ((x10.core.Rail<$U>)t$136280).size;
            
            //#line 778 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139984 = ((x10.core.Rail)(x10.regionarray.Array.this.raw));
            
            //#line 778 "x10/regionarray/Array.x10"
            final long t$139986 = ((x10.core.Rail<$T>)t$139984).size;
            
            //#line 778 "x10/regionarray/Array.x10"
            final boolean t$139987 = ((long) t$139985) == ((long) t$139986);
            
            //#line 778 "x10/regionarray/Array.x10"
            final boolean t$139989 = !(t$139987);
            
            //#line 778 "x10/regionarray/Array.x10"
            if (t$139989) {
                
                //#line 778 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$139988 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[U]{self.size==this(:x10.regionarray.Array).raw.size}");
                
                //#line 778 "x10/regionarray/Array.x10"
                throw t$139988;
            }
            
            //#line 778 "x10/regionarray/Array.x10"
            final x10.core.Rail dst$138896 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).raw));
            
            //#line 203 . "x10/util/RailUtils.x10"
            final long i$97091max$141704 = ((x10.core.Rail<$T>)src$138894).size;
            
            //#line 203 . "x10/util/RailUtils.x10"
            long i$141700 = 0L;
            
            //#line 203 . "x10/util/RailUtils.x10"
            for (;
                 true;
                 ) {
                
                //#line 203 . "x10/util/RailUtils.x10"
                final boolean t$141702 = ((i$141700) < (((long)(i$97091max$141704))));
                
                //#line 203 . "x10/util/RailUtils.x10"
                if (!(t$141702)) {
                    
                    //#line 203 . "x10/util/RailUtils.x10"
                    break;
                }
                
                //#line 204 . "x10/util/RailUtils.x10"
                final $T t$141694 = (($T)(((x10.core.Rail<$T>)src$138894).$apply$G((long)(i$141700))));
                
                //#line 204 . "x10/util/RailUtils.x10"
                final $U t$141695 = (($U)(((x10.core.Rail<$U>)t$136280).$apply$G((long)(i$141700))));
                
                //#line 204 . "x10/util/RailUtils.x10"
                final $S t$141696 = (($S)((($S)
                                            ((x10.core.fun.Fun_0_2<$T,$U,$S>)op).$apply(t$141694, $T, t$141695, $U))));
                
                //#line 204 . "x10/util/RailUtils.x10"
                ((x10.core.Rail<$S>)dst$138896).$set__1x10$lang$Rail$$T$G((long)(i$141700), (($S)(t$141696)));
                
                //#line 203 . "x10/util/RailUtils.x10"
                final long t$141699 = ((i$141700) + (((long)(1L))));
                
                //#line 203 . "x10/util/RailUtils.x10"
                i$141700 = t$141699;
            }
            
            //#line 779 "x10/regionarray/Array.x10"
            return dst;
        } else {
            
            //#line 781 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$139999 = ((x10.regionarray.Region)(this.region));
            
            //#line 781 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$137950 = t$139999.iterator();
            
            //#line 781 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 781 "x10/regionarray/Array.x10"
                final boolean t$140113 = ((x10.lang.Iterator<x10.lang.Point>)p$137950).hasNext$O();
                
                //#line 781 "x10/regionarray/Array.x10"
                if (!(t$140113)) {
                    
                    //#line 781 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 781 "x10/regionarray/Array.x10"
                final x10.lang.Point p$141771 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$137950).next$G()));
                
                //#line 782 "x10/regionarray/Array.x10"
                final x10.regionarray.Array this$141773 = ((x10.regionarray.Array)(this));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$141775 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$141773).region));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$141776 = t$141775.contains$O(((x10.lang.Point)(p$141771)));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$141777 = !(t$141776);
                
                //#line 524 . "x10/regionarray/Array.x10"
                if (t$141777) {
                    
                    //#line 525 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141771)));
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141778 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141773).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141780 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141781 = p$141771.$apply$O((long)(t$141780));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141782 = ((x10.regionarray.Array<$T>)this$141773).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$141783 = ((t$141781) - (((long)(t$141782))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$141784 = p$141771.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$141785 = ((t$141784) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$141785) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141787 = ((x10.regionarray.Array<$T>)this$141773).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141788 = ((offset$141783) * (((long)(t$141787))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141789 = p$141771.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141790 = ((t$141788) + (((long)(t$141789))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141791 = ((x10.regionarray.Array<$T>)this$141773).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141792 = ((t$141790) - (((long)(t$141791))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$141783 = t$141792;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141725 = p$141771.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138093max$141726 = ((t$141725) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$141722 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$141724 = ((i$141722) <= (((long)(i$138093max$141726))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$141724)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141706 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141773).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141707 = ((i$141722) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141708 = ((2L) * (((long)(t$141707))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141709 = ((long[])t$141706.value)[(int)t$141708];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141710 = ((offset$141783) * (((long)(t$141709))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141711 = p$141771.$apply$O((long)(i$141722));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141712 = ((t$141710) + (((long)(t$141711))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141713 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141773).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141714 = ((i$141722) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141715 = ((2L) * (((long)(t$141714))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141716 = ((t$141715) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141717 = ((long[])t$141713.value)[(int)t$141716];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141718 = ((t$141712) - (((long)(t$141717))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$141783 = t$141718;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$141721 = ((i$141722) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$141722 = t$141721;
                    }
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final $T t$141794 = (($T)(((x10.core.Rail<$T>)t$141778).$apply$G((long)(offset$141783))));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$141796 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)src).region));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$141797 = t$141796.contains$O(((x10.lang.Point)(p$141771)));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$141798 = !(t$141797);
                
                //#line 524 . "x10/regionarray/Array.x10"
                if (t$141798) {
                    
                    //#line 525 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141771)));
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141799 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141801 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141802 = p$141771.$apply$O((long)(t$141801));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141803 = ((x10.regionarray.Array<$U>)src).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$141804 = ((t$141802) - (((long)(t$141803))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$141805 = p$141771.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$141806 = ((t$141805) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$141806) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141808 = ((x10.regionarray.Array<$U>)src).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141809 = ((offset$141804) * (((long)(t$141808))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141810 = p$141771.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141811 = ((t$141809) + (((long)(t$141810))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141812 = ((x10.regionarray.Array<$U>)src).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141813 = ((t$141811) - (((long)(t$141812))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$141804 = t$141813;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141747 = p$141771.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138093max$141748 = ((t$141747) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$141744 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$141746 = ((i$141744) <= (((long)(i$138093max$141748))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$141746)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141728 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141729 = ((i$141744) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141730 = ((2L) * (((long)(t$141729))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141731 = ((long[])t$141728.value)[(int)t$141730];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141732 = ((offset$141804) * (((long)(t$141731))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141733 = p$141771.$apply$O((long)(i$141744));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141734 = ((t$141732) + (((long)(t$141733))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141735 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141736 = ((i$141744) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141737 = ((2L) * (((long)(t$141736))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141738 = ((t$141737) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141739 = ((long[])t$141735.value)[(int)t$141738];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141740 = ((t$141734) - (((long)(t$141739))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$141804 = t$141740;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$141743 = ((i$141744) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$141744 = t$141743;
                    }
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final $U t$141815 = (($U)(((x10.core.Rail<$U>)t$141799).$apply$G((long)(offset$141804))));
                
                //#line 782 "x10/regionarray/Array.x10"
                final $S v$141816 = (($S)((($S)
                                            ((x10.core.fun.Fun_0_2<$T,$U,$S>)op).$apply(t$141794, $T, t$141815, $U))));
                
                //#line 637 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$141817 = ((x10.regionarray.Region)(((x10.regionarray.Array<$S>)dst).region));
                
                //#line 637 . "x10/regionarray/Array.x10"
                final boolean t$141818 = t$141817.contains$O(((x10.lang.Point)(p$141771)));
                
                //#line 637 . "x10/regionarray/Array.x10"
                final boolean t$141819 = !(t$141818);
                
                //#line 637 . "x10/regionarray/Array.x10"
                if (t$141819) {
                    
                    //#line 638 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141771)));
                }
                
                //#line 640 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141820 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141822 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141823 = p$141771.$apply$O((long)(t$141822));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141824 = ((x10.regionarray.Array<$S>)dst).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$141825 = ((t$141823) - (((long)(t$141824))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$141826 = p$141771.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$141827 = ((t$141826) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$141827) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141829 = ((x10.regionarray.Array<$S>)dst).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141830 = ((offset$141825) * (((long)(t$141829))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141831 = p$141771.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141832 = ((t$141830) + (((long)(t$141831))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141833 = ((x10.regionarray.Array<$S>)dst).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141834 = ((t$141832) - (((long)(t$141833))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$141825 = t$141834;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141769 = p$141771.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138093max$141770 = ((t$141769) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$141766 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$141768 = ((i$141766) <= (((long)(i$138093max$141770))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$141768)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141750 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141751 = ((i$141766) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141752 = ((2L) * (((long)(t$141751))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141753 = ((long[])t$141750.value)[(int)t$141752];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141754 = ((offset$141825) * (((long)(t$141753))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141755 = p$141771.$apply$O((long)(i$141766));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141756 = ((t$141754) + (((long)(t$141755))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141757 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141758 = ((i$141766) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141759 = ((2L) * (((long)(t$141758))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141760 = ((t$141759) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141761 = ((long[])t$141757.value)[(int)t$141760];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141762 = ((t$141756) - (((long)(t$141761))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$141825 = t$141762;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$141765 = ((i$141766) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$141766 = t$141765;
                    }
                }
                
                //#line 640 . "x10/regionarray/Array.x10"
                ((x10.core.Rail<$S>)t$141820).$set__1x10$lang$Rail$$T$G((long)(offset$141825), (($S)(v$141816)));
            }
        }
        
        //#line 785 "x10/regionarray/Array.x10"
        return dst;
    }
    
    
    //#line 804 "x10/regionarray/Array.x10"
    /**
     * Map the given function onto the elements of this array
     * and the other src array for the subset of points contained in the filter region, 
     * storing the results in the given dst array such that for all points <code>p</code> 
     * in <code>filter</code>,
     * <code>dst(p) == op(this(p), src(p))</code>.<p>
     * 
     * @param dst the destination array for the map operation
     * @param src the second source array for the map operation
     * @param filter the region to select the subset of points to include in the map
     * @param op the function to apply to each element of the array
     * @return destination after applying the map operation.
     * @see #reduce((U,T)=>U,U)
     * @see #scan((U,T)=>U,U)
     */
    public <$S, $U>x10.regionarray.Array map__0$1x10$regionarray$Array$$S$2__1$1x10$regionarray$Array$$U$2__3$1x10$regionarray$Array$$T$3x10$regionarray$Array$$U$3x10$regionarray$Array$$S$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.Array dst, final x10.regionarray.Array src, final x10.regionarray.Region filter, final x10.core.fun.Fun_0_2 op) {
        
        //#line 805 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140115 = ((x10.regionarray.Region)(this.region));
        
        //#line 805 "x10/regionarray/Array.x10"
        final x10.regionarray.Region fregion = ((x10.regionarray.Region)(t$140115.$and(((x10.regionarray.Region)(filter)))));
        
        //#line 806 "x10/regionarray/Array.x10"
        final x10.lang.Iterator p$141967 = fregion.iterator();
        
        //#line 806 "x10/regionarray/Array.x10"
        for (;
             true;
             ) {
            
            //#line 806 "x10/regionarray/Array.x10"
            final boolean t$141968 = ((x10.lang.Iterator<x10.lang.Point>)p$141967).hasNext$O();
            
            //#line 806 "x10/regionarray/Array.x10"
            if (!(t$141968)) {
                
                //#line 806 "x10/regionarray/Array.x10"
                break;
            }
            
            //#line 806 "x10/regionarray/Array.x10"
            final x10.lang.Point p$141902 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$141967).next$G()));
            
            //#line 807 "x10/regionarray/Array.x10"
            final x10.regionarray.Array this$141904 = ((x10.regionarray.Array)(this));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141906 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$141904).region));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$141907 = t$141906.contains$O(((x10.lang.Point)(p$141902)));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$141908 = !(t$141907);
            
            //#line 524 . "x10/regionarray/Array.x10"
            if (t$141908) {
                
                //#line 525 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141902)));
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$141909 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141904).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141911 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141912 = p$141902.$apply$O((long)(t$141911));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141913 = ((x10.regionarray.Array<$T>)this$141904).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$141914 = ((t$141912) - (((long)(t$141913))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$141915 = p$141902.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$141916 = ((t$141915) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$141916) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141918 = ((x10.regionarray.Array<$T>)this$141904).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141919 = ((offset$141914) * (((long)(t$141918))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141920 = p$141902.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141921 = ((t$141919) + (((long)(t$141920))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141922 = ((x10.regionarray.Array<$T>)this$141904).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141923 = ((t$141921) - (((long)(t$141922))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$141914 = t$141923;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$141856 = p$141902.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138093max$141857 = ((t$141856) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$141853 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$141855 = ((i$141853) <= (((long)(i$138093max$141857))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$141855)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141837 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141904).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141838 = ((i$141853) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141839 = ((2L) * (((long)(t$141838))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141840 = ((long[])t$141837.value)[(int)t$141839];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141841 = ((offset$141914) * (((long)(t$141840))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141842 = p$141902.$apply$O((long)(i$141853));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141843 = ((t$141841) + (((long)(t$141842))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141844 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141904).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141845 = ((i$141853) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141846 = ((2L) * (((long)(t$141845))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141847 = ((t$141846) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141848 = ((long[])t$141844.value)[(int)t$141847];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141849 = ((t$141843) - (((long)(t$141848))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$141914 = t$141849;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141852 = ((i$141853) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$141853 = t$141852;
                }
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final $T t$141925 = (($T)(((x10.core.Rail<$T>)t$141909).$apply$G((long)(offset$141914))));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141927 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)src).region));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$141928 = t$141927.contains$O(((x10.lang.Point)(p$141902)));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$141929 = !(t$141928);
            
            //#line 524 . "x10/regionarray/Array.x10"
            if (t$141929) {
                
                //#line 525 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141902)));
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$141930 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141932 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141933 = p$141902.$apply$O((long)(t$141932));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141934 = ((x10.regionarray.Array<$U>)src).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$141935 = ((t$141933) - (((long)(t$141934))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$141936 = p$141902.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$141937 = ((t$141936) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$141937) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141939 = ((x10.regionarray.Array<$U>)src).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141940 = ((offset$141935) * (((long)(t$141939))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141941 = p$141902.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141942 = ((t$141940) + (((long)(t$141941))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141943 = ((x10.regionarray.Array<$U>)src).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141944 = ((t$141942) - (((long)(t$141943))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$141935 = t$141944;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$141878 = p$141902.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138093max$141879 = ((t$141878) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$141875 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$141877 = ((i$141875) <= (((long)(i$138093max$141879))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$141877)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141859 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141860 = ((i$141875) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141861 = ((2L) * (((long)(t$141860))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141862 = ((long[])t$141859.value)[(int)t$141861];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141863 = ((offset$141935) * (((long)(t$141862))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141864 = p$141902.$apply$O((long)(i$141875));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141865 = ((t$141863) + (((long)(t$141864))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141866 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141867 = ((i$141875) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141868 = ((2L) * (((long)(t$141867))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141869 = ((t$141868) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141870 = ((long[])t$141866.value)[(int)t$141869];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141871 = ((t$141865) - (((long)(t$141870))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$141935 = t$141871;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141874 = ((i$141875) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$141875 = t$141874;
                }
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final $U t$141946 = (($U)(((x10.core.Rail<$U>)t$141930).$apply$G((long)(offset$141935))));
            
            //#line 807 "x10/regionarray/Array.x10"
            final $S v$141947 = (($S)((($S)
                                        ((x10.core.fun.Fun_0_2<$T,$U,$S>)op).$apply(t$141925, $T, t$141946, $U))));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141948 = ((x10.regionarray.Region)(((x10.regionarray.Array<$S>)dst).region));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final boolean t$141949 = t$141948.contains$O(((x10.lang.Point)(p$141902)));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final boolean t$141950 = !(t$141949);
            
            //#line 637 . "x10/regionarray/Array.x10"
            if (t$141950) {
                
                //#line 638 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141902)));
            }
            
            //#line 640 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$141951 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141953 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141954 = p$141902.$apply$O((long)(t$141953));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141955 = ((x10.regionarray.Array<$S>)dst).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$141956 = ((t$141954) - (((long)(t$141955))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$141957 = p$141902.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$141958 = ((t$141957) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$141958) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141960 = ((x10.regionarray.Array<$S>)dst).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141961 = ((offset$141956) * (((long)(t$141960))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141962 = p$141902.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141963 = ((t$141961) + (((long)(t$141962))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141964 = ((x10.regionarray.Array<$S>)dst).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141965 = ((t$141963) - (((long)(t$141964))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$141956 = t$141965;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$141900 = p$141902.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138093max$141901 = ((t$141900) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$141897 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$141899 = ((i$141897) <= (((long)(i$138093max$141901))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$141899)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141881 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141882 = ((i$141897) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141883 = ((2L) * (((long)(t$141882))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141884 = ((long[])t$141881.value)[(int)t$141883];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141885 = ((offset$141956) * (((long)(t$141884))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141886 = p$141902.$apply$O((long)(i$141897));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141887 = ((t$141885) + (((long)(t$141886))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141888 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141889 = ((i$141897) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141890 = ((2L) * (((long)(t$141889))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141891 = ((t$141890) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141892 = ((long[])t$141888.value)[(int)t$141891];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141893 = ((t$141887) - (((long)(t$141892))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$141956 = t$141893;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141896 = ((i$141897) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$141897 = t$141896;
                }
            }
            
            //#line 640 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$S>)t$141951).$set__1x10$lang$Rail$$T$G((long)(offset$141956), (($S)(v$141947)));
        }
        
        //#line 809 "x10/regionarray/Array.x10"
        return dst;
    }
    
    
    //#line 825 "x10/regionarray/Array.x10"
    /**
     * Reduce this array using the given function and the given initial value.
     * Each element of the array will be given as an argument to the reduction
     * function exactly once, but in an arbitrary order.  The reduction function
     * may be applied concurrently to implement a parallel reduction. 
     * 
     * @param op the reduction function
     * @param unit the given initial value
     * @return the final result of the reduction.
     * @see #map((T)=>S)
     * @see #scan((U,T)=>U,U)
     */
    public <$U>$U reduce__0$1x10$regionarray$Array$$U$3x10$regionarray$Array$$T$3x10$regionarray$Array$$U$2__1x10$regionarray$Array$$U$G(final x10.rtt.Type $U, final x10.core.fun.Fun_0_2 op, final $U unit) {
        
        //#line 826 "x10/regionarray/Array.x10"
        final boolean t$140284 = this.rect;
        
        //#line 826 "x10/regionarray/Array.x10"
        if (t$140284) {
            
            //#line 830 "x10/regionarray/Array.x10"
            final x10.core.Rail src$138962 = ((x10.core.Rail)(this.raw));
            
            //#line 132 . "x10/util/RailUtils.x10"
            $U accum$138965 = (($U)(unit));
            
            //#line 133 . "x10/util/RailUtils.x10"
            final long i$97034max$141979 = ((x10.core.Rail<$T>)src$138962).size;
            
            //#line 133 . "x10/util/RailUtils.x10"
            long i$141975 = 0L;
            
            //#line 133 . "x10/util/RailUtils.x10"
            for (;
                 true;
                 ) {
                
                //#line 133 . "x10/util/RailUtils.x10"
                final boolean t$141977 = ((i$141975) < (((long)(i$97034max$141979))));
                
                //#line 133 . "x10/util/RailUtils.x10"
                if (!(t$141977)) {
                    
                    //#line 133 . "x10/util/RailUtils.x10"
                    break;
                }
                
                //#line 134 . "x10/util/RailUtils.x10"
                final $T t$141970 = (($T)(((x10.core.Rail<$T>)src$138962).$apply$G((long)(i$141975))));
                
                //#line 134 . "x10/util/RailUtils.x10"
                final $U t$141971 = (($U)((($U)
                                            ((x10.core.fun.Fun_0_2<$U,$T,$U>)op).$apply(accum$138965, $U, t$141970, $T))));
                
                //#line 134 . "x10/util/RailUtils.x10"
                accum$138965 = (($U)(t$141971));
                
                //#line 133 . "x10/util/RailUtils.x10"
                final long t$141974 = ((i$141975) + (((long)(1L))));
                
                //#line 133 . "x10/util/RailUtils.x10"
                i$141975 = t$141974;
            }
            
            //#line 830 "x10/regionarray/Array.x10"
            return accum$138965;
        } else {
            
            //#line 832 "x10/regionarray/Array.x10"
            $U accum = (($U)(unit));
            
            //#line 833 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142027 = ((x10.regionarray.Region)(this.region));
            
            //#line 833 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$142028 = t$142027.iterator();
            
            //#line 833 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 833 "x10/regionarray/Array.x10"
                final boolean t$142029 = ((x10.lang.Iterator<x10.lang.Point>)p$142028).hasNext$O();
                
                //#line 833 "x10/regionarray/Array.x10"
                if (!(t$142029)) {
                    
                    //#line 833 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 833 "x10/regionarray/Array.x10"
                final x10.lang.Point p$142002 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$142028).next$G()));
                
                //#line 834 "x10/regionarray/Array.x10"
                final x10.regionarray.Array this$142004 = ((x10.regionarray.Array)(this));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$142006 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$142004).region));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$142007 = t$142006.contains$O(((x10.lang.Point)(p$142002)));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$142008 = !(t$142007);
                
                //#line 524 . "x10/regionarray/Array.x10"
                if (t$142008) {
                    
                    //#line 525 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142002)));
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$142009 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142004).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142011 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142012 = p$142002.$apply$O((long)(t$142011));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142013 = ((x10.regionarray.Array<$T>)this$142004).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$142014 = ((t$142012) - (((long)(t$142013))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$142015 = p$142002.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$142016 = ((t$142015) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$142016) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142018 = ((x10.regionarray.Array<$T>)this$142004).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142019 = ((offset$142014) * (((long)(t$142018))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142020 = p$142002.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142021 = ((t$142019) + (((long)(t$142020))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142022 = ((x10.regionarray.Array<$T>)this$142004).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142023 = ((t$142021) - (((long)(t$142022))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$142014 = t$142023;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142000 = p$142002.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138093max$142001 = ((t$142000) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$141997 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$141999 = ((i$141997) <= (((long)(i$138093max$142001))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$141999)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141981 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142004).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141982 = ((i$141997) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141983 = ((2L) * (((long)(t$141982))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141984 = ((long[])t$141981.value)[(int)t$141983];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141985 = ((offset$142014) * (((long)(t$141984))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141986 = p$142002.$apply$O((long)(i$141997));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141987 = ((t$141985) + (((long)(t$141986))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141988 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142004).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141989 = ((i$141997) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141990 = ((2L) * (((long)(t$141989))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141991 = ((t$141990) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141992 = ((long[])t$141988.value)[(int)t$141991];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$141993 = ((t$141987) - (((long)(t$141992))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$142014 = t$141993;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$141996 = ((i$141997) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$141997 = t$141996;
                    }
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final $T t$142025 = (($T)(((x10.core.Rail<$T>)t$142009).$apply$G((long)(offset$142014))));
                
                //#line 834 "x10/regionarray/Array.x10"
                final $U t$142026 = (($U)((($U)
                                            ((x10.core.fun.Fun_0_2<$U,$T,$U>)op).$apply(accum, $U, t$142025, $T))));
                
                //#line 834 "x10/regionarray/Array.x10"
                accum = (($U)(t$142026));
            }
            
            //#line 836 "x10/regionarray/Array.x10"
            return accum;
        }
    }
    
    
    //#line 854 "x10/regionarray/Array.x10"
    /**
     * Scan this array using the function and the given initial value.
     * Starting with the initial value, apply the operation pointwise to the current running value
     * and each element of this array.
     * Return a new array with the same region as this array.
     * Each element of the new array is the result of applying the given function to the
     * current running value and the corresponding element of this array.
     * 
     * @param op the scan function
     * @param unit the given initial value
     * @return a new array containing the result of the scan 
     * @see #map((T)=>U)
     * @see #reduce((U,T)=>U,U)
     */
    public <$U>x10.regionarray.Array scan__0$1x10$regionarray$Array$$U$3x10$regionarray$Array$$T$3x10$regionarray$Array$$U$2__1x10$regionarray$Array$$U(final x10.rtt.Type $U, final x10.core.fun.Fun_0_2 op, final $U unit) {
        
        //#line 855 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$138995 = ((x10.regionarray.Array)(this));
        
        //#line 855 "x10/regionarray/Array.x10"
        final x10.regionarray.Array alloc$137863 = ((x10.regionarray.Array)(new x10.regionarray.Array<$U>((java.lang.System[]) null, $U)));
        
        //#line 855 "x10/regionarray/Array.x10"
        final x10.regionarray.Region reg$138983 = ((x10.regionarray.Region)(this.region));
        
        //#line 142 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$142030 = ((x10.regionarray.Region)
                                                  reg$138983);
        
        //#line 142 . "x10/regionarray/Array.x10"
        final boolean t$142031 = ((t$142030) != (null));
        
        //#line 142 . "x10/regionarray/Array.x10"
        final boolean t$142032 = !(t$142031);
        
        //#line 142 . "x10/regionarray/Array.x10"
        if (t$142032) {
            
            //#line 142 . "x10/regionarray/Array.x10"
            final boolean t$142033 = true;
            
            //#line 142 . "x10/regionarray/Array.x10"
            if (t$142033) {
                
                //#line 142 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$142034 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 142 . "x10/regionarray/Array.x10"
                throw t$142034;
            }
        }
        
        //#line 142 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137863).region = ((x10.regionarray.Region)(t$142030));
        
        //#line 142 . "x10/regionarray/Array.x10"
        final long t$142035 = reg$138983.rank;
        
        //#line 142 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137863).rank = t$142035;
        
        //#line 142 . "x10/regionarray/Array.x10"
        final boolean t$142036 = reg$138983.rect;
        
        //#line 142 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137863).rect = t$142036;
        
        //#line 142 . "x10/regionarray/Array.x10"
        final boolean t$142037 = reg$138983.zeroBased;
        
        //#line 142 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137863).zeroBased = t$142037;
        
        //#line 142 . "x10/regionarray/Array.x10"
        final boolean t$142038 = reg$138983.rail;
        
        //#line 142 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137863).rail = t$142038;
        
        //#line 142 . "x10/regionarray/Array.x10"
        final long t$142039 = reg$138983.size$O();
        
        //#line 142 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137863).size = t$142039;
        
        //#line 143 . "x10/regionarray/Array.x10"
        final x10.regionarray.Array.LayoutHelper crh$142130 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
        
        //#line 143 . "x10/regionarray/Array.x10"
        crh$142130.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg$138983)));
        
        //#line 144 . "x10/regionarray/Array.x10"
        final long t$142131 = crh$142130.min0;
        
        //#line 144 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137863).layout_min0 = t$142131;
        
        //#line 145 . "x10/regionarray/Array.x10"
        final long t$142132 = crh$142130.stride1;
        
        //#line 145 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137863).layout_stride1 = t$142132;
        
        //#line 146 . "x10/regionarray/Array.x10"
        final long t$142133 = crh$142130.min1;
        
        //#line 146 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137863).layout_min1 = t$142133;
        
        //#line 147 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142134 = ((x10.core.Rail)(crh$142130.layout));
        
        //#line 147 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137863).layout = ((x10.core.Rail)(t$142134));
        
        //#line 148 . "x10/regionarray/Array.x10"
        final long n$142135 = crh$142130.size;
        
        //#line 152 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142040 = ((x10.core.Rail)(x10.core.Rail.<$U>makeUnsafe($U, ((long)(n$142135)), false)));
        
        //#line 152 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$137863).raw = ((x10.core.Rail)(t$142040));
        
        //#line 873 . "x10/regionarray/Array.x10"
        $U accum$138992 = (($U)(unit));
        
        //#line 874 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$142136 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$138995).region));
        
        //#line 874 . "x10/regionarray/Array.x10"
        final x10.lang.Iterator p$142137 = t$142136.iterator();
        
        //#line 874 . "x10/regionarray/Array.x10"
        for (;
             true;
             ) {
            
            //#line 874 . "x10/regionarray/Array.x10"
            final boolean t$142138 = ((x10.lang.Iterator<x10.lang.Point>)p$142137).hasNext$O();
            
            //#line 874 . "x10/regionarray/Array.x10"
            if (!(t$142138)) {
                
                //#line 874 . "x10/regionarray/Array.x10"
                break;
            }
            
            //#line 874 . "x10/regionarray/Array.x10"
            final x10.lang.Point p$142085 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$142137).next$G()));
            
            //#line 524 .. "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142088 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$138995).region));
            
            //#line 524 .. "x10/regionarray/Array.x10"
            final boolean t$142089 = t$142088.contains$O(((x10.lang.Point)(p$142085)));
            
            //#line 524 .. "x10/regionarray/Array.x10"
            final boolean t$142090 = !(t$142089);
            
            //#line 524 .. "x10/regionarray/Array.x10"
            if (t$142090) {
                
                //#line 525 .. "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142085)));
            }
            
            //#line 527 .. "x10/regionarray/Array.x10"
            final x10.core.Rail t$142091 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138995).raw));
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            final long t$142093 = ((long)(((int)(0))));
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            final long t$142094 = p$142085.$apply$O((long)(t$142093));
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            final long t$142095 = ((x10.regionarray.Array<$T>)this$138995).layout_min0;
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            long offset$142096 = ((t$142094) - (((long)(t$142095))));
            
            //#line 1316 ... "x10/regionarray/Array.x10"
            final long t$142097 = p$142085.rank;
            
            //#line 1316 ... "x10/regionarray/Array.x10"
            final boolean t$142098 = ((t$142097) > (((long)(1L))));
            
            //#line 1316 ... "x10/regionarray/Array.x10"
            if (t$142098) {
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142100 = ((x10.regionarray.Array<$T>)this$138995).layout_stride1;
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142101 = ((offset$142096) * (((long)(t$142100))));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142102 = p$142085.$apply$O((long)(1L));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142103 = ((t$142101) + (((long)(t$142102))));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142104 = ((x10.regionarray.Array<$T>)this$138995).layout_min1;
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142105 = ((t$142103) - (((long)(t$142104))));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                offset$142096 = t$142105;
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                final long t$142061 = p$142085.rank;
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                final long i$138093max$142062 = ((t$142061) - (((long)(1L))));
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                long i$142058 = 2L;
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    final boolean t$142060 = ((i$142058) <= (((long)(i$138093max$142062))));
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    if (!(t$142060)) {
                        
                        //#line 1318 ... "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142042 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138995).layout));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142043 = ((i$142058) - (((long)(2L))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142044 = ((2L) * (((long)(t$142043))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142045 = ((long[])t$142042.value)[(int)t$142044];
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142046 = ((offset$142096) * (((long)(t$142045))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142047 = p$142085.$apply$O((long)(i$142058));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142048 = ((t$142046) + (((long)(t$142047))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142049 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$138995).layout));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142050 = ((i$142058) - (((long)(2L))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142051 = ((2L) * (((long)(t$142050))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142052 = ((t$142051) + (((long)(1L))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142053 = ((long[])t$142049.value)[(int)t$142052];
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142054 = ((t$142048) - (((long)(t$142053))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    offset$142096 = t$142054;
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    final long t$142057 = ((i$142058) + (((long)(1L))));
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    i$142058 = t$142057;
                }
            }
            
            //#line 527 .. "x10/regionarray/Array.x10"
            final $T t$142107 = (($T)(((x10.core.Rail<$T>)t$142091).$apply$G((long)(offset$142096))));
            
            //#line 875 . "x10/regionarray/Array.x10"
            final $U t$142108 = (($U)((($U)
                                        ((x10.core.fun.Fun_0_2<$U,$T,$U>)op).$apply(accum$138992, $U, t$142107, $T))));
            
            //#line 875 . "x10/regionarray/Array.x10"
            accum$138992 = (($U)(t$142108));
            
            //#line 637 .. "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142111 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)alloc$137863).region));
            
            //#line 637 .. "x10/regionarray/Array.x10"
            final boolean t$142112 = t$142111.contains$O(((x10.lang.Point)(p$142085)));
            
            //#line 637 .. "x10/regionarray/Array.x10"
            final boolean t$142113 = !(t$142112);
            
            //#line 637 .. "x10/regionarray/Array.x10"
            if (t$142113) {
                
                //#line 638 .. "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142085)));
            }
            
            //#line 640 .. "x10/regionarray/Array.x10"
            final x10.core.Rail t$142114 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)alloc$137863).raw));
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            final long t$142116 = ((long)(((int)(0))));
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            final long t$142117 = p$142085.$apply$O((long)(t$142116));
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            final long t$142118 = ((x10.regionarray.Array<$U>)alloc$137863).layout_min0;
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            long offset$142119 = ((t$142117) - (((long)(t$142118))));
            
            //#line 1316 ... "x10/regionarray/Array.x10"
            final long t$142120 = p$142085.rank;
            
            //#line 1316 ... "x10/regionarray/Array.x10"
            final boolean t$142121 = ((t$142120) > (((long)(1L))));
            
            //#line 1316 ... "x10/regionarray/Array.x10"
            if (t$142121) {
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142123 = ((x10.regionarray.Array<$U>)alloc$137863).layout_stride1;
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142124 = ((offset$142119) * (((long)(t$142123))));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142125 = p$142085.$apply$O((long)(1L));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142126 = ((t$142124) + (((long)(t$142125))));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142127 = ((x10.regionarray.Array<$U>)alloc$137863).layout_min1;
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142128 = ((t$142126) - (((long)(t$142127))));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                offset$142119 = t$142128;
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                final long t$142083 = p$142085.rank;
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                final long i$138093max$142084 = ((t$142083) - (((long)(1L))));
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                long i$142080 = 2L;
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    final boolean t$142082 = ((i$142080) <= (((long)(i$138093max$142084))));
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    if (!(t$142082)) {
                        
                        //#line 1318 ... "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142064 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)alloc$137863).layout));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142065 = ((i$142080) - (((long)(2L))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142066 = ((2L) * (((long)(t$142065))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142067 = ((long[])t$142064.value)[(int)t$142066];
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142068 = ((offset$142119) * (((long)(t$142067))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142069 = p$142085.$apply$O((long)(i$142080));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142070 = ((t$142068) + (((long)(t$142069))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142071 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)alloc$137863).layout));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142072 = ((i$142080) - (((long)(2L))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142073 = ((2L) * (((long)(t$142072))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142074 = ((t$142073) + (((long)(1L))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142075 = ((long[])t$142071.value)[(int)t$142074];
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142076 = ((t$142070) - (((long)(t$142075))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    offset$142119 = t$142076;
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    final long t$142079 = ((i$142080) + (((long)(1L))));
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    i$142080 = t$142079;
                }
            }
            
            //#line 640 .. "x10/regionarray/Array.x10"
            ((x10.core.Rail<$U>)t$142114).$set__1x10$lang$Rail$$T$G((long)(offset$142119), (($U)(accum$138992)));
        }
        
        //#line 855 "x10/regionarray/Array.x10"
        return alloc$137863;
    }
    
    
    //#line 872 "x10/regionarray/Array.x10"
    /**
     * Scan this array using the given function and the given initial value.
     * Starting with the initial value, apply the operation pointwise to the current running value
     * and each element of this array storing the result in the destination array.
     * Return the destination array where each element has been set to the result of 
     * applying the given operation to the current running value and the corresponding 
     * element of this array.
     * 
     * @param op the scan function
     * @param unit the given initial value
     * @return a new array containing the result of the scan 
     * @see #map((T)=>U)
     * @see #reduce((U,T)=>U,U)
     */
    public <$U>x10.regionarray.Array scan__0$1x10$regionarray$Array$$U$2__1$1x10$regionarray$Array$$U$3x10$regionarray$Array$$T$3x10$regionarray$Array$$U$2__2x10$regionarray$Array$$U(final x10.rtt.Type $U, final x10.regionarray.Array dst, final x10.core.fun.Fun_0_2 op, final $U unit) {
        
        //#line 873 "x10/regionarray/Array.x10"
        $U accum = (($U)(unit));
        
        //#line 874 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$142229 = ((x10.regionarray.Region)(this.region));
        
        //#line 874 "x10/regionarray/Array.x10"
        final x10.lang.Iterator p$142230 = t$142229.iterator();
        
        //#line 874 "x10/regionarray/Array.x10"
        for (;
             true;
             ) {
            
            //#line 874 "x10/regionarray/Array.x10"
            final boolean t$142231 = ((x10.lang.Iterator<x10.lang.Point>)p$142230).hasNext$O();
            
            //#line 874 "x10/regionarray/Array.x10"
            if (!(t$142231)) {
                
                //#line 874 "x10/regionarray/Array.x10"
                break;
            }
            
            //#line 874 "x10/regionarray/Array.x10"
            final x10.lang.Point p$142183 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$142230).next$G()));
            
            //#line 875 "x10/regionarray/Array.x10"
            final x10.regionarray.Array this$142185 = ((x10.regionarray.Array)(this));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142187 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$142185).region));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$142188 = t$142187.contains$O(((x10.lang.Point)(p$142183)));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$142189 = !(t$142188);
            
            //#line 524 . "x10/regionarray/Array.x10"
            if (t$142189) {
                
                //#line 525 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142183)));
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$142190 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142185).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142192 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142193 = p$142183.$apply$O((long)(t$142192));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142194 = ((x10.regionarray.Array<$T>)this$142185).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$142195 = ((t$142193) - (((long)(t$142194))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$142196 = p$142183.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$142197 = ((t$142196) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$142197) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142199 = ((x10.regionarray.Array<$T>)this$142185).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142200 = ((offset$142195) * (((long)(t$142199))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142201 = p$142183.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142202 = ((t$142200) + (((long)(t$142201))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142203 = ((x10.regionarray.Array<$T>)this$142185).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142204 = ((t$142202) - (((long)(t$142203))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$142195 = t$142204;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$142159 = p$142183.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138093max$142160 = ((t$142159) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$142156 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$142158 = ((i$142156) <= (((long)(i$138093max$142160))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$142158)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142140 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142185).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142141 = ((i$142156) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142142 = ((2L) * (((long)(t$142141))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142143 = ((long[])t$142140.value)[(int)t$142142];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142144 = ((offset$142195) * (((long)(t$142143))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142145 = p$142183.$apply$O((long)(i$142156));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142146 = ((t$142144) + (((long)(t$142145))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142147 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142185).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142148 = ((i$142156) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142149 = ((2L) * (((long)(t$142148))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142150 = ((t$142149) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142151 = ((long[])t$142147.value)[(int)t$142150];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142152 = ((t$142146) - (((long)(t$142151))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$142195 = t$142152;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142155 = ((i$142156) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$142156 = t$142155;
                }
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final $T t$142206 = (($T)(((x10.core.Rail<$T>)t$142190).$apply$G((long)(offset$142195))));
            
            //#line 875 "x10/regionarray/Array.x10"
            final $U t$142207 = (($U)((($U)
                                        ((x10.core.fun.Fun_0_2<$U,$T,$U>)op).$apply(accum, $U, t$142206, $T))));
            
            //#line 875 "x10/regionarray/Array.x10"
            accum = (($U)(t$142207));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142210 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)dst).region));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final boolean t$142211 = t$142210.contains$O(((x10.lang.Point)(p$142183)));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final boolean t$142212 = !(t$142211);
            
            //#line 637 . "x10/regionarray/Array.x10"
            if (t$142212) {
                
                //#line 638 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142183)));
            }
            
            //#line 640 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$142213 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142215 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142216 = p$142183.$apply$O((long)(t$142215));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142217 = ((x10.regionarray.Array<$U>)dst).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$142218 = ((t$142216) - (((long)(t$142217))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$142219 = p$142183.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$142220 = ((t$142219) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$142220) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142222 = ((x10.regionarray.Array<$U>)dst).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142223 = ((offset$142218) * (((long)(t$142222))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142224 = p$142183.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142225 = ((t$142223) + (((long)(t$142224))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142226 = ((x10.regionarray.Array<$U>)dst).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142227 = ((t$142225) - (((long)(t$142226))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$142218 = t$142227;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$142181 = p$142183.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138093max$142182 = ((t$142181) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$142178 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$142180 = ((i$142178) <= (((long)(i$138093max$142182))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$142180)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142162 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142163 = ((i$142178) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142164 = ((2L) * (((long)(t$142163))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142165 = ((long[])t$142162.value)[(int)t$142164];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142166 = ((offset$142218) * (((long)(t$142165))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142167 = p$142183.$apply$O((long)(i$142178));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142168 = ((t$142166) + (((long)(t$142167))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142169 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142170 = ((i$142178) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142171 = ((2L) * (((long)(t$142170))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142172 = ((t$142171) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142173 = ((long[])t$142169.value)[(int)t$142172];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142174 = ((t$142168) - (((long)(t$142173))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$142218 = t$142174;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142177 = ((i$142178) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$142178 = t$142177;
                }
            }
            
            //#line 640 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$U>)t$142213).$set__1x10$lang$Rail$$T$G((long)(offset$142218), (($U)(accum)));
        }
        
        //#line 878 "x10/regionarray/Array.x10"
        return dst;
    }
    
    
    //#line 903 "x10/regionarray/Array.x10"
    /**
     * Asynchronously copy all of the values from the source Array to the 
     * Array referenced by the destination RemoteArray.
     * The two arrays must be defined over Regions with equal size 
     * bounding boxes; if the backing storage for the two arrays is 
     * not of equal size, then an IllegalArgumentExeption will be raised.<p>
     * 
     * The activity created to do the copying will be registered with the
     * dynamically enclosing finish.<p>
     * 
     * Warning: This method is only intended to be used on Arrays containing
     *   non-Object data elements.  The elements are actually copied via an
     *   optimized DMA operation if available.  Therefore object-references will
     *   not be properly transferred. Ideally, future versions of the X10 type
     *   system would enable this restriction to be checked statically.</p>
     * 
     * @param src the source array.
     * @param dst the destination array.
     * @throws IllegalArgumentException if mismatch in size of backing storage
     *         of the two arrays.
     */
    public static <$T>void asyncCopy__0$1x10$regionarray$Array$$T$2__1$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final x10.regionarray.RemoteArray<$T> dst) {
        
        //#line 904 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140460 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 904 "x10/regionarray/Array.x10"
        final x10.lang.GlobalRail t$140461 = ((x10.lang.GlobalRail)(((x10.regionarray.RemoteArray<$T>)dst).rawData));
        
        //#line 904 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140459 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 904 "x10/regionarray/Array.x10"
        final long t$140462 = ((x10.core.Rail<$T>)t$140459).size;
        
        //#line 904 "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> asyncCopy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$140460)), (long)(0L), ((x10.lang.GlobalRail)(t$140461)), (long)(0L), (long)(t$140462));
    }
    
    
    //#line 934 "x10/regionarray/Array.x10"
    /**
     * Asynchronously copy the specified values from the source Array to the 
     * specified portion of the Array referenced by the destination RemoteArray.
     * If accessing any point in either the specified source or the 
     * specified destination range would in an ArrayIndexOutOfBoundsError
     * being raised, then this method will throw an IllegalArgumentException.<p>
     * 
     * The activity created to do the copying will be registered with the
     * dynamically enclosing finish.<p>
     * 
     * Warning: This method is only intended to be used on Arrays containing
     *   non-Object data elements.  The elements are actually copied via an
     *   optimized DMA operation if available.  Therefore object-references will
     *   not be properly transferred. Ideally, future versions of the X10 type
     *   system would enable this restriction to be checked statically.</p>
     * 
     * @param src the source array.
     * @param srcPoint the first element in this array to be copied.  
     * @param dst the destination array.  May actually be local or remote
     * @param dstPoint the first element in the destination
     *                 array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     * 
     * @throws IllegalArgumentException if the specified copy regions would 
     *         result in an ArrayIndexOutOfBoundsException.
     */
    public static <$T>void asyncCopy__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final x10.lang.Point srcPoint, final x10.regionarray.RemoteArray<$T> dst, final x10.lang.Point dstPoint, final long numElems) {
        
        //#line 937 "x10/regionarray/Array.x10"
        final x10.core.GlobalRef gra = ((x10.core.GlobalRef)(((x10.regionarray.RemoteArray<$T>)dst).array));
        
        //#line 938 "x10/regionarray/Array.x10"
        final x10.lang.Place t$135981 = ((x10.lang.Place)((gra).home));
        
        //#line 938 "x10/regionarray/Array.x10"
        final long dstIndex = x10.core.Long.$unbox(x10.xrx.Runtime.<x10.core.Long> evalAt__1$1x10$xrx$Runtime$$T$2$G(x10.rtt.Types.LONG, ((x10.lang.Place)(t$135981)), ((x10.core.fun.Fun_0_0)(new x10.regionarray.Array.$Closure$158<$T>($T, gra, dstPoint, (x10.regionarray.Array.$Closure$158.__0$1x10$regionarray$Array$1x10$regionarray$Array$$Closure$158$$T$2$2) null))), ((x10.xrx.Runtime.Profile)(null))));
        
        //#line 939 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140463 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
        
        //#line 939 "x10/regionarray/Array.x10"
        final long srcIndex$139037 = t$140463.indexOf$O(((x10.lang.Point)(srcPoint)));
        
        //#line 981 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142232 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 981 . "x10/regionarray/Array.x10"
        final x10.lang.GlobalRail t$142233 = ((x10.lang.GlobalRail)(((x10.regionarray.RemoteArray<$T>)dst).rawData));
        
        //#line 981 . "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> asyncCopy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$142232)), (long)(srcIndex$139037), ((x10.lang.GlobalRail)(t$142233)), (long)(dstIndex), (long)(numElems));
    }
    
    
    //#line 978 "x10/regionarray/Array.x10"
    /**
     * Asynchronously copy the specified values from the source Array to the 
     * specified portion of the Array referenced by the destination RemoteArray.
     * The index arguments that are used to specify the start of the source
     * and destination regions are interpreted as of they were the result
     * of calling {@link Region#indexOf} on the Point that specifies the
     * start of the copy region.  Note that for Arrays that have the 
     * <code>rail</code> property, this exactly corresponds to the index
     * that would be used to access the element via apply or set.
     * If accessing any point in either the specified source or the 
     * specified destination range would in an ArrayIndexOutOfBoundsError
     * being raised, then this method will throw an IllegalArgumentException.<p>
     * 
     * The activity created to do the copying will be registered with the
     * dynamically enclosing finish.<p>
     * 
     * Warning: This method is only intended to be used on Arrays containing
     *   non-Object data elements.  The elements are actually copied via an
     *   optimized DMA operation if available.  Therefore object-references will
     *   not be properly transferred. Ideally, future versions of the X10 type
     *   system would enable this restriction to be checked statically.</p>
     * 
     * @param src the source array.
     * @param srcIndex the index of the first element in this array
     *        to be copied.  
     * @param dst the destination array.  May actually be local or remote
     * @param dstIndex the index of the first element in the destination
     *        array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     * 
     * @see Region#indexOf
     * 
     * @throws IllegalArgumentException if the specified copy regions would 
     *         result in an ArrayIndexOutOfBoundsException.
     */
    public static <$T>void asyncCopy__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final long srcIndex, final x10.regionarray.RemoteArray<$T> dst, final long dstIndex, final long numElems) {
        
        //#line 981 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140466 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 981 "x10/regionarray/Array.x10"
        final x10.lang.GlobalRail t$140467 = ((x10.lang.GlobalRail)(((x10.regionarray.RemoteArray<$T>)dst).rawData));
        
        //#line 981 "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> asyncCopy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$140466)), (long)(srcIndex), ((x10.lang.GlobalRail)(t$140467)), (long)(dstIndex), (long)(numElems));
    }
    
    
    //#line 1006 "x10/regionarray/Array.x10"
    /**
     * Asynchronously copy all of the values from the source Array 
     * referenced by the RemoteArray to the destination Array.
     * The two arrays must be defined over Regions with equal size 
     * bounding boxes; if the backing storage for the two arrays is 
     * not of equal size, then an IllegalArgumentExeption will be raised.<p>
     * 
     * The activity created to do the copying will be registered with the
     * dynamically enclosing finish.<p>
     * 
     * Warning: This method is only intended to be used on Arrays containing
     *   non-Object data elements.  The elements are actually copied via an
     *   optimized DMA operation if available.  Therefore object-references will
     *   not be properly transferred. Ideally, future versions of the X10 type
     *   system would enable this restriction to be checked statically.</p>
     * 
     * @param src the source array.
     * @param dst the destination array.
     * @throws IllegalArgumentException if mismatch in size of backing storage
     *         of the two arrays.
     */
    public static <$T>void asyncCopy__0$1x10$regionarray$Array$$T$2__1$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.RemoteArray<$T> src, final x10.regionarray.Array<$T> dst) {
        
        //#line 1007 "x10/regionarray/Array.x10"
        final x10.lang.GlobalRail t$140469 = ((x10.lang.GlobalRail)(((x10.regionarray.RemoteArray<$T>)src).rawData));
        
        //#line 1007 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140470 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1007 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140468 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1007 "x10/regionarray/Array.x10"
        final long t$140471 = ((x10.core.Rail<$T>)t$140468).size;
        
        //#line 1007 "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> asyncCopy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.lang.GlobalRail)(t$140469)), (long)(0L), ((x10.core.Rail)(t$140470)), (long)(0L), (long)(t$140471));
    }
    
    
    //#line 1037 "x10/regionarray/Array.x10"
    /**
     * Asynchronously copy the specified values from the Array referenced by
     * the source RemoteArray to the specified portion of the destination Array.
     * If accessing any point in either the specified source or the 
     * specified destination range would in an ArrayIndexOutOfBoundsError
     * being raised, then this method will throw an IllegalArgumentException.<p>
     * 
     * The activity created to do the copying will be registered with the
     * dynamically enclosing finish.<p>
     * 
     * Warning: This method is only intended to be used on Arrays containing
     *   non-Object data elements.  The elements are actually copied via an
     *   optimized DMA operation if available.  Therefore object-references will
     *   not be properly transferred. Ideally, future versions of the X10 type
     *   system would enable this restriction to be checked statically.</p>
     * 
     * @param src the source array.
     * @param srcPoint the first element in this array to be copied.  
     * @param dst the destination array.  May actually be local or remote
     * @param dstPoint the first element in the destination
     *                 array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     * 
     * @throws IllegalArgumentException if the specified copy regions would 
     *         result in an ArrayIndexOutOfBoundsException.
     */
    public static <$T>void asyncCopy__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.RemoteArray<$T> src, final x10.lang.Point srcPoint, final x10.regionarray.Array<$T> dst, final x10.lang.Point dstPoint, final long numElems) {
        
        //#line 1040 "x10/regionarray/Array.x10"
        final x10.core.GlobalRef gra = ((x10.core.GlobalRef)(((x10.regionarray.RemoteArray<$T>)src).array));
        
        //#line 1041 "x10/regionarray/Array.x10"
        final x10.lang.Place t$135985 = ((x10.lang.Place)((gra).home));
        
        //#line 1041 "x10/regionarray/Array.x10"
        final long srcIndex = x10.core.Long.$unbox(x10.xrx.Runtime.<x10.core.Long> evalAt__1$1x10$xrx$Runtime$$T$2$G(x10.rtt.Types.LONG, ((x10.lang.Place)(t$135985)), ((x10.core.fun.Fun_0_0)(new x10.regionarray.Array.$Closure$159<$T>($T, gra, srcPoint, (x10.regionarray.Array.$Closure$159.__0$1x10$regionarray$Array$1x10$regionarray$Array$$Closure$159$$T$2$2) null))), ((x10.xrx.Runtime.Profile)(null))));
        
        //#line 1042 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140472 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)dst).region));
        
        //#line 1042 "x10/regionarray/Array.x10"
        final long dstIndex$139045 = t$140472.indexOf$O(((x10.lang.Point)(dstPoint)));
        
        //#line 1084 . "x10/regionarray/Array.x10"
        final x10.lang.GlobalRail t$142234 = ((x10.lang.GlobalRail)(((x10.regionarray.RemoteArray<$T>)src).rawData));
        
        //#line 1084 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142235 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1084 . "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> asyncCopy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.lang.GlobalRail)(t$142234)), (long)(srcIndex), ((x10.core.Rail)(t$142235)), (long)(dstIndex$139045), (long)(numElems));
    }
    
    
    //#line 1081 "x10/regionarray/Array.x10"
    /**
     * Asynchronously copy the specified values from the Array referenced by
     * the source RemoteArray to the specified portion of the destination Array.
     * The index arguments that are used to specify the start of the source
     * and destination regions are interpreted as of they were the result
     * of calling {@link Region#indexOf} on the Point that specifies the
     * start of the copy region.  Note that for Arrays that have the 
     * <code>rail</code> property, this exactly corresponds to the index
     * that would be used to access the element via apply or set.
     * If accessing any point in either the specified source or the 
     * specified destination range would in an ArrayIndexOutOfBoundsError
     * being raised, then this method will throw an IllegalArgumentException.<p>
     * 
     * The activity created to do the copying will be registered with the
     * dynamically enclosing finish.<p>
     * 
     * Warning: This method is only intended to be used on Arrays containing
     *   non-Object data elements.  The elements are actually copied via an
     *   optimized DMA operation if available.  Therefore object-references will
     *   not be properly transferred. Ideally, future versions of the X10 type
     *   system would enable this restriction to be checked statically.</p>
     * 
     * @param src the source array.
     * @param srcIndex the index of the first element in this array
     *        to be copied.  
     * @param dst the destination array.  May actually be local or remote
     * @param dstIndex the index of the first element in the destination
     *        array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     * 
     * @see Region#indexOf
     * 
     * @throws IllegalArgumentException if the specified copy regions would 
     *         result in an ArrayIndexOutOfBoundsException.
     */
    public static <$T>void asyncCopy__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.RemoteArray<$T> src, final long srcIndex, final x10.regionarray.Array<$T> dst, final long dstIndex, final long numElems) {
        
        //#line 1084 "x10/regionarray/Array.x10"
        final x10.lang.GlobalRail t$140475 = ((x10.lang.GlobalRail)(((x10.regionarray.RemoteArray<$T>)src).rawData));
        
        //#line 1084 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140476 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1084 "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> asyncCopy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.lang.GlobalRail)(t$140475)), (long)(srcIndex), ((x10.core.Rail)(t$140476)), (long)(dstIndex), (long)(numElems));
    }
    
    
    //#line 1099 "x10/regionarray/Array.x10"
    /**
     * Copy all of the values from the source Array to the destination Array.
     * The two arrays must be defined over Regions with equal size 
     * bounding boxes; if the backing storage for the two arrays is 
     * not of equal size, then an IllegalArgumentExeption will be raised.<p>
     * 
     * @param src the source array.
     * @param dst the destination array.
     * @throws IllegalArgumentException if mismatch in size of backing storage
     *         of the two arrays.
     */
    public static <$T>void copy__0$1x10$regionarray$Array$$T$2__1$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final x10.regionarray.Array<$T> dst) {
        
        //#line 1100 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140478 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 1100 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140479 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1100 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140477 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 1100 "x10/regionarray/Array.x10"
        final long t$140480 = ((x10.core.Rail<$T>)t$140477).size;
        
        //#line 1100 "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> copy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$140478)), (long)(0L), ((x10.core.Rail)(t$140479)), (long)(0L), (long)(t$140480));
    }
    
    
    //#line 1121 "x10/regionarray/Array.x10"
    /**
     * Copy the specified values from the source Array to the 
     * specified portion of the destination Array.
     * If accessing any point in either the specified source or the 
     * specified destination range would in an ArrayIndexOutOfBoundsError
     * being raised, then this method will throw an IllegalArgumentException.<p>
     * 
     * @param src the source array.
     * @param srcPoint the first element in this array to be copied.  
     * @param dst the destination array.  May actually be local or remote
     * @param dstPoint the first element in the destination
     *                 array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     * 
     * @throws IllegalArgumentException if the specified copy regions would 
     *         result in an ArrayIndexOutOfBoundsException.
     */
    public static <$T>void copy__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final x10.lang.Point srcPoint, final x10.regionarray.Array<$T> dst, final x10.lang.Point dstPoint, final long numElems) {
        
        //#line 1124 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140481 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
        
        //#line 1124 "x10/regionarray/Array.x10"
        final long srcIndex$139049 = t$140481.indexOf$O(((x10.lang.Point)(srcPoint)));
        
        //#line 1124 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140482 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)dst).region));
        
        //#line 1124 "x10/regionarray/Array.x10"
        final long dstIndex$139051 = t$140482.indexOf$O(((x10.lang.Point)(dstPoint)));
        
        //#line 1157 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142236 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 1157 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142237 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1157 . "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> copy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$142236)), (long)(srcIndex$139049), ((x10.core.Rail)(t$142237)), (long)(dstIndex$139051), (long)(numElems));
    }
    
    
    //#line 1154 "x10/regionarray/Array.x10"
    /**
     * Copy the specified values from the source Array to the 
     * specified portion of the destination Array.
     * The index arguments that are used to specify the start of the source
     * and destination regions are interpreted as of they were the result
     * of calling {@link Region#indexOf} on the Point that specifies the
     * start of the copy region.  Note that for Arrays that have the 
     * <code>rail</code> property, this exactly corresponds to the index
     * that would be used to access the element via apply or set.
     * If accessing any point in either the specified source or the 
     * specified destination range would in an ArrayIndexOutOfBoundsError
     * being raised, then this method will throw an IllegalArgumentException.<p>
     * 
     * @param src the source array.
     * @param srcIndex the index of the first element in this array
     *        to be copied.  
     * @param dst the destination array.  May actually be local or remote
     * @param dstIndex the index of the first element in the destination
     *        array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     * 
     * @see Region#indexOf
     * 
     * @throws IllegalArgumentException if the specified copy regions would 
     *         result in an ArrayIndexOutOfBoundsException.
     */
    public static <$T>void copy__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final long srcIndex, final x10.regionarray.Array<$T> dst, final long dstIndex, final long numElems) {
        
        //#line 1157 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140485 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 1157 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140486 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1157 "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> copy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$140485)), (long)(srcIndex), ((x10.core.Rail)(t$140486)), (long)(dstIndex), (long)(numElems));
    }
    
    
    //#line 1174 "x10/regionarray/Array.x10"
    /**
     * Copy the specified region from the source Array to this array.
     * If the specified region is not contained in the region for the source
     * array or this array, then an ArrayIndexOutOfBoundsError is raised.
     * 
     * @param src the source array.
     * @param region the region of the array to copy to this array
     * 
     * @see Region#indexOf
     * 
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in the source array or this array
     */
    public void copy__0$1x10$regionarray$Array$$T$2(final x10.regionarray.Array src, final x10.regionarray.Region r) {
        
        //#line 1176 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$142326 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
        
        //#line 1176 "x10/regionarray/Array.x10"
        final boolean t$142327 = t$142326.contains$O(((x10.regionarray.Region)(r)));
        
        //#line 1176 "x10/regionarray/Array.x10"
        final boolean t$142328 = !(t$142327);
        
        //#line 1176 "x10/regionarray/Array.x10"
        if (t$142328) {
            
            //#line 1177 "x10/regionarray/Array.x10"
            final java.lang.String t$142329 = (("region to copy: ") + (r));
            
            //#line 1177 "x10/regionarray/Array.x10"
            final java.lang.String t$142330 = ((t$142329) + (" not contained in source: "));
            
            //#line 1177 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142331 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1177 "x10/regionarray/Array.x10"
            final java.lang.String t$142332 = ((t$142330) + (t$142331));
            
            //#line 1177 "x10/regionarray/Array.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$142333 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$142332)));
            
            //#line 1177 "x10/regionarray/Array.x10"
            throw t$142333;
        } else {
            
            //#line 1178 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142334 = ((x10.regionarray.Region)(this.region));
            
            //#line 1178 "x10/regionarray/Array.x10"
            final boolean t$142335 = t$142334.contains$O(((x10.regionarray.Region)(r)));
            
            //#line 1178 "x10/regionarray/Array.x10"
            final boolean t$142336 = !(t$142335);
            
            //#line 1178 "x10/regionarray/Array.x10"
            if (t$142336) {
                
                //#line 1179 "x10/regionarray/Array.x10"
                final java.lang.String t$142337 = (("region to copy: ") + (r));
                
                //#line 1179 "x10/regionarray/Array.x10"
                final java.lang.String t$142338 = ((t$142337) + (" not contained in this array: "));
                
                //#line 1179 "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$142339 = ((x10.regionarray.Region)(this.region));
                
                //#line 1179 "x10/regionarray/Array.x10"
                final java.lang.String t$142340 = ((t$142338) + (t$142339));
                
                //#line 1179 "x10/regionarray/Array.x10"
                final java.lang.ArrayIndexOutOfBoundsException t$142341 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$142340)));
                
                //#line 1179 "x10/regionarray/Array.x10"
                throw t$142341;
            }
        }
        
        //#line 1182 "x10/regionarray/Array.x10"
        final long t$140503 = this.rank;
        
        //#line 1182 "x10/regionarray/Array.x10"
        boolean t$140504 = ((long) t$140503) == ((long) 3L);
        
        //#line 1182 "x10/regionarray/Array.x10"
        if (t$140504) {
            
            //#line 1182 "x10/regionarray/Array.x10"
            t$140504 = r.rect;
        }
        
        //#line 1182 "x10/regionarray/Array.x10"
        if (t$140504) {
            
            //#line 1183 "x10/regionarray/Array.x10"
            final x10.regionarray.Array t$136389 = ((x10.regionarray.Array<$T>)
                                                     this);
            
            //#line 1183 "x10/regionarray/Array.x10"
            final long t$140505 = ((x10.regionarray.Array<$T>)t$136389).rank;
            
            //#line 1183 "x10/regionarray/Array.x10"
            final boolean t$140506 = ((long) t$140505) == ((long) 3L);
            
            //#line 1183 "x10/regionarray/Array.x10"
            final boolean t$140508 = !(t$140506);
            
            //#line 1183 "x10/regionarray/Array.x10"
            if (t$140508) {
                
                //#line 1183 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$140507 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Array[T]{self.rank==3L}");
                
                //#line 1183 "x10/regionarray/Array.x10"
                throw t$140507;
            }
            
            //#line 1183 "x10/regionarray/Array.x10"
            final x10.regionarray.Array t$136391 = ((x10.regionarray.Array<$T>)
                                                     src);
            
            //#line 1183 "x10/regionarray/Array.x10"
            final long t$140509 = ((x10.regionarray.Array<$T>)t$136391).rank;
            
            //#line 1183 "x10/regionarray/Array.x10"
            final boolean t$140510 = ((long) t$140509) == ((long) 3L);
            
            //#line 1183 "x10/regionarray/Array.x10"
            final boolean t$140512 = !(t$140510);
            
            //#line 1183 "x10/regionarray/Array.x10"
            if (t$140512) {
                
                //#line 1183 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$140511 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Array[T]{self.rank==3L}");
                
                //#line 1183 "x10/regionarray/Array.x10"
                throw t$140511;
            }
            
            //#line 1183 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$136393 = ((x10.regionarray.Region)
                                                      r);
            
            //#line 1183 "x10/regionarray/Array.x10"
            final boolean t$140513 = t$136393.rect;
            
            //#line 1183 "x10/regionarray/Array.x10"
            boolean t$140515 = ((boolean) t$140513) == ((boolean) true);
            
            //#line 1183 "x10/regionarray/Array.x10"
            if (t$140515) {
                
                //#line 1183 "x10/regionarray/Array.x10"
                final long t$140514 = t$136393.rank;
                
                //#line 1183 "x10/regionarray/Array.x10"
                t$140515 = ((long) t$140514) == ((long) 3L);
            }
            
            //#line 1183 "x10/regionarray/Array.x10"
            final boolean t$140518 = !(t$140515);
            
            //#line 1183 "x10/regionarray/Array.x10"
            if (t$140518) {
                
                //#line 1183 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$140517 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==3L}");
                
                //#line 1183 "x10/regionarray/Array.x10"
                throw t$140517;
            }
            
            //#line 1183 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)t$136389).copy3__0$1x10$regionarray$Array$$T$2(((x10.regionarray.Array)(t$136391)), ((x10.regionarray.Region)(t$136393)));
            
            //#line 1184 "x10/regionarray/Array.x10"
            return;
        }
        
        //#line 1187 "x10/regionarray/Array.x10"
        final x10.core.Rail srcRaw = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 1188 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140520 = ((x10.regionarray.Region)(this.region));
        
        //#line 1188 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140521 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
        
        //#line 1188 "x10/regionarray/Array.x10"
        final boolean t$140595 = x10.rtt.Equality.equalsequals((t$140520),(t$140521));
        
        //#line 1188 "x10/regionarray/Array.x10"
        if (t$140595) {
            
            //#line 1190 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$137958 = r.iterator();
            
            //#line 1190 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1190 "x10/regionarray/Array.x10"
                final boolean t$140526 = ((x10.lang.Iterator<x10.lang.Point>)p$137958).hasNext$O();
                
                //#line 1190 "x10/regionarray/Array.x10"
                if (!(t$140526)) {
                    
                    //#line 1190 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1190 "x10/regionarray/Array.x10"
                final x10.lang.Point p$142238 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$137958).next$G()));
                
                //#line 1191 "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$142239 = ((x10.regionarray.Region)(this.region));
                
                //#line 1191 "x10/regionarray/Array.x10"
                final long offset$142240 = t$142239.indexOf$O(((x10.lang.Point)(p$142238)));
                
                //#line 1192 "x10/regionarray/Array.x10"
                final x10.core.Rail t$142241 = ((x10.core.Rail)(this.raw));
                
                //#line 1192 "x10/regionarray/Array.x10"
                final $T t$142242 = (($T)(((x10.core.Rail<$T>)srcRaw).$apply$G((long)(offset$142240))));
                
                //#line 1192 "x10/regionarray/Array.x10"
                ((x10.core.Rail<$T>)t$142241).$set__1x10$lang$Rail$$T$G((long)(offset$142240), (($T)(t$142242)));
            }
        } else {
            
            //#line 1196 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140527 = ((x10.regionarray.Region)(this.region));
            
            //#line 1196 "x10/regionarray/Array.x10"
            final x10.core.fun.Fun_0_1 min = t$140527.min();
            
            //#line 1197 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140528 = ((x10.regionarray.Region)(this.region));
            
            //#line 1197 "x10/regionarray/Array.x10"
            t$140528.max();
            
            //#line 1198 "x10/regionarray/Array.x10"
            final x10.regionarray.Array delta = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.core.Long>((java.lang.System[]) null, x10.rtt.Types.LONG)));
            
            //#line 1198 "x10/regionarray/Array.x10"
            final long size$139054 = this.rank;
            
            //#line 314 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$142316 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 314 . "x10/regionarray/Array.x10"
            final long t$142256 = ((size$139054) - (((long)(1L))));
            
            //#line 314 . "x10/regionarray/Array.x10"
            myReg$142316.x10$regionarray$RectRegion1D$$init$S(t$142256);
            
            //#line 315 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142257 = ((x10.regionarray.Region)
                                                      myReg$142316);
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).region = ((x10.regionarray.Region)(t$142257));
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).rank = 1L;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).rect = true;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).zeroBased = true;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).rail = true;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).size = size$139054;
            
            //#line 317 . "x10/regionarray/Array.x10"
            final long t$142317 = ((x10.regionarray.Array<x10.core.Long>)delta).layout_min1 = 0L;
            
            //#line 317 . "x10/regionarray/Array.x10"
            final long t$142318 = ((x10.regionarray.Array<x10.core.Long>)delta).layout_stride1 = t$142317;
            
            //#line 317 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).layout_min0 = t$142318;
            
            //#line 318 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).layout = null;
            
            //#line 319 . "x10/regionarray/Array.x10"
            final x10.core.Rail r$142319 = ((x10.core.Rail)(x10.core.Rail.<x10.core.Long>makeUnsafe(x10.rtt.Types.LONG, ((long)(size$139054)), false)));
            
            //#line 320 . "x10/regionarray/Array.x10"
            final long i$137890max$142258 = ((size$139054) - (((long)(1L))));
            
            //#line 320 . "x10/regionarray/Array.x10"
            long i$142253 = 0L;
            {
                
                //#line 320 . "x10/regionarray/Array.x10"
                final long[] r$142319$value$142485 = ((long[])r$142319.value);
                
                //#line 320 . "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    final boolean t$142255 = ((i$142253) <= (((long)(i$137890max$142258))));
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    if (!(t$142255)) {
                        
                        //#line 320 . "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1198 .. "x10/regionarray/Array.x10"
                    final x10.regionarray.Region t$142244 = ((x10.regionarray.Region)(this.region));
                    
                    //#line 1198 .. "x10/regionarray/Array.x10"
                    final long t$142245 = t$142244.max$O((long)(i$142253));
                    
                    //#line 1198 .. "x10/regionarray/Array.x10"
                    final x10.regionarray.Region t$142246 = ((x10.regionarray.Region)(this.region));
                    
                    //#line 1198 .. "x10/regionarray/Array.x10"
                    final long t$142247 = t$142246.min$O((long)(i$142253));
                    
                    //#line 1198 .. "x10/regionarray/Array.x10"
                    final long t$142248 = ((t$142245) - (((long)(t$142247))));
                    
                    //#line 1198 .. "x10/regionarray/Array.x10"
                    final long t$142249 = ((t$142248) + (((long)(1L))));
                    
                    //#line 321 . "x10/regionarray/Array.x10"
                    r$142319$value$142485[(int)i$142253]=t$142249;
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    final long t$142252 = ((i$142253) + (((long)(1L))));
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    i$142253 = t$142252;
                }
            }
            
            //#line 323 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).raw = ((x10.core.Rail)(r$142319));
            
            //#line 1199 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140544 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1199 "x10/regionarray/Array.x10"
            final x10.core.fun.Fun_0_1 srcMin = t$140544.min();
            
            //#line 1200 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140545 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1200 "x10/regionarray/Array.x10"
            t$140545.max();
            
            //#line 1201 "x10/regionarray/Array.x10"
            final x10.regionarray.Array srcDelta = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.core.Long>((java.lang.System[]) null, x10.rtt.Types.LONG)));
            
            //#line 1201 "x10/regionarray/Array.x10"
            final long size$139066 = this.rank;
            
            //#line 314 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$142320 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 314 . "x10/regionarray/Array.x10"
            final long t$142272 = ((size$139066) - (((long)(1L))));
            
            //#line 314 . "x10/regionarray/Array.x10"
            myReg$142320.x10$regionarray$RectRegion1D$$init$S(t$142272);
            
            //#line 315 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142273 = ((x10.regionarray.Region)
                                                      myReg$142320);
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).region = ((x10.regionarray.Region)(t$142273));
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).rank = 1L;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).rect = true;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).zeroBased = true;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).rail = true;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).size = size$139066;
            
            //#line 317 . "x10/regionarray/Array.x10"
            final long t$142321 = ((x10.regionarray.Array<x10.core.Long>)srcDelta).layout_min1 = 0L;
            
            //#line 317 . "x10/regionarray/Array.x10"
            final long t$142322 = ((x10.regionarray.Array<x10.core.Long>)srcDelta).layout_stride1 = t$142321;
            
            //#line 317 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).layout_min0 = t$142322;
            
            //#line 318 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).layout = null;
            
            //#line 319 . "x10/regionarray/Array.x10"
            final x10.core.Rail r$142323 = ((x10.core.Rail)(x10.core.Rail.<x10.core.Long>makeUnsafe(x10.rtt.Types.LONG, ((long)(size$139066)), false)));
            
            //#line 320 . "x10/regionarray/Array.x10"
            final long i$137890max$142274 = ((size$139066) - (((long)(1L))));
            
            //#line 320 . "x10/regionarray/Array.x10"
            long i$142269 = 0L;
            {
                
                //#line 320 . "x10/regionarray/Array.x10"
                final long[] r$142323$value$142486 = ((long[])r$142323.value);
                
                //#line 320 . "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    final boolean t$142271 = ((i$142269) <= (((long)(i$137890max$142274))));
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    if (!(t$142271)) {
                        
                        //#line 320 . "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1201 .. "x10/regionarray/Array.x10"
                    final x10.regionarray.Region t$142260 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
                    
                    //#line 1201 .. "x10/regionarray/Array.x10"
                    final long t$142261 = t$142260.max$O((long)(i$142269));
                    
                    //#line 1201 .. "x10/regionarray/Array.x10"
                    final x10.regionarray.Region t$142262 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
                    
                    //#line 1201 .. "x10/regionarray/Array.x10"
                    final long t$142263 = t$142262.min$O((long)(i$142269));
                    
                    //#line 1201 .. "x10/regionarray/Array.x10"
                    final long t$142264 = ((t$142261) - (((long)(t$142263))));
                    
                    //#line 1201 .. "x10/regionarray/Array.x10"
                    final long t$142265 = ((t$142264) + (((long)(1L))));
                    
                    //#line 321 . "x10/regionarray/Array.x10"
                    r$142323$value$142486[(int)i$142269]=t$142265;
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    final long t$142268 = ((i$142269) + (((long)(1L))));
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    i$142269 = t$142268;
                }
            }
            
            //#line 323 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).raw = ((x10.core.Rail)(r$142323));
            
            //#line 1202 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$142324 = r.iterator();
            
            //#line 1202 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1202 "x10/regionarray/Array.x10"
                final boolean t$142325 = ((x10.lang.Iterator<x10.lang.Point>)p$142324).hasNext$O();
                
                //#line 1202 "x10/regionarray/Array.x10"
                if (!(t$142325)) {
                    
                    //#line 1202 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1202 "x10/regionarray/Array.x10"
                final x10.lang.Point p$142305 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$142324).next$G()));
                
                //#line 1203 "x10/regionarray/Array.x10"
                final long t$142306 = p$142305.$apply$O((long)(0L));
                
                //#line 1203 "x10/regionarray/Array.x10"
                final long t$142307 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)min).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                
                //#line 1203 "x10/regionarray/Array.x10"
                long offset$142308 = ((t$142306) - (((long)(t$142307))));
                
                //#line 1204 "x10/regionarray/Array.x10"
                final long t$142309 = p$142305.$apply$O((long)(0L));
                
                //#line 1204 "x10/regionarray/Array.x10"
                final long t$142310 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)srcMin).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                
                //#line 1204 "x10/regionarray/Array.x10"
                long srcOffset$142311 = ((t$142309) - (((long)(t$142310))));
                
                //#line 1205 "x10/regionarray/Array.x10"
                final long t$142303 = this.rank;
                
                //#line 1205 "x10/regionarray/Array.x10"
                final long i$137960max$142304 = ((t$142303) - (((long)(1L))));
                
                //#line 1205 "x10/regionarray/Array.x10"
                long i$142300 = 1L;
                
                //#line 1205 "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1205 "x10/regionarray/Array.x10"
                    final boolean t$142302 = ((i$142300) <= (((long)(i$137960max$142304))));
                    
                    //#line 1205 "x10/regionarray/Array.x10"
                    if (!(t$142302)) {
                        
                        //#line 1205 "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    long ret$142281 =  0;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142275 = ((x10.core.Rail)(((x10.regionarray.Array<x10.core.Long>)delta).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final long t$142276 = ((long[])t$142275.value)[(int)i$142300];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$142281 = t$142276;
                    
                    //#line 1206 "x10/regionarray/Array.x10"
                    final long t$142283 = ((offset$142308) * (((long)(ret$142281))));
                    
                    //#line 1206 "x10/regionarray/Array.x10"
                    final long t$142284 = p$142305.$apply$O((long)(i$142300));
                    
                    //#line 1206 "x10/regionarray/Array.x10"
                    final long t$142285 = ((t$142283) + (((long)(t$142284))));
                    
                    //#line 1206 "x10/regionarray/Array.x10"
                    final long t$142286 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)min).$apply(x10.core.Long.$box(i$142300), x10.rtt.Types.LONG));
                    
                    //#line 1206 "x10/regionarray/Array.x10"
                    final long t$142287 = ((t$142285) - (((long)(t$142286))));
                    
                    //#line 1206 "x10/regionarray/Array.x10"
                    offset$142308 = t$142287;
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    long ret$142290 =  0;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142277 = ((x10.core.Rail)(((x10.regionarray.Array<x10.core.Long>)srcDelta).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final long t$142278 = ((long[])t$142277.value)[(int)i$142300];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$142290 = t$142278;
                    
                    //#line 1207 "x10/regionarray/Array.x10"
                    final long t$142292 = ((srcOffset$142311) * (((long)(ret$142290))));
                    
                    //#line 1207 "x10/regionarray/Array.x10"
                    final long t$142293 = p$142305.$apply$O((long)(i$142300));
                    
                    //#line 1207 "x10/regionarray/Array.x10"
                    final long t$142294 = ((t$142292) + (((long)(t$142293))));
                    
                    //#line 1207 "x10/regionarray/Array.x10"
                    final long t$142295 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)srcMin).$apply(x10.core.Long.$box(i$142300), x10.rtt.Types.LONG));
                    
                    //#line 1207 "x10/regionarray/Array.x10"
                    final long t$142296 = ((t$142294) - (((long)(t$142295))));
                    
                    //#line 1207 "x10/regionarray/Array.x10"
                    srcOffset$142311 = t$142296;
                    
                    //#line 1205 "x10/regionarray/Array.x10"
                    final long t$142299 = ((i$142300) + (((long)(1L))));
                    
                    //#line 1205 "x10/regionarray/Array.x10"
                    i$142300 = t$142299;
                }
                
                //#line 1209 "x10/regionarray/Array.x10"
                final x10.core.Rail t$142312 = ((x10.core.Rail)(this.raw));
                
                //#line 1209 "x10/regionarray/Array.x10"
                final $T t$142315 = (($T)(((x10.core.Rail<$T>)srcRaw).$apply$G((long)(srcOffset$142311))));
                
                //#line 1209 "x10/regionarray/Array.x10"
                ((x10.core.Rail<$T>)t$142312).$set__1x10$lang$Rail$$T$G((long)(offset$142308), (($T)(t$142315)));
            }
        }
    }
    
    
    //#line 1214 "x10/regionarray/Array.x10"
    private void copy3__0$1x10$regionarray$Array$$T$2(final x10.regionarray.Array src, final x10.regionarray.Region r) {
        
        //#line 1215 "x10/regionarray/Array.x10"
        final x10.core.Rail srcRaw = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 1216 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140597 = ((x10.regionarray.Region)(this.region));
        
        //#line 1216 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140598 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
        
        //#line 1216 "x10/regionarray/Array.x10"
        final boolean t$140653 = x10.rtt.Equality.equalsequals((t$140597),(t$140598));
        
        //#line 1216 "x10/regionarray/Array.x10"
        if (t$140653) {
            
            //#line 1218 "x10/regionarray/Array.x10"
            final long k$137981min$137982 = r.min$O((long)(2L));
            
            //#line 1218 "x10/regionarray/Array.x10"
            final long k$137981max$137983 = r.max$O((long)(2L));
            
            //#line 1218 "x10/regionarray/Array.x10"
            final long j$138000min$138001 = r.min$O((long)(1L));
            
            //#line 1218 "x10/regionarray/Array.x10"
            final long j$138000max$138002 = r.max$O((long)(1L));
            
            //#line 1218 "x10/regionarray/Array.x10"
            final long i$138019min$138020 = r.min$O((long)(0L));
            
            //#line 1218 "x10/regionarray/Array.x10"
            final long i$138019max$138021 = r.max$O((long)(0L));
            
            //#line 1218 "x10/regionarray/Array.x10"
            long i$142363 = i$138019min$138020;
            
            //#line 1218 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1218 "x10/regionarray/Array.x10"
                final boolean t$142365 = ((i$142363) <= (((long)(i$138019max$138021))));
                
                //#line 1218 "x10/regionarray/Array.x10"
                if (!(t$142365)) {
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1218 "x10/regionarray/Array.x10"
                long j$142357 = j$138000min$138001;
                
                //#line 1218 "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    final boolean t$142359 = ((j$142357) <= (((long)(j$138000max$138002))));
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    if (!(t$142359)) {
                        
                        //#line 1218 "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    long k$142351 = k$137981min$137982;
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1218 "x10/regionarray/Array.x10"
                        final boolean t$142353 = ((k$142351) <= (((long)(k$137981max$137983))));
                        
                        //#line 1218 "x10/regionarray/Array.x10"
                        if (!(t$142353)) {
                            
                            //#line 1218 "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1219 "x10/regionarray/Array.x10"
                        final x10.regionarray.Region t$142342 = ((x10.regionarray.Region)(this.region));
                        
                        //#line 1219 "x10/regionarray/Array.x10"
                        final x10.core.Rail r$142343 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {i$142363, j$142357, k$142351})));
                        
                        //#line 162 . "x10/lang/Point.x10"
                        final x10.lang.Point t$142344 = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(r$142343)))));
                        
                        //#line 1219 "x10/regionarray/Array.x10"
                        final long offset$142345 = t$142342.indexOf$O(((x10.lang.Point)(t$142344)));
                        
                        //#line 1220 "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142346 = ((x10.core.Rail)(this.raw));
                        
                        //#line 1220 "x10/regionarray/Array.x10"
                        final $T t$142347 = (($T)(((x10.core.Rail<$T>)srcRaw).$apply$G((long)(offset$142345))));
                        
                        //#line 1220 "x10/regionarray/Array.x10"
                        ((x10.core.Rail<$T>)t$142346).$set__1x10$lang$Rail$$T$G((long)(offset$142345), (($T)(t$142347)));
                        
                        //#line 1218 "x10/regionarray/Array.x10"
                        final long t$142350 = ((k$142351) + (((long)(1L))));
                        
                        //#line 1218 "x10/regionarray/Array.x10"
                        k$142351 = t$142350;
                    }
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    final long t$142356 = ((j$142357) + (((long)(1L))));
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    j$142357 = t$142356;
                }
                
                //#line 1218 "x10/regionarray/Array.x10"
                final long t$142362 = ((i$142363) + (((long)(1L))));
                
                //#line 1218 "x10/regionarray/Array.x10"
                i$142363 = t$142362;
            }
        } else {
            
            //#line 1223 "x10/regionarray/Array.x10"
            final x10.core.Rail t$140618 = ((x10.core.Rail)(this.layout));
            
            //#line 1223 "x10/regionarray/Array.x10"
            final long layout_stride2 = ((long[])t$140618.value)[(int)0L];
            
            //#line 1224 "x10/regionarray/Array.x10"
            final x10.core.Rail t$140619 = ((x10.core.Rail)(this.layout));
            
            //#line 1224 "x10/regionarray/Array.x10"
            final long layout_stride3 = ((long[])t$140619.value)[(int)1L];
            
            //#line 1226 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 1226 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142407 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1226 "x10/regionarray/Array.x10"
            crh.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(t$142407)));
            
            //#line 1227 "x10/regionarray/Array.x10"
            final long src_min0 = crh.min0;
            
            //#line 1228 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140621 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1228 "x10/regionarray/Array.x10"
            final long src_max0 = t$140621.max$O((long)(0L));
            
            //#line 1229 "x10/regionarray/Array.x10"
            final long src_stride1 = crh.stride1;
            
            //#line 1230 "x10/regionarray/Array.x10"
            final long src_min1 = crh.min1;
            
            //#line 1231 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140622 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1231 "x10/regionarray/Array.x10"
            final long src_max1 = t$140622.max$O((long)(1L));
            
            //#line 1232 "x10/regionarray/Array.x10"
            final x10.core.Rail src_layout = ((x10.core.Rail)(crh.layout));
            
            //#line 1233 "x10/regionarray/Array.x10"
            final long src_stride2 = ((long[])src_layout.value)[(int)0L];
            
            //#line 1234 "x10/regionarray/Array.x10"
            final long src_stride3 = ((long[])src_layout.value)[(int)1L];
            
            //#line 1235 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140623 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1235 "x10/regionarray/Array.x10"
            final long src_min2 = t$140623.min$O((long)(2L));
            
            //#line 1236 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140624 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1236 "x10/regionarray/Array.x10"
            final long src_max2 = t$140624.max$O((long)(2L));
            
            //#line 1238 "x10/regionarray/Array.x10"
            long i$142404 = src_min0;
            
            //#line 1238 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1238 "x10/regionarray/Array.x10"
                final boolean t$142406 = ((i$142404) <= (((long)(src_max0))));
                
                //#line 1238 "x10/regionarray/Array.x10"
                if (!(t$142406)) {
                    
                    //#line 1238 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1239 "x10/regionarray/Array.x10"
                final long t$142395 = this.layout_min0;
                
                //#line 1239 "x10/regionarray/Array.x10"
                final long t$142396 = ((i$142404) - (((long)(t$142395))));
                
                //#line 1239 "x10/regionarray/Array.x10"
                final long t$142397 = this.layout_stride1;
                
                //#line 1239 "x10/regionarray/Array.x10"
                final long offset$142398 = ((t$142396) * (((long)(t$142397))));
                
                //#line 1240 "x10/regionarray/Array.x10"
                final long t$142399 = ((i$142404) - (((long)(src_min0))));
                
                //#line 1240 "x10/regionarray/Array.x10"
                final long srcOffset$142400 = ((t$142399) * (((long)(src_stride1))));
                
                //#line 1241 "x10/regionarray/Array.x10"
                long i$142390 = src_min1;
                
                //#line 1241 "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1241 "x10/regionarray/Array.x10"
                    final boolean t$142392 = ((i$142390) <= (((long)(src_max1))));
                    
                    //#line 1241 "x10/regionarray/Array.x10"
                    if (!(t$142392)) {
                        
                        //#line 1241 "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1242 "x10/regionarray/Array.x10"
                    final long t$142380 = ((offset$142398) + (((long)(i$142390))));
                    
                    //#line 1242 "x10/regionarray/Array.x10"
                    final long t$142381 = this.layout_min1;
                    
                    //#line 1242 "x10/regionarray/Array.x10"
                    final long t$142382 = ((t$142380) - (((long)(t$142381))));
                    
                    //#line 1242 "x10/regionarray/Array.x10"
                    final long offset$142383 = ((t$142382) * (((long)(layout_stride2))));
                    
                    //#line 1243 "x10/regionarray/Array.x10"
                    final long t$142384 = ((srcOffset$142400) + (((long)(i$142390))));
                    
                    //#line 1243 "x10/regionarray/Array.x10"
                    final long t$142385 = ((t$142384) - (((long)(src_min1))));
                    
                    //#line 1243 "x10/regionarray/Array.x10"
                    final long srcOffset$142386 = ((t$142385) * (((long)(src_stride2))));
                    
                    //#line 1244 "x10/regionarray/Array.x10"
                    long i$142375 = src_min2;
                    
                    //#line 1244 "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1244 "x10/regionarray/Array.x10"
                        final boolean t$142377 = ((i$142375) <= (((long)(src_max2))));
                        
                        //#line 1244 "x10/regionarray/Array.x10"
                        if (!(t$142377)) {
                            
                            //#line 1244 "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1245 "x10/regionarray/Array.x10"
                        final long t$142366 = ((offset$142383) + (((long)(i$142375))));
                        
                        //#line 1245 "x10/regionarray/Array.x10"
                        final long offset$142367 = ((t$142366) - (((long)(layout_stride3))));
                        
                        //#line 1246 "x10/regionarray/Array.x10"
                        final long t$142368 = ((srcOffset$142386) + (((long)(i$142375))));
                        
                        //#line 1246 "x10/regionarray/Array.x10"
                        final long srcOffset$142369 = ((t$142368) - (((long)(src_stride3))));
                        
                        //#line 1247 "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142370 = ((x10.core.Rail)(this.raw));
                        
                        //#line 1247 "x10/regionarray/Array.x10"
                        final $T t$142371 = (($T)(((x10.core.Rail<$T>)srcRaw).$apply$G((long)(srcOffset$142369))));
                        
                        //#line 1247 "x10/regionarray/Array.x10"
                        ((x10.core.Rail<$T>)t$142370).$set__1x10$lang$Rail$$T$G((long)(offset$142367), (($T)(t$142371)));
                        
                        //#line 1244 "x10/regionarray/Array.x10"
                        final long t$142374 = ((i$142375) + (((long)(1L))));
                        
                        //#line 1244 "x10/regionarray/Array.x10"
                        i$142375 = t$142374;
                    }
                    
                    //#line 1241 "x10/regionarray/Array.x10"
                    final long t$142389 = ((i$142390) + (((long)(1L))));
                    
                    //#line 1241 "x10/regionarray/Array.x10"
                    i$142390 = t$142389;
                }
                
                //#line 1238 "x10/regionarray/Array.x10"
                final long t$142403 = ((i$142404) + (((long)(1L))));
                
                //#line 1238 "x10/regionarray/Array.x10"
                i$142404 = t$142403;
            }
        }
    }
    
    public static <$T>void copy3$P__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final x10.regionarray.Region r, final x10.regionarray.Array<$T> Array) {
        ((x10.regionarray.Array<$T>)Array).copy3__0$1x10$regionarray$Array$$T$2(((x10.regionarray.Array)(src)), ((x10.regionarray.Region)(r)));
    }
    
    
    //#line 1254 "x10/regionarray/Array.x10"
    private static void raiseBoundsError(final long i0) {
        
        //#line 1255 "x10/regionarray/Array.x10"
        final java.lang.String t$140654 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1255 "x10/regionarray/Array.x10"
        final java.lang.String t$140655 = ((t$140654) + (") not contained in array"));
        
        //#line 1255 "x10/regionarray/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$140656 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$140655)));
        
        //#line 1255 "x10/regionarray/Array.x10"
        throw t$140656;
    }
    
    public static void raiseBoundsError$P(final long i0) {
        x10.regionarray.Array.raiseBoundsError((long)(i0));
    }
    
    
    //#line 1257 "x10/regionarray/Array.x10"
    private static void raiseBoundsError(final long i0, final long i1) {
        
        //#line 1258 "x10/regionarray/Array.x10"
        final java.lang.String t$140657 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1258 "x10/regionarray/Array.x10"
        final java.lang.String t$140658 = ((t$140657) + (", "));
        
        //#line 1258 "x10/regionarray/Array.x10"
        final java.lang.String t$140659 = ((t$140658) + ((x10.core.Long.$box(i1))));
        
        //#line 1258 "x10/regionarray/Array.x10"
        final java.lang.String t$140660 = ((t$140659) + (") not contained in array"));
        
        //#line 1258 "x10/regionarray/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$140661 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$140660)));
        
        //#line 1258 "x10/regionarray/Array.x10"
        throw t$140661;
    }
    
    public static void raiseBoundsError$P(final long i0, final long i1) {
        x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1));
    }
    
    
    //#line 1260 "x10/regionarray/Array.x10"
    private static void raiseBoundsError(final long i0, final long i1, final long i2) {
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.String t$140662 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.String t$140663 = ((t$140662) + (", "));
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.String t$140664 = ((t$140663) + ((x10.core.Long.$box(i1))));
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.String t$140665 = ((t$140664) + (", "));
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.String t$140666 = ((t$140665) + ((x10.core.Long.$box(i2))));
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.String t$140667 = ((t$140666) + (") not contained in array"));
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$140668 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$140667)));
        
        //#line 1261 "x10/regionarray/Array.x10"
        throw t$140668;
    }
    
    public static void raiseBoundsError$P(final long i0, final long i1, final long i2) {
        x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1), (long)(i2));
    }
    
    
    //#line 1263 "x10/regionarray/Array.x10"
    private static void raiseBoundsError(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$140669 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$140670 = ((t$140669) + (", "));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$140671 = ((t$140670) + ((x10.core.Long.$box(i1))));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$140672 = ((t$140671) + (", "));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$140673 = ((t$140672) + ((x10.core.Long.$box(i2))));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$140674 = ((t$140673) + (", "));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$140675 = ((t$140674) + ((x10.core.Long.$box(i3))));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$140676 = ((t$140675) + (") not contained in array"));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$140677 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$140676)));
        
        //#line 1264 "x10/regionarray/Array.x10"
        throw t$140677;
    }
    
    public static void raiseBoundsError$P(final long i0, final long i1, final long i2, final long i3) {
        x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
    }
    
    
    //#line 1266 "x10/regionarray/Array.x10"
    private static void raiseBoundsError(final x10.lang.Point pt) {
        
        //#line 1267 "x10/regionarray/Array.x10"
        final java.lang.String t$140678 = (("point ") + (pt));
        
        //#line 1267 "x10/regionarray/Array.x10"
        final java.lang.String t$140679 = ((t$140678) + (" not contained in array"));
        
        //#line 1267 "x10/regionarray/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$140680 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$140679)));
        
        //#line 1267 "x10/regionarray/Array.x10"
        throw t$140680;
    }
    
    public static void raiseBoundsError$P(final x10.lang.Point pt) {
        x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(pt)));
    }
    
    
    //#line 1277 "x10/regionarray/Array.x10"
    public long layout_min0;
    
    //#line 1278 "x10/regionarray/Array.x10"
    public long layout_stride1;
    
    //#line 1279 "x10/regionarray/Array.x10"
    public long layout_min1;
    
    //#line 1287 "x10/regionarray/Array.x10"
    public x10.core.Rail<x10.core.Long> layout;
    
    
    //#line 1290 "x10/regionarray/Array.x10"
    private long offset$O(final long i0) {
        
        //#line 1290 "x10/regionarray/Array.x10"
        final long t$140681 = this.layout_min0;
        
        //#line 1290 "x10/regionarray/Array.x10"
        final long t$140682 = ((i0) - (((long)(t$140681))));
        
        //#line 1290 "x10/regionarray/Array.x10"
        return t$140682;
    }
    
    public static <$T>long offset$P__1$1x10$regionarray$Array$$T$2$O(final x10.rtt.Type $T, final long i0, final x10.regionarray.Array<$T> Array) {
        return ((x10.regionarray.Array<$T>)Array).offset$O((long)(i0));
    }
    
    
    //#line 1293 "x10/regionarray/Array.x10"
    private long offset$O(final long i0, final long i1) {
        
        //#line 1294 "x10/regionarray/Array.x10"
        final long t$140683 = this.layout_min0;
        
        //#line 1294 "x10/regionarray/Array.x10"
        long offset = ((i0) - (((long)(t$140683))));
        
        //#line 1295 "x10/regionarray/Array.x10"
        final long t$140685 = this.layout_stride1;
        
        //#line 1295 "x10/regionarray/Array.x10"
        final long t$140686 = ((offset) * (((long)(t$140685))));
        
        //#line 1295 "x10/regionarray/Array.x10"
        final long t$140687 = ((t$140686) + (((long)(i1))));
        
        //#line 1295 "x10/regionarray/Array.x10"
        final long t$140688 = this.layout_min1;
        
        //#line 1295 "x10/regionarray/Array.x10"
        final long t$140689 = ((t$140687) - (((long)(t$140688))));
        
        //#line 1295 "x10/regionarray/Array.x10"
        offset = t$140689;
        
        //#line 1296 "x10/regionarray/Array.x10"
        return offset;
    }
    
    public static <$T>long offset$P__2$1x10$regionarray$Array$$T$2$O(final x10.rtt.Type $T, final long i0, final long i1, final x10.regionarray.Array<$T> Array) {
        return ((x10.regionarray.Array<$T>)Array).offset$O((long)(i0), (long)(i1));
    }
    
    
    //#line 1299 "x10/regionarray/Array.x10"
    private long offset$O(final long i0, final long i1, final long i2) {
        
        //#line 1300 "x10/regionarray/Array.x10"
        final long t$140691 = this.layout_min0;
        
        //#line 1300 "x10/regionarray/Array.x10"
        long offset = ((i0) - (((long)(t$140691))));
        
        //#line 1301 "x10/regionarray/Array.x10"
        final long t$140693 = this.layout_stride1;
        
        //#line 1301 "x10/regionarray/Array.x10"
        final long t$140694 = ((offset) * (((long)(t$140693))));
        
        //#line 1301 "x10/regionarray/Array.x10"
        final long t$140695 = ((t$140694) + (((long)(i1))));
        
        //#line 1301 "x10/regionarray/Array.x10"
        final long t$140696 = this.layout_min1;
        
        //#line 1301 "x10/regionarray/Array.x10"
        final long t$140697 = ((t$140695) - (((long)(t$140696))));
        
        //#line 1301 "x10/regionarray/Array.x10"
        offset = t$140697;
        
        //#line 1302 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140698 = ((x10.core.Rail)(this.layout));
        
        //#line 1302 "x10/regionarray/Array.x10"
        final long t$140700 = ((long[])t$140698.value)[(int)0L];
        
        //#line 1302 "x10/regionarray/Array.x10"
        final long t$140701 = ((offset) * (((long)(t$140700))));
        
        //#line 1302 "x10/regionarray/Array.x10"
        final long t$140703 = ((t$140701) + (((long)(i2))));
        
        //#line 1302 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140702 = ((x10.core.Rail)(this.layout));
        
        //#line 1302 "x10/regionarray/Array.x10"
        final long t$140704 = ((long[])t$140702.value)[(int)1L];
        
        //#line 1302 "x10/regionarray/Array.x10"
        final long t$140705 = ((t$140703) - (((long)(t$140704))));
        
        //#line 1302 "x10/regionarray/Array.x10"
        offset = t$140705;
        
        //#line 1303 "x10/regionarray/Array.x10"
        return offset;
    }
    
    public static <$T>long offset$P__3$1x10$regionarray$Array$$T$2$O(final x10.rtt.Type $T, final long i0, final long i1, final long i2, final x10.regionarray.Array<$T> Array) {
        return ((x10.regionarray.Array<$T>)Array).offset$O((long)(i0), (long)(i1), (long)(i2));
    }
    
    
    //#line 1306 "x10/regionarray/Array.x10"
    private long offset$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 1307 "x10/regionarray/Array.x10"
        final long t$140707 = this.layout_min0;
        
        //#line 1307 "x10/regionarray/Array.x10"
        long offset = ((i0) - (((long)(t$140707))));
        
        //#line 1308 "x10/regionarray/Array.x10"
        final long t$140709 = this.layout_stride1;
        
        //#line 1308 "x10/regionarray/Array.x10"
        final long t$140710 = ((offset) * (((long)(t$140709))));
        
        //#line 1308 "x10/regionarray/Array.x10"
        final long t$140711 = ((t$140710) + (((long)(i1))));
        
        //#line 1308 "x10/regionarray/Array.x10"
        final long t$140712 = this.layout_min1;
        
        //#line 1308 "x10/regionarray/Array.x10"
        final long t$140713 = ((t$140711) - (((long)(t$140712))));
        
        //#line 1308 "x10/regionarray/Array.x10"
        offset = t$140713;
        
        //#line 1309 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140714 = ((x10.core.Rail)(this.layout));
        
        //#line 1309 "x10/regionarray/Array.x10"
        final long t$140716 = ((long[])t$140714.value)[(int)0L];
        
        //#line 1309 "x10/regionarray/Array.x10"
        final long t$140717 = ((offset) * (((long)(t$140716))));
        
        //#line 1309 "x10/regionarray/Array.x10"
        final long t$140719 = ((t$140717) + (((long)(i2))));
        
        //#line 1309 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140718 = ((x10.core.Rail)(this.layout));
        
        //#line 1309 "x10/regionarray/Array.x10"
        final long t$140720 = ((long[])t$140718.value)[(int)1L];
        
        //#line 1309 "x10/regionarray/Array.x10"
        final long t$140721 = ((t$140719) - (((long)(t$140720))));
        
        //#line 1309 "x10/regionarray/Array.x10"
        offset = t$140721;
        
        //#line 1310 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140722 = ((x10.core.Rail)(this.layout));
        
        //#line 1310 "x10/regionarray/Array.x10"
        final long t$140724 = ((long[])t$140722.value)[(int)2L];
        
        //#line 1310 "x10/regionarray/Array.x10"
        final long t$140725 = ((offset) * (((long)(t$140724))));
        
        //#line 1310 "x10/regionarray/Array.x10"
        final long t$140727 = ((t$140725) + (((long)(i3))));
        
        //#line 1310 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140726 = ((x10.core.Rail)(this.layout));
        
        //#line 1310 "x10/regionarray/Array.x10"
        final long t$140728 = ((long[])t$140726.value)[(int)3L];
        
        //#line 1310 "x10/regionarray/Array.x10"
        final long t$140729 = ((t$140727) - (((long)(t$140728))));
        
        //#line 1310 "x10/regionarray/Array.x10"
        offset = t$140729;
        
        //#line 1311 "x10/regionarray/Array.x10"
        return offset;
    }
    
    public static <$T>long offset$P__4$1x10$regionarray$Array$$T$2$O(final x10.rtt.Type $T, final long i0, final long i1, final long i2, final long i3, final x10.regionarray.Array<$T> Array) {
        return ((x10.regionarray.Array<$T>)Array).offset$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
    }
    
    
    //#line 1314 "x10/regionarray/Array.x10"
    private long offset$O(final x10.lang.Point pt) {
        
        //#line 1315 "x10/regionarray/Array.x10"
        final long t$140731 = ((long)(((int)(0))));
        
        //#line 1315 "x10/regionarray/Array.x10"
        final long t$140732 = pt.$apply$O((long)(t$140731));
        
        //#line 1315 "x10/regionarray/Array.x10"
        final long t$140733 = this.layout_min0;
        
        //#line 1315 "x10/regionarray/Array.x10"
        long offset = ((t$140732) - (((long)(t$140733))));
        
        //#line 1316 "x10/regionarray/Array.x10"
        final long t$140734 = pt.rank;
        
        //#line 1316 "x10/regionarray/Array.x10"
        final boolean t$140762 = ((t$140734) > (((long)(1L))));
        
        //#line 1316 "x10/regionarray/Array.x10"
        if (t$140762) {
            
            //#line 1317 "x10/regionarray/Array.x10"
            final long t$140736 = this.layout_stride1;
            
            //#line 1317 "x10/regionarray/Array.x10"
            final long t$140737 = ((offset) * (((long)(t$140736))));
            
            //#line 1317 "x10/regionarray/Array.x10"
            final long t$140738 = pt.$apply$O((long)(1L));
            
            //#line 1317 "x10/regionarray/Array.x10"
            final long t$140739 = ((t$140737) + (((long)(t$140738))));
            
            //#line 1317 "x10/regionarray/Array.x10"
            final long t$140740 = this.layout_min1;
            
            //#line 1317 "x10/regionarray/Array.x10"
            final long t$140741 = ((t$140739) - (((long)(t$140740))));
            
            //#line 1317 "x10/regionarray/Array.x10"
            offset = t$140741;
            
            //#line 1318 "x10/regionarray/Array.x10"
            final long t$142430 = pt.rank;
            
            //#line 1318 "x10/regionarray/Array.x10"
            final long i$138093max$142431 = ((t$142430) - (((long)(1L))));
            
            //#line 1318 "x10/regionarray/Array.x10"
            long i$142427 = 2L;
            
            //#line 1318 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1318 "x10/regionarray/Array.x10"
                final boolean t$142429 = ((i$142427) <= (((long)(i$138093max$142431))));
                
                //#line 1318 "x10/regionarray/Array.x10"
                if (!(t$142429)) {
                    
                    //#line 1318 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1319 "x10/regionarray/Array.x10"
                final x10.core.Rail t$142411 = ((x10.core.Rail)(this.layout));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$142412 = ((i$142427) - (((long)(2L))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$142413 = ((2L) * (((long)(t$142412))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$142414 = ((long[])t$142411.value)[(int)t$142413];
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$142415 = ((offset) * (((long)(t$142414))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$142416 = pt.$apply$O((long)(i$142427));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$142417 = ((t$142415) + (((long)(t$142416))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final x10.core.Rail t$142418 = ((x10.core.Rail)(this.layout));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$142419 = ((i$142427) - (((long)(2L))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$142420 = ((2L) * (((long)(t$142419))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$142421 = ((t$142420) + (((long)(1L))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$142422 = ((long[])t$142418.value)[(int)t$142421];
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$142423 = ((t$142417) - (((long)(t$142422))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                offset = t$142423;
                
                //#line 1318 "x10/regionarray/Array.x10"
                final long t$142426 = ((i$142427) + (((long)(1L))));
                
                //#line 1318 "x10/regionarray/Array.x10"
                i$142427 = t$142426;
            }
        }
        
        //#line 1322 "x10/regionarray/Array.x10"
        return offset;
    }
    
    public static <$T>long offset$P__1$1x10$regionarray$Array$$T$2$O(final x10.rtt.Type $T, final x10.lang.Point pt, final x10.regionarray.Array<$T> Array) {
        return ((x10.regionarray.Array<$T>)Array).offset$O(((x10.lang.Point)(pt)));
    }
    
    
    //#line 1331 "x10/regionarray/Array.x10"
    @x10.runtime.impl.java.X10Generated
    public static class LayoutHelper extends x10.core.Struct implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<LayoutHelper> $RTT = 
            x10.rtt.NamedStructType.<LayoutHelper> make("x10.regionarray.Array.LayoutHelper",
                                                        LayoutHelper.class,
                                                        new x10.rtt.Type[] {
                                                            x10.rtt.Types.STRUCT
                                                        });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.LayoutHelper $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.layout = $deserializer.readObject();
            $_obj.min0 = $deserializer.readLong();
            $_obj.min1 = $deserializer.readLong();
            $_obj.size = $deserializer.readLong();
            $_obj.stride1 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Array.LayoutHelper $_obj = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.layout);
            $serializer.write(this.min0);
            $serializer.write(this.min1);
            $serializer.write(this.size);
            $serializer.write(this.stride1);
            
        }
        
        // zero value constructor
        public LayoutHelper(final java.lang.System $dummy) { this.min0 = 0L; this.stride1 = 0L; this.min1 = 0L; this.size = 0L; this.layout = null; }
        
        // constructor just for allocation
        public LayoutHelper(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        //#line 1332 "x10/regionarray/Array.x10"
        public long min0;
        
        //#line 1333 "x10/regionarray/Array.x10"
        public long stride1;
        
        //#line 1334 "x10/regionarray/Array.x10"
        public long min1;
        
        //#line 1335 "x10/regionarray/Array.x10"
        public long size;
        
        //#line 1336 "x10/regionarray/Array.x10"
        public x10.core.Rail<x10.core.Long> layout;
        
        
        //#line 1338 "x10/regionarray/Array.x10"
        // creation method for java code (1-phase java constructor)
        public LayoutHelper(final x10.regionarray.Region reg) {
            this((java.lang.System[]) null);
            x10$regionarray$Array$LayoutHelper$$init$S(reg);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.Array.LayoutHelper x10$regionarray$Array$LayoutHelper$$init$S(final x10.regionarray.Region reg) {
             {
                
                //#line 1338 "x10/regionarray/Array.x10"
                
                
                //#line 1339 "x10/regionarray/Array.x10"
                final boolean t$140825 = reg.isEmpty$O();
                
                //#line 1339 "x10/regionarray/Array.x10"
                if (t$140825) {
                    
                    //#line 1340 "x10/regionarray/Array.x10"
                    final long t$140764 = this.min1 = 0L;
                    
                    //#line 1340 "x10/regionarray/Array.x10"
                    final long t$140765 = this.stride1 = t$140764;
                    
                    //#line 1340 "x10/regionarray/Array.x10"
                    this.min0 = t$140765;
                    
                    //#line 1341 "x10/regionarray/Array.x10"
                    this.size = 0L;
                    
                    //#line 1342 "x10/regionarray/Array.x10"
                    this.layout = null;
                } else {
                    
                    //#line 1344 "x10/regionarray/Array.x10"
                    final long t$140766 = reg.rank;
                    
                    //#line 1344 "x10/regionarray/Array.x10"
                    final boolean t$140824 = ((long) t$140766) == ((long) 1L);
                    
                    //#line 1344 "x10/regionarray/Array.x10"
                    if (t$140824) {
                        
                        //#line 1345 "x10/regionarray/Array.x10"
                        final long t$140767 = ((long)(((int)(0))));
                        
                        //#line 1345 "x10/regionarray/Array.x10"
                        final long t$140768 = reg.min$O((long)(t$140767));
                        
                        //#line 1345 "x10/regionarray/Array.x10"
                        this.min0 = t$140768;
                        
                        //#line 1346 "x10/regionarray/Array.x10"
                        this.stride1 = 0L;
                        
                        //#line 1347 "x10/regionarray/Array.x10"
                        this.min1 = 0L;
                        
                        //#line 1348 "x10/regionarray/Array.x10"
                        final long t$140769 = reg.max$O((long)(0L));
                        
                        //#line 1348 "x10/regionarray/Array.x10"
                        final long t$140770 = reg.min$O((long)(0L));
                        
                        //#line 1348 "x10/regionarray/Array.x10"
                        final long t$140771 = ((t$140769) - (((long)(t$140770))));
                        
                        //#line 1348 "x10/regionarray/Array.x10"
                        final long t$140772 = ((t$140771) + (((long)(1L))));
                        
                        //#line 1348 "x10/regionarray/Array.x10"
                        this.size = t$140772;
                        
                        //#line 1349 "x10/regionarray/Array.x10"
                        this.layout = null;
                    } else {
                        
                        //#line 1350 "x10/regionarray/Array.x10"
                        final long t$140773 = reg.rank;
                        
                        //#line 1350 "x10/regionarray/Array.x10"
                        final boolean t$140823 = ((long) t$140773) == ((long) 2L);
                        
                        //#line 1350 "x10/regionarray/Array.x10"
                        if (t$140823) {
                            
                            //#line 1351 "x10/regionarray/Array.x10"
                            final long t$140774 = reg.min$O((long)(0L));
                            
                            //#line 1351 "x10/regionarray/Array.x10"
                            this.min0 = t$140774;
                            
                            //#line 1352 "x10/regionarray/Array.x10"
                            final long t$140775 = reg.min$O((long)(1L));
                            
                            //#line 1352 "x10/regionarray/Array.x10"
                            this.min1 = t$140775;
                            
                            //#line 1353 "x10/regionarray/Array.x10"
                            final long t$140776 = reg.max$O((long)(1L));
                            
                            //#line 1353 "x10/regionarray/Array.x10"
                            final long t$140777 = reg.min$O((long)(1L));
                            
                            //#line 1353 "x10/regionarray/Array.x10"
                            final long t$140778 = ((t$140776) - (((long)(t$140777))));
                            
                            //#line 1353 "x10/regionarray/Array.x10"
                            final long t$140779 = ((t$140778) + (((long)(1L))));
                            
                            //#line 1353 "x10/regionarray/Array.x10"
                            this.stride1 = t$140779;
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            final long t$140783 = this.stride1;
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            final long t$140780 = reg.max$O((long)(0L));
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            final long t$140781 = reg.min$O((long)(0L));
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            final long t$140782 = ((t$140780) - (((long)(t$140781))));
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            final long t$140784 = ((t$140782) + (((long)(1L))));
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            final long t$140785 = ((t$140783) * (((long)(t$140784))));
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            this.size = t$140785;
                            
                            //#line 1355 "x10/regionarray/Array.x10"
                            this.layout = null;
                        } else {
                            
                            //#line 1357 "x10/regionarray/Array.x10"
                            final long t$140786 = reg.rank;
                            
                            //#line 1357 "x10/regionarray/Array.x10"
                            final long t$140787 = ((t$140786) - (((long)(2L))));
                            
                            //#line 1357 "x10/regionarray/Array.x10"
                            final long t$140788 = ((2L) * (((long)(t$140787))));
                            
                            //#line 1357 "x10/regionarray/Array.x10"
                            final x10.core.Rail t$140789 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, t$140788)));
                            
                            //#line 1357 "x10/regionarray/Array.x10"
                            this.layout = ((x10.core.Rail)(t$140789));
                            
                            //#line 1358 "x10/regionarray/Array.x10"
                            final long t$140790 = reg.min$O((long)(0L));
                            
                            //#line 1358 "x10/regionarray/Array.x10"
                            this.min0 = t$140790;
                            
                            //#line 1359 "x10/regionarray/Array.x10"
                            final long t$140791 = reg.min$O((long)(1L));
                            
                            //#line 1359 "x10/regionarray/Array.x10"
                            this.min1 = t$140791;
                            
                            //#line 1360 "x10/regionarray/Array.x10"
                            final long t$140792 = reg.max$O((long)(1L));
                            
                            //#line 1360 "x10/regionarray/Array.x10"
                            final long t$140793 = reg.min$O((long)(1L));
                            
                            //#line 1360 "x10/regionarray/Array.x10"
                            final long t$140794 = ((t$140792) - (((long)(t$140793))));
                            
                            //#line 1360 "x10/regionarray/Array.x10"
                            final long t$140795 = ((t$140794) + (((long)(1L))));
                            
                            //#line 1360 "x10/regionarray/Array.x10"
                            this.stride1 = t$140795;
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$140801 = this.stride1;
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$140796 = ((long)(((int)(0))));
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$140798 = reg.max$O((long)(t$140796));
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$140797 = ((long)(((int)(0))));
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$140799 = reg.min$O((long)(t$140797));
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$140800 = ((t$140798) - (((long)(t$140799))));
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$140802 = ((t$140800) + (((long)(1L))));
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            long sz = ((t$140801) * (((long)(t$140802))));
                            
                            //#line 1362 "x10/regionarray/Array.x10"
                            final long t$142452 = reg.rank;
                            
                            //#line 1362 "x10/regionarray/Array.x10"
                            final long i$138111max$142453 = ((t$142452) - (((long)(1L))));
                            
                            //#line 1362 "x10/regionarray/Array.x10"
                            long i$142449 = 2L;
                            
                            //#line 1362 "x10/regionarray/Array.x10"
                            for (;
                                 true;
                                 ) {
                                
                                //#line 1362 "x10/regionarray/Array.x10"
                                final boolean t$142451 = ((i$142449) <= (((long)(i$138111max$142453))));
                                
                                //#line 1362 "x10/regionarray/Array.x10"
                                if (!(t$142451)) {
                                    
                                    //#line 1362 "x10/regionarray/Array.x10"
                                    break;
                                }
                                
                                //#line 1363 "x10/regionarray/Array.x10"
                                final long t$142432 = reg.max$O((long)(i$142449));
                                
                                //#line 1363 "x10/regionarray/Array.x10"
                                final long t$142433 = reg.min$O((long)(i$142449));
                                
                                //#line 1363 "x10/regionarray/Array.x10"
                                final long t$142434 = ((t$142432) - (((long)(t$142433))));
                                
                                //#line 1363 "x10/regionarray/Array.x10"
                                final long stride$142435 = ((t$142434) + (((long)(1L))));
                                
                                //#line 1364 "x10/regionarray/Array.x10"
                                final long t$142437 = ((sz) * (((long)(stride$142435))));
                                
                                //#line 1364 "x10/regionarray/Array.x10"
                                sz = t$142437;
                                
                                //#line 1365 "x10/regionarray/Array.x10"
                                final x10.core.Rail t$142438 = ((x10.core.Rail)(this.layout));
                                
                                //#line 1365 "x10/regionarray/Array.x10"
                                final long t$142439 = ((i$142449) - (((long)(2L))));
                                
                                //#line 1365 "x10/regionarray/Array.x10"
                                final long t$142440 = ((2L) * (((long)(t$142439))));
                                
                                //#line 1365 "x10/regionarray/Array.x10"
                                ((long[])t$142438.value)[(int)t$142440] = stride$142435;
                                
                                //#line 1366 "x10/regionarray/Array.x10"
                                final x10.core.Rail t$142441 = ((x10.core.Rail)(this.layout));
                                
                                //#line 1366 "x10/regionarray/Array.x10"
                                final long t$142442 = ((i$142449) - (((long)(2L))));
                                
                                //#line 1366 "x10/regionarray/Array.x10"
                                final long t$142443 = ((2L) * (((long)(t$142442))));
                                
                                //#line 1366 "x10/regionarray/Array.x10"
                                final long t$142444 = ((t$142443) + (((long)(1L))));
                                
                                //#line 1366 "x10/regionarray/Array.x10"
                                final long t$142445 = reg.min$O((long)(i$142449));
                                
                                //#line 1366 "x10/regionarray/Array.x10"
                                ((long[])t$142441.value)[(int)t$142444] = t$142445;
                                
                                //#line 1362 "x10/regionarray/Array.x10"
                                final long t$142448 = ((i$142449) + (((long)(1L))));
                                
                                //#line 1362 "x10/regionarray/Array.x10"
                                i$142449 = t$142448;
                            }
                            
                            //#line 1368 "x10/regionarray/Array.x10"
                            this.size = sz;
                        }
                    }
                }
            }
            return this;
        }
        
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public java.lang.String typeName() {
            try {
                return x10.rtt.Types.typeName(this);
            }
            catch (java.lang.Throwable exc$205670) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$205670);
            }
            
        }
        
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public java.lang.String toString() {
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$140826 = "struct x10.regionarray.Array.LayoutHelper: min0=";
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$140827 = this.min0;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$140828 = ((t$140826) + ((x10.core.Long.$box(t$140827))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$140829 = ((t$140828) + (" stride1="));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$140830 = this.stride1;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$140831 = ((t$140829) + ((x10.core.Long.$box(t$140830))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$140832 = ((t$140831) + (" min1="));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$140833 = this.min1;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$140834 = ((t$140832) + ((x10.core.Long.$box(t$140833))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$140835 = ((t$140834) + (" size="));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$140836 = this.size;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$140837 = ((t$140835) + ((x10.core.Long.$box(t$140836))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$140838 = ((t$140837) + (" layout="));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final x10.core.Rail t$140839 = ((x10.core.Rail)(this.layout));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$140840 = ((t$140838) + (t$140839));
            
            //#line 1331 "x10/regionarray/Array.x10"
            return t$140840;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public int hashCode() {
            
            //#line 1331 "x10/regionarray/Array.x10"
            int result = 1;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140843 = ((8191) * (((int)(result))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$140842 = this.min0;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140844 = x10.rtt.Types.hashCode(t$140842);
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140845 = ((t$140843) + (((int)(t$140844))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            result = t$140845;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140848 = ((8191) * (((int)(result))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$140847 = this.stride1;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140849 = x10.rtt.Types.hashCode(t$140847);
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140850 = ((t$140848) + (((int)(t$140849))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            result = t$140850;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140853 = ((8191) * (((int)(result))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$140852 = this.min1;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140854 = x10.rtt.Types.hashCode(t$140852);
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140855 = ((t$140853) + (((int)(t$140854))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            result = t$140855;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140858 = ((8191) * (((int)(result))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$140857 = this.size;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140859 = x10.rtt.Types.hashCode(t$140857);
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140860 = ((t$140858) + (((int)(t$140859))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            result = t$140860;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140863 = ((8191) * (((int)(result))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final x10.core.Rail t$140862 = ((x10.core.Rail)(this.layout));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140864 = x10.rtt.Types.hashCode(((java.lang.Object)(t$140862)));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$140865 = ((t$140863) + (((int)(t$140864))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            result = t$140865;
            
            //#line 1331 "x10/regionarray/Array.x10"
            return result;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public boolean equals(java.lang.Object other) {
            
            //#line 1331 "x10/regionarray/Array.x10"
            final boolean t$140868 = x10.regionarray.Array.LayoutHelper.$RTT.isInstance(other);
            
            //#line 1331 "x10/regionarray/Array.x10"
            final boolean t$140869 = !(t$140868);
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$140869) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                return false;
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper t$140871 = ((x10.regionarray.Array.LayoutHelper)x10.rtt.Types.asStruct(x10.regionarray.Array.LayoutHelper.$RTT,other));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final boolean t$140872 = this.equals$O(((x10.regionarray.Array.LayoutHelper)(t$140871)));
            
            //#line 1331 "x10/regionarray/Array.x10"
            return t$140872;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public boolean equals$O(x10.regionarray.Array.LayoutHelper other) {
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$140874 = this.min0;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$140875 = other.min0;
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$140879 = ((long) t$140874) == ((long) t$140875);
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$140879) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$140877 = this.stride1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$140878 = other.stride1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$140879 = ((long) t$140877) == ((long) t$140878);
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$140883 = t$140879;
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$140879) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$140881 = this.min1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$140882 = other.min1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$140883 = ((long) t$140881) == ((long) t$140882);
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$140887 = t$140883;
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$140883) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$140885 = this.size;
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$140886 = other.size;
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$140887 = ((long) t$140885) == ((long) t$140886);
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$140891 = t$140887;
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$140887) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final x10.core.Rail t$140889 = ((x10.core.Rail)(this.layout));
                
                //#line 1331 "x10/regionarray/Array.x10"
                final x10.core.Rail t$140890 = ((x10.core.Rail)(other.layout));
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$140891 = x10.rtt.Equality.equalsequals((t$140889),(t$140890));
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            return t$140891;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public boolean _struct_equals$O(java.lang.Object other) {
            
            //#line 1331 "x10/regionarray/Array.x10"
            final boolean t$140894 = x10.regionarray.Array.LayoutHelper.$RTT.isInstance(other);
            
            //#line 1331 "x10/regionarray/Array.x10"
            final boolean t$140895 = !(t$140894);
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$140895) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                return false;
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper t$140897 = ((x10.regionarray.Array.LayoutHelper)x10.rtt.Types.asStruct(x10.regionarray.Array.LayoutHelper.$RTT,other));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final boolean t$140898 = this._struct_equals$O(((x10.regionarray.Array.LayoutHelper)(t$140897)));
            
            //#line 1331 "x10/regionarray/Array.x10"
            return t$140898;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public boolean _struct_equals$O(x10.regionarray.Array.LayoutHelper other) {
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$140900 = this.min0;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$140901 = other.min0;
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$140905 = ((long) t$140900) == ((long) t$140901);
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$140905) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$140903 = this.stride1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$140904 = other.stride1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$140905 = ((long) t$140903) == ((long) t$140904);
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$140909 = t$140905;
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$140905) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$140907 = this.min1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$140908 = other.min1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$140909 = ((long) t$140907) == ((long) t$140908);
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$140913 = t$140909;
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$140909) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$140911 = this.size;
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$140912 = other.size;
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$140913 = ((long) t$140911) == ((long) t$140912);
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$140917 = t$140913;
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$140913) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final x10.core.Rail t$140915 = ((x10.core.Rail)(this.layout));
                
                //#line 1331 "x10/regionarray/Array.x10"
                final x10.core.Rail t$140916 = ((x10.core.Rail)(other.layout));
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$140917 = x10.rtt.Equality.equalsequals((t$140915),(t$140916));
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            return t$140917;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public x10.regionarray.Array.LayoutHelper x10$regionarray$Array$LayoutHelper$$this$x10$regionarray$Array$LayoutHelper() {
            
            //#line 1331 "x10/regionarray/Array.x10"
            return x10.regionarray.Array.LayoutHelper.this;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public void __fieldInitializers_x10_regionarray_Array_LayoutHelper() {
            
        }
    }
    
    
    
    //#line 55 "x10/regionarray/Array.x10"
    final public x10.regionarray.Array x10$regionarray$Array$$this$x10$regionarray$Array() {
        
        //#line 55 "x10/regionarray/Array.x10"
        return x10.regionarray.Array.this;
    }
    
    
    //#line 55 "x10/regionarray/Array.x10"
    final public void __fieldInitializers_x10_regionarray_Array() {
        
    }
    
    
    //#line 414 "x10/regionarray/Array.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$14235<$T> extends x10.core.Ref implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$14235> $RTT = 
            x10.rtt.NamedType.<Anonymous$14235> make("x10.regionarray.Array.Anonymous$14235",
                                                     Anonymous$14235.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.Anonymous$14235<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Array.Anonymous$14235 $_obj = new x10.regionarray.Array.Anonymous$14235((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$);
            
        }
        
        // constructor just for allocation
        public Anonymous$14235(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.Array.Anonymous$14235.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$14235 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$Array$Anonymous$14235$$T$2 {}
        
    
        
        //#line 55 "x10/regionarray/Array.x10"
        public x10.regionarray.Array<$T> out$;
        
        
        //#line 415 "x10/regionarray/Array.x10"
        public x10.regionarray.Array.Anonymous$14235.Anonymous$14292 iterator() {
            
            //#line 415 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.Anonymous$14235.Anonymous$14292 alloc$137864 = ((x10.regionarray.Array.Anonymous$14235.Anonymous$14292)(new x10.regionarray.Array.Anonymous$14235.Anonymous$14292<$T>((java.lang.System[]) null, $T)));
            
            //#line 415 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.Anonymous$14235 out$139088 = ((x10.regionarray.Array.Anonymous$14235)(this));
            
            //#line 414 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array.Anonymous$14235.Anonymous$14292<$T>)alloc$137864).out$ = out$139088;
            
            //#line 415 "x10/regionarray/Array.x10"
            return alloc$137864;
        }
        
        
        //#line 414 "x10/regionarray/Array.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$14235(final x10.rtt.Type $T, final x10.regionarray.Array<$T> out$, __0$1x10$regionarray$Array$Anonymous$14235$$T$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$regionarray$Array$Anonymous$14235$$init$S(out$, (x10.regionarray.Array.Anonymous$14235.__0$1x10$regionarray$Array$Anonymous$14235$$T$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.Array.Anonymous$14235<$T> x10$regionarray$Array$Anonymous$14235$$init$S(final x10.regionarray.Array<$T> out$, __0$1x10$regionarray$Array$Anonymous$14235$$T$2 $dummy) {
             {
                
                //#line 55 "x10/regionarray/Array.x10"
                ((x10.regionarray.Array.Anonymous$14235<$T>)this).out$ = out$;
            }
            return this;
        }
        
        
        
        //#line 415 "x10/regionarray/Array.x10"
        @x10.runtime.impl.java.X10Generated
        final public static class Anonymous$14292<$T> extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<Anonymous$14292> $RTT = 
                x10.rtt.NamedType.<Anonymous$14292> make("x10.regionarray.Array.Anonymous$14235.Anonymous$14292",
                                                         Anonymous$14292.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.Anonymous$14235.Anonymous$14292<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.cur = $deserializer.readLong();
                $_obj.out$ = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.regionarray.Array.Anonymous$14235.Anonymous$14292 $_obj = new x10.regionarray.Array.Anonymous$14235.Anonymous$14292((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.cur);
                $serializer.write(this.out$);
                
            }
            
            // constructor just for allocation
            public Anonymous$14292(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.regionarray.Array.Anonymous$14235.Anonymous$14292.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final Anonymous$14292 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0$1x10$regionarray$Array$Anonymous$14235$Anonymous$14292$$T$2 {}
            
        
            
            //#line 414 "x10/regionarray/Array.x10"
            public x10.regionarray.Array.Anonymous$14235<$T> out$;
            
            //#line 416 "x10/regionarray/Array.x10"
            public long cur = 0L;
            
            
            //#line 417 "x10/regionarray/Array.x10"
            public $T next$G() {
                
                //#line 417 "x10/regionarray/Array.x10"
                final x10.regionarray.Array.Anonymous$14235 t$140919 = this.out$;
                
                //#line 417 "x10/regionarray/Array.x10"
                final x10.regionarray.Array t$140920 = ((x10.regionarray.Array.Anonymous$14235<$T>)t$140919).out$;
                
                //#line 417 "x10/regionarray/Array.x10"
                final x10.core.Rail t$140924 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)t$140920).raw));
                
                //#line 417 "x10/regionarray/Array.x10"
                final long t$140921 = this.cur;
                
                //#line 417 "x10/regionarray/Array.x10"
                final long t$140922 = ((t$140921) + (((long)(1L))));
                
                //#line 417 "x10/regionarray/Array.x10"
                final long t$140923 = ((x10.regionarray.Array.Anonymous$14235.Anonymous$14292<$T>)this).cur = t$140922;
                
                //#line 417 "x10/regionarray/Array.x10"
                final long t$140925 = ((t$140923) - (((long)(1L))));
                
                //#line 417 "x10/regionarray/Array.x10"
                final $T t$140926 = (($T)(((x10.core.Rail<$T>)t$140924).$apply$G((long)(t$140925))));
                
                //#line 417 "x10/regionarray/Array.x10"
                return t$140926;
            }
            
            
            //#line 418 "x10/regionarray/Array.x10"
            public boolean hasNext$O() {
                
                //#line 418 "x10/regionarray/Array.x10"
                final long t$140930 = this.cur;
                
                //#line 418 "x10/regionarray/Array.x10"
                final x10.regionarray.Array.Anonymous$14235 t$140927 = this.out$;
                
                //#line 418 "x10/regionarray/Array.x10"
                final x10.regionarray.Array t$140928 = ((x10.regionarray.Array.Anonymous$14235<$T>)t$140927).out$;
                
                //#line 418 "x10/regionarray/Array.x10"
                final x10.core.Rail t$140929 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)t$140928).raw));
                
                //#line 418 "x10/regionarray/Array.x10"
                final long t$140931 = ((x10.core.Rail<$T>)t$140929).size;
                
                //#line 418 "x10/regionarray/Array.x10"
                final boolean t$140932 = ((t$140930) < (((long)(t$140931))));
                
                //#line 418 "x10/regionarray/Array.x10"
                return t$140932;
            }
            
            
            //#line 415 "x10/regionarray/Array.x10"
            // creation method for java code (1-phase java constructor)
            public Anonymous$14292(final x10.rtt.Type $T, final x10.regionarray.Array.Anonymous$14235<$T> out$, __0$1x10$regionarray$Array$Anonymous$14235$Anonymous$14292$$T$2 $dummy) {
                this((java.lang.System[]) null, $T);
                x10$regionarray$Array$Anonymous$14235$Anonymous$14292$$init$S(out$, (x10.regionarray.Array.Anonymous$14235.Anonymous$14292.__0$1x10$regionarray$Array$Anonymous$14235$Anonymous$14292$$T$2) null);
            }
            
            // constructor for non-virtual call
            final public x10.regionarray.Array.Anonymous$14235.Anonymous$14292<$T> x10$regionarray$Array$Anonymous$14235$Anonymous$14292$$init$S(final x10.regionarray.Array.Anonymous$14235<$T> out$, __0$1x10$regionarray$Array$Anonymous$14235$Anonymous$14292$$T$2 $dummy) {
                 {
                    
                    //#line 414 "x10/regionarray/Array.x10"
                    ((x10.regionarray.Array.Anonymous$14235.Anonymous$14292<$T>)this).out$ = out$;
                }
                return this;
            }
            
        }
        
    }
    
    
    //#line 422 "x10/regionarray/Array.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$14520<$T> extends x10.core.Ref implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$14520> $RTT = 
            x10.rtt.NamedType.<Anonymous$14520> make("x10.regionarray.Array.Anonymous$14520",
                                                     Anonymous$14520.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.Anonymous$14520<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Array.Anonymous$14520 $_obj = new x10.regionarray.Array.Anonymous$14520((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$);
            
        }
        
        // constructor just for allocation
        public Anonymous$14520(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.Array.Anonymous$14520.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$14520 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$Array$Anonymous$14520$$T$2 {}
        
    
        
        //#line 55 "x10/regionarray/Array.x10"
        public x10.regionarray.Array<$T> out$;
        
        
        //#line 423 "x10/regionarray/Array.x10"
        public x10.regionarray.Array.Anonymous$14520.Anonymous$14577 iterator() {
            
            //#line 423 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.Anonymous$14520.Anonymous$14577 alloc$137865 = ((x10.regionarray.Array.Anonymous$14520.Anonymous$14577)(new x10.regionarray.Array.Anonymous$14520.Anonymous$14577<$T>((java.lang.System[]) null, $T)));
            
            //#line 423 "x10/regionarray/Array.x10"
            alloc$137865.x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$init$S(this, (x10.regionarray.Array.Anonymous$14520.Anonymous$14577.__0$1x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$T$2) null);
            
            //#line 423 "x10/regionarray/Array.x10"
            return alloc$137865;
        }
        
        
        //#line 422 "x10/regionarray/Array.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$14520(final x10.rtt.Type $T, final x10.regionarray.Array<$T> out$, __0$1x10$regionarray$Array$Anonymous$14520$$T$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$regionarray$Array$Anonymous$14520$$init$S(out$, (x10.regionarray.Array.Anonymous$14520.__0$1x10$regionarray$Array$Anonymous$14520$$T$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.Array.Anonymous$14520<$T> x10$regionarray$Array$Anonymous$14520$$init$S(final x10.regionarray.Array<$T> out$, __0$1x10$regionarray$Array$Anonymous$14520$$T$2 $dummy) {
             {
                
                //#line 55 "x10/regionarray/Array.x10"
                ((x10.regionarray.Array.Anonymous$14520<$T>)this).out$ = out$;
            }
            return this;
        }
        
        
        
        //#line 423 "x10/regionarray/Array.x10"
        @x10.runtime.impl.java.X10Generated
        final public static class Anonymous$14577<$T> extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<Anonymous$14577> $RTT = 
                x10.rtt.NamedType.<Anonymous$14577> make("x10.regionarray.Array.Anonymous$14520.Anonymous$14577",
                                                         Anonymous$14577.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.Anonymous$14520.Anonymous$14577<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.out$ = $deserializer.readObject();
                $_obj.regIt = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.regionarray.Array.Anonymous$14520.Anonymous$14577 $_obj = new x10.regionarray.Array.Anonymous$14520.Anonymous$14577((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.out$);
                $serializer.write(this.regIt);
                
            }
            
            // constructor just for allocation
            public Anonymous$14577(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.regionarray.Array.Anonymous$14520.Anonymous$14577.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final Anonymous$14577 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0$1x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$T$2 {}
            
        
            
            //#line 422 "x10/regionarray/Array.x10"
            public x10.regionarray.Array.Anonymous$14520<$T> out$;
            
            //#line 424 "x10/regionarray/Array.x10"
            public x10.lang.Iterator<x10.lang.Point> regIt;
            
            
            //#line 425 "x10/regionarray/Array.x10"
            public $T next$G() {
                
                //#line 425 "x10/regionarray/Array.x10"
                final x10.regionarray.Array.Anonymous$14520 t$140933 = this.out$;
                
                //#line 425 "x10/regionarray/Array.x10"
                final x10.regionarray.Array this$139091 = ((x10.regionarray.Array.Anonymous$14520<$T>)t$140933).out$;
                
                //#line 425 "x10/regionarray/Array.x10"
                final x10.lang.Iterator t$140934 = ((x10.lang.Iterator)(this.regIt));
                
                //#line 425 "x10/regionarray/Array.x10"
                final x10.lang.Point pt$139090 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)t$140934).next$G()));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$140935 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$139091).region));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$140936 = t$140935.contains$O(((x10.lang.Point)(pt$139090)));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$140937 = !(t$140936);
                
                //#line 524 . "x10/regionarray/Array.x10"
                if (t$140937) {
                    
                    //#line 525 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(pt$139090)));
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$140970 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139091).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$140938 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$140939 = pt$139090.$apply$O((long)(t$140938));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$140940 = ((x10.regionarray.Array<$T>)this$139091).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$139094 = ((t$140939) - (((long)(t$140940))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$140941 = pt$139090.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$140969 = ((t$140941) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$140969) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$140943 = ((x10.regionarray.Array<$T>)this$139091).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$140944 = ((offset$139094) * (((long)(t$140943))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$140945 = pt$139090.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$140946 = ((t$140944) + (((long)(t$140945))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$140947 = ((x10.regionarray.Array<$T>)this$139091).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$140948 = ((t$140946) - (((long)(t$140947))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$139094 = t$140948;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142475 = pt$139090.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138093max$142476 = ((t$142475) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$142472 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$142474 = ((i$142472) <= (((long)(i$138093max$142476))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$142474)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142456 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139091).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142457 = ((i$142472) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142458 = ((2L) * (((long)(t$142457))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142459 = ((long[])t$142456.value)[(int)t$142458];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142460 = ((offset$139094) * (((long)(t$142459))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142461 = pt$139090.$apply$O((long)(i$142472));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142462 = ((t$142460) + (((long)(t$142461))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142463 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139091).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142464 = ((i$142472) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142465 = ((2L) * (((long)(t$142464))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142466 = ((t$142465) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142467 = ((long[])t$142463.value)[(int)t$142466];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142468 = ((t$142462) - (((long)(t$142467))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$139094 = t$142468;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$142471 = ((i$142472) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$142472 = t$142471;
                    }
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final $T t$140972 = (($T)(((x10.core.Rail<$T>)t$140970).$apply$G((long)(offset$139094))));
                
                //#line 425 "x10/regionarray/Array.x10"
                return t$140972;
            }
            
            
            //#line 426 "x10/regionarray/Array.x10"
            public boolean hasNext$O() {
                
                //#line 426 "x10/regionarray/Array.x10"
                final x10.lang.Iterator t$140973 = ((x10.lang.Iterator)(this.regIt));
                
                //#line 426 "x10/regionarray/Array.x10"
                final boolean t$140974 = ((x10.lang.Iterator<x10.lang.Point>)t$140973).hasNext$O();
                
                //#line 426 "x10/regionarray/Array.x10"
                return t$140974;
            }
            
            
            //#line 423 "x10/regionarray/Array.x10"
            // creation method for java code (1-phase java constructor)
            public Anonymous$14577(final x10.rtt.Type $T, final x10.regionarray.Array.Anonymous$14520<$T> out$, __0$1x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$T$2 $dummy) {
                this((java.lang.System[]) null, $T);
                x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$init$S(out$, (x10.regionarray.Array.Anonymous$14520.Anonymous$14577.__0$1x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$T$2) null);
            }
            
            // constructor for non-virtual call
            final public x10.regionarray.Array.Anonymous$14520.Anonymous$14577<$T> x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$init$S(final x10.regionarray.Array.Anonymous$14520<$T> out$, __0$1x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$T$2 $dummy) {
                 {
                    
                    //#line 422 "x10/regionarray/Array.x10"
                    ((x10.regionarray.Array.Anonymous$14520.Anonymous$14577<$T>)this).out$ = out$;
                    
                    //#line 424 "x10/regionarray/Array.x10"
                    final x10.regionarray.Array.Anonymous$14520 t$140975 = this.out$;
                    
                    //#line 424 "x10/regionarray/Array.x10"
                    final x10.regionarray.Array this$139100 = ((x10.regionarray.Array.Anonymous$14520<$T>)t$140975).out$;
                    
                    //#line 404 . "x10/regionarray/Array.x10"
                    final x10.regionarray.Region t$140976 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$139100).region));
                    
                    //#line 404 . "x10/regionarray/Array.x10"
                    final x10.lang.Iterator t$140977 = t$140976.iterator();
                    
                    //#line 424 "x10/regionarray/Array.x10"
                    ((x10.regionarray.Array.Anonymous$14520.Anonymous$14577<$T>)this).regIt = ((x10.lang.Iterator)(t$140977));
                }
                return this;
            }
            
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$158<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$158> $RTT = 
            x10.rtt.StaticFunType.<$Closure$158> make($Closure$158.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.$Closure$158<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dstPoint = $deserializer.readObject();
            $_obj.gra = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Array.$Closure$158 $_obj = new x10.regionarray.Array.$Closure$158((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.dstPoint);
            $serializer.write(this.gra);
            
        }
        
        // constructor just for allocation
        public $Closure$158(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.Array.$Closure$158.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.core.Long $apply$G() {
            return x10.core.Long.$box($apply$O());
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$158 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$Array$1x10$regionarray$Array$$Closure$158$$T$2$2 {}
        
    
        
        public long $apply$O() {
            
            //#line 938 "x10/regionarray/Array.x10"
            try {{
                
                //#line 938 "x10/regionarray/Array.x10"
                final x10.regionarray.Array t$135978 = (((x10.core.GlobalRef<x10.regionarray.Array<$T>>)(this.gra))).$apply$G();
                
                //#line 938 "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$135979 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)t$135978).region));
                
                //#line 938 "x10/regionarray/Array.x10"
                final long t$135980 = t$135979.indexOf$O(((x10.lang.Point)(this.dstPoint)));
                
                //#line 938 "x10/regionarray/Array.x10"
                return t$135980;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 938 "x10/regionarray/Array.x10"
                long __lowerer__var__1__ = (x10.core.Long.$unbox(x10.xrx.Runtime.<x10.core.Long> wrapAtChecked$G(x10.rtt.Types.LONG, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 938 "x10/regionarray/Array.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.core.GlobalRef<x10.regionarray.Array<$T>> gra;
        public x10.lang.Point dstPoint;
        
        public $Closure$158(final x10.rtt.Type $T, final x10.core.GlobalRef<x10.regionarray.Array<$T>> gra, final x10.lang.Point dstPoint, __0$1x10$regionarray$Array$1x10$regionarray$Array$$Closure$158$$T$2$2 $dummy) {
            x10.regionarray.Array.$Closure$158.$initParams(this, $T);
             {
                ((x10.regionarray.Array.$Closure$158<$T>)this).gra = ((x10.core.GlobalRef)(gra));
                ((x10.regionarray.Array.$Closure$158<$T>)this).dstPoint = ((x10.lang.Point)(dstPoint));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$159<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$159> $RTT = 
            x10.rtt.StaticFunType.<$Closure$159> make($Closure$159.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.$Closure$159<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.gra = $deserializer.readObject();
            $_obj.srcPoint = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Array.$Closure$159 $_obj = new x10.regionarray.Array.$Closure$159((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.gra);
            $serializer.write(this.srcPoint);
            
        }
        
        // constructor just for allocation
        public $Closure$159(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.Array.$Closure$159.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.core.Long $apply$G() {
            return x10.core.Long.$box($apply$O());
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$159 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$Array$1x10$regionarray$Array$$Closure$159$$T$2$2 {}
        
    
        
        public long $apply$O() {
            
            //#line 1041 "x10/regionarray/Array.x10"
            try {{
                
                //#line 1041 "x10/regionarray/Array.x10"
                final x10.regionarray.Array t$135982 = (((x10.core.GlobalRef<x10.regionarray.Array<$T>>)(this.gra))).$apply$G();
                
                //#line 1041 "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$135983 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)t$135982).region));
                
                //#line 1041 "x10/regionarray/Array.x10"
                final long t$135984 = t$135983.indexOf$O(((x10.lang.Point)(this.srcPoint)));
                
                //#line 1041 "x10/regionarray/Array.x10"
                return t$135984;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 1041 "x10/regionarray/Array.x10"
                long __lowerer__var__1__ = (x10.core.Long.$unbox(x10.xrx.Runtime.<x10.core.Long> wrapAtChecked$G(x10.rtt.Types.LONG, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 1041 "x10/regionarray/Array.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.core.GlobalRef<x10.regionarray.Array<$T>> gra;
        public x10.lang.Point srcPoint;
        
        public $Closure$159(final x10.rtt.Type $T, final x10.core.GlobalRef<x10.regionarray.Array<$T>> gra, final x10.lang.Point srcPoint, __0$1x10$regionarray$Array$1x10$regionarray$Array$$Closure$159$$T$2$2 $dummy) {
            x10.regionarray.Array.$Closure$159.$initParams(this, $T);
             {
                ((x10.regionarray.Array.$Closure$159<$T>)this).gra = ((x10.core.GlobalRef)(gra));
                ((x10.regionarray.Array.$Closure$159<$T>)this).srcPoint = ((x10.lang.Point)(srcPoint));
            }
        }
        
    }
    
}




