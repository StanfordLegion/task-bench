package x10.regionarray;


/**
 * A BlockBlockDistGhostManager manages the local ghost region for a Ghostable
 * array that is distributed using a BlockBlockDist.
 * Ghost regions are sent using a simple put algorithm with no internal synchronization.
 */
@x10.runtime.impl.java.X10Generated
final public class BlockBlockDistGhostManager extends x10.regionarray.GhostManager implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<BlockBlockDistGhostManager> $RTT = 
        x10.rtt.NamedType.<BlockBlockDistGhostManager> make("x10.regionarray.BlockBlockDistGhostManager",
                                                            BlockBlockDistGhostManager.class,
                                                            new x10.rtt.Type[] {
                                                                x10.regionarray.GhostManager.$RTT
                                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockBlockDistGhostManager $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.GhostManager.$_deserialize_body($_obj, $deserializer);
        $_obj.bbd = $deserializer.readObject();
        $_obj.neighbors = $deserializer.readObject();
        $_obj.periodic = $deserializer.readBoolean();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.BlockBlockDistGhostManager $_obj = new x10.regionarray.BlockBlockDistGhostManager((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.bbd);
        $serializer.write(this.neighbors);
        $serializer.write(this.periodic);
        
    }
    
    // constructor just for allocation
    public BlockBlockDistGhostManager(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 24 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public x10.regionarray.BlockBlockDist bbd;
    
    //#line 25 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag> neighbors;
    
    //#line 26 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public boolean periodic;
    
    
    //#line 28 "x10/regionarray/BlockBlockDistGhostManager.x10"
    // creation method for java code (1-phase java constructor)
    public BlockBlockDistGhostManager(final long ghostWidth, final x10.regionarray.Dist bbd, final boolean periodic) {
        this((java.lang.System[]) null);
        x10$regionarray$BlockBlockDistGhostManager$$init$S(ghostWidth, bbd, periodic);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.BlockBlockDistGhostManager x10$regionarray$BlockBlockDistGhostManager$$init$S(final long ghostWidth, final x10.regionarray.Dist bbd, final boolean periodic) {
         {
            
            //#line 29 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.regionarray.GhostManager this$147132 = this;
            
            //#line 22 .. "x10/regionarray/GhostManager.x10"
            this$147132.currentPhase = ((byte) 0);
            
            //#line 38 . "x10/regionarray/GhostManager.x10"
            this$147132.ghostWidth = ghostWidth;
            
            //#line 39 . "x10/regionarray/GhostManager.x10"
            this$147132.currentPhase = ((byte) 0);
            
            //#line 28 "x10/regionarray/BlockBlockDistGhostManager.x10"
            
            
            //#line 30 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.regionarray.BlockBlockDist t$147155 = ((x10.regionarray.BlockBlockDist)(x10.rtt.Types.<x10.regionarray.BlockBlockDist> cast(bbd,x10.regionarray.BlockBlockDist.$RTT)));
            
            //#line 30 "x10/regionarray/BlockBlockDistGhostManager.x10"
            this.bbd = ((x10.regionarray.BlockBlockDist)(t$147155));
            
            //#line 31 "x10/regionarray/BlockBlockDistGhostManager.x10"
            this.periodic = periodic;
            
            //#line 32 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.core.Rail t$147156 = this.createNeighbors();
            
            //#line 32 "x10/regionarray/BlockBlockDistGhostManager.x10"
            this.neighbors = ((x10.core.Rail)(t$147156));
        }
        return this;
    }
    
    
    
    //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public x10.core.Rail getNeighbors() {
        
        //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail t$147157 = ((x10.core.Rail)(this.neighbors));
        
        //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147161 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)t$147157).size;
        
        //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.fun.Fun_0_1 t$147162 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockBlockDistGhostManager.$Closure$163(this, this.neighbors, (x10.regionarray.BlockBlockDistGhostManager.$Closure$163.__1$1x10$regionarray$GhostManager$GhostNeighborFlag$2) null)));
        
        //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail t$147163 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.Place>(x10.lang.Place.$RTT, ((long)(t$147161)), ((x10.core.fun.Fun_0_1)(t$147162)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return t$147163;
    }
    
    
    //#line 54 "x10/regionarray/BlockBlockDistGhostManager.x10"
    /** 
     * Creates the list of neighboring places that hold the blocks immediately
     * surrounding place p.  In a BlockBlockDist, a place may hold two blocks
     * contiguous in axis0 ("west-east"), so a place may adjoin either one or
     * two neighboring places in the "north" and "south" directions.
     * In a periodic distribution, a single neighbor may appear multiple times
     * in the list due to wrapping in any dimension.
     * The neighbors for place p are laid out as follows:
     *
     *   -- axis0 -->
     *  6 | 7 | 8 | 9  ^
     * --------------- |
     *  4 |   p   | 5  | axis1
     * --------------- |
     *  0 | 1 | 2 | 3
     *
     */
    private x10.core.Rail createNeighbors() {
        
        //#line 55 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.util.ArrayList neighborList = ((x10.util.ArrayList)(new x10.util.ArrayList<x10.regionarray.GhostManager.GhostNeighborFlag>((java.lang.System[]) null, x10.regionarray.GhostManager.GhostNeighborFlag.$RTT)));
        
        //#line 55 "x10/regionarray/BlockBlockDistGhostManager.x10"
        neighborList.x10$util$ArrayList$$init$S();
        
        //#line 56 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist t$147164 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 56 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region t$147165 = ((x10.regionarray.Region)(t$147164.region));
        
        //#line 56 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region b = ((x10.regionarray.Region)(t$147165.boundingBox()));
        
        //#line 57 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist t$147166 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 57 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long axis0 = t$147166.axis0;
        
        //#line 58 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist t$147167 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 58 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long axis1 = t$147167.axis1;
        
        //#line 59 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist this$147137 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 59 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.lang.PlaceGroup pg = this$147137.pg;
        
        //#line 60 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long min0 = b.min$O((long)(axis0));
        
        //#line 61 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long max0 = b.max$O((long)(axis0));
        
        //#line 62 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long min1 = b.min$O((long)(axis1));
        
        //#line 63 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long max1 = b.max$O((long)(axis1));
        
        //#line 64 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147168 = ((max0) - (((long)(min0))));
        
        //#line 64 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long size0 = ((t$147168) + (((long)(1L))));
        
        //#line 65 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147169 = ((max1) - (((long)(min1))));
        
        //#line 65 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long size1 = ((t$147169) + (((long)(1L))));
        
        //#line 66 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147170 = ((size0) % (((long)(2L))));
        
        //#line 66 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$147171 = ((long) t$147170) == ((long) 0L);
        
        //#line 66 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long t$147172 =  0;
        
        //#line 66 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$147171) {
            
            //#line 66 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147172 = size0;
        } else {
            
            //#line 66 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147172 = ((size0) - (((long)(1L))));
        }
        
        //#line 67 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147173 = pg.numPlaces$O();
        
        //#line 67 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147174 = ((t$147172) * (((long)(size1))));
        
        //#line 67 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long P = java.lang.Math.min(((long)(t$147173)),((long)(t$147174)));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147175 = ((double)(long)(((long)(P))));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147176 = java.lang.Math.log(((double)(t$147175)));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147177 = java.lang.Math.log(((double)(2.0)));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147178 = ((t$147176) / (((double)(t$147177))));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147179 = ((t$147178) / (((double)(2.0))));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147180 = java.lang.Math.ceil(((double)(t$147179)));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147181 = ((long)(double)(((double)(t$147180))));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147182 = x10.lang.Math.pow2$O((long)(t$147181));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long divisions0 = java.lang.Math.min(((long)(t$147172)),((long)(t$147182)));
        
        //#line 69 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147183 = ((double)(long)(((long)(P))));
        
        //#line 69 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147184 = ((double)(long)(((long)(divisions0))));
        
        //#line 69 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147185 = ((t$147183) / (((double)(t$147184))));
        
        //#line 69 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147186 = java.lang.Math.ceil(((double)(t$147185)));
        
        //#line 69 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147187 = ((long)(double)(((double)(t$147186))));
        
        //#line 69 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long divisions1 = java.lang.Math.min(((long)(size1)),((long)(t$147187)));
        
        //#line 70 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long numBlocks = ((divisions0) * (((long)(divisions1))));
        
        //#line 71 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long leftOver = ((numBlocks) - (((long)(P))));
        
        //#line 73 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long i = pg.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147188 = ((divisions0) % (((long)(2L))));
        
        //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$147191 = ((long) t$147188) == ((long) 0L);
        
        //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long t$147192 =  0;
        
        //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$147191) {
            
            //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147192 = 0L;
        } else {
            
            //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147189 = ((i) * (((long)(2L))));
            
            //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147190 = ((divisions0) + (((long)(1L))));
            
            //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147192 = ((t$147189) / (((long)(t$147190))));
        }
        
        //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$147196 = ((i) < (((long)(leftOver))));
        
        //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long t$147197 =  0;
        
        //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$147196) {
            
            //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147193 = ((i) * (((long)(2L))));
            
            //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147194 = ((t$147193) - (((long)(t$147192))));
            
            //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147197 = ((t$147194) % (((long)(divisions0))));
        } else {
            
            //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147195 = ((i) + (((long)(leftOver))));
            
            //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147197 = ((t$147195) % (((long)(divisions0))));
        }
        
        //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$147200 = ((i) < (((long)(leftOver))));
        
        //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long t$147201 =  0;
        
        //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$147200) {
            
            //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147198 = ((i) * (((long)(2L))));
            
            //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147201 = ((t$147198) / (((long)(divisions0))));
        } else {
            
            //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147199 = ((i) + (((long)(leftOver))));
            
            //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147201 = ((t$147199) / (((long)(divisions0))));
        }
        
        //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long i$147460 = -1L;
        
        //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
        for (;
             true;
             ) {
            
            //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final boolean t$147462 = ((i$147460) <= (((long)(1L))));
            
            //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (!(t$147462)) {
                
                //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
                break;
            }
            
            //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
            long i$147454 = -1L;
            
            //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
            for (;
                 true;
                 ) {
                
                //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$147456 = ((i$147454) <= (((long)(1L))));
                
                //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (!(t$147456)) {
                    
                    //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    break;
                }
                
                //#line 82 "x10/regionarray/BlockBlockDistGhostManager.x10"
                boolean t$147413 = ((long) i$147454) != ((long) 0L);
                
                //#line 82 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (!(t$147413)) {
                    
                    //#line 82 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    t$147413 = ((long) i$147460) != ((long) 0L);
                }
                
                //#line 82 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$147413) {
                    
                    //#line 83 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    long neighborBlockIndex$147415 = ((t$147197) + (((long)(i$147454))));
                    
                    //#line 84 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    long neighborBlockIndex$147416 = ((t$147201) + (((long)(i$147460))));
                    
                    //#line 85 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    boolean t$147417 = ((i) < (((long)(leftOver))));
                    
                    //#line 85 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$147417) {
                        
                        //#line 85 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        t$147417 = ((long) i$147454) == ((long) 1L);
                    }
                    
                    //#line 85 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$147417) {
                        
                        //#line 87 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147420 = ((neighborBlockIndex$147415) + (((long)(1L))));
                        
                        //#line 87 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        neighborBlockIndex$147415 = t$147420;
                    }
                    
                    //#line 89 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$147423 = this.periodic;
                    
                    //#line 89 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long groupIndex$147424 = x10.regionarray.BlockBlockDistGhostManager.getGroupIndex$O((long)(neighborBlockIndex$147415), (long)(neighborBlockIndex$147416), (long)(divisions0), (long)(divisions1), (long)(leftOver), (boolean)(t$147423), (long)(i));
                    
                    //#line 90 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.lang.Place place$147425 = pg.$apply((long)(groupIndex$147424));
                    
                    //#line 91 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    boolean t$147426 = this.periodic;
                    
                    //#line 91 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (!(t$147426)) {
                        
                        //#line 91 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        t$147426 = (!x10.rtt.Equality.equalsequals((place$147425),(x10.x10rt.X10RT.here())));
                    }
                    
                    //#line 91 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$147426) {
                        
                        //#line 92 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$147430 = this.periodic;
                        
                        //#line 92 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.lang.Point shift$147431 = ((x10.lang.Point)(this.getNeighborShift((long)(neighborBlockIndex$147415), (long)(neighborBlockIndex$147416), (long)(divisions0), (long)(divisions1), (boolean)(t$147430))));
                        
                        //#line 93 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag alloc$147432 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(new x10.regionarray.GhostManager.GhostNeighborFlag((java.lang.System[]) null)));
                        
                        //#line 79 . "x10/regionarray/GhostManager.x10"
                        alloc$147432.place = place$147425;
                        
                        //#line 79 . "x10/regionarray/GhostManager.x10"
                        alloc$147432.shift = shift$147431;
                        
                        //#line 79 .. "x10/regionarray/GhostManager.x10"
                        alloc$147432.received = false;
                        
                        //#line 93 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        ((x10.util.ArrayList<x10.regionarray.GhostManager.GhostNeighborFlag>)neighborList).add__0x10$util$ArrayList$$T$O(((x10.regionarray.GhostManager.GhostNeighborFlag)(alloc$147432)));
                    }
                    
                    //#line 95 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$147435 = ((long) i$147454) == ((long) 0L);
                    
                    //#line 95 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$147435) {
                        
                        //#line 97 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        boolean t$147436 = ((i) < (((long)(leftOver))));
                        
                        //#line 97 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$147436) {
                            
                            //#line 97 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            t$147436 = ((groupIndex$147424) >= (((long)(leftOver))));
                        }
                        
                        //#line 97 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$147436) {
                            
                            //#line 98 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final long t$147438 = ((groupIndex$147424) + (((long)(1L))));
                            
                            //#line 98 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final x10.lang.Place place$147439 = pg.$apply((long)(t$147438));
                            
                            //#line 99 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            boolean t$147440 = this.periodic;
                            
                            //#line 99 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            if (!(t$147440)) {
                                
                                //#line 99 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                t$147440 = (!x10.rtt.Equality.equalsequals((place$147439),(x10.x10rt.X10RT.here())));
                            }
                            
                            //#line 99 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            if (t$147440) {
                                
                                //#line 100 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                final boolean t$147444 = this.periodic;
                                
                                //#line 100 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                final x10.lang.Point shift$147445 = ((x10.lang.Point)(this.getNeighborShift((long)(neighborBlockIndex$147415), (long)(neighborBlockIndex$147416), (long)(divisions0), (long)(divisions1), (boolean)(t$147444))));
                                
                                //#line 101 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                final x10.regionarray.GhostManager.GhostNeighborFlag alloc$147446 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(new x10.regionarray.GhostManager.GhostNeighborFlag((java.lang.System[]) null)));
                                
                                //#line 79 . "x10/regionarray/GhostManager.x10"
                                alloc$147446.place = place$147439;
                                
                                //#line 79 . "x10/regionarray/GhostManager.x10"
                                alloc$147446.shift = shift$147445;
                                
                                //#line 79 .. "x10/regionarray/GhostManager.x10"
                                alloc$147446.received = false;
                                
                                //#line 101 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                ((x10.util.ArrayList<x10.regionarray.GhostManager.GhostNeighborFlag>)neighborList).add__0x10$util$ArrayList$$T$O(((x10.regionarray.GhostManager.GhostNeighborFlag)(alloc$147446)));
                            }
                        } else {
                            
                            //#line 103 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            boolean t$147449 = ((i) >= (((long)(leftOver))));
                            
                            //#line 103 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            if (t$147449) {
                                
                                //#line 103 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                t$147449 = ((groupIndex$147424) < (((long)(leftOver))));
                            }
                            
                            //#line 103 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            if (t$147449) {
                                
                                //#line 106 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                ((x10.util.ArrayList<x10.regionarray.GhostManager.GhostNeighborFlag>)neighborList).removeLast$G();
                            }
                        }
                    }
                }
                
                //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long t$147453 = ((i$147454) + (((long)(1L))));
                
                //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
                i$147454 = t$147453;
            }
            
            //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147459 = ((i$147460) + (((long)(1L))));
            
            //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
            i$147460 = t$147459;
        }
        
        //#line 112 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail t$147237 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)
                                         ((x10.util.ArrayList<x10.regionarray.GhostManager.GhostNeighborFlag>)neighborList).toRail());
        
        //#line 112 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return t$147237;
    }
    
    public static x10.core.Rail createNeighbors$P(final x10.regionarray.BlockBlockDistGhostManager BlockBlockDistGhostManager) {
        return BlockBlockDistGhostManager.createNeighbors();
    }
    
    
    //#line 115 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public long getInverseNeighborIndex$O(final long neighborIndex) {
        
        //#line 116 "x10/regionarray/BlockBlockDistGhostManager.x10"
        assert ((neighborIndex) >= (((long)(0L)))) && ((neighborIndex) <= (((long)(9L))));
        
        //#line 117 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147238 = ((9L) - (((long)(neighborIndex))));
        
        //#line 117 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return t$147238;
    }
    
    
    //#line 120 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public void setNeighborReceived(final x10.lang.Place place, final x10.lang.Point shift) {
        
        //#line 120 "x10/regionarray/BlockBlockDistGhostManager.x10"
        try {{
            
            //#line 120 "x10/regionarray/BlockBlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.core.Rail rail$147474 = ((x10.core.Rail)(this.neighbors));
                
                //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long size$147475 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)rail$147474).size;
                
                //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                long idx$147471 = 0L;
                {
                    
                    //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag[] rail$147474$value$147597 = ((x10.regionarray.GhostManager.GhostNeighborFlag[])rail$147474.value);
                    
                    //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$147473 = ((idx$147471) < (((long)(size$147475))));
                        
                        //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (!(t$147473)) {
                            
                            //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            break;
                        }
                        
                        //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag neighborFlag$147468 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(((x10.regionarray.GhostManager.GhostNeighborFlag)rail$147474$value$147597[(int)idx$147471])));
                        
                        //#line 122 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.lang.Place t$147463 = ((x10.lang.Place)(neighborFlag$147468.place));
                        
                        //#line 122 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        boolean t$147464 = x10.rtt.Equality.equalsequals((t$147463),(place));
                        
                        //#line 122 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$147464) {
                            
                            //#line 122 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final x10.lang.Point t$147465 = ((x10.lang.Point)(neighborFlag$147468.shift));
                            
                            //#line 122 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            t$147464 = t$147465.equals(((java.lang.Object)(shift)));
                        }
                        
                        //#line 122 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$147464) {
                            
                            //#line 123 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            neighborFlag$147468.received = true;
                            
                            //#line 124 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            return;
                        }
                        
                        //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147470 = ((idx$147471) + (((long)(1L))));
                        
                        //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        idx$147471 = t$147470;
                    }
                }
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final java.lang.String t$147249 = ((x10.x10rt.X10RT.here()) + (" trying to notify received from neighbor "));
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final java.lang.String t$147250 = ((t$147249) + (place));
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final java.lang.String t$147251 = ((t$147250) + (" shift "));
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final java.lang.String t$147252 = ((t$147251) + (shift));
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final java.lang.String t$147253 = ((t$147252) + (" - not a neighbor!"));
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.lang.BadPlaceException t$147254 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$147253)));
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                throw t$147254;
            }
        }}finally {{
              
              //#line 120 "x10/regionarray/BlockBlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 130 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public boolean allNeighborsReceived$O() {
        
        //#line 130 "x10/regionarray/BlockBlockDistGhostManager.x10"
        try {{
            
            //#line 130 "x10/regionarray/BlockBlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 131 "x10/regionarray/BlockBlockDistGhostManager.x10"
                long i = 0L;
                
                //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.core.Rail rail$147487 = ((x10.core.Rail)(this.neighbors));
                
                //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long size$147488 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)rail$147487).size;
                
                //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                long idx$147484 = 0L;
                {
                    
                    //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag[] rail$147487$value$147598 = ((x10.regionarray.GhostManager.GhostNeighborFlag[])rail$147487.value);
                    
                    //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$147486 = ((idx$147484) < (((long)(size$147488))));
                        
                        //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (!(t$147486)) {
                            
                            //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            break;
                        }
                        
                        //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag neighborFlag$147481 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(((x10.regionarray.GhostManager.GhostNeighborFlag)rail$147487$value$147598[(int)idx$147484])));
                        
                        //#line 133 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$147476 = neighborFlag$147481.received;
                        
                        //#line 133 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$147477 = ((boolean) t$147476) == ((boolean) false);
                        
                        //#line 133 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$147477) {
                            
                            //#line 134 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            return false;
                        }
                        
                        //#line 136 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147479 = ((i) + (((long)(1L))));
                        
                        //#line 136 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        i = t$147479;
                        
                        //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147483 = ((idx$147484) + (((long)(1L))));
                        
                        //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        idx$147484 = t$147483;
                    }
                }
                
                //#line 138 "x10/regionarray/BlockBlockDistGhostManager.x10"
                return true;
            }
        }}finally {{
              
              //#line 130 "x10/regionarray/BlockBlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 141 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public void resetNeighborsReceived() {
        
        //#line 141 "x10/regionarray/BlockBlockDistGhostManager.x10"
        try {{
            
            //#line 141 "x10/regionarray/BlockBlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.core.Rail rail$146735 = ((x10.core.Rail)(this.neighbors));
                
                //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long size$146736 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)rail$146735).size;
                
                //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                long idx$147493 = 0L;
                {
                    
                    //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag[] rail$146735$value$147599 = ((x10.regionarray.GhostManager.GhostNeighborFlag[])rail$146735.value);
                    
                    //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$147495 = ((idx$147493) < (((long)(size$146736))));
                        
                        //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (!(t$147495)) {
                            
                            //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            break;
                        }
                        
                        //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag neighborFlag$147490 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(((x10.regionarray.GhostManager.GhostNeighborFlag)rail$146735$value$147599[(int)idx$147493])));
                        
                        //#line 143 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        neighborFlag$147490.received = false;
                        
                        //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147492 = ((idx$147493) + (((long)(1L))));
                        
                        //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        idx$147493 = t$147492;
                    }
                }
            }
        }}finally {{
              
              //#line 141 "x10/regionarray/BlockBlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 147 "x10/regionarray/BlockBlockDistGhostManager.x10"
    private void setAllNeighborsReceived() {
        
        //#line 147 "x10/regionarray/BlockBlockDistGhostManager.x10"
        try {{
            
            //#line 147 "x10/regionarray/BlockBlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.core.Rail rail$146760 = ((x10.core.Rail)(this.neighbors));
                
                //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long size$146761 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)rail$146760).size;
                
                //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                long idx$147500 = 0L;
                {
                    
                    //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag[] rail$146760$value$147600 = ((x10.regionarray.GhostManager.GhostNeighborFlag[])rail$146760.value);
                    
                    //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$147502 = ((idx$147500) < (((long)(size$146761))));
                        
                        //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (!(t$147502)) {
                            
                            //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            break;
                        }
                        
                        //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag neighborFlag$147497 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(((x10.regionarray.GhostManager.GhostNeighborFlag)rail$146760$value$147600[(int)idx$147500])));
                        
                        //#line 149 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        neighborFlag$147497.received = true;
                        
                        //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147499 = ((idx$147500) + (((long)(1L))));
                        
                        //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        idx$147500 = t$147499;
                    }
                }
            }
        }}finally {{
              
              //#line 147 "x10/regionarray/BlockBlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    public static void setAllNeighborsReceived$P(final x10.regionarray.BlockBlockDistGhostManager BlockBlockDistGhostManager) {
        BlockBlockDistGhostManager.setAllNeighborsReceived();
    }
    
    
    //#line 153 "x10/regionarray/BlockBlockDistGhostManager.x10"
    private x10.lang.Point getNeighborShift(final long neighborBlockIndex0, final long neighborBlockIndex1, final long divisions0, final long divisions1, final boolean periodic) {
        
        //#line 154 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long axis0Shift = 0L;
        
        //#line 155 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long axis1Shift = 0L;
        
        //#line 157 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (periodic) {
            
            //#line 159 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final boolean t$147278 = ((neighborBlockIndex0) < (((long)(0L))));
            
            //#line 159 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (t$147278) {
                
                //#line 160 "x10/regionarray/BlockBlockDistGhostManager.x10"
                axis0Shift = 1L;
            } else {
                
                //#line 161 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$147277 = ((neighborBlockIndex0) >= (((long)(divisions0))));
                
                //#line 161 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$147277) {
                    
                    //#line 162 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    axis0Shift = -1L;
                }
            }
            
            //#line 164 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final boolean t$147280 = ((neighborBlockIndex1) < (((long)(0L))));
            
            //#line 164 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (t$147280) {
                
                //#line 165 "x10/regionarray/BlockBlockDistGhostManager.x10"
                axis1Shift = 1L;
            } else {
                
                //#line 166 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$147279 = ((neighborBlockIndex1) >= (((long)(divisions1))));
                
                //#line 166 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$147279) {
                    
                    //#line 167 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    axis1Shift = -1L;
                }
            }
        }
        
        //#line 170 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.lang.Point t$147283 = ((x10.lang.Point)(this.getShift((long)(axis0Shift), (long)(axis1Shift))));
        
        //#line 170 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return t$147283;
    }
    
    public static x10.lang.Point getNeighborShift$P(final long neighborBlockIndex0, final long neighborBlockIndex1, final long divisions0, final long divisions1, final boolean periodic, final x10.regionarray.BlockBlockDistGhostManager BlockBlockDistGhostManager) {
        return BlockBlockDistGhostManager.getNeighborShift((long)(neighborBlockIndex0), (long)(neighborBlockIndex1), (long)(divisions0), (long)(divisions1), (boolean)(periodic));
    }
    
    
    //#line 173 "x10/regionarray/BlockBlockDistGhostManager.x10"
    private x10.lang.Point getShift(final long axis0Shift, final long axis1Shift) {
        
        //#line 174 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist t$147284 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 174 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region fullRegion = ((x10.regionarray.Region)(t$147284.region));
        
        //#line 175 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist t$147285 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 175 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long axis0 = t$147285.axis0;
        
        //#line 176 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist t$147286 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 176 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long axis1 = t$147286.axis1;
        
        //#line 177 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147287 = fullRegion.max$O((long)(axis0));
        
        //#line 177 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147288 = fullRegion.min$O((long)(axis0));
        
        //#line 177 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147289 = ((t$147287) - (((long)(t$147288))));
        
        //#line 177 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long axis0Size = ((t$147289) + (((long)(1L))));
        
        //#line 178 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147290 = fullRegion.max$O((long)(axis1));
        
        //#line 178 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147291 = fullRegion.min$O((long)(axis1));
        
        //#line 178 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147292 = ((t$147290) - (((long)(t$147291))));
        
        //#line 178 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long axis1Size = ((t$147292) + (((long)(1L))));
        
        //#line 179 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147293 = fullRegion.rank;
        
        //#line 179 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail coords = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$147293)))));
        
        //#line 180 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147294 = ((axis0Shift) * (((long)(axis0Size))));
        
        //#line 180 "x10/regionarray/BlockBlockDistGhostManager.x10"
        ((long[])coords.value)[(int)axis0] = t$147294;
        
        //#line 181 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147295 = ((axis1Shift) * (((long)(axis1Size))));
        
        //#line 181 "x10/regionarray/BlockBlockDistGhostManager.x10"
        ((long[])coords.value)[(int)axis1] = t$147295;
        
        //#line 183 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.lang.Point t$147296 = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(coords)))));
        
        //#line 183 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return t$147296;
    }
    
    public static x10.lang.Point getShift$P(final long axis0Shift, final long axis1Shift, final x10.regionarray.BlockBlockDistGhostManager BlockBlockDistGhostManager) {
        return BlockBlockDistGhostManager.getShift((long)(axis0Shift), (long)(axis1Shift));
    }
    
    
    //#line 190 "x10/regionarray/BlockBlockDistGhostManager.x10"
    /**
     * Send ghost data for this place to neighboring places in a BlockBlockDist 
     * using a simple 'put' algorithm with no internal synchronization.
     */
    public void sendGhosts(final x10.regionarray.Ghostable array) {
        
        //#line 191 "x10/regionarray/BlockBlockDistGhostManager.x10"
        this.prepareToSendGhosts();
        
        //#line 192 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist this$147148 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 192 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.lang.Place p$147147 = ((x10.lang.Place)(x10.x10rt.X10RT.here()));
        
        //#line 192 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region regionHere = ((x10.regionarray.Region)(this$147148.get(((x10.lang.Place)(p$147147)))));
        
        //#line 193 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$147297 = regionHere.isEmpty$O();
        
        //#line 193 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$147297) {
            
            //#line 194 "x10/regionarray/BlockBlockDistGhostManager.x10"
            this.setAllNeighborsReceived();
            
            //#line 195 "x10/regionarray/BlockBlockDistGhostManager.x10"
            return;
        }
        
        //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail rail$147558 = ((x10.core.Rail)(this.neighbors));
        
        //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long size$147559 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)rail$147558).size;
        
        //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long idx$147555 = 0L;
        {
            
            //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag[] rail$147558$value$147601 = ((x10.regionarray.GhostManager.GhostNeighborFlag[])rail$147558.value);
            
            //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
            for (;
                 true;
                 ) {
                
                //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$147557 = ((idx$147555) < (((long)(size$147559))));
                
                //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (!(t$147557)) {
                    
                    //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    break;
                }
                
                //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag neighborFlag$147552 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(((x10.regionarray.GhostManager.GhostNeighborFlag)rail$147558$value$147601[(int)idx$147555])));
                
                //#line 199 "x10/regionarray/BlockBlockDistGhostManager.x10"
                boolean sentToNeighbor$147503 = false;
                
                //#line 200 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.lang.Place neighborPlace$147504 = ((x10.lang.Place)(neighborFlag$147552.place));
                
                //#line 201 "x10/regionarray/BlockBlockDistGhostManager.x10"
                boolean t$147505 = (!x10.rtt.Equality.equalsequals((neighborPlace$147504),(x10.x10rt.X10RT.here())));
                
                //#line 201 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (!(t$147505)) {
                    
                    //#line 201 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    t$147505 = this.periodic;
                }
                
                //#line 201 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$147505) {
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.Region t$147507 = this.getGhostRegion(((x10.lang.Place)(neighborPlace$147504)));
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.Region t$147508 = ((x10.regionarray.Region)
                                                              t$147507);
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$147509 = t$147508.rect;
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    boolean t$147510 = ((boolean) t$147509) == ((boolean) true);
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$147510) {
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147511 = t$147508.rank;
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.BlockBlockDist t$147512 = ((x10.regionarray.BlockBlockDist)(x10.regionarray.BlockBlockDistGhostManager.this.bbd));
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$147513 = ((x10.regionarray.Region)(t$147512.region));
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147514 = t$147513.rank;
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        t$147510 = ((long) t$147511) == ((long) t$147514);
                    }
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$147516 = !(t$147510);
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$147516) {
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.lang.FailedDynamicCheckException t$147517 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==this(:x10.regionarray.BlockBlockDistGhostManager).bbd.region.rank}");
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        throw t$147517;
                    }
                    
                    //#line 204 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    x10.regionarray.Region regionToSend$147519 =  null;
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.lang.Point t$147520 = ((x10.lang.Point)(neighborFlag$147552.shift));
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.lang.Point t$147521 = ((x10.lang.Point)
                                                      t$147520);
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$147522 = t$147521.rank;
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$147523 = regionHere.rank;
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$147524 = ((long) t$147522) == ((long) t$147523);
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$147525 = !(t$147524);
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$147525) {
                        
                        //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.lang.FailedDynamicCheckException t$147526 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==regionHere.rank}");
                        
                        //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        throw t$147526;
                    }
                    
                    //#line 206 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$147528 = this.periodic;
                    
                    //#line 206 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$147528) {
                        
                        //#line 207 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region shiftedNeighbor$147529 = ((x10.regionarray.Region)(t$147508.$minus(((x10.lang.Point)(t$147521)))));
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$147530 = ((x10.regionarray.Region)(regionHere.$and(((x10.regionarray.Region)(shiftedNeighbor$147529)))));
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$147531 = ((x10.regionarray.Region)
                                                                  t$147530);
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$147532 = t$147531.rect;
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        boolean t$147533 = ((boolean) t$147532) == ((boolean) true);
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$147533) {
                            
                            //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final long t$147534 = t$147531.rank;
                            
                            //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final long t$147535 = regionHere.rank;
                            
                            //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            t$147533 = ((long) t$147534) == ((long) t$147535);
                        }
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$147537 = !(t$147533);
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$147537) {
                            
                            //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final x10.lang.FailedDynamicCheckException t$147538 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==regionHere.rank}");
                            
                            //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            throw t$147538;
                        }
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        regionToSend$147519 = ((x10.regionarray.Region)(t$147531));
                    } else {
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$147539 = ((x10.regionarray.Region)(regionHere.$and(((x10.regionarray.Region)(t$147508)))));
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$147540 = ((x10.regionarray.Region)
                                                                  t$147539);
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$147541 = t$147540.rect;
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        boolean t$147542 = ((boolean) t$147541) == ((boolean) true);
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$147542) {
                            
                            //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final long t$147543 = t$147540.rank;
                            
                            //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final long t$147544 = regionHere.rank;
                            
                            //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            t$147542 = ((long) t$147543) == ((long) t$147544);
                        }
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$147546 = !(t$147542);
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$147546) {
                            
                            //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final x10.lang.FailedDynamicCheckException t$147547 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==regionHere.rank}");
                            
                            //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            throw t$147547;
                        }
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        regionToSend$147519 = ((x10.regionarray.Region)(t$147540));
                    }
                    
                    //#line 212 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager this$147549 = ((x10.regionarray.GhostManager)
                                                                       this);
                    
                    //#line 43 . "x10/regionarray/GhostManager.x10"
                    final byte t$147550 = this$147549.currentPhase;
                    
                    //#line 212 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    array.putOverlap(((x10.regionarray.Region)(regionToSend$147519)), ((x10.lang.Place)(neighborPlace$147504)), ((x10.lang.Point)(t$147521)), (byte)(t$147550));
                    
                    //#line 213 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    sentToNeighbor$147503 = true;
                }
                
                //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long t$147554 = ((idx$147555) + (((long)(1L))));
                
                //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
                idx$147555 = t$147554;
            }
        }
    }
    
    
    //#line 227 "x10/regionarray/BlockBlockDistGhostManager.x10"
    /**
     * Gets the ghost region for a given place, which is the bounding box 
     * for the region held at that place, expanded in each dimension by
     * <code>ghostWidth</code>.  For a periodic distribution, the ghost
     * region may extend beyond the limits of the entire region. For a 
     * non-periodic dist, the ghost region does not extend beyond the min/max
     * of the region in any dimension.
     * @return the ghost region for the given place
     */
    public x10.regionarray.Region getGhostRegion(final x10.lang.Place place) {
        
        //#line 228 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist this$147153 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 228 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region region = ((x10.regionarray.Region)(this$147153.get(((x10.lang.Place)(place)))));
        
        //#line 229 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$147341 = region.isEmpty$O();
        
        //#line 229 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$147341) {
            
            //#line 229 "x10/regionarray/BlockBlockDistGhostManager.x10"
            return region;
        }
        
        //#line 231 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region r = ((x10.regionarray.Region)(region.boundingBox()));
        
        //#line 232 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147342 = r.rank;
        
        //#line 232 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail min = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$147342)))));
        
        //#line 233 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147343 = r.rank;
        
        //#line 233 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail max = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$147343)))));
        
        //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147595 = r.rank;
        
        //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long i$146809max$147596 = ((t$147595) - (((long)(1L))));
        
        //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long i$147592 = 0L;
        {
            
            //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long[] min$value$147602 = ((long[])min.value);
            
            //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long[] max$value$147603 = ((long[])max.value);
            
            //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
            for (;
                 true;
                 ) {
                
                //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$147594 = ((i$147592) <= (((long)(i$146809max$147596))));
                
                //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (!(t$147594)) {
                    
                    //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    break;
                }
                
                //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.regionarray.BlockBlockDist t$147560 = ((x10.regionarray.BlockBlockDist)(this.bbd));
                
                //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long t$147561 = t$147560.axis0;
                
                //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                boolean t$147562 = ((long) i$147592) == ((long) t$147561);
                
                //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (!(t$147562)) {
                    
                    //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.BlockBlockDist t$147563 = ((x10.regionarray.BlockBlockDist)(this.bbd));
                    
                    //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$147564 = t$147563.axis1;
                    
                    //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    t$147562 = ((long) i$147592) == ((long) t$147564);
                }
                
                //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$147562) {
                    
                    //#line 236 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$147566 = this.periodic;
                    
                    //#line 236 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$147566) {
                        
                        //#line 237 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147567 = r.min$O((long)(i$147592));
                        
                        //#line 237 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147568 = this.ghostWidth;
                        
                        //#line 237 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147569 = ((t$147567) - (((long)(t$147568))));
                        
                        //#line 237 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        min$value$147602[(int)i$147592]=t$147569;
                        
                        //#line 238 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147570 = r.max$O((long)(i$147592));
                        
                        //#line 238 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147571 = this.ghostWidth;
                        
                        //#line 238 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147572 = ((t$147570) + (((long)(t$147571))));
                        
                        //#line 238 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        max$value$147603[(int)i$147592]=t$147572;
                    } else {
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.BlockBlockDist t$147573 = ((x10.regionarray.BlockBlockDist)(this.bbd));
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$147574 = ((x10.regionarray.Region)(t$147573.region));
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147575 = t$147574.min$O((long)(i$147592));
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147576 = r.min$O((long)(i$147592));
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147577 = this.ghostWidth;
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147578 = ((t$147576) - (((long)(t$147577))));
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147579 = java.lang.Math.max(((long)(t$147575)),((long)(t$147578)));
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        min$value$147602[(int)i$147592]=t$147579;
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.BlockBlockDist t$147580 = ((x10.regionarray.BlockBlockDist)(this.bbd));
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$147581 = ((x10.regionarray.Region)(t$147580.region));
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147582 = t$147581.max$O((long)(i$147592));
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147583 = r.max$O((long)(i$147592));
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147584 = this.ghostWidth;
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147585 = ((t$147583) + (((long)(t$147584))));
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$147586 = java.lang.Math.min(((long)(t$147582)),((long)(t$147585)));
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        max$value$147603[(int)i$147592]=t$147586;
                    }
                } else {
                    
                    //#line 244 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$147587 = r.min$O((long)(i$147592));
                    
                    //#line 244 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    min$value$147602[(int)i$147592]=t$147587;
                    
                    //#line 245 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$147588 = r.max$O((long)(i$147592));
                    
                    //#line 245 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    max$value$147603[(int)i$147592]=t$147588;
                }
                
                //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long t$147591 = ((i$147592) + (((long)(1L))));
                
                //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
                i$147592 = t$147591;
            }
        }
        
        //#line 248 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region t$147379 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$Long$2__1$1x10$lang$Long$2(((x10.core.Rail)(min)), ((x10.core.Rail)(max)))));
        
        //#line 248 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return t$147379;
    }
    
    
    //#line 251 "x10/regionarray/BlockBlockDistGhostManager.x10"
    private static long getGroupIndex$O(long neighborBlockIndex0, long neighborBlockIndex1, final long divisions0, final long divisions1, final long leftOver, final boolean periodic, final long groupIndexHere) {
        
        //#line 252 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (periodic) {
            
            //#line 254 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final boolean t$147387 = ((neighborBlockIndex0) < (((long)(0L))));
            
            //#line 254 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (t$147387) {
                
                //#line 255 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long t$147382 = ((neighborBlockIndex0) + (((long)(divisions0))));
                
                //#line 255 "x10/regionarray/BlockBlockDistGhostManager.x10"
                neighborBlockIndex0 = t$147382;
            } else {
                
                //#line 256 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$147386 = ((neighborBlockIndex0) >= (((long)(divisions0))));
                
                //#line 256 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$147386) {
                    
                    //#line 257 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$147385 = ((neighborBlockIndex0) - (((long)(divisions0))));
                    
                    //#line 257 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    neighborBlockIndex0 = t$147385;
                }
            }
            
            //#line 259 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final boolean t$147395 = ((neighborBlockIndex1) < (((long)(0L))));
            
            //#line 259 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (t$147395) {
                
                //#line 260 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long t$147390 = ((neighborBlockIndex1) + (((long)(divisions1))));
                
                //#line 260 "x10/regionarray/BlockBlockDistGhostManager.x10"
                neighborBlockIndex1 = t$147390;
            } else {
                
                //#line 261 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$147394 = ((neighborBlockIndex1) >= (((long)(divisions1))));
                
                //#line 261 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$147394) {
                    
                    //#line 262 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$147393 = ((neighborBlockIndex1) - (((long)(divisions1))));
                    
                    //#line 262 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    neighborBlockIndex1 = t$147393;
                }
            }
        } else {
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            boolean t$147398 = ((neighborBlockIndex0) < (((long)(0L))));
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (!(t$147398)) {
                
                //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
                t$147398 = ((neighborBlockIndex0) >= (((long)(divisions0))));
            }
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            boolean t$147400 = t$147398;
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (!(t$147398)) {
                
                //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
                t$147400 = ((neighborBlockIndex1) < (((long)(0L))));
            }
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            boolean t$147402 = t$147400;
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (!(t$147400)) {
                
                //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
                t$147402 = ((neighborBlockIndex1) >= (((long)(divisions1))));
            }
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (t$147402) {
                
                //#line 270 "x10/regionarray/BlockBlockDistGhostManager.x10"
                return groupIndexHere;
            }
        }
        
        //#line 273 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long groupIndex;
        
        //#line 274 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147405 = ((neighborBlockIndex1) * (((long)(divisions0))));
        
        //#line 274 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long neighborBlockIndex = ((t$147405) + (((long)(neighborBlockIndex0))));
        
        //#line 275 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147407 = ((leftOver) * (((long)(2L))));
        
        //#line 275 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$147411 = ((neighborBlockIndex) <= (((long)(t$147407))));
        
        //#line 275 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$147411) {
            
            //#line 276 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147408 = ((neighborBlockIndex) / (((long)(2L))));
            
            //#line 276 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147409 = t$147408;
            
            //#line 276 "x10/regionarray/BlockBlockDistGhostManager.x10"
            groupIndex = t$147409;
        } else {
            
            //#line 278 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147410 = ((neighborBlockIndex) - (((long)(leftOver))));
            
            //#line 278 "x10/regionarray/BlockBlockDistGhostManager.x10"
            groupIndex = t$147410;
        }
        
        //#line 280 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return groupIndex;
    }
    
    public static long getGroupIndex$P$O(long neighborBlockIndex0, long neighborBlockIndex1, final long divisions0, final long divisions1, final long leftOver, final boolean periodic, final long groupIndexHere) {
        return x10.regionarray.BlockBlockDistGhostManager.getGroupIndex$O((long)(neighborBlockIndex0), (long)(neighborBlockIndex1), (long)(divisions0), (long)(divisions1), (long)(leftOver), (boolean)(periodic), (long)(groupIndexHere));
    }
    
    
    //#line 23 "x10/regionarray/BlockBlockDistGhostManager.x10"
    final public x10.regionarray.BlockBlockDistGhostManager x10$regionarray$BlockBlockDistGhostManager$$this$x10$regionarray$BlockBlockDistGhostManager() {
        
        //#line 23 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return x10.regionarray.BlockBlockDistGhostManager.this;
    }
    
    
    //#line 23 "x10/regionarray/BlockBlockDistGhostManager.x10"
    final public void __fieldInitializers_x10_regionarray_BlockBlockDistGhostManager() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$163 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$163> $RTT = 
            x10.rtt.StaticFunType.<$Closure$163> make($Closure$163.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.lang.Place.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockBlockDistGhostManager.$Closure$163 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.neighbors = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockBlockDistGhostManager.$Closure$163 $_obj = new x10.regionarray.BlockBlockDistGhostManager.$Closure$163((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.neighbors);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$163(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$regionarray$GhostManager$GhostNeighborFlag$2 {}
        
    
        
        public x10.lang.Place $apply(final long i) {
            
            //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.core.Rail t$147158 = ((x10.core.Rail)(this.neighbors));
            
            //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$147159 = ((x10.regionarray.GhostManager.GhostNeighborFlag[])t$147158.value)[(int)i];
            
            //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.lang.Place t$147160 = ((x10.lang.Place)(t$147159.place));
            
            //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
            return t$147160;
        }
        
        public x10.regionarray.BlockBlockDistGhostManager out$$;
        public x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag> neighbors;
        
        public $Closure$163(final x10.regionarray.BlockBlockDistGhostManager out$$, final x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag> neighbors, __1$1x10$regionarray$GhostManager$GhostNeighborFlag$2 $dummy) {
             {
                this.out$$ = out$$;
                this.neighbors = ((x10.core.Rail)(neighbors));
            }
        }
        
    }
    
    }
    
    