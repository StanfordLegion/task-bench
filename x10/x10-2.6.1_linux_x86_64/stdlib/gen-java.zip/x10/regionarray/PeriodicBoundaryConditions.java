package x10.regionarray;

/**
 * Implements periodic boundary conditions, in which elements at each edge
 * of a region are considered to be neighbours, and indices that fall
 * outside the locally-held region in any dimension are wrapped around modulo 
 * the size of the full region in that dimension.
 */
@x10.runtime.impl.java.X10Generated
final public class PeriodicBoundaryConditions extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PeriodicBoundaryConditions> $RTT = 
        x10.rtt.NamedType.<PeriodicBoundaryConditions> make("x10.regionarray.PeriodicBoundaryConditions",
                                                            PeriodicBoundaryConditions.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PeriodicBoundaryConditions $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.PeriodicBoundaryConditions $_obj = new x10.regionarray.PeriodicBoundaryConditions((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public PeriodicBoundaryConditions(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 33 "x10/regionarray/PeriodicBoundaryConditions.x10"
    /**
     * Wrap the given index if it falls outside of [min,max], by adding
     * or subtracting multiples of <code>wrap</code>.
     * @param index the given index into a single dimension of a region
     * @param min the minimum index of the region in the given dimension
     * @param max the maximum index of the region in the given dimension
     * @param wrap the offset to add or subtract from the index when wrapping.
     *   For a region that is entirely held at a single place, wrap==(max-min+1).
     *   For the case of a block distribution over the given dimension,
     *   wrap==(fullRegion.max(dim)-fullRegion.min(dim)+1).
     */
    public static long getPeriodicIndex$O(final long index, final long min, final long max, final long wrap) {
        
        //#line 34 "x10/regionarray/PeriodicBoundaryConditions.x10"
        long actualIndex = index;
        
        //#line 35 "x10/regionarray/PeriodicBoundaryConditions.x10"
        while (true) {
            
            //#line 35 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final boolean t$151656 = ((actualIndex) < (((long)(min))));
            
            //#line 35 "x10/regionarray/PeriodicBoundaryConditions.x10"
            if (!(t$151656)) {
                
                //#line 35 "x10/regionarray/PeriodicBoundaryConditions.x10"
                break;
            }
            
            //#line 35 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151685 = ((actualIndex) + (((long)(wrap))));
            
            //#line 35 "x10/regionarray/PeriodicBoundaryConditions.x10"
            actualIndex = t$151685;
        }
        
        //#line 36 "x10/regionarray/PeriodicBoundaryConditions.x10"
        while (true) {
            
            //#line 36 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final boolean t$151660 = ((actualIndex) > (((long)(max))));
            
            //#line 36 "x10/regionarray/PeriodicBoundaryConditions.x10"
            if (!(t$151660)) {
                
                //#line 36 "x10/regionarray/PeriodicBoundaryConditions.x10"
                break;
            }
            
            //#line 36 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151687 = ((actualIndex) - (((long)(wrap))));
            
            //#line 36 "x10/regionarray/PeriodicBoundaryConditions.x10"
            actualIndex = t$151687;
        }
        
        //#line 37 "x10/regionarray/PeriodicBoundaryConditions.x10"
        return actualIndex;
    }
    
    
    //#line 50 "x10/regionarray/PeriodicBoundaryConditions.x10"
    /**
     * If <code>pt</code> falls outside of <code>localRegion</code>, wrap
     * the indices by adding or subtracting multiples of the size of
     * <code>fullRegion</code> in each dimension.
     * For example,
     * getPeriodic(Point([-2,2]),
     *             Region.makeRectangular(1..4, 0..7),
     *             Region.makeRectangular(1..8, 0..7))
     * returns: Point(6,2).
     */
    public static x10.lang.Point wrapPeriodic(final x10.lang.Point pt, final x10.regionarray.Region localRegion, final x10.regionarray.Region fullRegion) {
        
        //#line 53 "x10/regionarray/PeriodicBoundaryConditions.x10"
        final long t$151670 = pt.rank;
        
        //#line 53 "x10/regionarray/PeriodicBoundaryConditions.x10"
        final x10.core.fun.Fun_0_1 t$151671 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PeriodicBoundaryConditions.$Closure$202(pt, localRegion, fullRegion)));
        
        //#line 53 "x10/regionarray/PeriodicBoundaryConditions.x10"
        final x10.lang.Point t$151672 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$151670), ((x10.core.fun.Fun_0_1)(t$151671)))));
        
        //#line 53 "x10/regionarray/PeriodicBoundaryConditions.x10"
        return t$151672;
    }
    
    
    //#line 66 "x10/regionarray/PeriodicBoundaryConditions.x10"
    /**
     * If <code>pt</code> falls outside of <code>region</code>, wrap
     * the indices by adding or subtracting multiples of the size of
     * <code>region</code> in each dimension.
     * For example,
     * getPeriodic(Point([-2,2]),
     *             Region.makeRectangular(1..4, 0..7))
     * returns: Point(2,2).
     */
    public static x10.lang.Point wrapPeriodic(final x10.lang.Point pt, final x10.regionarray.Region region) {
        
        //#line 67 "x10/regionarray/PeriodicBoundaryConditions.x10"
        final long t$151681 = pt.rank;
        
        //#line 67 "x10/regionarray/PeriodicBoundaryConditions.x10"
        final x10.core.fun.Fun_0_1 t$151682 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PeriodicBoundaryConditions.$Closure$203(pt, region)));
        
        //#line 67 "x10/regionarray/PeriodicBoundaryConditions.x10"
        final x10.lang.Point t$151683 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$151681), ((x10.core.fun.Fun_0_1)(t$151682)))));
        
        //#line 67 "x10/regionarray/PeriodicBoundaryConditions.x10"
        return t$151683;
    }
    
    
    //#line 21 "x10/regionarray/PeriodicBoundaryConditions.x10"
    final public x10.regionarray.PeriodicBoundaryConditions x10$regionarray$PeriodicBoundaryConditions$$this$x10$regionarray$PeriodicBoundaryConditions() {
        
        //#line 21 "x10/regionarray/PeriodicBoundaryConditions.x10"
        return x10.regionarray.PeriodicBoundaryConditions.this;
    }
    
    
    //#line 21 "x10/regionarray/PeriodicBoundaryConditions.x10"
    // creation method for java code (1-phase java constructor)
    public PeriodicBoundaryConditions() {
        this((java.lang.System[]) null);
        x10$regionarray$PeriodicBoundaryConditions$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PeriodicBoundaryConditions x10$regionarray$PeriodicBoundaryConditions$$init$S() {
         {
            
            //#line 21 "x10/regionarray/PeriodicBoundaryConditions.x10"
            
        }
        return this;
    }
    
    
    
    //#line 21 "x10/regionarray/PeriodicBoundaryConditions.x10"
    final public void __fieldInitializers_x10_regionarray_PeriodicBoundaryConditions() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$202 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$202> $RTT = 
            x10.rtt.StaticFunType.<$Closure$202> make($Closure$202.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PeriodicBoundaryConditions.$Closure$202 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.fullRegion = $deserializer.readObject();
            $_obj.localRegion = $deserializer.readObject();
            $_obj.pt = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PeriodicBoundaryConditions.$Closure$202 $_obj = new x10.regionarray.PeriodicBoundaryConditions.$Closure$202((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.fullRegion);
            $serializer.write(this.localRegion);
            $serializer.write(this.pt);
            
        }
        
        // constructor just for allocation
        public $Closure$202(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151665 = this.pt.$apply$O((long)(i));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151666 = this.localRegion.min$O((long)(i));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151667 = this.localRegion.max$O((long)(i));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151662 = this.fullRegion.max$O((long)(i));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151663 = this.fullRegion.min$O((long)(i));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151664 = ((t$151662) - (((long)(t$151663))));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151668 = ((t$151664) + (((long)(1L))));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151669 = x10.regionarray.PeriodicBoundaryConditions.getPeriodicIndex$O((long)(t$151665), (long)(t$151666), (long)(t$151667), (long)(t$151668));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            return t$151669;
        }
        
        public x10.lang.Point pt;
        public x10.regionarray.Region localRegion;
        public x10.regionarray.Region fullRegion;
        
        public $Closure$202(final x10.lang.Point pt, final x10.regionarray.Region localRegion, final x10.regionarray.Region fullRegion) {
             {
                this.pt = ((x10.lang.Point)(pt));
                this.localRegion = ((x10.regionarray.Region)(localRegion));
                this.fullRegion = ((x10.regionarray.Region)(fullRegion));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$203 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$203> $RTT = 
            x10.rtt.StaticFunType.<$Closure$203> make($Closure$203.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PeriodicBoundaryConditions.$Closure$203 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.pt = $deserializer.readObject();
            $_obj.region = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PeriodicBoundaryConditions.$Closure$203 $_obj = new x10.regionarray.PeriodicBoundaryConditions.$Closure$203((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.pt);
            $serializer.write(this.region);
            
        }
        
        // constructor just for allocation
        public $Closure$203(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151676 = this.pt.$apply$O((long)(i));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151677 = this.region.min$O((long)(i));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151678 = this.region.max$O((long)(i));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151673 = this.region.max$O((long)(i));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151674 = this.region.min$O((long)(i));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151675 = ((t$151673) - (((long)(t$151674))));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151679 = ((t$151675) + (((long)(1L))));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$151680 = x10.regionarray.PeriodicBoundaryConditions.getPeriodicIndex$O((long)(t$151676), (long)(t$151677), (long)(t$151678), (long)(t$151679));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            return t$151680;
        }
        
        public x10.lang.Point pt;
        public x10.regionarray.Region region;
        
        public $Closure$203(final x10.lang.Point pt, final x10.regionarray.Region region) {
             {
                this.pt = ((x10.lang.Point)(pt));
                this.region = ((x10.regionarray.Region)(region));
            }
        }
        
    }
    
}

