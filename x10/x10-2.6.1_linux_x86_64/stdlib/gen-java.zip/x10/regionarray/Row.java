package x10.regionarray;


@x10.runtime.impl.java.X10Generated
abstract public class Row extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Row> $RTT = 
        x10.rtt.NamedType.<Row> make("x10.regionarray.Row",
                                     Row.class,
                                     new x10.rtt.Type[] {
                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.rtt.Types.INT)
                                     });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Row $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.cols = $deserializer.readInt();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.cols);
        
    }
    
    // constructor just for allocation
    public Row(final java.lang.System[] $dummy) {
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        return x10.core.Int.$box($apply$O(x10.core.Int.$unbox(a1)));
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $apply$O(x10.core.Int.$unbox(a1));
        
    }
    
    
    // properties
    
    //#line 18 "x10/regionarray/Row.x10"
    public int cols;
    

    
    
    //#line 20 "x10/regionarray/Row.x10"
    abstract public int $apply$O(final int i);
    
    
    //#line 21 "x10/regionarray/Row.x10"
    abstract public int $set$O(final int i, final int v);
    
    
    //#line 23 "x10/regionarray/Row.x10"
    
    // constructor for non-virtual call
    final public x10.regionarray.Row x10$regionarray$Row$$init$S(final int cols) {
         {
            
            //#line 23 "x10/regionarray/Row.x10"
            this.cols = cols;
            
        }
        return this;
    }
    
    
    
    //#line 28 "x10/regionarray/Row.x10"
    /**
     * print a row in both matrix and equation form
     */
    public void printInfo(final x10.io.Printer ps, final int row) {
        
        //#line 29 "x10/regionarray/Row.x10"
        ps.print(((java.lang.String)("[")));
        
        //#line 30 "x10/regionarray/Row.x10"
        int i$158427 = 0;
        
        //#line 30 "x10/regionarray/Row.x10"
        for (;
             true;
             ) {
            
            //#line 30 "x10/regionarray/Row.x10"
            final int t$158429 = this.cols;
            
            //#line 30 "x10/regionarray/Row.x10"
            final boolean t$158430 = ((i$158427) < (((int)(t$158429))));
            
            //#line 30 "x10/regionarray/Row.x10"
            if (!(t$158430)) {
                
                //#line 30 "x10/regionarray/Row.x10"
                break;
            }
            
            //#line 31 "x10/regionarray/Row.x10"
            final int t$158420 = this.$apply$O((int)(i$158427));
            
            //#line 31 "x10/regionarray/Row.x10"
            ps.print(x10.core.Int.$box(t$158420));
            
            //#line 32 "x10/regionarray/Row.x10"
            final int t$158422 = this.cols;
            
            //#line 32 "x10/regionarray/Row.x10"
            final int t$158423 = ((t$158422) - (((int)(2))));
            
            //#line 32 "x10/regionarray/Row.x10"
            final boolean t$158424 = ((int) i$158427) == ((int) t$158423);
            
            //#line 32 "x10/regionarray/Row.x10"
            if (t$158424) {
                
                //#line 32 "x10/regionarray/Row.x10"
                ps.print(((java.lang.String)(" |")));
            }
            
            //#line 30 "x10/regionarray/Row.x10"
            final int t$158426 = ((i$158427) + (((int)(1))));
            
            //#line 30 "x10/regionarray/Row.x10"
            i$158427 = t$158426;
        }
        
        //#line 34 "x10/regionarray/Row.x10"
        ps.print(((java.lang.String)(" ]   ")));
        
        //#line 35 "x10/regionarray/Row.x10"
        this.printEqn(((x10.io.Printer)(ps)), ((java.lang.String)(" ")), (int)(row));
        
        //#line 36 "x10/regionarray/Row.x10"
        ps.println();
    }
    
    
    //#line 42 "x10/regionarray/Row.x10"
    /**
     * print a row in equation form
     */
    public void printEqn(final x10.io.Printer ps, final java.lang.String spc, final int row) {
        
        //#line 43 "x10/regionarray/Row.x10"
        boolean first = true;
        
        //#line 44 "x10/regionarray/Row.x10"
        final java.lang.String t$158377 = (("y") + ((x10.core.Int.$box(row))));
        
        //#line 44 "x10/regionarray/Row.x10"
        final java.lang.String t$158378 = ((t$158377) + (" = "));
        
        //#line 44 "x10/regionarray/Row.x10"
        ps.print(((java.lang.String)(t$158378)));
        
        //#line 45 "x10/regionarray/Row.x10"
        int i$158456 = 0;
        
        //#line 45 "x10/regionarray/Row.x10"
        for (;
             true;
             ) {
            
            //#line 45 "x10/regionarray/Row.x10"
            final int t$158458 = this.cols;
            
            //#line 45 "x10/regionarray/Row.x10"
            final int t$158459 = ((t$158458) - (((int)(1))));
            
            //#line 45 "x10/regionarray/Row.x10"
            final boolean t$158460 = ((i$158456) < (((int)(t$158459))));
            
            //#line 45 "x10/regionarray/Row.x10"
            if (!(t$158460)) {
                
                //#line 45 "x10/regionarray/Row.x10"
                break;
            }
            
            //#line 46 "x10/regionarray/Row.x10"
            final int c$158432 = this.$apply$O((int)(i$158456));
            
            //#line 47 "x10/regionarray/Row.x10"
            final boolean t$158433 = ((int) c$158432) == ((int) 1);
            
            //#line 47 "x10/regionarray/Row.x10"
            if (t$158433) {
                
                //#line 48 "x10/regionarray/Row.x10"
                if (first) {
                    
                    //#line 49 "x10/regionarray/Row.x10"
                    final java.lang.String t$158436 = (("x") + ((x10.core.Int.$box(i$158456))));
                    
                    //#line 49 "x10/regionarray/Row.x10"
                    ps.print(((java.lang.String)(t$158436)));
                } else {
                    
                    //#line 51 "x10/regionarray/Row.x10"
                    final java.lang.String t$158438 = (("+x") + ((x10.core.Int.$box(i$158456))));
                    
                    //#line 51 "x10/regionarray/Row.x10"
                    ps.print(((java.lang.String)(t$158438)));
                }
            } else {
                
                //#line 52 "x10/regionarray/Row.x10"
                final boolean t$158439 = ((int) c$158432) == ((int) -1);
                
                //#line 52 "x10/regionarray/Row.x10"
                if (t$158439) {
                    
                    //#line 53 "x10/regionarray/Row.x10"
                    final java.lang.String t$158441 = (("-x") + ((x10.core.Int.$box(i$158456))));
                    
                    //#line 53 "x10/regionarray/Row.x10"
                    ps.print(((java.lang.String)(t$158441)));
                } else {
                    
                    //#line 54 "x10/regionarray/Row.x10"
                    final boolean t$158442 = ((int) c$158432) != ((int) 0);
                    
                    //#line 54 "x10/regionarray/Row.x10"
                    if (t$158442) {
                        
                        //#line 55 "x10/regionarray/Row.x10"
                        boolean t$158443 = ((c$158432) >= (((int)(0))));
                        
                        //#line 55 "x10/regionarray/Row.x10"
                        if (t$158443) {
                            
                            //#line 55 "x10/regionarray/Row.x10"
                            t$158443 = !(first);
                        }
                        
                        //#line 55 "x10/regionarray/Row.x10"
                        java.lang.String t$158446 =  null;
                        
                        //#line 55 "x10/regionarray/Row.x10"
                        if (t$158443) {
                            
                            //#line 55 "x10/regionarray/Row.x10"
                            t$158446 = "+";
                        } else {
                            
                            //#line 55 "x10/regionarray/Row.x10"
                            t$158446 = "";
                        }
                        
                        //#line 55 "x10/regionarray/Row.x10"
                        final java.lang.String t$158448 = ((t$158446) + ((x10.core.Int.$box(c$158432))));
                        
                        //#line 55 "x10/regionarray/Row.x10"
                        final java.lang.String t$158449 = ((t$158448) + ("*x"));
                        
                        //#line 55 "x10/regionarray/Row.x10"
                        final java.lang.String t$158451 = ((t$158449) + ((x10.core.Int.$box(i$158456))));
                        
                        //#line 55 "x10/regionarray/Row.x10"
                        final java.lang.String t$158452 = ((t$158451) + (" "));
                        
                        //#line 55 "x10/regionarray/Row.x10"
                        ps.print(((java.lang.String)(t$158452)));
                    }
                }
            }
            
            //#line 56 "x10/regionarray/Row.x10"
            final boolean t$158453 = ((int) c$158432) != ((int) 0);
            
            //#line 56 "x10/regionarray/Row.x10"
            if (t$158453) {
                
                //#line 57 "x10/regionarray/Row.x10"
                first = false;
            }
            
            //#line 45 "x10/regionarray/Row.x10"
            final int t$158455 = ((i$158456) + (((int)(1))));
            
            //#line 45 "x10/regionarray/Row.x10"
            i$158456 = t$158455;
        }
        
        //#line 59 "x10/regionarray/Row.x10"
        final int t$158408 = this.cols;
        
        //#line 59 "x10/regionarray/Row.x10"
        final int t$158409 = ((t$158408) - (((int)(1))));
        
        //#line 59 "x10/regionarray/Row.x10"
        final int c = this.$apply$O((int)(t$158409));
        
        //#line 60 "x10/regionarray/Row.x10"
        boolean t$158410 = ((int) c) != ((int) 0);
        
        //#line 60 "x10/regionarray/Row.x10"
        if (!(t$158410)) {
            
            //#line 60 "x10/regionarray/Row.x10"
            t$158410 = first;
        }
        
        //#line 60 "x10/regionarray/Row.x10"
        if (t$158410) {
            
            //#line 60 "x10/regionarray/Row.x10"
            boolean t$158412 = ((c) >= (((int)(0))));
            
            //#line 60 "x10/regionarray/Row.x10"
            if (t$158412) {
                
                //#line 60 "x10/regionarray/Row.x10"
                t$158412 = !(first);
            }
            
            //#line 60 "x10/regionarray/Row.x10"
            java.lang.String t$158414 =  null;
            
            //#line 60 "x10/regionarray/Row.x10"
            if (t$158412) {
                
                //#line 60 "x10/regionarray/Row.x10"
                t$158414 = "+";
            } else {
                
                //#line 60 "x10/regionarray/Row.x10"
                t$158414 = "";
            }
            
            //#line 60 "x10/regionarray/Row.x10"
            final java.lang.String t$158416 = ((t$158414) + ((x10.core.Int.$box(c))));
            
            //#line 60 "x10/regionarray/Row.x10"
            ps.print(((java.lang.String)(t$158416)));
        }
    }
    
    
    //#line 63 "x10/regionarray/Row.x10"
    public java.lang.String toString() {
        
        //#line 64 "x10/regionarray/Row.x10"
        final x10.io.StringWriter os = ((x10.io.StringWriter)(new x10.io.StringWriter((java.lang.System[]) null)));
        
        //#line 64 "x10/regionarray/Row.x10"
        os.x10$io$StringWriter$$init$S();
        
        //#line 65 "x10/regionarray/Row.x10"
        final x10.io.Printer ps = ((x10.io.Printer)(new x10.io.Printer((java.lang.System[]) null)));
        
        //#line 65 "x10/regionarray/Row.x10"
        ps.x10$io$Printer$$init$S(((x10.io.Writer)(os)));
        
        //#line 66 "x10/regionarray/Row.x10"
        this.printEqn(((x10.io.Printer)(ps)), ((java.lang.String)("")), (int)(0));
        
        //#line 67 "x10/regionarray/Row.x10"
        final java.lang.String t$158418 = os.result();
        
        //#line 67 "x10/regionarray/Row.x10"
        return t$158418;
    }
    
    
    //#line 18 "x10/regionarray/Row.x10"
    final public x10.regionarray.Row x10$regionarray$Row$$this$x10$regionarray$Row() {
        
        //#line 18 "x10/regionarray/Row.x10"
        return x10.regionarray.Row.this;
    }
    
    
    //#line 18 "x10/regionarray/Row.x10"
    final public void __fieldInitializers_x10_regionarray_Row() {
        
    }
}

