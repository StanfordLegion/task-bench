package x10.regionarray;

/**
 * A full region is the unbounded region that contains all points of its rank
 */
@x10.runtime.impl.java.X10Generated
final public class FullRegion extends x10.regionarray.Region implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<FullRegion> $RTT = 
        x10.rtt.NamedType.<FullRegion> make("x10.regionarray.FullRegion",
                                            FullRegion.class,
                                            new x10.rtt.Type[] {
                                                x10.regionarray.Region.$RTT
                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Region.$_deserialize_body($_obj, $deserializer);
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.FullRegion $_obj = new x10.regionarray.FullRegion((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        
    }
    
    // constructor just for allocation
    public FullRegion(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    
    //#line 19 "x10/regionarray/FullRegion.x10"
    // creation method for java code (1-phase java constructor)
    public FullRegion(final long rank) {
        this((java.lang.System[]) null);
        x10$regionarray$FullRegion$$init$S(rank);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.FullRegion x10$regionarray$FullRegion$$init$S(final long rank) {
         {
            
            //#line 20 "x10/regionarray/FullRegion.x10"
            final x10.regionarray.Region this$151080 = ((x10.regionarray.Region)(this));
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$151164 = ((long) rank) == ((long) 1L);
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$151164) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$151164 = true;
            }
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$151165 = t$151164;
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$151164) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$151165 = false;
            }
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$151080.rank = rank;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$151080.rect = true;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$151080.zeroBased = false;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$151080.rail = t$151165;
            
            //#line 19 "x10/regionarray/FullRegion.x10"
            
            
            //#line 21 "x10/regionarray/FullRegion.x10"
            final boolean t$151101 = ((rank) < (((long)(0L))));
            
            //#line 21 "x10/regionarray/FullRegion.x10"
            if (t$151101) {
                
                //#line 21 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151098 = (("Rank is negative (") + ((x10.core.Long.$box(rank))));
                
                //#line 21 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151099 = ((t$151098) + (")"));
                
                //#line 21 "x10/regionarray/FullRegion.x10"
                final java.lang.IllegalArgumentException t$151100 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException(t$151099)));
                
                //#line 21 "x10/regionarray/FullRegion.x10"
                throw t$151100;
            }
        }
        return this;
    }
    
    
    
    //#line 24 "x10/regionarray/FullRegion.x10"
    public boolean isConvex$O() {
        
        //#line 24 "x10/regionarray/FullRegion.x10"
        return true;
    }
    
    
    //#line 25 "x10/regionarray/FullRegion.x10"
    public boolean isEmpty$O() {
        
        //#line 25 "x10/regionarray/FullRegion.x10"
        return false;
    }
    
    
    //#line 26 "x10/regionarray/FullRegion.x10"
    public long size$O() {
        
        //#line 27 "x10/regionarray/FullRegion.x10"
        final x10.regionarray.UnboundedRegionException t$151102 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)("size not supported")))));
        
        //#line 27 "x10/regionarray/FullRegion.x10"
        throw t$151102;
    }
    
    
    //#line 29 "x10/regionarray/FullRegion.x10"
    public long indexOf$O(final x10.lang.Point id$220) {
        
        //#line 30 "x10/regionarray/FullRegion.x10"
        final x10.regionarray.UnboundedRegionException t$151103 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)("indexOf not supported")))));
        
        //#line 30 "x10/regionarray/FullRegion.x10"
        throw t$151103;
    }
    
    
    //#line 32 "x10/regionarray/FullRegion.x10"
    public x10.core.fun.Fun_0_1 min() {
        
        //#line 33 "x10/regionarray/FullRegion.x10"
        final x10.core.fun.Fun_0_1 t$151112 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.FullRegion.$Closure$196(this, this.rank)));
        
        //#line 33 "x10/regionarray/FullRegion.x10"
        return t$151112;
    }
    
    
    //#line 38 "x10/regionarray/FullRegion.x10"
    public x10.core.fun.Fun_0_1 max() {
        
        //#line 39 "x10/regionarray/FullRegion.x10"
        final x10.core.fun.Fun_0_1 t$151121 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.FullRegion.$Closure$197(this, this.rank)));
        
        //#line 39 "x10/regionarray/FullRegion.x10"
        return t$151121;
    }
    
    
    //#line 44 "x10/regionarray/FullRegion.x10"
    public x10.regionarray.Region intersection(final x10.regionarray.Region that) {
        
        //#line 44 "x10/regionarray/FullRegion.x10"
        return that;
    }
    
    
    //#line 45 "x10/regionarray/FullRegion.x10"
    public x10.regionarray.Region product(final x10.regionarray.Region that) {
        
        //#line 46 "x10/regionarray/FullRegion.x10"
        final boolean t$151157 = that.isEmpty$O();
        
        //#line 46 "x10/regionarray/FullRegion.x10"
        if (t$151157) {
            
            //#line 47 "x10/regionarray/FullRegion.x10"
            final long t$151122 = this.rank;
            
            //#line 47 "x10/regionarray/FullRegion.x10"
            final long t$151123 = that.rank;
            
            //#line 47 "x10/regionarray/FullRegion.x10"
            final long rank$151085 = ((t$151122) + (((long)(t$151123))));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.EmptyRegion alloc$151086 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            alloc$151086.x10$regionarray$EmptyRegion$$init$S(((long)(rank$151085)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$151124 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$151086)));
            
            //#line 47 "x10/regionarray/FullRegion.x10"
            return t$151124;
        } else {
            
            //#line 48 "x10/regionarray/FullRegion.x10"
            final boolean t$151156 = x10.regionarray.FullRegion.$RTT.isInstance(that);
            
            //#line 48 "x10/regionarray/FullRegion.x10"
            if (t$151156) {
                
                //#line 49 "x10/regionarray/FullRegion.x10"
                final x10.regionarray.FullRegion alloc$145899 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 49 "x10/regionarray/FullRegion.x10"
                final long t$151168 = this.rank;
                
                //#line 49 "x10/regionarray/FullRegion.x10"
                final long t$151169 = that.rank;
                
                //#line 49 "x10/regionarray/FullRegion.x10"
                final long t$151170 = ((t$151168) + (((long)(t$151169))));
                
                //#line 49 "x10/regionarray/FullRegion.x10"
                alloc$145899.x10$regionarray$FullRegion$$init$S(t$151170);
                
                //#line 49 "x10/regionarray/FullRegion.x10"
                return alloc$145899;
            } else {
                
                //#line 50 "x10/regionarray/FullRegion.x10"
                final boolean t$151155 = x10.regionarray.RectRegion.$RTT.isInstance(that);
                
                //#line 50 "x10/regionarray/FullRegion.x10"
                if (t$151155) {
                    
                    //#line 51 "x10/regionarray/FullRegion.x10"
                    final x10.regionarray.RectRegion this$151089 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
                    
                    //#line 223 . "x10/regionarray/RectRegion.x10"
                    x10.core.fun.Fun_0_1 ret$151090 =  null;
                    
                    //#line 223 . "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$151171 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.FullRegion.$Closure$198(this$151089)));
                    
                    //#line 223 . "x10/regionarray/RectRegion.x10"
                    ret$151090 = ((x10.core.fun.Fun_0_1)(t$151171));
                    
                    //#line 51 "x10/regionarray/FullRegion.x10"
                    final x10.core.fun.Fun_0_1 thatMin = ret$151090;
                    
                    //#line 52 "x10/regionarray/FullRegion.x10"
                    final x10.regionarray.RectRegion this$151093 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
                    
                    //#line 224 . "x10/regionarray/RectRegion.x10"
                    x10.core.fun.Fun_0_1 ret$151094 =  null;
                    
                    //#line 224 . "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$151174 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.FullRegion.$Closure$199(this$151093)));
                    
                    //#line 224 . "x10/regionarray/RectRegion.x10"
                    ret$151094 = ((x10.core.fun.Fun_0_1)(t$151174));
                    
                    //#line 52 "x10/regionarray/FullRegion.x10"
                    final x10.core.fun.Fun_0_1 thatMax = ret$151094;
                    
                    //#line 53 "x10/regionarray/FullRegion.x10"
                    final long t$151132 = this.rank;
                    
                    //#line 53 "x10/regionarray/FullRegion.x10"
                    final long t$151133 = that.rank;
                    
                    //#line 53 "x10/regionarray/FullRegion.x10"
                    final long newRank = ((t$151132) + (((long)(t$151133))));
                    
                    //#line 54 "x10/regionarray/FullRegion.x10"
                    final x10.core.fun.Fun_0_1 t$151140 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.FullRegion.$Closure$200(this, this.rank, thatMin, (x10.regionarray.FullRegion.$Closure$200.__2$1x10$lang$Long$3x10$lang$Long$2) null)));
                    
                    //#line 54 "x10/regionarray/FullRegion.x10"
                    final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(newRank)), ((x10.core.fun.Fun_0_1)(t$151140)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                    
                    //#line 55 "x10/regionarray/FullRegion.x10"
                    final x10.core.fun.Fun_0_1 t$151147 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.FullRegion.$Closure$201(this, this.rank, thatMax, (x10.regionarray.FullRegion.$Closure$201.__2$1x10$lang$Long$3x10$lang$Long$2) null)));
                    
                    //#line 55 "x10/regionarray/FullRegion.x10"
                    final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(newRank)), ((x10.core.fun.Fun_0_1)(t$151147)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                    
                    //#line 56 "x10/regionarray/FullRegion.x10"
                    final x10.regionarray.RectRegion alloc$145900 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
                    
                    //#line 56 "x10/regionarray/FullRegion.x10"
                    alloc$145900.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
                    
                    //#line 56 "x10/regionarray/FullRegion.x10"
                    return alloc$145900;
                } else {
                    
                    //#line 57 "x10/regionarray/FullRegion.x10"
                    final boolean t$151154 = x10.regionarray.RectRegion1D.$RTT.isInstance(that);
                    
                    //#line 57 "x10/regionarray/FullRegion.x10"
                    if (t$151154) {
                        
                        //#line 58 "x10/regionarray/FullRegion.x10"
                        final x10.regionarray.RectRegion1D t$151148 = ((x10.regionarray.RectRegion1D)(x10.rtt.Types.<x10.regionarray.RectRegion1D> cast(that,x10.regionarray.RectRegion1D.$RTT)));
                        
                        //#line 58 "x10/regionarray/FullRegion.x10"
                        final x10.regionarray.RectRegion t$151149 = ((x10.regionarray.RectRegion)(t$151148.toRectRegion()));
                        
                        //#line 58 "x10/regionarray/FullRegion.x10"
                        final x10.regionarray.Region t$151150 = ((x10.regionarray.Region)(this.product(((x10.regionarray.Region)(t$151149)))));
                        
                        //#line 58 "x10/regionarray/FullRegion.x10"
                        return t$151150;
                    } else {
                        
                        //#line 60 "x10/regionarray/FullRegion.x10"
                        final java.lang.String t$151151 = x10.rtt.Types.typeName(that);
                        
                        //#line 60 "x10/regionarray/FullRegion.x10"
                        final java.lang.String t$151152 = (("haven\'t implemented FullRegion product with ") + (t$151151));
                        
                        //#line 60 "x10/regionarray/FullRegion.x10"
                        final java.lang.UnsupportedOperationException t$151153 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$151152)));
                        
                        //#line 60 "x10/regionarray/FullRegion.x10"
                        throw t$151153;
                    }
                }
            }
        }
    }
    
    
    //#line 63 "x10/regionarray/FullRegion.x10"
    public x10.regionarray.Region projection(final long axis) {
        
        //#line 63 "x10/regionarray/FullRegion.x10"
        final x10.regionarray.FullRegion alloc$145901 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
        
        //#line 63 "x10/regionarray/FullRegion.x10"
        alloc$145901.x10$regionarray$FullRegion$$init$S(((long)(1L)));
        
        //#line 63 "x10/regionarray/FullRegion.x10"
        return alloc$145901;
    }
    
    
    //#line 64 "x10/regionarray/FullRegion.x10"
    public x10.regionarray.Region translate(final x10.lang.Point p) {
        
        //#line 64 "x10/regionarray/FullRegion.x10"
        return this;
    }
    
    
    //#line 65 "x10/regionarray/FullRegion.x10"
    public x10.regionarray.FullRegion eliminate(final long i) {
        
        //#line 65 "x10/regionarray/FullRegion.x10"
        final x10.regionarray.FullRegion alloc$145902 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
        
        //#line 65 "x10/regionarray/FullRegion.x10"
        final long t$151177 = this.rank;
        
        //#line 65 "x10/regionarray/FullRegion.x10"
        final long t$151178 = ((t$151177) - (((long)(1L))));
        
        //#line 65 "x10/regionarray/FullRegion.x10"
        alloc$145902.x10$regionarray$FullRegion$$init$S(t$151178);
        
        //#line 65 "x10/regionarray/FullRegion.x10"
        return alloc$145902;
    }
    
    
    //#line 66 "x10/regionarray/FullRegion.x10"
    public x10.regionarray.Region computeBoundingBox() {
        
        //#line 66 "x10/regionarray/FullRegion.x10"
        return this;
    }
    
    
    //#line 67 "x10/regionarray/FullRegion.x10"
    public boolean contains$O(final x10.regionarray.Region that) {
        
        //#line 67 "x10/regionarray/FullRegion.x10"
        return true;
    }
    
    
    //#line 68 "x10/regionarray/FullRegion.x10"
    public boolean contains$O(final x10.lang.Point p) {
        
        //#line 68 "x10/regionarray/FullRegion.x10"
        return true;
    }
    
    
    //#line 69 "x10/regionarray/FullRegion.x10"
    public java.lang.String toString() {
        
        //#line 69 "x10/regionarray/FullRegion.x10"
        final long t$151160 = this.rank;
        
        //#line 69 "x10/regionarray/FullRegion.x10"
        final java.lang.String t$151161 = (("full(") + ((x10.core.Long.$box(t$151160))));
        
        //#line 69 "x10/regionarray/FullRegion.x10"
        final java.lang.String t$151162 = ((t$151161) + (")"));
        
        //#line 69 "x10/regionarray/FullRegion.x10"
        return t$151162;
    }
    
    
    //#line 72 "x10/regionarray/FullRegion.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 73 "x10/regionarray/FullRegion.x10"
        final x10.regionarray.UnboundedRegionException t$151163 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)("iterator not supported")))));
        
        //#line 73 "x10/regionarray/FullRegion.x10"
        throw t$151163;
    }
    
    
    //#line 17 "x10/regionarray/FullRegion.x10"
    final public x10.regionarray.FullRegion x10$regionarray$FullRegion$$this$x10$regionarray$FullRegion() {
        
        //#line 17 "x10/regionarray/FullRegion.x10"
        return x10.regionarray.FullRegion.this;
    }
    
    
    //#line 17 "x10/regionarray/FullRegion.x10"
    final public void __fieldInitializers_x10_regionarray_FullRegion() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$196 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$196> $RTT = 
            x10.rtt.StaticFunType.<$Closure$196> make($Closure$196.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion.$Closure$196 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.FullRegion.$Closure$196 $_obj = new x10.regionarray.FullRegion.$Closure$196((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            
        }
        
        // constructor just for allocation
        public $Closure$196(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 34 "x10/regionarray/FullRegion.x10"
            boolean t$151105 = ((i) < (((long)(0L))));
            
            //#line 34 "x10/regionarray/FullRegion.x10"
            if (!(t$151105)) {
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                final long t$151104 = this.rank;
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                t$151105 = ((i) >= (((long)(t$151104))));
            }
            
            //#line 34 "x10/regionarray/FullRegion.x10"
            if (t$151105) {
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151106 = (("min: ") + ((x10.core.Long.$box(i))));
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151107 = ((t$151106) + (" is not a valid rank for "));
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151108 = ((t$151107) + (this.out$$));
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                final java.lang.ArrayIndexOutOfBoundsException t$151109 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$151108)));
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                throw t$151109;
            }
            
            //#line 35 "x10/regionarray/FullRegion.x10"
            final long t$151111 = java.lang.Long.MIN_VALUE;
            
            //#line 35 "x10/regionarray/FullRegion.x10"
            return t$151111;
        }
        
        public x10.regionarray.FullRegion out$$;
        public long rank;
        
        public $Closure$196(final x10.regionarray.FullRegion out$$, final long rank) {
             {
                this.out$$ = out$$;
                this.rank = rank;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$197 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$197> $RTT = 
            x10.rtt.StaticFunType.<$Closure$197> make($Closure$197.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion.$Closure$197 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.FullRegion.$Closure$197 $_obj = new x10.regionarray.FullRegion.$Closure$197((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            
        }
        
        // constructor just for allocation
        public $Closure$197(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 40 "x10/regionarray/FullRegion.x10"
            boolean t$151114 = ((i) < (((long)(0L))));
            
            //#line 40 "x10/regionarray/FullRegion.x10"
            if (!(t$151114)) {
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                final long t$151113 = this.rank;
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                t$151114 = ((i) >= (((long)(t$151113))));
            }
            
            //#line 40 "x10/regionarray/FullRegion.x10"
            if (t$151114) {
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151115 = (("max: ") + ((x10.core.Long.$box(i))));
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151116 = ((t$151115) + (" is not a valid rank for "));
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151117 = ((t$151116) + (this.out$$));
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                final java.lang.ArrayIndexOutOfBoundsException t$151118 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$151117)));
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                throw t$151118;
            }
            
            //#line 41 "x10/regionarray/FullRegion.x10"
            final long t$151120 = java.lang.Long.MAX_VALUE;
            
            //#line 41 "x10/regionarray/FullRegion.x10"
            return t$151120;
        }
        
        public x10.regionarray.FullRegion out$$;
        public long rank;
        
        public $Closure$197(final x10.regionarray.FullRegion out$$, final long rank) {
             {
                this.out$$ = out$$;
                this.rank = rank;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$198 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$198> $RTT = 
            x10.rtt.StaticFunType.<$Closure$198> make($Closure$198.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion.$Closure$198 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$151089 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.FullRegion.$Closure$198 $_obj = new x10.regionarray.FullRegion.$Closure$198((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$151089);
            
        }
        
        // constructor just for allocation
        public $Closure$198(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$151172) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$151173 = this.this$151089.min$O((long)(i$151172));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$151173;
        }
        
        public x10.regionarray.RectRegion this$151089;
        
        public $Closure$198(final x10.regionarray.RectRegion this$151089) {
             {
                this.this$151089 = ((x10.regionarray.RectRegion)(this$151089));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$199 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$199> $RTT = 
            x10.rtt.StaticFunType.<$Closure$199> make($Closure$199.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion.$Closure$199 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$151093 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.FullRegion.$Closure$199 $_obj = new x10.regionarray.FullRegion.$Closure$199((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$151093);
            
        }
        
        // constructor just for allocation
        public $Closure$199(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$151175) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$151176 = this.this$151093.max$O((long)(i$151175));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$151176;
        }
        
        public x10.regionarray.RectRegion this$151093;
        
        public $Closure$199(final x10.regionarray.RectRegion this$151093) {
             {
                this.this$151093 = ((x10.regionarray.RectRegion)(this$151093));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$200 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$200> $RTT = 
            x10.rtt.StaticFunType.<$Closure$200> make($Closure$200.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion.$Closure$200 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.thatMin = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.FullRegion.$Closure$200 $_obj = new x10.regionarray.FullRegion.$Closure$200((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            $serializer.write(this.thatMin);
            
        }
        
        // constructor just for allocation
        public $Closure$200(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __2$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 54 "x10/regionarray/FullRegion.x10"
            final long t$151134 = this.rank;
            
            //#line 54 "x10/regionarray/FullRegion.x10"
            final boolean t$151137 = ((i) < (((long)(t$151134))));
            
            //#line 54 "x10/regionarray/FullRegion.x10"
            long t$151138 =  0;
            
            //#line 54 "x10/regionarray/FullRegion.x10"
            if (t$151137) {
                
                //#line 54 "x10/regionarray/FullRegion.x10"
                t$151138 = java.lang.Long.MIN_VALUE;
            } else {
                
                //#line 54 "x10/regionarray/FullRegion.x10"
                final long t$151135 = this.rank;
                
                //#line 54 "x10/regionarray/FullRegion.x10"
                final long t$151136 = ((i) - (((long)(t$151135))));
                
                //#line 54 "x10/regionarray/FullRegion.x10"
                t$151138 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.thatMin).$apply(x10.core.Long.$box(t$151136), x10.rtt.Types.LONG));
            }
            
            //#line 54 "x10/regionarray/FullRegion.x10"
            return t$151138;
        }
        
        public x10.regionarray.FullRegion out$$;
        public long rank;
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMin;
        
        public $Closure$200(final x10.regionarray.FullRegion out$$, final long rank, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMin, __2$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.out$$ = out$$;
                this.rank = rank;
                this.thatMin = ((x10.core.fun.Fun_0_1)(thatMin));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$201 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$201> $RTT = 
            x10.rtt.StaticFunType.<$Closure$201> make($Closure$201.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion.$Closure$201 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.thatMax = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.FullRegion.$Closure$201 $_obj = new x10.regionarray.FullRegion.$Closure$201((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            $serializer.write(this.thatMax);
            
        }
        
        // constructor just for allocation
        public $Closure$201(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __2$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 55 "x10/regionarray/FullRegion.x10"
            final long t$151141 = this.rank;
            
            //#line 55 "x10/regionarray/FullRegion.x10"
            final boolean t$151144 = ((i) < (((long)(t$151141))));
            
            //#line 55 "x10/regionarray/FullRegion.x10"
            long t$151145 =  0;
            
            //#line 55 "x10/regionarray/FullRegion.x10"
            if (t$151144) {
                
                //#line 55 "x10/regionarray/FullRegion.x10"
                t$151145 = java.lang.Long.MAX_VALUE;
            } else {
                
                //#line 55 "x10/regionarray/FullRegion.x10"
                final long t$151142 = this.rank;
                
                //#line 55 "x10/regionarray/FullRegion.x10"
                final long t$151143 = ((i) - (((long)(t$151142))));
                
                //#line 55 "x10/regionarray/FullRegion.x10"
                t$151145 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.thatMax).$apply(x10.core.Long.$box(t$151143), x10.rtt.Types.LONG));
            }
            
            //#line 55 "x10/regionarray/FullRegion.x10"
            return t$151145;
        }
        
        public x10.regionarray.FullRegion out$$;
        public long rank;
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMax;
        
        public $Closure$201(final x10.regionarray.FullRegion out$$, final long rank, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMax, __2$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.out$$ = out$$;
                this.rank = rank;
                this.thatMax = ((x10.core.fun.Fun_0_1)(thatMax));
            }
        }
        
    }
    
}

