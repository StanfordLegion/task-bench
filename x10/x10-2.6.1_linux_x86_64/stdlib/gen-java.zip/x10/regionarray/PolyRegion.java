package x10.regionarray;


/**
 * A PolyRegion represents a polyhedral region represented as the
 * intersection of a list of PolyRows. The halfspaces are stored in
 * a PolyMat object, which is essentially a constraint matrix
 * that defines the region. The PolyRegion object wraps a
 * HalfpaceList, adding some static factory methods for PolyRegions
 * and some methods such as region algebra that operate on
 * PolyMat objects.
 */
@x10.runtime.impl.java.X10Generated
public class PolyRegion extends x10.regionarray.Region implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PolyRegion> $RTT = 
        x10.rtt.NamedType.<PolyRegion> make("x10.regionarray.PolyRegion",
                                            PolyRegion.class,
                                            new x10.rtt.Type[] {
                                                x10.regionarray.Region.$RTT
                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyRegion $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Region.$_deserialize_body($_obj, $deserializer);
        $_obj.mat = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.PolyRegion $_obj = new x10.regionarray.PolyRegion((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.mat);
        $serializer.write(this.size);
        
    }
    
    // constructor just for allocation
    public PolyRegion(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 28 "x10/regionarray/PolyRegion.x10"
    public x10.regionarray.PolyMat mat;
    
    
    //#line 30 "x10/regionarray/PolyRegion.x10"
    public boolean isConvex$O() {
        
        //#line 31 "x10/regionarray/PolyRegion.x10"
        return true;
    }
    
    
    //#line 34 "x10/regionarray/PolyRegion.x10"
    public long size;
    
    
    //#line 35 "x10/regionarray/PolyRegion.x10"
    public long size$O() {
        
        //#line 36 "x10/regionarray/PolyRegion.x10"
        final long t$154495 = this.size;
        
        //#line 36 "x10/regionarray/PolyRegion.x10"
        final boolean t$154502 = ((t$154495) < (((long)(0L))));
        
        //#line 36 "x10/regionarray/PolyRegion.x10"
        if (t$154502) {
            
            //#line 37 "x10/regionarray/PolyRegion.x10"
            long s = 0L;
            
            //#line 38 "x10/regionarray/PolyRegion.x10"
            this.iterator();
            
            //#line 39 "x10/regionarray/PolyRegion.x10"
            final x10.lang.Iterator p$154766 = this.iterator();
            
            //#line 39 "x10/regionarray/PolyRegion.x10"
            for (;
                 true;
                 ) {
                
                //#line 39 "x10/regionarray/PolyRegion.x10"
                final boolean t$154767 = ((x10.lang.Iterator<x10.lang.Point>)p$154766).hasNext$O();
                
                //#line 39 "x10/regionarray/PolyRegion.x10"
                if (!(t$154767)) {
                    
                    //#line 39 "x10/regionarray/PolyRegion.x10"
                    break;
                }
                
                //#line 39 "x10/regionarray/PolyRegion.x10"
                final x10.lang.Point t$154762 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$154766).next$G()));
                
                //#line 39 "x10/regionarray/PolyRegion.x10"
                x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Point)
                                                       t$154762));
                
                //#line 40 "x10/regionarray/PolyRegion.x10"
                final long t$154765 = ((s) + (((long)(1L))));
                
                //#line 40 "x10/regionarray/PolyRegion.x10"
                s = t$154765;
            }
            
            //#line 41 "x10/regionarray/PolyRegion.x10"
            this.size = s;
        }
        
        //#line 43 "x10/regionarray/PolyRegion.x10"
        final long t$154503 = this.size;
        
        //#line 43 "x10/regionarray/PolyRegion.x10"
        return t$154503;
    }
    
    
    //#line 46 "x10/regionarray/PolyRegion.x10"
    public long indexOf$O(final x10.lang.Point id$228) {
        
        //#line 47 "x10/regionarray/PolyRegion.x10"
        final java.lang.UnsupportedOperationException t$154504 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 47 "x10/regionarray/PolyRegion.x10"
        throw t$154504;
    }
    
    
    //#line 51 "x10/regionarray/PolyRegion.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 52 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$154505 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 52 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyScanner this$154476 = ((x10.regionarray.PolyScanner)(x10.regionarray.PolyScanner.make(((x10.regionarray.PolyMat)(t$154505)))));
        
        //#line 289 . "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.PolyScanner.Anonymous$10018 alloc$154475 = ((x10.regionarray.PolyScanner.Anonymous$10018)(new x10.regionarray.PolyScanner.Anonymous$10018((java.lang.System[]) null)));
        
        //#line 289 . "x10/regionarray/PolyScanner.x10"
        alloc$154475.x10$regionarray$PolyScanner$Anonymous$10018$$init$S(((x10.regionarray.PolyScanner)(this$154476)));
        
        //#line 289 . "x10/regionarray/PolyScanner.x10"
        final x10.lang.Iterator t$154506 = ((x10.lang.Iterator<x10.lang.Point>)
                                             alloc$154475);
        
        //#line 52 "x10/regionarray/PolyRegion.x10"
        return t$154506;
    }
    
    
    //#line 59 "x10/regionarray/PolyRegion.x10"
    public x10.regionarray.Region intersection(final x10.regionarray.Region t) {
        
        //#line 61 "x10/regionarray/PolyRegion.x10"
        final boolean t$154532 = x10.regionarray.PolyRegion.$RTT.isInstance(t);
        
        //#line 61 "x10/regionarray/PolyRegion.x10"
        if (t$154532) {
            
            //#line 64 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRegion that = ((x10.regionarray.PolyRegion)(x10.rtt.Types.<x10.regionarray.PolyRegion> cast(t,x10.regionarray.PolyRegion.$RTT)));
            
            //#line 65 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
            
            //#line 65 "x10/regionarray/PolyRegion.x10"
            final long t$154770 = this.rank;
            
            //#line 65 "x10/regionarray/PolyRegion.x10"
            pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$154770)));
            
            //#line 68 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyMat t$154771 = ((x10.regionarray.PolyMat)(this.mat));
            
            //#line 68 "x10/regionarray/PolyRegion.x10"
            final x10.lang.Iterator r$154772 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)t$154771).iterator();
            
            //#line 68 "x10/regionarray/PolyRegion.x10"
            for (;
                 true;
                 ) {
                
                //#line 68 "x10/regionarray/PolyRegion.x10"
                final boolean t$154773 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$154772).hasNext$O();
                
                //#line 68 "x10/regionarray/PolyRegion.x10"
                if (!(t$154773)) {
                    
                    //#line 68 "x10/regionarray/PolyRegion.x10"
                    break;
                }
                
                //#line 68 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.PolyRow r$154768 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$154772).next$G();
                
                //#line 69 "x10/regionarray/PolyRegion.x10"
                pmb.add(((x10.regionarray.Row)(r$154768)));
            }
            
            //#line 72 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyMat t$154774 = ((x10.regionarray.PolyMat)(that.mat));
            
            //#line 72 "x10/regionarray/PolyRegion.x10"
            final x10.lang.Iterator r$154775 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)t$154774).iterator();
            
            //#line 72 "x10/regionarray/PolyRegion.x10"
            for (;
                 true;
                 ) {
                
                //#line 72 "x10/regionarray/PolyRegion.x10"
                final boolean t$154776 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$154775).hasNext$O();
                
                //#line 72 "x10/regionarray/PolyRegion.x10"
                if (!(t$154776)) {
                    
                    //#line 72 "x10/regionarray/PolyRegion.x10"
                    break;
                }
                
                //#line 72 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.PolyRow r$154769 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$154775).next$G();
                
                //#line 73 "x10/regionarray/PolyRegion.x10"
                pmb.add(((x10.regionarray.Row)(r$154769)));
            }
            
            //#line 76 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
            
            //#line 77 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.Region t$154514 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
            
            //#line 77 "x10/regionarray/PolyRegion.x10"
            return t$154514;
        } else {
            
            //#line 79 "x10/regionarray/PolyRegion.x10"
            final boolean t$154531 = x10.regionarray.RectRegion.$RTT.isInstance(t);
            
            //#line 79 "x10/regionarray/PolyRegion.x10"
            if (t$154531) {
                
                //#line 80 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.RectRegion t$154515 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(t,x10.regionarray.RectRegion.$RTT)));
                
                //#line 80 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.Region t$154516 = ((x10.regionarray.Region)(t$154515.toPolyRegion()));
                
                //#line 80 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.Region t$154517 = ((x10.regionarray.Region)(this.intersection(((x10.regionarray.Region)(t$154516)))));
                
                //#line 80 "x10/regionarray/PolyRegion.x10"
                return t$154517;
            } else {
                
                //#line 81 "x10/regionarray/PolyRegion.x10"
                final boolean t$154530 = x10.regionarray.RectRegion1D.$RTT.isInstance(t);
                
                //#line 81 "x10/regionarray/PolyRegion.x10"
                if (t$154530) {
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final x10.regionarray.RectRegion1D t$154518 = ((x10.regionarray.RectRegion1D)(x10.rtt.Types.<x10.regionarray.RectRegion1D> cast(t,x10.regionarray.RectRegion1D.$RTT)));
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final x10.regionarray.RectRegion t$154519 = ((x10.regionarray.RectRegion)(t$154518.toRectRegion()));
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final x10.regionarray.Region t$154520 = ((x10.regionarray.Region)(t$154519.toPolyRegion()));
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final x10.regionarray.Region t$153352 = ((x10.regionarray.Region)
                                                              t$154520);
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final long t$154521 = t$153352.rank;
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final long t$154522 = x10.regionarray.PolyRegion.this.rank;
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final boolean t$154523 = ((long) t$154521) == ((long) t$154522);
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final boolean t$154525 = !(t$154523);
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    if (t$154525) {
                        
                        //#line 82 "x10/regionarray/PolyRegion.x10"
                        final x10.lang.FailedDynamicCheckException t$154524 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.PolyRegion).rank}");
                        
                        //#line 82 "x10/regionarray/PolyRegion.x10"
                        throw t$154524;
                    }
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final x10.regionarray.Region t$154526 = ((x10.regionarray.Region)(this.intersection(((x10.regionarray.Region)(t$153352)))));
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    return t$154526;
                } else {
                    
                    //#line 89 "x10/regionarray/PolyRegion.x10"
                    final java.lang.String t$154527 = (("intersection(") + (t));
                    
                    //#line 89 "x10/regionarray/PolyRegion.x10"
                    final java.lang.String t$154528 = ((t$154527) + (")"));
                    
                    //#line 89 "x10/regionarray/PolyRegion.x10"
                    final java.lang.UnsupportedOperationException t$154529 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$154528)));
                    
                    //#line 89 "x10/regionarray/PolyRegion.x10"
                    throw t$154529;
                }
            }
        }
    }
    
    
    //#line 94 "x10/regionarray/PolyRegion.x10"
    public boolean contains$O(final x10.regionarray.Region that) {
        
        //#line 95 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154533 = ((x10.regionarray.Region)(this.computeBoundingBox()));
        
        //#line 95 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154534 = ((x10.regionarray.Region)(that.computeBoundingBox()));
        
        //#line 95 "x10/regionarray/PolyRegion.x10"
        final boolean t$154535 = t$154533.contains$O(((x10.regionarray.Region)(t$154534)));
        
        //#line 95 "x10/regionarray/PolyRegion.x10"
        return t$154535;
    }
    
    
    //#line 102 "x10/regionarray/PolyRegion.x10"
    /**
     * Projection is computed by using FME to eliminate variables on
     * all but the axis of interest.
     */
    public x10.regionarray.Region projection(final long axis) {
        
        //#line 103 "x10/regionarray/PolyRegion.x10"
        x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 104 "x10/regionarray/PolyRegion.x10"
        int k$154785 = 0;
        
        //#line 104 "x10/regionarray/PolyRegion.x10"
        for (;
             true;
             ) {
            
            //#line 104 "x10/regionarray/PolyRegion.x10"
            final long t$154787 = ((long)(((int)(k$154785))));
            
            //#line 104 "x10/regionarray/PolyRegion.x10"
            final long t$154788 = this.rank;
            
            //#line 104 "x10/regionarray/PolyRegion.x10"
            final boolean t$154789 = ((t$154787) < (((long)(t$154788))));
            
            //#line 104 "x10/regionarray/PolyRegion.x10"
            if (!(t$154789)) {
                
                //#line 104 "x10/regionarray/PolyRegion.x10"
                break;
            }
            
            //#line 105 "x10/regionarray/PolyRegion.x10"
            final int t$154778 = ((int)(long)(((long)(axis))));
            
            //#line 105 "x10/regionarray/PolyRegion.x10"
            final boolean t$154779 = ((int) k$154785) != ((int) t$154778);
            
            //#line 105 "x10/regionarray/PolyRegion.x10"
            if (t$154779) {
                
                //#line 106 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.PolyMat t$154782 = ((x10.regionarray.PolyMat)(pm.eliminate((int)(k$154785), (boolean)(true))));
                
                //#line 106 "x10/regionarray/PolyRegion.x10"
                pm = ((x10.regionarray.PolyMat)(t$154782));
            }
            
            //#line 104 "x10/regionarray/PolyRegion.x10"
            final int t$154784 = ((k$154785) + (((int)(1))));
            
            //#line 104 "x10/regionarray/PolyRegion.x10"
            k$154785 = t$154784;
        }
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        final int t$154550 = ((int)(long)(((long)(axis))));
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        final int t$154551 = pm.rectMin$O((int)(t$154550));
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        final long min$154478 = ((long)(((int)(t$154551))));
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        final int t$154553 = ((int)(long)(((long)(axis))));
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        final int t$154554 = pm.rectMax$O((int)(t$154553));
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        final long max$154479 = ((long)(((int)(t$154554))));
        
        //#line 274 . "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$154480 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 274 . "x10/regionarray/Region.x10"
        alloc$154480.x10$regionarray$RectRegion1D$$init$S(((long)(min$154478)), ((long)(max$154479)));
        
        //#line 274 . "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$154555 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                            alloc$154480)));
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        return t$154555;
    }
    
    
    //#line 116 "x10/regionarray/PolyRegion.x10"
    /**
     * Eliminate the ith axis.
     */
    public x10.regionarray.Region eliminate(final long axis) {
        
        //#line 117 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$154556 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 117 "x10/regionarray/PolyRegion.x10"
        final int t$154557 = ((int)(long)(((long)(axis))));
        
        //#line 117 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(t$154556.eliminate((int)(t$154557), (boolean)(true))));
        
        //#line 118 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region result = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 119 "x10/regionarray/PolyRegion.x10"
        return result;
    }
    
    
    //#line 127 "x10/regionarray/PolyRegion.x10"
    /**
     * Cartesian product requires copying the halfspace matrices into
     * the result blockwise
     */
    public x10.regionarray.Region product(final x10.regionarray.Region r) {
        
        //#line 128 "x10/regionarray/PolyRegion.x10"
        final boolean t$154558 = x10.regionarray.PolyRegion.$RTT.isInstance(r);
        
        //#line 128 "x10/regionarray/PolyRegion.x10"
        final boolean t$154562 = !(t$154558);
        
        //#line 128 "x10/regionarray/PolyRegion.x10"
        if (t$154562) {
            
            //#line 129 "x10/regionarray/PolyRegion.x10"
            final java.lang.String t$154559 = (("product(") + (r));
            
            //#line 129 "x10/regionarray/PolyRegion.x10"
            final java.lang.String t$154560 = ((t$154559) + (")"));
            
            //#line 129 "x10/regionarray/PolyRegion.x10"
            final java.lang.UnsupportedOperationException t$154561 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$154560)));
            
            //#line 129 "x10/regionarray/PolyRegion.x10"
            throw t$154561;
        }
        
        //#line 130 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyRegion that = ((x10.regionarray.PolyRegion)(x10.rtt.Types.<x10.regionarray.PolyRegion> cast(r,x10.regionarray.PolyRegion.$RTT)));
        
        //#line 131 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 131 "x10/regionarray/PolyRegion.x10"
        final long t$154790 = this.rank;
        
        //#line 131 "x10/regionarray/PolyRegion.x10"
        final long t$154791 = that.rank;
        
        //#line 131 "x10/regionarray/PolyRegion.x10"
        final long t$154792 = ((t$154790) + (((long)(t$154791))));
        
        //#line 131 "x10/regionarray/PolyRegion.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(t$154792);
        
        //#line 132 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$154566 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 132 "x10/regionarray/PolyRegion.x10"
        x10.regionarray.PolyRegion.copy(((x10.regionarray.PolyMatBuilder)(pmb)), ((x10.regionarray.PolyMat)(t$154566)), (int)(0));
        
        //#line 133 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$154568 = ((x10.regionarray.PolyMat)(that.mat));
        
        //#line 133 "x10/regionarray/PolyRegion.x10"
        final long t$154567 = this.rank;
        
        //#line 133 "x10/regionarray/PolyRegion.x10"
        final int t$154569 = ((int)(long)(((long)(t$154567))));
        
        //#line 133 "x10/regionarray/PolyRegion.x10"
        x10.regionarray.PolyRegion.copy(((x10.regionarray.PolyMatBuilder)(pmb)), ((x10.regionarray.PolyMat)(t$154568)), (int)(t$154569));
        
        //#line 134 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 135 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154570 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 135 "x10/regionarray/PolyRegion.x10"
        return t$154570;
    }
    
    
    //#line 138 "x10/regionarray/PolyRegion.x10"
    private static void copy(final x10.regionarray.PolyMatBuilder tt, final x10.regionarray.PolyMat ff, final int offset) {
        
        //#line 139 "x10/regionarray/PolyRegion.x10"
        final x10.lang.Iterator r$153722 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)ff).iterator();
        
        //#line 139 "x10/regionarray/PolyRegion.x10"
        for (;
             true;
             ) {
            
            //#line 139 "x10/regionarray/PolyRegion.x10"
            final boolean t$154592 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153722).hasNext$O();
            
            //#line 139 "x10/regionarray/PolyRegion.x10"
            if (!(t$154592)) {
                
                //#line 139 "x10/regionarray/PolyRegion.x10"
                break;
            }
            
            //#line 139 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRow r$154807 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153722).next$G();
            
            //#line 141 "x10/regionarray/PolyRegion.x10"
            final long t$154809 = tt.rank;
            
            //#line 141 "x10/regionarray/PolyRegion.x10"
            final long t$154810 = ((t$154809) + (((long)(1L))));
            
            //#line 141 "x10/regionarray/PolyRegion.x10"
            final x10.core.Rail t$154811 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, t$154810)));
            
            //#line 142 "x10/regionarray/PolyRegion.x10"
            int i$154800 = 0;
            {
                
                //#line 142 "x10/regionarray/PolyRegion.x10"
                final int[] t$154811$value$154905 = ((int[])t$154811.value);
                
                //#line 142 "x10/regionarray/PolyRegion.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 142 "x10/regionarray/PolyRegion.x10"
                    final long t$154802 = ((long)(((int)(i$154800))));
                    
                    //#line 142 "x10/regionarray/PolyRegion.x10"
                    final long t$154803 = ff.rank;
                    
                    //#line 142 "x10/regionarray/PolyRegion.x10"
                    final boolean t$154804 = ((t$154802) < (((long)(t$154803))));
                    
                    //#line 142 "x10/regionarray/PolyRegion.x10"
                    if (!(t$154804)) {
                        
                        //#line 142 "x10/regionarray/PolyRegion.x10"
                        break;
                    }
                    
                    //#line 143 "x10/regionarray/PolyRegion.x10"
                    final int t$154794 = ((offset) + (((int)(i$154800))));
                    
                    //#line 143 "x10/regionarray/PolyRegion.x10"
                    final long t$154795 = ((long)(((int)(t$154794))));
                    
                    //#line 143 "x10/regionarray/PolyRegion.x10"
                    final int t$154797 = r$154807.$apply$O((int)(i$154800));
                    
                    //#line 143 "x10/regionarray/PolyRegion.x10"
                    t$154811$value$154905[(int)t$154795]=t$154797;
                    
                    //#line 142 "x10/regionarray/PolyRegion.x10"
                    final int t$154799 = ((i$154800) + (((int)(1))));
                    
                    //#line 142 "x10/regionarray/PolyRegion.x10"
                    i$154800 = t$154799;
                }
            }
            
            //#line 144 "x10/regionarray/PolyRegion.x10"
            final long t$154812 = tt.rank;
            
            //#line 144 "x10/regionarray/PolyRegion.x10"
            final long t$154813 = ff.rank;
            
            //#line 144 "x10/regionarray/PolyRegion.x10"
            final int t$154814 = ((int)(long)(((long)(t$154813))));
            
            //#line 144 "x10/regionarray/PolyRegion.x10"
            final int t$154815 = r$154807.$apply$O((int)(t$154814));
            
            //#line 144 "x10/regionarray/PolyRegion.x10"
            ((int[])t$154811.value)[(int)t$154812] = t$154815;
            
            //#line 145 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRow alloc$154816 = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
            
            //#line 29 . "x10/regionarray/PolyRow.x10"
            final long t$154805 = ((x10.core.Rail<x10.core.Int>)t$154811).size;
            
            //#line 29 . "x10/regionarray/PolyRow.x10"
            final long t$154806 = ((t$154805) - (((long)(1L))));
            
            //#line 29 . "x10/regionarray/PolyRow.x10"
            alloc$154816.x10$regionarray$PolyRow$$init$S(((x10.core.Rail)(t$154811)), t$154806, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
            
            //#line 145 "x10/regionarray/PolyRegion.x10"
            tt.add(((x10.regionarray.Row)(alloc$154816)));
        }
    }
    
    public static void copy$P(final x10.regionarray.PolyMatBuilder tt, final x10.regionarray.PolyMat ff, final int offset) {
        x10.regionarray.PolyRegion.copy(((x10.regionarray.PolyMatBuilder)(tt)), ((x10.regionarray.PolyMat)(ff)), (int)(offset));
    }
    
    
    //#line 150 "x10/regionarray/PolyRegion.x10"
    public x10.regionarray.Region translate(final x10.lang.Point v) {
        
        //#line 151 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 151 "x10/regionarray/PolyRegion.x10"
        final long t$154818 = this.rank;
        
        //#line 151 "x10/regionarray/PolyRegion.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$154818)));
        
        //#line 152 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$154594 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 152 "x10/regionarray/PolyRegion.x10"
        x10.regionarray.PolyRegion.translate(((x10.regionarray.PolyMatBuilder)(pmb)), ((x10.regionarray.PolyMat)(t$154594)), ((x10.lang.Point)(v)));
        
        //#line 153 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 154 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154595 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 154 "x10/regionarray/PolyRegion.x10"
        return t$154595;
    }
    
    
    //#line 157 "x10/regionarray/PolyRegion.x10"
    private static void translate(final x10.regionarray.PolyMatBuilder tt, final x10.regionarray.PolyMat ff, final x10.lang.Point v) {
        
        //#line 158 "x10/regionarray/PolyRegion.x10"
        final x10.lang.Iterator r$153724 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)ff).iterator();
        
        //#line 158 "x10/regionarray/PolyRegion.x10"
        for (;
             true;
             ) {
            
            //#line 158 "x10/regionarray/PolyRegion.x10"
            final boolean t$154628 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153724).hasNext$O();
            
            //#line 158 "x10/regionarray/PolyRegion.x10"
            if (!(t$154628)) {
                
                //#line 158 "x10/regionarray/PolyRegion.x10"
                break;
            }
            
            //#line 158 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRow r$154842 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153724).next$G();
            
            //#line 160 "x10/regionarray/PolyRegion.x10"
            final long t$154844 = ff.rank;
            
            //#line 160 "x10/regionarray/PolyRegion.x10"
            final long t$154845 = ((t$154844) + (((long)(1L))));
            
            //#line 160 "x10/regionarray/PolyRegion.x10"
            final x10.core.Rail t$154846 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, t$154845)));
            
            //#line 161 "x10/regionarray/PolyRegion.x10"
            int s$154847 = 0;
            
            //#line 162 "x10/regionarray/PolyRegion.x10"
            int i$154835 = 0;
            {
                
                //#line 162 "x10/regionarray/PolyRegion.x10"
                final int[] t$154846$value$154906 = ((int[])t$154846.value);
                
                //#line 162 "x10/regionarray/PolyRegion.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 162 "x10/regionarray/PolyRegion.x10"
                    final long t$154837 = ((long)(((int)(i$154835))));
                    
                    //#line 162 "x10/regionarray/PolyRegion.x10"
                    final long t$154838 = ff.rank;
                    
                    //#line 162 "x10/regionarray/PolyRegion.x10"
                    final boolean t$154839 = ((t$154837) < (((long)(t$154838))));
                    
                    //#line 162 "x10/regionarray/PolyRegion.x10"
                    if (!(t$154839)) {
                        
                        //#line 162 "x10/regionarray/PolyRegion.x10"
                        break;
                    }
                    
                    //#line 163 "x10/regionarray/PolyRegion.x10"
                    final long t$154820 = ((long)(((int)(i$154835))));
                    
                    //#line 163 "x10/regionarray/PolyRegion.x10"
                    final int t$154822 = r$154842.$apply$O((int)(i$154835));
                    
                    //#line 163 "x10/regionarray/PolyRegion.x10"
                    t$154846$value$154906[(int)t$154820]=t$154822;
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final long t$154824 = ((long)(((int)(s$154847))));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final int t$154826 = r$154842.$apply$O((int)(i$154835));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final long t$154827 = ((long)(((int)(t$154826))));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final long t$154829 = ((long)(((int)(i$154835))));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final long t$154830 = v.$apply$O((long)(t$154829));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final long t$154831 = ((t$154827) * (((long)(t$154830))));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final long t$154832 = ((t$154824) + (((long)(t$154831))));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    s$154847 = ((int)(((long)(t$154832))));
                    
                    //#line 162 "x10/regionarray/PolyRegion.x10"
                    final int t$154834 = ((i$154835) + (((int)(1))));
                    
                    //#line 162 "x10/regionarray/PolyRegion.x10"
                    i$154835 = t$154834;
                }
            }
            
            //#line 166 "x10/regionarray/PolyRegion.x10"
            final long t$154848 = ff.rank;
            
            //#line 166 "x10/regionarray/PolyRegion.x10"
            final long t$154849 = ff.rank;
            
            //#line 166 "x10/regionarray/PolyRegion.x10"
            final int t$154850 = ((int)(long)(((long)(t$154849))));
            
            //#line 166 "x10/regionarray/PolyRegion.x10"
            final int t$154851 = r$154842.$apply$O((int)(t$154850));
            
            //#line 166 "x10/regionarray/PolyRegion.x10"
            final int t$154853 = ((t$154851) - (((int)(s$154847))));
            
            //#line 166 "x10/regionarray/PolyRegion.x10"
            ((int[])t$154846.value)[(int)t$154848] = t$154853;
            
            //#line 167 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRow alloc$154854 = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
            
            //#line 29 . "x10/regionarray/PolyRow.x10"
            final long t$154840 = ((x10.core.Rail<x10.core.Int>)t$154846).size;
            
            //#line 29 . "x10/regionarray/PolyRow.x10"
            final long t$154841 = ((t$154840) - (((long)(1L))));
            
            //#line 29 . "x10/regionarray/PolyRow.x10"
            alloc$154854.x10$regionarray$PolyRow$$init$S(((x10.core.Rail)(t$154846)), t$154841, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
            
            //#line 167 "x10/regionarray/PolyRegion.x10"
            tt.add(((x10.regionarray.Row)(alloc$154854)));
        }
    }
    
    public static void translate$P(final x10.regionarray.PolyMatBuilder tt, final x10.regionarray.PolyMat ff, final x10.lang.Point v) {
        x10.regionarray.PolyRegion.translate(((x10.regionarray.PolyMatBuilder)(tt)), ((x10.regionarray.PolyMat)(ff)), ((x10.lang.Point)(v)));
    }
    
    
    //#line 196 "x10/regionarray/PolyRegion.x10"
    /**
     * -H0 || -H1 && H0 || -H2 && H1 && H0 || ...
     */
    public boolean isEmpty$O() {
        
        //#line 197 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$154629 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 197 "x10/regionarray/PolyRegion.x10"
        final boolean tmp = t$154629.isEmpty$O();
        
        //#line 198 "x10/regionarray/PolyRegion.x10"
        return tmp;
    }
    
    
    //#line 201 "x10/regionarray/PolyRegion.x10"
    public x10.regionarray.Region computeBoundingBox() {
        
        //#line 202 "x10/regionarray/PolyRegion.x10"
        final long t$154630 = this.rank;
        
        //#line 202 "x10/regionarray/PolyRegion.x10"
        final x10.core.Rail min = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$154630)))));
        
        //#line 203 "x10/regionarray/PolyRegion.x10"
        final long t$154631 = this.rank;
        
        //#line 203 "x10/regionarray/PolyRegion.x10"
        final x10.core.Rail max = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$154631)))));
        
        //#line 204 "x10/regionarray/PolyRegion.x10"
        x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 205 "x10/regionarray/PolyRegion.x10"
        int axis$154885 = 0;
        {
            
            //#line 205 "x10/regionarray/PolyRegion.x10"
            final long[] min$value$154907 = ((long[])min.value);
            
            //#line 205 "x10/regionarray/PolyRegion.x10"
            final long[] max$value$154908 = ((long[])max.value);
            
            //#line 205 "x10/regionarray/PolyRegion.x10"
            for (;
                 true;
                 ) {
                
                //#line 205 "x10/regionarray/PolyRegion.x10"
                final long t$154887 = ((long)(((int)(axis$154885))));
                
                //#line 205 "x10/regionarray/PolyRegion.x10"
                final long t$154888 = this.rank;
                
                //#line 205 "x10/regionarray/PolyRegion.x10"
                final boolean t$154889 = ((t$154887) < (((long)(t$154888))));
                
                //#line 205 "x10/regionarray/PolyRegion.x10"
                if (!(t$154889)) {
                    
                    //#line 205 "x10/regionarray/PolyRegion.x10"
                    break;
                }
                
                //#line 206 "x10/regionarray/PolyRegion.x10"
                x10.regionarray.PolyMat x$154867 = pm;
                
                //#line 207 "x10/regionarray/PolyRegion.x10"
                int k$154862 = ((axis$154885) + (((int)(1))));
                
                //#line 207 "x10/regionarray/PolyRegion.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 207 "x10/regionarray/PolyRegion.x10"
                    final long t$154864 = ((long)(((int)(k$154862))));
                    
                    //#line 207 "x10/regionarray/PolyRegion.x10"
                    final long t$154865 = this.rank;
                    
                    //#line 207 "x10/regionarray/PolyRegion.x10"
                    final boolean t$154866 = ((t$154864) < (((long)(t$154865))));
                    
                    //#line 207 "x10/regionarray/PolyRegion.x10"
                    if (!(t$154866)) {
                        
                        //#line 207 "x10/regionarray/PolyRegion.x10"
                        break;
                    }
                    
                    //#line 208 "x10/regionarray/PolyRegion.x10"
                    final x10.regionarray.PolyMat t$154858 = ((x10.regionarray.PolyMat)(x$154867.eliminate((int)(k$154862), (boolean)(true))));
                    
                    //#line 208 "x10/regionarray/PolyRegion.x10"
                    x$154867 = ((x10.regionarray.PolyMat)(t$154858));
                    
                    //#line 207 "x10/regionarray/PolyRegion.x10"
                    final int t$154860 = ((k$154862) + (((int)(1))));
                    
                    //#line 207 "x10/regionarray/PolyRegion.x10"
                    k$154862 = t$154860;
                }
                
                //#line 209 "x10/regionarray/PolyRegion.x10"
                final long t$154869 = ((long)(((int)(axis$154885))));
                
                //#line 209 "x10/regionarray/PolyRegion.x10"
                final int t$154872 = x$154867.rectMin$O((int)(axis$154885));
                
                //#line 209 "x10/regionarray/PolyRegion.x10"
                final long t$154873 = ((long)(((int)(t$154872))));
                
                //#line 209 "x10/regionarray/PolyRegion.x10"
                min$value$154907[(int)t$154869]=t$154873;
                
                //#line 210 "x10/regionarray/PolyRegion.x10"
                final long t$154875 = ((long)(((int)(axis$154885))));
                
                //#line 210 "x10/regionarray/PolyRegion.x10"
                final int t$154878 = x$154867.rectMax$O((int)(axis$154885));
                
                //#line 210 "x10/regionarray/PolyRegion.x10"
                final long t$154879 = ((long)(((int)(t$154878))));
                
                //#line 210 "x10/regionarray/PolyRegion.x10"
                max$value$154908[(int)t$154875]=t$154879;
                
                //#line 211 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.PolyMat t$154882 = ((x10.regionarray.PolyMat)(pm.eliminate((int)(axis$154885), (boolean)(true))));
                
                //#line 211 "x10/regionarray/PolyRegion.x10"
                pm = ((x10.regionarray.PolyMat)(t$154882));
                
                //#line 205 "x10/regionarray/PolyRegion.x10"
                final int t$154884 = ((axis$154885) + (((int)(1))));
                
                //#line 205 "x10/regionarray/PolyRegion.x10"
                axis$154885 = t$154884;
            }
        }
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154665 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$Long$2__1$1x10$lang$Long$2(((x10.core.Rail)(min)), ((x10.core.Rail)(max)))));
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$153577 = ((x10.regionarray.Region)
                                                  t$154665);
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        final boolean t$154666 = t$153577.rect;
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        boolean t$154669 = ((boolean) t$154666) == ((boolean) true);
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        if (t$154669) {
            
            //#line 213 "x10/regionarray/PolyRegion.x10"
            final long t$154667 = t$153577.rank;
            
            //#line 213 "x10/regionarray/PolyRegion.x10"
            final long t$154668 = x10.regionarray.PolyRegion.this.rank;
            
            //#line 213 "x10/regionarray/PolyRegion.x10"
            t$154669 = ((long) t$154667) == ((long) t$154668);
        }
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        final boolean t$154672 = !(t$154669);
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        if (t$154672) {
            
            //#line 213 "x10/regionarray/PolyRegion.x10"
            final x10.lang.FailedDynamicCheckException t$154671 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==this(:x10.regionarray.PolyRegion).rank}");
            
            //#line 213 "x10/regionarray/PolyRegion.x10"
            throw t$154671;
        }
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        return t$153577;
    }
    
    
    //#line 221 "x10/regionarray/PolyRegion.x10"
    /**
     * point
     */
    public boolean contains$O(final x10.lang.Point p) {
        
        //#line 223 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$154893 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 223 "x10/regionarray/PolyRegion.x10"
        final x10.lang.Iterator r$154894 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)t$154893).iterator();
        
        //#line 223 "x10/regionarray/PolyRegion.x10"
        for (;
             true;
             ) {
            
            //#line 223 "x10/regionarray/PolyRegion.x10"
            final boolean t$154895 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$154894).hasNext$O();
            
            //#line 223 "x10/regionarray/PolyRegion.x10"
            if (!(t$154895)) {
                
                //#line 223 "x10/regionarray/PolyRegion.x10"
                break;
            }
            
            //#line 223 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRow r$154890 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$154894).next$G();
            
            //#line 224 "x10/regionarray/PolyRegion.x10"
            final boolean t$154891 = r$154890.contains$O(((x10.lang.Point)(p)));
            
            //#line 224 "x10/regionarray/PolyRegion.x10"
            final boolean t$154892 = !(t$154891);
            
            //#line 224 "x10/regionarray/PolyRegion.x10"
            if (t$154892) {
                
                //#line 225 "x10/regionarray/PolyRegion.x10"
                return false;
            }
        }
        
        //#line 228 "x10/regionarray/PolyRegion.x10"
        return true;
    }
    
    
    //#line 244 "x10/regionarray/PolyRegion.x10"
    private static int ROW = 0;
    
    //#line 245 "x10/regionarray/PolyRegion.x10"
    private static int COL = 0;
    
    
    //#line 247 "x10/regionarray/PolyRegion.x10"
    public static x10.regionarray.Region makeBanded(final int rowMin, final int colMin, final int rowMax, final int colMax, final int upper, final int lower) {
        
        //#line 248 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 248 "x10/regionarray/PolyRegion.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(2L)));
        
        //#line 249 "x10/regionarray/PolyRegion.x10"
        final int t$154678 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 249 "x10/regionarray/PolyRegion.x10"
        final int t$154679 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 249 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$154678), (int)(t$154679), (int)(rowMin));
        
        //#line 250 "x10/regionarray/PolyRegion.x10"
        final int t$154680 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 250 "x10/regionarray/PolyRegion.x10"
        final int t$154681 = x10.regionarray.PolyMatBuilder.get$LE();
        
        //#line 250 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$154680), (int)(t$154681), (int)(rowMax));
        
        //#line 251 "x10/regionarray/PolyRegion.x10"
        final int t$154682 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 251 "x10/regionarray/PolyRegion.x10"
        final int t$154683 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 251 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$154682), (int)(t$154683), (int)(colMin));
        
        //#line 252 "x10/regionarray/PolyRegion.x10"
        final int t$154684 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 252 "x10/regionarray/PolyRegion.x10"
        final int t$154685 = x10.regionarray.PolyMatBuilder.get$LE();
        
        //#line 252 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$154684), (int)(t$154685), (int)(colMax));
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$154686 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$154687 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$154690 = ((t$154686) - (((int)(t$154687))));
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$154691 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$154688 = ((colMin) - (((int)(rowMin))));
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$154689 = ((lower) - (((int)(1))));
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$154692 = ((t$154688) - (((int)(t$154689))));
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$154690), (int)(t$154691), (int)(t$154692));
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$154693 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$154694 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$154697 = ((t$154693) - (((int)(t$154694))));
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$154698 = x10.regionarray.PolyMatBuilder.get$LE();
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$154695 = ((colMin) - (((int)(rowMin))));
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$154696 = ((upper) - (((int)(1))));
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$154699 = ((t$154695) + (((int)(t$154696))));
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$154697), (int)(t$154698), (int)(t$154699));
        
        //#line 255 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 256 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154700 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 256 "x10/regionarray/PolyRegion.x10"
        return t$154700;
    }
    
    
    //#line 259 "x10/regionarray/PolyRegion.x10"
    public static x10.regionarray.Region makeBanded(final int size, final int upper, final int lower) {
        
        //#line 260 "x10/regionarray/PolyRegion.x10"
        final int t$154701 = ((size) - (((int)(1))));
        
        //#line 260 "x10/regionarray/PolyRegion.x10"
        final int t$154702 = ((size) - (((int)(1))));
        
        //#line 260 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154703 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.makeBanded((int)(0), (int)(0), (int)(t$154701), (int)(t$154702), (int)(upper), (int)(lower))));
        
        //#line 260 "x10/regionarray/PolyRegion.x10"
        return t$154703;
    }
    
    
    //#line 263 "x10/regionarray/PolyRegion.x10"
    public static x10.regionarray.Region makeUpperTriangular2(final int rowMin, final int colMin, final int size) {
        
        //#line 264 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 264 "x10/regionarray/PolyRegion.x10"
        final long t$154896 = ((long)(((int)(2))));
        
        //#line 264 "x10/regionarray/PolyRegion.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(t$154896);
        
        //#line 265 "x10/regionarray/PolyRegion.x10"
        final int t$154705 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 265 "x10/regionarray/PolyRegion.x10"
        final int t$154706 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 265 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$154705), (int)(t$154706), (int)(rowMin));
        
        //#line 266 "x10/regionarray/PolyRegion.x10"
        final int t$154708 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 266 "x10/regionarray/PolyRegion.x10"
        final int t$154709 = x10.regionarray.PolyMatBuilder.get$LE();
        
        //#line 266 "x10/regionarray/PolyRegion.x10"
        final int t$154707 = ((colMin) + (((int)(size))));
        
        //#line 266 "x10/regionarray/PolyRegion.x10"
        final int t$154710 = ((t$154707) - (((int)(1))));
        
        //#line 266 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$154708), (int)(t$154709), (int)(t$154710));
        
        //#line 267 "x10/regionarray/PolyRegion.x10"
        final int t$154711 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 267 "x10/regionarray/PolyRegion.x10"
        final int t$154712 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 267 "x10/regionarray/PolyRegion.x10"
        final int t$154713 = ((t$154711) - (((int)(t$154712))));
        
        //#line 267 "x10/regionarray/PolyRegion.x10"
        final int t$154714 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 267 "x10/regionarray/PolyRegion.x10"
        final int t$154715 = ((colMin) - (((int)(rowMin))));
        
        //#line 267 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$154713), (int)(t$154714), (int)(t$154715));
        
        //#line 268 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(true))));
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154716 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$153677 = ((x10.regionarray.Region)
                                                  t$154716);
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        final long t$154717 = t$153677.rank;
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        final boolean t$154718 = ((long) t$154717) == ((long) 2L);
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        final boolean t$154720 = !(t$154718);
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        if (t$154720) {
            
            //#line 269 "x10/regionarray/PolyRegion.x10"
            final x10.lang.FailedDynamicCheckException t$154719 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==2L}");
            
            //#line 269 "x10/regionarray/PolyRegion.x10"
            throw t$154719;
        }
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        return t$153677;
    }
    
    
    //#line 272 "x10/regionarray/PolyRegion.x10"
    public static x10.regionarray.Region makeLowerTriangular2(final int rowMin, final int colMin, final int size) {
        
        //#line 273 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 273 "x10/regionarray/PolyRegion.x10"
        final long t$154897 = ((long)(((int)(2))));
        
        //#line 273 "x10/regionarray/PolyRegion.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(t$154897);
        
        //#line 274 "x10/regionarray/PolyRegion.x10"
        final int t$154722 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 274 "x10/regionarray/PolyRegion.x10"
        final int t$154723 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 274 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$154722), (int)(t$154723), (int)(colMin));
        
        //#line 275 "x10/regionarray/PolyRegion.x10"
        final int t$154725 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 275 "x10/regionarray/PolyRegion.x10"
        final int t$154726 = x10.regionarray.PolyMatBuilder.get$LE();
        
        //#line 275 "x10/regionarray/PolyRegion.x10"
        final int t$154724 = ((rowMin) + (((int)(size))));
        
        //#line 275 "x10/regionarray/PolyRegion.x10"
        final int t$154727 = ((t$154724) - (((int)(1))));
        
        //#line 275 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$154725), (int)(t$154726), (int)(t$154727));
        
        //#line 276 "x10/regionarray/PolyRegion.x10"
        final int t$154728 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 276 "x10/regionarray/PolyRegion.x10"
        final int t$154729 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 276 "x10/regionarray/PolyRegion.x10"
        final int t$154730 = ((t$154728) - (((int)(t$154729))));
        
        //#line 276 "x10/regionarray/PolyRegion.x10"
        final int t$154731 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 276 "x10/regionarray/PolyRegion.x10"
        final int t$154732 = ((rowMin) - (((int)(colMin))));
        
        //#line 276 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$154730), (int)(t$154731), (int)(t$154732));
        
        //#line 277 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(true))));
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154733 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$153707 = ((x10.regionarray.Region)
                                                  t$154733);
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        final long t$154734 = t$153707.rank;
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        final boolean t$154735 = ((long) t$154734) == ((long) 2L);
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        final boolean t$154737 = !(t$154735);
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        if (t$154737) {
            
            //#line 278 "x10/regionarray/PolyRegion.x10"
            final x10.lang.FailedDynamicCheckException t$154736 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==2L}");
            
            //#line 278 "x10/regionarray/PolyRegion.x10"
            throw t$154736;
        }
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        return t$153707;
    }
    
    
    //#line 288 "x10/regionarray/PolyRegion.x10"
    /**
     * here's where we examine the halfspaces and generate
     * special-case subclasses, such as RectRegion, for efficiency
     */
    public static x10.regionarray.Region make(final x10.regionarray.PolyMat pm) {
        
        //#line 289 "x10/regionarray/PolyRegion.x10"
        final boolean t$154739 = pm.isEmpty$O();
        
        //#line 289 "x10/regionarray/PolyRegion.x10"
        if (t$154739) {
            
            //#line 290 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.EmptyRegion alloc$153713 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
            
            //#line 290 "x10/regionarray/PolyRegion.x10"
            final long t$154898 = pm.rank;
            
            //#line 290 "x10/regionarray/PolyRegion.x10"
            alloc$153713.x10$regionarray$EmptyRegion$$init$S(((long)(t$154898)));
            
            //#line 290 "x10/regionarray/PolyRegion.x10"
            return alloc$153713;
        } else {
            
            //#line 292 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRegion alloc$153714 = ((x10.regionarray.PolyRegion)(new x10.regionarray.PolyRegion((java.lang.System[]) null)));
            
            //#line 292 "x10/regionarray/PolyRegion.x10"
            alloc$153714.x10$regionarray$PolyRegion$$init$S(((x10.regionarray.PolyMat)(pm)), ((boolean)(false)));
            
            //#line 292 "x10/regionarray/PolyRegion.x10"
            return alloc$153714;
        }
    }
    
    
    //#line 296 "x10/regionarray/PolyRegion.x10"
    // creation method for java code (1-phase java constructor)
    public PolyRegion(final x10.regionarray.PolyMat pm, final boolean hack198) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyRegion$$init$S(pm, hack198);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyRegion x10$regionarray$PolyRegion$$init$S(final x10.regionarray.PolyMat pm, final boolean hack198) {
         {
            
            //#line 298 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.Region this$154490 = ((x10.regionarray.Region)(this));
            
            //#line 298 "x10/regionarray/PolyRegion.x10"
            final long r$154486 = pm.rank;
            
            //#line 298 "x10/regionarray/PolyRegion.x10"
            final boolean t$154487 = pm.isRect$O();
            
            //#line 298 "x10/regionarray/PolyRegion.x10"
            final boolean z$154488 = pm.isZeroBased$O();
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$154899 = ((long) r$154486) == ((long) 1L);
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$154899) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$154899 = t$154487;
            }
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$154900 = t$154899;
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$154899) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$154900 = z$154488;
            }
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$154490.rank = r$154486;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$154490.rect = t$154487;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$154490.zeroBased = z$154488;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$154490.rail = t$154900;
            
            //#line 296 "x10/regionarray/PolyRegion.x10"
            
            
            //#line 26 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRegion this$154902 = this;
            
            //#line 26 "x10/regionarray/PolyRegion.x10"
            this$154902.size = -1L;
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyMat t$154742 = ((x10.regionarray.PolyMat)(pm.simplifyAll()));
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyMat t$153709 = ((x10.regionarray.PolyMat)
                                                       t$154742);
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            final long t$154743 = t$153709.rank;
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            final long t$154744 = x10.regionarray.PolyRegion.this.rank;
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            final boolean t$154745 = ((long) t$154743) == ((long) t$154744);
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            final boolean t$154747 = !(t$154745);
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            if (t$154747) {
                
                //#line 302 "x10/regionarray/PolyRegion.x10"
                final x10.lang.FailedDynamicCheckException t$154746 = new x10.lang.FailedDynamicCheckException("x10.regionarray.PolyMat{self.rank==this(:x10.regionarray.PolyRegion).rank}");
                
                //#line 302 "x10/regionarray/PolyRegion.x10"
                throw t$154746;
            }
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            this.mat = ((x10.regionarray.PolyMat)(t$153709));
        }
        return this;
    }
    
    
    
    //#line 310 "x10/regionarray/PolyRegion.x10"
    public x10.core.fun.Fun_0_1 min() {
        
        //#line 311 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154748 = ((x10.regionarray.Region)(this.boundingBox()));
        
        //#line 311 "x10/regionarray/PolyRegion.x10"
        final x10.core.fun.Fun_0_1 t = t$154748.min();
        
        //#line 312 "x10/regionarray/PolyRegion.x10"
        final x10.core.fun.Fun_0_1 t$154752 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyRegion.$Closure$212(t, (x10.regionarray.PolyRegion.$Closure$212.__0$1x10$lang$Long$3x10$lang$Long$2) null)));
        
        //#line 312 "x10/regionarray/PolyRegion.x10"
        return t$154752;
    }
    
    
    //#line 315 "x10/regionarray/PolyRegion.x10"
    public x10.core.fun.Fun_0_1 max() {
        
        //#line 316 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154753 = ((x10.regionarray.Region)(this.boundingBox()));
        
        //#line 316 "x10/regionarray/PolyRegion.x10"
        final x10.core.fun.Fun_0_1 t = t$154753.max();
        
        //#line 317 "x10/regionarray/PolyRegion.x10"
        final x10.core.fun.Fun_0_1 t$154757 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyRegion.$Closure$213(t, (x10.regionarray.PolyRegion.$Closure$213.__0$1x10$lang$Long$3x10$lang$Long$2) null)));
        
        //#line 317 "x10/regionarray/PolyRegion.x10"
        return t$154757;
    }
    
    
    //#line 325 "x10/regionarray/PolyRegion.x10"
    public void printInfo(final x10.io.Printer out) {
        
        //#line 326 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$154758 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 326 "x10/regionarray/PolyRegion.x10"
        final java.lang.String t$154759 = this.toString();
        
        //#line 326 "x10/regionarray/PolyRegion.x10"
        ((x10.regionarray.Mat<x10.regionarray.PolyRow>)t$154758).printInfo(((x10.io.Printer)(out)), ((java.lang.String)(t$154759)));
    }
    
    
    //#line 329 "x10/regionarray/PolyRegion.x10"
    public java.lang.String toString() {
        
        //#line 330 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$154760 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 330 "x10/regionarray/PolyRegion.x10"
        final java.lang.String t$154761 = t$154760.toString();
        
        //#line 330 "x10/regionarray/PolyRegion.x10"
        return t$154761;
    }
    
    
    //#line 26 "x10/regionarray/PolyRegion.x10"
    final public x10.regionarray.PolyRegion x10$regionarray$PolyRegion$$this$x10$regionarray$PolyRegion() {
        
        //#line 26 "x10/regionarray/PolyRegion.x10"
        return x10.regionarray.PolyRegion.this;
    }
    
    
    //#line 26 "x10/regionarray/PolyRegion.x10"
    final public void __fieldInitializers_x10_regionarray_PolyRegion() {
        
        //#line 26 "x10/regionarray/PolyRegion.x10"
        this.size = -1L;
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$COL = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$COL;
    final private static x10.core.concurrent.AtomicInteger initStatus$ROW = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$ROW;
    
    public static int get$ROW() {
        if (((int) x10.regionarray.PolyRegion.initStatus$ROW.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.regionarray.PolyRegion.ROW;
        }
        if (((int) x10.regionarray.PolyRegion.initStatus$ROW.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.regionarray.PolyRegion.exception$ROW;
        }
        if (x10.regionarray.PolyRegion.initStatus$ROW.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.regionarray.PolyRegion.ROW = x10.regionarray.PolyMatBuilder.X$O((int)(0));
            }}catch (java.lang.Throwable exc$154903) {
                x10.regionarray.PolyRegion.exception$ROW = new x10.lang.ExceptionInInitializer(exc$154903);
                x10.regionarray.PolyRegion.initStatus$ROW.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.regionarray.PolyRegion.exception$ROW;
            }
            x10.regionarray.PolyRegion.initStatus$ROW.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.regionarray.PolyRegion.initStatus$ROW.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.regionarray.PolyRegion.initStatus$ROW.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.regionarray.PolyRegion.initStatus$ROW.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.regionarray.PolyRegion.exception$ROW;
                }
            }
        }
        return x10.regionarray.PolyRegion.ROW;
    }
    
    public static int get$COL() {
        if (((int) x10.regionarray.PolyRegion.initStatus$COL.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.regionarray.PolyRegion.COL;
        }
        if (((int) x10.regionarray.PolyRegion.initStatus$COL.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.regionarray.PolyRegion.exception$COL;
        }
        if (x10.regionarray.PolyRegion.initStatus$COL.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.regionarray.PolyRegion.COL = x10.regionarray.PolyMatBuilder.X$O((int)(1));
            }}catch (java.lang.Throwable exc$154904) {
                x10.regionarray.PolyRegion.exception$COL = new x10.lang.ExceptionInInitializer(exc$154904);
                x10.regionarray.PolyRegion.initStatus$COL.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.regionarray.PolyRegion.exception$COL;
            }
            x10.regionarray.PolyRegion.initStatus$COL.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.regionarray.PolyRegion.initStatus$COL.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.regionarray.PolyRegion.initStatus$COL.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.regionarray.PolyRegion.initStatus$COL.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.regionarray.PolyRegion.exception$COL;
                }
            }
        }
        return x10.regionarray.PolyRegion.COL;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$212 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$212> $RTT = 
            x10.rtt.StaticFunType.<$Closure$212> make($Closure$212.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyRegion.$Closure$212 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.t = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyRegion.$Closure$212 $_obj = new x10.regionarray.PolyRegion.$Closure$212((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.t);
            
        }
        
        // constructor just for allocation
        public $Closure$212(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 312 "x10/regionarray/PolyRegion.x10"
            final int t$154749 = ((int)(long)(((long)(i))));
            
            //#line 312 "x10/regionarray/PolyRegion.x10"
            final long t$154750 = ((long)(((int)(t$154749))));
            
            //#line 312 "x10/regionarray/PolyRegion.x10"
            final long t$154751 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.t).$apply(x10.core.Long.$box(t$154750), x10.rtt.Types.LONG));
            
            //#line 312 "x10/regionarray/PolyRegion.x10"
            return t$154751;
        }
        
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> t;
        
        public $Closure$212(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> t, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.t = ((x10.core.fun.Fun_0_1)(t));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$213 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$213> $RTT = 
            x10.rtt.StaticFunType.<$Closure$213> make($Closure$213.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyRegion.$Closure$213 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.t = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyRegion.$Closure$213 $_obj = new x10.regionarray.PolyRegion.$Closure$213((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.t);
            
        }
        
        // constructor just for allocation
        public $Closure$213(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 317 "x10/regionarray/PolyRegion.x10"
            final int t$154754 = ((int)(long)(((long)(i))));
            
            //#line 317 "x10/regionarray/PolyRegion.x10"
            final long t$154755 = ((long)(((int)(t$154754))));
            
            //#line 317 "x10/regionarray/PolyRegion.x10"
            final long t$154756 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.t).$apply(x10.core.Long.$box(t$154755), x10.rtt.Types.LONG));
            
            //#line 317 "x10/regionarray/PolyRegion.x10"
            return t$154756;
        }
        
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> t;
        
        public $Closure$213(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> t, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.t = ((x10.core.fun.Fun_0_1)(t));
            }
        }
        
    }
    
}


