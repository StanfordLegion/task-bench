package x10.regionarray;


@x10.runtime.impl.java.X10Generated
public class MatBuilder extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<MatBuilder> $RTT = 
        x10.rtt.NamedType.<MatBuilder> make("x10.regionarray.MatBuilder",
                                            MatBuilder.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.MatBuilder $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.cols = $deserializer.readInt();
        $_obj.mat = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.MatBuilder $_obj = new x10.regionarray.MatBuilder((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.cols);
        $serializer.write(this.mat);
        
    }
    
    // constructor just for allocation
    public MatBuilder(final java.lang.System[] $dummy) {
        
    }
    
    

    
    //#line 18 "x10/regionarray/MatBuilder.x10"
    public x10.util.ArrayList<x10.regionarray.Row> mat;
    
    //#line 19 "x10/regionarray/MatBuilder.x10"
    public int cols;
    
    
    //#line 21 "x10/regionarray/MatBuilder.x10"
    // creation method for java code (1-phase java constructor)
    public MatBuilder(final int cols) {
        this((java.lang.System[]) null);
        x10$regionarray$MatBuilder$$init$S(cols);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.MatBuilder x10$regionarray$MatBuilder$$init$S(final int cols) {
         {
            
            //#line 21 "x10/regionarray/MatBuilder.x10"
            
            
            //#line 22 "x10/regionarray/MatBuilder.x10"
            this.cols = cols;
            
            //#line 23 "x10/regionarray/MatBuilder.x10"
            final x10.util.ArrayList alloc$151543 = ((x10.util.ArrayList)(new x10.util.ArrayList<x10.regionarray.Row>((java.lang.System[]) null, x10.regionarray.Row.$RTT)));
            
            //#line 23 "x10/regionarray/MatBuilder.x10"
            alloc$151543.x10$util$ArrayList$$init$S();
            
            //#line 23 "x10/regionarray/MatBuilder.x10"
            this.mat = ((x10.util.ArrayList)(alloc$151543));
        }
        return this;
    }
    
    
    
    //#line 26 "x10/regionarray/MatBuilder.x10"
    // creation method for java code (1-phase java constructor)
    public MatBuilder(final int rows, final int cols) {
        this((java.lang.System[]) null);
        x10$regionarray$MatBuilder$$init$S(rows, cols);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.MatBuilder x10$regionarray$MatBuilder$$init$S(final int rows, final int cols) {
         {
            
            //#line 26 "x10/regionarray/MatBuilder.x10"
            
            
            //#line 27 "x10/regionarray/MatBuilder.x10"
            this.cols = cols;
            
            //#line 28 "x10/regionarray/MatBuilder.x10"
            final x10.util.ArrayList m = ((x10.util.ArrayList)(new x10.util.ArrayList<x10.regionarray.Row>((java.lang.System[]) null, x10.regionarray.Row.$RTT)));
            
            //#line 28 "x10/regionarray/MatBuilder.x10"
            final long t$151610 = ((long)(((int)(rows))));
            
            //#line 28 "x10/regionarray/MatBuilder.x10"
            m.x10$util$ArrayList$$init$S(t$151610);
            
            //#line 29 "x10/regionarray/MatBuilder.x10"
            this.mat = ((x10.util.ArrayList)(m));
            
            //#line 30 "x10/regionarray/MatBuilder.x10"
            x10.regionarray.MatBuilder.need__1$1x10$regionarray$Row$2((int)(rows), ((x10.util.ArrayList)(m)), (int)(cols));
        }
        return this;
    }
    
    
    
    //#line 33 "x10/regionarray/MatBuilder.x10"
    public void add(final x10.regionarray.Row row) {
        
        //#line 34 "x10/regionarray/MatBuilder.x10"
        final x10.util.ArrayList t$151551 = ((x10.util.ArrayList)(this.mat));
        
        //#line 34 "x10/regionarray/MatBuilder.x10"
        ((x10.util.ArrayList<x10.regionarray.Row>)t$151551).add__0x10$util$ArrayList$$T$O(((x10.regionarray.Row)(row)));
    }
    
    
    //#line 37 "x10/regionarray/MatBuilder.x10"
    public void add__0$1x10$lang$Int$3x10$lang$Int$2(final x10.core.fun.Fun_0_1 a) {
        
        //#line 38 "x10/regionarray/MatBuilder.x10"
        final x10.util.ArrayList t$151553 = ((x10.util.ArrayList)(this.mat));
        
        //#line 38 "x10/regionarray/MatBuilder.x10"
        final x10.regionarray.VarRow alloc$151544 = ((x10.regionarray.VarRow)(new x10.regionarray.VarRow((java.lang.System[]) null)));
        
        //#line 38 "x10/regionarray/MatBuilder.x10"
        final int t$151611 = this.cols;
        
        //#line 38 "x10/regionarray/MatBuilder.x10"
        alloc$151544.x10$regionarray$VarRow$$init$S(((int)(t$151611)), ((x10.core.fun.Fun_0_1)(a)), (x10.regionarray.VarRow.__1$1x10$lang$Int$3x10$lang$Int$2) null);
        
        //#line 38 "x10/regionarray/MatBuilder.x10"
        ((x10.util.ArrayList<x10.regionarray.Row>)t$151553).add__0x10$util$ArrayList$$T$O(((x10.regionarray.Row)(alloc$151544)));
    }
    
    
    //#line 41 "x10/regionarray/MatBuilder.x10"
    public int $apply$O(final int i, final int j) {
        
        //#line 41 "x10/regionarray/MatBuilder.x10"
        final x10.util.ArrayList t$151554 = ((x10.util.ArrayList)(this.mat));
        
        //#line 41 "x10/regionarray/MatBuilder.x10"
        final long t$151555 = ((long)(((int)(i))));
        
        //#line 41 "x10/regionarray/MatBuilder.x10"
        final x10.regionarray.Row t$151556 = ((x10.util.ArrayList<x10.regionarray.Row>)t$151554).$apply$G((long)(t$151555));
        
        //#line 41 "x10/regionarray/MatBuilder.x10"
        final int t$151557 = t$151556.$apply$O((int)(j));
        
        //#line 41 "x10/regionarray/MatBuilder.x10"
        return t$151557;
    }
    
    
    //#line 43 "x10/regionarray/MatBuilder.x10"
    public void $set(final int i, final int j, final int v) {
        
        //#line 44 "x10/regionarray/MatBuilder.x10"
        final int t$151558 = ((i) + (((int)(1))));
        
        //#line 44 "x10/regionarray/MatBuilder.x10"
        this.need((int)(t$151558));
        
        //#line 45 "x10/regionarray/MatBuilder.x10"
        final x10.util.ArrayList t$151559 = ((x10.util.ArrayList)(this.mat));
        
        //#line 45 "x10/regionarray/MatBuilder.x10"
        final long t$151560 = ((long)(((int)(i))));
        
        //#line 45 "x10/regionarray/MatBuilder.x10"
        final x10.regionarray.Row t$151561 = ((x10.util.ArrayList<x10.regionarray.Row>)t$151559).$apply$G((long)(t$151560));
        
        //#line 45 "x10/regionarray/MatBuilder.x10"
        t$151561.$set$O((int)(j), (int)(v));
    }
    
    
    //#line 48 "x10/regionarray/MatBuilder.x10"
    public void setDiagonal__3$1x10$lang$Int$3x10$lang$Int$2(final int i, final int j, final int n, final x10.core.fun.Fun_0_1 v) {
        
        //#line 49 "x10/regionarray/MatBuilder.x10"
        final int t$151562 = ((i) + (((int)(n))));
        
        //#line 49 "x10/regionarray/MatBuilder.x10"
        this.need((int)(t$151562));
        
        //#line 50 "x10/regionarray/MatBuilder.x10"
        int k$151623 = 0;
        
        //#line 50 "x10/regionarray/MatBuilder.x10"
        for (;
             true;
             ) {
            
            //#line 50 "x10/regionarray/MatBuilder.x10"
            final boolean t$151625 = ((k$151623) < (((int)(n))));
            
            //#line 50 "x10/regionarray/MatBuilder.x10"
            if (!(t$151625)) {
                
                //#line 50 "x10/regionarray/MatBuilder.x10"
                break;
            }
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            final x10.util.ArrayList t$151612 = ((x10.util.ArrayList)(this.mat));
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            final int t$151614 = ((i) + (((int)(k$151623))));
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            final long t$151615 = ((long)(((int)(t$151614))));
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            final x10.regionarray.Row t$151616 = ((x10.util.ArrayList<x10.regionarray.Row>)t$151612).$apply$G((long)(t$151615));
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            final int t$151618 = ((j) + (((int)(k$151623))));
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            final int t$151620 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int>)v).$apply(x10.core.Int.$box(k$151623), x10.rtt.Types.INT));
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            t$151616.$set$O((int)(t$151618), (int)(t$151620));
            
            //#line 50 "x10/regionarray/MatBuilder.x10"
            final int t$151622 = ((k$151623) + (((int)(1))));
            
            //#line 50 "x10/regionarray/MatBuilder.x10"
            k$151623 = t$151622;
        }
    }
    
    
    //#line 54 "x10/regionarray/MatBuilder.x10"
    public void setColumn__3$1x10$lang$Int$3x10$lang$Int$2(final int i, final int j, final int n, final x10.core.fun.Fun_0_1 v) {
        
        //#line 55 "x10/regionarray/MatBuilder.x10"
        final int t$151577 = ((i) + (((int)(n))));
        
        //#line 55 "x10/regionarray/MatBuilder.x10"
        this.need((int)(t$151577));
        
        //#line 56 "x10/regionarray/MatBuilder.x10"
        int k$151635 = 0;
        
        //#line 56 "x10/regionarray/MatBuilder.x10"
        for (;
             true;
             ) {
            
            //#line 56 "x10/regionarray/MatBuilder.x10"
            final boolean t$151637 = ((k$151635) < (((int)(n))));
            
            //#line 56 "x10/regionarray/MatBuilder.x10"
            if (!(t$151637)) {
                
                //#line 56 "x10/regionarray/MatBuilder.x10"
                break;
            }
            
            //#line 57 "x10/regionarray/MatBuilder.x10"
            final x10.util.ArrayList t$151626 = ((x10.util.ArrayList)(this.mat));
            
            //#line 57 "x10/regionarray/MatBuilder.x10"
            final int t$151628 = ((i) + (((int)(k$151635))));
            
            //#line 57 "x10/regionarray/MatBuilder.x10"
            final long t$151629 = ((long)(((int)(t$151628))));
            
            //#line 57 "x10/regionarray/MatBuilder.x10"
            final x10.regionarray.Row t$151630 = ((x10.util.ArrayList<x10.regionarray.Row>)t$151626).$apply$G((long)(t$151629));
            
            //#line 57 "x10/regionarray/MatBuilder.x10"
            final int t$151632 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int>)v).$apply(x10.core.Int.$box(k$151635), x10.rtt.Types.INT));
            
            //#line 57 "x10/regionarray/MatBuilder.x10"
            t$151630.$set$O((int)(j), (int)(t$151632));
            
            //#line 56 "x10/regionarray/MatBuilder.x10"
            final int t$151634 = ((k$151635) + (((int)(1))));
            
            //#line 56 "x10/regionarray/MatBuilder.x10"
            k$151635 = t$151634;
        }
    }
    
    
    //#line 60 "x10/regionarray/MatBuilder.x10"
    public void setRow__3$1x10$lang$Int$3x10$lang$Int$2(final int i, final int j, final int n, final x10.core.fun.Fun_0_1 v) {
        
        //#line 61 "x10/regionarray/MatBuilder.x10"
        final int t$151590 = ((i) + (((int)(1))));
        
        //#line 61 "x10/regionarray/MatBuilder.x10"
        this.need((int)(t$151590));
        
        //#line 62 "x10/regionarray/MatBuilder.x10"
        int k$151647 = 0;
        
        //#line 62 "x10/regionarray/MatBuilder.x10"
        for (;
             true;
             ) {
            
            //#line 62 "x10/regionarray/MatBuilder.x10"
            final boolean t$151649 = ((k$151647) < (((int)(n))));
            
            //#line 62 "x10/regionarray/MatBuilder.x10"
            if (!(t$151649)) {
                
                //#line 62 "x10/regionarray/MatBuilder.x10"
                break;
            }
            
            //#line 63 "x10/regionarray/MatBuilder.x10"
            final x10.util.ArrayList t$151638 = ((x10.util.ArrayList)(this.mat));
            
            //#line 63 "x10/regionarray/MatBuilder.x10"
            final long t$151639 = ((long)(((int)(i))));
            
            //#line 63 "x10/regionarray/MatBuilder.x10"
            final x10.regionarray.Row t$151640 = ((x10.util.ArrayList<x10.regionarray.Row>)t$151638).$apply$G((long)(t$151639));
            
            //#line 63 "x10/regionarray/MatBuilder.x10"
            final int t$151642 = ((j) + (((int)(k$151647))));
            
            //#line 63 "x10/regionarray/MatBuilder.x10"
            final int t$151644 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int>)v).$apply(x10.core.Int.$box(k$151647), x10.rtt.Types.INT));
            
            //#line 63 "x10/regionarray/MatBuilder.x10"
            t$151640.$set$O((int)(t$151642), (int)(t$151644));
            
            //#line 62 "x10/regionarray/MatBuilder.x10"
            final int t$151646 = ((k$151647) + (((int)(1))));
            
            //#line 62 "x10/regionarray/MatBuilder.x10"
            k$151647 = t$151646;
        }
    }
    
    
    //#line 66 "x10/regionarray/MatBuilder.x10"
    private void need(final int n) {
        
        //#line 66 "x10/regionarray/MatBuilder.x10"
        final x10.util.ArrayList t$151603 = ((x10.util.ArrayList)(this.mat));
        
        //#line 66 "x10/regionarray/MatBuilder.x10"
        final int t$151604 = this.cols;
        
        //#line 66 "x10/regionarray/MatBuilder.x10"
        x10.regionarray.MatBuilder.need__1$1x10$regionarray$Row$2((int)(n), ((x10.util.ArrayList)(t$151603)), (int)(t$151604));
    }
    
    public static void need$P(final int n, final x10.regionarray.MatBuilder MatBuilder) {
        MatBuilder.need((int)(n));
    }
    
    
    //#line 67 "x10/regionarray/MatBuilder.x10"
    private static void need__1$1x10$regionarray$Row$2(final int n, final x10.util.ArrayList<x10.regionarray.Row> mat, final int cols) {
        
        //#line 68 "x10/regionarray/MatBuilder.x10"
        while (true) {
            
            //#line 68 "x10/regionarray/MatBuilder.x10"
            final long t$151605 = ((x10.util.ArrayList<x10.regionarray.Row>)mat).size$O();
            
            //#line 68 "x10/regionarray/MatBuilder.x10"
            final long t$151606 = ((long)(((int)(n))));
            
            //#line 68 "x10/regionarray/MatBuilder.x10"
            final boolean t$151607 = ((t$151605) < (((long)(t$151606))));
            
            //#line 68 "x10/regionarray/MatBuilder.x10"
            if (!(t$151607)) {
                
                //#line 68 "x10/regionarray/MatBuilder.x10"
                break;
            }
            
            //#line 69 "x10/regionarray/MatBuilder.x10"
            final x10.regionarray.VarRow alloc$151650 = ((x10.regionarray.VarRow)(new x10.regionarray.VarRow((java.lang.System[]) null)));
            
            //#line 69 "x10/regionarray/MatBuilder.x10"
            alloc$151650.x10$regionarray$VarRow$$init$S(((int)(cols)));
            
            //#line 69 "x10/regionarray/MatBuilder.x10"
            ((x10.util.ArrayList<x10.regionarray.Row>)mat).add__0x10$util$ArrayList$$T$O(((x10.regionarray.Row)(alloc$151650)));
        }
    }
    
    public static void need$P__1$1x10$regionarray$Row$2(final int n, final x10.util.ArrayList<x10.regionarray.Row> mat, final int cols) {
        x10.regionarray.MatBuilder.need__1$1x10$regionarray$Row$2((int)(n), ((x10.util.ArrayList)(mat)), (int)(cols));
    }
    
    
    //#line 16 "x10/regionarray/MatBuilder.x10"
    final public x10.regionarray.MatBuilder x10$regionarray$MatBuilder$$this$x10$regionarray$MatBuilder() {
        
        //#line 16 "x10/regionarray/MatBuilder.x10"
        return x10.regionarray.MatBuilder.this;
    }
    
    
    //#line 16 "x10/regionarray/MatBuilder.x10"
    final public void __fieldInitializers_x10_regionarray_MatBuilder() {
        
    }
}

