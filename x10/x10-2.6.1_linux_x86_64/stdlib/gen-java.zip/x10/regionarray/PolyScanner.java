package x10.regionarray;


/**
 * Here's the general scheme for the information used in scanning,
 * illustrated for a region of rank r=4. Each axis Xi is bounded by
 * two sets of halfspaces, min[i] and max[i], obtained from the
 * region halfspaces by FME (resulting in the 0 coefficients as
 * shown). Computing the bounds for Xi requires substituting X0 up to
 * Xi-1 into each halfspace (as shown for the min[i]s) and taking
 * mins and maxes.
 *
 *           0   1   2   r-1
 * 
 * min[0]
 *           A0  0   0   0   B   X0 bounded by B / A0
 *           A0  0   0   0   B   X0 bounded by B / A0
 *           ...                 ...
 * 
 * min[1]
 *           A0  A1  0   0   B   X1 bounded by (B+A0*X0) / A1
 *           A0  A1  0   0   B   X1 bounded by (B+A0*X0) / A1
 *           ...                 ...
 * 
 * min[2]
 *           A0  A1  A2  0   B   X2 bounded by (B+A0*X0+A1*X1) / A2
 *           A0  A1  A2  0   B   X2 bounded by (B+A0*X0+A1*X1) / A2
 *           ...                 ...
 * 
 * min[3]
 *           A0  A1  A2  A3  B   X3 bounded by (B+A0*X0+A1*X1+A2*X2) / A3
 *           A0  A1  A2  A3  B   X3 bounded by (B+A0*X0+A1*X1+A2*X2) / A3
 *           ...                 ...
 *
 * In the innermost loop the bounds for X3 could be computed by
 * substituting the known values of X0 through X2 into each
 * halfspace. However, part of that computation can be pulled out of
 * the inner loop by keeping track for each halfspace in in min[k]
 * and each constraint in max[k] a set of partial sums of the form
 *
 *     minSum[0] = B
 *     minSum[1] = B+A0*X0
 *     ...
 *     minSum[k] = B+A0*X0+A1*X1+...+Ak-1*Xk-1
 *
 * (and similiarly for maxSum) and updating each partial sum
 * minSum[i+1] (and similarly for maxSum[i+1]) every time Xi changes
 * by
 *
 *     minSum[i+1] := sum[i] + Ai*Xi
 *
 * The loop bounds for Xk are then obtained by computing mins and
 * maxes over the sum[k]/Ak for the halfspaces in elim[k].
 */
@x10.runtime.impl.java.X10Generated
final public class PolyScanner extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PolyScanner> $RTT = 
        x10.rtt.NamedType.<PolyScanner> make("x10.regionarray.PolyScanner",
                                             PolyScanner.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyScanner $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.C = $deserializer.readObject();
        $_obj.max2 = $deserializer.readObject();
        $_obj.maxSum = $deserializer.readObject();
        $_obj.min2 = $deserializer.readObject();
        $_obj.minSum = $deserializer.readObject();
        $_obj.myMax = $deserializer.readObject();
        $_obj.myMin = $deserializer.readObject();
        $_obj.parFlags = $deserializer.readObject();
        $_obj.rank = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.PolyScanner $_obj = new x10.regionarray.PolyScanner((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.C);
        $serializer.write(this.max2);
        $serializer.write(this.maxSum);
        $serializer.write(this.min2);
        $serializer.write(this.minSum);
        $serializer.write(this.myMax);
        $serializer.write(this.myMin);
        $serializer.write(this.parFlags);
        $serializer.write(this.rank);
        
    }
    
    // constructor just for allocation
    public PolyScanner(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 68 "x10/regionarray/PolyScanner.x10"
    public long rank;
    

    
    //#line 70 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.PolyMat C;
    
    //#line 74 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.regionarray.VarMat> myMin;
    
    //#line 75 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.regionarray.VarMat> myMax;
    
    //#line 76 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.regionarray.VarMat> minSum;
    
    //#line 77 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.regionarray.VarMat> maxSum;
    
    //#line 79 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.core.Boolean> parFlags;
    
    //#line 80 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>> min2;
    
    //#line 81 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>> max2;
    
    
    //#line 83 "x10/regionarray/PolyScanner.x10"
    public static x10.regionarray.PolyScanner make(final x10.regionarray.PolyMat pm) {
        
        //#line 84 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.PolyScanner x = ((x10.regionarray.PolyScanner)(new x10.regionarray.PolyScanner((java.lang.System[]) null)));
        
        //#line 84 "x10/regionarray/PolyScanner.x10"
        x.x10$regionarray$PolyScanner$$init$S(((x10.regionarray.PolyMat)(pm)));
        
        //#line 85 "x10/regionarray/PolyScanner.x10"
        x.init();
        
        //#line 86 "x10/regionarray/PolyScanner.x10"
        return x;
    }
    
    
    //#line 89 "x10/regionarray/PolyScanner.x10"
    // creation method for java code (1-phase java constructor)
    public PolyScanner(final x10.regionarray.PolyMat pm) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyScanner$$init$S(pm);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyScanner x10$regionarray$PolyScanner$$init$S(final x10.regionarray.PolyMat pm) {
         {
            
            //#line 90 "x10/regionarray/PolyScanner.x10"
            final long t$155918 = pm.rank;
            
            //#line 90 "x10/regionarray/PolyScanner.x10"
            this.rank = t$155918;
            
            
            //#line 91 "x10/regionarray/PolyScanner.x10"
            x10.regionarray.PolyMat pm0 = pm.simplifyAll();
            
            //#line 93 "x10/regionarray/PolyScanner.x10"
            this.C = ((x10.regionarray.PolyMat)(pm));
            
            //#line 94 "x10/regionarray/PolyScanner.x10"
            final long r = pm0.rank;
            
            //#line 95 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array n = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.VarMat>((java.lang.System[]) null, x10.regionarray.VarMat.$RTT)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$155934 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$155919 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$155934.x10$regionarray$RectRegion1D$$init$S(t$155919);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$155920 = ((x10.regionarray.Region)
                                                      myReg$155934);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).region = ((x10.regionarray.Region)(t$155920));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155935 = ((x10.regionarray.Array<x10.regionarray.VarMat>)n).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155936 = ((x10.regionarray.Array<x10.regionarray.VarMat>)n).layout_stride1 = t$155935;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).layout_min0 = t$155936;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$155937 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.VarMat>(x10.regionarray.VarMat.$RTT, r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).raw = ((x10.core.Rail)(t$155937));
            
            //#line 96 "x10/regionarray/PolyScanner.x10"
            this.myMin = ((x10.regionarray.Array)(n));
            
            //#line 97 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array x = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.VarMat>((java.lang.System[]) null, x10.regionarray.VarMat.$RTT)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$155938 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$155921 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$155938.x10$regionarray$RectRegion1D$$init$S(t$155921);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$155922 = ((x10.regionarray.Region)
                                                      myReg$155938);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).region = ((x10.regionarray.Region)(t$155922));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155939 = ((x10.regionarray.Array<x10.regionarray.VarMat>)x).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155940 = ((x10.regionarray.Array<x10.regionarray.VarMat>)x).layout_stride1 = t$155939;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).layout_min0 = t$155940;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$155941 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.VarMat>(x10.regionarray.VarMat.$RTT, r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).raw = ((x10.core.Rail)(t$155941));
            
            //#line 98 "x10/regionarray/PolyScanner.x10"
            this.myMax = ((x10.regionarray.Array)(x));
            
            //#line 99 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array nSum = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.VarMat>((java.lang.System[]) null, x10.regionarray.VarMat.$RTT)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$155942 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$155923 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$155942.x10$regionarray$RectRegion1D$$init$S(t$155923);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$155924 = ((x10.regionarray.Region)
                                                      myReg$155942);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).region = ((x10.regionarray.Region)(t$155924));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155943 = ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155944 = ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).layout_stride1 = t$155943;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).layout_min0 = t$155944;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$155945 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.VarMat>(x10.regionarray.VarMat.$RTT, r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).raw = ((x10.core.Rail)(t$155945));
            
            //#line 100 "x10/regionarray/PolyScanner.x10"
            this.minSum = ((x10.regionarray.Array)(nSum));
            
            //#line 101 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array xSum = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.VarMat>((java.lang.System[]) null, x10.regionarray.VarMat.$RTT)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$155946 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$155925 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$155946.x10$regionarray$RectRegion1D$$init$S(t$155925);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$155926 = ((x10.regionarray.Region)
                                                      myReg$155946);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).region = ((x10.regionarray.Region)(t$155926));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155947 = ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155948 = ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).layout_stride1 = t$155947;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).layout_min0 = t$155948;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$155949 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.VarMat>(x10.regionarray.VarMat.$RTT, r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).raw = ((x10.core.Rail)(t$155949));
            
            //#line 102 "x10/regionarray/PolyScanner.x10"
            this.maxSum = ((x10.regionarray.Array)(xSum));
            
            //#line 103 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array n2 = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>((java.lang.System[]) null, x10.rtt.ParameterizedType.make(x10.regionarray.Array.$RTT, x10.regionarray.PolyRow.$RTT))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$155950 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$155927 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$155950.x10$regionarray$RectRegion1D$$init$S(t$155927);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$155928 = ((x10.regionarray.Region)
                                                      myReg$155950);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).region = ((x10.regionarray.Region)(t$155928));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155951 = ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155952 = ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).layout_stride1 = t$155951;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).layout_min0 = t$155952;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$155953 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.Array<x10.regionarray.PolyRow>>(x10.rtt.ParameterizedType.make(x10.regionarray.Array.$RTT, x10.regionarray.PolyRow.$RTT), r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).raw = ((x10.core.Rail)(t$155953));
            
            //#line 104 "x10/regionarray/PolyScanner.x10"
            this.min2 = ((x10.regionarray.Array)(n2));
            
            //#line 105 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array x2 = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>((java.lang.System[]) null, x10.rtt.ParameterizedType.make(x10.regionarray.Array.$RTT, x10.regionarray.PolyRow.$RTT))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$155954 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$155929 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$155954.x10$regionarray$RectRegion1D$$init$S(t$155929);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$155930 = ((x10.regionarray.Region)
                                                      myReg$155954);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).region = ((x10.regionarray.Region)(t$155930));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155955 = ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155956 = ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).layout_stride1 = t$155955;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).layout_min0 = t$155956;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$155957 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.Array<x10.regionarray.PolyRow>>(x10.rtt.ParameterizedType.make(x10.regionarray.Array.$RTT, x10.regionarray.PolyRow.$RTT), r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).raw = ((x10.core.Rail)(t$155957));
            
            //#line 106 "x10/regionarray/PolyScanner.x10"
            this.max2 = ((x10.regionarray.Array)(x2));
            
            //#line 109 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array alloc$154462 = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.core.Boolean>((java.lang.System[]) null, x10.rtt.Types.BOOLEAN)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$155958 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$155931 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$155958.x10$regionarray$RectRegion1D$$init$S(t$155931);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$155932 = ((x10.regionarray.Region)
                                                      myReg$155958);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$154462).region = ((x10.regionarray.Region)(t$155932));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$154462).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$154462).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$154462).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$154462).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$154462).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155959 = ((x10.regionarray.Array<x10.core.Boolean>)alloc$154462).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$155960 = ((x10.regionarray.Array<x10.core.Boolean>)alloc$154462).layout_stride1 = t$155959;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$154462).layout_min0 = t$155960;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$154462).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$155961 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Boolean>(x10.rtt.Types.BOOLEAN, r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$154462).raw = ((x10.core.Rail)(t$155961));
            
            //#line 109 "x10/regionarray/PolyScanner.x10"
            this.parFlags = ((x10.regionarray.Array)(alloc$154462));
        }
        return this;
    }
    
    
    
    //#line 112 "x10/regionarray/PolyScanner.x10"
    private void init() {
        
        //#line 113 "x10/regionarray/PolyScanner.x10"
        x10.regionarray.PolyMat pm = this.C;
        
        //#line 114 "x10/regionarray/PolyScanner.x10"
        final long t$155419 = this.rank;
        
        //#line 114 "x10/regionarray/PolyScanner.x10"
        final int t$155420 = ((int)(long)(((long)(t$155419))));
        
        //#line 114 "x10/regionarray/PolyScanner.x10"
        final int t$155422 = ((t$155420) - (((int)(1))));
        
        //#line 114 "x10/regionarray/PolyScanner.x10"
        this.init(((x10.regionarray.PolyMat)(pm)), (int)(t$155422));
        
        //#line 115 "x10/regionarray/PolyScanner.x10"
        final long t$155970 = this.rank;
        
        //#line 115 "x10/regionarray/PolyScanner.x10"
        final int t$155971 = ((int)(long)(((long)(t$155970))));
        
        //#line 115 "x10/regionarray/PolyScanner.x10"
        int k$155972 = ((t$155971) - (((int)(2))));
        
        //#line 115 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 115 "x10/regionarray/PolyScanner.x10"
            final boolean t$155974 = ((k$155972) >= (((int)(0))));
            
            //#line 115 "x10/regionarray/PolyScanner.x10"
            if (!(t$155974)) {
                
                //#line 115 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 116 "x10/regionarray/PolyScanner.x10"
            final int t$155964 = ((k$155972) + (((int)(1))));
            
            //#line 116 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyMat t$155965 = ((x10.regionarray.PolyMat)(pm.eliminate((int)(t$155964), (boolean)(true))));
            
            //#line 116 "x10/regionarray/PolyScanner.x10"
            pm = ((x10.regionarray.PolyMat)(t$155965));
            
            //#line 117 "x10/regionarray/PolyScanner.x10"
            this.init(((x10.regionarray.PolyMat)(pm)), (int)(k$155972));
            
            //#line 115 "x10/regionarray/PolyScanner.x10"
            final int t$155969 = ((k$155972) - (((int)(1))));
            
            //#line 115 "x10/regionarray/PolyScanner.x10"
            k$155972 = t$155969;
        }
    }
    
    public static void init$P(final x10.regionarray.PolyScanner PolyScanner) {
        PolyScanner.init();
    }
    
    
    //#line 121 "x10/regionarray/PolyScanner.x10"
    final private void init(final x10.regionarray.PolyMat pm, final int axis) {
        
        //#line 126 "x10/regionarray/PolyScanner.x10"
        int imin = 0;
        
        //#line 127 "x10/regionarray/PolyScanner.x10"
        int imax = 0;
        
        //#line 128 "x10/regionarray/PolyScanner.x10"
        final x10.lang.Iterator r$156071 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)pm).iterator();
        
        //#line 128 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 128 "x10/regionarray/PolyScanner.x10"
            final boolean t$156072 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$156071).hasNext$O();
            
            //#line 128 "x10/regionarray/PolyScanner.x10"
            if (!(t$156072)) {
                
                //#line 128 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 128 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyRow r$155975 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$156071).next$G();
            
            //#line 129 "x10/regionarray/PolyScanner.x10"
            final int t$155976 = r$155975.$apply$O((int)(axis));
            
            //#line 129 "x10/regionarray/PolyScanner.x10"
            final boolean t$155977 = ((t$155976) < (((int)(0))));
            
            //#line 129 "x10/regionarray/PolyScanner.x10"
            if (t$155977) {
                
                //#line 129 "x10/regionarray/PolyScanner.x10"
                final int t$155979 = ((imin) + (((int)(1))));
                
                //#line 129 "x10/regionarray/PolyScanner.x10"
                imin = t$155979;
            }
            
            //#line 130 "x10/regionarray/PolyScanner.x10"
            final int t$155980 = r$155975.$apply$O((int)(axis));
            
            //#line 130 "x10/regionarray/PolyScanner.x10"
            final boolean t$155981 = ((t$155980) > (((int)(0))));
            
            //#line 130 "x10/regionarray/PolyScanner.x10"
            if (t$155981) {
                
                //#line 130 "x10/regionarray/PolyScanner.x10"
                final int t$155983 = ((imax) + (((int)(1))));
                
                //#line 130 "x10/regionarray/PolyScanner.x10"
                imax = t$155983;
            }
        }
        
        //#line 134 "x10/regionarray/PolyScanner.x10"
        boolean t$155448 = ((int) imin) == ((int) 0);
        
        //#line 134 "x10/regionarray/PolyScanner.x10"
        if (!(t$155448)) {
            
            //#line 134 "x10/regionarray/PolyScanner.x10"
            t$155448 = ((int) imax) == ((int) 0);
        }
        
        //#line 134 "x10/regionarray/PolyScanner.x10"
        if (t$155448) {
            
            //#line 135 "x10/regionarray/PolyScanner.x10"
            final boolean t$155450 = ((int) imin) == ((int) 0);
            
            //#line 135 "x10/regionarray/PolyScanner.x10"
            java.lang.String t$155451 =  null;
            
            //#line 135 "x10/regionarray/PolyScanner.x10"
            if (t$155450) {
                
                //#line 135 "x10/regionarray/PolyScanner.x10"
                t$155451 = "minimum";
            } else {
                
                //#line 135 "x10/regionarray/PolyScanner.x10"
                t$155451 = "maximum";
            }
            
            //#line 136 "x10/regionarray/PolyScanner.x10"
            final java.lang.String t$155452 = (("axis ") + ((x10.core.Int.$box(axis))));
            
            //#line 136 "x10/regionarray/PolyScanner.x10"
            final java.lang.String t$155453 = ((t$155452) + (" has no "));
            
            //#line 136 "x10/regionarray/PolyScanner.x10"
            final java.lang.String msg = ((t$155453) + (t$155451));
            
            //#line 137 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.UnboundedRegionException t$155454 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)(msg)))));
            
            //#line 137 "x10/regionarray/PolyScanner.x10"
            throw t$155454;
        }
        
        //#line 141 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array this$155222 = ((x10.regionarray.Array)(this.myMin));
        
        //#line 141 "x10/regionarray/PolyScanner.x10"
        final long i$155220 = ((long)(((int)(axis))));
        
        //#line 141 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.VarMat alloc$154463 = ((x10.regionarray.VarMat)(new x10.regionarray.VarMat((java.lang.System[]) null)));
        
        //#line 141 "x10/regionarray/PolyScanner.x10"
        final int t$156074 = ((axis) + (((int)(1))));
        
        //#line 141 "x10/regionarray/PolyScanner.x10"
        alloc$154463.x10$regionarray$VarMat$$init$S(imin, t$156074);
        
        //#line 547 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156075 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$155222).raw));
        
        //#line 547 . "x10/regionarray/Array.x10"
        ((x10.regionarray.VarMat[])t$156075.value)[(int)i$155220] = alloc$154463;
        
        //#line 142 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array this$155226 = ((x10.regionarray.Array)(this.myMax));
        
        //#line 142 "x10/regionarray/PolyScanner.x10"
        final long i$155224 = ((long)(((int)(axis))));
        
        //#line 142 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.VarMat alloc$154464 = ((x10.regionarray.VarMat)(new x10.regionarray.VarMat((java.lang.System[]) null)));
        
        //#line 142 "x10/regionarray/PolyScanner.x10"
        final int t$156077 = ((axis) + (((int)(1))));
        
        //#line 142 "x10/regionarray/PolyScanner.x10"
        alloc$154464.x10$regionarray$VarMat$$init$S(imax, t$156077);
        
        //#line 547 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156078 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$155226).raw));
        
        //#line 547 . "x10/regionarray/Array.x10"
        ((x10.regionarray.VarMat[])t$156078.value)[(int)i$155224] = alloc$154464;
        
        //#line 143 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array this$155230 = ((x10.regionarray.Array)(this.minSum));
        
        //#line 143 "x10/regionarray/PolyScanner.x10"
        final long i$155228 = ((long)(((int)(axis))));
        
        //#line 143 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.VarMat alloc$154465 = ((x10.regionarray.VarMat)(new x10.regionarray.VarMat((java.lang.System[]) null)));
        
        //#line 143 "x10/regionarray/PolyScanner.x10"
        final int t$156080 = ((axis) + (((int)(1))));
        
        //#line 143 "x10/regionarray/PolyScanner.x10"
        alloc$154465.x10$regionarray$VarMat$$init$S(imin, t$156080);
        
        //#line 547 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156081 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$155230).raw));
        
        //#line 547 . "x10/regionarray/Array.x10"
        ((x10.regionarray.VarMat[])t$156081.value)[(int)i$155228] = alloc$154465;
        
        //#line 144 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array this$155234 = ((x10.regionarray.Array)(this.maxSum));
        
        //#line 144 "x10/regionarray/PolyScanner.x10"
        final long i$155232 = ((long)(((int)(axis))));
        
        //#line 144 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.VarMat alloc$154466 = ((x10.regionarray.VarMat)(new x10.regionarray.VarMat((java.lang.System[]) null)));
        
        //#line 144 "x10/regionarray/PolyScanner.x10"
        final int t$156083 = ((axis) + (((int)(1))));
        
        //#line 144 "x10/regionarray/PolyScanner.x10"
        alloc$154466.x10$regionarray$VarMat$$init$S(imax, t$156083);
        
        //#line 547 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156084 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$155234).raw));
        
        //#line 547 . "x10/regionarray/Array.x10"
        ((x10.regionarray.VarMat[])t$156084.value)[(int)i$155232] = alloc$154466;
        
        //#line 145 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array this$155242 = ((x10.regionarray.Array)(this.min2));
        
        //#line 145 "x10/regionarray/PolyScanner.x10"
        final long i$155240 = ((long)(((int)(axis))));
        
        //#line 145 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array alloc$154467 = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.PolyRow>((java.lang.System[]) null, x10.regionarray.PolyRow.$RTT)));
        
        //#line 145 "x10/regionarray/PolyScanner.x10"
        final long size$155236 = ((long)(((int)(imin))));
        
        //#line 270 . "x10/regionarray/Array.x10"
        final x10.regionarray.RectRegion1D myReg$156085 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 270 . "x10/regionarray/Array.x10"
        final long t$155984 = ((size$155236) - (((long)(1L))));
        
        //#line 270 . "x10/regionarray/Array.x10"
        myReg$156085.x10$regionarray$RectRegion1D$$init$S(t$155984);
        
        //#line 271 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$155985 = ((x10.regionarray.Region)
                                                  myReg$156085);
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154467).region = ((x10.regionarray.Region)(t$155985));
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154467).rank = 1L;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154467).rect = true;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154467).zeroBased = true;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154467).rail = true;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154467).size = size$155236;
        
        //#line 273 . "x10/regionarray/Array.x10"
        final long t$156086 = ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154467).layout_min1 = 0L;
        
        //#line 273 . "x10/regionarray/Array.x10"
        final long t$156087 = ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154467).layout_stride1 = t$156086;
        
        //#line 273 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154467).layout_min0 = t$156087;
        
        //#line 274 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154467).layout = null;
        
        //#line 275 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156088 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.PolyRow>(x10.regionarray.PolyRow.$RTT, ((long)(size$155236)))));
        
        //#line 275 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154467).raw = ((x10.core.Rail)(t$156088));
        
        //#line 547 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156089 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)this$155242).raw));
        
        //#line 547 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array[])t$156089.value)[(int)i$155240] = alloc$154467;
        
        //#line 146 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array this$155250 = ((x10.regionarray.Array)(this.max2));
        
        //#line 146 "x10/regionarray/PolyScanner.x10"
        final long i$155248 = ((long)(((int)(axis))));
        
        //#line 146 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array alloc$154468 = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.PolyRow>((java.lang.System[]) null, x10.regionarray.PolyRow.$RTT)));
        
        //#line 146 "x10/regionarray/PolyScanner.x10"
        final long size$155244 = ((long)(((int)(imax))));
        
        //#line 270 . "x10/regionarray/Array.x10"
        final x10.regionarray.RectRegion1D myReg$156090 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 270 . "x10/regionarray/Array.x10"
        final long t$155986 = ((size$155244) - (((long)(1L))));
        
        //#line 270 . "x10/regionarray/Array.x10"
        myReg$156090.x10$regionarray$RectRegion1D$$init$S(t$155986);
        
        //#line 271 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$155987 = ((x10.regionarray.Region)
                                                  myReg$156090);
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154468).region = ((x10.regionarray.Region)(t$155987));
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154468).rank = 1L;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154468).rect = true;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154468).zeroBased = true;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154468).rail = true;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154468).size = size$155244;
        
        //#line 273 . "x10/regionarray/Array.x10"
        final long t$156091 = ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154468).layout_min1 = 0L;
        
        //#line 273 . "x10/regionarray/Array.x10"
        final long t$156092 = ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154468).layout_stride1 = t$156091;
        
        //#line 273 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154468).layout_min0 = t$156092;
        
        //#line 274 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154468).layout = null;
        
        //#line 275 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156093 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.PolyRow>(x10.regionarray.PolyRow.$RTT, ((long)(size$155244)))));
        
        //#line 275 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$154468).raw = ((x10.core.Rail)(t$156093));
        
        //#line 547 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156094 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)this$155250).raw));
        
        //#line 547 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array[])t$156094.value)[(int)i$155248] = alloc$154468;
        
        //#line 149 "x10/regionarray/PolyScanner.x10"
        imin = 0;
        
        //#line 149 "x10/regionarray/PolyScanner.x10"
        imax = 0;
        
        //#line 150 "x10/regionarray/PolyScanner.x10"
        final x10.lang.Iterator r$156095 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)pm).iterator();
        
        //#line 150 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 150 "x10/regionarray/PolyScanner.x10"
            final boolean t$156096 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$156095).hasNext$O();
            
            //#line 150 "x10/regionarray/PolyScanner.x10"
            if (!(t$156096)) {
                
                //#line 150 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 150 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyRow r$156030 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$156095).next$G();
            
            //#line 151 "x10/regionarray/PolyScanner.x10"
            final int t$156031 = r$156030.$apply$O((int)(axis));
            
            //#line 151 "x10/regionarray/PolyScanner.x10"
            final boolean t$156032 = ((t$156031) < (((int)(0))));
            
            //#line 151 "x10/regionarray/PolyScanner.x10"
            if (t$156032) {
                
                //#line 152 "x10/regionarray/PolyScanner.x10"
                int i$156001 = 0;
                
                //#line 152 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 152 "x10/regionarray/PolyScanner.x10"
                    final boolean t$156003 = ((i$156001) <= (((int)(axis))));
                    
                    //#line 152 "x10/regionarray/PolyScanner.x10"
                    if (!(t$156003)) {
                        
                        //#line 152 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 153 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$155990 = ((x10.regionarray.Array)(this.myMin));
                    
                    //#line 153 "x10/regionarray/PolyScanner.x10"
                    final long i$155991 = ((long)(((int)(axis))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$155992 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$155988 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$155990).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$155989 = ((x10.regionarray.VarMat[])t$155988.value)[(int)i$155991];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$155992 = t$155989;
                    
                    //#line 153 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$155995 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$155992).$apply$G((int)(imin));
                    
                    //#line 153 "x10/regionarray/PolyScanner.x10"
                    final int t$155998 = r$156030.$apply$O((int)(i$156001));
                    
                    //#line 153 "x10/regionarray/PolyScanner.x10"
                    t$155995.$set$O((int)(i$156001), (int)(t$155998));
                    
                    //#line 152 "x10/regionarray/PolyScanner.x10"
                    final int t$156000 = ((i$156001) + (((int)(1))));
                    
                    //#line 152 "x10/regionarray/PolyScanner.x10"
                    i$156001 = t$156000;
                }
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156033 = ((x10.regionarray.Array)(this.minSum));
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                final long i$156034 = ((long)(((int)(axis))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156035 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156004 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156033).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156005 = ((x10.regionarray.VarMat[])t$156004.value)[(int)i$156034];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156035 = t$156005;
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156038 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156035).$apply$G((int)(imin));
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                final long t$156039 = this.rank;
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                final int t$156040 = ((int)(long)(((long)(t$156039))));
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                final int t$156041 = r$156030.$apply$O((int)(t$156040));
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                t$156038.$set$O((int)(0), (int)(t$156041));
                
                //#line 155 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156042 = ((x10.regionarray.Array)(this.min2));
                
                //#line 155 "x10/regionarray/PolyScanner.x10"
                final long i$156043 = ((long)(((int)(axis))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.Array ret$156044 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156006 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)this$156042).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.Array t$156007 = ((x10.regionarray.Array)(((x10.regionarray.Array[])t$156006.value)[(int)i$156043]));
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156044 = ((x10.regionarray.Array)(t$156007));
                
                //#line 155 "x10/regionarray/PolyScanner.x10"
                final long i$156047 = ((long)(((int)(imin))));
                
                //#line 547 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156008 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.PolyRow>)ret$156044).raw));
                
                //#line 547 . "x10/regionarray/Array.x10"
                ((x10.regionarray.PolyRow[])t$156008.value)[(int)i$156047] = r$156030;
                
                //#line 156 "x10/regionarray/PolyScanner.x10"
                final int t$156050 = ((imin) + (((int)(1))));
                
                //#line 156 "x10/regionarray/PolyScanner.x10"
                imin = t$156050;
            }
            
            //#line 158 "x10/regionarray/PolyScanner.x10"
            final int t$156051 = r$156030.$apply$O((int)(axis));
            
            //#line 158 "x10/regionarray/PolyScanner.x10"
            final boolean t$156052 = ((t$156051) > (((int)(0))));
            
            //#line 158 "x10/regionarray/PolyScanner.x10"
            if (t$156052) {
                
                //#line 159 "x10/regionarray/PolyScanner.x10"
                int i$156022 = 0;
                
                //#line 159 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 159 "x10/regionarray/PolyScanner.x10"
                    final boolean t$156024 = ((i$156022) <= (((int)(axis))));
                    
                    //#line 159 "x10/regionarray/PolyScanner.x10"
                    if (!(t$156024)) {
                        
                        //#line 159 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 160 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$156011 = ((x10.regionarray.Array)(this.myMax));
                    
                    //#line 160 "x10/regionarray/PolyScanner.x10"
                    final long i$156012 = ((long)(((int)(axis))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$156013 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$156009 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156011).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$156010 = ((x10.regionarray.VarMat[])t$156009.value)[(int)i$156012];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$156013 = t$156010;
                    
                    //#line 160 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$156016 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156013).$apply$G((int)(imax));
                    
                    //#line 160 "x10/regionarray/PolyScanner.x10"
                    final int t$156019 = r$156030.$apply$O((int)(i$156022));
                    
                    //#line 160 "x10/regionarray/PolyScanner.x10"
                    t$156016.$set$O((int)(i$156022), (int)(t$156019));
                    
                    //#line 159 "x10/regionarray/PolyScanner.x10"
                    final int t$156021 = ((i$156022) + (((int)(1))));
                    
                    //#line 159 "x10/regionarray/PolyScanner.x10"
                    i$156022 = t$156021;
                }
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156053 = ((x10.regionarray.Array)(this.maxSum));
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                final long i$156054 = ((long)(((int)(axis))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156055 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156025 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156053).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156026 = ((x10.regionarray.VarMat[])t$156025.value)[(int)i$156054];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156055 = t$156026;
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156058 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156055).$apply$G((int)(imax));
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                final long t$156059 = this.rank;
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                final int t$156060 = ((int)(long)(((long)(t$156059))));
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                final int t$156061 = r$156030.$apply$O((int)(t$156060));
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                t$156058.$set$O((int)(0), (int)(t$156061));
                
                //#line 162 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156062 = ((x10.regionarray.Array)(this.max2));
                
                //#line 162 "x10/regionarray/PolyScanner.x10"
                final long i$156063 = ((long)(((int)(axis))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.Array ret$156064 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156027 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)this$156062).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.Array t$156028 = ((x10.regionarray.Array)(((x10.regionarray.Array[])t$156027.value)[(int)i$156063]));
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156064 = ((x10.regionarray.Array)(t$156028));
                
                //#line 162 "x10/regionarray/PolyScanner.x10"
                final long i$156067 = ((long)(((int)(imax))));
                
                //#line 547 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156029 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.PolyRow>)ret$156064).raw));
                
                //#line 547 . "x10/regionarray/Array.x10"
                ((x10.regionarray.PolyRow[])t$156029.value)[(int)i$156067] = r$156030;
                
                //#line 163 "x10/regionarray/PolyScanner.x10"
                final int t$156070 = ((imax) + (((int)(1))));
                
                //#line 163 "x10/regionarray/PolyScanner.x10"
                imax = t$156070;
            }
        }
    }
    
    final public static void init$P(final x10.regionarray.PolyMat pm, final int axis, final x10.regionarray.PolyScanner PolyScanner) {
        PolyScanner.init(((x10.regionarray.PolyMat)(pm)), (int)(axis));
    }
    
    
    //#line 177 "x10/regionarray/PolyScanner.x10"
    final public void $set(final int v, final int axis) {
        
        //#line 177 "x10/regionarray/PolyScanner.x10"
        this.set((int)(axis), (int)(v));
    }
    
    
    //#line 179 "x10/regionarray/PolyScanner.x10"
    final public void set(final int axis, final int v) {
        
        //#line 180 "x10/regionarray/PolyScanner.x10"
        int k$156191 = ((axis) + (((int)(1))));
        
        //#line 180 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 180 "x10/regionarray/PolyScanner.x10"
            final long t$156193 = ((long)(((int)(k$156191))));
            
            //#line 180 "x10/regionarray/PolyScanner.x10"
            final long t$156194 = this.rank;
            
            //#line 180 "x10/regionarray/PolyScanner.x10"
            final boolean t$156195 = ((t$156193) < (((long)(t$156194))));
            
            //#line 180 "x10/regionarray/PolyScanner.x10"
            if (!(t$156195)) {
                
                //#line 180 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 181 "x10/regionarray/PolyScanner.x10"
            int l$156133 = 0;
            
            //#line 181 "x10/regionarray/PolyScanner.x10"
            for (;
                 true;
                 ) {
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156135 = ((x10.regionarray.Array)(this.minSum));
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                final long i$156137 = ((long)(((int)(k$156191))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156138 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156103 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156135).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156104 = ((x10.regionarray.VarMat[])t$156103.value)[(int)i$156137];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156138 = t$156104;
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                final int t$156140 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156138).rows;
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                final boolean t$156141 = ((l$156133) < (((int)(t$156140))));
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                if (!(t$156141)) {
                    
                    //#line 181 "x10/regionarray/PolyScanner.x10"
                    break;
                }
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156105 = ((x10.regionarray.Array)(this.minSum));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final long i$156107 = ((long)(((int)(k$156191))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156108 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156097 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156105).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156098 = ((x10.regionarray.VarMat[])t$156097.value)[(int)i$156107];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156108 = t$156098;
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156111 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156108).$apply$G((int)(l$156133));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final int t$156112 = ((axis) + (((int)(1))));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156113 = ((x10.regionarray.Array)(this.myMin));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final long i$156115 = ((long)(((int)(k$156191))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156116 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156099 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156113).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156100 = ((x10.regionarray.VarMat[])t$156099.value)[(int)i$156115];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156116 = t$156100;
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156119 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156116).$apply$G((int)(l$156133));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final int t$156120 = t$156119.$apply$O((int)(axis));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final int t$156121 = ((t$156120) * (((int)(v))));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156122 = ((x10.regionarray.Array)(this.minSum));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final long i$156124 = ((long)(((int)(k$156191))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156125 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156101 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156122).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156102 = ((x10.regionarray.VarMat[])t$156101.value)[(int)i$156124];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156125 = t$156102;
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156128 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156125).$apply$G((int)(l$156133));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final int t$156129 = t$156128.$apply$O((int)(axis));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final int t$156130 = ((t$156121) + (((int)(t$156129))));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                t$156111.$set$O((int)(t$156112), (int)(t$156130));
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                final int t$156132 = ((l$156133) + (((int)(1))));
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                l$156133 = t$156132;
            }
            
            //#line 180 "x10/regionarray/PolyScanner.x10"
            final int t$156143 = ((k$156191) + (((int)(1))));
            
            //#line 180 "x10/regionarray/PolyScanner.x10"
            k$156191 = t$156143;
        }
        
        //#line 183 "x10/regionarray/PolyScanner.x10"
        int k$156196 = ((axis) + (((int)(1))));
        
        //#line 183 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 183 "x10/regionarray/PolyScanner.x10"
            final long t$156198 = ((long)(((int)(k$156196))));
            
            //#line 183 "x10/regionarray/PolyScanner.x10"
            final long t$156199 = this.rank;
            
            //#line 183 "x10/regionarray/PolyScanner.x10"
            final boolean t$156200 = ((t$156198) < (((long)(t$156199))));
            
            //#line 183 "x10/regionarray/PolyScanner.x10"
            if (!(t$156200)) {
                
                //#line 183 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 184 "x10/regionarray/PolyScanner.x10"
            int l$156180 = 0;
            
            //#line 184 "x10/regionarray/PolyScanner.x10"
            for (;
                 true;
                 ) {
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156182 = ((x10.regionarray.Array)(this.maxSum));
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                final long i$156184 = ((long)(((int)(k$156196))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156185 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156150 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156182).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156151 = ((x10.regionarray.VarMat[])t$156150.value)[(int)i$156184];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156185 = t$156151;
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                final int t$156187 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156185).rows;
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                final boolean t$156188 = ((l$156180) < (((int)(t$156187))));
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                if (!(t$156188)) {
                    
                    //#line 184 "x10/regionarray/PolyScanner.x10"
                    break;
                }
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156152 = ((x10.regionarray.Array)(this.maxSum));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final long i$156154 = ((long)(((int)(k$156196))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156155 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156144 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156152).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156145 = ((x10.regionarray.VarMat[])t$156144.value)[(int)i$156154];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156155 = t$156145;
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156158 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156155).$apply$G((int)(l$156180));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final int t$156159 = ((axis) + (((int)(1))));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156160 = ((x10.regionarray.Array)(this.myMax));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final long i$156162 = ((long)(((int)(k$156196))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156163 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156146 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156160).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156147 = ((x10.regionarray.VarMat[])t$156146.value)[(int)i$156162];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156163 = t$156147;
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156166 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156163).$apply$G((int)(l$156180));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final int t$156167 = t$156166.$apply$O((int)(axis));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final int t$156168 = ((t$156167) * (((int)(v))));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156169 = ((x10.regionarray.Array)(this.maxSum));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final long i$156171 = ((long)(((int)(k$156196))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156172 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156148 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156169).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156149 = ((x10.regionarray.VarMat[])t$156148.value)[(int)i$156171];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156172 = t$156149;
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156175 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156172).$apply$G((int)(l$156180));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final int t$156176 = t$156175.$apply$O((int)(axis));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final int t$156177 = ((t$156168) + (((int)(t$156176))));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                t$156158.$set$O((int)(t$156159), (int)(t$156177));
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                final int t$156179 = ((l$156180) + (((int)(1))));
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                l$156180 = t$156179;
            }
            
            //#line 183 "x10/regionarray/PolyScanner.x10"
            final int t$156190 = ((k$156196) + (((int)(1))));
            
            //#line 183 "x10/regionarray/PolyScanner.x10"
            k$156196 = t$156190;
        }
    }
    
    
    //#line 188 "x10/regionarray/PolyScanner.x10"
    final public int min$O(final int axis) {
        
        //#line 189 "x10/regionarray/PolyScanner.x10"
        int result = java.lang.Integer.MIN_VALUE;
        
        //#line 190 "x10/regionarray/PolyScanner.x10"
        int k$156235 = 0;
        
        //#line 190 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array this$156237 = ((x10.regionarray.Array)(this.myMin));
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            final long i$156238 = ((long)(((int)(axis))));
            
            //#line 442 . "x10/regionarray/Array.x10"
            x10.regionarray.VarMat ret$156239 =  null;
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156205 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156237).raw));
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.regionarray.VarMat t$156206 = ((x10.regionarray.VarMat[])t$156205.value)[(int)i$156238];
            
            //#line 446 . "x10/regionarray/Array.x10"
            ret$156239 = t$156206;
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            final int t$156241 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156239).rows;
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            final boolean t$156242 = ((k$156235) < (((int)(t$156241))));
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            if (!(t$156242)) {
                
                //#line 190 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 191 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array this$156207 = ((x10.regionarray.Array)(this.myMin));
            
            //#line 191 "x10/regionarray/PolyScanner.x10"
            final long i$156208 = ((long)(((int)(axis))));
            
            //#line 442 . "x10/regionarray/Array.x10"
            x10.regionarray.VarMat ret$156209 =  null;
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156201 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156207).raw));
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.regionarray.VarMat t$156202 = ((x10.regionarray.VarMat[])t$156201.value)[(int)i$156208];
            
            //#line 446 . "x10/regionarray/Array.x10"
            ret$156209 = t$156202;
            
            //#line 191 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.VarRow t$156212 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156209).$apply$G((int)(k$156235));
            
            //#line 191 "x10/regionarray/PolyScanner.x10"
            final int a$156213 = t$156212.$apply$O((int)(axis));
            
            //#line 192 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array this$156214 = ((x10.regionarray.Array)(this.minSum));
            
            //#line 192 "x10/regionarray/PolyScanner.x10"
            final long i$156215 = ((long)(((int)(axis))));
            
            //#line 442 . "x10/regionarray/Array.x10"
            x10.regionarray.VarMat ret$156216 =  null;
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156203 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156214).raw));
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.regionarray.VarMat t$156204 = ((x10.regionarray.VarMat[])t$156203.value)[(int)i$156215];
            
            //#line 446 . "x10/regionarray/Array.x10"
            ret$156216 = t$156204;
            
            //#line 192 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.VarRow t$156219 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156216).$apply$G((int)(k$156235));
            
            //#line 192 "x10/regionarray/PolyScanner.x10"
            int b$156220 = t$156219.$apply$O((int)(axis));
            
            //#line 194 "x10/regionarray/PolyScanner.x10"
            final boolean t$156222 = ((b$156220) > (((int)(0))));
            
            //#line 194 "x10/regionarray/PolyScanner.x10"
            int t$156223 =  0;
            
            //#line 194 "x10/regionarray/PolyScanner.x10"
            if (t$156222) {
                
                //#line 194 "x10/regionarray/PolyScanner.x10"
                final int t$156225 = (-(b$156220));
                
                //#line 194 "x10/regionarray/PolyScanner.x10"
                final int t$156226 = ((t$156225) + (((int)(a$156213))));
                
                //#line 194 "x10/regionarray/PolyScanner.x10"
                final int t$156227 = ((t$156226) + (((int)(1))));
                
                //#line 194 "x10/regionarray/PolyScanner.x10"
                t$156223 = ((t$156227) / (((int)(a$156213))));
            } else {
                
                //#line 194 "x10/regionarray/PolyScanner.x10"
                final int t$156229 = (-(b$156220));
                
                //#line 194 "x10/regionarray/PolyScanner.x10"
                t$156223 = ((t$156229) / (((int)(a$156213))));
            }
            
            //#line 195 "x10/regionarray/PolyScanner.x10"
            final boolean t$156232 = ((t$156223) > (((int)(result))));
            
            //#line 195 "x10/regionarray/PolyScanner.x10"
            if (t$156232) {
                
                //#line 195 "x10/regionarray/PolyScanner.x10"
                result = t$156223;
            }
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            final int t$156234 = ((k$156235) + (((int)(1))));
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            k$156235 = t$156234;
        }
        
        //#line 197 "x10/regionarray/PolyScanner.x10"
        return result;
    }
    
    
    //#line 200 "x10/regionarray/PolyScanner.x10"
    final public int max$O(final int axis) {
        
        //#line 201 "x10/regionarray/PolyScanner.x10"
        int result = java.lang.Integer.MAX_VALUE;
        
        //#line 202 "x10/regionarray/PolyScanner.x10"
        int k$156274 = 0;
        
        //#line 202 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array this$156276 = ((x10.regionarray.Array)(this.myMax));
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            final long i$156277 = ((long)(((int)(axis))));
            
            //#line 442 . "x10/regionarray/Array.x10"
            x10.regionarray.VarMat ret$156278 =  null;
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156247 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156276).raw));
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.regionarray.VarMat t$156248 = ((x10.regionarray.VarMat[])t$156247.value)[(int)i$156277];
            
            //#line 446 . "x10/regionarray/Array.x10"
            ret$156278 = t$156248;
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            final int t$156280 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156278).rows;
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            final boolean t$156281 = ((k$156274) < (((int)(t$156280))));
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            if (!(t$156281)) {
                
                //#line 202 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 203 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array this$156249 = ((x10.regionarray.Array)(this.myMax));
            
            //#line 203 "x10/regionarray/PolyScanner.x10"
            final long i$156250 = ((long)(((int)(axis))));
            
            //#line 442 . "x10/regionarray/Array.x10"
            x10.regionarray.VarMat ret$156251 =  null;
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156243 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156249).raw));
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.regionarray.VarMat t$156244 = ((x10.regionarray.VarMat[])t$156243.value)[(int)i$156250];
            
            //#line 446 . "x10/regionarray/Array.x10"
            ret$156251 = t$156244;
            
            //#line 203 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.VarRow t$156254 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156251).$apply$G((int)(k$156274));
            
            //#line 203 "x10/regionarray/PolyScanner.x10"
            final int a$156255 = t$156254.$apply$O((int)(axis));
            
            //#line 204 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array this$156256 = ((x10.regionarray.Array)(this.maxSum));
            
            //#line 204 "x10/regionarray/PolyScanner.x10"
            final long i$156257 = ((long)(((int)(axis))));
            
            //#line 442 . "x10/regionarray/Array.x10"
            x10.regionarray.VarMat ret$156258 =  null;
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156245 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156256).raw));
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.regionarray.VarMat t$156246 = ((x10.regionarray.VarMat[])t$156245.value)[(int)i$156257];
            
            //#line 446 . "x10/regionarray/Array.x10"
            ret$156258 = t$156246;
            
            //#line 204 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.VarRow t$156261 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156258).$apply$G((int)(k$156274));
            
            //#line 204 "x10/regionarray/PolyScanner.x10"
            final int b$156262 = t$156261.$apply$O((int)(axis));
            
            //#line 206 "x10/regionarray/PolyScanner.x10"
            final boolean t$156263 = ((b$156262) > (((int)(0))));
            
            //#line 206 "x10/regionarray/PolyScanner.x10"
            int t$156264 =  0;
            
            //#line 206 "x10/regionarray/PolyScanner.x10"
            if (t$156263) {
                
                //#line 206 "x10/regionarray/PolyScanner.x10"
                final int t$156265 = (-(b$156262));
                
                //#line 206 "x10/regionarray/PolyScanner.x10"
                final int t$156266 = ((t$156265) - (((int)(a$156255))));
                
                //#line 206 "x10/regionarray/PolyScanner.x10"
                final int t$156267 = ((t$156266) + (((int)(1))));
                
                //#line 206 "x10/regionarray/PolyScanner.x10"
                t$156264 = ((t$156267) / (((int)(a$156255))));
            } else {
                
                //#line 206 "x10/regionarray/PolyScanner.x10"
                final int t$156268 = (-(b$156262));
                
                //#line 206 "x10/regionarray/PolyScanner.x10"
                t$156264 = ((t$156268) / (((int)(a$156255))));
            }
            
            //#line 207 "x10/regionarray/PolyScanner.x10"
            final boolean t$156271 = ((t$156264) < (((int)(result))));
            
            //#line 207 "x10/regionarray/PolyScanner.x10"
            if (t$156271) {
                
                //#line 207 "x10/regionarray/PolyScanner.x10"
                result = t$156264;
            }
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            final int t$156273 = ((k$156274) + (((int)(1))));
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            k$156274 = t$156273;
        }
        
        //#line 209 "x10/regionarray/PolyScanner.x10"
        return result;
    }
    
    
    //#line 229 "x10/regionarray/PolyScanner.x10"
    /**
     * odometer-style iterator for this scanner
     *
     * advance() computes the k that is the axis to be bumped:
     *
     * axis    0    1         k        k+1
     * now   x[0] x[1] ...  x[k]   max[k+1] ...  max[rank-1]
     * next  x[0] x[1] ...  x[k]+1 min[k+1] ...  min[rank-1]
     *
     * i.e. bump k, reset k+1 through rank-1
     * finished if k<0
     *
     * next() does the bumping and resetting
     *
     * assumes no degenerate axes, which is guaranteeed by Scanner API
     */
    @x10.runtime.impl.java.X10Generated
    final public static class RailIt extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<RailIt> $RTT = 
            x10.rtt.NamedType.<RailIt> make("x10.regionarray.PolyScanner.RailIt",
                                            RailIt.class,
                                            new x10.rtt.Type[] {
                                                x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, x10.rtt.Types.INT))
                                            });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyScanner.RailIt $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.doesHaveNext = $deserializer.readBoolean();
            $_obj.k = $deserializer.readInt();
            $_obj.myMax = $deserializer.readObject();
            $_obj.myMin = $deserializer.readObject();
            $_obj.out$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.s = $deserializer.readObject();
            $_obj.x = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyScanner.RailIt $_obj = new x10.regionarray.PolyScanner.RailIt((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.doesHaveNext);
            $serializer.write(this.k);
            $serializer.write(this.myMax);
            $serializer.write(this.myMin);
            $serializer.write(this.out$);
            $serializer.write(this.rank);
            $serializer.write(this.s);
            $serializer.write(this.x);
            
        }
        
        // constructor just for allocation
        public RailIt(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        final public x10.core.Rail next$G() {
            return next();
        }
        
        
    
        
        //#line 68 "x10/regionarray/PolyScanner.x10"
        public x10.regionarray.PolyScanner out$;
        
        //#line 230 "x10/regionarray/PolyScanner.x10"
        public long rank;
        
        //#line 231 "x10/regionarray/PolyScanner.x10"
        public x10.regionarray.PolyScanner s;
        
        //#line 233 "x10/regionarray/PolyScanner.x10"
        public x10.core.Rail<x10.core.Int> x;
        
        //#line 234 "x10/regionarray/PolyScanner.x10"
        public x10.core.Rail<x10.core.Int> myMin;
        
        //#line 235 "x10/regionarray/PolyScanner.x10"
        public x10.core.Rail<x10.core.Int> myMax;
        
        //#line 237 "x10/regionarray/PolyScanner.x10"
        public int k;
        
        //#line 238 "x10/regionarray/PolyScanner.x10"
        public boolean doesHaveNext;
        
        
        //#line 239 "x10/regionarray/PolyScanner.x10"
        // creation method for java code (1-phase java constructor)
        public RailIt(final x10.regionarray.PolyScanner out$) {
            this((java.lang.System[]) null);
            x10$regionarray$PolyScanner$RailIt$$init$S(out$);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.PolyScanner.RailIt x10$regionarray$PolyScanner$RailIt$$init$S(final x10.regionarray.PolyScanner out$) {
             {
                
                //#line 68 "x10/regionarray/PolyScanner.x10"
                this.out$ = out$;
                
                //#line 239 "x10/regionarray/PolyScanner.x10"
                
                
                //#line 229 "x10/regionarray/PolyScanner.x10"
                this.__fieldInitializers_x10_regionarray_PolyScanner_RailIt();
                
                //#line 240 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$155682 = ((x10.core.Rail)(this.myMin));
                
                //#line 240 "x10/regionarray/PolyScanner.x10"
                final long t$155683 = ((long)(((int)(0))));
                
                //#line 240 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$155681 = ((x10.regionarray.PolyScanner)(this.s));
                
                //#line 240 "x10/regionarray/PolyScanner.x10"
                final int t$155684 = t$155681.min$O((int)(0));
                
                //#line 240 "x10/regionarray/PolyScanner.x10"
                ((int[])t$155682.value)[(int)t$155683] = t$155684;
                
                //#line 241 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$155686 = ((x10.core.Rail)(this.myMax));
                
                //#line 241 "x10/regionarray/PolyScanner.x10"
                final long t$155687 = ((long)(((int)(0))));
                
                //#line 241 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$155685 = ((x10.regionarray.PolyScanner)(this.s));
                
                //#line 241 "x10/regionarray/PolyScanner.x10"
                final int t$155688 = t$155685.max$O((int)(0));
                
                //#line 241 "x10/regionarray/PolyScanner.x10"
                ((int[])t$155686.value)[(int)t$155687] = t$155688;
                
                //#line 242 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$155690 = ((x10.core.Rail)(this.x));
                
                //#line 242 "x10/regionarray/PolyScanner.x10"
                final long t$155691 = ((long)(((int)(0))));
                
                //#line 242 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$155689 = ((x10.regionarray.PolyScanner)(this.s));
                
                //#line 242 "x10/regionarray/PolyScanner.x10"
                final int t$155692 = t$155689.min$O((int)(0));
                
                //#line 242 "x10/regionarray/PolyScanner.x10"
                ((int[])t$155690.value)[(int)t$155691] = t$155692;
                
                //#line 243 "x10/regionarray/PolyScanner.x10"
                this.k = 1;
                
                //#line 243 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    final int t$156307 = this.k;
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    final long t$156308 = ((long)(((int)(t$156307))));
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    final long t$156309 = this.rank;
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    final boolean t$156310 = ((t$156308) < (((long)(t$156309))));
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    if (!(t$156310)) {
                        
                        //#line 243 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.PolyScanner t$156282 = ((x10.regionarray.PolyScanner)(this.s));
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final int t$156283 = this.k;
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final int t$156284 = ((t$156283) - (((int)(1))));
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final x10.core.Rail t$156285 = ((x10.core.Rail)(this.x));
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final int t$156286 = this.k;
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final int t$156287 = ((t$156286) - (((int)(1))));
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final long t$156288 = ((long)(((int)(t$156287))));
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final int t$156289 = ((int[])t$156285.value)[(int)t$156288];
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    t$156282.set((int)(t$156284), (int)(t$156289));
                    
                    //#line 245 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.PolyScanner t$156290 = ((x10.regionarray.PolyScanner)(this.s));
                    
                    //#line 245 "x10/regionarray/PolyScanner.x10"
                    final int t$156291 = this.k;
                    
                    //#line 245 "x10/regionarray/PolyScanner.x10"
                    final int m$156292 = t$156290.min$O((int)(t$156291));
                    
                    //#line 246 "x10/regionarray/PolyScanner.x10"
                    final x10.core.Rail t$156293 = ((x10.core.Rail)(this.x));
                    
                    //#line 246 "x10/regionarray/PolyScanner.x10"
                    final int t$156294 = this.k;
                    
                    //#line 246 "x10/regionarray/PolyScanner.x10"
                    final long t$156295 = ((long)(((int)(t$156294))));
                    
                    //#line 246 "x10/regionarray/PolyScanner.x10"
                    ((int[])t$156293.value)[(int)t$156295] = m$156292;
                    
                    //#line 247 "x10/regionarray/PolyScanner.x10"
                    final x10.core.Rail t$156296 = ((x10.core.Rail)(this.myMin));
                    
                    //#line 247 "x10/regionarray/PolyScanner.x10"
                    final int t$156297 = this.k;
                    
                    //#line 247 "x10/regionarray/PolyScanner.x10"
                    final long t$156298 = ((long)(((int)(t$156297))));
                    
                    //#line 247 "x10/regionarray/PolyScanner.x10"
                    ((int[])t$156296.value)[(int)t$156298] = m$156292;
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    final x10.core.Rail t$156299 = ((x10.core.Rail)(this.myMax));
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    final int t$156300 = this.k;
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    final long t$156301 = ((long)(((int)(t$156300))));
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.PolyScanner t$156302 = ((x10.regionarray.PolyScanner)(this.s));
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    final int t$156303 = this.k;
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    final int t$156304 = t$156302.max$O((int)(t$156303));
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    ((int[])t$156299.value)[(int)t$156301] = t$156304;
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    final int t$156305 = this.k;
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    final int t$156306 = ((t$156305) + (((int)(1))));
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    this.k = t$156306;
                }
                
                //#line 250 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail a$154250 = ((x10.core.Rail)(this.x));
                
                //#line 250 "x10/regionarray/PolyScanner.x10"
                final long t$155722 = this.rank;
                
                //#line 250 "x10/regionarray/PolyScanner.x10"
                final long i0$154251 = ((t$155722) - (((long)(1L))));
                
                //#line 250 "x10/regionarray/PolyScanner.x10"
                final int t$155723 = ((int[])a$154250.value)[(int)i0$154251];
                
                //#line 250 "x10/regionarray/PolyScanner.x10"
                final int r$154259 = ((t$155723) - (((int)(1))));
                
                //#line 250 "x10/regionarray/PolyScanner.x10"
                ((int[])a$154250.value)[(int)i0$154251] = r$154259;
                
                //#line 251 "x10/regionarray/PolyScanner.x10"
                this.checkHasNext();
            }
            return this;
        }
        
        
        
        //#line 254 "x10/regionarray/PolyScanner.x10"
        public boolean hasNext$O() {
            
            //#line 254 "x10/regionarray/PolyScanner.x10"
            final boolean t$155724 = this.doesHaveNext;
            
            //#line 254 "x10/regionarray/PolyScanner.x10"
            return t$155724;
        }
        
        
        //#line 256 "x10/regionarray/PolyScanner.x10"
        private void checkHasNext() {
            
            //#line 257 "x10/regionarray/PolyScanner.x10"
            final long t$155725 = this.rank;
            
            //#line 257 "x10/regionarray/PolyScanner.x10"
            final int t$155726 = ((int)(long)(((long)(t$155725))));
            
            //#line 257 "x10/regionarray/PolyScanner.x10"
            final int t$155727 = ((t$155726) - (((int)(1))));
            
            //#line 257 "x10/regionarray/PolyScanner.x10"
            this.k = t$155727;
            
            //#line 258 "x10/regionarray/PolyScanner.x10"
            while (true) {
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$155729 = ((x10.core.Rail)(this.x));
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final int t$155728 = this.k;
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final long t$155730 = ((long)(((int)(t$155728))));
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final int t$155734 = ((int[])t$155729.value)[(int)t$155730];
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$155732 = ((x10.core.Rail)(this.myMax));
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final int t$155731 = this.k;
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final long t$155733 = ((long)(((int)(t$155731))));
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final int t$155735 = ((int[])t$155732.value)[(int)t$155733];
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final boolean t$155741 = ((t$155734) >= (((int)(t$155735))));
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                if (!(t$155741)) {
                    
                    //#line 258 "x10/regionarray/PolyScanner.x10"
                    break;
                }
                
                //#line 259 "x10/regionarray/PolyScanner.x10"
                final int t$156311 = this.k;
                
                //#line 259 "x10/regionarray/PolyScanner.x10"
                final int t$156312 = ((t$156311) - (((int)(1))));
                
                //#line 259 "x10/regionarray/PolyScanner.x10"
                final int t$156313 = this.k = t$156312;
                
                //#line 259 "x10/regionarray/PolyScanner.x10"
                final long t$156314 = ((long)(((int)(t$156313))));
                
                //#line 259 "x10/regionarray/PolyScanner.x10"
                final boolean t$156315 = ((t$156314) < (((long)(0L))));
                
                //#line 259 "x10/regionarray/PolyScanner.x10"
                if (t$156315) {
                    
                    //#line 260 "x10/regionarray/PolyScanner.x10"
                    this.doesHaveNext = false;
                    
                    //#line 261 "x10/regionarray/PolyScanner.x10"
                    return;
                }
            }
            
            //#line 264 "x10/regionarray/PolyScanner.x10"
            this.doesHaveNext = true;
        }
        
        public static void checkHasNext$P(final x10.regionarray.PolyScanner.RailIt RailIt) {
            RailIt.checkHasNext();
        }
        
        
        //#line 267 "x10/regionarray/PolyScanner.x10"
        final public x10.core.Rail next() {
            
            //#line 268 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail a$154290 = ((x10.core.Rail)(this.x));
            
            //#line 268 "x10/regionarray/PolyScanner.x10"
            final int t$155742 = this.k;
            
            //#line 268 "x10/regionarray/PolyScanner.x10"
            final long i0$154291 = ((long)(((int)(t$155742))));
            
            //#line 268 "x10/regionarray/PolyScanner.x10"
            final int t$155743 = ((int[])a$154290.value)[(int)i0$154291];
            
            //#line 268 "x10/regionarray/PolyScanner.x10"
            final int r$154299 = ((t$155743) + (((int)(1))));
            
            //#line 268 "x10/regionarray/PolyScanner.x10"
            ((int[])a$154290.value)[(int)i0$154291] = r$154299;
            
            //#line 269 "x10/regionarray/PolyScanner.x10"
            final int t$156341 = this.k;
            
            //#line 269 "x10/regionarray/PolyScanner.x10"
            final int t$156342 = ((t$156341) + (((int)(1))));
            
            //#line 269 "x10/regionarray/PolyScanner.x10"
            this.k = t$156342;
            
            //#line 269 "x10/regionarray/PolyScanner.x10"
            for (;
                 true;
                 ) {
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                final int t$156343 = this.k;
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                final long t$156344 = ((long)(((int)(t$156343))));
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                final long t$156345 = this.rank;
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                final boolean t$156346 = ((t$156344) < (((long)(t$156345))));
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                if (!(t$156346)) {
                    
                    //#line 269 "x10/regionarray/PolyScanner.x10"
                    break;
                }
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$156316 = ((x10.regionarray.PolyScanner)(this.s));
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final int t$156317 = this.k;
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final int t$156318 = ((t$156317) - (((int)(1))));
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$156319 = ((x10.core.Rail)(this.x));
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final int t$156320 = this.k;
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final int t$156321 = ((t$156320) - (((int)(1))));
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final long t$156322 = ((long)(((int)(t$156321))));
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final int t$156323 = ((int[])t$156319.value)[(int)t$156322];
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                t$156316.set((int)(t$156318), (int)(t$156323));
                
                //#line 271 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$156324 = ((x10.regionarray.PolyScanner)(this.s));
                
                //#line 271 "x10/regionarray/PolyScanner.x10"
                final int t$156325 = this.k;
                
                //#line 271 "x10/regionarray/PolyScanner.x10"
                final int m$156326 = t$156324.min$O((int)(t$156325));
                
                //#line 272 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$156327 = ((x10.core.Rail)(this.x));
                
                //#line 272 "x10/regionarray/PolyScanner.x10"
                final int t$156328 = this.k;
                
                //#line 272 "x10/regionarray/PolyScanner.x10"
                final long t$156329 = ((long)(((int)(t$156328))));
                
                //#line 272 "x10/regionarray/PolyScanner.x10"
                ((int[])t$156327.value)[(int)t$156329] = m$156326;
                
                //#line 273 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$156330 = ((x10.core.Rail)(this.myMin));
                
                //#line 273 "x10/regionarray/PolyScanner.x10"
                final int t$156331 = this.k;
                
                //#line 273 "x10/regionarray/PolyScanner.x10"
                final long t$156332 = ((long)(((int)(t$156331))));
                
                //#line 273 "x10/regionarray/PolyScanner.x10"
                ((int[])t$156330.value)[(int)t$156332] = m$156326;
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$156333 = ((x10.core.Rail)(this.myMax));
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                final int t$156334 = this.k;
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                final long t$156335 = ((long)(((int)(t$156334))));
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$156336 = ((x10.regionarray.PolyScanner)(this.s));
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                final int t$156337 = this.k;
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                final int t$156338 = t$156336.max$O((int)(t$156337));
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                ((int[])t$156333.value)[(int)t$156335] = t$156338;
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                final int t$156339 = this.k;
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                final int t$156340 = ((t$156339) + (((int)(1))));
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                this.k = t$156340;
            }
            
            //#line 276 "x10/regionarray/PolyScanner.x10"
            this.checkHasNext();
            
            //#line 277 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail t$155775 = ((x10.core.Rail)(this.x));
            
            //#line 277 "x10/regionarray/PolyScanner.x10"
            return t$155775;
        }
        
        
        //#line 280 "x10/regionarray/PolyScanner.x10"
        public void remove() {
            
        }
        
        
        //#line 229 "x10/regionarray/PolyScanner.x10"
        final public x10.regionarray.PolyScanner.RailIt x10$regionarray$PolyScanner$RailIt$$this$x10$regionarray$PolyScanner$RailIt() {
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            return x10.regionarray.PolyScanner.RailIt.this;
        }
        
        
        //#line 229 "x10/regionarray/PolyScanner.x10"
        final public x10.regionarray.PolyScanner x10$regionarray$PolyScanner$RailIt$$this$x10$regionarray$PolyScanner() {
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyScanner t$155776 = this.out$;
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            return t$155776;
        }
        
        
        //#line 229 "x10/regionarray/PolyScanner.x10"
        final public void __fieldInitializers_x10_regionarray_PolyScanner_RailIt() {
            
            //#line 230 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyScanner t$155777 = this.out$;
            
            //#line 230 "x10/regionarray/PolyScanner.x10"
            final long t$155778 = t$155777.rank;
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.rank = t$155778;
            
            //#line 231 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyScanner t$155779 = this.out$;
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.s = ((x10.regionarray.PolyScanner)(t$155779));
            
            //#line 233 "x10/regionarray/PolyScanner.x10"
            final long t$155780 = this.rank;
            
            //#line 233 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail t$155781 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, ((long)(t$155780)))));
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.x = ((x10.core.Rail)(t$155781));
            
            //#line 234 "x10/regionarray/PolyScanner.x10"
            final long t$155782 = this.rank;
            
            //#line 234 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail t$155783 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, ((long)(t$155782)))));
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.myMin = ((x10.core.Rail)(t$155783));
            
            //#line 235 "x10/regionarray/PolyScanner.x10"
            final long t$155784 = this.rank;
            
            //#line 235 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail t$155785 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, ((long)(t$155784)))));
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.myMax = ((x10.core.Rail)(t$155785));
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.k = 0;
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.doesHaveNext = false;
        }
    }
    
    
    
    //#line 289 "x10/regionarray/PolyScanner.x10"
    /**
     * required by API, but less efficient b/c of allocation
     * XXX figure out how to expose
     *   1. Any/Var/ValPoint?
     *   2. hide inside iterator(body:(Point)=>void)?
     */
    public x10.lang.Iterator iterator() {
        
        //#line 289 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.PolyScanner.Anonymous$10018 alloc$154469 = ((x10.regionarray.PolyScanner.Anonymous$10018)(new x10.regionarray.PolyScanner.Anonymous$10018((java.lang.System[]) null)));
        
        //#line 289 "x10/regionarray/PolyScanner.x10"
        alloc$154469.x10$regionarray$PolyScanner$Anonymous$10018$$init$S(this);
        
        //#line 289 "x10/regionarray/PolyScanner.x10"
        return alloc$154469;
    }
    
    
    //#line 304 "x10/regionarray/PolyScanner.x10"
    public void printInfo(final x10.io.Printer ps) {
        
        //#line 305 "x10/regionarray/PolyScanner.x10"
        ps.println(((java.lang.Object)("PolyScanner")));
        
        //#line 306 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.PolyMat t$155786 = ((x10.regionarray.PolyMat)(this.C));
        
        //#line 306 "x10/regionarray/PolyScanner.x10"
        ((x10.regionarray.Mat<x10.regionarray.PolyRow>)t$155786).printInfo(((x10.io.Printer)(ps)), ((java.lang.String)("  C")));
    }
    
    
    //#line 309 "x10/regionarray/PolyScanner.x10"
    public void printInfo2(final x10.io.Printer ps) {
        
        //#line 310 "x10/regionarray/PolyScanner.x10"
        int k = 0;
        
        //#line 310 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            final long t$155790 = ((long)(((int)(k))));
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array t$155789 = ((x10.regionarray.Array)(this.myMin));
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            final long t$155791 = ((x10.regionarray.Array<x10.regionarray.VarMat>)t$155789).size;
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            final boolean t$155900 = ((t$155790) < (((long)(t$155791))));
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            if (!(t$155900)) {
                
                //#line 310 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 311 "x10/regionarray/PolyScanner.x10"
            final java.lang.String t$156482 = (("axis ") + ((x10.core.Int.$box(k))));
            
            //#line 311 "x10/regionarray/PolyScanner.x10"
            ps.println(((java.lang.Object)(t$156482)));
            
            //#line 312 "x10/regionarray/PolyScanner.x10"
            ps.println(((java.lang.Object)("  min")));
            
            //#line 313 "x10/regionarray/PolyScanner.x10"
            int l$156463 = 0;
            
            //#line 313 "x10/regionarray/PolyScanner.x10"
            for (;
                 true;
                 ) {
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156465 = ((x10.regionarray.Array)(this.myMin));
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                final long i$156467 = ((long)(((int)(k))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156468 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156401 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156465).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156402 = ((x10.regionarray.VarMat[])t$156401.value)[(int)i$156467];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156468 = t$156402;
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                final int t$156470 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156468).rows;
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                final boolean t$156471 = ((l$156463) < (((int)(t$156470))));
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                if (!(t$156471)) {
                    
                    //#line 313 "x10/regionarray/PolyScanner.x10"
                    break;
                }
                
                //#line 314 "x10/regionarray/PolyScanner.x10"
                ps.print(((java.lang.String)("  ")));
                
                //#line 315 "x10/regionarray/PolyScanner.x10"
                int m$156379 = 0;
                
                //#line 315 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$156381 = ((x10.regionarray.Array)(this.myMin));
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    final long i$156383 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$156384 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$156349 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156381).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$156350 = ((x10.regionarray.VarMat[])t$156349.value)[(int)i$156383];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$156384 = t$156350;
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$156387 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156384).$apply$G((int)(l$156463));
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    final int t$156388 = t$156387.cols;
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    final boolean t$156389 = ((m$156379) < (((int)(t$156388))));
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    if (!(t$156389)) {
                        
                        //#line 315 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 316 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$156351 = ((x10.regionarray.Array)(this.myMin));
                    
                    //#line 316 "x10/regionarray/PolyScanner.x10"
                    final long i$156353 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$156354 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$156347 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156351).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$156348 = ((x10.regionarray.VarMat[])t$156347.value)[(int)i$156353];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$156354 = t$156348;
                    
                    //#line 316 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$156357 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156354).$apply$G((int)(l$156463));
                    
                    //#line 316 "x10/regionarray/PolyScanner.x10"
                    final int t$156359 = t$156357.$apply$O((int)(m$156379));
                    
                    //#line 316 "x10/regionarray/PolyScanner.x10"
                    final java.lang.String t$156360 = ((" ") + ((x10.core.Int.$box(t$156359))));
                    
                    //#line 316 "x10/regionarray/PolyScanner.x10"
                    ps.print(((java.lang.String)(t$156360)));
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    final int t$156362 = ((m$156379) + (((int)(1))));
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    m$156379 = t$156362;
                }
                
                //#line 317 "x10/regionarray/PolyScanner.x10"
                ps.print(((java.lang.String)("  sum")));
                
                //#line 318 "x10/regionarray/PolyScanner.x10"
                int m$156390 = 0;
                
                //#line 318 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$156392 = ((x10.regionarray.Array)(this.minSum));
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    final long i$156394 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$156395 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$156365 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156392).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$156366 = ((x10.regionarray.VarMat[])t$156365.value)[(int)i$156394];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$156395 = t$156366;
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$156398 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156395).$apply$G((int)(l$156463));
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    final int t$156399 = t$156398.cols;
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    final boolean t$156400 = ((m$156390) < (((int)(t$156399))));
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    if (!(t$156400)) {
                        
                        //#line 318 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 319 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$156367 = ((x10.regionarray.Array)(this.minSum));
                    
                    //#line 319 "x10/regionarray/PolyScanner.x10"
                    final long i$156369 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$156370 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$156363 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156367).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$156364 = ((x10.regionarray.VarMat[])t$156363.value)[(int)i$156369];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$156370 = t$156364;
                    
                    //#line 319 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$156373 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156370).$apply$G((int)(l$156463));
                    
                    //#line 319 "x10/regionarray/PolyScanner.x10"
                    final int t$156375 = t$156373.$apply$O((int)(m$156390));
                    
                    //#line 319 "x10/regionarray/PolyScanner.x10"
                    final java.lang.String t$156376 = ((" ") + ((x10.core.Int.$box(t$156375))));
                    
                    //#line 319 "x10/regionarray/PolyScanner.x10"
                    ps.print(((java.lang.String)(t$156376)));
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    final int t$156378 = ((m$156390) + (((int)(1))));
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    m$156390 = t$156378;
                }
                
                //#line 320 "x10/regionarray/PolyScanner.x10"
                ps.print(((java.lang.String)("\n")));
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                final int t$156404 = ((l$156463) + (((int)(1))));
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                l$156463 = t$156404;
            }
            
            //#line 322 "x10/regionarray/PolyScanner.x10"
            ps.printf(((java.lang.String)("  max\n")));
            
            //#line 323 "x10/regionarray/PolyScanner.x10"
            int l$156472 = 0;
            
            //#line 323 "x10/regionarray/PolyScanner.x10"
            for (;
                 true;
                 ) {
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156474 = ((x10.regionarray.Array)(this.myMax));
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                final long i$156476 = ((long)(((int)(k))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156477 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156459 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156474).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156460 = ((x10.regionarray.VarMat[])t$156459.value)[(int)i$156476];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156477 = t$156460;
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                final int t$156479 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156477).rows;
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                final boolean t$156480 = ((l$156472) < (((int)(t$156479))));
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                if (!(t$156480)) {
                    
                    //#line 323 "x10/regionarray/PolyScanner.x10"
                    break;
                }
                
                //#line 324 "x10/regionarray/PolyScanner.x10"
                ps.print(((java.lang.String)("  ")));
                
                //#line 325 "x10/regionarray/PolyScanner.x10"
                int m$156437 = 0;
                
                //#line 325 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$156439 = ((x10.regionarray.Array)(this.myMax));
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    final long i$156441 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$156442 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$156407 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156439).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$156408 = ((x10.regionarray.VarMat[])t$156407.value)[(int)i$156441];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$156442 = t$156408;
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$156445 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156442).$apply$G((int)(l$156472));
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    final int t$156446 = t$156445.cols;
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    final boolean t$156447 = ((m$156437) < (((int)(t$156446))));
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    if (!(t$156447)) {
                        
                        //#line 325 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 326 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$156409 = ((x10.regionarray.Array)(this.myMax));
                    
                    //#line 326 "x10/regionarray/PolyScanner.x10"
                    final long i$156411 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$156412 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$156405 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156409).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$156406 = ((x10.regionarray.VarMat[])t$156405.value)[(int)i$156411];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$156412 = t$156406;
                    
                    //#line 326 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$156415 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156412).$apply$G((int)(l$156472));
                    
                    //#line 326 "x10/regionarray/PolyScanner.x10"
                    final int t$156417 = t$156415.$apply$O((int)(m$156437));
                    
                    //#line 326 "x10/regionarray/PolyScanner.x10"
                    final java.lang.String t$156418 = ((" ") + ((x10.core.Int.$box(t$156417))));
                    
                    //#line 326 "x10/regionarray/PolyScanner.x10"
                    ps.print(((java.lang.String)(t$156418)));
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    final int t$156420 = ((m$156437) + (((int)(1))));
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    m$156437 = t$156420;
                }
                
                //#line 327 "x10/regionarray/PolyScanner.x10"
                ps.print(((java.lang.String)("  sum")));
                
                //#line 328 "x10/regionarray/PolyScanner.x10"
                int m$156448 = 0;
                
                //#line 328 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$156450 = ((x10.regionarray.Array)(this.maxSum));
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    final long i$156452 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$156453 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$156423 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156450).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$156424 = ((x10.regionarray.VarMat[])t$156423.value)[(int)i$156452];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$156453 = t$156424;
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$156456 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156453).$apply$G((int)(l$156472));
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    final int t$156457 = t$156456.cols;
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    final boolean t$156458 = ((m$156448) < (((int)(t$156457))));
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    if (!(t$156458)) {
                        
                        //#line 328 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 329 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$156425 = ((x10.regionarray.Array)(this.maxSum));
                    
                    //#line 329 "x10/regionarray/PolyScanner.x10"
                    final long i$156427 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$156428 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$156421 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156425).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$156422 = ((x10.regionarray.VarMat[])t$156421.value)[(int)i$156427];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$156428 = t$156422;
                    
                    //#line 329 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$156431 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156428).$apply$G((int)(l$156472));
                    
                    //#line 329 "x10/regionarray/PolyScanner.x10"
                    final int t$156433 = t$156431.$apply$O((int)(m$156448));
                    
                    //#line 329 "x10/regionarray/PolyScanner.x10"
                    final java.lang.String t$156434 = ((" ") + ((x10.core.Int.$box(t$156433))));
                    
                    //#line 329 "x10/regionarray/PolyScanner.x10"
                    ps.print(((java.lang.String)(t$156434)));
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    final int t$156436 = ((m$156448) + (((int)(1))));
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    m$156448 = t$156436;
                }
                
                //#line 330 "x10/regionarray/PolyScanner.x10"
                ps.println();
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                final int t$156462 = ((l$156472) + (((int)(1))));
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                l$156472 = t$156462;
            }
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            final int t$156484 = ((k) + (((int)(1))));
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            k = t$156484;
        }
    }
    
    
    //#line 68 "x10/regionarray/PolyScanner.x10"
    final public x10.regionarray.PolyScanner x10$regionarray$PolyScanner$$this$x10$regionarray$PolyScanner() {
        
        //#line 68 "x10/regionarray/PolyScanner.x10"
        return x10.regionarray.PolyScanner.this;
    }
    
    
    //#line 68 "x10/regionarray/PolyScanner.x10"
    final public void __fieldInitializers_x10_regionarray_PolyScanner() {
        
    }
    
    
    //#line 289 "x10/regionarray/PolyScanner.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$10018 extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$10018> $RTT = 
            x10.rtt.NamedType.<Anonymous$10018> make("x10.regionarray.PolyScanner.Anonymous$10018",
                                                     Anonymous$10018.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyScanner.Anonymous$10018 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.it = $deserializer.readObject();
            $_obj.out$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyScanner.Anonymous$10018 $_obj = new x10.regionarray.PolyScanner.Anonymous$10018((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.it);
            $serializer.write(this.out$);
            
        }
        
        // constructor just for allocation
        public Anonymous$10018(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        final public x10.lang.Point next$G() {
            return next();
        }
        
        
    
        
        //#line 68 "x10/regionarray/PolyScanner.x10"
        public x10.regionarray.PolyScanner out$;
        
        //#line 290 "x10/regionarray/PolyScanner.x10"
        public x10.regionarray.PolyScanner.RailIt it;
        
        
        //#line 291 "x10/regionarray/PolyScanner.x10"
        final public boolean hasNext$O() {
            
            //#line 291 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyScanner.RailIt this$155380 = ((x10.regionarray.PolyScanner.RailIt)(this.it));
            
            //#line 254 . "x10/regionarray/PolyScanner.x10"
            final boolean t$155901 = this$155380.doesHaveNext;
            
            //#line 291 "x10/regionarray/PolyScanner.x10"
            return t$155901;
        }
        
        
        //#line 292 "x10/regionarray/PolyScanner.x10"
        final public x10.lang.Point next() {
            
            //#line 293 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyScanner.RailIt t$155902 = ((x10.regionarray.PolyScanner.RailIt)(this.it));
            
            //#line 293 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail t = t$155902.next();
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final long t$155907 = ((x10.core.Rail<x10.core.Int>)t).size;
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final x10.core.fun.Fun_0_1 t$155908 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyScanner.Anonymous$10018.$Closure$216(t, (x10.regionarray.PolyScanner.Anonymous$10018.$Closure$216.__0$1x10$lang$Int$2) null)));
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail t$155909 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$155907)), ((x10.core.fun.Fun_0_1)(t$155908)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final x10.lang.Point t$155910 = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(t$155909)))));
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final x10.lang.Point t$154335 = ((x10.lang.Point)
                                              t$155910);
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final long t$155912 = t$154335.rank;
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyScanner t$155911 = this.out$;
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final long t$155913 = t$155911.rank;
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final boolean t$155914 = ((long) t$155912) == ((long) t$155913);
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final boolean t$155916 = !(t$155914);
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            if (t$155916) {
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                final x10.lang.FailedDynamicCheckException t$155915 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==x10.regionarray.PolyScanner.this(:<anonymous class>).rank}");
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                throw t$155915;
            }
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            return t$154335;
        }
        
        
        //#line 289 "x10/regionarray/PolyScanner.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$10018(final x10.regionarray.PolyScanner out$) {
            this((java.lang.System[]) null);
            x10$regionarray$PolyScanner$Anonymous$10018$$init$S(out$);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.PolyScanner.Anonymous$10018 x10$regionarray$PolyScanner$Anonymous$10018$$init$S(final x10.regionarray.PolyScanner out$) {
             {
                
                //#line 68 "x10/regionarray/PolyScanner.x10"
                this.out$ = out$;
                
                //#line 290 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner.RailIt alloc$154470 = ((x10.regionarray.PolyScanner.RailIt)(new x10.regionarray.PolyScanner.RailIt((java.lang.System[]) null)));
                
                //#line 290 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$156485 = this.out$;
                
                //#line 290 "x10/regionarray/PolyScanner.x10"
                alloc$154470.x10$regionarray$PolyScanner$RailIt$$init$S(t$156485);
                
                //#line 290 "x10/regionarray/PolyScanner.x10"
                this.it = ((x10.regionarray.PolyScanner.RailIt)(alloc$154470));
            }
            return this;
        }
        
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$216 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$216> $RTT = 
                x10.rtt.StaticFunType.<$Closure$216> make($Closure$216.class,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                          });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyScanner.Anonymous$10018.$Closure$216 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.t = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.regionarray.PolyScanner.Anonymous$10018.$Closure$216 $_obj = new x10.regionarray.PolyScanner.Anonymous$10018.$Closure$216((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.t);
                
            }
            
            // constructor just for allocation
            public $Closure$216(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
                return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
                return $apply$O(x10.core.Long.$unbox(a1));
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Int$2 {}
            
        
            
            public long $apply$O(final long i) {
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                final int t$155903 = ((int)(long)(((long)(i))));
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                final long t$155904 = ((long)(((int)(t$155903))));
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                final int t$155905 = ((int[])this.t.value)[(int)t$155904];
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                final long t$155906 = ((long)(((int)(t$155905))));
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                return t$155906;
            }
            
            public x10.core.Rail<x10.core.Int> t;
            
            public $Closure$216(final x10.core.Rail<x10.core.Int> t, __0$1x10$lang$Int$2 $dummy) {
                 {
                    this.t = ((x10.core.Rail)(t));
                }
            }
            
        }
        
    }
    
}

