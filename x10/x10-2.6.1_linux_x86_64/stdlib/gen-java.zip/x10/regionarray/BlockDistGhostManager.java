package x10.regionarray;

/**
 * A BlockDistGhostManager manages the local ghost region for a Ghostable
 * array that is distributed using a BlockDist.
 */
@x10.runtime.impl.java.X10Generated
final public class BlockDistGhostManager extends x10.regionarray.GhostManager implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<BlockDistGhostManager> $RTT = 
        x10.rtt.NamedType.<BlockDistGhostManager> make("x10.regionarray.BlockDistGhostManager",
                                                       BlockDistGhostManager.class,
                                                       new x10.rtt.Type[] {
                                                           x10.regionarray.GhostManager.$RTT
                                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.GhostManager.$_deserialize_body($_obj, $deserializer);
        $_obj.bd = $deserializer.readObject();
        $_obj.leftNeighbor = $deserializer.readObject();
        $_obj.periodic = $deserializer.readBoolean();
        $_obj.rightNeighbor = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.BlockDistGhostManager $_obj = new x10.regionarray.BlockDistGhostManager((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.bd);
        $serializer.write(this.leftNeighbor);
        $serializer.write(this.periodic);
        $serializer.write(this.rightNeighbor);
        
    }
    
    // constructor just for allocation
    public BlockDistGhostManager(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 19 "x10/regionarray/BlockDistGhostManager.x10"
    public x10.regionarray.BlockDist bd;
    
    //#line 20 "x10/regionarray/BlockDistGhostManager.x10"
    public x10.regionarray.GhostManager.GhostNeighborFlag leftNeighbor;
    
    //#line 21 "x10/regionarray/BlockDistGhostManager.x10"
    public x10.regionarray.GhostManager.GhostNeighborFlag rightNeighbor;
    
    //#line 22 "x10/regionarray/BlockDistGhostManager.x10"
    public boolean periodic;
    
    
    //#line 24 "x10/regionarray/BlockDistGhostManager.x10"
    // creation method for java code (1-phase java constructor)
    public BlockDistGhostManager(final long ghostWidth, final x10.regionarray.BlockDist bd, final boolean periodic) {
        this((java.lang.System[]) null);
        x10$regionarray$BlockDistGhostManager$$init$S(ghostWidth, bd, periodic);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.BlockDistGhostManager x10$regionarray$BlockDistGhostManager$$init$S(final long ghostWidth, final x10.regionarray.BlockDist bd, final boolean periodic) {
         {
            
            //#line 25 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager this$148245 = this;
            
            //#line 22 .. "x10/regionarray/GhostManager.x10"
            this$148245.currentPhase = ((byte) 0);
            
            //#line 38 . "x10/regionarray/GhostManager.x10"
            this$148245.ghostWidth = ghostWidth;
            
            //#line 39 . "x10/regionarray/GhostManager.x10"
            this$148245.currentPhase = ((byte) 0);
            
            //#line 24 "x10/regionarray/BlockDistGhostManager.x10"
            
            
            //#line 26 "x10/regionarray/BlockDistGhostManager.x10"
            this.bd = ((x10.regionarray.BlockDist)(bd));
            
            //#line 28 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.PlaceGroup pg = bd.pg;
            
            //#line 30 "x10/regionarray/BlockDistGhostManager.x10"
            final long i = pg.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
            
            //#line 31 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Place left;
            
            //#line 32 "x10/regionarray/BlockDistGhostManager.x10"
            x10.lang.Point leftShift =  null;
            
            //#line 33 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$148306 = ((i) > (((long)(0L))));
            
            //#line 33 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$148306) {
                
                //#line 34 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148277 = ((i) - (((long)(1L))));
                
                //#line 34 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.lang.Place t$148278 = pg.$apply((long)(t$148277));
                
                //#line 34 "x10/regionarray/BlockDistGhostManager.x10"
                left = ((x10.lang.Place)(t$148278));
                
                //#line 38 . "x10/regionarray/Dist.x10"
                final x10.regionarray.Region t$148279 = ((x10.regionarray.Region)(bd.region));
                
                //#line 38 . "x10/regionarray/Dist.x10"
                final long t$148280 = t$148279.rank;
                
                //#line 35 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.core.fun.Fun_0_1 t$148281 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$167()));
                
                //#line 35 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.lang.Point t$148282 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$148280), ((x10.core.fun.Fun_0_1)(t$148281)))));
                
                //#line 35 "x10/regionarray/BlockDistGhostManager.x10"
                leftShift = ((x10.lang.Point)(t$148282));
            } else {
                
                //#line 36 "x10/regionarray/BlockDistGhostManager.x10"
                if (periodic) {
                    
                    //#line 35 . "x10/lang/PlaceGroup.x10"
                    final long t$148283 = pg.numPlaces$O();
                    
                    //#line 37 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148284 = ((t$148283) - (((long)(1L))));
                    
                    //#line 37 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Place t$148285 = pg.$apply((long)(t$148284));
                    
                    //#line 37 "x10/regionarray/BlockDistGhostManager.x10"
                    left = ((x10.lang.Place)(t$148285));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final x10.regionarray.Region t$148286 = ((x10.regionarray.Region)(bd.region));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final long t$148299 = t$148286.rank;
                    
                    //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.core.fun.Fun_0_1 t$148300 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$168(bd)));
                    
                    //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Point t$148301 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$148299), ((x10.core.fun.Fun_0_1)(t$148300)))));
                    
                    //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                    leftShift = ((x10.lang.Point)(t$148301));
                } else {
                    
                    //#line 40 "x10/regionarray/BlockDistGhostManager.x10"
                    left = ((x10.lang.Place)(x10.x10rt.X10RT.here()));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final x10.regionarray.Region t$148302 = ((x10.regionarray.Region)(bd.region));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final long t$148303 = t$148302.rank;
                    
                    //#line 41 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.core.fun.Fun_0_1 t$148304 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$169()));
                    
                    //#line 41 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Point t$148305 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$148303), ((x10.core.fun.Fun_0_1)(t$148304)))));
                    
                    //#line 41 "x10/regionarray/BlockDistGhostManager.x10"
                    leftShift = ((x10.lang.Point)(t$148305));
                }
            }
            
            //#line 43 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag alloc$148069 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(new x10.regionarray.GhostManager.GhostNeighborFlag((java.lang.System[]) null)));
            
            //#line 79 . "x10/regionarray/GhostManager.x10"
            alloc$148069.place = left;
            
            //#line 79 . "x10/regionarray/GhostManager.x10"
            alloc$148069.shift = leftShift;
            
            //#line 79 .. "x10/regionarray/GhostManager.x10"
            alloc$148069.received = false;
            
            //#line 43 "x10/regionarray/BlockDistGhostManager.x10"
            this.leftNeighbor = ((x10.regionarray.GhostManager.GhostNeighborFlag)(alloc$148069));
            
            //#line 45 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Place right;
            
            //#line 46 "x10/regionarray/BlockDistGhostManager.x10"
            x10.lang.Point rightShift =  null;
            
            //#line 35 . "x10/lang/PlaceGroup.x10"
            final long t$148307 = pg.numPlaces$O();
            
            //#line 47 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148308 = ((t$148307) - (((long)(1L))));
            
            //#line 47 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$148335 = ((i) < (((long)(t$148308))));
            
            //#line 47 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$148335) {
                
                //#line 48 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148309 = ((i) + (((long)(1L))));
                
                //#line 48 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.lang.Place t$148310 = pg.$apply((long)(t$148309));
                
                //#line 48 "x10/regionarray/BlockDistGhostManager.x10"
                right = ((x10.lang.Place)(t$148310));
                
                //#line 38 . "x10/regionarray/Dist.x10"
                final x10.regionarray.Region t$148311 = ((x10.regionarray.Region)(bd.region));
                
                //#line 38 . "x10/regionarray/Dist.x10"
                final long t$148312 = t$148311.rank;
                
                //#line 49 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.core.fun.Fun_0_1 t$148313 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$170()));
                
                //#line 49 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.lang.Point t$148314 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$148312), ((x10.core.fun.Fun_0_1)(t$148313)))));
                
                //#line 49 "x10/regionarray/BlockDistGhostManager.x10"
                rightShift = ((x10.lang.Point)(t$148314));
            } else {
                
                //#line 50 "x10/regionarray/BlockDistGhostManager.x10"
                if (periodic) {
                    
                    //#line 51 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Place t$148315 = pg.$apply((long)(0L));
                    
                    //#line 51 "x10/regionarray/BlockDistGhostManager.x10"
                    right = ((x10.lang.Place)(t$148315));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final x10.regionarray.Region t$148316 = ((x10.regionarray.Region)(bd.region));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final long t$148328 = t$148316.rank;
                    
                    //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.core.fun.Fun_0_1 t$148329 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$171(bd)));
                    
                    //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Point t$148330 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$148328), ((x10.core.fun.Fun_0_1)(t$148329)))));
                    
                    //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                    rightShift = ((x10.lang.Point)(t$148330));
                } else {
                    
                    //#line 54 "x10/regionarray/BlockDistGhostManager.x10"
                    right = ((x10.lang.Place)(x10.x10rt.X10RT.here()));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final x10.regionarray.Region t$148331 = ((x10.regionarray.Region)(bd.region));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final long t$148332 = t$148331.rank;
                    
                    //#line 55 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.core.fun.Fun_0_1 t$148333 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$172()));
                    
                    //#line 55 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Point t$148334 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$148332), ((x10.core.fun.Fun_0_1)(t$148333)))));
                    
                    //#line 55 "x10/regionarray/BlockDistGhostManager.x10"
                    rightShift = ((x10.lang.Point)(t$148334));
                }
            }
            
            //#line 57 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag alloc$148070 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(new x10.regionarray.GhostManager.GhostNeighborFlag((java.lang.System[]) null)));
            
            //#line 79 . "x10/regionarray/GhostManager.x10"
            alloc$148070.place = right;
            
            //#line 79 . "x10/regionarray/GhostManager.x10"
            alloc$148070.shift = rightShift;
            
            //#line 79 .. "x10/regionarray/GhostManager.x10"
            alloc$148070.received = false;
            
            //#line 57 "x10/regionarray/BlockDistGhostManager.x10"
            this.rightNeighbor = ((x10.regionarray.GhostManager.GhostNeighborFlag)(alloc$148070));
            
            //#line 58 "x10/regionarray/BlockDistGhostManager.x10"
            this.periodic = periodic;
        }
        return this;
    }
    
    
    
    //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
    public x10.core.Rail getNeighbors() {
        
        //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.GhostManager.GhostNeighborFlag t$148336 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
        
        //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.lang.Place t$148338 = ((x10.lang.Place)(t$148336.place));
        
        //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.GhostManager.GhostNeighborFlag t$148337 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
        
        //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.lang.Place t$148339 = ((x10.lang.Place)(t$148337.place));
        
        //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.core.Rail t$148340 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.lang.Place> makeRailFromJavaArray(x10.lang.Place.$RTT, new x10.lang.Place[] {t$148338, t$148339})));
        
        //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
        return t$148340;
    }
    
    
    //#line 72 "x10/regionarray/BlockDistGhostManager.x10"
    /**
     * Gets the ghost region for a given place, which is the bounding box 
     * for the region held at that place, expanded in each dimension by
     * <code>ghostWidth</code>.  For a periodic distribution, the ghost
     * region may extend beyond the limits of the entire region. For a 
     * non-periodic dist, the ghost region does not extend beyond the min/max
     * of the region in any dimension.
     * @return the ghost region for the given place
     */
    public x10.regionarray.Region getGhostRegion(final x10.lang.Place place) {
        
        //#line 73 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.BlockDist this$148268 = ((x10.regionarray.BlockDist)(this.bd));
        
        //#line 73 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.Region region = ((x10.regionarray.Region)(this$148268.get(((x10.lang.Place)(place)))));
        
        //#line 74 "x10/regionarray/BlockDistGhostManager.x10"
        final boolean t$148341 = region.isEmpty$O();
        
        //#line 74 "x10/regionarray/BlockDistGhostManager.x10"
        if (t$148341) {
            
            //#line 74 "x10/regionarray/BlockDistGhostManager.x10"
            return region;
        }
        
        //#line 76 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.Region r = ((x10.regionarray.Region)(region.boundingBox()));
        
        //#line 77 "x10/regionarray/BlockDistGhostManager.x10"
        final long t$148342 = r.rank;
        
        //#line 77 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.core.Rail min = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148342)))));
        
        //#line 78 "x10/regionarray/BlockDistGhostManager.x10"
        final long t$148343 = r.rank;
        
        //#line 78 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.core.Rail max = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148343)))));
        
        //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
        final long t$148540 = r.rank;
        
        //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
        final long i$148072max$148541 = ((t$148540) - (((long)(1L))));
        
        //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
        long i$148537 = 0L;
        {
            
            //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
            final long[] min$value$148542 = ((long[])min.value);
            
            //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
            final long[] max$value$148543 = ((long[])max.value);
            
            //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
            for (;
                 true;
                 ) {
                
                //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
                final boolean t$148539 = ((i$148537) <= (((long)(i$148072max$148541))));
                
                //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
                if (!(t$148539)) {
                    
                    //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
                    break;
                }
                
                //#line 80 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$148508 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 80 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148509 = t$148508.axis;
                
                //#line 80 "x10/regionarray/BlockDistGhostManager.x10"
                final boolean t$148510 = ((long) i$148537) == ((long) t$148509);
                
                //#line 80 "x10/regionarray/BlockDistGhostManager.x10"
                if (t$148510) {
                    
                    //#line 81 "x10/regionarray/BlockDistGhostManager.x10"
                    final boolean t$148511 = this.periodic;
                    
                    //#line 81 "x10/regionarray/BlockDistGhostManager.x10"
                    if (t$148511) {
                        
                        //#line 82 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148512 = r.min$O((long)(i$148537));
                        
                        //#line 82 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148513 = this.ghostWidth;
                        
                        //#line 82 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148514 = ((t$148512) - (((long)(t$148513))));
                        
                        //#line 82 "x10/regionarray/BlockDistGhostManager.x10"
                        min$value$148542[(int)i$148537]=t$148514;
                        
                        //#line 83 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148515 = r.max$O((long)(i$148537));
                        
                        //#line 83 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148516 = this.ghostWidth;
                        
                        //#line 83 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148517 = ((t$148515) + (((long)(t$148516))));
                        
                        //#line 83 "x10/regionarray/BlockDistGhostManager.x10"
                        max$value$148543[(int)i$148537]=t$148517;
                    } else {
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.regionarray.BlockDist t$148518 = ((x10.regionarray.BlockDist)(this.bd));
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.regionarray.Region t$148519 = ((x10.regionarray.Region)(t$148518.region));
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148520 = t$148519.min$O((long)(i$148537));
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148521 = r.min$O((long)(i$148537));
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148522 = this.ghostWidth;
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148523 = ((t$148521) - (((long)(t$148522))));
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148524 = java.lang.Math.max(((long)(t$148520)),((long)(t$148523)));
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        min$value$148542[(int)i$148537]=t$148524;
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.regionarray.BlockDist t$148525 = ((x10.regionarray.BlockDist)(this.bd));
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.regionarray.Region t$148526 = ((x10.regionarray.Region)(t$148525.region));
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148527 = t$148526.max$O((long)(i$148537));
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148528 = r.max$O((long)(i$148537));
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148529 = this.ghostWidth;
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148530 = ((t$148528) + (((long)(t$148529))));
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$148531 = java.lang.Math.min(((long)(t$148527)),((long)(t$148530)));
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        max$value$148543[(int)i$148537]=t$148531;
                    }
                } else {
                    
                    //#line 89 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148532 = r.min$O((long)(i$148537));
                    
                    //#line 89 "x10/regionarray/BlockDistGhostManager.x10"
                    min$value$148542[(int)i$148537]=t$148532;
                    
                    //#line 90 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148533 = r.max$O((long)(i$148537));
                    
                    //#line 90 "x10/regionarray/BlockDistGhostManager.x10"
                    max$value$148543[(int)i$148537]=t$148533;
                }
                
                //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148536 = ((i$148537) + (((long)(1L))));
                
                //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
                i$148537 = t$148536;
            }
        }
        
        //#line 93 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.Region t$148376 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$Long$2__1$1x10$lang$Long$2(((x10.core.Rail)(min)), ((x10.core.Rail)(max)))));
        
        //#line 93 "x10/regionarray/BlockDistGhostManager.x10"
        return t$148376;
    }
    
    
    //#line 96 "x10/regionarray/BlockDistGhostManager.x10"
    public long getInverseNeighborIndex$O(final long neighborIndex) {
        
        //#line 97 "x10/regionarray/BlockDistGhostManager.x10"
        final boolean t$148380 = ((long) neighborIndex) == ((long) 0L);
        
        //#line 97 "x10/regionarray/BlockDistGhostManager.x10"
        if (t$148380) {
            
            //#line 97 "x10/regionarray/BlockDistGhostManager.x10"
            return 1L;
        } else {
            
            //#line 98 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$148379 = ((long) neighborIndex) == ((long) 1L);
            
            //#line 98 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$148379) {
                
                //#line 98 "x10/regionarray/BlockDistGhostManager.x10"
                return 0L;
            } else {
                
                //#line 99 "x10/regionarray/BlockDistGhostManager.x10"
                final java.lang.String t$148377 = (("no inverse neighbor found for neighborIndex ") + ((x10.core.Long.$box(neighborIndex))));
                
                //#line 99 "x10/regionarray/BlockDistGhostManager.x10"
                final java.lang.UnsupportedOperationException t$148378 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$148377)));
                
                //#line 99 "x10/regionarray/BlockDistGhostManager.x10"
                throw t$148378;
            }
        }
    }
    
    
    //#line 102 "x10/regionarray/BlockDistGhostManager.x10"
    public void setNeighborReceived(final x10.lang.Place place, final x10.lang.Point shift) {
        
        //#line 102 "x10/regionarray/BlockDistGhostManager.x10"
        try {{
            
            //#line 102 "x10/regionarray/BlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag t$148381 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
                
                //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.lang.Place t$148382 = ((x10.lang.Place)(t$148381.place));
                
                //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                boolean t$148385 = x10.rtt.Equality.equalsequals((t$148382),(place));
                
                //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                if (t$148385) {
                    
                    //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag t$148383 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
                    
                    //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                    final boolean t$148384 = t$148383.received;
                    
                    //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                    t$148385 = ((boolean) t$148384) == ((boolean) false);
                }
                
                //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                if (t$148385) {
                    
                    //#line 104 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag t$148386 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
                    
                    //#line 104 "x10/regionarray/BlockDistGhostManager.x10"
                    t$148386.received = true;
                } else {
                    
                    //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag t$148387 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
                    
                    //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Place t$148388 = ((x10.lang.Place)(t$148387.place));
                    
                    //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                    boolean t$148391 = x10.rtt.Equality.equalsequals((t$148388),(place));
                    
                    //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                    if (t$148391) {
                        
                        //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag t$148389 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
                        
                        //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                        final boolean t$148390 = t$148389.received;
                        
                        //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                        t$148391 = ((boolean) t$148390) == ((boolean) false);
                    }
                    
                    //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                    if (t$148391) {
                        
                        //#line 106 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag t$148392 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
                        
                        //#line 106 "x10/regionarray/BlockDistGhostManager.x10"
                        t$148392.received = true;
                    } else {
                        
                        //#line 108 "x10/regionarray/BlockDistGhostManager.x10"
                        final java.lang.String t$148393 = ((x10.x10rt.X10RT.here()) + (" trying to notify received from neighbor "));
                        
                        //#line 108 "x10/regionarray/BlockDistGhostManager.x10"
                        final java.lang.String t$148394 = ((t$148393) + (place));
                        
                        //#line 108 "x10/regionarray/BlockDistGhostManager.x10"
                        final java.lang.String t$148395 = ((t$148394) + (" - not a neighbor or already received!"));
                        
                        //#line 108 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.lang.BadPlaceException t$148396 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$148395)));
                        
                        //#line 108 "x10/regionarray/BlockDistGhostManager.x10"
                        throw t$148396;
                    }
                }
            }
        }}finally {{
              
              //#line 102 "x10/regionarray/BlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 113 "x10/regionarray/BlockDistGhostManager.x10"
    public boolean allNeighborsReceived$O() {
        
        //#line 113 "x10/regionarray/BlockDistGhostManager.x10"
        try {{
            
            //#line 113 "x10/regionarray/BlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 114 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag t$148399 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
                
                //#line 114 "x10/regionarray/BlockDistGhostManager.x10"
                boolean t$148401 = t$148399.received;
                
                //#line 114 "x10/regionarray/BlockDistGhostManager.x10"
                if (t$148401) {
                    
                    //#line 114 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag t$148400 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
                    
                    //#line 114 "x10/regionarray/BlockDistGhostManager.x10"
                    t$148401 = t$148400.received;
                }
                
                //#line 114 "x10/regionarray/BlockDistGhostManager.x10"
                return t$148401;
            }
        }}finally {{
              
              //#line 113 "x10/regionarray/BlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 117 "x10/regionarray/BlockDistGhostManager.x10"
    public void resetNeighborsReceived() {
        
        //#line 117 "x10/regionarray/BlockDistGhostManager.x10"
        try {{
            
            //#line 117 "x10/regionarray/BlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 118 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag t$148403 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
                
                //#line 118 "x10/regionarray/BlockDistGhostManager.x10"
                t$148403.received = false;
                
                //#line 119 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag t$148404 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
                
                //#line 119 "x10/regionarray/BlockDistGhostManager.x10"
                t$148404.received = false;
            }
        }}finally {{
              
              //#line 117 "x10/regionarray/BlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 122 "x10/regionarray/BlockDistGhostManager.x10"
    private void setAllNeighborsReceived() {
        
        //#line 122 "x10/regionarray/BlockDistGhostManager.x10"
        try {{
            
            //#line 122 "x10/regionarray/BlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 123 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag t$148405 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
                
                //#line 123 "x10/regionarray/BlockDistGhostManager.x10"
                t$148405.received = true;
                
                //#line 124 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag t$148406 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
                
                //#line 124 "x10/regionarray/BlockDistGhostManager.x10"
                t$148406.received = true;
            }
        }}finally {{
              
              //#line 122 "x10/regionarray/BlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    public static void setAllNeighborsReceived$P(final x10.regionarray.BlockDistGhostManager BlockDistGhostManager) {
        BlockDistGhostManager.setAllNeighborsReceived();
    }
    
    
    //#line 132 "x10/regionarray/BlockDistGhostManager.x10"
    /**
     * Send ghost data for this place to neighboring places in a BlockDist.
     * As this DistArray is only divided along one axis, data only need
     * to be sent along that axis.
     */
    public void sendGhosts(final x10.regionarray.Ghostable array) {
        
        //#line 133 "x10/regionarray/BlockDistGhostManager.x10"
        this.prepareToSendGhosts();
        
        //#line 135 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.BlockDist this$148271 = ((x10.regionarray.BlockDist)(this.bd));
        
        //#line 135 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.lang.Place p$148270 = ((x10.lang.Place)(x10.x10rt.X10RT.here()));
        
        //#line 135 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.Region r = ((x10.regionarray.Region)(this$148271.get(((x10.lang.Place)(p$148270)))));
        
        //#line 136 "x10/regionarray/BlockDistGhostManager.x10"
        final boolean t$148407 = r.isEmpty$O();
        
        //#line 136 "x10/regionarray/BlockDistGhostManager.x10"
        if (t$148407) {
            
            //#line 137 "x10/regionarray/BlockDistGhostManager.x10"
            this.setAllNeighborsReceived();
            
            //#line 138 "x10/regionarray/BlockDistGhostManager.x10"
            return;
        }
        
        //#line 141 "x10/regionarray/BlockDistGhostManager.x10"
        boolean t$148410 = this.periodic;
        
        //#line 141 "x10/regionarray/BlockDistGhostManager.x10"
        if (!(t$148410)) {
            
            //#line 141 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$148408 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
            
            //#line 141 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Place t$148409 = ((x10.lang.Place)(t$148408.place));
            
            //#line 141 "x10/regionarray/BlockDistGhostManager.x10"
            t$148410 = (!x10.rtt.Equality.equalsequals((t$148409),(x10.x10rt.X10RT.here())));
        }
        
        //#line 141 "x10/regionarray/BlockDistGhostManager.x10"
        if (t$148410) {
            
            //#line 142 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148412 = r.rank;
            
            //#line 142 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.fun.Fun_0_1 t$148413 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$173(r)));
            
            //#line 142 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.Rail leftMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148412)), ((x10.core.fun.Fun_0_1)(t$148413)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148422 = r.rank;
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.fun.Fun_0_1 t$148423 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$174(this, this.bd, r, this.ghostWidth)));
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.Rail leftMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148422)), ((x10.core.fun.Fun_0_1)(t$148423)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 144 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.Region leftReg = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$Long$2__1$1x10$lang$Long$2(((x10.core.Rail)(leftMin)), ((x10.core.Rail)(leftMax)))));
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148450 = r.rank;
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.fun.Fun_0_1 t$148451 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$175(this, this.bd, r)));
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.Rail shiftCoords = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148450)), ((x10.core.fun.Fun_0_1)(t$148451)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 150 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Point shift = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(shiftCoords)))));
            
            //#line 152 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$148452 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
            
            //#line 152 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Place t$148453 = ((x10.lang.Place)(t$148452.place));
            
            //#line 152 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager this$148273 = ((x10.regionarray.GhostManager)
                                                               this);
            
            //#line 43 . "x10/regionarray/GhostManager.x10"
            final byte t$148454 = this$148273.currentPhase;
            
            //#line 152 "x10/regionarray/BlockDistGhostManager.x10"
            array.putOverlap(((x10.regionarray.Region)(leftReg)), ((x10.lang.Place)(t$148453)), ((x10.lang.Point)(shift)), (byte)(t$148454));
        } else {
            
            //#line 154 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$148455 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
            
            //#line 154 "x10/regionarray/BlockDistGhostManager.x10"
            t$148455.received = true;
        }
        
        //#line 157 "x10/regionarray/BlockDistGhostManager.x10"
        boolean t$148459 = this.periodic;
        
        //#line 157 "x10/regionarray/BlockDistGhostManager.x10"
        if (!(t$148459)) {
            
            //#line 157 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$148457 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
            
            //#line 157 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Place t$148458 = ((x10.lang.Place)(t$148457.place));
            
            //#line 157 "x10/regionarray/BlockDistGhostManager.x10"
            t$148459 = (!x10.rtt.Equality.equalsequals((t$148458),(x10.x10rt.X10RT.here())));
        }
        
        //#line 157 "x10/regionarray/BlockDistGhostManager.x10"
        if (t$148459) {
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148468 = r.rank;
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.fun.Fun_0_1 t$148469 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$176(this, this.bd, r, this.ghostWidth)));
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.Rail rightMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148468)), ((x10.core.fun.Fun_0_1)(t$148469)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 159 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148471 = r.rank;
            
            //#line 159 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.fun.Fun_0_1 t$148472 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$177(r)));
            
            //#line 159 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.Rail rightMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148471)), ((x10.core.fun.Fun_0_1)(t$148472)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 160 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.Region rightReg = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$Long$2__1$1x10$lang$Long$2(((x10.core.Rail)(rightMin)), ((x10.core.Rail)(rightMax)))));
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148500 = r.rank;
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.fun.Fun_0_1 t$148501 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$178(this, this.bd, r)));
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.Rail shiftCoords = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148500)), ((x10.core.fun.Fun_0_1)(t$148501)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 166 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Point shift = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(shiftCoords)))));
            
            //#line 168 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$148502 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
            
            //#line 168 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Place t$148503 = ((x10.lang.Place)(t$148502.place));
            
            //#line 168 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager this$148275 = ((x10.regionarray.GhostManager)
                                                               this);
            
            //#line 43 . "x10/regionarray/GhostManager.x10"
            final byte t$148504 = this$148275.currentPhase;
            
            //#line 168 "x10/regionarray/BlockDistGhostManager.x10"
            array.putOverlap(((x10.regionarray.Region)(rightReg)), ((x10.lang.Place)(t$148503)), ((x10.lang.Point)(shift)), (byte)(t$148504));
        } else {
            
            //#line 170 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$148505 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
            
            //#line 170 "x10/regionarray/BlockDistGhostManager.x10"
            t$148505.received = true;
        }
    }
    
    
    //#line 18 "x10/regionarray/BlockDistGhostManager.x10"
    final public x10.regionarray.BlockDistGhostManager x10$regionarray$BlockDistGhostManager$$this$x10$regionarray$BlockDistGhostManager() {
        
        //#line 18 "x10/regionarray/BlockDistGhostManager.x10"
        return x10.regionarray.BlockDistGhostManager.this;
    }
    
    
    //#line 18 "x10/regionarray/BlockDistGhostManager.x10"
    final public void __fieldInitializers_x10_regionarray_BlockDistGhostManager() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$167 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$167> $RTT = 
            x10.rtt.StaticFunType.<$Closure$167> make($Closure$167.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$167 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$167 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$167((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure$167(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 35 "x10/regionarray/BlockDistGhostManager.x10"
            return 0L;
        }
        
        public $Closure$167() {
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$168 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$168> $RTT = 
            x10.rtt.StaticFunType.<$Closure$168> make($Closure$168.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$168 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.bd = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$168 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$168((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.bd);
            
        }
        
        // constructor just for allocation
        public $Closure$168(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148287 = this.bd.axis;
            
            //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$148296 = ((long) i) == ((long) t$148287);
            
            //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
            long t$148297 =  0;
            
            //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$148296) {
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.Region t$148288 = ((x10.regionarray.Region)(this.bd.region));
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148289 = this.bd.axis;
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148292 = t$148288.max$O((long)(t$148289));
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.Region t$148290 = ((x10.regionarray.Region)(this.bd.region));
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148291 = this.bd.axis;
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148293 = t$148290.min$O((long)(t$148291));
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148294 = ((t$148292) - (((long)(t$148293))));
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148295 = ((t$148294) + (((long)(1L))));
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                t$148297 = (-(t$148295));
            } else {
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                t$148297 = 0L;
            }
            
            //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
            return t$148297;
        }
        
        public x10.regionarray.BlockDist bd;
        
        public $Closure$168(final x10.regionarray.BlockDist bd) {
             {
                this.bd = ((x10.regionarray.BlockDist)(bd));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$169 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$169> $RTT = 
            x10.rtt.StaticFunType.<$Closure$169> make($Closure$169.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$169 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$169 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$169((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure$169(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 41 "x10/regionarray/BlockDistGhostManager.x10"
            return 0L;
        }
        
        public $Closure$169() {
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$170 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$170> $RTT = 
            x10.rtt.StaticFunType.<$Closure$170> make($Closure$170.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$170 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$170 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$170((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure$170(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 49 "x10/regionarray/BlockDistGhostManager.x10"
            return 0L;
        }
        
        public $Closure$170() {
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$171 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$171> $RTT = 
            x10.rtt.StaticFunType.<$Closure$171> make($Closure$171.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$171 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.bd = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$171 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$171((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.bd);
            
        }
        
        // constructor just for allocation
        public $Closure$171(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148317 = this.bd.axis;
            
            //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$148325 = ((long) i) == ((long) t$148317);
            
            //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
            long t$148326 =  0;
            
            //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$148325) {
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.Region t$148318 = ((x10.regionarray.Region)(this.bd.region));
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148319 = this.bd.axis;
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148322 = t$148318.max$O((long)(t$148319));
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.Region t$148320 = ((x10.regionarray.Region)(this.bd.region));
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148321 = this.bd.axis;
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148323 = t$148320.min$O((long)(t$148321));
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148324 = ((t$148322) - (((long)(t$148323))));
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                t$148326 = ((t$148324) + (((long)(1L))));
            } else {
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                t$148326 = 0L;
            }
            
            //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
            return t$148326;
        }
        
        public x10.regionarray.BlockDist bd;
        
        public $Closure$171(final x10.regionarray.BlockDist bd) {
             {
                this.bd = ((x10.regionarray.BlockDist)(bd));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$172 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$172> $RTT = 
            x10.rtt.StaticFunType.<$Closure$172> make($Closure$172.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$172 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$172 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$172((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure$172(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 55 "x10/regionarray/BlockDistGhostManager.x10"
            return 0L;
        }
        
        public $Closure$172() {
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$173 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$173> $RTT = 
            x10.rtt.StaticFunType.<$Closure$173> make($Closure$173.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$173 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$173 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$173((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$173(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 142 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148411 = this.r.min$O((long)(i));
            
            //#line 142 "x10/regionarray/BlockDistGhostManager.x10"
            return t$148411;
        }
        
        public x10.regionarray.Region r;
        
        public $Closure$173(final x10.regionarray.Region r) {
             {
                this.r = ((x10.regionarray.Region)(r));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$174 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$174> $RTT = 
            x10.rtt.StaticFunType.<$Closure$174> make($Closure$174.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$174 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.bd = $deserializer.readObject();
            $_obj.ghostWidth = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$174 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$174((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.bd);
            $serializer.write(this.ghostWidth);
            $serializer.write(this.out$$);
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$174(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.BlockDist t$148414 = ((x10.regionarray.BlockDist)(this.bd));
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148415 = t$148414.axis;
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$148419 = ((long) i) == ((long) t$148415);
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            long t$148420 =  0;
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$148419) {
                
                //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148416 = this.r.min$O((long)(i));
                
                //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148417 = this.ghostWidth;
                
                //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148418 = ((t$148416) + (((long)(t$148417))));
                
                //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
                t$148420 = ((t$148418) - (((long)(1L))));
            } else {
                
                //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
                t$148420 = this.r.max$O((long)(i));
            }
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            return t$148420;
        }
        
        public x10.regionarray.BlockDistGhostManager out$$;
        public x10.regionarray.BlockDist bd;
        public x10.regionarray.Region r;
        public long ghostWidth;
        
        public $Closure$174(final x10.regionarray.BlockDistGhostManager out$$, final x10.regionarray.BlockDist bd, final x10.regionarray.Region r, final long ghostWidth) {
             {
                this.out$$ = out$$;
                this.bd = ((x10.regionarray.BlockDist)(bd));
                this.r = ((x10.regionarray.Region)(r));
                this.ghostWidth = ghostWidth;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$175 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$175> $RTT = 
            x10.rtt.StaticFunType.<$Closure$175> make($Closure$175.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$175 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.bd = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$175 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$175((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.bd);
            $serializer.write(this.out$$);
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$175(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.BlockDist t$148424 = ((x10.regionarray.BlockDist)(this.bd));
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148425 = t$148424.axis;
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$148447 = ((long) i) == ((long) t$148425);
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            long t$148448 =  0;
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$148447) {
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$148426 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148427 = t$148426.axis;
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148432 = this.r.min$O((long)(t$148427));
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$148428 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.Region t$148430 = ((x10.regionarray.Region)(t$148428.region));
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$148429 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148431 = t$148429.axis;
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148433 = t$148430.min$O((long)(t$148431));
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final boolean t$148445 = ((long) t$148432) == ((long) t$148433);
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                long t$148446 =  0;
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                if (t$148445) {
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$148434 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.Region t$148436 = ((x10.regionarray.Region)(t$148434.region));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$148435 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148437 = t$148435.axis;
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148442 = t$148436.max$O((long)(t$148437));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$148438 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.Region t$148440 = ((x10.regionarray.Region)(t$148438.region));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$148439 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148441 = t$148439.axis;
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148443 = t$148440.min$O((long)(t$148441));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148444 = ((t$148442) - (((long)(t$148443))));
                    
                    //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                    t$148446 = ((t$148444) + (((long)(1L))));
                } else {
                    
                    //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                    t$148446 = 0L;
                }
                
                //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
                t$148448 = t$148446;
            } else {
                
                //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
                t$148448 = 0L;
            }
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            return t$148448;
        }
        
        public x10.regionarray.BlockDistGhostManager out$$;
        public x10.regionarray.BlockDist bd;
        public x10.regionarray.Region r;
        
        public $Closure$175(final x10.regionarray.BlockDistGhostManager out$$, final x10.regionarray.BlockDist bd, final x10.regionarray.Region r) {
             {
                this.out$$ = out$$;
                this.bd = ((x10.regionarray.BlockDist)(bd));
                this.r = ((x10.regionarray.Region)(r));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$176 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$176> $RTT = 
            x10.rtt.StaticFunType.<$Closure$176> make($Closure$176.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$176 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.bd = $deserializer.readObject();
            $_obj.ghostWidth = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$176 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$176((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.bd);
            $serializer.write(this.ghostWidth);
            $serializer.write(this.out$$);
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$176(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.BlockDist t$148460 = ((x10.regionarray.BlockDist)(this.bd));
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148461 = t$148460.axis;
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$148465 = ((long) i) == ((long) t$148461);
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            long t$148466 =  0;
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$148465) {
                
                //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148462 = this.r.max$O((long)(i));
                
                //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148463 = this.ghostWidth;
                
                //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148464 = ((t$148462) - (((long)(t$148463))));
                
                //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
                t$148466 = ((t$148464) + (((long)(1L))));
            } else {
                
                //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
                t$148466 = this.r.min$O((long)(i));
            }
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            return t$148466;
        }
        
        public x10.regionarray.BlockDistGhostManager out$$;
        public x10.regionarray.BlockDist bd;
        public x10.regionarray.Region r;
        public long ghostWidth;
        
        public $Closure$176(final x10.regionarray.BlockDistGhostManager out$$, final x10.regionarray.BlockDist bd, final x10.regionarray.Region r, final long ghostWidth) {
             {
                this.out$$ = out$$;
                this.bd = ((x10.regionarray.BlockDist)(bd));
                this.r = ((x10.regionarray.Region)(r));
                this.ghostWidth = ghostWidth;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$177 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$177> $RTT = 
            x10.rtt.StaticFunType.<$Closure$177> make($Closure$177.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$177 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$177 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$177((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$177(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 159 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148470 = this.r.max$O((long)(i));
            
            //#line 159 "x10/regionarray/BlockDistGhostManager.x10"
            return t$148470;
        }
        
        public x10.regionarray.Region r;
        
        public $Closure$177(final x10.regionarray.Region r) {
             {
                this.r = ((x10.regionarray.Region)(r));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$178 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$178> $RTT = 
            x10.rtt.StaticFunType.<$Closure$178> make($Closure$178.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$178 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.bd = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$178 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$178((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.bd);
            $serializer.write(this.out$$);
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$178(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.BlockDist t$148473 = ((x10.regionarray.BlockDist)(this.bd));
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148474 = t$148473.axis;
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$148497 = ((long) i) == ((long) t$148474);
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            long t$148498 =  0;
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$148497) {
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$148475 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148476 = t$148475.axis;
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148481 = this.r.max$O((long)(t$148476));
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$148477 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.Region t$148479 = ((x10.regionarray.Region)(t$148477.region));
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$148478 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148480 = t$148478.axis;
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148482 = t$148479.max$O((long)(t$148480));
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final boolean t$148495 = ((long) t$148481) == ((long) t$148482);
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                long t$148496 =  0;
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                if (t$148495) {
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$148483 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.Region t$148485 = ((x10.regionarray.Region)(t$148483.region));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$148484 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148486 = t$148484.axis;
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148491 = t$148485.max$O((long)(t$148486));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$148487 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.Region t$148489 = ((x10.regionarray.Region)(t$148487.region));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$148488 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148490 = t$148488.axis;
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148492 = t$148489.min$O((long)(t$148490));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148493 = ((t$148491) - (((long)(t$148492))));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148494 = ((t$148493) + (((long)(1L))));
                    
                    //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                    t$148496 = (-(t$148494));
                } else {
                    
                    //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                    t$148496 = 0L;
                }
                
                //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
                t$148498 = t$148496;
            } else {
                
                //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
                t$148498 = 0L;
            }
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            return t$148498;
        }
        
        public x10.regionarray.BlockDistGhostManager out$$;
        public x10.regionarray.BlockDist bd;
        public x10.regionarray.Region r;
        
        public $Closure$178(final x10.regionarray.BlockDistGhostManager out$$, final x10.regionarray.BlockDist bd, final x10.regionarray.Region r) {
             {
                this.out$$ = out$$;
                this.bd = ((x10.regionarray.BlockDist)(bd));
                this.r = ((x10.regionarray.Region)(r));
            }
        }
        
    }
    
    }
    
    