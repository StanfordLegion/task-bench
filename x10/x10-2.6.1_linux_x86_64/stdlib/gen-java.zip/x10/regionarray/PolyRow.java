package x10.regionarray;


/**
 * This class represents a single polyhedral halfspace of the form
 *
 *     a0*x0 + a1*x1 + ... + constant <= 0
 *
 * The a's are stored in the first rank elements of ValRow.this; the
 * constant is stored in this(rank) (using homogeneous coordinates).
 *
 * Equivalently, this class may be considered to represent a linear
 * inequality constraint, or a row in a constraint matrix.
 */
@x10.runtime.impl.java.X10Generated
public class PolyRow extends x10.regionarray.ValRow implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PolyRow> $RTT = 
        x10.rtt.NamedType.<PolyRow> make("x10.regionarray.PolyRow",
                                         PolyRow.class,
                                         new x10.rtt.Type[] {
                                             x10.regionarray.ValRow.$RTT
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyRow $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.ValRow.$_deserialize_body($_obj, $deserializer);
        $_obj.rank = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.PolyRow $_obj = new x10.regionarray.PolyRow((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.rank);
        
    }
    
    // constructor just for allocation
    public PolyRow(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$Int$2 {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Int$3x10$lang$Int$2 {}
    
    // properties
    
    //#line 27 "x10/regionarray/PolyRow.x10"
    public long rank;
    

    
    
    //#line 29 "x10/regionarray/PolyRow.x10"
    // creation method for java code (1-phase java constructor)
    public PolyRow(final x10.core.Rail<x10.core.Int> as_, __0$1x10$lang$Int$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyRow$$init$S(as_, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyRow x10$regionarray$PolyRow$$init$S(final x10.core.Rail<x10.core.Int> as_, __0$1x10$lang$Int$2 $dummy) {
         {
            
            //#line 29 "x10/regionarray/PolyRow.x10"
            final long t$154917 = ((x10.core.Rail<x10.core.Int>)as_).size;
            
            //#line 29 "x10/regionarray/PolyRow.x10"
            final long t$154918 = ((t$154917) - (((long)(1L))));
            
            //#line 29 "x10/regionarray/PolyRow.x10"
            /*this.*/x10$regionarray$PolyRow$$init$S(((x10.core.Rail)(as_)), t$154918, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
        }
        return this;
    }
    
    
    
    //#line 31 "x10/regionarray/PolyRow.x10"
    // creation method for java code (1-phase java constructor)
    public PolyRow(final x10.core.Rail<x10.core.Int> as_, final long n, __0$1x10$lang$Int$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyRow$$init$S(as_, n, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyRow x10$regionarray$PolyRow$$init$S(final x10.core.Rail<x10.core.Int> as_, final long n, __0$1x10$lang$Int$2 $dummy) {
         {
            
            //#line 32 "x10/regionarray/PolyRow.x10"
            /*super.*/x10$regionarray$ValRow$$init$S(((x10.core.Rail)(as_)), (x10.regionarray.ValRow.__0$1x10$lang$Int$2) null);
            
            //#line 33 "x10/regionarray/PolyRow.x10"
            final long t$155069 = n;
            
            //#line 33 "x10/regionarray/PolyRow.x10"
            this.rank = t$155069;
            
        }
        return this;
    }
    
    
    
    //#line 36 "x10/regionarray/PolyRow.x10"
    // creation method for java code (1-phase java constructor)
    public PolyRow(final x10.lang.Point p, final int k) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyRow$$init$S(p, k);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyRow x10$regionarray$PolyRow$$init$S(final x10.lang.Point p, final int k) {
         {
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final long t$155072 = p.rank;
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final long t$155073 = ((t$155072) + (((long)(1L))));
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final int t$155074 = ((int)(long)(((long)(t$155073))));
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final x10.core.fun.Fun_0_1 t$155075 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyRow.$Closure$214(p, k)));
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            /*super.*/x10$regionarray$ValRow$$init$S(t$155074, ((x10.core.fun.Fun_0_1)(t$155075)), (x10.regionarray.ValRow.__1$1x10$lang$Int$3x10$lang$Int$2) null);
            
            //#line 38 "x10/regionarray/PolyRow.x10"
            final long t$155071 = p.rank;
            
            //#line 38 "x10/regionarray/PolyRow.x10"
            this.rank = t$155071;
            
        }
        return this;
    }
    
    
    
    //#line 41 "x10/regionarray/PolyRow.x10"
    // creation method for java code (1-phase java constructor)
    public PolyRow(final int cols, final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int> init, __1$1x10$lang$Int$3x10$lang$Int$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyRow$$init$S(cols, init, (x10.regionarray.PolyRow.__1$1x10$lang$Int$3x10$lang$Int$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyRow x10$regionarray$PolyRow$$init$S(final int cols, final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int> init, __1$1x10$lang$Int$3x10$lang$Int$2 $dummy) {
         {
            
            //#line 42 "x10/regionarray/PolyRow.x10"
            /*super.*/x10$regionarray$ValRow$$init$S(((int)(cols)), ((x10.core.fun.Fun_0_1)(init)), (x10.regionarray.ValRow.__1$1x10$lang$Int$3x10$lang$Int$2) null);
            
            //#line 43 "x10/regionarray/PolyRow.x10"
            final int cols1 = ((cols) - (((int)(1))));
            
            //#line 44 "x10/regionarray/PolyRow.x10"
            final long t$155085 = ((long)(((int)(cols1))));
            
            //#line 44 "x10/regionarray/PolyRow.x10"
            this.rank = t$155085;
            
        }
        return this;
    }
    
    
    
    //#line 53 "x10/regionarray/PolyRow.x10"
    /**
     * natural sort order for halfspaces: from lo to hi on each
     * axis, from most major to least major axis, with constant as
     * least siginficant part of key
     */
    public static int compare$O(final x10.regionarray.Row a, final x10.regionarray.Row b) {
        
        //#line 54 "x10/regionarray/PolyRow.x10"
        int i$155099 = 0;
        
        //#line 54 "x10/regionarray/PolyRow.x10"
        for (;
             true;
             ) {
            
            //#line 54 "x10/regionarray/PolyRow.x10"
            final int t$155101 = a.cols;
            
            //#line 54 "x10/regionarray/PolyRow.x10"
            final boolean t$155102 = ((i$155099) < (((int)(t$155101))));
            
            //#line 54 "x10/regionarray/PolyRow.x10"
            if (!(t$155102)) {
                
                //#line 54 "x10/regionarray/PolyRow.x10"
                break;
            }
            
            //#line 55 "x10/regionarray/PolyRow.x10"
            final int t$155088 = a.$apply$O((int)(i$155099));
            
            //#line 55 "x10/regionarray/PolyRow.x10"
            final int t$155090 = b.$apply$O((int)(i$155099));
            
            //#line 55 "x10/regionarray/PolyRow.x10"
            final boolean t$155091 = ((t$155088) < (((int)(t$155090))));
            
            //#line 55 "x10/regionarray/PolyRow.x10"
            if (t$155091) {
                
                //#line 56 "x10/regionarray/PolyRow.x10"
                return -1;
            } else {
                
                //#line 57 "x10/regionarray/PolyRow.x10"
                final int t$155093 = a.$apply$O((int)(i$155099));
                
                //#line 57 "x10/regionarray/PolyRow.x10"
                final int t$155095 = b.$apply$O((int)(i$155099));
                
                //#line 57 "x10/regionarray/PolyRow.x10"
                final boolean t$155096 = ((t$155093) > (((int)(t$155095))));
                
                //#line 57 "x10/regionarray/PolyRow.x10"
                if (t$155096) {
                    
                    //#line 58 "x10/regionarray/PolyRow.x10"
                    return 1;
                }
            }
            
            //#line 54 "x10/regionarray/PolyRow.x10"
            final int t$155098 = ((i$155099) + (((int)(1))));
            
            //#line 54 "x10/regionarray/PolyRow.x10"
            i$155099 = t$155098;
        }
        
        //#line 60 "x10/regionarray/PolyRow.x10"
        return 0;
    }
    
    
    //#line 71 "x10/regionarray/PolyRow.x10"
    /**
     * two halfspaces are parallel if all coefficients are the
     * same; constants may differ
     *
     * XXX only right if first coefficients are the same; needs to
     * allow for multiplication by positive constant
     */
    public boolean isParallel$O(final x10.regionarray.PolyRow that) {
        
        //#line 72 "x10/regionarray/PolyRow.x10"
        int i$155110 = 0;
        
        //#line 72 "x10/regionarray/PolyRow.x10"
        for (;
             true;
             ) {
            
            //#line 72 "x10/regionarray/PolyRow.x10"
            final int t$155112 = this.cols;
            
            //#line 72 "x10/regionarray/PolyRow.x10"
            final int t$155113 = ((t$155112) - (((int)(1))));
            
            //#line 72 "x10/regionarray/PolyRow.x10"
            final boolean t$155114 = ((i$155110) < (((int)(t$155113))));
            
            //#line 72 "x10/regionarray/PolyRow.x10"
            if (!(t$155114)) {
                
                //#line 72 "x10/regionarray/PolyRow.x10"
                break;
            }
            
            //#line 73 "x10/regionarray/PolyRow.x10"
            final int t$155104 = this.$apply$O((int)(i$155110));
            
            //#line 73 "x10/regionarray/PolyRow.x10"
            final int t$155106 = that.$apply$O((int)(i$155110));
            
            //#line 73 "x10/regionarray/PolyRow.x10"
            final boolean t$155107 = ((int) t$155104) != ((int) t$155106);
            
            //#line 73 "x10/regionarray/PolyRow.x10"
            if (t$155107) {
                
                //#line 74 "x10/regionarray/PolyRow.x10"
                return false;
            }
            
            //#line 72 "x10/regionarray/PolyRow.x10"
            final int t$155109 = ((i$155110) + (((int)(1))));
            
            //#line 72 "x10/regionarray/PolyRow.x10"
            i$155110 = t$155109;
        }
        
        //#line 75 "x10/regionarray/PolyRow.x10"
        return true;
    }
    
    
    //#line 83 "x10/regionarray/PolyRow.x10"
    /**
     * halfspace is rectangular if only one coefficent is
     * non-zero
     */
    public boolean isRect$O() {
        
        //#line 84 "x10/regionarray/PolyRow.x10"
        boolean nz = false;
        
        //#line 85 "x10/regionarray/PolyRow.x10"
        int i$155121 = 0;
        
        //#line 85 "x10/regionarray/PolyRow.x10"
        for (;
             true;
             ) {
            
            //#line 85 "x10/regionarray/PolyRow.x10"
            final int t$155123 = this.cols;
            
            //#line 85 "x10/regionarray/PolyRow.x10"
            final int t$155124 = ((t$155123) - (((int)(1))));
            
            //#line 85 "x10/regionarray/PolyRow.x10"
            final boolean t$155125 = ((i$155121) < (((int)(t$155124))));
            
            //#line 85 "x10/regionarray/PolyRow.x10"
            if (!(t$155125)) {
                
                //#line 85 "x10/regionarray/PolyRow.x10"
                break;
            }
            
            //#line 86 "x10/regionarray/PolyRow.x10"
            final int t$155116 = this.$apply$O((int)(i$155121));
            
            //#line 86 "x10/regionarray/PolyRow.x10"
            final boolean t$155117 = ((int) t$155116) != ((int) 0);
            
            //#line 86 "x10/regionarray/PolyRow.x10"
            if (t$155117) {
                
                //#line 87 "x10/regionarray/PolyRow.x10"
                if (nz) {
                    
                    //#line 87 "x10/regionarray/PolyRow.x10"
                    return false;
                }
                
                //#line 88 "x10/regionarray/PolyRow.x10"
                nz = true;
            }
            
            //#line 85 "x10/regionarray/PolyRow.x10"
            final int t$155120 = ((i$155121) + (((int)(1))));
            
            //#line 85 "x10/regionarray/PolyRow.x10"
            i$155121 = t$155120;
        }
        
        //#line 91 "x10/regionarray/PolyRow.x10"
        return true;
    }
    
    
    //#line 98 "x10/regionarray/PolyRow.x10"
    /**
     * determine whether point satisfies halfspace
     */
    public boolean contains$O(final x10.lang.Point p) {
        
        //#line 99 "x10/regionarray/PolyRow.x10"
        final long t$154972 = this.rank;
        
        //#line 99 "x10/regionarray/PolyRow.x10"
        final int t$154973 = ((int)(long)(((long)(t$154972))));
        
        //#line 99 "x10/regionarray/PolyRow.x10"
        int sum = this.$apply$O((int)(t$154973));
        
        //#line 100 "x10/regionarray/PolyRow.x10"
        int i$155138 = 0;
        
        //#line 100 "x10/regionarray/PolyRow.x10"
        for (;
             true;
             ) {
            
            //#line 100 "x10/regionarray/PolyRow.x10"
            final long t$155140 = ((long)(((int)(i$155138))));
            
            //#line 100 "x10/regionarray/PolyRow.x10"
            final long t$155141 = this.rank;
            
            //#line 100 "x10/regionarray/PolyRow.x10"
            final boolean t$155142 = ((t$155140) < (((long)(t$155141))));
            
            //#line 100 "x10/regionarray/PolyRow.x10"
            if (!(t$155142)) {
                
                //#line 100 "x10/regionarray/PolyRow.x10"
                break;
            }
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final long t$155127 = ((long)(((int)(sum))));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final int t$155129 = this.$apply$O((int)(i$155138));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final long t$155130 = ((long)(((int)(t$155129))));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final long t$155132 = ((long)(((int)(i$155138))));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final long t$155133 = p.$apply$O((long)(t$155132));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final long t$155134 = ((t$155130) * (((long)(t$155133))));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final long t$155135 = ((t$155127) + (((long)(t$155134))));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            sum = ((int)(((long)(t$155135))));
            
            //#line 100 "x10/regionarray/PolyRow.x10"
            final int t$155137 = ((i$155138) + (((int)(1))));
            
            //#line 100 "x10/regionarray/PolyRow.x10"
            i$155138 = t$155137;
        }
        
        //#line 102 "x10/regionarray/PolyRow.x10"
        final boolean t$154992 = ((sum) <= (((int)(0))));
        
        //#line 102 "x10/regionarray/PolyRow.x10"
        return t$154992;
    }
    
    
    //#line 115 "x10/regionarray/PolyRow.x10"
    /**
     * given
     *    a0*x0 + ... +ar   <=  0
     * complement is
     *    a0*x0 + ... +ar   >   0
     *   -a0*x0 - ... -ar   <   0
     *   -a0*x0 - ... -ar   <= -1
     *   -a0*x0 - ... -ar+1 <=  0
     */
    public x10.regionarray.PolyRow complement() {
        
        //#line 117 "x10/regionarray/PolyRow.x10"
        final long t$154993 = this.rank;
        
        //#line 117 "x10/regionarray/PolyRow.x10"
        final long t$154994 = ((long)(((int)(1))));
        
        //#line 117 "x10/regionarray/PolyRow.x10"
        final long t$155007 = ((t$154993) + (((long)(t$154994))));
        
        //#line 116 "x10/regionarray/PolyRow.x10"
        final x10.core.fun.Fun_0_1 t$155008 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyRow.$Closure$215(this, this.rank)));
        
        //#line 117 "x10/regionarray/PolyRow.x10"
        final x10.core.Rail as_ = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, t$155007, ((x10.core.fun.Fun_0_1)(t$155008)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 118 "x10/regionarray/PolyRow.x10"
        final x10.regionarray.PolyRow alloc$152705 = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
        
        //#line 29 . "x10/regionarray/PolyRow.x10"
        final long t$155143 = ((x10.core.Rail<x10.core.Int>)as_).size;
        
        //#line 29 . "x10/regionarray/PolyRow.x10"
        final long t$155144 = ((t$155143) - (((long)(1L))));
        
        //#line 29 . "x10/regionarray/PolyRow.x10"
        alloc$152705.x10$regionarray$PolyRow$$init$S(((x10.core.Rail)(as_)), t$155144, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
        
        //#line 118 "x10/regionarray/PolyRow.x10"
        return alloc$152705;
    }
    
    
    //#line 125 "x10/regionarray/PolyRow.x10"
    /**
     * print a halfspace in equation form
     */
    public void printEqn(final x10.io.Printer ps, final java.lang.String spc, final int row) {
        
        //#line 126 "x10/regionarray/PolyRow.x10"
        int sgn = 0;
        
        //#line 127 "x10/regionarray/PolyRow.x10"
        boolean first = true;
        
        //#line 128 "x10/regionarray/PolyRow.x10"
        int i$155181 = 0;
        
        //#line 128 "x10/regionarray/PolyRow.x10"
        for (;
             true;
             ) {
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            final long t$155183 = ((long)(((int)(i$155181))));
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            final int t$155184 = this.cols;
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            final long t$155185 = ((long)(((int)(t$155184))));
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            final long t$155186 = ((t$155185) - (((long)(1L))));
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            final boolean t$155187 = ((t$155183) < (((long)(t$155186))));
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            if (!(t$155187)) {
                
                //#line 128 "x10/regionarray/PolyRow.x10"
                break;
            }
            
            //#line 129 "x10/regionarray/PolyRow.x10"
            final boolean t$155146 = ((int) sgn) == ((int) 0);
            
            //#line 129 "x10/regionarray/PolyRow.x10"
            if (t$155146) {
                
                //#line 130 "x10/regionarray/PolyRow.x10"
                final int t$155148 = this.$apply$O((int)(i$155181));
                
                //#line 130 "x10/regionarray/PolyRow.x10"
                final boolean t$155149 = ((t$155148) < (((int)(0))));
                
                //#line 130 "x10/regionarray/PolyRow.x10"
                if (t$155149) {
                    
                    //#line 131 "x10/regionarray/PolyRow.x10"
                    sgn = -1;
                } else {
                    
                    //#line 132 "x10/regionarray/PolyRow.x10"
                    final int t$155151 = this.$apply$O((int)(i$155181));
                    
                    //#line 132 "x10/regionarray/PolyRow.x10"
                    final boolean t$155152 = ((t$155151) > (((int)(0))));
                    
                    //#line 132 "x10/regionarray/PolyRow.x10"
                    if (t$155152) {
                        
                        //#line 133 "x10/regionarray/PolyRow.x10"
                        sgn = 1;
                    }
                }
            }
            
            //#line 135 "x10/regionarray/PolyRow.x10"
            final int t$155155 = this.$apply$O((int)(i$155181));
            
            //#line 135 "x10/regionarray/PolyRow.x10"
            final int c$155156 = ((sgn) * (((int)(t$155155))));
            
            //#line 136 "x10/regionarray/PolyRow.x10"
            final boolean t$155157 = ((int) c$155156) == ((int) 1);
            
            //#line 136 "x10/regionarray/PolyRow.x10"
            if (t$155157) {
                
                //#line 137 "x10/regionarray/PolyRow.x10"
                if (first) {
                    
                    //#line 138 "x10/regionarray/PolyRow.x10"
                    final java.lang.String t$155160 = (("x") + ((x10.core.Int.$box(i$155181))));
                    
                    //#line 138 "x10/regionarray/PolyRow.x10"
                    ps.print(((java.lang.String)(t$155160)));
                } else {
                    
                    //#line 140 "x10/regionarray/PolyRow.x10"
                    final java.lang.String t$155162 = (("+x") + ((x10.core.Int.$box(i$155181))));
                    
                    //#line 140 "x10/regionarray/PolyRow.x10"
                    ps.print(((java.lang.String)(t$155162)));
                }
            } else {
                
                //#line 141 "x10/regionarray/PolyRow.x10"
                final boolean t$155163 = ((int) c$155156) == ((int) -1);
                
                //#line 141 "x10/regionarray/PolyRow.x10"
                if (t$155163) {
                    
                    //#line 142 "x10/regionarray/PolyRow.x10"
                    final java.lang.String t$155165 = (("-x") + ((x10.core.Int.$box(i$155181))));
                    
                    //#line 142 "x10/regionarray/PolyRow.x10"
                    ps.print(((java.lang.String)(t$155165)));
                } else {
                    
                    //#line 143 "x10/regionarray/PolyRow.x10"
                    final boolean t$155166 = ((int) c$155156) != ((int) 0);
                    
                    //#line 143 "x10/regionarray/PolyRow.x10"
                    if (t$155166) {
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        final long t$155167 = ((long)(((int)(c$155156))));
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        boolean t$155168 = ((t$155167) >= (((long)(0L))));
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        if (t$155168) {
                            
                            //#line 144 "x10/regionarray/PolyRow.x10"
                            t$155168 = !(first);
                        }
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        java.lang.String t$155171 =  null;
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        if (t$155168) {
                            
                            //#line 144 "x10/regionarray/PolyRow.x10"
                            t$155171 = "+";
                        } else {
                            
                            //#line 144 "x10/regionarray/PolyRow.x10"
                            t$155171 = "";
                        }
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        final java.lang.String t$155173 = ((t$155171) + ((x10.core.Int.$box(c$155156))));
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        final java.lang.String t$155174 = ((t$155173) + ("*x"));
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        final java.lang.String t$155176 = ((t$155174) + ((x10.core.Int.$box(i$155181))));
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        final java.lang.String t$155177 = ((t$155176) + (" "));
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        ps.print(((java.lang.String)(t$155177)));
                    }
                }
            }
            
            //#line 145 "x10/regionarray/PolyRow.x10"
            final boolean t$155178 = ((int) c$155156) != ((int) 0);
            
            //#line 145 "x10/regionarray/PolyRow.x10"
            if (t$155178) {
                
                //#line 146 "x10/regionarray/PolyRow.x10"
                first = false;
            }
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            final int t$155180 = ((i$155181) + (((int)(1))));
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            i$155181 = t$155180;
        }
        
        //#line 148 "x10/regionarray/PolyRow.x10"
        if (first) {
            
            //#line 149 "x10/regionarray/PolyRow.x10"
            ps.print(((java.lang.String)("0")));
        }
        
        //#line 150 "x10/regionarray/PolyRow.x10"
        final boolean t$155068 = ((sgn) > (((int)(0))));
        
        //#line 150 "x10/regionarray/PolyRow.x10"
        if (t$155068) {
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final java.lang.String t$155055 = ((spc) + ("<="));
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final java.lang.String t$155059 = ((t$155055) + (spc));
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final int t$155056 = this.cols;
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final int t$155057 = ((t$155056) - (((int)(1))));
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final int t$155058 = this.$apply$O((int)(t$155057));
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final int t$155060 = (-(t$155058));
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final java.lang.String t$155061 = ((t$155059) + ((x10.core.Int.$box(t$155060))));
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            ps.print(((java.lang.String)(t$155061)));
        } else {
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            final java.lang.String t$155062 = ((spc) + (">="));
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            final java.lang.String t$155065 = ((t$155062) + (spc));
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            final int t$155063 = this.cols;
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            final int t$155064 = ((t$155063) - (((int)(1))));
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            final int t$155066 = this.$apply$O((int)(t$155064));
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            final java.lang.String t$155067 = ((t$155065) + ((x10.core.Int.$box(t$155066))));
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            ps.print(((java.lang.String)(t$155067)));
        }
    }
    
    
    //#line 27 "x10/regionarray/PolyRow.x10"
    final public x10.regionarray.PolyRow x10$regionarray$PolyRow$$this$x10$regionarray$PolyRow() {
        
        //#line 27 "x10/regionarray/PolyRow.x10"
        return x10.regionarray.PolyRow.this;
    }
    
    
    //#line 27 "x10/regionarray/PolyRow.x10"
    final public void __fieldInitializers_x10_regionarray_PolyRow() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$214 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$214> $RTT = 
            x10.rtt.StaticFunType.<$Closure$214> make($Closure$214.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyRow.$Closure$214 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.k = $deserializer.readInt();
            $_obj.p = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyRow.$Closure$214 $_obj = new x10.regionarray.PolyRow.$Closure$214((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.k);
            $serializer.write(this.p);
            
        }
        
        // constructor just for allocation
        public $Closure$214(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Int.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Int.$unbox(a1));
            
        }
        
        
    
        
        public int $apply$O(final int i$155076) {
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final long t$155077 = ((long)(((int)(i$155076))));
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final long t$155078 = this.p.rank;
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final boolean t$155079 = ((t$155077) < (((long)(t$155078))));
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            int t$155080 =  0;
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            if (t$155079) {
                
                //#line 37 "x10/regionarray/PolyRow.x10"
                final long t$155081 = ((long)(((int)(i$155076))));
                
                //#line 37 "x10/regionarray/PolyRow.x10"
                final long t$155082 = this.p.$apply$O((long)(t$155081));
                
                //#line 37 "x10/regionarray/PolyRow.x10"
                t$155080 = ((int)(long)(((long)(t$155082))));
            } else {
                
                //#line 37 "x10/regionarray/PolyRow.x10"
                t$155080 = this.k;
            }
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            return t$155080;
        }
        
        public x10.lang.Point p;
        public int k;
        
        public $Closure$214(final x10.lang.Point p, final int k) {
             {
                this.p = ((x10.lang.Point)(p));
                this.k = k;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$215 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$215> $RTT = 
            x10.rtt.StaticFunType.<$Closure$215> make($Closure$215.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyRow.$Closure$215 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyRow.$Closure$215 $_obj = new x10.regionarray.PolyRow.$Closure$215((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            
        }
        
        // constructor just for allocation
        public $Closure$215(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public int $apply$O(final long i) {
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            final int t$154995 = ((int)(long)(((long)(i))));
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            final long t$154996 = ((long)(((int)(t$154995))));
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            final long t$154997 = this.rank;
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            final boolean t$155004 = ((t$154996) < (((long)(t$154997))));
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            int t$155005 =  0;
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            if (t$155004) {
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                final int t$154998 = ((int)(long)(((long)(i))));
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                final int t$154999 = this.out$$.$apply$O((int)(t$154998));
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                t$155005 = (-(t$154999));
            } else {
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                final long t$155000 = this.rank;
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                final int t$155001 = ((int)(long)(((long)(t$155000))));
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                final int t$155002 = this.out$$.$apply$O((int)(t$155001));
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                final int t$155003 = (-(t$155002));
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                t$155005 = ((t$155003) + (((int)(1))));
            }
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            return t$155005;
        }
        
        public x10.regionarray.PolyRow out$$;
        public long rank;
        
        public $Closure$215(final x10.regionarray.PolyRow out$$, final long rank) {
             {
                this.out$$ = out$$;
                this.rank = rank;
            }
        }
        
    }
    
}


