package x10.regionarray;


/**
 * A distribution that maps the region 0..(numPlaces()-1)
 * to the members of its PlaceGroup such that for 
 * every Place p the region returned by get is 
 * the single point region that matches the indexOf
 * p in the PlaceGroup.
 * In particular, if the PlaceGroup of the UniqueDist 
 * is Place.places() and no Place has failed, then each Place p 
 * will be assigned the region p.id..p.id.
 */
@x10.runtime.impl.java.X10Generated
final public class UniqueDist extends x10.regionarray.Dist implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<UniqueDist> $RTT = 
        x10.rtt.NamedType.<UniqueDist> make("x10.regionarray.UniqueDist",
                                            UniqueDist.class,
                                            new x10.rtt.Type[] {
                                                x10.regionarray.Dist.$RTT
                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.UniqueDist $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Dist.$_deserialize_body($_obj, $deserializer);
        $_obj.pg = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.UniqueDist $_obj = new x10.regionarray.UniqueDist((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.pg);
        
    }
    
    // constructor just for allocation
    public UniqueDist(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 31 "x10/regionarray/UniqueDist.x10"
    /**
    * The place group for this distribution
    */
    public x10.lang.PlaceGroup pg;
    
    //#line 36 "x10/regionarray/UniqueDist.x10"
    /**
     * Cached restricted region for the current place.
     */
    public transient x10.regionarray.Region regionForHere;
    
    
    //#line 42 "x10/regionarray/UniqueDist.x10"
    /**
     * Create a unique distribution over the argument PlaceGroup
     * @param g the place group
     */
    // creation method for java code (1-phase java constructor)
    public UniqueDist(final x10.lang.PlaceGroup g) {
        this((java.lang.System[]) null);
        x10$regionarray$UniqueDist$$init$S(g);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.UniqueDist x10$regionarray$UniqueDist$$init$S(final x10.lang.PlaceGroup g) {
         {
            
            //#line 43 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Dist this$158466 = ((x10.regionarray.Dist)(this));
            
            //#line 43 "x10/regionarray/UniqueDist.x10"
            final long t$158491 = g.numPlaces$O();
            
            //#line 43 "x10/regionarray/UniqueDist.x10"
            final long max$158462 = ((t$158491) - (((long)(1L))));
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$158463 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            alloc$158463.x10$regionarray$RectRegion1D$$init$S(((long)(0L)), ((long)(max$158462)));
            
            //#line 43 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region region$158465 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                     alloc$158463)));
            
            //#line 548 . "x10/regionarray/Dist.x10"
            this$158466.region = region$158465;
            
            //#line 42 "x10/regionarray/UniqueDist.x10"
            
            
            //#line 26 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.UniqueDist this$158557 = this;
            
            //#line 26 "x10/regionarray/UniqueDist.x10"
            this$158557.regionForHere = null;
            
            //#line 44 "x10/regionarray/UniqueDist.x10"
            this.pg = ((x10.lang.PlaceGroup)(g));
        }
        return this;
    }
    
    
    
    //#line 50 "x10/regionarray/UniqueDist.x10"
    /**
     * Create a unique distribution over Place.places();
     */
    // creation method for java code (1-phase java constructor)
    public UniqueDist() {
        this((java.lang.System[]) null);
        x10$regionarray$UniqueDist$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.UniqueDist x10$regionarray$UniqueDist$$init$S() {
         {
            
            //#line 51 "x10/regionarray/UniqueDist.x10"
            final x10.lang.PlaceGroup t$158492 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 51 "x10/regionarray/UniqueDist.x10"
            /*this.*/x10$regionarray$UniqueDist$$init$S(((x10.lang.PlaceGroup)(t$158492)));
        }
        return this;
    }
    
    
    
    //#line 54 "x10/regionarray/UniqueDist.x10"
    public x10.lang.PlaceGroup places() {
        
        //#line 54 "x10/regionarray/UniqueDist.x10"
        final x10.lang.PlaceGroup t$158493 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 54 "x10/regionarray/UniqueDist.x10"
        return t$158493;
    }
    
    
    //#line 56 "x10/regionarray/UniqueDist.x10"
    public long numPlaces$O() {
        
        //#line 56 "x10/regionarray/UniqueDist.x10"
        final x10.lang.PlaceGroup t$158494 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 56 "x10/regionarray/UniqueDist.x10"
        final long t$158495 = t$158494.numPlaces$O();
        
        //#line 56 "x10/regionarray/UniqueDist.x10"
        return t$158495;
    }
    
    
    //#line 58 "x10/regionarray/UniqueDist.x10"
    public x10.lang.Iterable regions() {
        
        //#line 59 "x10/regionarray/UniqueDist.x10"
        final x10.lang.PlaceGroup t$158496 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 59 "x10/regionarray/UniqueDist.x10"
        final long t$158504 = t$158496.numPlaces$O();
        
        //#line 59 "x10/regionarray/UniqueDist.x10"
        final x10.core.fun.Fun_0_1 t$158505 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.UniqueDist.$Closure$256(this)));
        
        //#line 59 "x10/regionarray/UniqueDist.x10"
        final x10.core.Rail t$158506 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.Region>(x10.regionarray.Region.$RTT, t$158504, ((x10.core.fun.Fun_0_1)(t$158505)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 59 "x10/regionarray/UniqueDist.x10"
        return t$158506;
    }
    
    
    //#line 62 "x10/regionarray/UniqueDist.x10"
    public x10.regionarray.Region get(final x10.lang.Place p) {
        
        //#line 63 "x10/regionarray/UniqueDist.x10"
        final boolean t$158526 = x10.rtt.Equality.equalsequals((p),(x10.x10rt.X10RT.here()));
        
        //#line 63 "x10/regionarray/UniqueDist.x10"
        if (t$158526) {
            
            //#line 64 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region t$158507 = ((x10.regionarray.Region)(this.regionForHere));
            
            //#line 64 "x10/regionarray/UniqueDist.x10"
            final boolean t$158516 = ((t$158507) == (null));
            
            //#line 64 "x10/regionarray/UniqueDist.x10"
            if (t$158516) {
                
                //#line 65 "x10/regionarray/UniqueDist.x10"
                final x10.lang.PlaceGroup t$158508 = ((x10.lang.PlaceGroup)(this.pg));
                
                //#line 65 "x10/regionarray/UniqueDist.x10"
                final long idx = t$158508.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
                
                //#line 279 . "x10/regionarray/Region.x10"
                final x10.regionarray.RectRegion1D alloc$158477 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
                
                //#line 279 . "x10/regionarray/Region.x10"
                alloc$158477.x10$regionarray$RectRegion1D$$init$S(idx, idx);
                
                //#line 279 . "x10/regionarray/Region.x10"
                final x10.regionarray.Region t$158509 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                    alloc$158477)));
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                final x10.regionarray.Region t$148625 = ((x10.regionarray.Region)
                                                          t$158509);
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                final long t$158511 = t$148625.rank;
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                final x10.regionarray.Region t$158510 = ((x10.regionarray.Region)(x10.regionarray.UniqueDist.this.region));
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                final long t$158512 = t$158510.rank;
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                final boolean t$158513 = ((long) t$158511) == ((long) t$158512);
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                final boolean t$158515 = !(t$158513);
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                if (t$158515) {
                    
                    //#line 66 "x10/regionarray/UniqueDist.x10"
                    final x10.lang.FailedDynamicCheckException t$158514 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.UniqueDist).region.rank}");
                    
                    //#line 66 "x10/regionarray/UniqueDist.x10"
                    throw t$158514;
                }
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                this.regionForHere = ((x10.regionarray.Region)(t$148625));
            }
            
            //#line 68 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region t$158517 = ((x10.regionarray.Region)(this.regionForHere));
            
            //#line 68 "x10/regionarray/UniqueDist.x10"
            return t$158517;
        } else {
            
            //#line 70 "x10/regionarray/UniqueDist.x10"
            final x10.lang.PlaceGroup t$158518 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 70 "x10/regionarray/UniqueDist.x10"
            final long idx = t$158518.indexOf$O(((x10.lang.Place)(p)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$158481 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            alloc$158481.x10$regionarray$RectRegion1D$$init$S(idx, idx);
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$158519 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$158481)));
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region t$148627 = ((x10.regionarray.Region)
                                                      t$158519);
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            final long t$158521 = t$148627.rank;
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region t$158520 = ((x10.regionarray.Region)(x10.regionarray.UniqueDist.this.region));
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            final long t$158522 = t$158520.rank;
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            final boolean t$158523 = ((long) t$158521) == ((long) t$158522);
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            final boolean t$158525 = !(t$158523);
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            if (t$158525) {
                
                //#line 71 "x10/regionarray/UniqueDist.x10"
                final x10.lang.FailedDynamicCheckException t$158524 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.UniqueDist).region.rank}");
                
                //#line 71 "x10/regionarray/UniqueDist.x10"
                throw t$158524;
            }
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            return t$148627;
        }
    }
    
    
    //#line 76 "x10/regionarray/UniqueDist.x10"
    public x10.regionarray.Region $apply(final x10.lang.Place p) {
        
        //#line 76 "x10/regionarray/UniqueDist.x10"
        final x10.regionarray.Region t$158527 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(p)))));
        
        //#line 76 "x10/regionarray/UniqueDist.x10"
        return t$158527;
    }
    
    
    //#line 78 "x10/regionarray/UniqueDist.x10"
    public x10.lang.Place $apply(final x10.lang.Point pt) {
        
        //#line 78 "x10/regionarray/UniqueDist.x10"
        final x10.lang.PlaceGroup t$158529 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 78 "x10/regionarray/UniqueDist.x10"
        final long t$158528 = ((long)(((int)(0))));
        
        //#line 78 "x10/regionarray/UniqueDist.x10"
        final long t$158530 = pt.$apply$O((long)(t$158528));
        
        //#line 78 "x10/regionarray/UniqueDist.x10"
        final x10.lang.Place t$158531 = t$158529.$apply((long)(t$158530));
        
        //#line 78 "x10/regionarray/UniqueDist.x10"
        return t$158531;
    }
    
    
    //#line 80 "x10/regionarray/UniqueDist.x10"
    public x10.lang.Place $apply(final long i0) {
        
        //#line 80 "x10/regionarray/UniqueDist.x10"
        final x10.lang.PlaceGroup t$158534 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 80 "x10/regionarray/UniqueDist.x10"
        final x10.lang.Place t$158535 = t$158534.$apply((long)(i0));
        
        //#line 80 "x10/regionarray/UniqueDist.x10"
        return t$158535;
    }
    
    
    //#line 84 "x10/regionarray/UniqueDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1) {
        
        //#line 85 "x10/regionarray/UniqueDist.x10"
        final java.lang.UnsupportedOperationException t$158538 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException("operator(i0:Long,i1:Long)")));
        
        //#line 85 "x10/regionarray/UniqueDist.x10"
        throw t$158538;
    }
    
    
    //#line 90 "x10/regionarray/UniqueDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2) {
        
        //#line 91 "x10/regionarray/UniqueDist.x10"
        final java.lang.UnsupportedOperationException t$158541 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException("operator(i0:Long,i1:Long,i2:Long)")));
        
        //#line 91 "x10/regionarray/UniqueDist.x10"
        throw t$158541;
    }
    
    
    //#line 96 "x10/regionarray/UniqueDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 97 "x10/regionarray/UniqueDist.x10"
        final java.lang.UnsupportedOperationException t$158544 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException("operator(i0:Long,i1:Long,i2:Long,i3:Long)")));
        
        //#line 97 "x10/regionarray/UniqueDist.x10"
        throw t$158544;
    }
    
    
    //#line 100 "x10/regionarray/UniqueDist.x10"
    public x10.regionarray.Dist restriction(final x10.regionarray.Region r) {
        
        //#line 101 "x10/regionarray/UniqueDist.x10"
        final x10.regionarray.WrappedDistRegionRestricted alloc$148631 = ((x10.regionarray.WrappedDistRegionRestricted)(new x10.regionarray.WrappedDistRegionRestricted((java.lang.System[]) null)));
        
        //#line 101 "x10/regionarray/UniqueDist.x10"
        alloc$148631.x10$regionarray$WrappedDistRegionRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.regionarray.Region)(r)));
        
        //#line 101 "x10/regionarray/UniqueDist.x10"
        return alloc$148631;
    }
    
    
    //#line 104 "x10/regionarray/UniqueDist.x10"
    public x10.regionarray.Dist restriction(final x10.lang.Place p) {
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final x10.regionarray.WrappedDistPlaceRestricted alloc$148632 = ((x10.regionarray.WrappedDistPlaceRestricted)(new x10.regionarray.WrappedDistPlaceRestricted((java.lang.System[]) null)));
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        alloc$148632.x10$regionarray$WrappedDistPlaceRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.lang.Place)(p)));
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final x10.regionarray.Dist t$148629 = ((x10.regionarray.Dist)
                                                alloc$148632);
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final x10.regionarray.Region t$158545 = ((x10.regionarray.Region)(t$148629.region));
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final long t$158547 = t$158545.rank;
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final x10.regionarray.Region t$158546 = ((x10.regionarray.Region)(x10.regionarray.UniqueDist.this.region));
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final long t$158548 = t$158546.rank;
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final boolean t$158549 = ((long) t$158547) == ((long) t$158548);
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final boolean t$158551 = !(t$158549);
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        if (t$158551) {
            
            //#line 105 "x10/regionarray/UniqueDist.x10"
            final x10.lang.FailedDynamicCheckException t$158550 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Dist{self.region.rank==this(:x10.regionarray.UniqueDist).region.rank}");
            
            //#line 105 "x10/regionarray/UniqueDist.x10"
            throw t$158550;
        }
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        return t$148629;
    }
    
    
    //#line 108 "x10/regionarray/UniqueDist.x10"
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 109 "x10/regionarray/UniqueDist.x10"
        final boolean t$158556 = x10.regionarray.UniqueDist.$RTT.isInstance(thatObj);
        
        //#line 109 "x10/regionarray/UniqueDist.x10"
        if (t$158556) {
            
            //#line 110 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.UniqueDist that = ((x10.regionarray.UniqueDist)(x10.rtt.Types.<x10.regionarray.UniqueDist> cast(thatObj,x10.regionarray.UniqueDist.$RTT)));
            
            //#line 111 "x10/regionarray/UniqueDist.x10"
            final x10.lang.PlaceGroup t$158552 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 111 "x10/regionarray/UniqueDist.x10"
            final x10.lang.PlaceGroup t$158553 = ((x10.lang.PlaceGroup)(that.pg));
            
            //#line 111 "x10/regionarray/UniqueDist.x10"
            final boolean t$158554 = t$158552.equals(((java.lang.Object)(t$158553)));
            
            //#line 111 "x10/regionarray/UniqueDist.x10"
            return t$158554;
        } else {
            
            //#line 113 "x10/regionarray/UniqueDist.x10"
            final boolean t$158555 = super.equals(((java.lang.Object)(thatObj)));
            
            //#line 113 "x10/regionarray/UniqueDist.x10"
            return t$158555;
        }
    }
    
    
    //#line 26 "x10/regionarray/UniqueDist.x10"
    final public x10.regionarray.UniqueDist x10$regionarray$UniqueDist$$this$x10$regionarray$UniqueDist() {
        
        //#line 26 "x10/regionarray/UniqueDist.x10"
        return x10.regionarray.UniqueDist.this;
    }
    
    
    //#line 26 "x10/regionarray/UniqueDist.x10"
    final public void __fieldInitializers_x10_regionarray_UniqueDist() {
        
        //#line 26 "x10/regionarray/UniqueDist.x10"
        this.regionForHere = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$256 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$256> $RTT = 
            x10.rtt.StaticFunType.<$Closure$256> make($Closure$256.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.regionarray.Region.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.UniqueDist.$Closure$256 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.UniqueDist.$Closure$256 $_obj = new x10.regionarray.UniqueDist.$Closure$256((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$256(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.regionarray.Region $apply(final long i) {
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$158473 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            alloc$158473.x10$regionarray$RectRegion1D$$init$S(i, i);
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$158497 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$158473)));
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region t$148623 = ((x10.regionarray.Region)
                                                      t$158497);
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            final long t$158499 = t$148623.rank;
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region t$158498 = ((x10.regionarray.Region)(this.out$$.region));
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            final long t$158500 = t$158498.rank;
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            final boolean t$158501 = ((long) t$158499) == ((long) t$158500);
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            final boolean t$158503 = !(t$158501);
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            if (t$158503) {
                
                //#line 59 "x10/regionarray/UniqueDist.x10"
                final x10.lang.FailedDynamicCheckException t$158502 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.UniqueDist).region.rank}");
                
                //#line 59 "x10/regionarray/UniqueDist.x10"
                throw t$158502;
            }
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            return t$148623;
        }
        
        public x10.regionarray.UniqueDist out$$;
        
        public $Closure$256(final x10.regionarray.UniqueDist out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    
    public boolean x10$regionarray$Dist$equals$S$O(final java.lang.Object a0) {
        return super.equals(((java.lang.Object)(a0)));
    }
}

