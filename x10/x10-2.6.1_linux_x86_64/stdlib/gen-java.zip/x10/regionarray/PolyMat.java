package x10.regionarray;


/**
 * A PolyMat is a set of linear inequalisty constraints represented as
 * a constraint matrix. Each row is represented as a PolyRow
 * object. The constraint matrix represents a set of points defined as
 * the intersection of the halfspaces represented by each PolyRow in
 * the PolyMat, or equivalently, as the set of points satisfying the
 * conjunction of the linear inequalities represented by each PolyRow
 * object.
 */
@x10.runtime.impl.java.X10Generated
public class PolyMat extends x10.regionarray.Mat<x10.regionarray.PolyRow> implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PolyMat> $RTT = 
        x10.rtt.NamedType.<PolyMat> make("x10.regionarray.PolyMat",
                                         PolyMat.class,
                                         new x10.rtt.Type[] {
                                             x10.rtt.ParameterizedType.make(x10.regionarray.Mat.$RTT, x10.regionarray.PolyRow.$RTT)
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyMat $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Mat.$_deserialize_body($_obj, $deserializer);
        $_obj.isSimplified = $deserializer.readBoolean();
        $_obj.rank = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.PolyMat $_obj = new x10.regionarray.PolyMat((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.isSimplified);
        $serializer.write(this.rank);
        
    }
    
    // constructor just for allocation
    public PolyMat(final java.lang.System[] $dummy) {
        super($dummy, x10.regionarray.PolyRow.$RTT);
        
    }
    
    // bridge for inherited method public x10.regionarray.Mat[T].operator()(i:x10.lang.Int){}:T
    public x10.regionarray.PolyRow $apply(int a1){
        return super.$apply$G((a1));
    }
    
    // synthetic type for parameter mangling
    public static final class __2$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 {}
    
    // properties
    
    //#line 26 "x10/regionarray/PolyMat.x10"
    public long rank;
    

    
    //#line 32 "x10/regionarray/PolyMat.x10"
    public boolean isSimplified;
    
    
    //#line 39 "x10/regionarray/PolyMat.x10"
    /**
     * Low-level constructor. For greater convenience use PolyMatBuilder.
     */
    // creation method for java code (1-phase java constructor)
    public PolyMat(final int rows, final int cols, final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init, final boolean isSimplified, __2$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyMat$$init$S(rows, cols, init, isSimplified, (x10.regionarray.PolyMat.__2$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyMat x10$regionarray$PolyMat$$init$S(final int rows, final int cols, final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init, final boolean isSimplified, __2$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
         {
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.Mat this$152709 = ((x10.regionarray.Mat)(this));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final int rows$152706 = rows;
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final int cols$152707 = cols;
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final long t$152812 = ((long)(((int)(rows))));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final x10.core.fun.Fun_0_1 t$152813 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyMat.$Closure$205(init, cols, (x10.regionarray.PolyMat.$Closure$205.__0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2) null)));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final x10.core.Rail mat$152708 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.PolyRow>(x10.regionarray.PolyRow.$RTT, t$152812, ((x10.core.fun.Fun_0_1)(t$152813)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 22 . "x10/regionarray/Mat.x10"
            ((x10.regionarray.Mat<x10.regionarray.PolyRow>)this$152709).rows = rows$152706;
            
            //#line 22 . "x10/regionarray/Mat.x10"
            ((x10.regionarray.Mat<x10.regionarray.PolyRow>)this$152709).cols = cols$152707;
            
            //#line 23 . "x10/regionarray/Mat.x10"
            ((x10.regionarray.Mat<x10.regionarray.PolyRow>)this$152709).mat = ((x10.core.Rail)(mat$152708));
            
            //#line 41 "x10/regionarray/PolyMat.x10"
            final int cols1 = ((cols) - (((int)(1))));
            
            //#line 42 "x10/regionarray/PolyMat.x10"
            final long t$153028 = ((long)(((int)(cols1))));
            
            //#line 42 "x10/regionarray/PolyMat.x10"
            this.rank = t$153028;
            
            
            //#line 43 "x10/regionarray/PolyMat.x10"
            this.isSimplified = isSimplified;
        }
        return this;
    }
    
    
    
    //#line 55 "x10/regionarray/PolyMat.x10"
    /**
     * Eliminate redundant parallel halfspaces. Since halfspaces
     * with equal coefficients are sorted in increasing order of
     * the constant (which is the least significant part of the
     * key) taking the last of a set of parallel halfspaces
     * captures the strongest halfspace.
     */
    public x10.regionarray.PolyMat simplifyParallel() {
        
        //#line 57 "x10/regionarray/PolyMat.x10"
        final int t$152815 = this.rows;
        
        //#line 57 "x10/regionarray/PolyMat.x10"
        final boolean t$152816 = ((int) t$152815) == ((int) 0);
        
        //#line 57 "x10/regionarray/PolyMat.x10"
        if (t$152816) {
            
            //#line 58 "x10/regionarray/PolyMat.x10"
            return this;
        }
        
        //#line 60 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 60 "x10/regionarray/PolyMat.x10"
        final long t$153037 = this.rank;
        
        //#line 60 "x10/regionarray/PolyMat.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$153037)));
        
        //#line 61 "x10/regionarray/PolyMat.x10"
        x10.regionarray.PolyRow last = null;
        
        //#line 62 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator next$153038 = this.iterator();
        
        //#line 62 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 62 "x10/regionarray/PolyMat.x10"
            final boolean t$153039 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)next$153038).hasNext$O();
            
            //#line 62 "x10/regionarray/PolyMat.x10"
            if (!(t$153039)) {
                
                //#line 62 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 62 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow next$153030 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)next$153038).next$G();
            
            //#line 63 "x10/regionarray/PolyMat.x10"
            boolean t$153032 = ((last) != (null));
            
            //#line 63 "x10/regionarray/PolyMat.x10"
            if (t$153032) {
                
                //#line 63 "x10/regionarray/PolyMat.x10"
                final boolean t$153034 = next$153030.isParallel$O(((x10.regionarray.PolyRow)(last)));
                
                //#line 63 "x10/regionarray/PolyMat.x10"
                t$153032 = !(t$153034);
            }
            
            //#line 63 "x10/regionarray/PolyMat.x10"
            if (t$153032) {
                
                //#line 64 "x10/regionarray/PolyMat.x10"
                pmb.add(((x10.regionarray.Row)(last)));
            }
            
            //#line 65 "x10/regionarray/PolyMat.x10"
            last = ((x10.regionarray.PolyRow)(next$153030));
        }
        
        //#line 67 "x10/regionarray/PolyMat.x10"
        pmb.add(((x10.regionarray.Row)(last)));
        
        //#line 69 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMat t$152827 = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 69 "x10/regionarray/PolyMat.x10"
        return t$152827;
    }
    
    
    //#line 82 "x10/regionarray/PolyMat.x10"
    /**
     * Determine whether a halfspace is redundant by reductio ad
     * absurdum: assume the negation of H, and if the result is the
     * empty set then H is implied by the other halfspaces.
     *
     * This is guaranteed to remove redundant halfspaces, but it may
     * be expensive.
     */
    public x10.regionarray.PolyMat simplifyAll() {
        
        //#line 84 "x10/regionarray/PolyMat.x10"
        final boolean t$152828 = this.isSimplified;
        
        //#line 84 "x10/regionarray/PolyMat.x10"
        if (t$152828) {
            
            //#line 85 "x10/regionarray/PolyMat.x10"
            return this;
        }
        
        //#line 87 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 87 "x10/regionarray/PolyMat.x10"
        final long t$153067 = this.rank;
        
        //#line 87 "x10/regionarray/PolyMat.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$153067)));
        
        //#line 88 "x10/regionarray/PolyMat.x10"
        final int t$152830 = this.rows;
        
        //#line 88 "x10/regionarray/PolyMat.x10"
        final long t$152831 = ((long)(((int)(t$152830))));
        
        //#line 88 "x10/regionarray/PolyMat.x10"
        final x10.core.Rail removed = ((x10.core.Rail)(new x10.core.Rail<x10.core.Boolean>(x10.rtt.Types.BOOLEAN, t$152831, (x10.core.Boolean.$box(false)), (x10.core.Rail.__1x10$lang$Rail$$T) null)));
        
        //#line 90 "x10/regionarray/PolyMat.x10"
        int i$153068 = 0;
        {
            
            //#line 90 "x10/regionarray/PolyMat.x10"
            final boolean[] removed$value$153220 = ((boolean[])removed.value);
            
            //#line 90 "x10/regionarray/PolyMat.x10"
            for (;
                 true;
                 ) {
                
                //#line 90 "x10/regionarray/PolyMat.x10"
                final int t$153070 = this.rows;
                
                //#line 90 "x10/regionarray/PolyMat.x10"
                final boolean t$153071 = ((i$153068) < (((int)(t$153070))));
                
                //#line 90 "x10/regionarray/PolyMat.x10"
                if (!(t$153071)) {
                    
                    //#line 90 "x10/regionarray/PolyMat.x10"
                    break;
                }
                
                //#line 91 "x10/regionarray/PolyMat.x10"
                final x10.regionarray.PolyRow r$153058 = this.$apply$G((int)(i$153068));
                
                //#line 92 "x10/regionarray/PolyMat.x10"
                final x10.regionarray.PolyMatBuilder trial$153059 = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
                
                //#line 92 "x10/regionarray/PolyMat.x10"
                final long t$153052 = this.rank;
                
                //#line 92 "x10/regionarray/PolyMat.x10"
                trial$153059.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$153052)));
                
                //#line 93 "x10/regionarray/PolyMat.x10"
                int j$153053 = 0;
                {
                    
                    //#line 93 "x10/regionarray/PolyMat.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 93 "x10/regionarray/PolyMat.x10"
                        final int t$153055 = this.rows;
                        
                        //#line 93 "x10/regionarray/PolyMat.x10"
                        final boolean t$153056 = ((j$153053) < (((int)(t$153055))));
                        
                        //#line 93 "x10/regionarray/PolyMat.x10"
                        if (!(t$153056)) {
                            
                            //#line 93 "x10/regionarray/PolyMat.x10"
                            break;
                        }
                        
                        //#line 94 "x10/regionarray/PolyMat.x10"
                        final long t$153041 = ((long)(((int)(j$153053))));
                        
                        //#line 94 "x10/regionarray/PolyMat.x10"
                        final boolean t$153042 = ((boolean)removed$value$153220[(int)t$153041]);
                        
                        //#line 94 "x10/regionarray/PolyMat.x10"
                        final boolean t$153043 = !(t$153042);
                        
                        //#line 94 "x10/regionarray/PolyMat.x10"
                        if (t$153043) {
                            
                            //#line 95 "x10/regionarray/PolyMat.x10"
                            final boolean t$153046 = ((int) i$153068) == ((int) j$153053);
                            
                            //#line 95 "x10/regionarray/PolyMat.x10"
                            x10.regionarray.PolyRow t$153047 =  null;
                            
                            //#line 95 "x10/regionarray/PolyMat.x10"
                            if (t$153046) {
                                
                                //#line 95 "x10/regionarray/PolyMat.x10"
                                t$153047 = r$153058.complement();
                            } else {
                                
                                //#line 95 "x10/regionarray/PolyMat.x10"
                                t$153047 = this.$apply$G((int)(j$153053));
                            }
                            
                            //#line 95 "x10/regionarray/PolyMat.x10"
                            trial$153059.add(((x10.regionarray.Row)(t$153047)));
                        }
                        
                        //#line 93 "x10/regionarray/PolyMat.x10"
                        final int t$153051 = ((j$153053) + (((int)(1))));
                        
                        //#line 93 "x10/regionarray/PolyMat.x10"
                        j$153053 = t$153051;
                    }
                }
                
                //#line 96 "x10/regionarray/PolyMat.x10"
                final x10.regionarray.PolyMat t$153060 = ((x10.regionarray.PolyMat)(trial$153059.toSortedPolyMat((boolean)(false))));
                
                //#line 96 "x10/regionarray/PolyMat.x10"
                final boolean t$153061 = t$153060.isEmpty$O();
                
                //#line 96 "x10/regionarray/PolyMat.x10"
                final boolean t$153062 = !(t$153061);
                
                //#line 96 "x10/regionarray/PolyMat.x10"
                if (t$153062) {
                    
                    //#line 97 "x10/regionarray/PolyMat.x10"
                    pmb.add(((x10.regionarray.Row)(r$153058)));
                } else {
                    
                    //#line 99 "x10/regionarray/PolyMat.x10"
                    final long t$153064 = ((long)(((int)(i$153068))));
                    
                    //#line 99 "x10/regionarray/PolyMat.x10"
                    removed$value$153220[(int)t$153064]=true;
                }
                
                //#line 90 "x10/regionarray/PolyMat.x10"
                final int t$153066 = ((i$153068) + (((int)(1))));
                
                //#line 90 "x10/regionarray/PolyMat.x10"
                i$153068 = t$153066;
            }
        }
        
        //#line 102 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMat t$152861 = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(true))));
        
        //#line 102 "x10/regionarray/PolyMat.x10"
        return t$152861;
    }
    
    
    //#line 122 "x10/regionarray/PolyMat.x10"
    /**
     * Apply Fourier-Motzkin Elimination to eliminate variable k:
     *
     * Copy each halfspace whose kth coefficient is already 0
     *
     * For each pair of halfspaces such that the kth coefficient is of
     * opposite sign, construct a new halfspace by adding the two
     * original halfspaces with appropriate positive multipliers to
     * obtain a halfspace with a kth coefficent of 0.
     *
     * The result is a set of halfspaces that describe the polyhedron
     * that is the projection of the polyhedron described by the
     * original halfspaces onto a rank-1 dimensional subspace obtained
     * by eliminating axis k
     */
    public x10.regionarray.PolyMat eliminate(final int k, final boolean simplifyDegenerate) {
        
        //#line 123 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 123 "x10/regionarray/PolyMat.x10"
        final long t$153145 = this.rank;
        
        //#line 123 "x10/regionarray/PolyMat.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$153145)));
        
        //#line 124 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator ir$153146 = this.iterator();
        
        //#line 124 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 124 "x10/regionarray/PolyMat.x10"
            final boolean t$153147 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)ir$153146).hasNext$O();
            
            //#line 124 "x10/regionarray/PolyMat.x10"
            if (!(t$153147)) {
                
                //#line 124 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 124 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow ir$153140 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)ir$153146).next$G();
            
            //#line 125 "x10/regionarray/PolyMat.x10"
            final int ia$153141 = ir$153140.$apply$O((int)(k));
            
            //#line 126 "x10/regionarray/PolyMat.x10"
            final boolean t$153142 = ((int) ia$153141) == ((int) 0);
            
            //#line 126 "x10/regionarray/PolyMat.x10"
            if (t$153142) {
                
                //#line 127 "x10/regionarray/PolyMat.x10"
                pmb.add(((x10.regionarray.Row)(ir$153140)));
            } else {
                
                //#line 129 "x10/regionarray/PolyMat.x10"
                final x10.lang.Iterator jr$153143 = this.iterator();
                
                //#line 129 "x10/regionarray/PolyMat.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 129 "x10/regionarray/PolyMat.x10"
                    final boolean t$153144 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)jr$153143).hasNext$O();
                    
                    //#line 129 "x10/regionarray/PolyMat.x10"
                    if (!(t$153144)) {
                        
                        //#line 129 "x10/regionarray/PolyMat.x10"
                        break;
                    }
                    
                    //#line 129 "x10/regionarray/PolyMat.x10"
                    final x10.regionarray.PolyRow jr$153106 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)jr$153143).next$G();
                    
                    //#line 130 "x10/regionarray/PolyMat.x10"
                    final int ja$153107 = jr$153106.$apply$O((int)(k));
                    
                    //#line 131 "x10/regionarray/PolyMat.x10"
                    final long t$153108 = this.rank;
                    
                    //#line 131 "x10/regionarray/PolyMat.x10"
                    final long t$153109 = ((long)(((int)(1))));
                    
                    //#line 131 "x10/regionarray/PolyMat.x10"
                    final long t$153110 = ((t$153108) + (((long)(t$153109))));
                    
                    //#line 131 "x10/regionarray/PolyMat.x10"
                    final x10.core.Rail as_$153111 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, t$153110)));
                    
                    //#line 132 "x10/regionarray/PolyMat.x10"
                    boolean t$153112 = ((ia$153141) > (((int)(0))));
                    
                    //#line 132 "x10/regionarray/PolyMat.x10"
                    if (t$153112) {
                        
                        //#line 132 "x10/regionarray/PolyMat.x10"
                        t$153112 = ((ja$153107) < (((int)(0))));
                    }
                    
                    //#line 132 "x10/regionarray/PolyMat.x10"
                    if (t$153112) {
                        
                        //#line 133 "x10/regionarray/PolyMat.x10"
                        int l$153114 = 0;
                        {
                            
                            //#line 133 "x10/regionarray/PolyMat.x10"
                            final int[] as_$153111$value$153221 = ((int[])as_$153111.value);
                            
                            //#line 133 "x10/regionarray/PolyMat.x10"
                            for (;
                                 true;
                                 ) {
                                
                                //#line 133 "x10/regionarray/PolyMat.x10"
                                final long t$153116 = ((long)(((int)(l$153114))));
                                
                                //#line 133 "x10/regionarray/PolyMat.x10"
                                final long t$153117 = this.rank;
                                
                                //#line 133 "x10/regionarray/PolyMat.x10"
                                final boolean t$153118 = ((t$153116) <= (((long)(t$153117))));
                                
                                //#line 133 "x10/regionarray/PolyMat.x10"
                                if (!(t$153118)) {
                                    
                                    //#line 133 "x10/regionarray/PolyMat.x10"
                                    break;
                                }
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                final long t$153073 = ((long)(((int)(l$153114))));
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                final int t$153075 = jr$153106.$apply$O((int)(l$153114));
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                final int t$153076 = ((ia$153141) * (((int)(t$153075))));
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                final int t$153078 = ir$153140.$apply$O((int)(l$153114));
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                final int t$153079 = ((ja$153107) * (((int)(t$153078))));
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                final int t$153080 = ((t$153076) - (((int)(t$153079))));
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                as_$153111$value$153221[(int)t$153073]=t$153080;
                                
                                //#line 133 "x10/regionarray/PolyMat.x10"
                                final int t$153082 = ((l$153114) + (((int)(1))));
                                
                                //#line 133 "x10/regionarray/PolyMat.x10"
                                l$153114 = t$153082;
                            }
                        }
                    } else {
                        
                        //#line 135 "x10/regionarray/PolyMat.x10"
                        boolean t$153119 = ((ia$153141) < (((int)(0))));
                        
                        //#line 135 "x10/regionarray/PolyMat.x10"
                        if (t$153119) {
                            
                            //#line 135 "x10/regionarray/PolyMat.x10"
                            t$153119 = ((ja$153107) > (((int)(0))));
                        }
                        
                        //#line 135 "x10/regionarray/PolyMat.x10"
                        if (t$153119) {
                            
                            //#line 136 "x10/regionarray/PolyMat.x10"
                            int l$153121 = 0;
                            {
                                
                                //#line 136 "x10/regionarray/PolyMat.x10"
                                final int[] as_$153111$value$153222 = ((int[])as_$153111.value);
                                
                                //#line 136 "x10/regionarray/PolyMat.x10"
                                for (;
                                     true;
                                     ) {
                                    
                                    //#line 136 "x10/regionarray/PolyMat.x10"
                                    final long t$153123 = ((long)(((int)(l$153121))));
                                    
                                    //#line 136 "x10/regionarray/PolyMat.x10"
                                    final long t$153124 = this.rank;
                                    
                                    //#line 136 "x10/regionarray/PolyMat.x10"
                                    final boolean t$153125 = ((t$153123) <= (((long)(t$153124))));
                                    
                                    //#line 136 "x10/regionarray/PolyMat.x10"
                                    if (!(t$153125)) {
                                        
                                        //#line 136 "x10/regionarray/PolyMat.x10"
                                        break;
                                    }
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    final long t$153084 = ((long)(((int)(l$153121))));
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    final int t$153086 = ir$153140.$apply$O((int)(l$153121));
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    final int t$153087 = ((ja$153107) * (((int)(t$153086))));
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    final int t$153089 = jr$153106.$apply$O((int)(l$153121));
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    final int t$153090 = ((ia$153141) * (((int)(t$153089))));
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    final int t$153091 = ((t$153087) - (((int)(t$153090))));
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    as_$153111$value$153222[(int)t$153084]=t$153091;
                                    
                                    //#line 136 "x10/regionarray/PolyMat.x10"
                                    final int t$153093 = ((l$153121) + (((int)(1))));
                                    
                                    //#line 136 "x10/regionarray/PolyMat.x10"
                                    l$153121 = t$153093;
                                }
                            }
                        }
                    }
                    
                    //#line 139 "x10/regionarray/PolyMat.x10"
                    long t$153126 =  0;
                    
                    //#line 139 "x10/regionarray/PolyMat.x10"
                    if (simplifyDegenerate) {
                        
                        //#line 139 "x10/regionarray/PolyMat.x10"
                        t$153126 = this.rank;
                    } else {
                        
                        //#line 139 "x10/regionarray/PolyMat.x10"
                        final long t$153127 = this.rank;
                        
                        //#line 139 "x10/regionarray/PolyMat.x10"
                        final long t$153128 = ((long)(((int)(1))));
                        
                        //#line 139 "x10/regionarray/PolyMat.x10"
                        t$153126 = ((t$153127) + (((long)(t$153128))));
                    }
                    
                    //#line 140 "x10/regionarray/PolyMat.x10"
                    boolean degenerate$153130 = true;
                    
                    //#line 141 "x10/regionarray/PolyMat.x10"
                    int l$153102 = 0;
                    {
                        
                        //#line 141 "x10/regionarray/PolyMat.x10"
                        final int[] as_$153111$value$153223 = ((int[])as_$153111.value);
                        
                        //#line 141 "x10/regionarray/PolyMat.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 141 "x10/regionarray/PolyMat.x10"
                            final long t$153104 = ((long)(((int)(l$153102))));
                            
                            //#line 141 "x10/regionarray/PolyMat.x10"
                            final boolean t$153105 = ((t$153104) < (((long)(t$153126))));
                            
                            //#line 141 "x10/regionarray/PolyMat.x10"
                            if (!(t$153105)) {
                                
                                //#line 141 "x10/regionarray/PolyMat.x10"
                                break;
                            }
                            
                            //#line 142 "x10/regionarray/PolyMat.x10"
                            final long t$153095 = ((long)(((int)(l$153102))));
                            
                            //#line 142 "x10/regionarray/PolyMat.x10"
                            final int t$153096 = ((int)as_$153111$value$153223[(int)t$153095]);
                            
                            //#line 142 "x10/regionarray/PolyMat.x10"
                            final boolean t$153097 = ((int) t$153096) != ((int) 0);
                            
                            //#line 142 "x10/regionarray/PolyMat.x10"
                            if (t$153097) {
                                
                                //#line 143 "x10/regionarray/PolyMat.x10"
                                degenerate$153130 = false;
                            }
                            
                            //#line 141 "x10/regionarray/PolyMat.x10"
                            final int t$153099 = ((l$153102) + (((int)(1))));
                            
                            //#line 141 "x10/regionarray/PolyMat.x10"
                            l$153102 = t$153099;
                        }
                    }
                    
                    //#line 144 "x10/regionarray/PolyMat.x10"
                    final boolean t$153132 = !(degenerate$153130);
                    
                    //#line 144 "x10/regionarray/PolyMat.x10"
                    if (t$153132) {
                        
                        //#line 145 "x10/regionarray/PolyMat.x10"
                        x10.regionarray.PolyRow r$153133 = new x10.regionarray.PolyRow((java.lang.System[]) null);
                        
                        //#line 145 "x10/regionarray/PolyMat.x10"
                        final long t$153134 = ((x10.core.Rail<x10.core.Int>)as_$153111).size;
                        
                        //#line 145 "x10/regionarray/PolyMat.x10"
                        final x10.core.fun.Fun_0_1 t$153135 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyMat.$Closure$206(as_$153111, (x10.regionarray.PolyMat.$Closure$206.__0$1x10$lang$Int$2) null)));
                        
                        //#line 145 "x10/regionarray/PolyMat.x10"
                        final x10.core.Rail as_$153138 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, ((long)(t$153134)), ((x10.core.fun.Fun_0_1)(t$153135)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                        
                        //#line 29 . "x10/regionarray/PolyRow.x10"
                        final long t$153100 = ((x10.core.Rail<x10.core.Int>)as_$153138).size;
                        
                        //#line 29 . "x10/regionarray/PolyRow.x10"
                        final long t$153101 = ((t$153100) - (((long)(1L))));
                        
                        //#line 29 . "x10/regionarray/PolyRow.x10"
                        r$153133.x10$regionarray$PolyRow$$init$S(((x10.core.Rail)(as_$153138)), t$153101, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
                        
                        //#line 146 "x10/regionarray/PolyMat.x10"
                        pmb.add(((x10.regionarray.Row)(r$153133)));
                    }
                }
            }
        }
        
        //#line 151 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMat t$152928 = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 151 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMat t$152929 = ((x10.regionarray.PolyMat)(t$152928.simplifyParallel()));
        
        //#line 151 "x10/regionarray/PolyMat.x10"
        return t$152929;
    }
    
    
    //#line 166 "x10/regionarray/PolyMat.x10"
    /**
     * Support for constructing rectangular regions: determining
     * whether or not a cl is rectangular, and computing min/max along
     * each axis if it is.
     *
     * XXX cache these for efficiency during region construction
     * XXX assume halfspaces have been sorted and simplified - check/enforce
     * XXX rectMin/Max only work if isRect is true - check/enforce
     * XXX cache rectMin/rectMax/isZeroBased for performance
     */
    public boolean isRect$O() {
        
        //#line 167 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153151 = this.iterator();
        
        //#line 167 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 167 "x10/regionarray/PolyMat.x10"
            final boolean t$153152 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153151).hasNext$O();
            
            //#line 167 "x10/regionarray/PolyMat.x10"
            if (!(t$153152)) {
                
                //#line 167 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 167 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153148 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153151).next$G();
            
            //#line 168 "x10/regionarray/PolyMat.x10"
            final boolean t$153149 = r$153148.isRect$O();
            
            //#line 168 "x10/regionarray/PolyMat.x10"
            final boolean t$153150 = !(t$153149);
            
            //#line 168 "x10/regionarray/PolyMat.x10"
            if (t$153150) {
                
                //#line 169 "x10/regionarray/PolyMat.x10"
                return false;
            }
        }
        
        //#line 171 "x10/regionarray/PolyMat.x10"
        return true;
    }
    
    
    //#line 174 "x10/regionarray/PolyMat.x10"
    public int rectMin$O(final int axis) {
        
        //#line 176 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153162 = this.iterator();
        
        //#line 176 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 176 "x10/regionarray/PolyMat.x10"
            final boolean t$153163 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153162).hasNext$O();
            
            //#line 176 "x10/regionarray/PolyMat.x10"
            if (!(t$153163)) {
                
                //#line 176 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 176 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153153 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153162).next$G();
            
            //#line 177 "x10/regionarray/PolyMat.x10"
            final int a$153154 = r$153153.$apply$O((int)(axis));
            
            //#line 178 "x10/regionarray/PolyMat.x10"
            final long t$153155 = ((long)(((int)(a$153154))));
            
            //#line 178 "x10/regionarray/PolyMat.x10"
            final boolean t$153156 = ((t$153155) < (((long)(0L))));
            
            //#line 178 "x10/regionarray/PolyMat.x10"
            if (t$153156) {
                
                //#line 179 "x10/regionarray/PolyMat.x10"
                final long t$153157 = this.rank;
                
                //#line 179 "x10/regionarray/PolyMat.x10"
                final int t$153158 = ((int)(long)(((long)(t$153157))));
                
                //#line 179 "x10/regionarray/PolyMat.x10"
                final int t$153159 = r$153153.$apply$O((int)(t$153158));
                
                //#line 179 "x10/regionarray/PolyMat.x10"
                final int t$153160 = (-(t$153159));
                
                //#line 179 "x10/regionarray/PolyMat.x10"
                final int t$153161 = ((t$153160) / (((int)(a$153154))));
                
                //#line 179 "x10/regionarray/PolyMat.x10"
                return t$153161;
            }
        }
        
        //#line 182 "x10/regionarray/PolyMat.x10"
        final java.lang.String t$152943 = (("axis ") + ((x10.core.Int.$box(axis))));
        
        //#line 182 "x10/regionarray/PolyMat.x10"
        java.lang.String msg = ((t$152943) + (" has no minimum"));
        
        //#line 183 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.UnboundedRegionException t$152945 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(msg)));
        
        //#line 183 "x10/regionarray/PolyMat.x10"
        throw t$152945;
    }
    
    
    //#line 186 "x10/regionarray/PolyMat.x10"
    public int rectMax$O(final int axis) {
        
        //#line 188 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153173 = this.iterator();
        
        //#line 188 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 188 "x10/regionarray/PolyMat.x10"
            final boolean t$153174 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153173).hasNext$O();
            
            //#line 188 "x10/regionarray/PolyMat.x10"
            if (!(t$153174)) {
                
                //#line 188 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 188 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153164 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153173).next$G();
            
            //#line 189 "x10/regionarray/PolyMat.x10"
            final int a$153165 = r$153164.$apply$O((int)(axis));
            
            //#line 190 "x10/regionarray/PolyMat.x10"
            final long t$153166 = ((long)(((int)(a$153165))));
            
            //#line 190 "x10/regionarray/PolyMat.x10"
            final boolean t$153167 = ((t$153166) > (((long)(0L))));
            
            //#line 190 "x10/regionarray/PolyMat.x10"
            if (t$153167) {
                
                //#line 191 "x10/regionarray/PolyMat.x10"
                final long t$153168 = this.rank;
                
                //#line 191 "x10/regionarray/PolyMat.x10"
                final int t$153169 = ((int)(long)(((long)(t$153168))));
                
                //#line 191 "x10/regionarray/PolyMat.x10"
                final int t$153170 = r$153164.$apply$O((int)(t$153169));
                
                //#line 191 "x10/regionarray/PolyMat.x10"
                final int t$153171 = (-(t$153170));
                
                //#line 191 "x10/regionarray/PolyMat.x10"
                final int t$153172 = ((t$153171) / (((int)(a$153165))));
                
                //#line 191 "x10/regionarray/PolyMat.x10"
                return t$153172;
            }
        }
        
        //#line 194 "x10/regionarray/PolyMat.x10"
        final java.lang.String t$152955 = (("axis ") + ((x10.core.Int.$box(axis))));
        
        //#line 194 "x10/regionarray/PolyMat.x10"
        final java.lang.String msg = ((t$152955) + (" has no maximum"));
        
        //#line 195 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.UnboundedRegionException t$152956 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)(msg)))));
        
        //#line 195 "x10/regionarray/PolyMat.x10"
        throw t$152956;
    }
    
    
    //#line 198 "x10/regionarray/PolyMat.x10"
    public x10.core.Rail rectMin() {
        
        //#line 198 "x10/regionarray/PolyMat.x10"
        final long t$152959 = this.rank;
        
        //#line 198 "x10/regionarray/PolyMat.x10"
        final x10.core.fun.Fun_0_1 t$152960 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyMat.$Closure$207(this)));
        
        //#line 198 "x10/regionarray/PolyMat.x10"
        final x10.core.Rail t$152961 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, ((long)(t$152959)), ((x10.core.fun.Fun_0_1)(t$152960)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 198 "x10/regionarray/PolyMat.x10"
        return t$152961;
    }
    
    
    //#line 200 "x10/regionarray/PolyMat.x10"
    public x10.core.Rail rectMax() {
        
        //#line 200 "x10/regionarray/PolyMat.x10"
        final long t$152964 = this.rank;
        
        //#line 200 "x10/regionarray/PolyMat.x10"
        final x10.core.fun.Fun_0_1 t$152965 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyMat.$Closure$208(this)));
        
        //#line 200 "x10/regionarray/PolyMat.x10"
        final x10.core.Rail t$152966 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, ((long)(t$152964)), ((x10.core.fun.Fun_0_1)(t$152965)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 200 "x10/regionarray/PolyMat.x10"
        return t$152966;
    }
    
    
    //#line 202 "x10/regionarray/PolyMat.x10"
    public boolean isZeroBased$O() {
        
        //#line 203 "x10/regionarray/PolyMat.x10"
        final boolean t$152967 = this.isRect$O();
        
        //#line 203 "x10/regionarray/PolyMat.x10"
        final boolean t$152968 = !(t$152967);
        
        //#line 203 "x10/regionarray/PolyMat.x10"
        if (t$152968) {
            
            //#line 204 "x10/regionarray/PolyMat.x10"
            return false;
        }
        
        //#line 205 "x10/regionarray/PolyMat.x10"
        try {{
            
            //#line 206 "x10/regionarray/PolyMat.x10"
            int i = 0;
            
            //#line 206 "x10/regionarray/PolyMat.x10"
            for (;
                 true;
                 ) {
                
                //#line 206 "x10/regionarray/PolyMat.x10"
                final long t$152971 = ((long)(((int)(i))));
                
                //#line 206 "x10/regionarray/PolyMat.x10"
                final long t$152972 = this.rank;
                
                //#line 206 "x10/regionarray/PolyMat.x10"
                final boolean t$152978 = ((t$152971) < (((long)(t$152972))));
                
                //#line 206 "x10/regionarray/PolyMat.x10"
                if (!(t$152978)) {
                    
                    //#line 206 "x10/regionarray/PolyMat.x10"
                    break;
                }
                
                //#line 207 "x10/regionarray/PolyMat.x10"
                final int t$153176 = this.rectMin$O((int)(i));
                
                //#line 207 "x10/regionarray/PolyMat.x10"
                final boolean t$153177 = ((int) t$153176) != ((int) 0);
                
                //#line 207 "x10/regionarray/PolyMat.x10"
                if (t$153177) {
                    
                    //#line 208 "x10/regionarray/PolyMat.x10"
                    return false;
                }
                
                //#line 206 "x10/regionarray/PolyMat.x10"
                final int t$153179 = ((i) + (((int)(1))));
                
                //#line 206 "x10/regionarray/PolyMat.x10"
                i = t$153179;
            }
        }}catch (final x10.regionarray.UnboundedRegionException e) {
            
            //#line 210 "x10/regionarray/PolyMat.x10"
            return false;
        }
        
        //#line 212 "x10/regionarray/PolyMat.x10"
        return true;
    }
    
    
    //#line 215 "x10/regionarray/PolyMat.x10"
    public boolean isBounded$O() {
        
        //#line 216 "x10/regionarray/PolyMat.x10"
        try {{
            
            //#line 217 "x10/regionarray/PolyMat.x10"
            int i = 0;
            
            //#line 217 "x10/regionarray/PolyMat.x10"
            for (;
                 true;
                 ) {
                
                //#line 217 "x10/regionarray/PolyMat.x10"
                final long t$152981 = ((long)(((int)(i))));
                
                //#line 217 "x10/regionarray/PolyMat.x10"
                final long t$152982 = this.rank;
                
                //#line 217 "x10/regionarray/PolyMat.x10"
                final boolean t$152987 = ((t$152981) < (((long)(t$152982))));
                
                //#line 217 "x10/regionarray/PolyMat.x10"
                if (!(t$152987)) {
                    
                    //#line 217 "x10/regionarray/PolyMat.x10"
                    break;
                }
                
                //#line 218 "x10/regionarray/PolyMat.x10"
                this.rectMin$O((int)(i));
                
                //#line 219 "x10/regionarray/PolyMat.x10"
                this.rectMax$O((int)(i));
                
                //#line 217 "x10/regionarray/PolyMat.x10"
                final int t$153183 = ((i) + (((int)(1))));
                
                //#line 217 "x10/regionarray/PolyMat.x10"
                i = t$153183;
            }
        }}catch (final x10.regionarray.UnboundedRegionException e) {
            
            //#line 222 "x10/regionarray/PolyMat.x10"
            return false;
        }
        
        //#line 224 "x10/regionarray/PolyMat.x10"
        return true;
    }
    
    
    //#line 234 "x10/regionarray/PolyMat.x10"
    /**
     * A set of halfspaces is empty iff, after eliminating all
     * variables with FME, we are left with a contradiction, i.e. a
     * halfspace k<=0 where k>0.
     */
    public boolean isEmpty$O() {
        
        //#line 236 "x10/regionarray/PolyMat.x10"
        x10.regionarray.PolyMat pm = this;
        
        //#line 237 "x10/regionarray/PolyMat.x10"
        int i$153195 = 0;
        
        //#line 237 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 237 "x10/regionarray/PolyMat.x10"
            final long t$153197 = ((long)(((int)(i$153195))));
            
            //#line 237 "x10/regionarray/PolyMat.x10"
            final long t$153198 = this.rank;
            
            //#line 237 "x10/regionarray/PolyMat.x10"
            final boolean t$153199 = ((t$153197) < (((long)(t$153198))));
            
            //#line 237 "x10/regionarray/PolyMat.x10"
            if (!(t$153199)) {
                
                //#line 237 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 238 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyMat t$153186 = ((x10.regionarray.PolyMat)(pm.eliminate((int)(i$153195), (boolean)(false))));
            
            //#line 238 "x10/regionarray/PolyMat.x10"
            pm = ((x10.regionarray.PolyMat)(t$153186));
            
            //#line 237 "x10/regionarray/PolyMat.x10"
            final int t$153188 = ((i$153195) + (((int)(1))));
            
            //#line 237 "x10/regionarray/PolyMat.x10"
            i$153195 = t$153188;
        }
        
        //#line 241 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153201 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)pm).iterator();
        
        //#line 241 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 241 "x10/regionarray/PolyMat.x10"
            final boolean t$153202 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153201).hasNext$O();
            
            //#line 241 "x10/regionarray/PolyMat.x10"
            if (!(t$153202)) {
                
                //#line 241 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 241 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153189 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153201).next$G();
            
            //#line 242 "x10/regionarray/PolyMat.x10"
            final long t$153190 = this.rank;
            
            //#line 242 "x10/regionarray/PolyMat.x10"
            final int t$153191 = ((int)(long)(((long)(t$153190))));
            
            //#line 242 "x10/regionarray/PolyMat.x10"
            final int t$153192 = r$153189.$apply$O((int)(t$153191));
            
            //#line 242 "x10/regionarray/PolyMat.x10"
            final long t$153193 = ((long)(((int)(t$153192))));
            
            //#line 242 "x10/regionarray/PolyMat.x10"
            final boolean t$153194 = ((t$153193) > (((long)(0L))));
            
            //#line 242 "x10/regionarray/PolyMat.x10"
            if (t$153194) {
                
                //#line 243 "x10/regionarray/PolyMat.x10"
                return true;
            }
        }
        
        //#line 246 "x10/regionarray/PolyMat.x10"
        return false;
    }
    
    
    //#line 254 "x10/regionarray/PolyMat.x10"
    /**
     * Concatenate matrices
     */
    public x10.regionarray.PolyMat $or(final x10.regionarray.PolyMat that) {
        
        //#line 255 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 255 "x10/regionarray/PolyMat.x10"
        final long t$153205 = this.rank;
        
        //#line 255 "x10/regionarray/PolyMat.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$153205)));
        
        //#line 256 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153206 = this.iterator();
        
        //#line 256 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 256 "x10/regionarray/PolyMat.x10"
            final boolean t$153207 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153206).hasNext$O();
            
            //#line 256 "x10/regionarray/PolyMat.x10"
            if (!(t$153207)) {
                
                //#line 256 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 256 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153203 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153206).next$G();
            
            //#line 257 "x10/regionarray/PolyMat.x10"
            pmb.add(((x10.regionarray.Row)(r$153203)));
        }
        
        //#line 258 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153208 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)that).iterator();
        
        //#line 258 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 258 "x10/regionarray/PolyMat.x10"
            final boolean t$153209 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153208).hasNext$O();
            
            //#line 258 "x10/regionarray/PolyMat.x10"
            if (!(t$153209)) {
                
                //#line 258 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 258 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153204 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153208).next$G();
            
            //#line 259 "x10/regionarray/PolyMat.x10"
            pmb.add(((x10.regionarray.Row)(r$153204)));
        }
        
        //#line 260 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMat t$153011 = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 260 "x10/regionarray/PolyMat.x10"
        return t$153011;
    }
    
    
    //#line 264 "x10/regionarray/PolyMat.x10"
    public java.lang.String toString() {
        
        //#line 266 "x10/regionarray/PolyMat.x10"
        java.lang.String s = "(";
        
        //#line 267 "x10/regionarray/PolyMat.x10"
        boolean first = true;
        
        //#line 269 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153218 = this.iterator();
        
        //#line 269 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 269 "x10/regionarray/PolyMat.x10"
            final boolean t$153219 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153218).hasNext$O();
            
            //#line 269 "x10/regionarray/PolyMat.x10"
            if (!(t$153219)) {
                
                //#line 269 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 269 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153210 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153218).next$G();
            
            //#line 270 "x10/regionarray/PolyMat.x10"
            final boolean t$153212 = !(first);
            
            //#line 270 "x10/regionarray/PolyMat.x10"
            if (t$153212) {
                
                //#line 270 "x10/regionarray/PolyMat.x10"
                final java.lang.String t$153214 = ((s) + (" && "));
                
                //#line 270 "x10/regionarray/PolyMat.x10"
                s = ((java.lang.String)(t$153214));
            }
            
            //#line 271 "x10/regionarray/PolyMat.x10"
            final java.lang.String t$153216 = r$153210.toString();
            
            //#line 271 "x10/regionarray/PolyMat.x10"
            final java.lang.String t$153217 = ((s) + (t$153216));
            
            //#line 271 "x10/regionarray/PolyMat.x10"
            s = ((java.lang.String)(t$153217));
            
            //#line 272 "x10/regionarray/PolyMat.x10"
            first = false;
        }
        
        //#line 275 "x10/regionarray/PolyMat.x10"
        final java.lang.String t$153022 = ((s) + (")"));
        
        //#line 275 "x10/regionarray/PolyMat.x10"
        s = ((java.lang.String)(t$153022));
        
        //#line 276 "x10/regionarray/PolyMat.x10"
        return s;
    }
    
    
    //#line 26 "x10/regionarray/PolyMat.x10"
    final public x10.regionarray.PolyMat x10$regionarray$PolyMat$$this$x10$regionarray$PolyMat() {
        
        //#line 26 "x10/regionarray/PolyMat.x10"
        return x10.regionarray.PolyMat.this;
    }
    
    
    //#line 26 "x10/regionarray/PolyMat.x10"
    final public void __fieldInitializers_x10_regionarray_PolyMat() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$204 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$204> $RTT = 
            x10.rtt.StaticFunType.<$Closure$204> make($Closure$204.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyMat.$Closure$204 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.i = $deserializer.readLong();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyMat.$Closure$204 $_obj = new x10.regionarray.PolyMat.$Closure$204((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.i);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$204(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Int.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Int.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 {}
        
    
        
        public int $apply$O(final int j$153025) {
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final int t$153026 = ((int)(long)(((long)(this.i))));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final int t$153027 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int>)this.init).$apply(x10.core.Int.$box(t$153026), x10.rtt.Types.INT, x10.core.Int.$box(j$153025), x10.rtt.Types.INT));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            return t$153027;
        }
        
        public long i;
        public x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init;
        
        public $Closure$204(final long i, final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init, __1$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
             {
                this.i = i;
                this.init = ((x10.core.fun.Fun_0_2)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$205 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$205> $RTT = 
            x10.rtt.StaticFunType.<$Closure$205> make($Closure$205.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.regionarray.PolyRow.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyMat.$Closure$205 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cols = $deserializer.readInt();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyMat.$Closure$205 $_obj = new x10.regionarray.PolyMat.$Closure$205((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cols);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$205(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 {}
        
    
        
        public x10.regionarray.PolyRow $apply(final long i) {
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow alloc$152155 = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final x10.core.fun.Fun_0_1 t$153024 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyMat.$Closure$204(i, ((x10.core.fun.Fun_0_2)(this.init)), (x10.regionarray.PolyMat.$Closure$204.__1$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2) null)));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            alloc$152155.x10$regionarray$PolyRow$$init$S(this.cols, ((x10.core.fun.Fun_0_1)(t$153024)), (x10.regionarray.PolyRow.__1$1x10$lang$Int$3x10$lang$Int$2) null);
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            return alloc$152155;
        }
        
        public x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init;
        public int cols;
        
        public $Closure$205(final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init, final int cols, __0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
             {
                this.init = ((x10.core.fun.Fun_0_2)(init));
                this.cols = cols;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$206 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$206> $RTT = 
            x10.rtt.StaticFunType.<$Closure$206> make($Closure$206.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyMat.$Closure$206 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.as_$153111 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyMat.$Closure$206 $_obj = new x10.regionarray.PolyMat.$Closure$206((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.as_$153111);
            
        }
        
        // constructor just for allocation
        public $Closure$206(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$2 {}
        
    
        
        public int $apply$O(final long i$153136) {
            
            //#line 145 "x10/regionarray/PolyMat.x10"
            final int t$153137 = ((int[])this.as_$153111.value)[(int)i$153136];
            
            //#line 145 "x10/regionarray/PolyMat.x10"
            return t$153137;
        }
        
        public x10.core.Rail<x10.core.Int> as_$153111;
        
        public $Closure$206(final x10.core.Rail<x10.core.Int> as_$153111, __0$1x10$lang$Int$2 $dummy) {
             {
                this.as_$153111 = ((x10.core.Rail)(as_$153111));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$207 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$207> $RTT = 
            x10.rtt.StaticFunType.<$Closure$207> make($Closure$207.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyMat.$Closure$207 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyMat.$Closure$207 $_obj = new x10.regionarray.PolyMat.$Closure$207((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$207(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public int $apply$O(final long i) {
            
            //#line 198 "x10/regionarray/PolyMat.x10"
            final int t$152957 = ((int)(long)(((long)(i))));
            
            //#line 198 "x10/regionarray/PolyMat.x10"
            final int t$152958 = this.out$$.rectMin$O((int)(t$152957));
            
            //#line 198 "x10/regionarray/PolyMat.x10"
            return t$152958;
        }
        
        public x10.regionarray.PolyMat out$$;
        
        public $Closure$207(final x10.regionarray.PolyMat out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$208 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$208> $RTT = 
            x10.rtt.StaticFunType.<$Closure$208> make($Closure$208.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyMat.$Closure$208 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyMat.$Closure$208 $_obj = new x10.regionarray.PolyMat.$Closure$208((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$208(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public int $apply$O(final long i) {
            
            //#line 200 "x10/regionarray/PolyMat.x10"
            final int t$152962 = ((int)(long)(((long)(i))));
            
            //#line 200 "x10/regionarray/PolyMat.x10"
            final int t$152963 = this.out$$.rectMax$O((int)(t$152962));
            
            //#line 200 "x10/regionarray/PolyMat.x10"
            return t$152963;
        }
        
        public x10.regionarray.PolyMat out$$;
        
        public $Closure$208(final x10.regionarray.PolyMat out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
}


