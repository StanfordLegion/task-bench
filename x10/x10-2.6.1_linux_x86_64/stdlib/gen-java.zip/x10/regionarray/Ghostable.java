package x10.regionarray;

/**
 * A Ghostable array allows the sending of ghost data to other places.
 * This is an interface to DistArray, to avoid the use of generic types
 * in the interface GhostManager.
 */
@x10.runtime.impl.java.X10Generated
public interface Ghostable extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<Ghostable> $RTT = 
        x10.rtt.NamedType.<Ghostable> make("x10.regionarray.Ghostable",
                                           Ghostable.class);
    
    

    
    
    //#line 21 "x10/regionarray/Ghostable.x10"
    /** Gets the distribution over which this Ghostable array is defined. */
    x10.regionarray.Dist getDist();
    
    
    //#line 38 "x10/regionarray/Ghostable.x10"
    /**
     * Collect data from the given overlap region from this place and send to
     * the ghost region at neighborPlace, shifted by the given shift.
     * @param overlap the region of this place that overlaps with the ghost
     *   region at the neighboring place
     * @param neighborPlace the neighboring place
     * @param shift the vector by which to shift the overlap region at the
     *   neighboring place.  Must be null e.g. [0, 0, ..., 0] for non-periodic
     *   distributions; for a periodic distribution, the shift will be non-zero
     *   in any dimension for which the overlap region wraps past the edge
     *   of the full region.
     * @param phase the phase for which these ghosts are valid. If the
     *   neighboring place has not yet reached this phase, the ghosts will be
     *   held awaiting the change of phase.
     */
    void putOverlap(final x10.regionarray.Region overlap, final x10.lang.Place neighborPlace, final x10.lang.Point shift, final byte phase);
}

