package x10.regionarray;

/**
 * A GhostManager manages the ghost region at a single place, including
 * sending ghost data to other places.
 * Intended for use in a phased computation: in each phase, ghost data are
 * updated at all places, then used at all places.
 * However, synchronization is local between neighboring places, rather than
 * global between all places.
 */
@x10.runtime.impl.java.X10Generated
abstract public class GhostManager extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<GhostManager> $RTT = 
        x10.rtt.NamedType.<GhostManager> make("x10.regionarray.GhostManager",
                                              GhostManager.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.GhostManager $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.currentPhase = $deserializer.readByte();
        $_obj.ghostWidth = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.currentPhase);
        $serializer.write(this.ghostWidth);
        
    }
    
    // constructor just for allocation
    public GhostManager(final java.lang.System[] $dummy) {
        
    }
    
    

    
    //#line 27 "x10/regionarray/GhostManager.x10"
    /**
     * The width of the "ghost" region for which each place should
     * hold a copy of data stored at neighboring places.
     */
    public long ghostWidth;
    
    //#line 35 "x10/regionarray/GhostManager.x10"
    /**
     * The current phase of the computation with regard to ghost cell updates.
     * Places are assumed to progress together; in even phases, ghost cells are
     * used; in odd phases, ghost cells are updated.  No place may start phase 
     * P+2 before neighboring places have completed phase P.
     */
    public byte currentPhase;
    
    
    //#line 37 "x10/regionarray/GhostManager.x10"
    
    // constructor for non-virtual call
    final public x10.regionarray.GhostManager x10$regionarray$GhostManager$$init$S(final long ghostWidth) {
         {
            
            //#line 37 "x10/regionarray/GhostManager.x10"
            
            
            //#line 22 "x10/regionarray/GhostManager.x10"
            final x10.regionarray.GhostManager this$151186 = this;
            
            //#line 22 "x10/regionarray/GhostManager.x10"
            this$151186.currentPhase = ((byte) 0);
            
            //#line 38 "x10/regionarray/GhostManager.x10"
            this.ghostWidth = ghostWidth;
            
            //#line 39 "x10/regionarray/GhostManager.x10"
            this.currentPhase = ((byte) 0);
        }
        return this;
    }
    
    
    
    //#line 42 "x10/regionarray/GhostManager.x10"
    final public byte currentPhase$O() {
        
        //#line 43 "x10/regionarray/GhostManager.x10"
        final byte t$151183 = this.currentPhase;
        
        //#line 43 "x10/regionarray/GhostManager.x10"
        return t$151183;
    }
    
    
    //#line 47 "x10/regionarray/GhostManager.x10"
    /** Get the neighboring places that hold ghost regions for this place. */
    abstract public x10.core.Rail getNeighbors();
    
    
    //#line 50 "x10/regionarray/GhostManager.x10"
    /** @return the ghost region at the given place */
    abstract public x10.regionarray.Region getGhostRegion(final x10.lang.Place place);
    
    
    //#line 52 "x10/regionarray/GhostManager.x10"
    abstract public void setNeighborReceived(final x10.lang.Place place, final x10.lang.Point shift);
    
    
    //#line 53 "x10/regionarray/GhostManager.x10"
    abstract public boolean allNeighborsReceived$O();
    
    
    //#line 54 "x10/regionarray/GhostManager.x10"
    abstract public void resetNeighborsReceived();
    
    
    //#line 55 "x10/regionarray/GhostManager.x10"
    abstract public void sendGhosts(final x10.regionarray.Ghostable array);
    
    
    //#line 61 "x10/regionarray/GhostManager.x10"
    /** 
     * Wait for all ghosts to be received and then return.
     * Used to switch ghost manager phase from sending to using ghost data.
     */
    public void waitOnGhosts() {
        {
            
            //#line 62 "x10/regionarray/GhostManager.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 62 "x10/regionarray/GhostManager.x10"
            try {{
                
                //#line 62 "x10/regionarray/GhostManager.x10"
                x10.xrx.Runtime.enterAtomic();
                
                //#line 62 "x10/regionarray/GhostManager.x10"
                while (true) {
                    
                    //#line 62 "x10/regionarray/GhostManager.x10"
                    if (this.allNeighborsReceived$O()) {
                        {
                            
                            //#line 63 "x10/regionarray/GhostManager.x10"
                            this.currentPhase = ((byte) ((this.currentPhase) + (((byte)(((byte) 1))))));
                            
                            //#line 64 "x10/regionarray/GhostManager.x10"
                            this.resetNeighborsReceived();
                        }
                        
                        //#line 62 "x10/regionarray/GhostManager.x10"
                        break;
                    }
                    
                    //#line 62 "x10/regionarray/GhostManager.x10"
                    x10.xrx.Runtime.awaitAtomic();
                }
            }}finally {{
                  
                  //#line 62 "x10/regionarray/GhostManager.x10"
                  x10.xrx.Runtime.exitAtomic();
              }}
            }
        }
    
    
    //#line 72 "x10/regionarray/GhostManager.x10"
    /**
     * Prepare to send ghosts to other places.
     * Used to switch ghost manager phase from using to sending ghost data.
     */
    public void prepareToSendGhosts() {
        
        //#line 72 "x10/regionarray/GhostManager.x10"
        try {{
            
            //#line 72 "x10/regionarray/GhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 73 "x10/regionarray/GhostManager.x10"
                final byte t$151184 = this.currentPhase;
                
                //#line 73 "x10/regionarray/GhostManager.x10"
                final byte t$151185 = ((byte) ((t$151184) + (((byte)(((byte) 1))))));
                
                //#line 73 "x10/regionarray/GhostManager.x10"
                this.currentPhase = t$151185;
            }
        }}finally {{
              
              //#line 72 "x10/regionarray/GhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 79 "x10/regionarray/GhostManager.x10"
    /**
     * A GhostNeighborFlag holds the status of a neighbor place for a GhostManager.
     */
    @x10.runtime.impl.java.X10Generated
    public static class GhostNeighborFlag extends x10.core.Ref implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<GhostNeighborFlag> $RTT = 
            x10.rtt.NamedType.<GhostNeighborFlag> make("x10.regionarray.GhostManager.GhostNeighborFlag",
                                                       GhostNeighborFlag.class);
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.GhostManager.GhostNeighborFlag $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.place = $deserializer.readObject();
            $_obj.received = $deserializer.readBoolean();
            $_obj.shift = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.GhostManager.GhostNeighborFlag $_obj = new x10.regionarray.GhostManager.GhostNeighborFlag((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.place);
            $serializer.write(this.received);
            $serializer.write(this.shift);
            
        }
        
        // constructor just for allocation
        public GhostNeighborFlag(final java.lang.System[] $dummy) {
            
        }
        
        
        // properties
        
        //#line 79 "x10/regionarray/GhostManager.x10"
        public x10.lang.Place place;
        
        //#line 79 "x10/regionarray/GhostManager.x10"
        public x10.lang.Point shift;
        
    
        
        //#line 80 "x10/regionarray/GhostManager.x10"
        public boolean received;
        
        
        //#line 79 "x10/regionarray/GhostManager.x10"
        final public x10.regionarray.GhostManager.GhostNeighborFlag x10$regionarray$GhostManager$GhostNeighborFlag$$this$x10$regionarray$GhostManager$GhostNeighborFlag() {
            
            //#line 79 "x10/regionarray/GhostManager.x10"
            return x10.regionarray.GhostManager.GhostNeighborFlag.this;
        }
        
        
        //#line 79 "x10/regionarray/GhostManager.x10"
        // creation method for java code (1-phase java constructor)
        public GhostNeighborFlag(final x10.lang.Place place, final x10.lang.Point shift) {
            this((java.lang.System[]) null);
            x10$regionarray$GhostManager$GhostNeighborFlag$$init$S(place, shift);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.GhostManager.GhostNeighborFlag x10$regionarray$GhostManager$GhostNeighborFlag$$init$S(final x10.lang.Place place, final x10.lang.Point shift) {
             {
                
                //#line 79 "x10/regionarray/GhostManager.x10"
                this.place = place;
                this.shift = shift;
                
                
                //#line 79 "x10/regionarray/GhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag this$151181 = this;
                
                //#line 79 "x10/regionarray/GhostManager.x10"
                this$151181.received = false;
            }
            return this;
        }
        
        
        
        //#line 79 "x10/regionarray/GhostManager.x10"
        final public void __fieldInitializers_x10_regionarray_GhostManager_GhostNeighborFlag() {
            
            //#line 79 "x10/regionarray/GhostManager.x10"
            this.received = false;
        }
    }
    
    
    
    //#line 22 "x10/regionarray/GhostManager.x10"
    final public x10.regionarray.GhostManager x10$regionarray$GhostManager$$this$x10$regionarray$GhostManager() {
        
        //#line 22 "x10/regionarray/GhostManager.x10"
        return x10.regionarray.GhostManager.this;
    }
    
    
    //#line 22 "x10/regionarray/GhostManager.x10"
    final public void __fieldInitializers_x10_regionarray_GhostManager() {
        
        //#line 22 "x10/regionarray/GhostManager.x10"
        this.currentPhase = ((byte) 0);
    }
    }
    
    