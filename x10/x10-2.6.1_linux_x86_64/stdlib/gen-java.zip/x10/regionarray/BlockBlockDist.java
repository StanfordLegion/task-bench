package x10.regionarray;


/**
 * <p>A BlockBlock distribution maps points in its region
 * in a 2D blocked fashion to the places in its PlaceGroup</p>
 *
 * It caches the region for the current place as a transient field.
 * This makes the initial access to this information somewhat slow,
 * but optimizes the wire-transfer size of the Dist object. 
 * This appears to be the appropriate tradeoff, since Dist objects
 * are frequently serialized and usually the restriction operation is 
 * applied to get the Region for here, not for other places.
 */
@x10.runtime.impl.java.X10Generated
final public class BlockBlockDist extends x10.regionarray.Dist implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<BlockBlockDist> $RTT = 
        x10.rtt.NamedType.<BlockBlockDist> make("x10.regionarray.BlockBlockDist",
                                                BlockBlockDist.class,
                                                new x10.rtt.Type[] {
                                                    x10.regionarray.Dist.$RTT
                                                });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockBlockDist $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Dist.$_deserialize_body($_obj, $deserializer);
        $_obj.axis0 = $deserializer.readLong();
        $_obj.axis1 = $deserializer.readLong();
        $_obj.pg = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.BlockBlockDist $_obj = new x10.regionarray.BlockBlockDist((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.axis0);
        $serializer.write(this.axis1);
        $serializer.write(this.pg);
        
    }
    
    // constructor just for allocation
    public BlockBlockDist(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 32 "x10/regionarray/BlockBlockDist.x10"
    /**
     * The place group for this distribution
     */
    public x10.lang.PlaceGroup pg;
    
    //#line 37 "x10/regionarray/BlockBlockDist.x10"
    /**
     * The first axis along which the region is distributed
     */
    public long axis0;
    
    //#line 42 "x10/regionarray/BlockBlockDist.x10"
    /**
     * The second axis along which the region is distributed
     */
    public long axis1;
    
    //#line 47 "x10/regionarray/BlockBlockDist.x10"
    /**
     * Cached restricted region for the current place.
     */
    public transient x10.regionarray.Region regionForHere;
    
    
    //#line 50 "x10/regionarray/BlockBlockDist.x10"
    // creation method for java code (1-phase java constructor)
    public BlockBlockDist(final x10.regionarray.Region r, final long axis0, final long axis1, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null);
        x10$regionarray$BlockBlockDist$$init$S(r, axis0, axis1, pg);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.BlockBlockDist x10$regionarray$BlockBlockDist$$init$S(final x10.regionarray.Region r, final long axis0, final long axis1, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 51 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Dist this$143827 = ((x10.regionarray.Dist)(this));
            
            //#line 548 . "x10/regionarray/Dist.x10"
            this$143827.region = r;
            
            //#line 50 "x10/regionarray/BlockBlockDist.x10"
            
            
            //#line 27 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.BlockBlockDist this$147116 = this;
            
            //#line 27 "x10/regionarray/BlockBlockDist.x10"
            this$147116.regionForHere = null;
            
            //#line 52 "x10/regionarray/BlockBlockDist.x10"
            this.axis0 = axis0;
            
            //#line 53 "x10/regionarray/BlockBlockDist.x10"
            this.axis1 = axis1;
            
            //#line 54 "x10/regionarray/BlockBlockDist.x10"
            this.pg = ((x10.lang.PlaceGroup)(pg));
        }
        return this;
    }
    
    
    
    //#line 65 "x10/regionarray/BlockBlockDist.x10"
    /**
     * The key algorithm for this class.
     * Compute the region for the given place by doing region algebra.
     *
     * Assumption: Caller has done error checking to ensure that place is 
     *   actually a member of pg.
     */
    private x10.regionarray.Region blockBlockRegionForPlace(final x10.lang.Place place) {
        
        //#line 66 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$146826 = ((x10.regionarray.Region)(this.region));
        
        //#line 66 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region b = ((x10.regionarray.Region)(t$146826.boundingBox()));
        
        //#line 67 "x10/regionarray/BlockBlockDist.x10"
        final long t$146827 = this.axis0;
        
        //#line 67 "x10/regionarray/BlockBlockDist.x10"
        final long min0 = b.min$O((long)(t$146827));
        
        //#line 68 "x10/regionarray/BlockBlockDist.x10"
        final long t$146828 = this.axis0;
        
        //#line 68 "x10/regionarray/BlockBlockDist.x10"
        final long max0 = b.max$O((long)(t$146828));
        
        //#line 69 "x10/regionarray/BlockBlockDist.x10"
        final long t$146829 = this.axis1;
        
        //#line 69 "x10/regionarray/BlockBlockDist.x10"
        final long min1 = b.min$O((long)(t$146829));
        
        //#line 70 "x10/regionarray/BlockBlockDist.x10"
        final long t$146830 = this.axis1;
        
        //#line 70 "x10/regionarray/BlockBlockDist.x10"
        final long max1 = b.max$O((long)(t$146830));
        
        //#line 71 "x10/regionarray/BlockBlockDist.x10"
        final long t$146831 = ((max0) - (((long)(min0))));
        
        //#line 71 "x10/regionarray/BlockBlockDist.x10"
        final long size0 = ((t$146831) + (((long)(1L))));
        
        //#line 72 "x10/regionarray/BlockBlockDist.x10"
        final long t$146832 = ((max1) - (((long)(min1))));
        
        //#line 72 "x10/regionarray/BlockBlockDist.x10"
        final long size1 = ((t$146832) + (((long)(1L))));
        
        //#line 73 "x10/regionarray/BlockBlockDist.x10"
        final long divisions0;
        
        //#line 74 "x10/regionarray/BlockBlockDist.x10"
        final long P;
        
        //#line 75 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$146853 = ((size0) > (((long)(1L))));
        
        //#line 75 "x10/regionarray/BlockBlockDist.x10"
        if (t$146853) {
            
            //#line 76 "x10/regionarray/BlockBlockDist.x10"
            final long t$146833 = ((size0) % (((long)(2L))));
            
            //#line 76 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$146834 = ((long) t$146833) == ((long) 0L);
            
            //#line 76 "x10/regionarray/BlockBlockDist.x10"
            long t$146835 =  0;
            
            //#line 76 "x10/regionarray/BlockBlockDist.x10"
            if (t$146834) {
                
                //#line 76 "x10/regionarray/BlockBlockDist.x10"
                t$146835 = size0;
            } else {
                
                //#line 76 "x10/regionarray/BlockBlockDist.x10"
                t$146835 = ((size0) - (((long)(1L))));
            }
            
            //#line 77 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$146836 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 77 "x10/regionarray/BlockBlockDist.x10"
            final long t$146837 = t$146836.numPlaces$O();
            
            //#line 77 "x10/regionarray/BlockBlockDist.x10"
            final long t$146838 = t$146837;
            
            //#line 77 "x10/regionarray/BlockBlockDist.x10"
            final long t$146839 = ((t$146835) * (((long)(size1))));
            
            //#line 77 "x10/regionarray/BlockBlockDist.x10"
            final long t$146840 = java.lang.Math.min(((long)(t$146838)),((long)(t$146839)));
            
            //#line 77 "x10/regionarray/BlockBlockDist.x10"
            P = t$146840;
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final double t$146841 = ((double)(long)(((long)(P))));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final double t$146842 = java.lang.Math.log(((double)(t$146841)));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final double t$146843 = java.lang.Math.log(((double)(2.0)));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final double t$146844 = ((t$146842) / (((double)(t$146843))));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final double t$146845 = ((t$146844) / (((double)(2.0))));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final double t$146846 = java.lang.Math.ceil(((double)(t$146845)));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final long t$146847 = ((long)(double)(((double)(t$146846))));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final long t$146848 = x10.lang.Math.pow2$O((long)(t$146847));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final long t$146849 = java.lang.Math.min(((long)(t$146835)),((long)(t$146848)));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            divisions0 = t$146849;
        } else {
            
            //#line 80 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$146850 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 80 "x10/regionarray/BlockBlockDist.x10"
            final long t$146851 = t$146850.numPlaces$O();
            
            //#line 80 "x10/regionarray/BlockBlockDist.x10"
            final long t$146852 = java.lang.Math.min(((long)(t$146851)),((long)(size1)));
            
            //#line 80 "x10/regionarray/BlockBlockDist.x10"
            P = t$146852;
            
            //#line 81 "x10/regionarray/BlockBlockDist.x10"
            divisions0 = 1L;
        }
        
        //#line 83 "x10/regionarray/BlockBlockDist.x10"
        final double t$146854 = ((double)(long)(((long)(P))));
        
        //#line 83 "x10/regionarray/BlockBlockDist.x10"
        final double t$146855 = ((double)(long)(((long)(divisions0))));
        
        //#line 83 "x10/regionarray/BlockBlockDist.x10"
        final double t$146856 = ((t$146854) / (((double)(t$146855))));
        
        //#line 83 "x10/regionarray/BlockBlockDist.x10"
        final double t$146857 = java.lang.Math.ceil(((double)(t$146856)));
        
        //#line 83 "x10/regionarray/BlockBlockDist.x10"
        final long t$146858 = ((long)(double)(((double)(t$146857))));
        
        //#line 83 "x10/regionarray/BlockBlockDist.x10"
        final long divisions1 = java.lang.Math.min(((long)(size1)),((long)(t$146858)));
        
        //#line 84 "x10/regionarray/BlockBlockDist.x10"
        final long t$146859 = ((divisions0) * (((long)(divisions1))));
        
        //#line 84 "x10/regionarray/BlockBlockDist.x10"
        final long leftOver = ((t$146859) - (((long)(P))));
        
        //#line 86 "x10/regionarray/BlockBlockDist.x10"
        final x10.lang.PlaceGroup t$146860 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 86 "x10/regionarray/BlockBlockDist.x10"
        final long i = t$146860.indexOf$O(((x10.lang.Place)(place)));
        
        //#line 87 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$146863 = ((i) >= (((long)(P))));
        
        //#line 87 "x10/regionarray/BlockBlockDist.x10"
        if (t$146863) {
            
            //#line 87 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Dist this$143832 = ((x10.regionarray.Dist)
                                                       this);
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$146861 = ((x10.regionarray.Region)(this$143832.region));
            
            //#line 87 "x10/regionarray/BlockBlockDist.x10"
            final long rank$143834 = t$146861.rank;
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.EmptyRegion alloc$143835 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            alloc$143835.x10$regionarray$EmptyRegion$$init$S(((long)(rank$143834)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$146862 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$143835)));
            
            //#line 87 "x10/regionarray/BlockBlockDist.x10"
            return t$146862;
        }
        
        //#line 89 "x10/regionarray/BlockBlockDist.x10"
        final long t$146864 = ((divisions0) % (((long)(2L))));
        
        //#line 89 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$146867 = ((long) t$146864) == ((long) 0L);
        
        //#line 89 "x10/regionarray/BlockBlockDist.x10"
        long t$146868 =  0;
        
        //#line 89 "x10/regionarray/BlockBlockDist.x10"
        if (t$146867) {
            
            //#line 89 "x10/regionarray/BlockBlockDist.x10"
            t$146868 = 0L;
        } else {
            
            //#line 89 "x10/regionarray/BlockBlockDist.x10"
            final long t$146865 = ((i) * (((long)(2L))));
            
            //#line 89 "x10/regionarray/BlockBlockDist.x10"
            final long t$146866 = ((divisions0) + (((long)(1L))));
            
            //#line 89 "x10/regionarray/BlockBlockDist.x10"
            t$146868 = ((t$146865) / (((long)(t$146866))));
        }
        
        //#line 91 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$146872 = ((i) < (((long)(leftOver))));
        
        //#line 91 "x10/regionarray/BlockBlockDist.x10"
        long t$146873 =  0;
        
        //#line 91 "x10/regionarray/BlockBlockDist.x10"
        if (t$146872) {
            
            //#line 91 "x10/regionarray/BlockBlockDist.x10"
            final long t$146869 = ((i) * (((long)(2L))));
            
            //#line 91 "x10/regionarray/BlockBlockDist.x10"
            final long t$146870 = ((t$146869) - (((long)(t$146868))));
            
            //#line 91 "x10/regionarray/BlockBlockDist.x10"
            t$146873 = ((t$146870) % (((long)(divisions0))));
        } else {
            
            //#line 91 "x10/regionarray/BlockBlockDist.x10"
            final long t$146871 = ((i) + (((long)(leftOver))));
            
            //#line 91 "x10/regionarray/BlockBlockDist.x10"
            t$146873 = ((t$146871) % (((long)(divisions0))));
        }
        
        //#line 92 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$146876 = ((i) < (((long)(leftOver))));
        
        //#line 92 "x10/regionarray/BlockBlockDist.x10"
        long t$146877 =  0;
        
        //#line 92 "x10/regionarray/BlockBlockDist.x10"
        if (t$146876) {
            
            //#line 92 "x10/regionarray/BlockBlockDist.x10"
            final long t$146874 = ((i) * (((long)(2L))));
            
            //#line 92 "x10/regionarray/BlockBlockDist.x10"
            t$146877 = ((t$146874) / (((long)(divisions0))));
        } else {
            
            //#line 92 "x10/regionarray/BlockBlockDist.x10"
            final long t$146875 = ((i) + (((long)(leftOver))));
            
            //#line 92 "x10/regionarray/BlockBlockDist.x10"
            t$146877 = ((t$146875) / (((long)(divisions0))));
        }
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final long t$146878 = ((t$146873) * (((long)(size0))));
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final double t$146879 = ((double)(long)(((long)(t$146878))));
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final double t$146880 = ((double)(long)(((long)(divisions0))));
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final double t$146881 = ((t$146879) / (((double)(t$146880))));
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final double t$146882 = java.lang.Math.ceil(((double)(t$146881)));
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final long t$146883 = ((long)(double)(((double)(t$146882))));
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final long low0 = ((min0) + (((long)(t$146883))));
        
        //#line 95 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$146884 = ((i) < (((long)(leftOver))));
        
        //#line 95 "x10/regionarray/BlockBlockDist.x10"
        long t$146885 =  0;
        
        //#line 95 "x10/regionarray/BlockBlockDist.x10"
        if (t$146884) {
            
            //#line 95 "x10/regionarray/BlockBlockDist.x10"
            t$146885 = 2L;
        } else {
            
            //#line 95 "x10/regionarray/BlockBlockDist.x10"
            t$146885 = 1L;
        }
        
        //#line 95 "x10/regionarray/BlockBlockDist.x10"
        final long blockHi0 = ((t$146873) + (((long)(t$146885))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final long t$146887 = ((blockHi0) * (((long)(size0))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final double t$146888 = ((double)(long)(((long)(t$146887))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final double t$146889 = ((double)(long)(((long)(divisions0))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final double t$146890 = ((t$146888) / (((double)(t$146889))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final double t$146891 = java.lang.Math.ceil(((double)(t$146890)));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final long t$146892 = ((long)(double)(((double)(t$146891))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final long t$146893 = ((min0) + (((long)(t$146892))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final long hi0 = ((t$146893) - (((long)(1L))));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final long t$146894 = ((t$146877) * (((long)(size1))));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final double t$146895 = ((double)(long)(((long)(t$146894))));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final double t$146896 = ((double)(long)(((long)(divisions1))));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final double t$146897 = ((t$146895) / (((double)(t$146896))));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final double t$146898 = java.lang.Math.ceil(((double)(t$146897)));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final long t$146899 = ((long)(double)(((double)(t$146898))));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final long low1 = ((min1) + (((long)(t$146899))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final long t$146900 = ((t$146877) + (((long)(1L))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final long t$146901 = ((t$146900) * (((long)(size1))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final double t$146902 = ((double)(long)(((long)(t$146901))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final double t$146903 = ((double)(long)(((long)(divisions1))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final double t$146904 = ((t$146902) / (((double)(t$146903))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final double t$146905 = java.lang.Math.ceil(((double)(t$146904)));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final long t$146906 = ((long)(double)(((double)(t$146905))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final long t$146907 = ((min1) + (((long)(t$146906))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final long hi1 = ((t$146907) - (((long)(1L))));
        
        //#line 101 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$146908 = ((x10.regionarray.Region)(this.region));
        
        //#line 101 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$146978 = x10.regionarray.RectRegion.$RTT.isInstance(t$146908);
        
        //#line 101 "x10/regionarray/BlockBlockDist.x10"
        if (t$146978) {
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Dist this$143954 = ((x10.regionarray.Dist)
                                                       this);
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$146909 = ((x10.regionarray.Region)(this$143954.region));
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final long t$146914 = t$146909.rank;
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final x10.core.fun.Fun_0_1 t$146915 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockBlockDist.$Closure$160(this, this.region)));
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$146914)), ((x10.core.fun.Fun_0_1)(t$146915)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Dist this$143956 = ((x10.regionarray.Dist)
                                                       this);
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$146916 = ((x10.regionarray.Region)(this$143956.region));
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final long t$146921 = t$146916.rank;
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final x10.core.fun.Fun_0_1 t$146922 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockBlockDist.$Closure$161(this, this.region)));
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$146921)), ((x10.core.fun.Fun_0_1)(t$146922)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 105 "x10/regionarray/BlockBlockDist.x10"
            final long t$146923 = this.axis0;
            
            //#line 105 "x10/regionarray/BlockBlockDist.x10"
            ((long[])newMin.value)[(int)t$146923] = low0;
            
            //#line 106 "x10/regionarray/BlockBlockDist.x10"
            final long t$146924 = this.axis1;
            
            //#line 106 "x10/regionarray/BlockBlockDist.x10"
            ((long[])newMin.value)[(int)t$146924] = low1;
            
            //#line 107 "x10/regionarray/BlockBlockDist.x10"
            final long t$146925 = this.axis0;
            
            //#line 107 "x10/regionarray/BlockBlockDist.x10"
            ((long[])newMax.value)[(int)t$146925] = hi0;
            
            //#line 108 "x10/regionarray/BlockBlockDist.x10"
            final long t$146926 = this.axis1;
            
            //#line 108 "x10/regionarray/BlockBlockDist.x10"
            ((long[])newMax.value)[(int)t$146926] = hi1;
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.RectRegion alloc$143042 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            alloc$143042.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$142785 = ((x10.regionarray.Region)
                                                      alloc$143042);
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final long t$146928 = t$142785.rank;
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$146927 = ((x10.regionarray.Region)(x10.regionarray.BlockBlockDist.this.region));
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final long t$146929 = t$146927.rank;
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$146930 = ((long) t$146928) == ((long) t$146929);
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$146932 = !(t$146930);
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            if (t$146932) {
                
                //#line 109 "x10/regionarray/BlockBlockDist.x10"
                final x10.lang.FailedDynamicCheckException t$146931 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.BlockBlockDist).region.rank}");
                
                //#line 109 "x10/regionarray/BlockBlockDist.x10"
                throw t$146931;
            }
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            return t$142785;
        } else {
            
            //#line 112 "x10/regionarray/BlockBlockDist.x10"
            final long t$146933 = this.axis1;
            
            //#line 112 "x10/regionarray/BlockBlockDist.x10"
            final long t$146934 = this.axis0;
            
            //#line 112 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$146935 = ((t$146933) > (((long)(t$146934))));
            
            //#line 112 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Region t$146936 =  null;
            
            //#line 112 "x10/regionarray/BlockBlockDist.x10"
            if (t$146935) {
                
                //#line 112 "x10/regionarray/BlockBlockDist.x10"
                final long rank$145568 = this.axis0;
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$145569 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$145569.x10$regionarray$FullRegion$$init$S(((long)(rank$145568)));
                
                //#line 112 "x10/regionarray/BlockBlockDist.x10"
                t$146936 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                       alloc$145569)));
            } else {
                
                //#line 112 "x10/regionarray/BlockBlockDist.x10"
                final long rank$145903 = this.axis1;
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$145904 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$145904.x10$regionarray$FullRegion$$init$S(((long)(rank$145903)));
                
                //#line 112 "x10/regionarray/BlockBlockDist.x10"
                t$146936 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                       alloc$145904)));
            }
            
            //#line 113 "x10/regionarray/BlockBlockDist.x10"
            final long t$146937 = this.axis1;
            
            //#line 113 "x10/regionarray/BlockBlockDist.x10"
            final long t$146938 = this.axis0;
            
            //#line 113 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$146947 = ((t$146937) > (((long)(t$146938))));
            
            //#line 113 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Region t$146948 =  null;
            
            //#line 113 "x10/regionarray/BlockBlockDist.x10"
            if (t$146947) {
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$146939 = this.axis1;
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$146940 = this.axis0;
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$146941 = ((t$146939) - (((long)(t$146940))));
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$146942 = ((long)(((int)(1))));
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long rank$145906 = ((t$146941) - (((long)(t$146942))));
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$145907 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$145907.x10$regionarray$FullRegion$$init$S(((long)(rank$145906)));
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                t$146948 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                       alloc$145907)));
            } else {
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$146943 = this.axis0;
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$146944 = this.axis1;
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$146945 = ((t$146943) - (((long)(t$146944))));
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$146946 = ((long)(((int)(1))));
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long rank$145909 = ((t$146945) - (((long)(t$146946))));
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$145910 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$145910.x10$regionarray$FullRegion$$init$S(((long)(rank$145909)));
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                t$146948 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                       alloc$145910)));
            }
            
            //#line 114 "x10/regionarray/BlockBlockDist.x10"
            final long t$146949 = this.axis1;
            
            //#line 114 "x10/regionarray/BlockBlockDist.x10"
            final long t$146950 = this.axis0;
            
            //#line 114 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$146961 = ((t$146949) > (((long)(t$146950))));
            
            //#line 114 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Region t$146962 =  null;
            
            //#line 114 "x10/regionarray/BlockBlockDist.x10"
            if (t$146961) {
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final x10.regionarray.Region t$146951 = ((x10.regionarray.Region)(this.region));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$146952 = t$146951.rank;
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$146953 = this.axis1;
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$146954 = ((t$146952) - (((long)(t$146953))));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$146955 = ((long)(((int)(1))));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long rank$145912 = ((t$146954) - (((long)(t$146955))));
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$145913 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$145913.x10$regionarray$FullRegion$$init$S(((long)(rank$145912)));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                t$146962 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                       alloc$145913)));
            } else {
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final x10.regionarray.Region t$146956 = ((x10.regionarray.Region)(this.region));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$146957 = t$146956.rank;
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$146958 = this.axis0;
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$146959 = ((t$146957) - (((long)(t$146958))));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$146960 = ((long)(((int)(1))));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long rank$145915 = ((t$146959) - (((long)(t$146960))));
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$145916 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$145916.x10$regionarray$FullRegion$$init$S(((long)(rank$145915)));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                t$146962 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                       alloc$145916)));
            }
            
            //#line 115 "x10/regionarray/BlockBlockDist.x10"
            long lowFirst =  0;
            
            //#line 116 "x10/regionarray/BlockBlockDist.x10"
            final long hiFirst;
            
            //#line 117 "x10/regionarray/BlockBlockDist.x10"
            final long lowSecond;
            
            //#line 118 "x10/regionarray/BlockBlockDist.x10"
            final long hiSecond;
            
            //#line 119 "x10/regionarray/BlockBlockDist.x10"
            final long t$146963 = this.axis1;
            
            //#line 119 "x10/regionarray/BlockBlockDist.x10"
            final long t$146964 = this.axis0;
            
            //#line 119 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$146965 = ((t$146963) > (((long)(t$146964))));
            
            //#line 119 "x10/regionarray/BlockBlockDist.x10"
            if (t$146965) {
                
                //#line 120 "x10/regionarray/BlockBlockDist.x10"
                lowFirst = low0;
                
                //#line 121 "x10/regionarray/BlockBlockDist.x10"
                lowSecond = low1;
                
                //#line 122 "x10/regionarray/BlockBlockDist.x10"
                hiFirst = hi0;
                
                //#line 123 "x10/regionarray/BlockBlockDist.x10"
                hiSecond = hi1;
            } else {
                
                //#line 125 "x10/regionarray/BlockBlockDist.x10"
                lowFirst = low1;
                
                //#line 126 "x10/regionarray/BlockBlockDist.x10"
                lowSecond = low0;
                
                //#line 127 "x10/regionarray/BlockBlockDist.x10"
                hiFirst = hi1;
                
                //#line 128 "x10/regionarray/BlockBlockDist.x10"
                hiSecond = hi0;
            }
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$145920 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            alloc$145920.x10$regionarray$RectRegion1D$$init$S(lowFirst, hiFirst);
            
            //#line 130 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region rFirst = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                              alloc$145920)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$145924 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            alloc$145924.x10$regionarray$RectRegion1D$$init$S(lowSecond, hiSecond);
            
            //#line 131 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region rSecond = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                               alloc$145924)));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$146966 = ((x10.regionarray.Region)(t$146936.product(((x10.regionarray.Region)(rFirst)))));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$146967 = ((x10.regionarray.Region)(t$146966.product(((x10.regionarray.Region)(t$146948)))));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$146968 = ((x10.regionarray.Region)(t$146967.product(((x10.regionarray.Region)(rSecond)))));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$146969 = ((x10.regionarray.Region)(t$146968.product(((x10.regionarray.Region)(t$146962)))));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$142871 = ((x10.regionarray.Region)
                                                      t$146969);
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final long t$146971 = t$142871.rank;
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$146970 = ((x10.regionarray.Region)(x10.regionarray.BlockBlockDist.this.region));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final long t$146972 = t$146970.rank;
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$146973 = ((long) t$146971) == ((long) t$146972);
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$146975 = !(t$146973);
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            if (t$146975) {
                
                //#line 133 "x10/regionarray/BlockBlockDist.x10"
                final x10.lang.FailedDynamicCheckException t$146974 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.BlockBlockDist).region.rank}");
                
                //#line 133 "x10/regionarray/BlockBlockDist.x10"
                throw t$146974;
            }
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$146976 = ((x10.regionarray.Region)(this.region));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$146977 = ((x10.regionarray.Region)(t$142871.intersection(((x10.regionarray.Region)(t$146976)))));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            return t$146977;
        }
    }
    
    public static x10.regionarray.Region blockBlockRegionForPlace$P(final x10.lang.Place place, final x10.regionarray.BlockBlockDist BlockBlockDist) {
        return BlockBlockDist.blockBlockRegionForPlace(((x10.lang.Place)(place)));
    }
    
    
    //#line 143 "x10/regionarray/BlockBlockDist.x10"
    /**
     * Given an index into the "axis dimensions" determine which place it 
     * is mapped to.
     * Assumption: Caller has done error checking to ensure that index is 
     *   actually within the bounds of the axis dimension.
     */
    private x10.lang.Place mapIndexToPlace(final long index0, final long index1) {
        
        //#line 144 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$146979 = ((x10.regionarray.Region)(this.region));
        
        //#line 144 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region b = ((x10.regionarray.Region)(t$146979.boundingBox()));
        
        //#line 145 "x10/regionarray/BlockBlockDist.x10"
        final long t$146980 = this.axis0;
        
        //#line 145 "x10/regionarray/BlockBlockDist.x10"
        final long min0 = b.min$O((long)(t$146980));
        
        //#line 146 "x10/regionarray/BlockBlockDist.x10"
        final long t$146981 = this.axis0;
        
        //#line 146 "x10/regionarray/BlockBlockDist.x10"
        final long max0 = b.max$O((long)(t$146981));
        
        //#line 147 "x10/regionarray/BlockBlockDist.x10"
        final long t$146982 = this.axis1;
        
        //#line 147 "x10/regionarray/BlockBlockDist.x10"
        final long min1 = b.min$O((long)(t$146982));
        
        //#line 148 "x10/regionarray/BlockBlockDist.x10"
        final long t$146983 = this.axis1;
        
        //#line 148 "x10/regionarray/BlockBlockDist.x10"
        final long max1 = b.max$O((long)(t$146983));
        
        //#line 149 "x10/regionarray/BlockBlockDist.x10"
        final long t$146984 = ((max0) - (((long)(min0))));
        
        //#line 149 "x10/regionarray/BlockBlockDist.x10"
        final long size0 = ((t$146984) + (((long)(1L))));
        
        //#line 150 "x10/regionarray/BlockBlockDist.x10"
        final long t$146985 = ((max1) - (((long)(min1))));
        
        //#line 150 "x10/regionarray/BlockBlockDist.x10"
        final long size1 = ((t$146985) + (((long)(1L))));
        
        //#line 151 "x10/regionarray/BlockBlockDist.x10"
        final long divisions0;
        
        //#line 152 "x10/regionarray/BlockBlockDist.x10"
        final long P;
        
        //#line 153 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147006 = ((size0) > (((long)(1L))));
        
        //#line 153 "x10/regionarray/BlockBlockDist.x10"
        if (t$147006) {
            
            //#line 154 "x10/regionarray/BlockBlockDist.x10"
            final long t$146986 = ((size0) % (((long)(2L))));
            
            //#line 154 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$146987 = ((long) t$146986) == ((long) 0L);
            
            //#line 154 "x10/regionarray/BlockBlockDist.x10"
            long t$146988 =  0;
            
            //#line 154 "x10/regionarray/BlockBlockDist.x10"
            if (t$146987) {
                
                //#line 154 "x10/regionarray/BlockBlockDist.x10"
                t$146988 = size0;
            } else {
                
                //#line 154 "x10/regionarray/BlockBlockDist.x10"
                t$146988 = ((size0) - (((long)(1L))));
            }
            
            //#line 155 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$146989 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 155 "x10/regionarray/BlockBlockDist.x10"
            final long t$146990 = t$146989.numPlaces$O();
            
            //#line 155 "x10/regionarray/BlockBlockDist.x10"
            final long t$146991 = t$146990;
            
            //#line 155 "x10/regionarray/BlockBlockDist.x10"
            final long t$146992 = ((t$146988) * (((long)(size1))));
            
            //#line 155 "x10/regionarray/BlockBlockDist.x10"
            final long t$146993 = java.lang.Math.min(((long)(t$146991)),((long)(t$146992)));
            
            //#line 155 "x10/regionarray/BlockBlockDist.x10"
            P = t$146993;
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final double t$146994 = ((double)(long)(((long)(P))));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final double t$146995 = java.lang.Math.log(((double)(t$146994)));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final double t$146996 = java.lang.Math.log(((double)(2.0)));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final double t$146997 = ((t$146995) / (((double)(t$146996))));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final double t$146998 = ((t$146997) / (((double)(2.0))));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final double t$146999 = java.lang.Math.ceil(((double)(t$146998)));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final long t$147000 = ((long)(double)(((double)(t$146999))));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final long t$147001 = x10.lang.Math.pow2$O((long)(t$147000));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final long t$147002 = java.lang.Math.min(((long)(t$146988)),((long)(t$147001)));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            divisions0 = t$147002;
        } else {
            
            //#line 158 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$147003 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 158 "x10/regionarray/BlockBlockDist.x10"
            final long t$147004 = t$147003.numPlaces$O();
            
            //#line 158 "x10/regionarray/BlockBlockDist.x10"
            final long t$147005 = java.lang.Math.min(((long)(t$147004)),((long)(size1)));
            
            //#line 158 "x10/regionarray/BlockBlockDist.x10"
            P = t$147005;
            
            //#line 159 "x10/regionarray/BlockBlockDist.x10"
            divisions0 = 1L;
        }
        
        //#line 161 "x10/regionarray/BlockBlockDist.x10"
        final double t$147007 = ((double)(long)(((long)(P))));
        
        //#line 161 "x10/regionarray/BlockBlockDist.x10"
        final double t$147008 = ((double)(long)(((long)(divisions0))));
        
        //#line 161 "x10/regionarray/BlockBlockDist.x10"
        final double t$147009 = ((t$147007) / (((double)(t$147008))));
        
        //#line 161 "x10/regionarray/BlockBlockDist.x10"
        final double t$147010 = java.lang.Math.ceil(((double)(t$147009)));
        
        //#line 161 "x10/regionarray/BlockBlockDist.x10"
        final long t$147011 = ((long)(double)(((double)(t$147010))));
        
        //#line 161 "x10/regionarray/BlockBlockDist.x10"
        final long divisions1 = java.lang.Math.min(((long)(size1)),((long)(t$147011)));
        
        //#line 162 "x10/regionarray/BlockBlockDist.x10"
        final long numBlocks = ((divisions0) * (((long)(divisions1))));
        
        //#line 163 "x10/regionarray/BlockBlockDist.x10"
        final long leftOver = ((numBlocks) - (((long)(P))));
        
        //#line 165 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147014 = ((long) divisions0) == ((long) 1L);
        
        //#line 165 "x10/regionarray/BlockBlockDist.x10"
        long t$147015 =  0;
        
        //#line 165 "x10/regionarray/BlockBlockDist.x10"
        if (t$147014) {
            
            //#line 165 "x10/regionarray/BlockBlockDist.x10"
            t$147015 = 0L;
        } else {
            
            //#line 165 "x10/regionarray/BlockBlockDist.x10"
            final long t$147012 = ((index0) - (((long)(min0))));
            
            //#line 165 "x10/regionarray/BlockBlockDist.x10"
            final long t$147013 = ((t$147012) * (((long)(divisions0))));
            
            //#line 165 "x10/regionarray/BlockBlockDist.x10"
            t$147015 = ((t$147013) / (((long)(size0))));
        }
        
        //#line 166 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147018 = ((long) divisions1) == ((long) 1L);
        
        //#line 166 "x10/regionarray/BlockBlockDist.x10"
        long t$147019 =  0;
        
        //#line 166 "x10/regionarray/BlockBlockDist.x10"
        if (t$147018) {
            
            //#line 166 "x10/regionarray/BlockBlockDist.x10"
            t$147019 = 0L;
        } else {
            
            //#line 166 "x10/regionarray/BlockBlockDist.x10"
            final long t$147016 = ((index1) - (((long)(min1))));
            
            //#line 166 "x10/regionarray/BlockBlockDist.x10"
            final long t$147017 = ((t$147016) * (((long)(divisions1))));
            
            //#line 166 "x10/regionarray/BlockBlockDist.x10"
            t$147019 = ((t$147017) / (((long)(size1))));
        }
        
        //#line 167 "x10/regionarray/BlockBlockDist.x10"
        final long t$147020 = ((t$147019) * (((long)(divisions0))));
        
        //#line 167 "x10/regionarray/BlockBlockDist.x10"
        final long blockIndex = ((t$147020) + (((long)(t$147015))));
        
        //#line 169 "x10/regionarray/BlockBlockDist.x10"
        final long t$147021 = ((leftOver) * (((long)(2L))));
        
        //#line 169 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147032 = ((blockIndex) <= (((long)(t$147021))));
        
        //#line 169 "x10/regionarray/BlockBlockDist.x10"
        if (t$147032) {
            
            //#line 170 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$147024 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 170 "x10/regionarray/BlockBlockDist.x10"
            final long t$147022 = ((blockIndex) / (((long)(2L))));
            
            //#line 170 "x10/regionarray/BlockBlockDist.x10"
            final int t$147023 = ((int)(long)(((long)(t$147022))));
            
            //#line 170 "x10/regionarray/BlockBlockDist.x10"
            final long t$147025 = ((long)(((int)(t$147023))));
            
            //#line 170 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.Place t$147026 = t$147024.$apply((long)(t$147025));
            
            //#line 170 "x10/regionarray/BlockBlockDist.x10"
            return t$147026;
        } else {
            
            //#line 172 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$147029 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 172 "x10/regionarray/BlockBlockDist.x10"
            final long t$147027 = ((blockIndex) - (((long)(leftOver))));
            
            //#line 172 "x10/regionarray/BlockBlockDist.x10"
            final int t$147028 = ((int)(long)(((long)(t$147027))));
            
            //#line 172 "x10/regionarray/BlockBlockDist.x10"
            final long t$147030 = ((long)(((int)(t$147028))));
            
            //#line 172 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.Place t$147031 = t$147029.$apply((long)(t$147030));
            
            //#line 172 "x10/regionarray/BlockBlockDist.x10"
            return t$147031;
        }
    }
    
    public static x10.lang.Place mapIndexToPlace$P(final long index0, final long index1, final x10.regionarray.BlockBlockDist BlockBlockDist) {
        return BlockBlockDist.mapIndexToPlace((long)(index0), (long)(index1));
    }
    
    
    //#line 176 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.PlaceGroup places() {
        
        //#line 176 "x10/regionarray/BlockBlockDist.x10"
        final x10.lang.PlaceGroup t$147033 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 176 "x10/regionarray/BlockBlockDist.x10"
        return t$147033;
    }
    
    
    //#line 178 "x10/regionarray/BlockBlockDist.x10"
    public long numPlaces$O() {
        
        //#line 178 "x10/regionarray/BlockBlockDist.x10"
        final x10.lang.PlaceGroup t$147034 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 178 "x10/regionarray/BlockBlockDist.x10"
        final long t$147035 = t$147034.numPlaces$O();
        
        //#line 178 "x10/regionarray/BlockBlockDist.x10"
        return t$147035;
    }
    
    
    //#line 180 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.Iterable regions() {
        
        //#line 181 "x10/regionarray/BlockBlockDist.x10"
        final x10.lang.PlaceGroup t$147036 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 181 "x10/regionarray/BlockBlockDist.x10"
        final long t$147042 = t$147036.numPlaces$O();
        
        //#line 181 "x10/regionarray/BlockBlockDist.x10"
        final x10.core.fun.Fun_0_1 t$147043 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockBlockDist.$Closure$162(this, this.pg)));
        
        //#line 181 "x10/regionarray/BlockBlockDist.x10"
        final x10.core.Rail t$147044 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.Region>(x10.regionarray.Region.$RTT, t$147042, ((x10.core.fun.Fun_0_1)(t$147043)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 181 "x10/regionarray/BlockBlockDist.x10"
        return t$147044;
    }
    
    
    //#line 184 "x10/regionarray/BlockBlockDist.x10"
    public x10.regionarray.Region get(final x10.lang.Place p) {
        
        //#line 185 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147050 = x10.rtt.Equality.equalsequals((p),(x10.x10rt.X10RT.here()));
        
        //#line 185 "x10/regionarray/BlockBlockDist.x10"
        if (t$147050) {
            
            //#line 186 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147045 = ((x10.regionarray.Region)(this.regionForHere));
            
            //#line 186 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147047 = ((t$147045) == (null));
            
            //#line 186 "x10/regionarray/BlockBlockDist.x10"
            if (t$147047) {
                
                //#line 187 "x10/regionarray/BlockBlockDist.x10"
                final x10.regionarray.Region t$147046 = ((x10.regionarray.Region)(this.blockBlockRegionForPlace(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 187 "x10/regionarray/BlockBlockDist.x10"
                this.regionForHere = ((x10.regionarray.Region)(t$147046));
            }
            
            //#line 189 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147048 = ((x10.regionarray.Region)(this.regionForHere));
            
            //#line 189 "x10/regionarray/BlockBlockDist.x10"
            return t$147048;
        } else {
            
            //#line 191 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147049 = ((x10.regionarray.Region)(this.blockBlockRegionForPlace(((x10.lang.Place)(p)))));
            
            //#line 191 "x10/regionarray/BlockBlockDist.x10"
            return t$147049;
        }
    }
    
    
    //#line 195 "x10/regionarray/BlockBlockDist.x10"
    public boolean containsLocally$O(final x10.lang.Point p) {
        
        //#line 195 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147051 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
        
        //#line 195 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147052 = t$147051.contains$O(((x10.lang.Point)(p)));
        
        //#line 195 "x10/regionarray/BlockBlockDist.x10"
        return t$147052;
    }
    
    
    //#line 198 "x10/regionarray/BlockBlockDist.x10"
    public x10.regionarray.Region $apply(final x10.lang.Place p) {
        
        //#line 198 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147053 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(p)))));
        
        //#line 198 "x10/regionarray/BlockBlockDist.x10"
        return t$147053;
    }
    
    
    //#line 200 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.Place $apply(final x10.lang.Point pt) {
        
        //#line 201 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147054 = ((x10.regionarray.Region)(this.region));
        
        //#line 201 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147055 = t$147054.contains$O(((x10.lang.Point)(pt)));
        
        //#line 201 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147056 = !(t$147055);
        
        //#line 201 "x10/regionarray/BlockBlockDist.x10"
        if (t$147056) {
            
            //#line 201 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError(((x10.lang.Point)(pt)));
        }
        
        //#line 202 "x10/regionarray/BlockBlockDist.x10"
        final long t$147057 = this.axis0;
        
        //#line 202 "x10/regionarray/BlockBlockDist.x10"
        final long t$147059 = pt.$apply$O((long)(t$147057));
        
        //#line 202 "x10/regionarray/BlockBlockDist.x10"
        final long t$147058 = this.axis1;
        
        //#line 202 "x10/regionarray/BlockBlockDist.x10"
        final long t$147060 = pt.$apply$O((long)(t$147058));
        
        //#line 202 "x10/regionarray/BlockBlockDist.x10"
        final x10.lang.Place t$147061 = this.mapIndexToPlace((long)(t$147059), (long)(t$147060));
        
        //#line 202 "x10/regionarray/BlockBlockDist.x10"
        return t$147061;
    }
    
    
    //#line 205 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.Place $apply(final long i0) {
        
        //#line 207 "x10/regionarray/BlockBlockDist.x10"
        final java.lang.UnsupportedOperationException t$147064 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException("operator(i0:Long)")));
        
        //#line 207 "x10/regionarray/BlockBlockDist.x10"
        throw t$147064;
    }
    
    
    //#line 210 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1) {
        
        //#line 211 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147067 = ((x10.regionarray.Region)(this.region));
        
        //#line 211 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147068 = t$147067.contains$O((long)(i0), (long)(i1));
        
        //#line 211 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147069 = !(t$147068);
        
        //#line 211 "x10/regionarray/BlockBlockDist.x10"
        if (t$147069) {
            
            //#line 211 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1));
        }
        
        //#line 212 "x10/regionarray/BlockBlockDist.x10"
        final long t$147070 = this.axis0;
        
        //#line 212 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147071 = ((long) t$147070) == ((long) 0L);
        
        //#line 212 "x10/regionarray/BlockBlockDist.x10"
        x10.lang.Place t$147072 =  null;
        
        //#line 212 "x10/regionarray/BlockBlockDist.x10"
        if (t$147071) {
            
            //#line 212 "x10/regionarray/BlockBlockDist.x10"
            t$147072 = this.mapIndexToPlace((long)(i0), (long)(i1));
        } else {
            
            //#line 212 "x10/regionarray/BlockBlockDist.x10"
            t$147072 = this.mapIndexToPlace((long)(i1), (long)(i0));
        }
        
        //#line 212 "x10/regionarray/BlockBlockDist.x10"
        return t$147072;
    }
    
    
    //#line 215 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2) {
        
        //#line 216 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147076 = ((x10.regionarray.Region)(this.region));
        
        //#line 216 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147077 = t$147076.contains$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 216 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147078 = !(t$147077);
        
        //#line 216 "x10/regionarray/BlockBlockDist.x10"
        if (t$147078) {
            
            //#line 216 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 217 "x10/regionarray/BlockBlockDist.x10"
        final long t$147079 = this.axis0;
        
        //#line 217 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147094 = ((long) t$147079) == ((long) 0L);
        
        //#line 217 "x10/regionarray/BlockBlockDist.x10"
        if (t$147094) {
            
            //#line 218 "x10/regionarray/BlockBlockDist.x10"
            final long t$147080 = this.axis1;
            
            //#line 218 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147081 = ((long) t$147080) == ((long) 1L);
            
            //#line 218 "x10/regionarray/BlockBlockDist.x10"
            x10.lang.Place t$147082 =  null;
            
            //#line 218 "x10/regionarray/BlockBlockDist.x10"
            if (t$147081) {
                
                //#line 218 "x10/regionarray/BlockBlockDist.x10"
                t$147082 = this.mapIndexToPlace((long)(i0), (long)(i1));
            } else {
                
                //#line 218 "x10/regionarray/BlockBlockDist.x10"
                t$147082 = this.mapIndexToPlace((long)(i0), (long)(i2));
            }
            
            //#line 218 "x10/regionarray/BlockBlockDist.x10"
            return t$147082;
        } else {
            
            //#line 219 "x10/regionarray/BlockBlockDist.x10"
            final long t$147084 = this.axis0;
            
            //#line 219 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147093 = ((long) t$147084) == ((long) 1L);
            
            //#line 219 "x10/regionarray/BlockBlockDist.x10"
            if (t$147093) {
                
                //#line 220 "x10/regionarray/BlockBlockDist.x10"
                final long t$147085 = this.axis1;
                
                //#line 220 "x10/regionarray/BlockBlockDist.x10"
                final boolean t$147086 = ((long) t$147085) == ((long) 0L);
                
                //#line 220 "x10/regionarray/BlockBlockDist.x10"
                x10.lang.Place t$147087 =  null;
                
                //#line 220 "x10/regionarray/BlockBlockDist.x10"
                if (t$147086) {
                    
                    //#line 220 "x10/regionarray/BlockBlockDist.x10"
                    t$147087 = this.mapIndexToPlace((long)(i1), (long)(i0));
                } else {
                    
                    //#line 220 "x10/regionarray/BlockBlockDist.x10"
                    t$147087 = this.mapIndexToPlace((long)(i1), (long)(i2));
                }
                
                //#line 220 "x10/regionarray/BlockBlockDist.x10"
                return t$147087;
            } else {
                
                //#line 222 "x10/regionarray/BlockBlockDist.x10"
                final long t$147089 = this.axis1;
                
                //#line 222 "x10/regionarray/BlockBlockDist.x10"
                final boolean t$147090 = ((long) t$147089) == ((long) 0L);
                
                //#line 222 "x10/regionarray/BlockBlockDist.x10"
                x10.lang.Place t$147091 =  null;
                
                //#line 222 "x10/regionarray/BlockBlockDist.x10"
                if (t$147090) {
                    
                    //#line 222 "x10/regionarray/BlockBlockDist.x10"
                    t$147091 = this.mapIndexToPlace((long)(i2), (long)(i0));
                } else {
                    
                    //#line 222 "x10/regionarray/BlockBlockDist.x10"
                    t$147091 = this.mapIndexToPlace((long)(i2), (long)(i1));
                }
                
                //#line 222 "x10/regionarray/BlockBlockDist.x10"
                return t$147091;
            }
        }
    }
    
    
    //#line 226 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 154 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$145938 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 154 . "x10/lang/Point.x10"
        alloc$145938.x10$lang$Point$$init$S(i0, i1, i2, i3);
        
        //#line 228 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147097 = ((x10.regionarray.Region)(this.region));
        
        //#line 228 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147098 = t$147097.contains$O(((x10.lang.Point)(alloc$145938)));
        
        //#line 228 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147099 = !(t$147098);
        
        //#line 228 "x10/regionarray/BlockBlockDist.x10"
        if (t$147099) {
            
            //#line 228 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError(((x10.lang.Point)(alloc$145938)));
        }
        
        //#line 229 "x10/regionarray/BlockBlockDist.x10"
        final long t$147100 = this.axis0;
        
        //#line 229 "x10/regionarray/BlockBlockDist.x10"
        final long t$147102 = alloc$145938.$apply$O((long)(t$147100));
        
        //#line 229 "x10/regionarray/BlockBlockDist.x10"
        final long t$147101 = this.axis1;
        
        //#line 229 "x10/regionarray/BlockBlockDist.x10"
        final long t$147103 = alloc$145938.$apply$O((long)(t$147101));
        
        //#line 229 "x10/regionarray/BlockBlockDist.x10"
        final x10.lang.Place t$147104 = this.mapIndexToPlace((long)(t$147102), (long)(t$147103));
        
        //#line 229 "x10/regionarray/BlockBlockDist.x10"
        return t$147104;
    }
    
    
    //#line 232 "x10/regionarray/BlockBlockDist.x10"
    public x10.regionarray.Dist restriction(final x10.regionarray.Region r) {
        
        //#line 233 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.WrappedDistRegionRestricted alloc$143043 = ((x10.regionarray.WrappedDistRegionRestricted)(new x10.regionarray.WrappedDistRegionRestricted((java.lang.System[]) null)));
        
        //#line 233 "x10/regionarray/BlockBlockDist.x10"
        alloc$143043.x10$regionarray$WrappedDistRegionRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.regionarray.Region)(r)));
        
        //#line 233 "x10/regionarray/BlockBlockDist.x10"
        return alloc$143043;
    }
    
    
    //#line 236 "x10/regionarray/BlockBlockDist.x10"
    public x10.regionarray.Dist restriction(final x10.lang.Place p) {
        
        //#line 237 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.WrappedDistPlaceRestricted alloc$143044 = ((x10.regionarray.WrappedDistPlaceRestricted)(new x10.regionarray.WrappedDistPlaceRestricted((java.lang.System[]) null)));
        
        //#line 237 "x10/regionarray/BlockBlockDist.x10"
        alloc$143044.x10$regionarray$WrappedDistPlaceRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.lang.Place)(p)));
        
        //#line 237 "x10/regionarray/BlockBlockDist.x10"
        return alloc$143044;
    }
    
    
    //#line 240 "x10/regionarray/BlockBlockDist.x10"
    public x10.regionarray.BlockBlockDistGhostManager getLocalGhostManager(final long ghostWidth, final boolean periodic) {
        
        //#line 241 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.BlockBlockDistGhostManager alloc$143045 = ((x10.regionarray.BlockBlockDistGhostManager)(new x10.regionarray.BlockBlockDistGhostManager((java.lang.System[]) null)));
        
        //#line 241 "x10/regionarray/BlockBlockDist.x10"
        alloc$143045.x10$regionarray$BlockBlockDistGhostManager$$init$S(((long)(ghostWidth)), ((x10.regionarray.Dist)(this)), ((boolean)(periodic)));
        
        //#line 241 "x10/regionarray/BlockBlockDist.x10"
        return alloc$143045;
    }
    
    
    //#line 244 "x10/regionarray/BlockBlockDist.x10"
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 245 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147105 = x10.regionarray.BlockBlockDist.$RTT.isInstance(thatObj);
        
        //#line 245 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147106 = !(t$147105);
        
        //#line 245 "x10/regionarray/BlockBlockDist.x10"
        if (t$147106) {
            
            //#line 245 "x10/regionarray/BlockBlockDist.x10"
            return false;
        }
        
        //#line 246 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.BlockBlockDist that = ((x10.regionarray.BlockBlockDist)(x10.rtt.Types.<x10.regionarray.BlockBlockDist> cast(thatObj,x10.regionarray.BlockBlockDist.$RTT)));
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        final long t$147107 = this.axis0;
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        final long t$147108 = that.axis0;
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        boolean t$147111 = x10.rtt.Equality.equalsequals(t$147107, ((long)(t$147108)));
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        if (t$147111) {
            
            //#line 247 "x10/regionarray/BlockBlockDist.x10"
            final long t$147109 = this.axis1;
            
            //#line 247 "x10/regionarray/BlockBlockDist.x10"
            final long t$147110 = that.axis1;
            
            //#line 247 "x10/regionarray/BlockBlockDist.x10"
            t$147111 = x10.rtt.Equality.equalsequals(t$147109, ((long)(t$147110)));
        }
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        boolean t$147114 = t$147111;
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        if (t$147111) {
            
            //#line 247 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147112 = ((x10.regionarray.Region)(this.region));
            
            //#line 247 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147113 = ((x10.regionarray.Region)(that.region));
            
            //#line 247 "x10/regionarray/BlockBlockDist.x10"
            t$147114 = t$147112.equals(((java.lang.Object)(t$147113)));
        }
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        return t$147114;
    }
    
    
    //#line 27 "x10/regionarray/BlockBlockDist.x10"
    final public x10.regionarray.BlockBlockDist x10$regionarray$BlockBlockDist$$this$x10$regionarray$BlockBlockDist() {
        
        //#line 27 "x10/regionarray/BlockBlockDist.x10"
        return x10.regionarray.BlockBlockDist.this;
    }
    
    
    //#line 27 "x10/regionarray/BlockBlockDist.x10"
    final public void __fieldInitializers_x10_regionarray_BlockBlockDist() {
        
        //#line 27 "x10/regionarray/BlockBlockDist.x10"
        this.regionForHere = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$160 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$160> $RTT = 
            x10.rtt.StaticFunType.<$Closure$160> make($Closure$160.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockBlockDist.$Closure$160 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.region = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockBlockDist.$Closure$160 $_obj = new x10.regionarray.BlockBlockDist.$Closure$160((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.region);
            
        }
        
        // constructor just for allocation
        public $Closure$160(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$146911 = ((x10.regionarray.Region)(this.region));
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final int t$146910 = ((int)(long)(((long)(i))));
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final long t$146912 = ((long)(((int)(t$146910))));
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final long t$146913 = t$146911.min$O((long)(t$146912));
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            return t$146913;
        }
        
        public x10.regionarray.BlockBlockDist out$$;
        public x10.regionarray.Region region;
        
        public $Closure$160(final x10.regionarray.BlockBlockDist out$$, final x10.regionarray.Region region) {
             {
                this.out$$ = out$$;
                this.region = ((x10.regionarray.Region)(region));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$161 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$161> $RTT = 
            x10.rtt.StaticFunType.<$Closure$161> make($Closure$161.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockBlockDist.$Closure$161 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.region = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockBlockDist.$Closure$161 $_obj = new x10.regionarray.BlockBlockDist.$Closure$161((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.region);
            
        }
        
        // constructor just for allocation
        public $Closure$161(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$146918 = ((x10.regionarray.Region)(this.region));
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final int t$146917 = ((int)(long)(((long)(i))));
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final long t$146919 = ((long)(((int)(t$146917))));
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final long t$146920 = t$146918.max$O((long)(t$146919));
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            return t$146920;
        }
        
        public x10.regionarray.BlockBlockDist out$$;
        public x10.regionarray.Region region;
        
        public $Closure$161(final x10.regionarray.BlockBlockDist out$$, final x10.regionarray.Region region) {
             {
                this.out$$ = out$$;
                this.region = ((x10.regionarray.Region)(region));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$162 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$162> $RTT = 
            x10.rtt.StaticFunType.<$Closure$162> make($Closure$162.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.regionarray.Region.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockBlockDist.$Closure$162 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockBlockDist.$Closure$162 $_obj = new x10.regionarray.BlockBlockDist.$Closure$162((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$162(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.regionarray.Region $apply(final long i) {
            
            //#line 181 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$147038 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 181 "x10/regionarray/BlockBlockDist.x10"
            final int t$147037 = ((int)(long)(((long)(i))));
            
            //#line 181 "x10/regionarray/BlockBlockDist.x10"
            final long t$147039 = ((long)(((int)(t$147037))));
            
            //#line 181 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.Place t$147040 = t$147038.$apply((long)(t$147039));
            
            //#line 181 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147041 = ((x10.regionarray.Region)(this.out$$.blockBlockRegionForPlace(((x10.lang.Place)(t$147040)))));
            
            //#line 181 "x10/regionarray/BlockBlockDist.x10"
            return t$147041;
        }
        
        public x10.regionarray.BlockBlockDist out$$;
        public x10.lang.PlaceGroup pg;
        
        public $Closure$162(final x10.regionarray.BlockBlockDist out$$, final x10.lang.PlaceGroup pg) {
             {
                this.out$$ = out$$;
                this.pg = ((x10.lang.PlaceGroup)(pg));
            }
        }
        
    }
    
}

