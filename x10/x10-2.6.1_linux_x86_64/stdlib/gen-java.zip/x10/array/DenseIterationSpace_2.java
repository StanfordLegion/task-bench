package x10.array;

/**
 * A DenseIterationSpace_2 represents the rank 2 
 * iteration space of points [min0,min1]..[max0,max1] inclusive.
 */
@x10.runtime.impl.java.X10Generated
final public class DenseIterationSpace_2 extends x10.array.IterationSpace implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DenseIterationSpace_2> $RTT = 
        x10.rtt.NamedType.<DenseIterationSpace_2> make("x10.array.DenseIterationSpace_2",
                                                       DenseIterationSpace_2.class,
                                                       new x10.rtt.Type[] {
                                                           x10.array.IterationSpace.$RTT
                                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_2 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.IterationSpace.$_deserialize_body($_obj, $deserializer);
        $_obj.max0 = $deserializer.readLong();
        $_obj.max1 = $deserializer.readLong();
        $_obj.min0 = $deserializer.readLong();
        $_obj.min1 = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DenseIterationSpace_2 $_obj = new x10.array.DenseIterationSpace_2((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.max0);
        $serializer.write(this.max1);
        $serializer.write(this.min0);
        $serializer.write(this.min1);
        
    }
    
    // constructor just for allocation
    public DenseIterationSpace_2(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 20 "x10/array/DenseIterationSpace_2.x10"
    public long min0;
    
    //#line 21 "x10/array/DenseIterationSpace_2.x10"
    public long min1;
    
    //#line 22 "x10/array/DenseIterationSpace_2.x10"
    public long max0;
    
    //#line 23 "x10/array/DenseIterationSpace_2.x10"
    public long max1;
    
    //#line 25 "x10/array/DenseIterationSpace_2.x10"
    private static x10.array.DenseIterationSpace_2 EMPTY;
    
    
    //#line 27 "x10/array/DenseIterationSpace_2.x10"
    // creation method for java code (1-phase java constructor)
    public DenseIterationSpace_2(final long min0, final long min1, final long max0, final long max1) {
        this((java.lang.System[]) null);
        x10$array$DenseIterationSpace_2$$init$S(min0, min1, max0, max1);
    }
    
    // constructor for non-virtual call
    final public x10.array.DenseIterationSpace_2 x10$array$DenseIterationSpace_2$$init$S(final long min0, final long min1, final long max0, final long max1) {
         {
            
            //#line 28 "x10/array/DenseIterationSpace_2.x10"
            final x10.array.IterationSpace this$104079 = ((x10.array.IterationSpace)(this));
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104079.rank = 2L;
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104079.rect = true;
            
            //#line 27 "x10/array/DenseIterationSpace_2.x10"
            
            
            //#line 29 "x10/array/DenseIterationSpace_2.x10"
            this.min0 = min0;
            
            //#line 30 "x10/array/DenseIterationSpace_2.x10"
            this.min1 = min1;
            
            //#line 31 "x10/array/DenseIterationSpace_2.x10"
            this.max0 = max0;
            
            //#line 32 "x10/array/DenseIterationSpace_2.x10"
            this.max1 = max1;
        }
        return this;
    }
    
    
    
    //#line 35 "x10/array/DenseIterationSpace_2.x10"
    public x10.array.DenseIterationSpace_3 $times(final x10.lang.LongRange that) {
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final x10.array.DenseIterationSpace_3 alloc$99028 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final long t$104159 = this.min0;
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final long t$104160 = this.min1;
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final long t$104161 = that.min;
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final long t$104162 = this.max0;
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final long t$104163 = this.max1;
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final long t$104164 = that.max;
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        alloc$99028.x10$array$DenseIterationSpace_3$$init$S(((long)(t$104159)), ((long)(t$104160)), ((long)(t$104161)), ((long)(t$104162)), ((long)(t$104163)), ((long)(t$104164)));
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        return alloc$99028;
    }
    
    
    //#line 39 "x10/array/DenseIterationSpace_2.x10"
    public long min$O(final long i) {
        
        //#line 40 "x10/array/DenseIterationSpace_2.x10"
        final boolean t$104097 = ((long) i) == ((long) 0L);
        
        //#line 40 "x10/array/DenseIterationSpace_2.x10"
        if (t$104097) {
            
            //#line 40 "x10/array/DenseIterationSpace_2.x10"
            final long t$104096 = this.min0;
            
            //#line 40 "x10/array/DenseIterationSpace_2.x10"
            return t$104096;
        }
        
        //#line 41 "x10/array/DenseIterationSpace_2.x10"
        final boolean t$104099 = ((long) i) == ((long) 1L);
        
        //#line 41 "x10/array/DenseIterationSpace_2.x10"
        if (t$104099) {
            
            //#line 41 "x10/array/DenseIterationSpace_2.x10"
            final long t$104098 = this.min1;
            
            //#line 41 "x10/array/DenseIterationSpace_2.x10"
            return t$104098;
        }
        
        //#line 42 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104100 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
        
        //#line 42 "x10/array/DenseIterationSpace_2.x10"
        final x10.lang.IllegalOperationException t$104101 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104100)));
        
        //#line 42 "x10/array/DenseIterationSpace_2.x10"
        throw t$104101;
    }
    
    
    //#line 45 "x10/array/DenseIterationSpace_2.x10"
    public long max$O(final long i) {
        
        //#line 46 "x10/array/DenseIterationSpace_2.x10"
        final boolean t$104103 = ((long) i) == ((long) 0L);
        
        //#line 46 "x10/array/DenseIterationSpace_2.x10"
        if (t$104103) {
            
            //#line 46 "x10/array/DenseIterationSpace_2.x10"
            final long t$104102 = this.max0;
            
            //#line 46 "x10/array/DenseIterationSpace_2.x10"
            return t$104102;
        }
        
        //#line 47 "x10/array/DenseIterationSpace_2.x10"
        final boolean t$104105 = ((long) i) == ((long) 1L);
        
        //#line 47 "x10/array/DenseIterationSpace_2.x10"
        if (t$104105) {
            
            //#line 47 "x10/array/DenseIterationSpace_2.x10"
            final long t$104104 = this.max1;
            
            //#line 47 "x10/array/DenseIterationSpace_2.x10"
            return t$104104;
        }
        
        //#line 48 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104106 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
        
        //#line 48 "x10/array/DenseIterationSpace_2.x10"
        final x10.lang.IllegalOperationException t$104107 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104106)));
        
        //#line 48 "x10/array/DenseIterationSpace_2.x10"
        throw t$104107;
    }
    
    
    //#line 51 "x10/array/DenseIterationSpace_2.x10"
    public boolean isEmpty$O() {
        
        //#line 51 "x10/array/DenseIterationSpace_2.x10"
        final long t$104108 = this.max0;
        
        //#line 51 "x10/array/DenseIterationSpace_2.x10"
        final long t$104109 = this.min0;
        
        //#line 51 "x10/array/DenseIterationSpace_2.x10"
        boolean t$104112 = ((t$104108) < (((long)(t$104109))));
        
        //#line 51 "x10/array/DenseIterationSpace_2.x10"
        if (!(t$104112)) {
            
            //#line 51 "x10/array/DenseIterationSpace_2.x10"
            final long t$104110 = this.max1;
            
            //#line 51 "x10/array/DenseIterationSpace_2.x10"
            final long t$104111 = this.min1;
            
            //#line 51 "x10/array/DenseIterationSpace_2.x10"
            t$104112 = ((t$104110) < (((long)(t$104111))));
        }
        
        //#line 51 "x10/array/DenseIterationSpace_2.x10"
        return t$104112;
    }
    
    
    //#line 53 "x10/array/DenseIterationSpace_2.x10"
    public long size$O() {
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104114 = this.max0;
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104115 = this.min0;
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104116 = ((t$104114) - (((long)(t$104115))));
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104120 = ((t$104116) + (((long)(1L))));
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104117 = this.max1;
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104118 = this.min1;
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104119 = ((t$104117) - (((long)(t$104118))));
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104121 = ((t$104119) + (((long)(1L))));
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104122 = ((t$104120) * (((long)(t$104121))));
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        return t$104122;
    }
    
    
    //#line 55 "x10/array/DenseIterationSpace_2.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 55 "x10/array/DenseIterationSpace_2.x10"
        final x10.array.DenseIterationSpace_2.DIS2_It alloc$99029 = ((x10.array.DenseIterationSpace_2.DIS2_It)(new x10.array.DenseIterationSpace_2.DIS2_It((java.lang.System[]) null)));
        
        //#line 55 "x10/array/DenseIterationSpace_2.x10"
        alloc$99029.x10$array$DenseIterationSpace_2$DIS2_It$$init$S(this);
        
        //#line 55 "x10/array/DenseIterationSpace_2.x10"
        return alloc$99029;
    }
    
    
    //#line 57 "x10/array/DenseIterationSpace_2.x10"
    @x10.runtime.impl.java.X10Generated
    public static class DIS2_It extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<DIS2_It> $RTT = 
            x10.rtt.NamedType.<DIS2_It> make("x10.array.DenseIterationSpace_2.DIS2_It",
                                             DIS2_It.class,
                                             new x10.rtt.Type[] {
                                                 x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                             });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_2.DIS2_It $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur0 = $deserializer.readLong();
            $_obj.cur1 = $deserializer.readLong();
            $_obj.out$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DenseIterationSpace_2.DIS2_It $_obj = new x10.array.DenseIterationSpace_2.DIS2_It((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur0);
            $serializer.write(this.cur1);
            $serializer.write(this.out$);
            
        }
        
        // constructor just for allocation
        public DIS2_It(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.lang.Point next$G() {
            return next();
        }
        
        
    
        
        //#line 18 "x10/array/DenseIterationSpace_2.x10"
        public x10.array.DenseIterationSpace_2 out$;
        
        //#line 58 "x10/array/DenseIterationSpace_2.x10"
        public long cur0;
        
        //#line 59 "x10/array/DenseIterationSpace_2.x10"
        public long cur1;
        
        
        //#line 61 "x10/array/DenseIterationSpace_2.x10"
        // creation method for java code (1-phase java constructor)
        public DIS2_It(final x10.array.DenseIterationSpace_2 out$) {
            this((java.lang.System[]) null);
            x10$array$DenseIterationSpace_2$DIS2_It$$init$S(out$);
        }
        
        // constructor for non-virtual call
        final public x10.array.DenseIterationSpace_2.DIS2_It x10$array$DenseIterationSpace_2$DIS2_It$$init$S(final x10.array.DenseIterationSpace_2 out$) {
             {
                
                //#line 18 "x10/array/DenseIterationSpace_2.x10"
                this.out$ = out$;
                
                //#line 61 "x10/array/DenseIterationSpace_2.x10"
                
                
                //#line 57 "x10/array/DenseIterationSpace_2.x10"
                final x10.array.DenseIterationSpace_2.DIS2_It this$104165 = this;
                
                //#line 57 "x10/array/DenseIterationSpace_2.x10"
                this$104165.cur0 = 0L;
                
                //#line 57 "x10/array/DenseIterationSpace_2.x10"
                this$104165.cur1 = 0L;
                
                //#line 62 "x10/array/DenseIterationSpace_2.x10"
                final x10.array.DenseIterationSpace_2 t$104123 = this.out$;
                
                //#line 62 "x10/array/DenseIterationSpace_2.x10"
                final long t$104124 = t$104123.min0;
                
                //#line 62 "x10/array/DenseIterationSpace_2.x10"
                this.cur0 = t$104124;
                
                //#line 63 "x10/array/DenseIterationSpace_2.x10"
                final x10.array.DenseIterationSpace_2 t$104125 = this.out$;
                
                //#line 63 "x10/array/DenseIterationSpace_2.x10"
                final long t$104126 = t$104125.min1;
                
                //#line 63 "x10/array/DenseIterationSpace_2.x10"
                this.cur1 = t$104126;
            }
            return this;
        }
        
        
        
        //#line 66 "x10/array/DenseIterationSpace_2.x10"
        public boolean hasNext$O() {
            
            //#line 66 "x10/array/DenseIterationSpace_2.x10"
            final long t$104128 = this.cur0;
            
            //#line 66 "x10/array/DenseIterationSpace_2.x10"
            final x10.array.DenseIterationSpace_2 t$104127 = this.out$;
            
            //#line 66 "x10/array/DenseIterationSpace_2.x10"
            final long t$104129 = t$104127.max0;
            
            //#line 66 "x10/array/DenseIterationSpace_2.x10"
            boolean t$104133 = ((t$104128) <= (((long)(t$104129))));
            
            //#line 66 "x10/array/DenseIterationSpace_2.x10"
            if (t$104133) {
                
                //#line 66 "x10/array/DenseIterationSpace_2.x10"
                final long t$104131 = this.cur1;
                
                //#line 66 "x10/array/DenseIterationSpace_2.x10"
                final x10.array.DenseIterationSpace_2 t$104130 = this.out$;
                
                //#line 66 "x10/array/DenseIterationSpace_2.x10"
                final long t$104132 = t$104130.max1;
                
                //#line 66 "x10/array/DenseIterationSpace_2.x10"
                t$104133 = ((t$104131) <= (((long)(t$104132))));
            }
            
            //#line 66 "x10/array/DenseIterationSpace_2.x10"
            return t$104133;
        }
        
        
        //#line 68 "x10/array/DenseIterationSpace_2.x10"
        public x10.lang.Point next() {
            
            //#line 69 "x10/array/DenseIterationSpace_2.x10"
            final long i$104086 = this.cur0;
            
            //#line 69 "x10/array/DenseIterationSpace_2.x10"
            final long i$104087 = this.cur1;
            
            //#line 152 . "x10/lang/Point.x10"
            final x10.lang.Point alloc$104088 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 152 . "x10/lang/Point.x10"
            alloc$104088.x10$lang$Point$$init$S(((long)(i$104086)), ((long)(i$104087)));
            
            //#line 70 "x10/array/DenseIterationSpace_2.x10"
            final long t$104135 = this.cur1;
            
            //#line 70 "x10/array/DenseIterationSpace_2.x10"
            final long t$104136 = ((t$104135) + (((long)(1L))));
            
            //#line 70 "x10/array/DenseIterationSpace_2.x10"
            this.cur1 = t$104136;
            
            //#line 71 "x10/array/DenseIterationSpace_2.x10"
            final long t$104138 = this.cur1;
            
            //#line 71 "x10/array/DenseIterationSpace_2.x10"
            final x10.array.DenseIterationSpace_2 t$104137 = this.out$;
            
            //#line 71 "x10/array/DenseIterationSpace_2.x10"
            final long t$104139 = t$104137.max1;
            
            //#line 71 "x10/array/DenseIterationSpace_2.x10"
            final boolean t$104144 = ((t$104138) > (((long)(t$104139))));
            
            //#line 71 "x10/array/DenseIterationSpace_2.x10"
            if (t$104144) {
                
                //#line 72 "x10/array/DenseIterationSpace_2.x10"
                final x10.array.DenseIterationSpace_2 t$104140 = this.out$;
                
                //#line 72 "x10/array/DenseIterationSpace_2.x10"
                final long t$104141 = t$104140.min1;
                
                //#line 72 "x10/array/DenseIterationSpace_2.x10"
                this.cur1 = t$104141;
                
                //#line 73 "x10/array/DenseIterationSpace_2.x10"
                final long t$104142 = this.cur0;
                
                //#line 73 "x10/array/DenseIterationSpace_2.x10"
                final long t$104143 = ((t$104142) + (((long)(1L))));
                
                //#line 73 "x10/array/DenseIterationSpace_2.x10"
                this.cur0 = t$104143;
            }
            
            //#line 75 "x10/array/DenseIterationSpace_2.x10"
            return alloc$104088;
        }
        
        
        //#line 57 "x10/array/DenseIterationSpace_2.x10"
        final public x10.array.DenseIterationSpace_2.DIS2_It x10$array$DenseIterationSpace_2$DIS2_It$$this$x10$array$DenseIterationSpace_2$DIS2_It() {
            
            //#line 57 "x10/array/DenseIterationSpace_2.x10"
            return x10.array.DenseIterationSpace_2.DIS2_It.this;
        }
        
        
        //#line 57 "x10/array/DenseIterationSpace_2.x10"
        final public x10.array.DenseIterationSpace_2 x10$array$DenseIterationSpace_2$DIS2_It$$this$x10$array$DenseIterationSpace_2() {
            
            //#line 57 "x10/array/DenseIterationSpace_2.x10"
            final x10.array.DenseIterationSpace_2 t$104145 = this.out$;
            
            //#line 57 "x10/array/DenseIterationSpace_2.x10"
            return t$104145;
        }
        
        
        //#line 57 "x10/array/DenseIterationSpace_2.x10"
        final public void __fieldInitializers_x10_array_DenseIterationSpace_2_DIS2_It() {
            
            //#line 57 "x10/array/DenseIterationSpace_2.x10"
            this.cur0 = 0L;
            
            //#line 57 "x10/array/DenseIterationSpace_2.x10"
            this.cur1 = 0L;
        }
    }
    
    
    
    //#line 79 "x10/array/DenseIterationSpace_2.x10"
    public java.lang.String toString() {
        
        //#line 81 "x10/array/DenseIterationSpace_2.x10"
        final long t$104146 = this.min0;
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104147 = (("[") + ((x10.core.Long.$box(t$104146))));
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104148 = ((t$104147) + (".."));
        
        //#line 81 "x10/array/DenseIterationSpace_2.x10"
        final long t$104149 = this.max0;
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104150 = ((t$104148) + ((x10.core.Long.$box(t$104149))));
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104151 = ((t$104150) + (","));
        
        //#line 82 "x10/array/DenseIterationSpace_2.x10"
        final long t$104152 = this.min1;
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104153 = ((t$104151) + ((x10.core.Long.$box(t$104152))));
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104154 = ((t$104153) + (".."));
        
        //#line 82 "x10/array/DenseIterationSpace_2.x10"
        final long t$104155 = this.max1;
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104156 = ((t$104154) + ((x10.core.Long.$box(t$104155))));
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104157 = ((t$104156) + ("]"));
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        return t$104157;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_2.x10"
    final public x10.array.DenseIterationSpace_2 x10$array$DenseIterationSpace_2$$this$x10$array$DenseIterationSpace_2() {
        
        //#line 18 "x10/array/DenseIterationSpace_2.x10"
        return x10.array.DenseIterationSpace_2.this;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_2.x10"
    final public void __fieldInitializers_x10_array_DenseIterationSpace_2() {
        
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$EMPTY = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$EMPTY;
    
    public static x10.array.DenseIterationSpace_2 get$EMPTY() {
        if (((int) x10.array.DenseIterationSpace_2.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.array.DenseIterationSpace_2.EMPTY;
        }
        if (((int) x10.array.DenseIterationSpace_2.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.array.DenseIterationSpace_2.exception$EMPTY;
        }
        if (x10.array.DenseIterationSpace_2.initStatus$EMPTY.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.array.DenseIterationSpace_2.EMPTY = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null).x10$array$DenseIterationSpace_2$$init$S(((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)))));
            }}catch (java.lang.Throwable exc$104166) {
                x10.array.DenseIterationSpace_2.exception$EMPTY = new x10.lang.ExceptionInInitializer(exc$104166);
                x10.array.DenseIterationSpace_2.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.array.DenseIterationSpace_2.exception$EMPTY;
            }
            x10.array.DenseIterationSpace_2.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.array.DenseIterationSpace_2.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.array.DenseIterationSpace_2.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.array.DenseIterationSpace_2.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.array.DenseIterationSpace_2.exception$EMPTY;
                }
            }
        }
        return x10.array.DenseIterationSpace_2.EMPTY;
    }
}

