package x10.array;

/**
 * A DenseIterationSpace_1 represents the rank 1 
 * iteration space of points [min]..[max] inclusive.
 */
@x10.runtime.impl.java.X10Generated
final public class DenseIterationSpace_1 extends x10.array.IterationSpace implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DenseIterationSpace_1> $RTT = 
        x10.rtt.NamedType.<DenseIterationSpace_1> make("x10.array.DenseIterationSpace_1",
                                                       DenseIterationSpace_1.class,
                                                       new x10.rtt.Type[] {
                                                           x10.array.IterationSpace.$RTT
                                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_1 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.IterationSpace.$_deserialize_body($_obj, $deserializer);
        $_obj.max = $deserializer.readLong();
        $_obj.min = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DenseIterationSpace_1 $_obj = new x10.array.DenseIterationSpace_1((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.max);
        $serializer.write(this.min);
        
    }
    
    // constructor just for allocation
    public DenseIterationSpace_1(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 20 "x10/array/DenseIterationSpace_1.x10"
    public long min;
    
    //#line 21 "x10/array/DenseIterationSpace_1.x10"
    public long max;
    
    //#line 23 "x10/array/DenseIterationSpace_1.x10"
    private static x10.array.DenseIterationSpace_1 EMPTY;
    
    
    //#line 25 "x10/array/DenseIterationSpace_1.x10"
    // creation method for java code (1-phase java constructor)
    public DenseIterationSpace_1(final long min, final long max) {
        this((java.lang.System[]) null);
        x10$array$DenseIterationSpace_1$$init$S(min, max);
    }
    
    // constructor for non-virtual call
    final public x10.array.DenseIterationSpace_1 x10$array$DenseIterationSpace_1$$init$S(final long min, final long max) {
         {
            
            //#line 26 "x10/array/DenseIterationSpace_1.x10"
            final x10.array.IterationSpace this$104021 = ((x10.array.IterationSpace)(this));
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104021.rank = 1L;
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104021.rect = true;
            
            //#line 25 "x10/array/DenseIterationSpace_1.x10"
            
            
            //#line 27 "x10/array/DenseIterationSpace_1.x10"
            this.min = min;
            
            //#line 28 "x10/array/DenseIterationSpace_1.x10"
            this.max = max;
        }
        return this;
    }
    
    
    
    //#line 31 "x10/array/DenseIterationSpace_1.x10"
    public static x10.array.DenseIterationSpace_1 $implicit_convert(final x10.lang.LongRange r) {
        
        //#line 31 "x10/array/DenseIterationSpace_1.x10"
        final x10.array.DenseIterationSpace_1 alloc$97518 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
        
        //#line 31 "x10/array/DenseIterationSpace_1.x10"
        final long t$104069 = r.min;
        
        //#line 31 "x10/array/DenseIterationSpace_1.x10"
        final long t$104070 = r.max;
        
        //#line 31 "x10/array/DenseIterationSpace_1.x10"
        alloc$97518.x10$array$DenseIterationSpace_1$$init$S(((long)(t$104069)), ((long)(t$104070)));
        
        //#line 31 "x10/array/DenseIterationSpace_1.x10"
        return alloc$97518;
    }
    
    
    //#line 33 "x10/array/DenseIterationSpace_1.x10"
    public x10.array.DenseIterationSpace_2 $times(final x10.lang.LongRange that) {
        
        //#line 34 "x10/array/DenseIterationSpace_1.x10"
        final x10.array.DenseIterationSpace_2 alloc$97519 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 34 "x10/array/DenseIterationSpace_1.x10"
        final long t$104071 = this.min;
        
        //#line 34 "x10/array/DenseIterationSpace_1.x10"
        final long t$104072 = that.min;
        
        //#line 34 "x10/array/DenseIterationSpace_1.x10"
        final long t$104073 = this.max;
        
        //#line 34 "x10/array/DenseIterationSpace_1.x10"
        final long t$104074 = that.max;
        
        //#line 34 "x10/array/DenseIterationSpace_1.x10"
        alloc$97519.x10$array$DenseIterationSpace_2$$init$S(((long)(t$104071)), ((long)(t$104072)), ((long)(t$104073)), ((long)(t$104074)));
        
        //#line 34 "x10/array/DenseIterationSpace_1.x10"
        return alloc$97519;
    }
    
    
    //#line 37 "x10/array/DenseIterationSpace_1.x10"
    public long min$O(final long i) {
        
        //#line 38 "x10/array/DenseIterationSpace_1.x10"
        final boolean t$104043 = ((long) i) != ((long) 0L);
        
        //#line 38 "x10/array/DenseIterationSpace_1.x10"
        if (t$104043) {
            
            //#line 38 "x10/array/DenseIterationSpace_1.x10"
            final java.lang.String t$104041 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
            
            //#line 38 "x10/array/DenseIterationSpace_1.x10"
            final x10.lang.IllegalOperationException t$104042 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104041)));
            
            //#line 38 "x10/array/DenseIterationSpace_1.x10"
            throw t$104042;
        }
        
        //#line 39 "x10/array/DenseIterationSpace_1.x10"
        final long t$104044 = this.min;
        
        //#line 39 "x10/array/DenseIterationSpace_1.x10"
        return t$104044;
    }
    
    
    //#line 42 "x10/array/DenseIterationSpace_1.x10"
    public long max$O(final long i) {
        
        //#line 43 "x10/array/DenseIterationSpace_1.x10"
        final boolean t$104047 = ((long) i) != ((long) 0L);
        
        //#line 43 "x10/array/DenseIterationSpace_1.x10"
        if (t$104047) {
            
            //#line 43 "x10/array/DenseIterationSpace_1.x10"
            final java.lang.String t$104045 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
            
            //#line 43 "x10/array/DenseIterationSpace_1.x10"
            final x10.lang.IllegalOperationException t$104046 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104045)));
            
            //#line 43 "x10/array/DenseIterationSpace_1.x10"
            throw t$104046;
        }
        
        //#line 44 "x10/array/DenseIterationSpace_1.x10"
        final long t$104048 = this.max;
        
        //#line 44 "x10/array/DenseIterationSpace_1.x10"
        return t$104048;
    }
    
    
    //#line 47 "x10/array/DenseIterationSpace_1.x10"
    public boolean isEmpty$O() {
        
        //#line 47 "x10/array/DenseIterationSpace_1.x10"
        final long t$104049 = this.max;
        
        //#line 47 "x10/array/DenseIterationSpace_1.x10"
        final long t$104050 = this.min;
        
        //#line 47 "x10/array/DenseIterationSpace_1.x10"
        final boolean t$104051 = ((t$104049) < (((long)(t$104050))));
        
        //#line 47 "x10/array/DenseIterationSpace_1.x10"
        return t$104051;
    }
    
    
    //#line 49 "x10/array/DenseIterationSpace_1.x10"
    public long size$O() {
        
        //#line 49 "x10/array/DenseIterationSpace_1.x10"
        final long t$104052 = this.max;
        
        //#line 49 "x10/array/DenseIterationSpace_1.x10"
        final long t$104053 = this.min;
        
        //#line 49 "x10/array/DenseIterationSpace_1.x10"
        final long t$104054 = ((t$104052) - (((long)(t$104053))));
        
        //#line 49 "x10/array/DenseIterationSpace_1.x10"
        final long t$104055 = ((t$104054) + (((long)(1L))));
        
        //#line 49 "x10/array/DenseIterationSpace_1.x10"
        return t$104055;
    }
    
    
    //#line 51 "x10/array/DenseIterationSpace_1.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 51 "x10/array/DenseIterationSpace_1.x10"
        final x10.array.DenseIterationSpace_1.DIS_1_It alloc$97520 = ((x10.array.DenseIterationSpace_1.DIS_1_It)(new x10.array.DenseIterationSpace_1.DIS_1_It((java.lang.System[]) null)));
        
        //#line 51 "x10/array/DenseIterationSpace_1.x10"
        final long min$104026 = this.min;
        
        //#line 51 "x10/array/DenseIterationSpace_1.x10"
        final long max$104027 = this.max;
        
        //#line 53 .. "x10/array/DenseIterationSpace_1.x10"
        alloc$97520.cur = 0L;
        
        //#line 58 . "x10/array/DenseIterationSpace_1.x10"
        alloc$97520.cur = min$104026;
        
        //#line 59 . "x10/array/DenseIterationSpace_1.x10"
        alloc$97520.last = max$104027;
        
        //#line 51 "x10/array/DenseIterationSpace_1.x10"
        return alloc$97520;
    }
    
    
    //#line 53 "x10/array/DenseIterationSpace_1.x10"
    @x10.runtime.impl.java.X10Generated
    public static class DIS_1_It extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<DIS_1_It> $RTT = 
            x10.rtt.NamedType.<DIS_1_It> make("x10.array.DenseIterationSpace_1.DIS_1_It",
                                              DIS_1_It.class,
                                              new x10.rtt.Type[] {
                                                  x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                              });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_1.DIS_1_It $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur = $deserializer.readLong();
            $_obj.last = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DenseIterationSpace_1.DIS_1_It $_obj = new x10.array.DenseIterationSpace_1.DIS_1_It((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur);
            $serializer.write(this.last);
            
        }
        
        // constructor just for allocation
        public DIS_1_It(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.lang.Point next$G() {
            return next();
        }
        
        
    
        
        //#line 54 "x10/array/DenseIterationSpace_1.x10"
        public long cur;
        
        //#line 55 "x10/array/DenseIterationSpace_1.x10"
        public long last;
        
        
        //#line 57 "x10/array/DenseIterationSpace_1.x10"
        // creation method for java code (1-phase java constructor)
        public DIS_1_It(final long min, final long max) {
            this((java.lang.System[]) null);
            x10$array$DenseIterationSpace_1$DIS_1_It$$init$S(min, max);
        }
        
        // constructor for non-virtual call
        final public x10.array.DenseIterationSpace_1.DIS_1_It x10$array$DenseIterationSpace_1$DIS_1_It$$init$S(final long min, final long max) {
             {
                
                //#line 57 "x10/array/DenseIterationSpace_1.x10"
                
                
                //#line 53 "x10/array/DenseIterationSpace_1.x10"
                final x10.array.DenseIterationSpace_1.DIS_1_It this$104075 = this;
                
                //#line 53 "x10/array/DenseIterationSpace_1.x10"
                this$104075.cur = 0L;
                
                //#line 58 "x10/array/DenseIterationSpace_1.x10"
                this.cur = min;
                
                //#line 59 "x10/array/DenseIterationSpace_1.x10"
                this.last = max;
            }
            return this;
        }
        
        
        
        //#line 62 "x10/array/DenseIterationSpace_1.x10"
        public boolean hasNext$O() {
            
            //#line 62 "x10/array/DenseIterationSpace_1.x10"
            final long t$104056 = this.cur;
            
            //#line 62 "x10/array/DenseIterationSpace_1.x10"
            final long t$104057 = this.last;
            
            //#line 62 "x10/array/DenseIterationSpace_1.x10"
            final boolean t$104058 = ((t$104056) <= (((long)(t$104057))));
            
            //#line 62 "x10/array/DenseIterationSpace_1.x10"
            return t$104058;
        }
        
        
        //#line 63 "x10/array/DenseIterationSpace_1.x10"
        public x10.lang.Point next() {
            
            //#line 63 "x10/array/DenseIterationSpace_1.x10"
            final long t$104059 = this.cur;
            
            //#line 63 "x10/array/DenseIterationSpace_1.x10"
            final long t$104060 = ((t$104059) + (((long)(1L))));
            
            //#line 63 "x10/array/DenseIterationSpace_1.x10"
            final long t$104061 = this.cur = t$104060;
            
            //#line 63 "x10/array/DenseIterationSpace_1.x10"
            final long i$104032 = ((t$104061) - (((long)(1L))));
            
            //#line 151 . "x10/lang/Point.x10"
            final x10.lang.Point alloc$104033 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 151 . "x10/lang/Point.x10"
            alloc$104033.x10$lang$Point$$init$S(((long)(i$104032)));
            
            //#line 63 "x10/array/DenseIterationSpace_1.x10"
            return alloc$104033;
        }
        
        
        //#line 53 "x10/array/DenseIterationSpace_1.x10"
        final public x10.array.DenseIterationSpace_1.DIS_1_It x10$array$DenseIterationSpace_1$DIS_1_It$$this$x10$array$DenseIterationSpace_1$DIS_1_It() {
            
            //#line 53 "x10/array/DenseIterationSpace_1.x10"
            return x10.array.DenseIterationSpace_1.DIS_1_It.this;
        }
        
        
        //#line 53 "x10/array/DenseIterationSpace_1.x10"
        final public void __fieldInitializers_x10_array_DenseIterationSpace_1_DIS_1_It() {
            
            //#line 53 "x10/array/DenseIterationSpace_1.x10"
            this.cur = 0L;
        }
    }
    
    
    
    //#line 66 "x10/array/DenseIterationSpace_1.x10"
    public java.lang.String toString() {
        
        //#line 68 "x10/array/DenseIterationSpace_1.x10"
        final long t$104062 = this.min;
        
        //#line 67 "x10/array/DenseIterationSpace_1.x10"
        final java.lang.String t$104063 = (("[") + ((x10.core.Long.$box(t$104062))));
        
        //#line 67 "x10/array/DenseIterationSpace_1.x10"
        final java.lang.String t$104064 = ((t$104063) + (".."));
        
        //#line 68 "x10/array/DenseIterationSpace_1.x10"
        final long t$104065 = this.max;
        
        //#line 67 "x10/array/DenseIterationSpace_1.x10"
        final java.lang.String t$104066 = ((t$104064) + ((x10.core.Long.$box(t$104065))));
        
        //#line 67 "x10/array/DenseIterationSpace_1.x10"
        final java.lang.String t$104067 = ((t$104066) + ("]"));
        
        //#line 67 "x10/array/DenseIterationSpace_1.x10"
        return t$104067;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_1.x10"
    final public x10.array.DenseIterationSpace_1 x10$array$DenseIterationSpace_1$$this$x10$array$DenseIterationSpace_1() {
        
        //#line 18 "x10/array/DenseIterationSpace_1.x10"
        return x10.array.DenseIterationSpace_1.this;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_1.x10"
    final public void __fieldInitializers_x10_array_DenseIterationSpace_1() {
        
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$EMPTY = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$EMPTY;
    
    public static x10.array.DenseIterationSpace_1 get$EMPTY() {
        if (((int) x10.array.DenseIterationSpace_1.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.array.DenseIterationSpace_1.EMPTY;
        }
        if (((int) x10.array.DenseIterationSpace_1.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.array.DenseIterationSpace_1.exception$EMPTY;
        }
        if (x10.array.DenseIterationSpace_1.initStatus$EMPTY.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.array.DenseIterationSpace_1.EMPTY = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null).x10$array$DenseIterationSpace_1$$init$S(((long)(0L)), ((long)(-1L)))));
            }}catch (java.lang.Throwable exc$104076) {
                x10.array.DenseIterationSpace_1.exception$EMPTY = new x10.lang.ExceptionInInitializer(exc$104076);
                x10.array.DenseIterationSpace_1.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.array.DenseIterationSpace_1.exception$EMPTY;
            }
            x10.array.DenseIterationSpace_1.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.array.DenseIterationSpace_1.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.array.DenseIterationSpace_1.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.array.DenseIterationSpace_1.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.array.DenseIterationSpace_1.exception$EMPTY;
                }
            }
        }
        return x10.array.DenseIterationSpace_1.EMPTY;
    }
}

