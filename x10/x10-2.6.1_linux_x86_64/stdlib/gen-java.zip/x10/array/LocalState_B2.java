package x10.array;

@x10.runtime.impl.java.X10Generated
public class LocalState_B2<$S> extends x10.array.LocalState<$S> implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<LocalState_B2> $RTT = 
        x10.rtt.NamedType.<LocalState_B2> make("x10.array.LocalState_B2",
                                               LocalState_B2.class,
                                               1,
                                               new x10.rtt.Type[] {
                                                   x10.rtt.ParameterizedType.make(x10.array.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                               });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $S; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$S> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.LocalState_B2<$S> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.LocalState.$_deserialize_body($_obj, $deserializer);
        $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
        $_obj.dist = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.LocalState_B2 $_obj = new x10.array.LocalState_B2((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$S);
        $serializer.write(this.dist);
        
    }
    
    // constructor just for allocation
    public LocalState_B2(final java.lang.System[] $dummy, final x10.rtt.Type $S) {
        super($dummy, $S);
        x10.array.LocalState_B2.$initParams(this, $S);
        
    }
    
    private x10.rtt.Type $S;
    
    // initializer of type parameters
    public static void $initParams(final LocalState_B2 $this, final x10.rtt.Type $S) {
        $this.$S = $S;
        
    }
    // synthetic type for parameter mangling
    public static final class __1$1x10$array$LocalState_B2$$S$2 {}
    

    
    //#line 265 "x10/array/DistArray_Block_2.x10"
    public x10.array.Dist_Block_2 dist;
    
    
    //#line 267 "x10/array/DistArray_Block_2.x10"
    // creation method for java code (1-phase java constructor)
    public LocalState_B2(final x10.rtt.Type $S, final x10.lang.PlaceGroup pg, final x10.core.Rail<$S> data, final long size, final x10.array.Dist_Block_2 d, __1$1x10$array$LocalState_B2$$S$2 $dummy) {
        this((java.lang.System[]) null, $S);
        x10$array$LocalState_B2$$init$S(pg, data, size, d, (x10.array.LocalState_B2.__1$1x10$array$LocalState_B2$$S$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.LocalState_B2<$S> x10$array$LocalState_B2$$init$S(final x10.lang.PlaceGroup pg, final x10.core.Rail<$S> data, final long size, final x10.array.Dist_Block_2 d, __1$1x10$array$LocalState_B2$$S$2 $dummy) {
         {
            
            //#line 269 "x10/array/DistArray_Block_2.x10"
            final x10.array.LocalState this$108410 = ((x10.array.LocalState)(this));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$108410).pg = ((x10.lang.PlaceGroup)(pg));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$108410).rail = ((x10.core.Rail)(data));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$108410).size = size;
            
            //#line 267 "x10/array/DistArray_Block_2.x10"
            
            
            //#line 270 "x10/array/DistArray_Block_2.x10"
            ((x10.array.LocalState_B2<$S>)this).dist = ((x10.array.Dist_Block_2)(d));
        }
        return this;
    }
    
    
    
    //#line 273 "x10/array/DistArray_Block_2.x10"
    public static <$S>x10.array.LocalState_B2 make__3$1x10$lang$Long$3x10$lang$Long$3x10$array$LocalState_B2$$S$2(final x10.rtt.Type $S, final x10.lang.PlaceGroup pg, final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$S> init) {
        
        //#line 274 "x10/array/DistArray_Block_2.x10"
        final x10.array.DenseIterationSpace_2 globalSpace = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 274 "x10/array/DistArray_Block_2.x10"
        final long t$108631 = ((m) - (((long)(1L))));
        
        //#line 274 "x10/array/DistArray_Block_2.x10"
        final long t$108632 = ((n) - (((long)(1L))));
        
        //#line 274 "x10/array/DistArray_Block_2.x10"
        globalSpace.x10$array$DenseIterationSpace_2$$init$S(((long)(0L)), ((long)(0L)), t$108631, t$108632);
        
        //#line 275 "x10/array/DistArray_Block_2.x10"
        final x10.array.Dist_Block_2 dist = ((x10.array.Dist_Block_2)(new x10.array.Dist_Block_2((java.lang.System[]) null)));
        
        //#line 275 "x10/array/DistArray_Block_2.x10"
        dist.x10$array$Dist_Block_2$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.array.DenseIterationSpace_2)(globalSpace)));
        
        //#line 277 "x10/array/DistArray_Block_2.x10"
        final x10.core.Rail data;
        
        //#line 278 "x10/array/DistArray_Block_2.x10"
        final x10.array.DenseIterationSpace_2 t$108544 = ((x10.array.DenseIterationSpace_2)(dist.localIndices));
        
        //#line 278 "x10/array/DistArray_Block_2.x10"
        final boolean t$108567 = t$108544.isEmpty$O();
        
        //#line 278 "x10/array/DistArray_Block_2.x10"
        if (t$108567) {
            
            //#line 279 "x10/array/DistArray_Block_2.x10"
            final x10.core.Rail t$108545 = ((x10.core.Rail)(new x10.core.Rail<$S>($S)));
            
            //#line 279 "x10/array/DistArray_Block_2.x10"
            data = ((x10.core.Rail)(t$108545));
        } else {
            
            //#line 281 "x10/array/DistArray_Block_2.x10"
            final x10.array.DenseIterationSpace_2 t$108546 = ((x10.array.DenseIterationSpace_2)(dist.localIndices));
            
            //#line 281 "x10/array/DistArray_Block_2.x10"
            final long low1 = t$108546.min$O((long)(0L));
            
            //#line 282 "x10/array/DistArray_Block_2.x10"
            final x10.array.DenseIterationSpace_2 t$108547 = ((x10.array.DenseIterationSpace_2)(dist.localIndices));
            
            //#line 282 "x10/array/DistArray_Block_2.x10"
            final long hi1 = t$108547.max$O((long)(0L));
            
            //#line 283 "x10/array/DistArray_Block_2.x10"
            final x10.array.DenseIterationSpace_2 t$108548 = ((x10.array.DenseIterationSpace_2)(dist.localIndices));
            
            //#line 283 "x10/array/DistArray_Block_2.x10"
            final long low2 = t$108548.min$O((long)(1L));
            
            //#line 284 "x10/array/DistArray_Block_2.x10"
            final x10.array.DenseIterationSpace_2 t$108549 = ((x10.array.DenseIterationSpace_2)(dist.localIndices));
            
            //#line 284 "x10/array/DistArray_Block_2.x10"
            final long hi2 = t$108549.max$O((long)(1L));
            
            //#line 285 "x10/array/DistArray_Block_2.x10"
            final long t$108550 = ((hi1) - (((long)(low1))));
            
            //#line 285 "x10/array/DistArray_Block_2.x10"
            final long localSize1 = ((t$108550) + (((long)(1L))));
            
            //#line 286 "x10/array/DistArray_Block_2.x10"
            final long t$108551 = ((hi2) - (((long)(low2))));
            
            //#line 286 "x10/array/DistArray_Block_2.x10"
            final long localSize2 = ((t$108551) + (((long)(1L))));
            
            //#line 287 "x10/array/DistArray_Block_2.x10"
            final long dataSize = ((localSize1) * (((long)(localSize2))));
            
            //#line 288 "x10/array/DistArray_Block_2.x10"
            final x10.core.Rail t$108552 = ((x10.core.Rail)(x10.core.Rail.<$S>makeUnsafe($S, ((long)(dataSize)), false)));
            
            //#line 288 "x10/array/DistArray_Block_2.x10"
            data = ((x10.core.Rail)(t$108552));
            
            //#line 289 "x10/array/DistArray_Block_2.x10"
            long i$108626 = low1;
            
            //#line 289 "x10/array/DistArray_Block_2.x10"
            for (;
                 true;
                 ) {
                
                //#line 289 "x10/array/DistArray_Block_2.x10"
                final boolean t$108628 = ((i$108626) <= (((long)(hi1))));
                
                //#line 289 "x10/array/DistArray_Block_2.x10"
                if (!(t$108628)) {
                    
                    //#line 289 "x10/array/DistArray_Block_2.x10"
                    break;
                }
                
                //#line 290 "x10/array/DistArray_Block_2.x10"
                long i$108618 = low2;
                
                //#line 290 "x10/array/DistArray_Block_2.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 290 "x10/array/DistArray_Block_2.x10"
                    final boolean t$108620 = ((i$108618) <= (((long)(hi2))));
                    
                    //#line 290 "x10/array/DistArray_Block_2.x10"
                    if (!(t$108620)) {
                        
                        //#line 290 "x10/array/DistArray_Block_2.x10"
                        break;
                    }
                    
                    //#line 291 "x10/array/DistArray_Block_2.x10"
                    final long t$108610 = ((i$108618) - (((long)(low2))));
                    
                    //#line 291 "x10/array/DistArray_Block_2.x10"
                    final long t$108611 = ((i$108626) - (((long)(low1))));
                    
                    //#line 291 "x10/array/DistArray_Block_2.x10"
                    final long t$108612 = ((t$108611) * (((long)(localSize2))));
                    
                    //#line 291 "x10/array/DistArray_Block_2.x10"
                    final long offset$108613 = ((t$108610) + (((long)(t$108612))));
                    
                    //#line 292 "x10/array/DistArray_Block_2.x10"
                    final $S t$108614 = (($S)((($S)
                                                ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$S>)init).$apply(x10.core.Long.$box(i$108626), x10.rtt.Types.LONG, x10.core.Long.$box(i$108618), x10.rtt.Types.LONG))));
                    
                    //#line 292 "x10/array/DistArray_Block_2.x10"
                    ((x10.core.Rail<$S>)data).$set__1x10$lang$Rail$$T$G((long)(offset$108613), (($S)(t$108614)));
                    
                    //#line 290 "x10/array/DistArray_Block_2.x10"
                    final long t$108617 = ((i$108618) + (((long)(1L))));
                    
                    //#line 290 "x10/array/DistArray_Block_2.x10"
                    i$108618 = t$108617;
                }
                
                //#line 289 "x10/array/DistArray_Block_2.x10"
                final long t$108625 = ((i$108626) + (((long)(1L))));
                
                //#line 289 "x10/array/DistArray_Block_2.x10"
                i$108626 = t$108625;
            }
        }
        
        //#line 296 "x10/array/DistArray_Block_2.x10"
        final x10.array.LocalState_B2 alloc$108256 = ((x10.array.LocalState_B2)(new x10.array.LocalState_B2<$S>((java.lang.System[]) null, $S)));
        
        //#line 296 "x10/array/DistArray_Block_2.x10"
        final long t$108633 = ((m) * (((long)(n))));
        
        //#line 296 "x10/array/DistArray_Block_2.x10"
        alloc$108256.x10$array$LocalState_B2$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.Rail)(data)), t$108633, ((x10.array.Dist_Block_2)(dist)), (x10.array.LocalState_B2.__1$1x10$array$LocalState_B2$$S$2) null);
        
        //#line 296 "x10/array/DistArray_Block_2.x10"
        return alloc$108256;
    }
    
    
    //#line 264 "x10/array/DistArray_Block_2.x10"
    final public x10.array.LocalState_B2 x10$array$LocalState_B2$$this$x10$array$LocalState_B2() {
        
        //#line 264 "x10/array/DistArray_Block_2.x10"
        return x10.array.LocalState_B2.this;
    }
    
    
    //#line 264 "x10/array/DistArray_Block_2.x10"
    final public void __fieldInitializers_x10_array_LocalState_B2() {
        
    }
}

