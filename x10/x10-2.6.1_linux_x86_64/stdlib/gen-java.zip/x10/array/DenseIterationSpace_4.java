package x10.array;

/**
 * A DenseIterationSpace_4 represents the rank 4 
 * iteration space of points [min0,min1,min2]..[max0,max1,max2] inclusive.
 */
@x10.runtime.impl.java.X10Generated
final public class DenseIterationSpace_4 extends x10.array.IterationSpace implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DenseIterationSpace_4> $RTT = 
        x10.rtt.NamedType.<DenseIterationSpace_4> make("x10.array.DenseIterationSpace_4",
                                                       DenseIterationSpace_4.class,
                                                       new x10.rtt.Type[] {
                                                           x10.array.IterationSpace.$RTT
                                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_4 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.IterationSpace.$_deserialize_body($_obj, $deserializer);
        $_obj.max0 = $deserializer.readLong();
        $_obj.max1 = $deserializer.readLong();
        $_obj.max2 = $deserializer.readLong();
        $_obj.max3 = $deserializer.readLong();
        $_obj.min0 = $deserializer.readLong();
        $_obj.min1 = $deserializer.readLong();
        $_obj.min2 = $deserializer.readLong();
        $_obj.min3 = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DenseIterationSpace_4 $_obj = new x10.array.DenseIterationSpace_4((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.max0);
        $serializer.write(this.max1);
        $serializer.write(this.max2);
        $serializer.write(this.max3);
        $serializer.write(this.min0);
        $serializer.write(this.min1);
        $serializer.write(this.min2);
        $serializer.write(this.min3);
        
    }
    
    // constructor just for allocation
    public DenseIterationSpace_4(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 20 "x10/array/DenseIterationSpace_4.x10"
    public long min0;
    
    //#line 21 "x10/array/DenseIterationSpace_4.x10"
    public long min1;
    
    //#line 22 "x10/array/DenseIterationSpace_4.x10"
    public long min2;
    
    //#line 23 "x10/array/DenseIterationSpace_4.x10"
    public long min3;
    
    //#line 24 "x10/array/DenseIterationSpace_4.x10"
    public long max0;
    
    //#line 25 "x10/array/DenseIterationSpace_4.x10"
    public long max1;
    
    //#line 26 "x10/array/DenseIterationSpace_4.x10"
    public long max2;
    
    //#line 27 "x10/array/DenseIterationSpace_4.x10"
    public long max3;
    
    //#line 29 "x10/array/DenseIterationSpace_4.x10"
    private static x10.array.DenseIterationSpace_4 EMPTY;
    
    
    //#line 31 "x10/array/DenseIterationSpace_4.x10"
    // creation method for java code (1-phase java constructor)
    public DenseIterationSpace_4(final long min0, final long min1, final long min2, final long min3, final long max0, final long max1, final long max2, final long max3) {
        this((java.lang.System[]) null);
        x10$array$DenseIterationSpace_4$$init$S(min0, min1, min2, min3, max0, max1, max2, max3);
    }
    
    // constructor for non-virtual call
    final public x10.array.DenseIterationSpace_4 x10$array$DenseIterationSpace_4$$init$S(final long min0, final long min1, final long min2, final long min3, final long max0, final long max1, final long max2, final long max3) {
         {
            
            //#line 33 "x10/array/DenseIterationSpace_4.x10"
            final x10.array.IterationSpace this$104296 = ((x10.array.IterationSpace)(this));
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104296.rank = 4L;
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104296.rect = true;
            
            //#line 31 "x10/array/DenseIterationSpace_4.x10"
            
            
            //#line 34 "x10/array/DenseIterationSpace_4.x10"
            this.min0 = min0;
            
            //#line 35 "x10/array/DenseIterationSpace_4.x10"
            this.min1 = min1;
            
            //#line 36 "x10/array/DenseIterationSpace_4.x10"
            this.min2 = min2;
            
            //#line 37 "x10/array/DenseIterationSpace_4.x10"
            this.min3 = min3;
            
            //#line 38 "x10/array/DenseIterationSpace_4.x10"
            this.max0 = max0;
            
            //#line 39 "x10/array/DenseIterationSpace_4.x10"
            this.max1 = max1;
            
            //#line 40 "x10/array/DenseIterationSpace_4.x10"
            this.max2 = max2;
            
            //#line 41 "x10/array/DenseIterationSpace_4.x10"
            this.max3 = max3;
        }
        return this;
    }
    
    
    
    //#line 44 "x10/array/DenseIterationSpace_4.x10"
    public long min$O(final long i) {
        
        //#line 45 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104310 = ((long) i) == ((long) 0L);
        
        //#line 45 "x10/array/DenseIterationSpace_4.x10"
        if (t$104310) {
            
            //#line 45 "x10/array/DenseIterationSpace_4.x10"
            final long t$104309 = this.min0;
            
            //#line 45 "x10/array/DenseIterationSpace_4.x10"
            return t$104309;
        }
        
        //#line 46 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104312 = ((long) i) == ((long) 1L);
        
        //#line 46 "x10/array/DenseIterationSpace_4.x10"
        if (t$104312) {
            
            //#line 46 "x10/array/DenseIterationSpace_4.x10"
            final long t$104311 = this.min1;
            
            //#line 46 "x10/array/DenseIterationSpace_4.x10"
            return t$104311;
        }
        
        //#line 47 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104314 = ((long) i) == ((long) 2L);
        
        //#line 47 "x10/array/DenseIterationSpace_4.x10"
        if (t$104314) {
            
            //#line 47 "x10/array/DenseIterationSpace_4.x10"
            final long t$104313 = this.min2;
            
            //#line 47 "x10/array/DenseIterationSpace_4.x10"
            return t$104313;
        }
        
        //#line 48 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104316 = ((long) i) == ((long) 3L);
        
        //#line 48 "x10/array/DenseIterationSpace_4.x10"
        if (t$104316) {
            
            //#line 48 "x10/array/DenseIterationSpace_4.x10"
            final long t$104315 = this.min3;
            
            //#line 48 "x10/array/DenseIterationSpace_4.x10"
            return t$104315;
        }
        
        //#line 49 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104317 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
        
        //#line 49 "x10/array/DenseIterationSpace_4.x10"
        final x10.lang.IllegalOperationException t$104318 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104317)));
        
        //#line 49 "x10/array/DenseIterationSpace_4.x10"
        throw t$104318;
    }
    
    
    //#line 52 "x10/array/DenseIterationSpace_4.x10"
    public long max$O(final long i) {
        
        //#line 53 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104320 = ((long) i) == ((long) 0L);
        
        //#line 53 "x10/array/DenseIterationSpace_4.x10"
        if (t$104320) {
            
            //#line 53 "x10/array/DenseIterationSpace_4.x10"
            final long t$104319 = this.max0;
            
            //#line 53 "x10/array/DenseIterationSpace_4.x10"
            return t$104319;
        }
        
        //#line 54 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104322 = ((long) i) == ((long) 1L);
        
        //#line 54 "x10/array/DenseIterationSpace_4.x10"
        if (t$104322) {
            
            //#line 54 "x10/array/DenseIterationSpace_4.x10"
            final long t$104321 = this.max1;
            
            //#line 54 "x10/array/DenseIterationSpace_4.x10"
            return t$104321;
        }
        
        //#line 55 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104324 = ((long) i) == ((long) 2L);
        
        //#line 55 "x10/array/DenseIterationSpace_4.x10"
        if (t$104324) {
            
            //#line 55 "x10/array/DenseIterationSpace_4.x10"
            final long t$104323 = this.max2;
            
            //#line 55 "x10/array/DenseIterationSpace_4.x10"
            return t$104323;
        }
        
        //#line 56 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104326 = ((long) i) == ((long) 3L);
        
        //#line 56 "x10/array/DenseIterationSpace_4.x10"
        if (t$104326) {
            
            //#line 56 "x10/array/DenseIterationSpace_4.x10"
            final long t$104325 = this.max3;
            
            //#line 56 "x10/array/DenseIterationSpace_4.x10"
            return t$104325;
        }
        
        //#line 57 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104327 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
        
        //#line 57 "x10/array/DenseIterationSpace_4.x10"
        final x10.lang.IllegalOperationException t$104328 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104327)));
        
        //#line 57 "x10/array/DenseIterationSpace_4.x10"
        throw t$104328;
    }
    
    
    //#line 60 "x10/array/DenseIterationSpace_4.x10"
    public boolean isEmpty$O() {
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        final long t$104329 = this.max0;
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        final long t$104330 = this.min0;
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        boolean t$104333 = ((t$104329) < (((long)(t$104330))));
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        if (!(t$104333)) {
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            final long t$104331 = this.max1;
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            final long t$104332 = this.min1;
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            t$104333 = ((t$104331) < (((long)(t$104332))));
        }
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        boolean t$104336 = t$104333;
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        if (!(t$104333)) {
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            final long t$104334 = this.max2;
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            final long t$104335 = this.min2;
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            t$104336 = ((t$104334) < (((long)(t$104335))));
        }
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        boolean t$104339 = t$104336;
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        if (!(t$104336)) {
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            final long t$104337 = this.max3;
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            final long t$104338 = this.min3;
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            t$104339 = ((t$104337) < (((long)(t$104338))));
        }
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        return t$104339;
    }
    
    
    //#line 62 "x10/array/DenseIterationSpace_4.x10"
    public long size$O() {
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104341 = this.max0;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104342 = this.min0;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104343 = ((t$104341) - (((long)(t$104342))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104347 = ((t$104343) + (((long)(1L))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104344 = this.max1;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104345 = this.min1;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104346 = ((t$104344) - (((long)(t$104345))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104348 = ((t$104346) + (((long)(1L))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104352 = ((t$104347) * (((long)(t$104348))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104349 = this.max2;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104350 = this.min2;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104351 = ((t$104349) - (((long)(t$104350))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104353 = ((t$104351) + (((long)(1L))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104357 = ((t$104352) * (((long)(t$104353))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104354 = this.max3;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104355 = this.min3;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104356 = ((t$104354) - (((long)(t$104355))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104358 = ((t$104356) + (((long)(1L))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104359 = ((t$104357) * (((long)(t$104358))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        return t$104359;
    }
    
    
    //#line 64 "x10/array/DenseIterationSpace_4.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 64 "x10/array/DenseIterationSpace_4.x10"
        final x10.array.DenseIterationSpace_4.DIS4_It alloc$102038 = ((x10.array.DenseIterationSpace_4.DIS4_It)(new x10.array.DenseIterationSpace_4.DIS4_It((java.lang.System[]) null)));
        
        //#line 64 "x10/array/DenseIterationSpace_4.x10"
        alloc$102038.x10$array$DenseIterationSpace_4$DIS4_It$$init$S(this);
        
        //#line 64 "x10/array/DenseIterationSpace_4.x10"
        return alloc$102038;
    }
    
    
    //#line 66 "x10/array/DenseIterationSpace_4.x10"
    @x10.runtime.impl.java.X10Generated
    public static class DIS4_It extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<DIS4_It> $RTT = 
            x10.rtt.NamedType.<DIS4_It> make("x10.array.DenseIterationSpace_4.DIS4_It",
                                             DIS4_It.class,
                                             new x10.rtt.Type[] {
                                                 x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                             });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_4.DIS4_It $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur0 = $deserializer.readLong();
            $_obj.cur1 = $deserializer.readLong();
            $_obj.cur2 = $deserializer.readLong();
            $_obj.cur3 = $deserializer.readLong();
            $_obj.out$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DenseIterationSpace_4.DIS4_It $_obj = new x10.array.DenseIterationSpace_4.DIS4_It((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur0);
            $serializer.write(this.cur1);
            $serializer.write(this.cur2);
            $serializer.write(this.cur3);
            $serializer.write(this.out$);
            
        }
        
        // constructor just for allocation
        public DIS4_It(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.lang.Point next$G() {
            return next();
        }
        
        
    
        
        //#line 18 "x10/array/DenseIterationSpace_4.x10"
        public x10.array.DenseIterationSpace_4 out$;
        
        //#line 67 "x10/array/DenseIterationSpace_4.x10"
        public long cur0;
        
        //#line 68 "x10/array/DenseIterationSpace_4.x10"
        public long cur1;
        
        //#line 69 "x10/array/DenseIterationSpace_4.x10"
        public long cur2;
        
        //#line 70 "x10/array/DenseIterationSpace_4.x10"
        public long cur3;
        
        
        //#line 72 "x10/array/DenseIterationSpace_4.x10"
        // creation method for java code (1-phase java constructor)
        public DIS4_It(final x10.array.DenseIterationSpace_4 out$) {
            this((java.lang.System[]) null);
            x10$array$DenseIterationSpace_4$DIS4_It$$init$S(out$);
        }
        
        // constructor for non-virtual call
        final public x10.array.DenseIterationSpace_4.DIS4_It x10$array$DenseIterationSpace_4$DIS4_It$$init$S(final x10.array.DenseIterationSpace_4 out$) {
             {
                
                //#line 18 "x10/array/DenseIterationSpace_4.x10"
                this.out$ = out$;
                
                //#line 72 "x10/array/DenseIterationSpace_4.x10"
                
                
                //#line 66 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4.DIS4_It this$104436 = this;
                
                //#line 66 "x10/array/DenseIterationSpace_4.x10"
                this$104436.cur0 = 0L;
                
                //#line 66 "x10/array/DenseIterationSpace_4.x10"
                this$104436.cur1 = 0L;
                
                //#line 66 "x10/array/DenseIterationSpace_4.x10"
                this$104436.cur2 = 0L;
                
                //#line 66 "x10/array/DenseIterationSpace_4.x10"
                this$104436.cur3 = 0L;
                
                //#line 73 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104360 = this.out$;
                
                //#line 73 "x10/array/DenseIterationSpace_4.x10"
                final long t$104361 = t$104360.min0;
                
                //#line 73 "x10/array/DenseIterationSpace_4.x10"
                this.cur0 = t$104361;
                
                //#line 74 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104362 = this.out$;
                
                //#line 74 "x10/array/DenseIterationSpace_4.x10"
                final long t$104363 = t$104362.min1;
                
                //#line 74 "x10/array/DenseIterationSpace_4.x10"
                this.cur1 = t$104363;
                
                //#line 75 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104364 = this.out$;
                
                //#line 75 "x10/array/DenseIterationSpace_4.x10"
                final long t$104365 = t$104364.min2;
                
                //#line 75 "x10/array/DenseIterationSpace_4.x10"
                this.cur2 = t$104365;
                
                //#line 76 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104366 = this.out$;
                
                //#line 76 "x10/array/DenseIterationSpace_4.x10"
                final long t$104367 = t$104366.min3;
                
                //#line 76 "x10/array/DenseIterationSpace_4.x10"
                this.cur3 = t$104367;
            }
            return this;
        }
        
        
        
        //#line 79 "x10/array/DenseIterationSpace_4.x10"
        public boolean hasNext$O() {
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            final long t$104369 = this.cur0;
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            final x10.array.DenseIterationSpace_4 t$104368 = this.out$;
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            final long t$104370 = t$104368.max0;
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            boolean t$104374 = ((t$104369) <= (((long)(t$104370))));
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            if (t$104374) {
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final long t$104372 = this.cur1;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104371 = this.out$;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final long t$104373 = t$104371.max1;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                t$104374 = ((t$104372) <= (((long)(t$104373))));
            }
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            boolean t$104378 = t$104374;
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            if (t$104374) {
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final long t$104376 = this.cur2;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104375 = this.out$;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final long t$104377 = t$104375.max2;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                t$104378 = ((t$104376) <= (((long)(t$104377))));
            }
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            boolean t$104382 = t$104378;
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            if (t$104378) {
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final long t$104380 = this.cur3;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104379 = this.out$;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final long t$104381 = t$104379.max3;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                t$104382 = ((t$104380) <= (((long)(t$104381))));
            }
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            return t$104382;
        }
        
        
        //#line 81 "x10/array/DenseIterationSpace_4.x10"
        public x10.lang.Point next() {
            
            //#line 82 "x10/array/DenseIterationSpace_4.x10"
            final long i$104303 = this.cur0;
            
            //#line 82 "x10/array/DenseIterationSpace_4.x10"
            final long i$104304 = this.cur1;
            
            //#line 82 "x10/array/DenseIterationSpace_4.x10"
            final long i$104305 = this.cur2;
            
            //#line 82 "x10/array/DenseIterationSpace_4.x10"
            final long i$104306 = this.cur3;
            
            //#line 154 . "x10/lang/Point.x10"
            final x10.lang.Point alloc$104307 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 154 . "x10/lang/Point.x10"
            alloc$104307.x10$lang$Point$$init$S(((long)(i$104303)), ((long)(i$104304)), ((long)(i$104305)), ((long)(i$104306)));
            
            //#line 83 "x10/array/DenseIterationSpace_4.x10"
            final long t$104384 = this.cur3;
            
            //#line 83 "x10/array/DenseIterationSpace_4.x10"
            final long t$104385 = ((t$104384) + (((long)(1L))));
            
            //#line 83 "x10/array/DenseIterationSpace_4.x10"
            this.cur3 = t$104385;
            
            //#line 84 "x10/array/DenseIterationSpace_4.x10"
            final long t$104387 = this.cur3;
            
            //#line 84 "x10/array/DenseIterationSpace_4.x10"
            final x10.array.DenseIterationSpace_4 t$104386 = this.out$;
            
            //#line 84 "x10/array/DenseIterationSpace_4.x10"
            final long t$104388 = t$104386.max3;
            
            //#line 84 "x10/array/DenseIterationSpace_4.x10"
            final boolean t$104409 = ((t$104387) > (((long)(t$104388))));
            
            //#line 84 "x10/array/DenseIterationSpace_4.x10"
            if (t$104409) {
                
                //#line 85 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104389 = this.out$;
                
                //#line 85 "x10/array/DenseIterationSpace_4.x10"
                final long t$104390 = t$104389.min3;
                
                //#line 85 "x10/array/DenseIterationSpace_4.x10"
                this.cur3 = t$104390;
                
                //#line 86 "x10/array/DenseIterationSpace_4.x10"
                final long t$104391 = this.cur2;
                
                //#line 86 "x10/array/DenseIterationSpace_4.x10"
                final long t$104392 = ((t$104391) + (((long)(1L))));
                
                //#line 86 "x10/array/DenseIterationSpace_4.x10"
                this.cur2 = t$104392;
                
                //#line 87 "x10/array/DenseIterationSpace_4.x10"
                final long t$104394 = this.cur2;
                
                //#line 87 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104393 = this.out$;
                
                //#line 87 "x10/array/DenseIterationSpace_4.x10"
                final long t$104395 = t$104393.max2;
                
                //#line 87 "x10/array/DenseIterationSpace_4.x10"
                final boolean t$104408 = ((t$104394) > (((long)(t$104395))));
                
                //#line 87 "x10/array/DenseIterationSpace_4.x10"
                if (t$104408) {
                    
                    //#line 88 "x10/array/DenseIterationSpace_4.x10"
                    final x10.array.DenseIterationSpace_4 t$104396 = this.out$;
                    
                    //#line 88 "x10/array/DenseIterationSpace_4.x10"
                    final long t$104397 = t$104396.min2;
                    
                    //#line 88 "x10/array/DenseIterationSpace_4.x10"
                    this.cur2 = t$104397;
                    
                    //#line 89 "x10/array/DenseIterationSpace_4.x10"
                    final long t$104398 = this.cur1;
                    
                    //#line 89 "x10/array/DenseIterationSpace_4.x10"
                    final long t$104399 = ((t$104398) + (((long)(1L))));
                    
                    //#line 89 "x10/array/DenseIterationSpace_4.x10"
                    this.cur1 = t$104399;
                    
                    //#line 90 "x10/array/DenseIterationSpace_4.x10"
                    final long t$104401 = this.cur1;
                    
                    //#line 90 "x10/array/DenseIterationSpace_4.x10"
                    final x10.array.DenseIterationSpace_4 t$104400 = this.out$;
                    
                    //#line 90 "x10/array/DenseIterationSpace_4.x10"
                    final long t$104402 = t$104400.max1;
                    
                    //#line 90 "x10/array/DenseIterationSpace_4.x10"
                    final boolean t$104407 = ((t$104401) > (((long)(t$104402))));
                    
                    //#line 90 "x10/array/DenseIterationSpace_4.x10"
                    if (t$104407) {
                        
                        //#line 91 "x10/array/DenseIterationSpace_4.x10"
                        final x10.array.DenseIterationSpace_4 t$104403 = this.out$;
                        
                        //#line 91 "x10/array/DenseIterationSpace_4.x10"
                        final long t$104404 = t$104403.min1;
                        
                        //#line 91 "x10/array/DenseIterationSpace_4.x10"
                        this.cur1 = t$104404;
                        
                        //#line 92 "x10/array/DenseIterationSpace_4.x10"
                        final long t$104405 = this.cur0;
                        
                        //#line 92 "x10/array/DenseIterationSpace_4.x10"
                        final long t$104406 = ((t$104405) + (((long)(1L))));
                        
                        //#line 92 "x10/array/DenseIterationSpace_4.x10"
                        this.cur0 = t$104406;
                    }
                }
            }
            
            //#line 96 "x10/array/DenseIterationSpace_4.x10"
            return alloc$104307;
        }
        
        
        //#line 66 "x10/array/DenseIterationSpace_4.x10"
        final public x10.array.DenseIterationSpace_4.DIS4_It x10$array$DenseIterationSpace_4$DIS4_It$$this$x10$array$DenseIterationSpace_4$DIS4_It() {
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            return x10.array.DenseIterationSpace_4.DIS4_It.this;
        }
        
        
        //#line 66 "x10/array/DenseIterationSpace_4.x10"
        final public x10.array.DenseIterationSpace_4 x10$array$DenseIterationSpace_4$DIS4_It$$this$x10$array$DenseIterationSpace_4() {
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            final x10.array.DenseIterationSpace_4 t$104410 = this.out$;
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            return t$104410;
        }
        
        
        //#line 66 "x10/array/DenseIterationSpace_4.x10"
        final public void __fieldInitializers_x10_array_DenseIterationSpace_4_DIS4_It() {
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            this.cur0 = 0L;
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            this.cur1 = 0L;
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            this.cur2 = 0L;
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            this.cur3 = 0L;
        }
    }
    
    
    
    //#line 100 "x10/array/DenseIterationSpace_4.x10"
    public java.lang.String toString() {
        
        //#line 102 "x10/array/DenseIterationSpace_4.x10"
        final long t$104411 = this.min0;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104412 = (("[") + ((x10.core.Long.$box(t$104411))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104413 = ((t$104412) + (".."));
        
        //#line 102 "x10/array/DenseIterationSpace_4.x10"
        final long t$104414 = this.max0;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104415 = ((t$104413) + ((x10.core.Long.$box(t$104414))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104416 = ((t$104415) + (","));
        
        //#line 103 "x10/array/DenseIterationSpace_4.x10"
        final long t$104417 = this.min1;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104418 = ((t$104416) + ((x10.core.Long.$box(t$104417))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104419 = ((t$104418) + (".."));
        
        //#line 103 "x10/array/DenseIterationSpace_4.x10"
        final long t$104420 = this.max1;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104421 = ((t$104419) + ((x10.core.Long.$box(t$104420))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104422 = ((t$104421) + (","));
        
        //#line 104 "x10/array/DenseIterationSpace_4.x10"
        final long t$104423 = this.min2;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104424 = ((t$104422) + ((x10.core.Long.$box(t$104423))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104425 = ((t$104424) + (".."));
        
        //#line 104 "x10/array/DenseIterationSpace_4.x10"
        final long t$104426 = this.max2;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104427 = ((t$104425) + ((x10.core.Long.$box(t$104426))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104428 = ((t$104427) + (","));
        
        //#line 105 "x10/array/DenseIterationSpace_4.x10"
        final long t$104429 = this.min3;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104430 = ((t$104428) + ((x10.core.Long.$box(t$104429))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104431 = ((t$104430) + (".."));
        
        //#line 105 "x10/array/DenseIterationSpace_4.x10"
        final long t$104432 = this.max3;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104433 = ((t$104431) + ((x10.core.Long.$box(t$104432))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104434 = ((t$104433) + ("]"));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        return t$104434;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_4.x10"
    final public x10.array.DenseIterationSpace_4 x10$array$DenseIterationSpace_4$$this$x10$array$DenseIterationSpace_4() {
        
        //#line 18 "x10/array/DenseIterationSpace_4.x10"
        return x10.array.DenseIterationSpace_4.this;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_4.x10"
    final public void __fieldInitializers_x10_array_DenseIterationSpace_4() {
        
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$EMPTY = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$EMPTY;
    
    public static x10.array.DenseIterationSpace_4 get$EMPTY() {
        if (((int) x10.array.DenseIterationSpace_4.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.array.DenseIterationSpace_4.EMPTY;
        }
        if (((int) x10.array.DenseIterationSpace_4.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.array.DenseIterationSpace_4.exception$EMPTY;
        }
        if (x10.array.DenseIterationSpace_4.initStatus$EMPTY.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.array.DenseIterationSpace_4.EMPTY = ((x10.array.DenseIterationSpace_4)(new x10.array.DenseIterationSpace_4((java.lang.System[]) null).x10$array$DenseIterationSpace_4$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)), ((long)(-1L)), ((long)(-1L)))));
            }}catch (java.lang.Throwable exc$104437) {
                x10.array.DenseIterationSpace_4.exception$EMPTY = new x10.lang.ExceptionInInitializer(exc$104437);
                x10.array.DenseIterationSpace_4.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.array.DenseIterationSpace_4.exception$EMPTY;
            }
            x10.array.DenseIterationSpace_4.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.array.DenseIterationSpace_4.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.array.DenseIterationSpace_4.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.array.DenseIterationSpace_4.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.array.DenseIterationSpace_4.exception$EMPTY;
                }
            }
        }
        return x10.array.DenseIterationSpace_4.EMPTY;
    }
}

