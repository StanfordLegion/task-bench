package x10.array;


/**
 * Implementation of a 3-D DistArray that distributes its data elements
 * over the places in its PlaceGroup in a 2-D blocked fashion.
 */
@x10.runtime.impl.java.X10Generated
public class DistArray_BlockBlock_3<$T> extends x10.array.DistArray<$T> implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray_BlockBlock_3> $RTT = 
        x10.rtt.NamedType.<DistArray_BlockBlock_3> make("x10.array.DistArray_BlockBlock_3",
                                                        DistArray_BlockBlock_3.class,
                                                        1,
                                                        new x10.rtt.Type[] {
                                                            x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                                            x10.rtt.ParameterizedType.make(x10.array.DistArray.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                        });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_3<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.globalIndices = $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        $_obj.numElems_3 = $deserializer.readLong();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localIndices = $_obj.reloadLocalIndices();
        $_obj.minIndex_1 = $_obj.reloadMinIndex_1$O();
        $_obj.minIndex_2 = $_obj.reloadMinIndex_2$O();
        $_obj.numElemsLocal_1 = $_obj.reloadNumElemsLocal_1$O();
        $_obj.numElemsLocal_2 = $_obj.reloadNumElemsLocal_2$O();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray_BlockBlock_3 $_obj = new x10.array.DistArray_BlockBlock_3((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.globalIndices);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        $serializer.write(this.numElems_3);
        
    }
    
    // constructor just for allocation
    public DistArray_BlockBlock_3(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.DistArray_BlockBlock_3.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
        
    }
    
    // bridge for method abstract public x10.array.DistArray[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.DistArray).rank()}, v:T){}:T{self==v}
    final public $T $set__1x10$array$DistArray$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$DistArray_BlockBlock_3$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray_BlockBlock_3 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2 {}
    

    
    
    //#line 25 "x10/array/DistArray_BlockBlock_3.x10"
    final public long rank$O() {
        
        //#line 25 "x10/array/DistArray_BlockBlock_3.x10"
        return 3L;
    }
    
    
    //#line 27 "x10/array/DistArray_BlockBlock_3.x10"
    public x10.array.DenseIterationSpace_3 globalIndices;
    
    //#line 29 "x10/array/DistArray_BlockBlock_3.x10"
    public long numElems_1;
    
    //#line 31 "x10/array/DistArray_BlockBlock_3.x10"
    public long numElems_2;
    
    //#line 33 "x10/array/DistArray_BlockBlock_3.x10"
    public long numElems_3;
    
    //#line 36 "x10/array/DistArray_BlockBlock_3.x10"
    public transient x10.array.DenseIterationSpace_3 localIndices;
    
    
    //#line 37 "x10/array/DistArray_BlockBlock_3.x10"
    final public x10.array.DenseIterationSpace_3 reloadLocalIndices() {
        
        //#line 39 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.lang.PlaceLocalHandle t$107110 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 39 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.LocalState t$107111 = ((x10.lang.PlaceLocalHandle<x10.array.LocalState<$T>>)t$107110).$apply$G();
        
        //#line 39 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.LocalState_BB3 ls = x10.rtt.Types.<x10.array.LocalState_BB3<$T>> cast(t$107111,x10.rtt.ParameterizedType.make(x10.array.LocalState_BB3.$RTT, $T));
        
        //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
        final boolean t$107113 = ((ls) != (null));
        
        //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
        x10.array.DenseIterationSpace_3 t$107114 =  null;
        
        //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107113) {
            
            //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.Dist_BlockBlock_3 t$107112 = ((x10.array.Dist_BlockBlock_3)(((x10.array.LocalState_BB3<$T>)ls).dist));
            
            //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
            t$107114 = ((x10.array.DenseIterationSpace_3)(t$107112.localIndices));
        } else {
            
            //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 alloc$106889 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
            
            //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
            alloc$106889.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)), ((long)(-1L)));
            
            //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
            t$107114 = ((x10.array.DenseIterationSpace_3)(alloc$106889));
        }
        
        //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107114;
    }
    
    
    //#line 44 "x10/array/DistArray_BlockBlock_3.x10"
    public transient long minIndex_1;
    
    
    //#line 45 "x10/array/DistArray_BlockBlock_3.x10"
    final public long reloadMinIndex_1$O() {
        
        //#line 45 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107116 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 45 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107117 = t$107116.min$O((long)(0L));
        
        //#line 45 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107117;
    }
    
    
    //#line 48 "x10/array/DistArray_BlockBlock_3.x10"
    public transient long minIndex_2;
    
    
    //#line 49 "x10/array/DistArray_BlockBlock_3.x10"
    final public long reloadMinIndex_2$O() {
        
        //#line 49 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107118 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 49 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107119 = t$107118.min$O((long)(1L));
        
        //#line 49 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107119;
    }
    
    
    //#line 52 "x10/array/DistArray_BlockBlock_3.x10"
    public transient long numElemsLocal_1;
    
    
    //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
    final public long reloadNumElemsLocal_1$O() {
        
        //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107120 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107121 = t$107120.max$O((long)(0L));
        
        //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107122 = this.minIndex_1;
        
        //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107123 = ((t$107121) - (((long)(t$107122))));
        
        //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107124 = ((t$107123) + (((long)(1L))));
        
        //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107124;
    }
    
    
    //#line 56 "x10/array/DistArray_BlockBlock_3.x10"
    public transient long numElemsLocal_2;
    
    
    //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
    final public long reloadNumElemsLocal_2$O() {
        
        //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107125 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107126 = t$107125.max$O((long)(1L));
        
        //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107127 = this.minIndex_2;
        
        //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107128 = ((t$107126) - (((long)(t$107127))));
        
        //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107129 = ((t$107128) + (((long)(1L))));
        
        //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107129;
    }
    
    
    //#line 70 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Construct a m by n by p block-block distributed DistArray
     * whose data is distributed over pg and initialized using
     * the init function.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_3$$init$S(m, n, p, pg, init, (x10.array.DistArray_BlockBlock_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_3<$T> x10$array$DistArray_BlockBlock_3$$init$S(final long m, final long n, final long p, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2 $dummy) {
         {
            
            //#line 71 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.core.fun.Fun_0_0 t$107342 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_BlockBlock_3.$Closure$8<$T>($T, pg, m, n, p, init, (x10.array.DistArray_BlockBlock_3.$Closure$8.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$Closure$8$$T$2) null)));
            
            //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
            boolean t$107347 = ((m) < (((long)(0L))));
            
            //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
            if (!(t$107347)) {
                
                //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
                t$107347 = ((n) < (((long)(0L))));
            }
            
            //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
            boolean t$107348 = t$107347;
            
            //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
            if (!(t$107347)) {
                
                //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
                t$107348 = ((p) < (((long)(0L))));
            }
            
            //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
            if (t$107348) {
                
                //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
                x10.array.DistArray.raiseNegativeArraySizeException();
            }
            
            //#line 279 . "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107350 = ((m) * (((long)(n))));
            
            //#line 279 . "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107351 = ((t$107350) * (((long)(p))));
            
            //#line 71 "x10/array/DistArray_BlockBlock_3.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$107342)), t$107351, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 70 "x10/array/DistArray_BlockBlock_3.x10"
            
            
            //#line 72 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 alloc$106890 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
            
            //#line 72 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107353 = ((m) - (((long)(1L))));
            
            //#line 72 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107354 = ((n) - (((long)(1L))));
            
            //#line 72 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107355 = ((p) - (((long)(1L))));
            
            //#line 72 "x10/array/DistArray_BlockBlock_3.x10"
            alloc$106890.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), t$107353, t$107354, t$107355);
            
            //#line 72 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).globalIndices = ((x10.array.DenseIterationSpace_3)(alloc$106890));
            
            //#line 73 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).numElems_1 = m;
            
            //#line 74 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).numElems_2 = n;
            
            //#line 75 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).numElems_3 = p;
            
            //#line 76 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107140 = ((x10.array.DenseIterationSpace_3)(this.reloadLocalIndices()));
            
            //#line 76 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).localIndices = ((x10.array.DenseIterationSpace_3)(t$107140));
            
            //#line 77 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DistArray_BlockBlock_3 this$107047 = ((x10.array.DistArray_BlockBlock_3)(this));
            
            //#line 45 . "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107141 = ((x10.array.DenseIterationSpace_3)(((x10.array.DistArray_BlockBlock_3<$T>)this$107047).localIndices));
            
            //#line 45 . "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107142 = t$107141.min$O((long)(0L));
            
            //#line 77 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).minIndex_1 = t$107142;
            
            //#line 78 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DistArray_BlockBlock_3 this$107049 = ((x10.array.DistArray_BlockBlock_3)(this));
            
            //#line 49 . "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107143 = ((x10.array.DenseIterationSpace_3)(((x10.array.DistArray_BlockBlock_3<$T>)this$107049).localIndices));
            
            //#line 49 . "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107144 = t$107143.min$O((long)(1L));
            
            //#line 78 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).minIndex_2 = t$107144;
            
            //#line 79 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107145 = this.reloadNumElemsLocal_1$O();
            
            //#line 79 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).numElemsLocal_1 = t$107145;
            
            //#line 80 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107146 = this.reloadNumElemsLocal_2$O();
            
            //#line 80 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).numElemsLocal_2 = t$107146;
        }
        return this;
    }
    
    
    
    //#line 94 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Construct a m by n by p block-block distributed DistArray
     * whose data is distributed over Place.places() and 
     * initialized using the provided init closure.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_3$$init$S(m, n, p, init, (x10.array.DistArray_BlockBlock_3.__3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_3<$T> x10$array$DistArray_BlockBlock_3$$init$S(final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2 $dummy) {
         {
            
            //#line 95 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.lang.PlaceGroup t$107147 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 95 "x10/array/DistArray_BlockBlock_3.x10"
            /*this.*/x10$array$DistArray_BlockBlock_3$$init$S(((long)(m)), ((long)(n)), ((long)(p)), t$107147, ((x10.core.fun.Fun_0_3)(init)), (x10.array.DistArray_BlockBlock_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 108 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Construct a m by n by p block-block distributed DistArray
     * whose data is distributed over pg and zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_3$$init$S(m, n, p, pg);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_3<$T> x10$array$DistArray_BlockBlock_3$$init$S(final long m, final long n, final long p, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 109 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.core.fun.Fun_0_3 t$107149 = ((x10.core.fun.Fun_0_3)(new x10.array.DistArray_BlockBlock_3.$Closure$9<$T>($T)));
            
            //#line 109 "x10/array/DistArray_BlockBlock_3.x10"
            /*this.*/x10$array$DistArray_BlockBlock_3$$init$S(((long)(m)), ((long)(n)), ((long)(p)), ((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_3)(t$107149)), (x10.array.DistArray_BlockBlock_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 122 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Construct a m by n by p block-block distributed DistArray
     * whose data is distributed over Place.places() and 
     * zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_3(final x10.rtt.Type $T, final long m, final long n, final long p) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_3$$init$S(m, n, p);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_3<$T> x10$array$DistArray_BlockBlock_3$$init$S(final long m, final long n, final long p) {
         {
            
            //#line 123 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.lang.PlaceGroup t$107151 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 123 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.core.fun.Fun_0_3 t$107152 = ((x10.core.fun.Fun_0_3)(new x10.array.DistArray_BlockBlock_3.$Closure$10<$T>($T)));
            
            //#line 123 "x10/array/DistArray_BlockBlock_3.x10"
            /*this.*/x10$array$DistArray_BlockBlock_3$$init$S(((long)(m)), ((long)(n)), ((long)(p)), t$107151, ((x10.core.fun.Fun_0_3)(t$107152)), (x10.array.DistArray_BlockBlock_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 132 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the global iteration space (valid indices) of the DistArray.
     * @return an IterationSpace for the DistArray
     */
    final public x10.array.DenseIterationSpace_3 globalIndices() {
        
        //#line 132 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107153 = ((x10.array.DenseIterationSpace_3)(this.globalIndices));
        
        //#line 132 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107153;
    }
    
    
    //#line 140 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the local iteration space (valid indices) of the DistArray at the current Place.
     * @return an IterationSpace for the local portion of the DistArray
     */
    final public x10.array.DenseIterationSpace_3 localIndices() {
        
        //#line 140 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107154 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 140 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107154;
    }
    
    
    //#line 154 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Return the Place which contains the data for the argument
     * index or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param i the index in the first dimension
     * @param j the index in the second dimension
     * @param k the index in the third dimension
     * @return the Place where (i,j,k) is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if (i,j,k) is not contained in globalIndices
     */
    final public x10.lang.Place place(final long i, final long j, final long k) {
        
        //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107156 = ((k) < (((long)(0L))));
        
        //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107156)) {
            
            //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107155 = this.numElems_3;
            
            //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
            t$107156 = ((k) >= (((long)(t$107155))));
        }
        
        //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107156) {
            
            //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.lang.Place t$107157 = ((x10.lang.Place)(x10.lang.Place.get$INVALID_PLACE()));
            
            //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
            return t$107157;
        }
        
        //#line 156 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107159 = this.numElems_1;
        
        //#line 156 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107161 = ((t$107159) - (((long)(1L))));
        
        //#line 156 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107160 = this.numElems_2;
        
        //#line 156 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107162 = ((t$107160) - (((long)(1L))));
        
        //#line 156 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.lang.PlaceGroup this$107051 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$107163 = this$107051.numPlaces$O();
        
        //#line 156 "x10/array/DistArray_BlockBlock_3.x10"
        final long tmp = x10.array.BlockingUtils.mapIndexToBlockBlockPartition$O((long)(0L), (long)(0L), (long)(t$107161), (long)(t$107162), (long)(t$107163), (long)(i), (long)(j));
        
        //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
        final boolean t$107165 = ((long) tmp) == ((long) -1L);
        
        //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
        x10.lang.Place t$107166 =  null;
        
        //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107165) {
            
            //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
            t$107166 = x10.lang.Place.get$INVALID_PLACE();
        } else {
            
            //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.lang.PlaceGroup t$107164 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
            t$107166 = t$107164.$apply((long)(tmp));
        }
        
        //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107166;
    }
    
    
    //#line 170 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Return the Place which contains the data for the argument
     * Point or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param p the Point to lookup
     * @return the Place where p is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if p is not contained in globalIndices
     */
    final public x10.lang.Place place(final x10.lang.Point p) {
        
        //#line 170 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107168 = p.$apply$O((long)(0L));
        
        //#line 170 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107169 = p.$apply$O((long)(1L));
        
        //#line 170 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107170 = p.$apply$O((long)(2L));
        
        //#line 170 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.lang.Place t$107171 = this.place((long)(t$107168), (long)(t$107169), (long)(t$107170));
        
        //#line 170 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107171;
    }
    
    
    //#line 182 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @return the element of this array corresponding to the given index.
     * @see #set(T, Long, Long, Long)
     */
    final public $T $apply$G(final long i, final long j, final long k) {
        
        //#line 183 "x10/array/DistArray_BlockBlock_3.x10"
        this.validateIndex((long)(i), (long)(j), (long)(k));
        
        //#line 184 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.core.Rail r$107058 = ((x10.core.Rail)(this.raw));
        
        //#line 184 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DistArray_BlockBlock_3 this$107056 = ((x10.array.DistArray_BlockBlock_3)(this));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107178 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107056).numElems_3;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107172 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107056).minIndex_2;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107176 = ((j) - (((long)(t$107172))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107174 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107056).numElemsLocal_2;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107173 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107056).minIndex_1;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107175 = ((i) - (((long)(t$107173))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107177 = ((t$107174) * (((long)(t$107175))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107179 = ((t$107176) + (((long)(t$107177))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107180 = ((t$107178) * (((long)(t$107179))));
        
        //#line 184 "x10/array/DistArray_BlockBlock_3.x10"
        final long i$107059 = ((k) + (((long)(t$107180))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$107181 = (($T)(((x10.core.Rail<$T>)r$107058).$apply$G((long)(i$107059))));
        
        //#line 184 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107181;
    }
    
    
    //#line 195 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    final public $T $apply$G(final x10.lang.Point p) {
        
        //#line 195 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DistArray_BlockBlock_3 this$107064 = ((x10.array.DistArray_BlockBlock_3)(this));
        
        //#line 195 "x10/array/DistArray_BlockBlock_3.x10"
        final long i$107061 = p.$apply$O((long)(0L));
        
        //#line 195 "x10/array/DistArray_BlockBlock_3.x10"
        final long j$107062 = p.$apply$O((long)(1L));
        
        //#line 195 "x10/array/DistArray_BlockBlock_3.x10"
        final long k$107063 = p.$apply$O((long)(2L));
        
        //#line 183 . "x10/array/DistArray_BlockBlock_3.x10"
        ((x10.array.DistArray_BlockBlock_3<$T>)this$107064).validateIndex((long)(i$107061), (long)(j$107062), (long)(k$107063));
        
        //#line 184 . "x10/array/DistArray_BlockBlock_3.x10"
        final x10.core.Rail r$107070 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$107064).raw));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107188 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107064).numElems_3;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107182 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107064).minIndex_2;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107186 = ((j$107062) - (((long)(t$107182))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107184 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107064).numElemsLocal_2;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107183 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107064).minIndex_1;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107185 = ((i$107061) - (((long)(t$107183))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107187 = ((t$107184) * (((long)(t$107185))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107189 = ((t$107186) + (((long)(t$107187))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107190 = ((t$107188) * (((long)(t$107189))));
        
        //#line 184 . "x10/array/DistArray_BlockBlock_3.x10"
        final long i$107071 = ((k$107063) + (((long)(t$107190))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$107191 = (($T)(((x10.core.Rail<$T>)r$107070).$apply$G((long)(i$107071))));
        
        //#line 195 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107191;
    }
    
    
    //#line 209 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long, Long, Long)
     */
    final public $T $set__3x10$array$DistArray_BlockBlock_3$$T$G(final long i, final long j, final long k, final $T v) {
        
        //#line 210 "x10/array/DistArray_BlockBlock_3.x10"
        this.validateIndex((long)(i), (long)(j), (long)(k));
        
        //#line 211 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.core.Rail r$107078 = ((x10.core.Rail)(this.raw));
        
        //#line 211 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DistArray_BlockBlock_3 this$107076 = ((x10.array.DistArray_BlockBlock_3)(this));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107198 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107076).numElems_3;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107192 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107076).minIndex_2;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107196 = ((j) - (((long)(t$107192))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107194 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107076).numElemsLocal_2;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107193 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107076).minIndex_1;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107195 = ((i) - (((long)(t$107193))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107197 = ((t$107194) * (((long)(t$107195))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107199 = ((t$107196) + (((long)(t$107197))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107200 = ((t$107198) * (((long)(t$107199))));
        
        //#line 211 "x10/array/DistArray_BlockBlock_3.x10"
        final long i$107079 = ((k) + (((long)(t$107200))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$107078).$set__1x10$lang$Rail$$T$G((long)(i$107079), (($T)(v)));
        
        //#line 211 "x10/array/DistArray_BlockBlock_3.x10"
        return (($T)
                 v);
    }
    
    
    //#line 224 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    final public $T $set__1x10$array$DistArray_BlockBlock_3$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 224 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DistArray_BlockBlock_3 this$107086 = ((x10.array.DistArray_BlockBlock_3)(this));
        
        //#line 224 "x10/array/DistArray_BlockBlock_3.x10"
        final long i$107082 = p.$apply$O((long)(0L));
        
        //#line 224 "x10/array/DistArray_BlockBlock_3.x10"
        final long j$107083 = p.$apply$O((long)(1L));
        
        //#line 224 "x10/array/DistArray_BlockBlock_3.x10"
        final long k$107084 = p.$apply$O((long)(2L));
        
        //#line 210 . "x10/array/DistArray_BlockBlock_3.x10"
        ((x10.array.DistArray_BlockBlock_3<$T>)this$107086).validateIndex((long)(i$107082), (long)(j$107083), (long)(k$107084));
        
        //#line 211 . "x10/array/DistArray_BlockBlock_3.x10"
        final x10.core.Rail r$107092 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$107086).raw));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107207 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107086).numElems_3;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107201 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107086).minIndex_2;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107205 = ((j$107083) - (((long)(t$107201))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107203 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107086).numElemsLocal_2;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107202 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107086).minIndex_1;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107204 = ((i$107082) - (((long)(t$107202))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107206 = ((t$107203) * (((long)(t$107204))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107208 = ((t$107205) + (((long)(t$107206))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107209 = ((t$107207) * (((long)(t$107208))));
        
        //#line 211 . "x10/array/DistArray_BlockBlock_3.x10"
        final long i$107093 = ((k$107084) + (((long)(t$107209))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$107092).$set__1x10$lang$Rail$$T$G((long)(i$107093), (($T)(v)));
        
        //#line 224 "x10/array/DistArray_BlockBlock_3.x10"
        return (($T)
                 v);
    }
    
    
    //#line 232 "x10/array/DistArray_BlockBlock_3.x10"
    final public void validateIndex(final long i, final long j, final long k) {
        
        //#line 234 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107211 = ((k) < (((long)(0L))));
        
        //#line 234 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107211)) {
            
            //#line 234 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107210 = this.numElems_3;
            
            //#line 234 "x10/array/DistArray_BlockBlock_3.x10"
            t$107211 = ((k) >= (((long)(t$107210))));
        }
        
        //#line 234 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107211) {
            
            //#line 235 "x10/array/DistArray_BlockBlock_3.x10"
            x10.array.DistArray.raiseBoundsError((long)(i), (long)(j), (long)(k));
        }
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107213 = this.minIndex_1;
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107217 = ((i) < (((long)(t$107213))));
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107217)) {
            
            //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107214 = this.minIndex_1;
            
            //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107215 = this.numElemsLocal_1;
            
            //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107216 = ((t$107214) + (((long)(t$107215))));
            
            //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
            t$107217 = ((i) >= (((long)(t$107216))));
        }
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107219 = t$107217;
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107217)) {
            
            //#line 238 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107218 = this.minIndex_2;
            
            //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
            t$107219 = ((j) < (((long)(t$107218))));
        }
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107223 = t$107219;
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107219)) {
            
            //#line 238 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107220 = this.minIndex_2;
            
            //#line 238 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107221 = this.numElemsLocal_2;
            
            //#line 238 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107222 = ((t$107220) + (((long)(t$107221))));
            
            //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
            t$107223 = ((j) >= (((long)(t$107222))));
        }
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107223) {
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            boolean t$107225 = ((i) < (((long)(0L))));
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            if (!(t$107225)) {
                
                //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
                final long t$107224 = this.numElems_1;
                
                //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
                t$107225 = ((i) >= (((long)(t$107224))));
            }
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            boolean t$107226 = t$107225;
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            if (!(t$107225)) {
                
                //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
                t$107226 = ((j) < (((long)(0L))));
            }
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            boolean t$107228 = t$107226;
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            if (!(t$107226)) {
                
                //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
                final long t$107227 = this.numElems_2;
                
                //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
                t$107228 = ((j) >= (((long)(t$107227))));
            }
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            if (t$107228) {
                
                //#line 240 "x10/array/DistArray_BlockBlock_3.x10"
                x10.array.DistArray.raiseBoundsError((long)(i), (long)(j), (long)(k));
            }
            
            //#line 242 "x10/array/DistArray_BlockBlock_3.x10"
            x10.array.DistArray.raisePlaceError((long)(i), (long)(j), (long)(k));
        }
    }
    
    
    //#line 247 "x10/array/DistArray_BlockBlock_3.x10"
    final public long offset$O(final long i, final long j, final long k) {
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107237 = this.numElems_3;
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107231 = this.minIndex_2;
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107235 = ((j) - (((long)(t$107231))));
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107233 = this.numElemsLocal_2;
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107232 = this.minIndex_1;
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107234 = ((i) - (((long)(t$107232))));
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107236 = ((t$107233) * (((long)(t$107234))));
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107238 = ((t$107235) + (((long)(t$107236))));
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107239 = ((t$107237) * (((long)(t$107238))));
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107240 = ((k) + (((long)(t$107239))));
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107240;
    }
    
    
    //#line 259 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Returns the specified rectangular patch of this array as a Rail.
     * 
     * @param space the IterationSpace representing the portion of this array to copy
     * @see offset
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in this array
     */
    public x10.core.Rail getPatch(final x10.array.IterationSpace space) {
        
        //#line 260 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 r = ((x10.array.DenseIterationSpace_3)(x10.rtt.Types.<x10.array.DenseIterationSpace_3> cast(space,x10.array.DenseIterationSpace_3.$RTT)));
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107241 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107242 = t$107241.min0;
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107243 = r.min0;
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107247 = ((t$107242) <= (((long)(t$107243))));
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107247) {
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107245 = r.max0;
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107244 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107246 = t$107244.max0;
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            t$107247 = ((t$107245) <= (((long)(t$107246))));
        }
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107251 = t$107247;
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107247) {
            
            //#line 264 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107248 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 264 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107249 = t$107248.min1;
            
            //#line 264 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107250 = r.min1;
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            t$107251 = ((t$107249) <= (((long)(t$107250))));
        }
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107255 = t$107251;
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107251) {
            
            //#line 264 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107253 = r.max1;
            
            //#line 264 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107252 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 264 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107254 = t$107252.max1;
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            t$107255 = ((t$107253) <= (((long)(t$107254))));
        }
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107259 = t$107255;
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107255) {
            
            //#line 265 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107256 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 265 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107257 = t$107256.min2;
            
            //#line 265 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107258 = r.min2;
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            t$107259 = ((t$107257) <= (((long)(t$107258))));
        }
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107263 = t$107259;
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107259) {
            
            //#line 265 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107261 = r.max2;
            
            //#line 265 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107260 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 265 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107262 = t$107260.max2;
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            t$107263 = ((t$107261) <= (((long)(t$107262))));
        }
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        final boolean t$107270 = !(t$107263);
        
        //#line 262 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107270) {
            
            //#line 266 "x10/array/DistArray_BlockBlock_3.x10"
            final java.lang.String t$107265 = (("patch to copy: ") + (r));
            
            //#line 266 "x10/array/DistArray_BlockBlock_3.x10"
            final java.lang.String t$107266 = ((t$107265) + (" not contained in local indices: "));
            
            //#line 266 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107267 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 266 "x10/array/DistArray_BlockBlock_3.x10"
            final java.lang.String t$107268 = ((t$107266) + (t$107267));
            
            //#line 266 "x10/array/DistArray_BlockBlock_3.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$107269 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$107268)));
            
            //#line 266 "x10/array/DistArray_BlockBlock_3.x10"
            throw t$107269;
        }
        
        //#line 269 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107271 = r.size$O();
        
        //#line 269 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.core.Rail patch = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$107271)), false)));
        
        //#line 270 "x10/array/DistArray_BlockBlock_3.x10"
        long patchIndex = 0L;
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        final long i2$106894min$107394 = r.min$O((long)(2L));
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        final long i2$106894max$107395 = r.max$O((long)(2L));
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        final long i1$106925min$107396 = r.min$O((long)(1L));
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        final long i1$106925max$107397 = r.max$O((long)(1L));
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        final long i0$106956min$107398 = r.min$O((long)(0L));
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        final long i0$106956max$107399 = r.max$O((long)(0L));
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        long i$107390 = i0$106956min$107398;
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        for (;
             true;
             ) {
            
            //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
            final boolean t$107392 = ((i$107390) <= (((long)(i0$106956max$107399))));
            
            //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
            if (!(t$107392)) {
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                break;
            }
            
            //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
            long i$107384 = i1$106925min$107396;
            
            //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
            for (;
                 true;
                 ) {
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                final boolean t$107386 = ((i$107384) <= (((long)(i1$106925max$107397))));
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                if (!(t$107386)) {
                    
                    //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                    break;
                }
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                long i$107378 = i2$106894min$107394;
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                    final boolean t$107380 = ((i$107378) <= (((long)(i2$106894max$107395))));
                    
                    //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                    if (!(t$107380)) {
                        
                        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                        break;
                    }
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    final long pre$107356 = patchIndex;
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107358 = ((patchIndex) + (((long)(1L))));
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    patchIndex = t$107358;
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    final x10.core.Rail t$107359 = ((x10.core.Rail)(this.raw));
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    final x10.array.DistArray_BlockBlock_3 this$107360 = ((x10.array.DistArray_BlockBlock_3)(this));
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107364 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107360).numElems_3;
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107365 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107360).minIndex_2;
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107366 = ((i$107384) - (((long)(t$107365))));
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107367 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107360).numElemsLocal_2;
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107368 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107360).minIndex_1;
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107369 = ((i$107390) - (((long)(t$107368))));
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107370 = ((t$107367) * (((long)(t$107369))));
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107371 = ((t$107366) + (((long)(t$107370))));
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107372 = ((t$107364) * (((long)(t$107371))));
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107373 = ((i$107378) + (((long)(t$107372))));
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    final $T t$107374 = (($T)(((x10.core.Rail<$T>)t$107359).$apply$G((long)(t$107373))));
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    ((x10.core.Rail<$T>)patch).$set__1x10$lang$Rail$$T$G((long)(pre$107356), (($T)(t$107374)));
                    
                    //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107377 = ((i$107378) + (((long)(1L))));
                    
                    //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                    i$107378 = t$107377;
                }
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                final long t$107383 = ((i$107384) + (((long)(1L))));
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                i$107384 = t$107383;
            }
            
            //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107389 = ((i$107390) + (((long)(1L))));
            
            //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
            i$107390 = t$107389;
        }
        
        //#line 274 "x10/array/DistArray_BlockBlock_3.x10"
        return patch;
    }
    
    
    //#line 277 "x10/array/DistArray_BlockBlock_3.x10"
    private static long validateSize$O(final long m, final long n, final long p) {
        
        //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107301 = ((m) < (((long)(0L))));
        
        //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107301)) {
            
            //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
            t$107301 = ((n) < (((long)(0L))));
        }
        
        //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107302 = t$107301;
        
        //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107301)) {
            
            //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
            t$107302 = ((p) < (((long)(0L))));
        }
        
        //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107302) {
            
            //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
            x10.array.DistArray.raiseNegativeArraySizeException();
        }
        
        //#line 279 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107304 = ((m) * (((long)(n))));
        
        //#line 279 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107305 = ((t$107304) * (((long)(p))));
        
        //#line 279 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107305;
    }
    
    public static long validateSize$P$O(final long m, final long n, final long p) {
        return x10.array.DistArray_BlockBlock_3.validateSize$O((long)(m), (long)(n), (long)(p));
    }
    
    
    //#line 23 "x10/array/DistArray_BlockBlock_3.x10"
    final public x10.array.DistArray_BlockBlock_3 x10$array$DistArray_BlockBlock_3$$this$x10$array$DistArray_BlockBlock_3() {
        
        //#line 23 "x10/array/DistArray_BlockBlock_3.x10"
        return x10.array.DistArray_BlockBlock_3.this;
    }
    
    
    //#line 23 "x10/array/DistArray_BlockBlock_3.x10"
    final public void __fieldInitializers_x10_array_DistArray_BlockBlock_3() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$8<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$8> $RTT = 
            x10.rtt.StaticFunType.<$Closure$8> make($Closure$8.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState_BB3.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_3.$Closure$8<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.m = $deserializer.readLong();
            $_obj.n = $deserializer.readLong();
            $_obj.p = $deserializer.readLong();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_BlockBlock_3.$Closure$8 $_obj = new x10.array.DistArray_BlockBlock_3.$Closure$8((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.m);
            $serializer.write(this.n);
            $serializer.write(this.p);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$8(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_3.$Closure$8.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState_BB3 $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$8 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$Closure$8$$T$2 {}
        
    
        
        public x10.array.LocalState_BB3 $apply() {
            
            //#line 71 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.LocalState_BB3 t$107343 = x10.array.LocalState_BB3.<$T> make__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$LocalState_BB3$$S$2($T, ((x10.lang.PlaceGroup)(this.pg)), (long)(this.m), (long)(this.n), (long)(this.p), ((x10.core.fun.Fun_0_3)(this.init)));
            
            //#line 71 "x10/array/DistArray_BlockBlock_3.x10"
            return t$107343;
        }
        
        public x10.lang.PlaceGroup pg;
        public long m;
        public long n;
        public long p;
        public x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init;
        
        public $Closure$8(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$Closure$8$$T$2 $dummy) {
            x10.array.DistArray_BlockBlock_3.$Closure$8.$initParams(this, $T);
             {
                ((x10.array.DistArray_BlockBlock_3.$Closure$8<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
                ((x10.array.DistArray_BlockBlock_3.$Closure$8<$T>)this).m = m;
                ((x10.array.DistArray_BlockBlock_3.$Closure$8<$T>)this).n = n;
                ((x10.array.DistArray_BlockBlock_3.$Closure$8<$T>)this).p = p;
                ((x10.array.DistArray_BlockBlock_3.$Closure$8<$T>)this).init = ((x10.core.fun.Fun_0_3)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$9<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$9> $RTT = 
            x10.rtt.StaticFunType.<$Closure$9> make($Closure$9.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_3.$Closure$9<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_BlockBlock_3.$Closure$9 $_obj = new x10.array.DistArray_BlockBlock_3.$Closure$9((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$9(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_3.$Closure$9.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$9 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$60, final long id$61, final long id$62) {
            
            //#line 109 "x10/array/DistArray_BlockBlock_3.x10"
            final $T t$107148 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 109 "x10/array/DistArray_BlockBlock_3.x10"
            return t$107148;
        }
        
        public $Closure$9(final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_3.$Closure$9.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$10<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$10> $RTT = 
            x10.rtt.StaticFunType.<$Closure$10> make($Closure$10.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_3.$Closure$10<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_BlockBlock_3.$Closure$10 $_obj = new x10.array.DistArray_BlockBlock_3.$Closure$10((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$10(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_3.$Closure$10.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$10 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$63, final long id$64, final long id$65) {
            
            //#line 123 "x10/array/DistArray_BlockBlock_3.x10"
            final $T t$107150 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 123 "x10/array/DistArray_BlockBlock_3.x10"
            return t$107150;
        }
        
        public $Closure$10(final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_3.$Closure$10.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
}


