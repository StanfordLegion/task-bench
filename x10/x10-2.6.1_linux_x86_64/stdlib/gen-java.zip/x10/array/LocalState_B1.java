package x10.array;

@x10.runtime.impl.java.X10Generated
public class LocalState_B1<$S> extends x10.array.LocalState<$S> implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<LocalState_B1> $RTT = 
        x10.rtt.NamedType.<LocalState_B1> make("x10.array.LocalState_B1",
                                               LocalState_B1.class,
                                               1,
                                               new x10.rtt.Type[] {
                                                   x10.rtt.ParameterizedType.make(x10.array.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                               });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $S; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$S> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.LocalState_B1<$S> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.LocalState.$_deserialize_body($_obj, $deserializer);
        $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
        $_obj.dist = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.LocalState_B1 $_obj = new x10.array.LocalState_B1((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$S);
        $serializer.write(this.dist);
        
    }
    
    // constructor just for allocation
    public LocalState_B1(final java.lang.System[] $dummy, final x10.rtt.Type $S) {
        super($dummy, $S);
        x10.array.LocalState_B1.$initParams(this, $S);
        
    }
    
    private x10.rtt.Type $S;
    
    // initializer of type parameters
    public static void $initParams(final LocalState_B1 $this, final x10.rtt.Type $S) {
        $this.$S = $S;
        
    }
    // synthetic type for parameter mangling
    public static final class __1$1x10$array$LocalState_B1$$S$2 {}
    

    
    //#line 234 "x10/array/DistArray_Block_1.x10"
    public x10.array.Dist_Block_1 dist;
    
    
    //#line 236 "x10/array/DistArray_Block_1.x10"
    // creation method for java code (1-phase java constructor)
    public LocalState_B1(final x10.rtt.Type $S, final x10.lang.PlaceGroup pg, final x10.core.Rail<$S> data, final long size, final x10.array.Dist_Block_1 d, __1$1x10$array$LocalState_B1$$S$2 $dummy) {
        this((java.lang.System[]) null, $S);
        x10$array$LocalState_B1$$init$S(pg, data, size, d, (x10.array.LocalState_B1.__1$1x10$array$LocalState_B1$$S$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.LocalState_B1<$S> x10$array$LocalState_B1$$init$S(final x10.lang.PlaceGroup pg, final x10.core.Rail<$S> data, final long size, final x10.array.Dist_Block_1 d, __1$1x10$array$LocalState_B1$$S$2 $dummy) {
         {
            
            //#line 238 "x10/array/DistArray_Block_1.x10"
            final x10.array.LocalState this$107731 = ((x10.array.LocalState)(this));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$107731).pg = ((x10.lang.PlaceGroup)(pg));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$107731).rail = ((x10.core.Rail)(data));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$107731).size = size;
            
            //#line 236 "x10/array/DistArray_Block_1.x10"
            
            
            //#line 239 "x10/array/DistArray_Block_1.x10"
            ((x10.array.LocalState_B1<$S>)this).dist = ((x10.array.Dist_Block_1)(d));
        }
        return this;
    }
    
    
    
    //#line 242 "x10/array/DistArray_Block_1.x10"
    public static <$S>x10.array.LocalState_B1 make__2$1x10$lang$Long$3x10$array$LocalState_B1$$S$2(final x10.rtt.Type $S, final x10.lang.PlaceGroup pg, final long n, final x10.core.fun.Fun_0_1<x10.core.Long,$S> init) {
        
        //#line 243 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 globalSpace = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
        
        //#line 243 "x10/array/DistArray_Block_1.x10"
        final long t$107912 = ((n) - (((long)(1L))));
        
        //#line 243 "x10/array/DistArray_Block_1.x10"
        globalSpace.x10$array$DenseIterationSpace_1$$init$S(((long)(0L)), t$107912);
        
        //#line 244 "x10/array/DistArray_Block_1.x10"
        final x10.array.Dist_Block_1 dist = ((x10.array.Dist_Block_1)(new x10.array.Dist_Block_1((java.lang.System[]) null)));
        
        //#line 244 "x10/array/DistArray_Block_1.x10"
        dist.x10$array$Dist_Block_1$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.array.DenseIterationSpace_1)(globalSpace)));
        
        //#line 246 "x10/array/DistArray_Block_1.x10"
        final x10.core.Rail data;
        
        //#line 247 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 this$107736 = ((x10.array.DenseIterationSpace_1)(dist.localIndices));
        
        //#line 47 . "x10/array/DenseIterationSpace_1.x10"
        final long t$107838 = this$107736.max;
        
        //#line 47 . "x10/array/DenseIterationSpace_1.x10"
        final long t$107839 = this$107736.min;
        
        //#line 47 . "x10/array/DenseIterationSpace_1.x10"
        final boolean t$107851 = ((t$107838) < (((long)(t$107839))));
        
        //#line 247 "x10/array/DistArray_Block_1.x10"
        if (t$107851) {
            
            //#line 248 "x10/array/DistArray_Block_1.x10"
            final x10.core.Rail t$107840 = ((x10.core.Rail)(new x10.core.Rail<$S>($S)));
            
            //#line 248 "x10/array/DistArray_Block_1.x10"
            data = ((x10.core.Rail)(t$107840));
        } else {
            
            //#line 250 "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$107841 = ((x10.array.DenseIterationSpace_1)(dist.localIndices));
            
            //#line 250 "x10/array/DistArray_Block_1.x10"
            final long low = t$107841.min$O((long)(0L));
            
            //#line 251 "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$107842 = ((x10.array.DenseIterationSpace_1)(dist.localIndices));
            
            //#line 251 "x10/array/DistArray_Block_1.x10"
            final long hi = t$107842.max$O((long)(0L));
            
            //#line 252 "x10/array/DistArray_Block_1.x10"
            final long t$107843 = ((hi) - (((long)(low))));
            
            //#line 252 "x10/array/DistArray_Block_1.x10"
            final long dataSize = ((t$107843) + (((long)(1L))));
            
            //#line 253 "x10/array/DistArray_Block_1.x10"
            final x10.core.Rail t$107844 = ((x10.core.Rail)(x10.core.Rail.<$S>makeUnsafe($S, ((long)(dataSize)), false)));
            
            //#line 253 "x10/array/DistArray_Block_1.x10"
            data = ((x10.core.Rail)(t$107844));
            
            //#line 254 "x10/array/DistArray_Block_1.x10"
            long i$107907 = low;
            
            //#line 254 "x10/array/DistArray_Block_1.x10"
            for (;
                 true;
                 ) {
                
                //#line 254 "x10/array/DistArray_Block_1.x10"
                final boolean t$107909 = ((i$107907) <= (((long)(hi))));
                
                //#line 254 "x10/array/DistArray_Block_1.x10"
                if (!(t$107909)) {
                    
                    //#line 254 "x10/array/DistArray_Block_1.x10"
                    break;
                }
                
                //#line 255 "x10/array/DistArray_Block_1.x10"
                final long offset$107902 = ((i$107907) - (((long)(low))));
                
                //#line 256 "x10/array/DistArray_Block_1.x10"
                final $S t$107903 = (($S)((($S)
                                            ((x10.core.fun.Fun_0_1<x10.core.Long,$S>)init).$apply(x10.core.Long.$box(i$107907), x10.rtt.Types.LONG))));
                
                //#line 256 "x10/array/DistArray_Block_1.x10"
                ((x10.core.Rail<$S>)data).$set__1x10$lang$Rail$$T$G((long)(offset$107902), (($S)(t$107903)));
                
                //#line 254 "x10/array/DistArray_Block_1.x10"
                final long t$107906 = ((i$107907) + (((long)(1L))));
                
                //#line 254 "x10/array/DistArray_Block_1.x10"
                i$107907 = t$107906;
            }
        }
        
        //#line 259 "x10/array/DistArray_Block_1.x10"
        final x10.array.LocalState_B1 alloc$107644 = ((x10.array.LocalState_B1)(new x10.array.LocalState_B1<$S>((java.lang.System[]) null, $S)));
        
        //#line 259 "x10/array/DistArray_Block_1.x10"
        alloc$107644.x10$array$LocalState_B1$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.Rail)(data)), ((long)(n)), ((x10.array.Dist_Block_1)(dist)), (x10.array.LocalState_B1.__1$1x10$array$LocalState_B1$$S$2) null);
        
        //#line 259 "x10/array/DistArray_Block_1.x10"
        return alloc$107644;
    }
    
    
    //#line 233 "x10/array/DistArray_Block_1.x10"
    final public x10.array.LocalState_B1 x10$array$LocalState_B1$$this$x10$array$LocalState_B1() {
        
        //#line 233 "x10/array/DistArray_Block_1.x10"
        return x10.array.LocalState_B1.this;
    }
    
    
    //#line 233 "x10/array/DistArray_Block_1.x10"
    final public void __fieldInitializers_x10_array_LocalState_B1() {
        
    }
}

