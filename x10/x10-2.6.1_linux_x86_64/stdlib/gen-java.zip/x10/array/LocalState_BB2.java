package x10.array;

@x10.runtime.impl.java.X10Generated
public class LocalState_BB2<$S> extends x10.array.LocalState<$S> implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<LocalState_BB2> $RTT = 
        x10.rtt.NamedType.<LocalState_BB2> make("x10.array.LocalState_BB2",
                                                LocalState_BB2.class,
                                                1,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.array.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $S; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$S> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.LocalState_BB2<$S> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.LocalState.$_deserialize_body($_obj, $deserializer);
        $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
        $_obj.dist = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.LocalState_BB2 $_obj = new x10.array.LocalState_BB2((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$S);
        $serializer.write(this.dist);
        
    }
    
    // constructor just for allocation
    public LocalState_BB2(final java.lang.System[] $dummy, final x10.rtt.Type $S) {
        super($dummy, $S);
        x10.array.LocalState_BB2.$initParams(this, $S);
        
    }
    
    private x10.rtt.Type $S;
    
    // initializer of type parameters
    public static void $initParams(final LocalState_BB2 $this, final x10.rtt.Type $S) {
        $this.$S = $S;
        
    }
    // synthetic type for parameter mangling
    public static final class __1$1x10$array$LocalState_BB2$$S$2 {}
    

    
    //#line 271 "x10/array/DistArray_BlockBlock_2.x10"
    public x10.array.Dist_BlockBlock_2 dist;
    
    
    //#line 273 "x10/array/DistArray_BlockBlock_2.x10"
    // creation method for java code (1-phase java constructor)
    public LocalState_BB2(final x10.rtt.Type $S, final x10.lang.PlaceGroup pg, final x10.core.Rail<$S> data, final long size, final x10.array.Dist_BlockBlock_2 d, __1$1x10$array$LocalState_BB2$$S$2 $dummy) {
        this((java.lang.System[]) null, $S);
        x10$array$LocalState_BB2$$init$S(pg, data, size, d, (x10.array.LocalState_BB2.__1$1x10$array$LocalState_BB2$$S$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.LocalState_BB2<$S> x10$array$LocalState_BB2$$init$S(final x10.lang.PlaceGroup pg, final x10.core.Rail<$S> data, final long size, final x10.array.Dist_BlockBlock_2 d, __1$1x10$array$LocalState_BB2$$S$2 $dummy) {
         {
            
            //#line 275 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.LocalState this$106138 = ((x10.array.LocalState)(this));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$106138).pg = ((x10.lang.PlaceGroup)(pg));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$106138).rail = ((x10.core.Rail)(data));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$106138).size = size;
            
            //#line 273 "x10/array/DistArray_BlockBlock_2.x10"
            
            
            //#line 276 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.LocalState_BB2<$S>)this).dist = ((x10.array.Dist_BlockBlock_2)(d));
        }
        return this;
    }
    
    
    
    //#line 279 "x10/array/DistArray_BlockBlock_2.x10"
    public static <$S>x10.array.LocalState_BB2 make__3$1x10$lang$Long$3x10$lang$Long$3x10$array$LocalState_BB2$$S$2(final x10.rtt.Type $S, final x10.lang.PlaceGroup pg, final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$S> init) {
        
        //#line 280 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 globalSpace = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 280 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106383 = ((m) - (((long)(1L))));
        
        //#line 280 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106384 = ((n) - (((long)(1L))));
        
        //#line 280 "x10/array/DistArray_BlockBlock_2.x10"
        globalSpace.x10$array$DenseIterationSpace_2$$init$S(((long)(0L)), ((long)(0L)), t$106383, t$106384);
        
        //#line 281 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.Dist_BlockBlock_2 dist = ((x10.array.Dist_BlockBlock_2)(new x10.array.Dist_BlockBlock_2((java.lang.System[]) null)));
        
        //#line 281 "x10/array/DistArray_BlockBlock_2.x10"
        dist.x10$array$Dist_BlockBlock_2$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.array.DenseIterationSpace_2)(globalSpace)));
        
        //#line 283 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.core.Rail data;
        
        //#line 284 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106294 = ((x10.array.DenseIterationSpace_2)(dist.localIndices));
        
        //#line 284 "x10/array/DistArray_BlockBlock_2.x10"
        final boolean t$106317 = t$106294.isEmpty$O();
        
        //#line 284 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106317) {
            
            //#line 285 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.core.Rail t$106295 = ((x10.core.Rail)(new x10.core.Rail<$S>($S)));
            
            //#line 285 "x10/array/DistArray_BlockBlock_2.x10"
            data = ((x10.core.Rail)(t$106295));
        } else {
            
            //#line 287 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106296 = ((x10.array.DenseIterationSpace_2)(dist.localIndices));
            
            //#line 287 "x10/array/DistArray_BlockBlock_2.x10"
            final long low1 = t$106296.min$O((long)(0L));
            
            //#line 288 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106297 = ((x10.array.DenseIterationSpace_2)(dist.localIndices));
            
            //#line 288 "x10/array/DistArray_BlockBlock_2.x10"
            final long hi1 = t$106297.max$O((long)(0L));
            
            //#line 289 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106298 = ((x10.array.DenseIterationSpace_2)(dist.localIndices));
            
            //#line 289 "x10/array/DistArray_BlockBlock_2.x10"
            final long low2 = t$106298.min$O((long)(1L));
            
            //#line 290 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106299 = ((x10.array.DenseIterationSpace_2)(dist.localIndices));
            
            //#line 290 "x10/array/DistArray_BlockBlock_2.x10"
            final long hi2 = t$106299.max$O((long)(1L));
            
            //#line 291 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106300 = ((hi1) - (((long)(low1))));
            
            //#line 291 "x10/array/DistArray_BlockBlock_2.x10"
            final long localSize1 = ((t$106300) + (((long)(1L))));
            
            //#line 292 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106301 = ((hi2) - (((long)(low2))));
            
            //#line 292 "x10/array/DistArray_BlockBlock_2.x10"
            final long localSize2 = ((t$106301) + (((long)(1L))));
            
            //#line 293 "x10/array/DistArray_BlockBlock_2.x10"
            final long dataSize = ((localSize1) * (((long)(localSize2))));
            
            //#line 294 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.core.Rail t$106302 = ((x10.core.Rail)(x10.core.Rail.<$S>makeUnsafe($S, ((long)(dataSize)), false)));
            
            //#line 294 "x10/array/DistArray_BlockBlock_2.x10"
            data = ((x10.core.Rail)(t$106302));
            
            //#line 295 "x10/array/DistArray_BlockBlock_2.x10"
            long i$106378 = low1;
            
            //#line 295 "x10/array/DistArray_BlockBlock_2.x10"
            for (;
                 true;
                 ) {
                
                //#line 295 "x10/array/DistArray_BlockBlock_2.x10"
                final boolean t$106380 = ((i$106378) <= (((long)(hi1))));
                
                //#line 295 "x10/array/DistArray_BlockBlock_2.x10"
                if (!(t$106380)) {
                    
                    //#line 295 "x10/array/DistArray_BlockBlock_2.x10"
                    break;
                }
                
                //#line 296 "x10/array/DistArray_BlockBlock_2.x10"
                long i$106370 = low2;
                
                //#line 296 "x10/array/DistArray_BlockBlock_2.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 296 "x10/array/DistArray_BlockBlock_2.x10"
                    final boolean t$106372 = ((i$106370) <= (((long)(hi2))));
                    
                    //#line 296 "x10/array/DistArray_BlockBlock_2.x10"
                    if (!(t$106372)) {
                        
                        //#line 296 "x10/array/DistArray_BlockBlock_2.x10"
                        break;
                    }
                    
                    //#line 297 "x10/array/DistArray_BlockBlock_2.x10"
                    final long t$106362 = ((i$106370) - (((long)(low2))));
                    
                    //#line 297 "x10/array/DistArray_BlockBlock_2.x10"
                    final long t$106363 = ((i$106378) - (((long)(low1))));
                    
                    //#line 297 "x10/array/DistArray_BlockBlock_2.x10"
                    final long t$106364 = ((t$106363) * (((long)(localSize2))));
                    
                    //#line 297 "x10/array/DistArray_BlockBlock_2.x10"
                    final long offset$106365 = ((t$106362) + (((long)(t$106364))));
                    
                    //#line 298 "x10/array/DistArray_BlockBlock_2.x10"
                    final $S t$106366 = (($S)((($S)
                                                ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$S>)init).$apply(x10.core.Long.$box(i$106378), x10.rtt.Types.LONG, x10.core.Long.$box(i$106370), x10.rtt.Types.LONG))));
                    
                    //#line 298 "x10/array/DistArray_BlockBlock_2.x10"
                    ((x10.core.Rail<$S>)data).$set__1x10$lang$Rail$$T$G((long)(offset$106365), (($S)(t$106366)));
                    
                    //#line 296 "x10/array/DistArray_BlockBlock_2.x10"
                    final long t$106369 = ((i$106370) + (((long)(1L))));
                    
                    //#line 296 "x10/array/DistArray_BlockBlock_2.x10"
                    i$106370 = t$106369;
                }
                
                //#line 295 "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106377 = ((i$106378) + (((long)(1L))));
                
                //#line 295 "x10/array/DistArray_BlockBlock_2.x10"
                i$106378 = t$106377;
            }
        }
        
        //#line 302 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.LocalState_BB2 alloc$105880 = ((x10.array.LocalState_BB2)(new x10.array.LocalState_BB2<$S>((java.lang.System[]) null, $S)));
        
        //#line 302 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106385 = ((m) * (((long)(n))));
        
        //#line 302 "x10/array/DistArray_BlockBlock_2.x10"
        alloc$105880.x10$array$LocalState_BB2$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.Rail)(data)), t$106385, ((x10.array.Dist_BlockBlock_2)(dist)), (x10.array.LocalState_BB2.__1$1x10$array$LocalState_BB2$$S$2) null);
        
        //#line 302 "x10/array/DistArray_BlockBlock_2.x10"
        return alloc$105880;
    }
    
    
    //#line 270 "x10/array/DistArray_BlockBlock_2.x10"
    final public x10.array.LocalState_BB2 x10$array$LocalState_BB2$$this$x10$array$LocalState_BB2() {
        
        //#line 270 "x10/array/DistArray_BlockBlock_2.x10"
        return x10.array.LocalState_BB2.this;
    }
    
    
    //#line 270 "x10/array/DistArray_BlockBlock_2.x10"
    final public void __fieldInitializers_x10_array_LocalState_BB2() {
        
    }
}

