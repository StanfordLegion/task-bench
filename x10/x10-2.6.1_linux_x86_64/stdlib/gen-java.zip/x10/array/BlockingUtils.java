package x10.array;

/**
 * Utility functions for blocking iteration spaces.
 * Can be used both for computing local iteration spaces for 
 * distributed arrays and for tiling iteration spaces for concurrency within
 * a single place. 
 */
@x10.runtime.impl.java.X10Generated
public class BlockingUtils extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<BlockingUtils> $RTT = 
        x10.rtt.NamedType.<BlockingUtils> make("x10.array.BlockingUtils",
                                               BlockingUtils.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.BlockingUtils $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.BlockingUtils $_obj = new x10.array.BlockingUtils((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public BlockingUtils(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 43 "x10/array/BlockingUtils.x10"
    /**
     * A Block distribution takes a rank-1 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * @param is the iteration space to partition
     * @param n is the total number of partitions desired
     * @return the IterationSpace representing the ith partition
     */
    public static x10.core.Rail partitionBlock(final x10.array.IterationSpace is, final long n) {
        
        //#line 44 "x10/array/BlockingUtils.x10"
        final x10.core.fun.Fun_0_1 t$103865 = ((x10.core.fun.Fun_0_1)(new x10.array.BlockingUtils.$Closure$0(is, n)));
        
        //#line 44 "x10/array/BlockingUtils.x10"
        final x10.core.Rail t$103866 = ((x10.core.Rail)(new x10.core.Rail<x10.array.DenseIterationSpace_1>(x10.array.DenseIterationSpace_1.$RTT, ((long)(n)), ((x10.core.fun.Fun_0_1)(t$103865)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 44 "x10/array/BlockingUtils.x10"
        return t$103866;
    }
    
    
    //#line 65 "x10/array/BlockingUtils.x10"
    /**
     * A Block distribution takes a rank-1 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes and returns the ith element in such a distribution.
     *
     * @param is the iteration space to partition
     * @param n is the total number of partitions desired
     * @param i is the index of the partition requested
     * @return the IterationSpace representing the ith partition
     */
    public static x10.array.DenseIterationSpace_1 partitionBlock(final x10.array.IterationSpace is, final long n, final long i) {
        
        //#line 66 "x10/array/BlockingUtils.x10"
        final long t$103867 = is.min$O((long)(0L));
        
        //#line 66 "x10/array/BlockingUtils.x10"
        final long t$103868 = is.max$O((long)(0L));
        
        //#line 66 "x10/array/BlockingUtils.x10"
        final x10.array.DenseIterationSpace_1 t$103869 = ((x10.array.DenseIterationSpace_1)(x10.array.BlockingUtils.partitionBlock((long)(t$103867), (long)(t$103868), (long)(n), (long)(i))));
        
        //#line 66 "x10/array/BlockingUtils.x10"
        return t$103869;
    }
    
    
    //#line 88 "x10/array/BlockingUtils.x10"
    /**
     * A Block distribution takes a rank-1 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes and returns the ith element in such a distribution.
     *
     * @param min is the minimum element in the iteration space to partition
     * @param max is the maximum element in the iteration space to partition
     * @param n is the total number of partitions desired
     * @param i is the index of the partition requested
     * @return the IterationSpace representing the ith partition
     */
    public static x10.array.DenseIterationSpace_1 partitionBlock(final long min, final long max, final long n, final long i) {
        
        //#line 89 "x10/array/BlockingUtils.x10"
        final long t$103870 = ((max) - (((long)(min))));
        
        //#line 89 "x10/array/BlockingUtils.x10"
        final long numElems = ((t$103870) + (((long)(1L))));
        
        //#line 90 "x10/array/BlockingUtils.x10"
        final boolean t$103872 = ((numElems) < (((long)(1L))));
        
        //#line 90 "x10/array/BlockingUtils.x10"
        if (t$103872) {
            
            //#line 90 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_1 t$103871 = ((x10.array.DenseIterationSpace_1)(x10.array.DenseIterationSpace_1.get$EMPTY()));
            
            //#line 90 "x10/array/BlockingUtils.x10"
            return t$103871;
        }
        
        //#line 91 "x10/array/BlockingUtils.x10"
        final long blockSize = ((numElems) / (((long)(n))));
        
        //#line 92 "x10/array/BlockingUtils.x10"
        final long t$103873 = ((n) * (((long)(blockSize))));
        
        //#line 92 "x10/array/BlockingUtils.x10"
        final long leftOver = ((numElems) - (((long)(t$103873))));
        
        //#line 93 "x10/array/BlockingUtils.x10"
        final long t$103874 = ((blockSize) * (((long)(i))));
        
        //#line 93 "x10/array/BlockingUtils.x10"
        final long t$103877 = ((min) + (((long)(t$103874))));
        
        //#line 93 "x10/array/BlockingUtils.x10"
        final boolean t$103875 = ((i) < (((long)(leftOver))));
        
        //#line 93 "x10/array/BlockingUtils.x10"
        long t$103876 =  0;
        
        //#line 93 "x10/array/BlockingUtils.x10"
        if (t$103875) {
            
            //#line 93 "x10/array/BlockingUtils.x10"
            t$103876 = i;
        } else {
            
            //#line 93 "x10/array/BlockingUtils.x10"
            t$103876 = leftOver;
        }
        
        //#line 93 "x10/array/BlockingUtils.x10"
        final long low = ((t$103877) + (((long)(t$103876))));
        
        //#line 94 "x10/array/BlockingUtils.x10"
        final long t$103881 = ((low) + (((long)(blockSize))));
        
        //#line 94 "x10/array/BlockingUtils.x10"
        final boolean t$103879 = ((i) < (((long)(leftOver))));
        
        //#line 94 "x10/array/BlockingUtils.x10"
        long t$103880 =  0;
        
        //#line 94 "x10/array/BlockingUtils.x10"
        if (t$103879) {
            
            //#line 94 "x10/array/BlockingUtils.x10"
            t$103880 = 0L;
        } else {
            
            //#line 94 "x10/array/BlockingUtils.x10"
            t$103880 = -1L;
        }
        
        //#line 94 "x10/array/BlockingUtils.x10"
        final long hi = ((t$103881) + (((long)(t$103880))));
        
        //#line 95 "x10/array/BlockingUtils.x10"
        final x10.array.DenseIterationSpace_1 alloc$103204 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
        
        //#line 95 "x10/array/BlockingUtils.x10"
        alloc$103204.x10$array$DenseIterationSpace_1$$init$S(((long)(low)), ((long)(hi)));
        
        //#line 95 "x10/array/BlockingUtils.x10"
        return alloc$103204;
    }
    
    
    //#line 117 "x10/array/BlockingUtils.x10"
    /**
     * A Block distribution takes a rank-1 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes which partition an argument index would be placed.
     *
     * @param is the iteration space to partition
     * @param n is the total number of partitions desired
     * @param i the given index 
     * @return the partition number into which i is mapped by the distribution
     *         (or -1 if not contained in the bounding box of the argument iteration space)
     */
    public static long mapIndexToBlockPartition$O(final x10.array.IterationSpace is, final long n, final long i) {
        
        //#line 118 "x10/array/BlockingUtils.x10"
        is.min$O((long)(0L));
        
        //#line 119 "x10/array/BlockingUtils.x10"
        is.max$O((long)(0L));
        
        //#line 120 "x10/array/BlockingUtils.x10"
        final long t$103883 = is.min$O((long)(0L));
        
        //#line 120 "x10/array/BlockingUtils.x10"
        final long t$103884 = is.max$O((long)(0L));
        
        //#line 120 "x10/array/BlockingUtils.x10"
        final long t$103885 = x10.array.BlockingUtils.mapIndexToBlockPartition$O((long)(t$103883), (long)(t$103884), (long)(n), (long)(i));
        
        //#line 120 "x10/array/BlockingUtils.x10"
        return t$103885;
    }
    
    
    //#line 143 "x10/array/BlockingUtils.x10"
    /**
     * A Block distribution takes a rank-1 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes which partition an argument index would be placed.
     *
     * @param min is the minimum element in the iteration space to partition
     * @param max is the maximum element in the iteration space to partition
     * @param n is the total number of partitions desired
     * @param i the given index 
     * @return the partition number into which i is mapped by the distribution
     *         (or -1 if not contained in the bounding box of the argument iteration space)
     */
    public static long mapIndexToBlockPartition$O(final long min, final long max, final long n, final long i) {
        
        //#line 144 "x10/array/BlockingUtils.x10"
        boolean t$103886 = ((i) < (((long)(min))));
        
        //#line 144 "x10/array/BlockingUtils.x10"
        if (!(t$103886)) {
            
            //#line 144 "x10/array/BlockingUtils.x10"
            t$103886 = ((i) > (((long)(max))));
        }
        
        //#line 144 "x10/array/BlockingUtils.x10"
        if (t$103886) {
            
            //#line 144 "x10/array/BlockingUtils.x10"
            return -1L;
        }
        
        //#line 145 "x10/array/BlockingUtils.x10"
        final long t$103888 = ((max) - (((long)(min))));
        
        //#line 145 "x10/array/BlockingUtils.x10"
        final long numElems = ((t$103888) + (((long)(1L))));
        
        //#line 146 "x10/array/BlockingUtils.x10"
        final long blockSize = ((numElems) / (((long)(n))));
        
        //#line 147 "x10/array/BlockingUtils.x10"
        final long t$103889 = ((n) * (((long)(blockSize))));
        
        //#line 147 "x10/array/BlockingUtils.x10"
        final long leftOver = ((numElems) - (((long)(t$103889))));
        
        //#line 148 "x10/array/BlockingUtils.x10"
        final long normalizedIndex = ((i) - (((long)(min))));
        
        //#line 149 "x10/array/BlockingUtils.x10"
        final long t$103890 = ((blockSize) + (((long)(1L))));
        
        //#line 149 "x10/array/BlockingUtils.x10"
        final long nominalIndex = ((normalizedIndex) / (((long)(t$103890))));
        
        //#line 150 "x10/array/BlockingUtils.x10"
        final boolean t$103894 = ((nominalIndex) < (((long)(leftOver))));
        
        //#line 150 "x10/array/BlockingUtils.x10"
        if (t$103894) {
            
            //#line 151 "x10/array/BlockingUtils.x10"
            return nominalIndex;
        } else {
            
            //#line 153 "x10/array/BlockingUtils.x10"
            final long indexFromTop = ((max) - (((long)(i))));
            
            //#line 154 "x10/array/BlockingUtils.x10"
            final long t$103891 = ((n) - (((long)(1L))));
            
            //#line 154 "x10/array/BlockingUtils.x10"
            final long t$103892 = ((indexFromTop) / (((long)(blockSize))));
            
            //#line 154 "x10/array/BlockingUtils.x10"
            final long t$103893 = ((t$103891) - (((long)(t$103892))));
            
            //#line 154 "x10/array/BlockingUtils.x10"
            return t$103893;
        }
    }
    
    
    //#line 179 "x10/array/BlockingUtils.x10"
    /**
     * A BlockBlock distribution takes a rank-2 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units in 2-d grid.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * @param is the iteration space to partition
     * @param n is the total number of partitions desired
     * @return the IterationSpace representing the ith partition
     */
    public static x10.core.Rail partitionBlockBlock(final x10.array.IterationSpace is, final long n) {
        
        //#line 180 "x10/array/BlockingUtils.x10"
        final x10.core.fun.Fun_0_1 t$103896 = ((x10.core.fun.Fun_0_1)(new x10.array.BlockingUtils.$Closure$1(is, n)));
        
        //#line 180 "x10/array/BlockingUtils.x10"
        final x10.core.Rail t$103897 = ((x10.core.Rail)(new x10.core.Rail<x10.array.DenseIterationSpace_2>(x10.array.DenseIterationSpace_2.$RTT, ((long)(n)), ((x10.core.fun.Fun_0_1)(t$103896)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 180 "x10/array/BlockingUtils.x10"
        return t$103897;
    }
    
    
    //#line 201 "x10/array/BlockingUtils.x10"
    /**
     * A BlockBlock distribution takes a rank-2 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units in 2-d grid.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes and returns the ith element in such a distribution.
     *
     * @param is the iteration space to partition
     * @param n is the total number of partitions desired
     * @param i is the index of the partition requested
     * @return the IterationSpace representing the ith partition
     */
    public static x10.array.DenseIterationSpace_2 partitionBlockBlock(final x10.array.IterationSpace is, final long n, final long i) {
        
        //#line 202 "x10/array/BlockingUtils.x10"
        final long min0 = is.min$O((long)(0L));
        
        //#line 203 "x10/array/BlockingUtils.x10"
        final long max0 = is.max$O((long)(0L));
        
        //#line 204 "x10/array/BlockingUtils.x10"
        final long min1 = is.min$O((long)(1L));
        
        //#line 205 "x10/array/BlockingUtils.x10"
        final long max1 = is.max$O((long)(1L));
        
        //#line 206 "x10/array/BlockingUtils.x10"
        final x10.array.DenseIterationSpace_2 t$103898 = ((x10.array.DenseIterationSpace_2)(x10.array.BlockingUtils.partitionBlockBlock((long)(min0), (long)(min1), (long)(max0), (long)(max1), (long)(n), (long)(i))));
        
        //#line 206 "x10/array/BlockingUtils.x10"
        return t$103898;
    }
    
    
    //#line 230 "x10/array/BlockingUtils.x10"
    /**
     * A BlockBlock distribution takes a rank-2 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units in 2-d grid.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes and returns the ith element in such a distribution.
     *
     * param min0 is the min index of the first dimension
     * param min1 is the min index of the second dimension
     * param max0 is the max index of the first dimension
     * param max1 is the max index of the second dimension
     * @param n is the total number of partitions desired
     * @param i is the index of the partition requested
     * @return the IterationSpace representing the ith partition
     */
    public static x10.array.DenseIterationSpace_2 partitionBlockBlock(final long min0, final long min1, final long max0, final long max1, final long n, final long i) {
        
        //#line 232 "x10/array/BlockingUtils.x10"
        final long t$103899 = ((max0) - (((long)(min0))));
        
        //#line 232 "x10/array/BlockingUtils.x10"
        final long size0 = ((t$103899) + (((long)(1L))));
        
        //#line 233 "x10/array/BlockingUtils.x10"
        final long t$103900 = ((max1) - (((long)(min1))));
        
        //#line 233 "x10/array/BlockingUtils.x10"
        final long size1 = ((t$103900) + (((long)(1L))));
        
        //#line 235 "x10/array/BlockingUtils.x10"
        boolean t$103901 = ((size0) < (((long)(1L))));
        
        //#line 235 "x10/array/BlockingUtils.x10"
        if (!(t$103901)) {
            
            //#line 235 "x10/array/BlockingUtils.x10"
            t$103901 = ((size1) < (((long)(1L))));
        }
        
        //#line 235 "x10/array/BlockingUtils.x10"
        if (t$103901) {
            
            //#line 235 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_2 t$103902 = ((x10.array.DenseIterationSpace_2)(x10.array.DenseIterationSpace_2.get$EMPTY()));
            
            //#line 235 "x10/array/BlockingUtils.x10"
            return t$103902;
        }
        
        //#line 236 "x10/array/BlockingUtils.x10"
        final boolean t$103906 = ((long) size0) == ((long) 1L);
        
        //#line 236 "x10/array/BlockingUtils.x10"
        if (t$103906) {
            
            //#line 237 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_1 is1 = ((x10.array.DenseIterationSpace_1)(x10.array.BlockingUtils.partitionBlock((long)(min1), (long)(max1), (long)(n), (long)(i))));
            
            //#line 238 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_2 alloc$103205 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
            
            //#line 238 "x10/array/BlockingUtils.x10"
            final long t$104015 = is1.min$O((long)(0L));
            
            //#line 238 "x10/array/BlockingUtils.x10"
            final long t$104016 = is1.max$O((long)(0L));
            
            //#line 238 "x10/array/BlockingUtils.x10"
            alloc$103205.x10$array$DenseIterationSpace_2$$init$S(((long)(min0)), t$104015, ((long)(max0)), t$104016);
            
            //#line 238 "x10/array/BlockingUtils.x10"
            return alloc$103205;
        }
        
        //#line 240 "x10/array/BlockingUtils.x10"
        final boolean t$103909 = ((long) size1) == ((long) 1L);
        
        //#line 240 "x10/array/BlockingUtils.x10"
        if (t$103909) {
            
            //#line 241 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_1 is0 = ((x10.array.DenseIterationSpace_1)(x10.array.BlockingUtils.partitionBlock((long)(min0), (long)(max0), (long)(n), (long)(i))));
            
            //#line 242 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_2 alloc$103206 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
            
            //#line 242 "x10/array/BlockingUtils.x10"
            final long t$104017 = is0.min$O((long)(0L));
            
            //#line 242 "x10/array/BlockingUtils.x10"
            final long t$104018 = is0.max$O((long)(0L));
            
            //#line 242 "x10/array/BlockingUtils.x10"
            alloc$103206.x10$array$DenseIterationSpace_2$$init$S(t$104017, ((long)(min1)), t$104018, ((long)(max1)));
            
            //#line 242 "x10/array/BlockingUtils.x10"
            return alloc$103206;
        }
        
        //#line 245 "x10/array/BlockingUtils.x10"
        final long t$103910 = ((size0) % (((long)(2L))));
        
        //#line 245 "x10/array/BlockingUtils.x10"
        final boolean t$103911 = ((long) t$103910) == ((long) 0L);
        
        //#line 245 "x10/array/BlockingUtils.x10"
        long t$103912 =  0;
        
        //#line 245 "x10/array/BlockingUtils.x10"
        if (t$103911) {
            
            //#line 245 "x10/array/BlockingUtils.x10"
            t$103912 = size0;
        } else {
            
            //#line 245 "x10/array/BlockingUtils.x10"
            t$103912 = ((size0) - (((long)(1L))));
        }
        
        //#line 246 "x10/array/BlockingUtils.x10"
        final long t$103913 = ((t$103912) * (((long)(size1))));
        
        //#line 246 "x10/array/BlockingUtils.x10"
        final long P = java.lang.Math.min(((long)(n)),((long)(t$103913)));
        
        //#line 247 "x10/array/BlockingUtils.x10"
        final boolean t$103915 = ((i) >= (((long)(P))));
        
        //#line 247 "x10/array/BlockingUtils.x10"
        if (t$103915) {
            
            //#line 247 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_2 t$103914 = ((x10.array.DenseIterationSpace_2)(x10.array.DenseIterationSpace_2.get$EMPTY()));
            
            //#line 247 "x10/array/BlockingUtils.x10"
            return t$103914;
        }
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final double t$103916 = ((double)(long)(((long)(P))));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final double t$103917 = java.lang.Math.log(((double)(t$103916)));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final double t$103918 = java.lang.Math.log(((double)(2.0)));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final double t$103919 = ((t$103917) / (((double)(t$103918))));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final double t$103920 = ((t$103919) / (((double)(2.0))));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final double t$103921 = java.lang.Math.ceil(((double)(t$103920)));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final long t$103922 = ((long)(double)(((double)(t$103921))));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final long t$103923 = x10.lang.Math.pow2$O((long)(t$103922));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final long divisions0 = java.lang.Math.min(((long)(t$103912)),((long)(t$103923)));
        
        //#line 250 "x10/array/BlockingUtils.x10"
        final double t$103924 = ((double)(long)(((long)(P))));
        
        //#line 250 "x10/array/BlockingUtils.x10"
        final double t$103925 = ((double)(long)(((long)(divisions0))));
        
        //#line 250 "x10/array/BlockingUtils.x10"
        final double t$103926 = ((t$103924) / (((double)(t$103925))));
        
        //#line 250 "x10/array/BlockingUtils.x10"
        final double t$103927 = java.lang.Math.ceil(((double)(t$103926)));
        
        //#line 250 "x10/array/BlockingUtils.x10"
        final long t$103928 = ((long)(double)(((double)(t$103927))));
        
        //#line 250 "x10/array/BlockingUtils.x10"
        final long divisions1 = java.lang.Math.min(((long)(size1)),((long)(t$103928)));
        
        //#line 251 "x10/array/BlockingUtils.x10"
        final long t$103929 = ((divisions0) * (((long)(divisions1))));
        
        //#line 251 "x10/array/BlockingUtils.x10"
        final long leftOver = ((t$103929) - (((long)(P))));
        
        //#line 252 "x10/array/BlockingUtils.x10"
        final long t$103930 = ((divisions0) % (((long)(2L))));
        
        //#line 252 "x10/array/BlockingUtils.x10"
        final boolean t$103933 = ((long) t$103930) == ((long) 0L);
        
        //#line 252 "x10/array/BlockingUtils.x10"
        long t$103934 =  0;
        
        //#line 252 "x10/array/BlockingUtils.x10"
        if (t$103933) {
            
            //#line 252 "x10/array/BlockingUtils.x10"
            t$103934 = 0L;
        } else {
            
            //#line 252 "x10/array/BlockingUtils.x10"
            final long t$103931 = ((i) * (((long)(2L))));
            
            //#line 252 "x10/array/BlockingUtils.x10"
            final long t$103932 = ((divisions0) + (((long)(1L))));
            
            //#line 252 "x10/array/BlockingUtils.x10"
            t$103934 = ((t$103931) / (((long)(t$103932))));
        }
        
        //#line 254 "x10/array/BlockingUtils.x10"
        final boolean t$103938 = ((i) < (((long)(leftOver))));
        
        //#line 254 "x10/array/BlockingUtils.x10"
        long t$103939 =  0;
        
        //#line 254 "x10/array/BlockingUtils.x10"
        if (t$103938) {
            
            //#line 254 "x10/array/BlockingUtils.x10"
            final long t$103935 = ((i) * (((long)(2L))));
            
            //#line 254 "x10/array/BlockingUtils.x10"
            final long t$103936 = ((t$103935) - (((long)(t$103934))));
            
            //#line 254 "x10/array/BlockingUtils.x10"
            t$103939 = ((t$103936) % (((long)(divisions0))));
        } else {
            
            //#line 254 "x10/array/BlockingUtils.x10"
            final long t$103937 = ((i) + (((long)(leftOver))));
            
            //#line 254 "x10/array/BlockingUtils.x10"
            t$103939 = ((t$103937) % (((long)(divisions0))));
        }
        
        //#line 255 "x10/array/BlockingUtils.x10"
        final boolean t$103942 = ((i) < (((long)(leftOver))));
        
        //#line 255 "x10/array/BlockingUtils.x10"
        long t$103943 =  0;
        
        //#line 255 "x10/array/BlockingUtils.x10"
        if (t$103942) {
            
            //#line 255 "x10/array/BlockingUtils.x10"
            final long t$103940 = ((i) * (((long)(2L))));
            
            //#line 255 "x10/array/BlockingUtils.x10"
            t$103943 = ((t$103940) / (((long)(divisions0))));
        } else {
            
            //#line 255 "x10/array/BlockingUtils.x10"
            final long t$103941 = ((i) + (((long)(leftOver))));
            
            //#line 255 "x10/array/BlockingUtils.x10"
            t$103943 = ((t$103941) / (((long)(divisions0))));
        }
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final long t$103944 = ((t$103939) * (((long)(size0))));
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final double t$103945 = ((double)(long)(((long)(t$103944))));
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final double t$103946 = ((double)(long)(((long)(divisions0))));
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final double t$103947 = ((t$103945) / (((double)(t$103946))));
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final double t$103948 = java.lang.Math.ceil(((double)(t$103947)));
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final long t$103949 = ((long)(double)(((double)(t$103948))));
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final long low0 = ((min0) + (((long)(t$103949))));
        
        //#line 258 "x10/array/BlockingUtils.x10"
        final boolean t$103950 = ((i) < (((long)(leftOver))));
        
        //#line 258 "x10/array/BlockingUtils.x10"
        long t$103951 =  0;
        
        //#line 258 "x10/array/BlockingUtils.x10"
        if (t$103950) {
            
            //#line 258 "x10/array/BlockingUtils.x10"
            t$103951 = 2L;
        } else {
            
            //#line 258 "x10/array/BlockingUtils.x10"
            t$103951 = 1L;
        }
        
        //#line 258 "x10/array/BlockingUtils.x10"
        final long blockHi0 = ((t$103939) + (((long)(t$103951))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final long t$103953 = ((blockHi0) * (((long)(size0))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final double t$103954 = ((double)(long)(((long)(t$103953))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final double t$103955 = ((double)(long)(((long)(divisions0))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final double t$103956 = ((t$103954) / (((double)(t$103955))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final double t$103957 = java.lang.Math.ceil(((double)(t$103956)));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final long t$103958 = ((long)(double)(((double)(t$103957))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final long t$103959 = ((min0) + (((long)(t$103958))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final long hi0 = ((t$103959) - (((long)(1L))));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final long t$103960 = ((t$103943) * (((long)(size1))));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final double t$103961 = ((double)(long)(((long)(t$103960))));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final double t$103962 = ((double)(long)(((long)(divisions1))));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final double t$103963 = ((t$103961) / (((double)(t$103962))));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final double t$103964 = java.lang.Math.ceil(((double)(t$103963)));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final long t$103965 = ((long)(double)(((double)(t$103964))));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final long low1 = ((min1) + (((long)(t$103965))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final long t$103966 = ((t$103943) + (((long)(1L))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final long t$103967 = ((t$103966) * (((long)(size1))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final double t$103968 = ((double)(long)(((long)(t$103967))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final double t$103969 = ((double)(long)(((long)(divisions1))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final double t$103970 = ((t$103968) / (((double)(t$103969))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final double t$103971 = java.lang.Math.ceil(((double)(t$103970)));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final long t$103972 = ((long)(double)(((double)(t$103971))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final long t$103973 = ((min1) + (((long)(t$103972))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final long hi1 = ((t$103973) - (((long)(1L))));
        
        //#line 264 "x10/array/BlockingUtils.x10"
        final x10.array.DenseIterationSpace_2 alloc$103207 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 264 "x10/array/BlockingUtils.x10"
        alloc$103207.x10$array$DenseIterationSpace_2$$init$S(((long)(low0)), ((long)(low1)), ((long)(hi0)), ((long)(hi1)));
        
        //#line 264 "x10/array/BlockingUtils.x10"
        return alloc$103207;
    }
    
    
    //#line 287 "x10/array/BlockingUtils.x10"
    /**
     * A BlockBlock distribution takes a rank-2 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units in 2-d grid.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes which partition an argument index would be placed.
     *
     * @param is the iteration space to partition
     * @param n is the total number of partitions desired
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the partition number into which (i,j) is mapped by the distribution
     *         (or -1 if not contained in the bounding box of the argument iteration space)
     */
    public static long mapIndexToBlockBlockPartition$O(final x10.array.IterationSpace is, final long n, final long i, final long j) {
        
        //#line 288 "x10/array/BlockingUtils.x10"
        final long min0 = is.min$O((long)(0L));
        
        //#line 289 "x10/array/BlockingUtils.x10"
        final long max0 = is.max$O((long)(0L));
        
        //#line 290 "x10/array/BlockingUtils.x10"
        final long min1 = is.min$O((long)(1L));
        
        //#line 291 "x10/array/BlockingUtils.x10"
        final long max1 = is.max$O((long)(1L));
        
        //#line 292 "x10/array/BlockingUtils.x10"
        final long t$103974 = x10.array.BlockingUtils.mapIndexToBlockBlockPartition$O((long)(min0), (long)(min1), (long)(max0), (long)(max1), (long)(n), (long)(i), (long)(j));
        
        //#line 292 "x10/array/BlockingUtils.x10"
        return t$103974;
    }
    
    
    //#line 318 "x10/array/BlockingUtils.x10"
    /**
     * A BlockBlock distribution takes a rank-2 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units in 2-d grid.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes which partition an argument index would be placed.
     *
     * param min0 is the min index of the first dimension
     * param min1 is the min index of the second dimension
     * param max0 is the max index of the first dimension
     * param max1 is the max index of the second dimension
     * @param n is the total number of partitions desired
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the partition number into which (i,j) is mapped by the distribution
     *         (or -1 if not contained in the bounding box of the argument iteration space)
     */
    public static long mapIndexToBlockBlockPartition$O(final long min0, final long min1, final long max0, final long max1, final long n, final long i, final long j) {
        
        //#line 320 "x10/array/BlockingUtils.x10"
        boolean t$103975 = ((i) < (((long)(min0))));
        
        //#line 320 "x10/array/BlockingUtils.x10"
        if (!(t$103975)) {
            
            //#line 320 "x10/array/BlockingUtils.x10"
            t$103975 = ((i) > (((long)(max0))));
        }
        
        //#line 320 "x10/array/BlockingUtils.x10"
        boolean t$103976 = t$103975;
        
        //#line 320 "x10/array/BlockingUtils.x10"
        if (!(t$103975)) {
            
            //#line 320 "x10/array/BlockingUtils.x10"
            t$103976 = ((j) < (((long)(min1))));
        }
        
        //#line 320 "x10/array/BlockingUtils.x10"
        boolean t$103977 = t$103976;
        
        //#line 320 "x10/array/BlockingUtils.x10"
        if (!(t$103976)) {
            
            //#line 320 "x10/array/BlockingUtils.x10"
            t$103977 = ((j) > (((long)(max1))));
        }
        
        //#line 320 "x10/array/BlockingUtils.x10"
        if (t$103977) {
            
            //#line 320 "x10/array/BlockingUtils.x10"
            return -1L;
        }
        
        //#line 322 "x10/array/BlockingUtils.x10"
        final long t$103979 = ((max0) - (((long)(min0))));
        
        //#line 322 "x10/array/BlockingUtils.x10"
        final long size0 = ((t$103979) + (((long)(1L))));
        
        //#line 323 "x10/array/BlockingUtils.x10"
        final long t$103980 = ((max1) - (((long)(min1))));
        
        //#line 323 "x10/array/BlockingUtils.x10"
        final long size1 = ((t$103980) + (((long)(1L))));
        
        //#line 325 "x10/array/BlockingUtils.x10"
        final boolean t$103982 = ((long) size0) == ((long) 1L);
        
        //#line 325 "x10/array/BlockingUtils.x10"
        if (t$103982) {
            
            //#line 326 "x10/array/BlockingUtils.x10"
            final long t$103981 = x10.array.BlockingUtils.mapIndexToBlockPartition$O((long)(min1), (long)(max1), (long)(n), (long)(j));
            
            //#line 326 "x10/array/BlockingUtils.x10"
            return t$103981;
        }
        
        //#line 328 "x10/array/BlockingUtils.x10"
        final boolean t$103984 = ((long) size1) == ((long) 1L);
        
        //#line 328 "x10/array/BlockingUtils.x10"
        if (t$103984) {
            
            //#line 329 "x10/array/BlockingUtils.x10"
            final long t$103983 = x10.array.BlockingUtils.mapIndexToBlockPartition$O((long)(min0), (long)(max0), (long)(n), (long)(i));
            
            //#line 329 "x10/array/BlockingUtils.x10"
            return t$103983;
        }
        
        //#line 332 "x10/array/BlockingUtils.x10"
        final long t$103985 = ((size0) % (((long)(2L))));
        
        //#line 332 "x10/array/BlockingUtils.x10"
        final boolean t$103986 = ((long) t$103985) == ((long) 0L);
        
        //#line 332 "x10/array/BlockingUtils.x10"
        long t$103987 =  0;
        
        //#line 332 "x10/array/BlockingUtils.x10"
        if (t$103986) {
            
            //#line 332 "x10/array/BlockingUtils.x10"
            t$103987 = size0;
        } else {
            
            //#line 332 "x10/array/BlockingUtils.x10"
            t$103987 = ((size0) - (((long)(1L))));
        }
        
        //#line 333 "x10/array/BlockingUtils.x10"
        final long t$103988 = ((t$103987) * (((long)(size1))));
        
        //#line 333 "x10/array/BlockingUtils.x10"
        final long P = java.lang.Math.min(((long)(n)),((long)(t$103988)));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final double t$103989 = ((double)(long)(((long)(P))));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final double t$103990 = java.lang.Math.log(((double)(t$103989)));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final double t$103991 = java.lang.Math.log(((double)(2.0)));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final double t$103992 = ((t$103990) / (((double)(t$103991))));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final double t$103993 = ((t$103992) / (((double)(2.0))));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final double t$103994 = java.lang.Math.ceil(((double)(t$103993)));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final long t$103995 = ((long)(double)(((double)(t$103994))));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final long t$103996 = x10.lang.Math.pow2$O((long)(t$103995));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final long divisions0 = java.lang.Math.min(((long)(t$103987)),((long)(t$103996)));
        
        //#line 335 "x10/array/BlockingUtils.x10"
        final double t$103997 = ((double)(long)(((long)(P))));
        
        //#line 335 "x10/array/BlockingUtils.x10"
        final double t$103998 = ((double)(long)(((long)(divisions0))));
        
        //#line 335 "x10/array/BlockingUtils.x10"
        final double t$103999 = ((t$103997) / (((double)(t$103998))));
        
        //#line 335 "x10/array/BlockingUtils.x10"
        final double t$104000 = java.lang.Math.ceil(((double)(t$103999)));
        
        //#line 335 "x10/array/BlockingUtils.x10"
        final long t$104001 = ((long)(double)(((double)(t$104000))));
        
        //#line 335 "x10/array/BlockingUtils.x10"
        final long divisions1 = java.lang.Math.min(((long)(size1)),((long)(t$104001)));
        
        //#line 336 "x10/array/BlockingUtils.x10"
        final long numBlocks = ((divisions0) * (((long)(divisions1))));
        
        //#line 337 "x10/array/BlockingUtils.x10"
        final long leftOver = ((numBlocks) - (((long)(P))));
        
        //#line 339 "x10/array/BlockingUtils.x10"
        final boolean t$104004 = ((long) divisions0) == ((long) 1L);
        
        //#line 339 "x10/array/BlockingUtils.x10"
        long t$104005 =  0;
        
        //#line 339 "x10/array/BlockingUtils.x10"
        if (t$104004) {
            
            //#line 339 "x10/array/BlockingUtils.x10"
            t$104005 = 0L;
        } else {
            
            //#line 339 "x10/array/BlockingUtils.x10"
            final long t$104002 = ((i) - (((long)(min0))));
            
            //#line 339 "x10/array/BlockingUtils.x10"
            final long t$104003 = ((t$104002) * (((long)(divisions0))));
            
            //#line 339 "x10/array/BlockingUtils.x10"
            t$104005 = ((t$104003) / (((long)(size0))));
        }
        
        //#line 340 "x10/array/BlockingUtils.x10"
        final boolean t$104008 = ((long) divisions1) == ((long) 1L);
        
        //#line 340 "x10/array/BlockingUtils.x10"
        long t$104009 =  0;
        
        //#line 340 "x10/array/BlockingUtils.x10"
        if (t$104008) {
            
            //#line 340 "x10/array/BlockingUtils.x10"
            t$104009 = 0L;
        } else {
            
            //#line 340 "x10/array/BlockingUtils.x10"
            final long t$104006 = ((j) - (((long)(min1))));
            
            //#line 340 "x10/array/BlockingUtils.x10"
            final long t$104007 = ((t$104006) * (((long)(divisions1))));
            
            //#line 340 "x10/array/BlockingUtils.x10"
            t$104009 = ((t$104007) / (((long)(size1))));
        }
        
        //#line 341 "x10/array/BlockingUtils.x10"
        final long t$104010 = ((t$104009) * (((long)(divisions0))));
        
        //#line 341 "x10/array/BlockingUtils.x10"
        final long blockIndex = ((t$104010) + (((long)(t$104005))));
        
        //#line 343 "x10/array/BlockingUtils.x10"
        final long t$104011 = ((leftOver) * (((long)(2L))));
        
        //#line 343 "x10/array/BlockingUtils.x10"
        final boolean t$104014 = ((blockIndex) <= (((long)(t$104011))));
        
        //#line 343 "x10/array/BlockingUtils.x10"
        if (t$104014) {
            
            //#line 344 "x10/array/BlockingUtils.x10"
            final long t$104012 = ((blockIndex) / (((long)(2L))));
            
            //#line 344 "x10/array/BlockingUtils.x10"
            return t$104012;
        } else {
            
            //#line 346 "x10/array/BlockingUtils.x10"
            final long t$104013 = ((blockIndex) - (((long)(leftOver))));
            
            //#line 346 "x10/array/BlockingUtils.x10"
            return t$104013;
        }
    }
    
    
    //#line 21 "x10/array/BlockingUtils.x10"
    final public x10.array.BlockingUtils x10$array$BlockingUtils$$this$x10$array$BlockingUtils() {
        
        //#line 21 "x10/array/BlockingUtils.x10"
        return x10.array.BlockingUtils.this;
    }
    
    
    //#line 21 "x10/array/BlockingUtils.x10"
    // creation method for java code (1-phase java constructor)
    public BlockingUtils() {
        this((java.lang.System[]) null);
        x10$array$BlockingUtils$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.array.BlockingUtils x10$array$BlockingUtils$$init$S() {
         {
            
            //#line 21 "x10/array/BlockingUtils.x10"
            
        }
        return this;
    }
    
    
    
    //#line 21 "x10/array/BlockingUtils.x10"
    final public void __fieldInitializers_x10_array_BlockingUtils() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$0 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$0> $RTT = 
            x10.rtt.StaticFunType.<$Closure$0> make($Closure$0.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.array.DenseIterationSpace_1.$RTT)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.BlockingUtils.$Closure$0 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.is = $deserializer.readObject();
            $_obj.n = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.BlockingUtils.$Closure$0 $_obj = new x10.array.BlockingUtils.$Closure$0((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.is);
            $serializer.write(this.n);
            
        }
        
        // constructor just for allocation
        public $Closure$0(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.array.DenseIterationSpace_1 $apply(final long i) {
            
            //#line 44 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_1 t$103864 = ((x10.array.DenseIterationSpace_1)(x10.array.BlockingUtils.partitionBlock(((x10.array.IterationSpace)(this.is)), (long)(this.n), (long)(i))));
            
            //#line 44 "x10/array/BlockingUtils.x10"
            return t$103864;
        }
        
        public x10.array.IterationSpace is;
        public long n;
        
        public $Closure$0(final x10.array.IterationSpace is, final long n) {
             {
                this.is = ((x10.array.IterationSpace)(is));
                this.n = n;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$1 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$1> $RTT = 
            x10.rtt.StaticFunType.<$Closure$1> make($Closure$1.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.array.DenseIterationSpace_2.$RTT)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.BlockingUtils.$Closure$1 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.is = $deserializer.readObject();
            $_obj.n = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.BlockingUtils.$Closure$1 $_obj = new x10.array.BlockingUtils.$Closure$1((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.is);
            $serializer.write(this.n);
            
        }
        
        // constructor just for allocation
        public $Closure$1(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.array.DenseIterationSpace_2 $apply(final long i) {
            
            //#line 180 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_2 t$103895 = ((x10.array.DenseIterationSpace_2)(x10.array.BlockingUtils.partitionBlockBlock(((x10.array.IterationSpace)(this.is)), (long)(this.n), (long)(i))));
            
            //#line 180 "x10/array/BlockingUtils.x10"
            return t$103895;
        }
        
        public x10.array.IterationSpace is;
        public long n;
        
        public $Closure$1(final x10.array.IterationSpace is, final long n) {
             {
                this.is = ((x10.array.IterationSpace)(is));
                this.n = n;
            }
        }
        
    }
    
}

