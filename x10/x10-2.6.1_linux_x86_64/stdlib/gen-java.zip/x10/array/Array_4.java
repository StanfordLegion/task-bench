package x10.array;


/**
 * Implementation of 4-dimensional Array using row-major ordering.
 */
@x10.runtime.impl.java.X10Generated
final public class Array_4<$T> extends x10.array.Array<$T> implements x10.core.fun.Fun_0_4, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Array_4> $RTT = 
        x10.rtt.NamedType.<Array_4> make("x10.array.Array_4",
                                         Array_4.class,
                                         1,
                                         new x10.rtt.Type[] {
                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_4.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                             x10.rtt.ParameterizedType.make(x10.array.Array.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.Array_4<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        $_obj.numElems_3 = $deserializer.readLong();
        $_obj.numElems_4 = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array_4 $_obj = new x10.array.Array_4((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        $serializer.write(this.numElems_3);
        $serializer.write(this.numElems_4);
        
    }
    
    // constructor just for allocation
    public Array_4(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.Array_4.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>U.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4));
        
    }
    
    // bridge for method abstract public x10.array.Array[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.Array).rank()}, v:T){}:T{self==v}
    public $T $set__1x10$array$Array$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$Array_4$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final Array_4 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __4x10$array$Array_4$$T {}
    // synthetic type for parameter mangling
    public static final class __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_4$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __0$1x10$array$Array_4$$T$2 {}
    
    // properties
    
    //#line 25 "x10/array/Array_4.x10"
    /**
         * The number of elements in rank 1 (indexed 0..(numElems_1-1))
         */
    public long numElems_1;
    
    //#line 30 "x10/array/Array_4.x10"
    /**
         * The number of elements in rank 2 (indexed 0..(numElems_2-1)).
         */
    public long numElems_2;
    
    //#line 35 "x10/array/Array_4.x10"
    /**
         * The number of elements in rank 3 (indexed 0..(numElems_3-1)).
         */
    public long numElems_3;
    
    //#line 40 "x10/array/Array_4.x10"
    /**
         * The number of elements in rank 4 (indexed 0..(numElems_4-1)).
         */
    public long numElems_4;
    

    
    
    //#line 46 "x10/array/Array_4.x10"
    /**
     * @return the rank (dimensionality) of the Array
     */
    final public long rank$O() {
        
        //#line 46 "x10/array/Array_4.x10"
        return 4L;
    }
    
    
    //#line 52 "x10/array/Array_4.x10"
    /**
     * Construct a 4-dimensional array with indices [0..m-1][0..n-1][0..p-1][0..q-1]
     * whose elements are zero-initialized.
     */
    // creation method for java code (1-phase java constructor)
    public Array_4(final x10.rtt.Type $T, final long m, final long n, final long p, final long q) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_4$$init$S(m, n, p, q);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_4<$T> x10$array$Array_4$$init$S(final long m, final long n, final long p, final long q) {
         {
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102341 = ((m) < (((long)(0L))));
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102341)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102341 = ((n) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102342 = t$102341;
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102341)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102342 = ((p) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102343 = t$102342;
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102342)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102343 = ((q) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            if (t$102343) {
                
                //#line 228 . "x10/array/Array_4.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102345 = ((m) * (((long)(n))));
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102346 = ((t$102345) * (((long)(p))));
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102347 = ((t$102346) * (((long)(q))));
            
            //#line 53 "x10/array/Array_4.x10"
            /*super.*/x10$array$Array$$init$S(t$102347, ((boolean)(true)));
            
            //#line 54 "x10/array/Array_4.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            this.numElems_4 = q;
            
        }
        return this;
    }
    
    
    
    //#line 61 "x10/array/Array_4.x10"
    /**
     * Construct a 4-dimensional array with indices [0..m-1][0..n-1][0..p-1][0..q-1]
     * whose elements are initialized to init.
     */
    // creation method for java code (1-phase java constructor)
    public Array_4(final x10.rtt.Type $T, final long m, final long n, final long p, final long q, final $T init, __4x10$array$Array_4$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_4$$init$S(m, n, p, q, init, (x10.array.Array_4.__4x10$array$Array_4$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_4<$T> x10$array$Array_4$$init$S(final long m, final long n, final long p, final long q, final $T init, __4x10$array$Array_4$$T $dummy) {
         {
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102353 = ((m) < (((long)(0L))));
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102353)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102353 = ((n) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102354 = t$102353;
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102353)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102354 = ((p) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102355 = t$102354;
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102354)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102355 = ((q) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            if (t$102355) {
                
                //#line 228 . "x10/array/Array_4.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102357 = ((m) * (((long)(n))));
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102358 = ((t$102357) * (((long)(p))));
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102359 = ((t$102358) * (((long)(q))));
            
            //#line 62 "x10/array/Array_4.x10"
            /*super.*/x10$array$Array$$init$S(t$102359, ((boolean)(false)));
            
            //#line 63 "x10/array/Array_4.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            this.numElems_4 = q;
            
            
            //#line 64 "x10/array/Array_4.x10"
            final x10.core.Rail t$102102 = ((x10.core.Rail)(this.raw));
            
            //#line 64 "x10/array/Array_4.x10"
            ((x10.core.Rail<$T>)t$102102).fill__0x10$lang$Rail$$T((($T)(init)));
        }
        return this;
    }
    
    
    
    //#line 71 "x10/array/Array_4.x10"
    /**
     * Construct a 4-dimensional array with indices [0..m-1][0..n-1][0..p-1][0..q-1]
     * whose elements are initialized to the value returned by the init closure for each index.
     */
    // creation method for java code (1-phase java constructor)
    public Array_4(final x10.rtt.Type $T, final long m, final long n, final long p, final long q, final x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_4$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_4$$init$S(m, n, p, q, init, (x10.array.Array_4.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_4$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_4<$T> x10$array$Array_4$$init$S(final long m, final long n, final long p, final long q, final x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_4$$T$2 $dummy) {
         {
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102408 = ((m) < (((long)(0L))));
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102408)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102408 = ((n) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102409 = t$102408;
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102408)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102409 = ((p) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102410 = t$102409;
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102409)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102410 = ((q) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            if (t$102410) {
                
                //#line 228 . "x10/array/Array_4.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102412 = ((m) * (((long)(n))));
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102413 = ((t$102412) * (((long)(p))));
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102414 = ((t$102413) * (((long)(q))));
            
            //#line 72 "x10/array/Array_4.x10"
            /*super.*/x10$array$Array$$init$S(t$102414, ((boolean)(false)));
            
            //#line 73 "x10/array/Array_4.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            this.numElems_4 = q;
            
            
            //#line 74 "x10/array/Array_4.x10"
            final long i$101331max$102416 = ((m) - (((long)(1L))));
            
            //#line 74 "x10/array/Array_4.x10"
            long i$102401 = 0L;
            
            //#line 74 "x10/array/Array_4.x10"
            for (;
                 true;
                 ) {
                
                //#line 74 "x10/array/Array_4.x10"
                final boolean t$102403 = ((i$102401) <= (((long)(i$101331max$102416))));
                
                //#line 74 "x10/array/Array_4.x10"
                if (!(t$102403)) {
                    
                    //#line 74 "x10/array/Array_4.x10"
                    break;
                }
                
                //#line 75 "x10/array/Array_4.x10"
                final long i$101313max$102397 = ((n) - (((long)(1L))));
                
                //#line 75 "x10/array/Array_4.x10"
                long i$102394 = 0L;
                
                //#line 75 "x10/array/Array_4.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 75 "x10/array/Array_4.x10"
                    final boolean t$102396 = ((i$102394) <= (((long)(i$101313max$102397))));
                    
                    //#line 75 "x10/array/Array_4.x10"
                    if (!(t$102396)) {
                        
                        //#line 75 "x10/array/Array_4.x10"
                        break;
                    }
                    
                    //#line 76 "x10/array/Array_4.x10"
                    final long i$101295max$102390 = ((p) - (((long)(1L))));
                    
                    //#line 76 "x10/array/Array_4.x10"
                    long i$102387 = 0L;
                    
                    //#line 76 "x10/array/Array_4.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 76 "x10/array/Array_4.x10"
                        final boolean t$102389 = ((i$102387) <= (((long)(i$101295max$102390))));
                        
                        //#line 76 "x10/array/Array_4.x10"
                        if (!(t$102389)) {
                            
                            //#line 76 "x10/array/Array_4.x10"
                            break;
                        }
                        
                        //#line 77 "x10/array/Array_4.x10"
                        final long i$101277max$102383 = ((q) - (((long)(1L))));
                        
                        //#line 77 "x10/array/Array_4.x10"
                        long i$102380 = 0L;
                        
                        //#line 77 "x10/array/Array_4.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 77 "x10/array/Array_4.x10"
                            final boolean t$102382 = ((i$102380) <= (((long)(i$101277max$102383))));
                            
                            //#line 77 "x10/array/Array_4.x10"
                            if (!(t$102382)) {
                                
                                //#line 77 "x10/array/Array_4.x10"
                                break;
                            }
                            
                            //#line 78 "x10/array/Array_4.x10"
                            final x10.core.Rail t$102361 = ((x10.core.Rail)(this.raw));
                            
                            //#line 78 "x10/array/Array_4.x10"
                            final x10.array.Array_4 this$102362 = ((x10.array.Array_4)(this));
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102367 = ((x10.array.Array_4<$T>)this$102362).numElems_4;
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102368 = ((x10.array.Array_4<$T>)this$102362).numElems_3;
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102369 = ((x10.array.Array_4<$T>)this$102362).numElems_2;
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102370 = ((i$102401) * (((long)(t$102369))));
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102371 = ((i$102394) + (((long)(t$102370))));
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102372 = ((t$102368) * (((long)(t$102371))));
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102373 = ((i$102387) + (((long)(t$102372))));
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102374 = ((t$102367) * (((long)(t$102373))));
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102375 = ((i$102380) + (((long)(t$102374))));
                            
                            //#line 78 "x10/array/Array_4.x10"
                            final $T t$102376 = (($T)((($T)
                                                        ((x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T>)init).$apply(x10.core.Long.$box(i$102401), x10.rtt.Types.LONG, x10.core.Long.$box(i$102394), x10.rtt.Types.LONG, x10.core.Long.$box(i$102387), x10.rtt.Types.LONG, x10.core.Long.$box(i$102380), x10.rtt.Types.LONG))));
                            
                            //#line 78 "x10/array/Array_4.x10"
                            ((x10.core.Rail<$T>)t$102361).$set__1x10$lang$Rail$$T$G((long)(t$102375), (($T)(t$102376)));
                            
                            //#line 77 "x10/array/Array_4.x10"
                            final long t$102379 = ((i$102380) + (((long)(1L))));
                            
                            //#line 77 "x10/array/Array_4.x10"
                            i$102380 = t$102379;
                        }
                        
                        //#line 76 "x10/array/Array_4.x10"
                        final long t$102386 = ((i$102387) + (((long)(1L))));
                        
                        //#line 76 "x10/array/Array_4.x10"
                        i$102387 = t$102386;
                    }
                    
                    //#line 75 "x10/array/Array_4.x10"
                    final long t$102393 = ((i$102394) + (((long)(1L))));
                    
                    //#line 75 "x10/array/Array_4.x10"
                    i$102394 = t$102393;
                }
                
                //#line 74 "x10/array/Array_4.x10"
                final long t$102400 = ((i$102401) + (((long)(1L))));
                
                //#line 74 "x10/array/Array_4.x10"
                i$102401 = t$102400;
            }
        }
        return this;
    }
    
    
    
    //#line 89 "x10/array/Array_4.x10"
    /**
     * Construct a new 4-dimensional array by copying all elements of src
     * @param src The source array to copy
     */
    // creation method for java code (1-phase java constructor)
    public Array_4(final x10.rtt.Type $T, final x10.array.Array_4<$T> src, __0$1x10$array$Array_4$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_4$$init$S(src, (x10.array.Array_4.__0$1x10$array$Array_4$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_4<$T> x10$array$Array_4$$init$S(final x10.array.Array_4<$T> src, __0$1x10$array$Array_4$$T$2 $dummy) {
         {
            
            //#line 90 "x10/array/Array_4.x10"
            final x10.array.Array this$101448 = ((x10.array.Array)(this));
            
            //#line 90 "x10/array/Array_4.x10"
            final x10.core.Rail t$102141 = ((x10.core.Rail)(((x10.array.Array<$T>)src).raw));
            
            //#line 90 "x10/array/Array_4.x10"
            final x10.core.Rail r$101447 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((x10.core.Rail)(t$102141)), (x10.core.Rail.__0$1x10$lang$Rail$$T$2) null)));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$102417 = ((x10.core.Rail<$T>)r$101447).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$101448).size = t$102417;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$101448).raw = ((x10.core.Rail)(r$101447));
            
            //#line 91 "x10/array/Array_4.x10"
            final long t$102418 = ((x10.array.Array_4<$T>)src).numElems_1;
            
            //#line 91 "x10/array/Array_4.x10"
            final long t$102419 = ((x10.array.Array_4<$T>)src).numElems_2;
            
            //#line 91 "x10/array/Array_4.x10"
            final long t$102420 = ((x10.array.Array_4<$T>)src).numElems_3;
            
            //#line 91 "x10/array/Array_4.x10"
            final long t$102421 = ((x10.array.Array_4<$T>)src).numElems_4;
            
            //#line 91 "x10/array/Array_4.x10"
            this.numElems_1 = t$102418;
            this.numElems_2 = t$102419;
            this.numElems_3 = t$102420;
            this.numElems_4 = t$102421;
            
        }
        return this;
    }
    
    
    
    //#line 95 "x10/array/Array_4.x10"
    // creation method for java code (1-phase java constructor)
    public Array_4(final x10.rtt.Type $T, final x10.core.Rail<$T> r, final long m, final long n, final long p, final long q, __0$1x10$array$Array_4$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_4$$init$S(r, m, n, p, q, (x10.array.Array_4.__0$1x10$array$Array_4$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_4<$T> x10$array$Array_4$$init$S(final x10.core.Rail<$T> r, final long m, final long n, final long p, final long q, __0$1x10$array$Array_4$$T$2 $dummy) {
         {
            
            //#line 96 "x10/array/Array_4.x10"
            final x10.array.Array this$101454 = ((x10.array.Array)(this));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$102423 = ((x10.core.Rail<$T>)r).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$101454).size = t$102423;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$101454).raw = ((x10.core.Rail)(r));
            
            //#line 97 "x10/array/Array_4.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            this.numElems_4 = q;
            
        }
        return this;
    }
    
    
    
    //#line 103 "x10/array/Array_4.x10"
    /**
     * Construct an Array_4 view over an existing Rail
     */
    public static <$T>x10.array.Array_4 makeView__0$1x10$array$Array_4$$T$2(final x10.rtt.Type $T, final x10.core.Rail<$T> r, final long m, final long n, final long p, final long q) {
        
        //#line 104 "x10/array/Array_4.x10"
        final long t$102148 = ((n) * (((long)(m))));
        
        //#line 104 "x10/array/Array_4.x10"
        final long t$102149 = ((t$102148) * (((long)(p))));
        
        //#line 104 "x10/array/Array_4.x10"
        final long size = ((t$102149) * (((long)(q))));
        
        //#line 105 "x10/array/Array_4.x10"
        final long t$102150 = ((x10.core.Rail<$T>)r).size;
        
        //#line 105 "x10/array/Array_4.x10"
        final boolean t$102162 = ((long) size) != ((long) t$102150);
        
        //#line 105 "x10/array/Array_4.x10"
        if (t$102162) {
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102151 = (("size mismatch: ") + ((x10.core.Long.$box(m))));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102152 = ((t$102151) + (" * "));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102153 = ((t$102152) + ((x10.core.Long.$box(n))));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102154 = ((t$102153) + (" * "));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102155 = ((t$102154) + ((x10.core.Long.$box(p))));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102156 = ((t$102155) + (" * "));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102157 = ((t$102156) + ((x10.core.Long.$box(q))));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102158 = ((t$102157) + (" != "));
            
            //#line 105 "x10/array/Array_4.x10"
            final long t$102159 = ((x10.core.Rail<$T>)r).size;
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102160 = ((t$102158) + ((x10.core.Long.$box(t$102159))));
            
            //#line 105 "x10/array/Array_4.x10"
            final x10.lang.IllegalOperationException t$102161 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$102160)));
            
            //#line 105 "x10/array/Array_4.x10"
            throw t$102161;
        }
        
        //#line 106 "x10/array/Array_4.x10"
        final x10.array.Array_4 alloc$101274 = ((x10.array.Array_4)(new x10.array.Array_4<$T>((java.lang.System[]) null, $T)));
        
        //#line 106 "x10/array/Array_4.x10"
        alloc$101274.x10$array$Array_4$$init$S(((x10.core.Rail)(r)), ((long)(m)), ((long)(n)), ((long)(p)), ((long)(q)), (x10.array.Array_4.__0$1x10$array$Array_4$$T$2) null);
        
        //#line 106 "x10/array/Array_4.x10"
        return alloc$101274;
    }
    
    
    //#line 115 "x10/array/Array_4.x10"
    /**
     * Return the string representation of this array.
     * 
     * @return the string representation of this array.
     */
    public java.lang.String toString() {
        
        //#line 116 "x10/array/Array_4.x10"
        final java.lang.String t$102163 = this.toString((long)(10L));
        
        //#line 116 "x10/array/Array_4.x10"
        return t$102163;
    }
    
    
    //#line 125 "x10/array/Array_4.x10"
    /**
     * Return the string representation of this array.
     *
     * @param limit maximum number of elements to print
     * @return the string representation of this array.
     */
    public java.lang.String toString(final long limit) {
        
        //#line 126 "x10/array/Array_4.x10"
        final x10.util.StringBuilder sb = ((x10.util.StringBuilder)(new x10.util.StringBuilder((java.lang.System[]) null)));
        
        //#line 126 "x10/array/Array_4.x10"
        sb.x10$util$StringBuilder$$init$S();
        
        //#line 127 "x10/array/Array_4.x10"
        sb.add(((java.lang.String)("[")));
        
        //#line 128 "x10/array/Array_4.x10"
        long printed = 0L;
        
        //#line 129 "x10/array/Array_4.x10"
        final long t$102503 = this.numElems_1;
        
        //#line 129 "x10/array/Array_4.x10"
        final long i$101403max$102504 = ((t$102503) - (((long)(1L))));
        
        //#line 129 "x10/array/Array_4.x10"
        long i$102499 = 0L;
        
        //#line 129 "x10/array/Array_4.x10"
        outer$102500: 
        //#line 129 "x10/array/Array_4.x10"
        for (;
             true;
             ) {
            
            //#line 129 "x10/array/Array_4.x10"
            final boolean t$102502 = ((i$102499) <= (((long)(i$101403max$102504))));
            
            //#line 129 "x10/array/Array_4.x10"
            if (!(t$102502)) {
                
                //#line 129 "x10/array/Array_4.x10"
                break;
            }
            
            //#line 130 "x10/array/Array_4.x10"
            final long t$102494 = this.numElems_2;
            
            //#line 130 "x10/array/Array_4.x10"
            final long i$101385max$102495 = ((t$102494) - (((long)(1L))));
            
            //#line 130 "x10/array/Array_4.x10"
            long i$102491 = 0L;
            
            //#line 130 "x10/array/Array_4.x10"
            for (;
                 true;
                 ) {
                
                //#line 130 "x10/array/Array_4.x10"
                final boolean t$102493 = ((i$102491) <= (((long)(i$101385max$102495))));
                
                //#line 130 "x10/array/Array_4.x10"
                if (!(t$102493)) {
                    
                    //#line 130 "x10/array/Array_4.x10"
                    break;
                }
                
                //#line 131 "x10/array/Array_4.x10"
                final long t$102481 = this.numElems_3;
                
                //#line 131 "x10/array/Array_4.x10"
                final long i$101367max$102482 = ((t$102481) - (((long)(1L))));
                
                //#line 131 "x10/array/Array_4.x10"
                long i$102478 = 0L;
                
                //#line 131 "x10/array/Array_4.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 131 "x10/array/Array_4.x10"
                    final boolean t$102480 = ((i$102478) <= (((long)(i$101367max$102482))));
                    
                    //#line 131 "x10/array/Array_4.x10"
                    if (!(t$102480)) {
                        
                        //#line 131 "x10/array/Array_4.x10"
                        break;
                    }
                    
                    //#line 132 "x10/array/Array_4.x10"
                    final long t$102468 = this.numElems_4;
                    
                    //#line 132 "x10/array/Array_4.x10"
                    final long i$101349max$102469 = ((t$102468) - (((long)(1L))));
                    
                    //#line 132 "x10/array/Array_4.x10"
                    long i$102465 = 0L;
                    
                    //#line 132 "x10/array/Array_4.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 132 "x10/array/Array_4.x10"
                        final boolean t$102467 = ((i$102465) <= (((long)(i$101349max$102469))));
                        
                        //#line 132 "x10/array/Array_4.x10"
                        if (!(t$102467)) {
                            
                            //#line 132 "x10/array/Array_4.x10"
                            break;
                        }
                        
                        //#line 133 "x10/array/Array_4.x10"
                        final boolean t$102425 = ((long) i$102465) != ((long) 0L);
                        
                        //#line 133 "x10/array/Array_4.x10"
                        if (t$102425) {
                            
                            //#line 133 "x10/array/Array_4.x10"
                            sb.add(((java.lang.String)(", ")));
                        }
                        
                        //#line 134 "x10/array/Array_4.x10"
                        final x10.array.Array_4 this$102426 = ((x10.array.Array_4)(this));
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102431 = ((i$102499) < (((long)(0L))));
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102431)) {
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            final long t$102432 = ((x10.array.Array_4<$T>)this$102426).numElems_1;
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102431 = ((i$102499) >= (((long)(t$102432))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102433 = t$102431;
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102431)) {
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102433 = ((i$102491) < (((long)(0L))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102434 = t$102433;
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102433)) {
                            
                            //#line 176 . "x10/array/Array_4.x10"
                            final long t$102435 = ((x10.array.Array_4<$T>)this$102426).numElems_2;
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102434 = ((i$102491) >= (((long)(t$102435))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102436 = t$102434;
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102434)) {
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102436 = ((i$102478) < (((long)(0L))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102437 = t$102436;
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102436)) {
                            
                            //#line 177 . "x10/array/Array_4.x10"
                            final long t$102438 = ((x10.array.Array_4<$T>)this$102426).numElems_3;
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102437 = ((i$102478) >= (((long)(t$102438))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102439 = t$102437;
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102437)) {
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102439 = ((i$102465) < (((long)(0L))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102440 = t$102439;
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102439)) {
                            
                            //#line 178 . "x10/array/Array_4.x10"
                            final long t$102441 = ((x10.array.Array_4<$T>)this$102426).numElems_4;
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102440 = ((i$102465) >= (((long)(t$102441))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (t$102440) {
                            
                            //#line 179 . "x10/array/Array_4.x10"
                            x10.array.Array.raiseBoundsError((long)(i$102499), (long)(i$102491), (long)(i$102478), (long)(i$102465));
                        }
                        
                        //#line 181 . "x10/array/Array_4.x10"
                        final x10.core.Rail r$102443 = ((x10.core.Rail)(((x10.array.Array<$T>)this$102426).raw));
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102448 = ((x10.array.Array_4<$T>)this$102426).numElems_4;
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102449 = ((x10.array.Array_4<$T>)this$102426).numElems_3;
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102450 = ((x10.array.Array_4<$T>)this$102426).numElems_2;
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102451 = ((i$102499) * (((long)(t$102450))));
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102452 = ((i$102491) + (((long)(t$102451))));
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102453 = ((t$102449) * (((long)(t$102452))));
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102454 = ((i$102478) + (((long)(t$102453))));
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102455 = ((t$102448) * (((long)(t$102454))));
                        
                        //#line 181 . "x10/array/Array_4.x10"
                        final long i$102456 = ((i$102465) + (((long)(t$102455))));
                        
                        //#line 38 .. "x10/lang/Unsafe.x10"
                        final $T t$102457 = (($T)(((x10.core.Rail<$T>)r$102443).$apply$G((long)(i$102456))));
                        
                        //#line 134 "x10/array/Array_4.x10"
                        sb.add(((java.lang.Object)(t$102457)));
                        
                        //#line 135 "x10/array/Array_4.x10"
                        final long t$102459 = ((printed) + (((long)(1L))));
                        
                        //#line 135 "x10/array/Array_4.x10"
                        final long t$102460 = printed = t$102459;
                        
                        //#line 135 "x10/array/Array_4.x10"
                        final boolean t$102461 = ((t$102460) > (((long)(limit))));
                        
                        //#line 135 "x10/array/Array_4.x10"
                        if (t$102461) {
                            
                            //#line 135 "x10/array/Array_4.x10"
                            break outer$102500;
                        }
                        
                        //#line 132 "x10/array/Array_4.x10"
                        final long t$102464 = ((i$102465) + (((long)(1L))));
                        
                        //#line 132 "x10/array/Array_4.x10"
                        i$102465 = t$102464;
                    }
                    
                    //#line 137 "x10/array/Array_4.x10"
                    final long t$102470 = this.numElems_3;
                    
                    //#line 137 "x10/array/Array_4.x10"
                    final long t$102471 = ((t$102470) - (((long)(1L))));
                    
                    //#line 137 "x10/array/Array_4.x10"
                    final boolean t$102472 = ((long) i$102478) == ((long) t$102471);
                    
                    //#line 137 "x10/array/Array_4.x10"
                    java.lang.String t$102473 =  null;
                    
                    //#line 137 "x10/array/Array_4.x10"
                    if (t$102472) {
                        
                        //#line 137 "x10/array/Array_4.x10"
                        t$102473 = ";; ";
                    } else {
                        
                        //#line 137 "x10/array/Array_4.x10"
                        t$102473 = "; ";
                    }
                    
                    //#line 137 "x10/array/Array_4.x10"
                    sb.add(((java.lang.String)(t$102473)));
                    
                    //#line 131 "x10/array/Array_4.x10"
                    final long t$102477 = ((i$102478) + (((long)(1L))));
                    
                    //#line 131 "x10/array/Array_4.x10"
                    i$102478 = t$102477;
                }
                
                //#line 139 "x10/array/Array_4.x10"
                final long t$102483 = this.numElems_2;
                
                //#line 139 "x10/array/Array_4.x10"
                final long t$102484 = ((t$102483) - (((long)(1L))));
                
                //#line 139 "x10/array/Array_4.x10"
                final boolean t$102485 = ((long) i$102491) == ((long) t$102484);
                
                //#line 139 "x10/array/Array_4.x10"
                java.lang.String t$102486 =  null;
                
                //#line 139 "x10/array/Array_4.x10"
                if (t$102485) {
                    
                    //#line 139 "x10/array/Array_4.x10"
                    t$102486 = ";; ";
                } else {
                    
                    //#line 139 "x10/array/Array_4.x10"
                    t$102486 = "; ";
                }
                
                //#line 139 "x10/array/Array_4.x10"
                sb.add(((java.lang.String)(t$102486)));
                
                //#line 130 "x10/array/Array_4.x10"
                final long t$102490 = ((i$102491) + (((long)(1L))));
                
                //#line 130 "x10/array/Array_4.x10"
                i$102491 = t$102490;
            }
            
            //#line 129 "x10/array/Array_4.x10"
            final long t$102498 = ((i$102499) + (((long)(1L))));
            
            //#line 129 "x10/array/Array_4.x10"
            i$102499 = t$102498;
        }
        
        //#line 142 "x10/array/Array_4.x10"
        final long t$102224 = this.size;
        
        //#line 142 "x10/array/Array_4.x10"
        final boolean t$102229 = ((limit) < (((long)(t$102224))));
        
        //#line 142 "x10/array/Array_4.x10"
        if (t$102229) {
            
            //#line 143 "x10/array/Array_4.x10"
            final long t$102225 = this.size;
            
            //#line 143 "x10/array/Array_4.x10"
            final long t$102226 = ((t$102225) - (((long)(limit))));
            
            //#line 143 "x10/array/Array_4.x10"
            final java.lang.String t$102227 = (("...(omitted ") + ((x10.core.Long.$box(t$102226))));
            
            //#line 143 "x10/array/Array_4.x10"
            final java.lang.String t$102228 = ((t$102227) + (" elements)"));
            
            //#line 143 "x10/array/Array_4.x10"
            sb.add(((java.lang.String)(t$102228)));
        }
        
        //#line 145 "x10/array/Array_4.x10"
        sb.add(((java.lang.String)("]")));
        
        //#line 146 "x10/array/Array_4.x10"
        final java.lang.String t$102230 = sb.toString();
        
        //#line 146 "x10/array/Array_4.x10"
        return t$102230;
    }
    
    
    //#line 152 "x10/array/Array_4.x10"
    /**
     * @return an IterationSpace containing all valid Points for indexing this Array.
     */
    public x10.array.DenseIterationSpace_4 indices() {
        
        //#line 153 "x10/array/Array_4.x10"
        final x10.array.DenseIterationSpace_4 alloc$101275 = ((x10.array.DenseIterationSpace_4)(new x10.array.DenseIterationSpace_4((java.lang.System[]) null)));
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102505 = this.numElems_1;
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102506 = ((t$102505) - (((long)(1L))));
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102507 = this.numElems_2;
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102508 = ((t$102507) - (((long)(1L))));
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102509 = this.numElems_3;
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102510 = ((t$102509) - (((long)(1L))));
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102511 = this.numElems_4;
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102512 = ((t$102511) - (((long)(1L))));
        
        //#line 153 "x10/array/Array_4.x10"
        alloc$101275.x10$array$DenseIterationSpace_4$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), ((long)(0L)), t$102506, t$102508, t$102510, t$102512);
        
        //#line 153 "x10/array/Array_4.x10"
        return alloc$101275;
    }
    
    
    //#line 160 "x10/array/Array_4.x10"
    /**
     * Map a 4-D (i,j,k,l) index into a 1-D index into the backing Rail
     * returned by raw(). Uses row-major ordering.
     */
    public long offset$O(final long i, final long j, final long k, final long l) {
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102244 = this.numElems_4;
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102241 = this.numElems_3;
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102239 = this.numElems_2;
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102240 = ((i) * (((long)(t$102239))));
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102242 = ((j) + (((long)(t$102240))));
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102243 = ((t$102241) * (((long)(t$102242))));
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102245 = ((k) + (((long)(t$102243))));
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102246 = ((t$102244) * (((long)(t$102245))));
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102247 = ((l) + (((long)(t$102246))));
        
        //#line 161 "x10/array/Array_4.x10"
        return t$102247;
    }
    
    
    //#line 174 "x10/array/Array_4.x10"
    /**
     * Return the element of this array corresponding to the given triple of indices.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @param l the given index in the fourth dimension
     * @return the element of this array corresponding to the given quad of indices.
     * @see #set(T, Long, Long, Long, Long)
     */
    public $T $apply$G(final long i, final long j, final long k, final long l) {
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102249 = ((i) < (((long)(0L))));
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102249)) {
            
            //#line 175 "x10/array/Array_4.x10"
            final long t$102248 = this.numElems_1;
            
            //#line 175 "x10/array/Array_4.x10"
            t$102249 = ((i) >= (((long)(t$102248))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102250 = t$102249;
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102249)) {
            
            //#line 175 "x10/array/Array_4.x10"
            t$102250 = ((j) < (((long)(0L))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102252 = t$102250;
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102250)) {
            
            //#line 176 "x10/array/Array_4.x10"
            final long t$102251 = this.numElems_2;
            
            //#line 175 "x10/array/Array_4.x10"
            t$102252 = ((j) >= (((long)(t$102251))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102253 = t$102252;
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102252)) {
            
            //#line 175 "x10/array/Array_4.x10"
            t$102253 = ((k) < (((long)(0L))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102255 = t$102253;
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102253)) {
            
            //#line 177 "x10/array/Array_4.x10"
            final long t$102254 = this.numElems_3;
            
            //#line 175 "x10/array/Array_4.x10"
            t$102255 = ((k) >= (((long)(t$102254))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102256 = t$102255;
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102255)) {
            
            //#line 175 "x10/array/Array_4.x10"
            t$102256 = ((l) < (((long)(0L))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102258 = t$102256;
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102256)) {
            
            //#line 178 "x10/array/Array_4.x10"
            final long t$102257 = this.numElems_4;
            
            //#line 175 "x10/array/Array_4.x10"
            t$102258 = ((l) >= (((long)(t$102257))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        if (t$102258) {
            
            //#line 179 "x10/array/Array_4.x10"
            x10.array.Array.raiseBoundsError((long)(i), (long)(j), (long)(k), (long)(l));
        }
        
        //#line 181 "x10/array/Array_4.x10"
        final x10.core.Rail r$102045 = ((x10.core.Rail)(this.raw));
        
        //#line 181 "x10/array/Array_4.x10"
        final x10.array.Array_4 this$102043 = ((x10.array.Array_4)(this));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102265 = ((x10.array.Array_4<$T>)this$102043).numElems_4;
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102262 = ((x10.array.Array_4<$T>)this$102043).numElems_3;
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102260 = ((x10.array.Array_4<$T>)this$102043).numElems_2;
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102261 = ((i) * (((long)(t$102260))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102263 = ((j) + (((long)(t$102261))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102264 = ((t$102262) * (((long)(t$102263))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102266 = ((k) + (((long)(t$102264))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102267 = ((t$102265) * (((long)(t$102266))));
        
        //#line 181 "x10/array/Array_4.x10"
        final long i$102046 = ((l) + (((long)(t$102267))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$102268 = (($T)(((x10.core.Rail<$T>)r$102045).$apply$G((long)(i$102046))));
        
        //#line 181 "x10/array/Array_4.x10"
        return t$102268;
    }
    
    
    //#line 191 "x10/array/Array_4.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point p) {
        
        //#line 191 "x10/array/Array_4.x10"
        final x10.array.Array_4 this$102052 = ((x10.array.Array_4)(this));
        
        //#line 191 "x10/array/Array_4.x10"
        final long i$102048 = p.$apply$O((long)(0L));
        
        //#line 191 "x10/array/Array_4.x10"
        final long j$102049 = p.$apply$O((long)(1L));
        
        //#line 191 "x10/array/Array_4.x10"
        final long k$102050 = p.$apply$O((long)(2L));
        
        //#line 191 "x10/array/Array_4.x10"
        final long l$102051 = p.$apply$O((long)(3L));
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102270 = ((i$102048) < (((long)(0L))));
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102270)) {
            
            //#line 175 . "x10/array/Array_4.x10"
            final long t$102269 = ((x10.array.Array_4<$T>)this$102052).numElems_1;
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102270 = ((i$102048) >= (((long)(t$102269))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102271 = t$102270;
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102270)) {
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102271 = ((j$102049) < (((long)(0L))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102273 = t$102271;
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102271)) {
            
            //#line 176 . "x10/array/Array_4.x10"
            final long t$102272 = ((x10.array.Array_4<$T>)this$102052).numElems_2;
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102273 = ((j$102049) >= (((long)(t$102272))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102274 = t$102273;
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102273)) {
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102274 = ((k$102050) < (((long)(0L))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102276 = t$102274;
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102274)) {
            
            //#line 177 . "x10/array/Array_4.x10"
            final long t$102275 = ((x10.array.Array_4<$T>)this$102052).numElems_3;
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102276 = ((k$102050) >= (((long)(t$102275))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102277 = t$102276;
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102276)) {
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102277 = ((l$102051) < (((long)(0L))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102279 = t$102277;
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102277)) {
            
            //#line 178 . "x10/array/Array_4.x10"
            final long t$102278 = ((x10.array.Array_4<$T>)this$102052).numElems_4;
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102279 = ((l$102051) >= (((long)(t$102278))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        if (t$102279) {
            
            //#line 179 . "x10/array/Array_4.x10"
            x10.array.Array.raiseBoundsError((long)(i$102048), (long)(j$102049), (long)(k$102050), (long)(l$102051));
        }
        
        //#line 181 . "x10/array/Array_4.x10"
        final x10.core.Rail r$102059 = ((x10.core.Rail)(((x10.array.Array<$T>)this$102052).raw));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102286 = ((x10.array.Array_4<$T>)this$102052).numElems_4;
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102283 = ((x10.array.Array_4<$T>)this$102052).numElems_3;
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102281 = ((x10.array.Array_4<$T>)this$102052).numElems_2;
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102282 = ((i$102048) * (((long)(t$102281))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102284 = ((j$102049) + (((long)(t$102282))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102285 = ((t$102283) * (((long)(t$102284))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102287 = ((k$102050) + (((long)(t$102285))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102288 = ((t$102286) * (((long)(t$102287))));
        
        //#line 181 . "x10/array/Array_4.x10"
        final long i$102060 = ((l$102051) + (((long)(t$102288))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$102289 = (($T)(((x10.core.Rail<$T>)r$102059).$apply$G((long)(i$102060))));
        
        //#line 191 "x10/array/Array_4.x10"
        return t$102289;
    }
    
    
    //#line 205 "x10/array/Array_4.x10"
    /**
     * Set the element of this array corresponding to the given triple of indices to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @param l the given index in the fourth dimension
     * @return the new value of the element of this array corresponding to the given quad of indices.
     * @see #operator(Long, Long, Long, Long)
     */
    public $T $set__4x10$array$Array_4$$T$G(final long i, final long j, final long k, final long l, final $T v) {
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102291 = ((i) < (((long)(0L))));
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102291)) {
            
            //#line 206 "x10/array/Array_4.x10"
            final long t$102290 = this.numElems_1;
            
            //#line 206 "x10/array/Array_4.x10"
            t$102291 = ((i) >= (((long)(t$102290))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102292 = t$102291;
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102291)) {
            
            //#line 206 "x10/array/Array_4.x10"
            t$102292 = ((j) < (((long)(0L))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102294 = t$102292;
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102292)) {
            
            //#line 207 "x10/array/Array_4.x10"
            final long t$102293 = this.numElems_2;
            
            //#line 206 "x10/array/Array_4.x10"
            t$102294 = ((j) >= (((long)(t$102293))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102295 = t$102294;
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102294)) {
            
            //#line 206 "x10/array/Array_4.x10"
            t$102295 = ((k) < (((long)(0L))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102297 = t$102295;
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102295)) {
            
            //#line 208 "x10/array/Array_4.x10"
            final long t$102296 = this.numElems_3;
            
            //#line 206 "x10/array/Array_4.x10"
            t$102297 = ((k) >= (((long)(t$102296))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102298 = t$102297;
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102297)) {
            
            //#line 206 "x10/array/Array_4.x10"
            t$102298 = ((l) < (((long)(0L))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102300 = t$102298;
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102298)) {
            
            //#line 209 "x10/array/Array_4.x10"
            final long t$102299 = this.numElems_4;
            
            //#line 206 "x10/array/Array_4.x10"
            t$102300 = ((l) >= (((long)(t$102299))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        if (t$102300) {
            
            //#line 210 "x10/array/Array_4.x10"
            x10.array.Array.raiseBoundsError((long)(i), (long)(j), (long)(k), (long)(l));
        }
        
        //#line 212 "x10/array/Array_4.x10"
        final x10.core.Rail r$102068 = ((x10.core.Rail)(this.raw));
        
        //#line 212 "x10/array/Array_4.x10"
        final x10.array.Array_4 this$102066 = ((x10.array.Array_4)(this));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102307 = ((x10.array.Array_4<$T>)this$102066).numElems_4;
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102304 = ((x10.array.Array_4<$T>)this$102066).numElems_3;
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102302 = ((x10.array.Array_4<$T>)this$102066).numElems_2;
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102303 = ((i) * (((long)(t$102302))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102305 = ((j) + (((long)(t$102303))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102306 = ((t$102304) * (((long)(t$102305))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102308 = ((k) + (((long)(t$102306))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102309 = ((t$102307) * (((long)(t$102308))));
        
        //#line 212 "x10/array/Array_4.x10"
        final long i$102069 = ((l) + (((long)(t$102309))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$102068).$set__1x10$lang$Rail$$T$G((long)(i$102069), (($T)(v)));
        
        //#line 212 "x10/array/Array_4.x10"
        return (($T)
                 v);
    }
    
    
    //#line 224 "x10/array/Array_4.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    public $T $set__1x10$array$Array_4$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 224 "x10/array/Array_4.x10"
        final x10.array.Array_4 this$102077 = ((x10.array.Array_4)(this));
        
        //#line 224 "x10/array/Array_4.x10"
        final long i$102072 = p.$apply$O((long)(0L));
        
        //#line 224 "x10/array/Array_4.x10"
        final long j$102073 = p.$apply$O((long)(1L));
        
        //#line 224 "x10/array/Array_4.x10"
        final long k$102074 = p.$apply$O((long)(2L));
        
        //#line 224 "x10/array/Array_4.x10"
        final long l$102075 = p.$apply$O((long)(3L));
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102311 = ((i$102072) < (((long)(0L))));
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102311)) {
            
            //#line 206 . "x10/array/Array_4.x10"
            final long t$102310 = ((x10.array.Array_4<$T>)this$102077).numElems_1;
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102311 = ((i$102072) >= (((long)(t$102310))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102312 = t$102311;
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102311)) {
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102312 = ((j$102073) < (((long)(0L))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102314 = t$102312;
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102312)) {
            
            //#line 207 . "x10/array/Array_4.x10"
            final long t$102313 = ((x10.array.Array_4<$T>)this$102077).numElems_2;
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102314 = ((j$102073) >= (((long)(t$102313))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102315 = t$102314;
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102314)) {
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102315 = ((k$102074) < (((long)(0L))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102317 = t$102315;
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102315)) {
            
            //#line 208 . "x10/array/Array_4.x10"
            final long t$102316 = ((x10.array.Array_4<$T>)this$102077).numElems_3;
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102317 = ((k$102074) >= (((long)(t$102316))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102318 = t$102317;
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102317)) {
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102318 = ((l$102075) < (((long)(0L))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102320 = t$102318;
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102318)) {
            
            //#line 209 . "x10/array/Array_4.x10"
            final long t$102319 = ((x10.array.Array_4<$T>)this$102077).numElems_4;
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102320 = ((l$102075) >= (((long)(t$102319))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        if (t$102320) {
            
            //#line 210 . "x10/array/Array_4.x10"
            x10.array.Array.raiseBoundsError((long)(i$102072), (long)(j$102073), (long)(k$102074), (long)(l$102075));
        }
        
        //#line 212 . "x10/array/Array_4.x10"
        final x10.core.Rail r$102084 = ((x10.core.Rail)(((x10.array.Array<$T>)this$102077).raw));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102327 = ((x10.array.Array_4<$T>)this$102077).numElems_4;
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102324 = ((x10.array.Array_4<$T>)this$102077).numElems_3;
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102322 = ((x10.array.Array_4<$T>)this$102077).numElems_2;
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102323 = ((i$102072) * (((long)(t$102322))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102325 = ((j$102073) + (((long)(t$102323))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102326 = ((t$102324) * (((long)(t$102325))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102328 = ((k$102074) + (((long)(t$102326))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102329 = ((t$102327) * (((long)(t$102328))));
        
        //#line 212 . "x10/array/Array_4.x10"
        final long i$102085 = ((l$102075) + (((long)(t$102329))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$102084).$set__1x10$lang$Rail$$T$G((long)(i$102085), (($T)(v)));
        
        //#line 224 "x10/array/Array_4.x10"
        return (($T)
                 v);
    }
    
    
    //#line 227 "x10/array/Array_4.x10"
    private static long validateSize$O(final long m, final long n, final long p, final long q) {
        
        //#line 228 "x10/array/Array_4.x10"
        boolean t$102330 = ((m) < (((long)(0L))));
        
        //#line 228 "x10/array/Array_4.x10"
        if (!(t$102330)) {
            
            //#line 228 "x10/array/Array_4.x10"
            t$102330 = ((n) < (((long)(0L))));
        }
        
        //#line 228 "x10/array/Array_4.x10"
        boolean t$102331 = t$102330;
        
        //#line 228 "x10/array/Array_4.x10"
        if (!(t$102330)) {
            
            //#line 228 "x10/array/Array_4.x10"
            t$102331 = ((p) < (((long)(0L))));
        }
        
        //#line 228 "x10/array/Array_4.x10"
        boolean t$102332 = t$102331;
        
        //#line 228 "x10/array/Array_4.x10"
        if (!(t$102331)) {
            
            //#line 228 "x10/array/Array_4.x10"
            t$102332 = ((q) < (((long)(0L))));
        }
        
        //#line 228 "x10/array/Array_4.x10"
        if (t$102332) {
            
            //#line 228 "x10/array/Array_4.x10"
            x10.array.Array.raiseNegativeArraySizeException();
        }
        
        //#line 229 "x10/array/Array_4.x10"
        final long t$102334 = ((m) * (((long)(n))));
        
        //#line 229 "x10/array/Array_4.x10"
        final long t$102335 = ((t$102334) * (((long)(p))));
        
        //#line 229 "x10/array/Array_4.x10"
        final long t$102336 = ((t$102335) * (((long)(q))));
        
        //#line 229 "x10/array/Array_4.x10"
        return t$102336;
    }
    
    public static long validateSize$P$O(final long m, final long n, final long p, final long q) {
        return x10.array.Array_4.validateSize$O((long)(m), (long)(n), (long)(p), (long)(q));
    }
    
    
    //#line 21 "x10/array/Array_4.x10"
    final public x10.array.Array_4 x10$array$Array_4$$this$x10$array$Array_4() {
        
        //#line 21 "x10/array/Array_4.x10"
        return x10.array.Array_4.this;
    }
    
    
    //#line 21 "x10/array/Array_4.x10"
    final public void __fieldInitializers_x10_array_Array_4() {
        
    }
}

