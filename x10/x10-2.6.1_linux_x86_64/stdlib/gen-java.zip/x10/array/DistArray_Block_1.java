package x10.array;


/**
 * Implementation of a 1-D DistArray that distributes its data elements
 * over the places in its PlaceGroup in a 1-D blocked fashion.
 */
@x10.runtime.impl.java.X10Generated
public class DistArray_Block_1<$T> extends x10.array.DistArray<$T> implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray_Block_1> $RTT = 
        x10.rtt.NamedType.<DistArray_Block_1> make("x10.array.DistArray_Block_1",
                                                   DistArray_Block_1.class,
                                                   1,
                                                   new x10.rtt.Type[] {
                                                       x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                                       x10.rtt.ParameterizedType.make(x10.array.DistArray.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                   });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_1<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.globalIndices = $deserializer.readObject();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localIndices = $_obj.reloadLocalIndices();
        $_obj.maxLocalIndex = $_obj.reloadMaxLocalIndex$O();
        $_obj.minLocalIndex = $_obj.reloadMinLocalIndex$O();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray_Block_1 $_obj = new x10.array.DistArray_Block_1((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.globalIndices);
        
    }
    
    // constructor just for allocation
    public DistArray_Block_1(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.DistArray_Block_1.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        if (t1.equals(x10.rtt.Types.LONG)) { return $apply$G(x10.core.Long.$unbox(a1)); }
        if (t1.equals(x10.lang.Point.$RTT)) { return $apply$G((x10.lang.Point)a1); }
        throw new java.lang.Error("dispatch mechanism not completely implemented for contra-variant types.");
    }
    
    // bridge for method abstract public x10.array.DistArray[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.DistArray).rank()}, v:T){}:T{self==v}
    final public $T $set__1x10$array$DistArray$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$DistArray_Block_1$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray_Block_1 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2 {}
    

    
    
    //#line 25 "x10/array/DistArray_Block_1.x10"
    final public long rank$O() {
        
        //#line 25 "x10/array/DistArray_Block_1.x10"
        return 1L;
    }
    
    
    //#line 27 "x10/array/DistArray_Block_1.x10"
    public x10.array.DenseIterationSpace_1 globalIndices;
    
    //#line 30 "x10/array/DistArray_Block_1.x10"
    public transient x10.array.DenseIterationSpace_1 localIndices;
    
    
    //#line 31 "x10/array/DistArray_Block_1.x10"
    final public x10.array.DenseIterationSpace_1 reloadLocalIndices() {
        
        //#line 32 "x10/array/DistArray_Block_1.x10"
        final x10.lang.PlaceLocalHandle t$107738 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 32 "x10/array/DistArray_Block_1.x10"
        final x10.array.LocalState t$107739 = ((x10.lang.PlaceLocalHandle<x10.array.LocalState<$T>>)t$107738).$apply$G();
        
        //#line 32 "x10/array/DistArray_Block_1.x10"
        final x10.array.LocalState_B1 ls = x10.rtt.Types.<x10.array.LocalState_B1<$T>> cast(t$107739,x10.rtt.ParameterizedType.make(x10.array.LocalState_B1.$RTT, $T));
        
        //#line 33 "x10/array/DistArray_Block_1.x10"
        final boolean t$107741 = ((ls) != (null));
        
        //#line 33 "x10/array/DistArray_Block_1.x10"
        x10.array.DenseIterationSpace_1 t$107742 =  null;
        
        //#line 33 "x10/array/DistArray_Block_1.x10"
        if (t$107741) {
            
            //#line 33 "x10/array/DistArray_Block_1.x10"
            final x10.array.Dist_Block_1 t$107740 = ((x10.array.Dist_Block_1)(((x10.array.LocalState_B1<$T>)ls).dist));
            
            //#line 33 "x10/array/DistArray_Block_1.x10"
            t$107742 = ((x10.array.DenseIterationSpace_1)(t$107740.localIndices));
        } else {
            
            //#line 33 "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 alloc$107642 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
            
            //#line 33 "x10/array/DistArray_Block_1.x10"
            alloc$107642.x10$array$DenseIterationSpace_1$$init$S(((long)(0L)), ((long)(-1L)));
            
            //#line 33 "x10/array/DistArray_Block_1.x10"
            t$107742 = ((x10.array.DenseIterationSpace_1)(alloc$107642));
        }
        
        //#line 33 "x10/array/DistArray_Block_1.x10"
        return t$107742;
    }
    
    
    //#line 37 "x10/array/DistArray_Block_1.x10"
    public transient long minLocalIndex;
    
    
    //#line 38 "x10/array/DistArray_Block_1.x10"
    final public long reloadMinLocalIndex$O() {
        
        //#line 38 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$107744 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
        
        //#line 38 "x10/array/DistArray_Block_1.x10"
        final long t$107745 = t$107744.min$O((long)(0L));
        
        //#line 38 "x10/array/DistArray_Block_1.x10"
        return t$107745;
    }
    
    
    //#line 41 "x10/array/DistArray_Block_1.x10"
    public transient long maxLocalIndex;
    
    
    //#line 42 "x10/array/DistArray_Block_1.x10"
    final public long reloadMaxLocalIndex$O() {
        
        //#line 42 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$107746 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
        
        //#line 42 "x10/array/DistArray_Block_1.x10"
        final long t$107747 = t$107746.max$O((long)(0L));
        
        //#line 42 "x10/array/DistArray_Block_1.x10"
        return t$107747;
    }
    
    
    //#line 53 "x10/array/DistArray_Block_1.x10"
    /**
     * Construct a n-element block distributed DistArray
     * whose data is distributed over pg and initialized using
     * the init function.
     *
     * @param n number of elements 
     * @param pg the PlaceGroup to use to distibute the elements.
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_1(final x10.rtt.Type $T, final long n, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_1$$init$S(n, pg, init, (x10.array.DistArray_Block_1.__2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_1<$T> x10$array$DistArray_Block_1$$init$S(final long n, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2 $dummy) {
         {
            
            //#line 54 "x10/array/DistArray_Block_1.x10"
            final x10.core.fun.Fun_0_0 t$107852 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_Block_1.$Closure$11<$T>($T, pg, n, init, (x10.array.DistArray_Block_1.$Closure$11.__2$1x10$lang$Long$3x10$array$DistArray_Block_1$$Closure$11$$T$2) null)));
            
            //#line 225 . "x10/array/DistArray_Block_1.x10"
            final boolean t$107855 = ((n) < (((long)(0L))));
            
            //#line 225 . "x10/array/DistArray_Block_1.x10"
            if (t$107855) {
                
                //#line 225 . "x10/array/DistArray_Block_1.x10"
                x10.array.DistArray.raiseNegativeArraySizeException();
            }
            
            //#line 54 "x10/array/DistArray_Block_1.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$107852)), n, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 53 "x10/array/DistArray_Block_1.x10"
            
            
            //#line 55 "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 alloc$107643 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
            
            //#line 55 "x10/array/DistArray_Block_1.x10"
            final long t$107857 = ((n) - (((long)(1L))));
            
            //#line 55 "x10/array/DistArray_Block_1.x10"
            alloc$107643.x10$array$DenseIterationSpace_1$$init$S(((long)(0L)), t$107857);
            
            //#line 55 "x10/array/DistArray_Block_1.x10"
            ((x10.array.DistArray_Block_1<$T>)this).globalIndices = ((x10.array.DenseIterationSpace_1)(alloc$107643));
            
            //#line 56 "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$107752 = ((x10.array.DenseIterationSpace_1)(this.reloadLocalIndices()));
            
            //#line 56 "x10/array/DistArray_Block_1.x10"
            ((x10.array.DistArray_Block_1<$T>)this).localIndices = ((x10.array.DenseIterationSpace_1)(t$107752));
            
            //#line 57 "x10/array/DistArray_Block_1.x10"
            final x10.array.DistArray_Block_1 this$107700 = ((x10.array.DistArray_Block_1)(this));
            
            //#line 38 . "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$107753 = ((x10.array.DenseIterationSpace_1)(((x10.array.DistArray_Block_1<$T>)this$107700).localIndices));
            
            //#line 38 . "x10/array/DistArray_Block_1.x10"
            final long t$107754 = t$107753.min$O((long)(0L));
            
            //#line 57 "x10/array/DistArray_Block_1.x10"
            ((x10.array.DistArray_Block_1<$T>)this).minLocalIndex = t$107754;
            
            //#line 58 "x10/array/DistArray_Block_1.x10"
            final x10.array.DistArray_Block_1 this$107702 = ((x10.array.DistArray_Block_1)(this));
            
            //#line 42 . "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$107755 = ((x10.array.DenseIterationSpace_1)(((x10.array.DistArray_Block_1<$T>)this$107702).localIndices));
            
            //#line 42 . "x10/array/DistArray_Block_1.x10"
            final long t$107756 = t$107755.max$O((long)(0L));
            
            //#line 58 "x10/array/DistArray_Block_1.x10"
            ((x10.array.DistArray_Block_1<$T>)this).maxLocalIndex = t$107756;
        }
        return this;
    }
    
    
    
    //#line 70 "x10/array/DistArray_Block_1.x10"
    /**
     * Construct a n-element block distributed DistArray
     * whose data is distributed over Place.places() and 
     * initialized using the provided init closure.
     *
     * @param n number of elements
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_1(final x10.rtt.Type $T, final long n, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __1$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_1$$init$S(n, init, (x10.array.DistArray_Block_1.__1$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_1<$T> x10$array$DistArray_Block_1$$init$S(final long n, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __1$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2 $dummy) {
         {
            
            //#line 71 "x10/array/DistArray_Block_1.x10"
            final x10.lang.PlaceGroup t$107757 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 71 "x10/array/DistArray_Block_1.x10"
            /*this.*/x10$array$DistArray_Block_1$$init$S(((long)(n)), t$107757, ((x10.core.fun.Fun_0_1)(init)), (x10.array.DistArray_Block_1.__2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 82 "x10/array/DistArray_Block_1.x10"
    /**
     * Construct a n-elmenent block distributed DistArray
     * whose data is distributed over pg and zero-initialized.
     *
     * @param n number of elements 
     * @param pg the PlaceGroup to use to distibute the elements.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_1(final x10.rtt.Type $T, final long n, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_1$$init$S(n, pg);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_1<$T> x10$array$DistArray_Block_1$$init$S(final long n, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 83 "x10/array/DistArray_Block_1.x10"
            final x10.core.fun.Fun_0_1 t$107759 = ((x10.core.fun.Fun_0_1)(new x10.array.DistArray_Block_1.$Closure$12<$T>($T)));
            
            //#line 83 "x10/array/DistArray_Block_1.x10"
            /*this.*/x10$array$DistArray_Block_1$$init$S(((long)(n)), ((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_1)(t$107759)), (x10.array.DistArray_Block_1.__2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 94 "x10/array/DistArray_Block_1.x10"
    /**
     * Construct a n-element block distributed DistArray
     * whose data is distributed over Place.places() and 
     * zero-initialized.
     *
     * @param n number of elements
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_1(final x10.rtt.Type $T, final long n) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_1$$init$S(n);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_1<$T> x10$array$DistArray_Block_1$$init$S(final long n) {
         {
            
            //#line 95 "x10/array/DistArray_Block_1.x10"
            final x10.lang.PlaceGroup t$107761 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 95 "x10/array/DistArray_Block_1.x10"
            final x10.core.fun.Fun_0_1 t$107762 = ((x10.core.fun.Fun_0_1)(new x10.array.DistArray_Block_1.$Closure$13<$T>($T)));
            
            //#line 95 "x10/array/DistArray_Block_1.x10"
            /*this.*/x10$array$DistArray_Block_1$$init$S(((long)(n)), t$107761, ((x10.core.fun.Fun_0_1)(t$107762)), (x10.array.DistArray_Block_1.__2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 104 "x10/array/DistArray_Block_1.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the global iteration space (valid indices) of the DistArray.
     * @return an IterationSpace for the DistArray
     */
    final public x10.array.DenseIterationSpace_1 globalIndices() {
        
        //#line 104 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$107763 = ((x10.array.DenseIterationSpace_1)(this.globalIndices));
        
        //#line 104 "x10/array/DistArray_Block_1.x10"
        return t$107763;
    }
    
    
    //#line 112 "x10/array/DistArray_Block_1.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the local iteration space (valid indices) of the DistArray at the current Place.
     * @return an IterationSpace for the local portion of the DistArray
     */
    final public x10.array.DenseIterationSpace_1 localIndices() {
        
        //#line 112 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$107764 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
        
        //#line 112 "x10/array/DistArray_Block_1.x10"
        return t$107764;
    }
    
    
    //#line 124 "x10/array/DistArray_Block_1.x10"
    /**
     * Return the Place which contains the data for the argument
     * index or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param i the index 
     * @return the Place where i is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if i is not contained in globalIndices
     */
    final public x10.lang.Place place(final long i) {
        
        //#line 125 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$107765 = ((x10.array.DenseIterationSpace_1)(this.globalIndices));
        
        //#line 125 "x10/array/DistArray_Block_1.x10"
        final x10.lang.PlaceGroup this$107704 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$107766 = this$107704.numPlaces$O();
        
        //#line 125 "x10/array/DistArray_Block_1.x10"
        final long tmp = x10.array.BlockingUtils.mapIndexToBlockPartition$O(((x10.array.IterationSpace)(t$107765)), (long)(t$107766), (long)(i));
        
        //#line 126 "x10/array/DistArray_Block_1.x10"
        final boolean t$107768 = ((long) tmp) == ((long) -1L);
        
        //#line 126 "x10/array/DistArray_Block_1.x10"
        x10.lang.Place t$107769 =  null;
        
        //#line 126 "x10/array/DistArray_Block_1.x10"
        if (t$107768) {
            
            //#line 126 "x10/array/DistArray_Block_1.x10"
            t$107769 = x10.lang.Place.get$INVALID_PLACE();
        } else {
            
            //#line 126 "x10/array/DistArray_Block_1.x10"
            final x10.lang.PlaceGroup t$107767 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 126 "x10/array/DistArray_Block_1.x10"
            t$107769 = t$107767.$apply((long)(tmp));
        }
        
        //#line 126 "x10/array/DistArray_Block_1.x10"
        return t$107769;
    }
    
    
    //#line 139 "x10/array/DistArray_Block_1.x10"
    /**
     * Return the Place which contains the data for the argument
     * Point or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param p the Point to lookup
     * @return the Place where p is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if p is not contained in globalIndices
     */
    final public x10.lang.Place place(final x10.lang.Point p) {
        
        //#line 139 "x10/array/DistArray_Block_1.x10"
        final long t$107771 = p.$apply$O((long)(0L));
        
        //#line 139 "x10/array/DistArray_Block_1.x10"
        final x10.lang.Place t$107772 = this.place((long)(t$107771));
        
        //#line 139 "x10/array/DistArray_Block_1.x10"
        return t$107772;
    }
    
    
    //#line 149 "x10/array/DistArray_Block_1.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * 
     * @param i the given index
     * @return the element of this array corresponding to the given index.
     * @see #set(T, Long)
     */
    final public $T $apply$G(final long i) {
        
        //#line 151 "x10/array/DistArray_Block_1.x10"
        final long t$107858 = this.minLocalIndex;
        
        //#line 151 "x10/array/DistArray_Block_1.x10"
        boolean t$107859 = ((i) < (((long)(t$107858))));
        
        //#line 151 "x10/array/DistArray_Block_1.x10"
        if (!(t$107859)) {
            
            //#line 151 "x10/array/DistArray_Block_1.x10"
            final long t$107860 = this.maxLocalIndex;
            
            //#line 151 "x10/array/DistArray_Block_1.x10"
            t$107859 = ((i) > (((long)(t$107860))));
        }
        
        //#line 151 "x10/array/DistArray_Block_1.x10"
        if (t$107859) {
            
            //#line 152 "x10/array/DistArray_Block_1.x10"
            boolean t$107862 = ((i) < (((long)(0L))));
            
            //#line 152 "x10/array/DistArray_Block_1.x10"
            if (!(t$107862)) {
                
                //#line 152 "x10/array/DistArray_Block_1.x10"
                final long t$107863 = this.size;
                
                //#line 152 "x10/array/DistArray_Block_1.x10"
                t$107862 = ((i) >= (((long)(t$107863))));
            }
            
            //#line 152 "x10/array/DistArray_Block_1.x10"
            if (t$107862) {
                
                //#line 152 "x10/array/DistArray_Block_1.x10"
                x10.array.DistArray.raiseBoundsError((long)(i));
            }
            
            //#line 153 "x10/array/DistArray_Block_1.x10"
            x10.array.DistArray.raisePlaceError((long)(i));
        }
        
        //#line 156 "x10/array/DistArray_Block_1.x10"
        final x10.core.Rail r$107706 = ((x10.core.Rail)(this.raw));
        
        //#line 156 "x10/array/DistArray_Block_1.x10"
        final long t$107780 = this.minLocalIndex;
        
        //#line 156 "x10/array/DistArray_Block_1.x10"
        final long i$107707 = ((i) - (((long)(t$107780))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$107781 = (($T)(((x10.core.Rail<$T>)r$107706).$apply$G((long)(i$107707))));
        
        //#line 156 "x10/array/DistArray_Block_1.x10"
        return t$107781;
    }
    
    
    //#line 167 "x10/array/DistArray_Block_1.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    final public $T $apply$G(final x10.lang.Point p) {
        
        //#line 167 "x10/array/DistArray_Block_1.x10"
        final x10.array.DistArray_Block_1 this$107710 = ((x10.array.DistArray_Block_1)(this));
        
        //#line 167 "x10/array/DistArray_Block_1.x10"
        final long i$107709 = p.$apply$O((long)(0L));
        
        //#line 151 . "x10/array/DistArray_Block_1.x10"
        final long t$107865 = ((x10.array.DistArray_Block_1<$T>)this$107710).minLocalIndex;
        
        //#line 151 . "x10/array/DistArray_Block_1.x10"
        boolean t$107866 = ((i$107709) < (((long)(t$107865))));
        
        //#line 151 . "x10/array/DistArray_Block_1.x10"
        if (!(t$107866)) {
            
            //#line 151 . "x10/array/DistArray_Block_1.x10"
            final long t$107867 = ((x10.array.DistArray_Block_1<$T>)this$107710).maxLocalIndex;
            
            //#line 151 . "x10/array/DistArray_Block_1.x10"
            t$107866 = ((i$107709) > (((long)(t$107867))));
        }
        
        //#line 151 . "x10/array/DistArray_Block_1.x10"
        if (t$107866) {
            
            //#line 152 . "x10/array/DistArray_Block_1.x10"
            boolean t$107869 = ((i$107709) < (((long)(0L))));
            
            //#line 152 . "x10/array/DistArray_Block_1.x10"
            if (!(t$107869)) {
                
                //#line 152 . "x10/array/DistArray_Block_1.x10"
                final long t$107870 = ((x10.array.DistArray<$T>)this$107710).size;
                
                //#line 152 . "x10/array/DistArray_Block_1.x10"
                t$107869 = ((i$107709) >= (((long)(t$107870))));
            }
            
            //#line 152 . "x10/array/DistArray_Block_1.x10"
            if (t$107869) {
                
                //#line 152 . "x10/array/DistArray_Block_1.x10"
                x10.array.DistArray.raiseBoundsError((long)(i$107709));
            }
            
            //#line 153 . "x10/array/DistArray_Block_1.x10"
            x10.array.DistArray.raisePlaceError((long)(i$107709));
        }
        
        //#line 156 . "x10/array/DistArray_Block_1.x10"
        final x10.core.Rail r$107712 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$107710).raw));
        
        //#line 156 . "x10/array/DistArray_Block_1.x10"
        final long t$107789 = ((x10.array.DistArray_Block_1<$T>)this$107710).minLocalIndex;
        
        //#line 156 . "x10/array/DistArray_Block_1.x10"
        final long i$107713 = ((i$107709) - (((long)(t$107789))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$107790 = (($T)(((x10.core.Rail<$T>)r$107712).$apply$G((long)(i$107713))));
        
        //#line 167 "x10/array/DistArray_Block_1.x10"
        return t$107790;
    }
    
    
    //#line 179 "x10/array/DistArray_Block_1.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index 
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long)
     */
    final public $T $set__1x10$array$DistArray_Block_1$$T$G(final long i, final $T v) {
        
        //#line 181 "x10/array/DistArray_Block_1.x10"
        final long t$107872 = this.minLocalIndex;
        
        //#line 181 "x10/array/DistArray_Block_1.x10"
        boolean t$107873 = ((i) < (((long)(t$107872))));
        
        //#line 181 "x10/array/DistArray_Block_1.x10"
        if (!(t$107873)) {
            
            //#line 181 "x10/array/DistArray_Block_1.x10"
            final long t$107874 = this.maxLocalIndex;
            
            //#line 181 "x10/array/DistArray_Block_1.x10"
            t$107873 = ((i) > (((long)(t$107874))));
        }
        
        //#line 181 "x10/array/DistArray_Block_1.x10"
        if (t$107873) {
            
            //#line 182 "x10/array/DistArray_Block_1.x10"
            boolean t$107876 = ((i) < (((long)(0L))));
            
            //#line 182 "x10/array/DistArray_Block_1.x10"
            if (!(t$107876)) {
                
                //#line 182 "x10/array/DistArray_Block_1.x10"
                final long t$107877 = this.size;
                
                //#line 182 "x10/array/DistArray_Block_1.x10"
                t$107876 = ((i) >= (((long)(t$107877))));
            }
            
            //#line 182 "x10/array/DistArray_Block_1.x10"
            if (t$107876) {
                
                //#line 182 "x10/array/DistArray_Block_1.x10"
                x10.array.DistArray.raiseBoundsError((long)(i));
            }
            
            //#line 183 "x10/array/DistArray_Block_1.x10"
            x10.array.DistArray.raisePlaceError((long)(i));
        }
        
        //#line 186 "x10/array/DistArray_Block_1.x10"
        final x10.core.Rail r$107715 = ((x10.core.Rail)(this.raw));
        
        //#line 186 "x10/array/DistArray_Block_1.x10"
        final long t$107798 = this.minLocalIndex;
        
        //#line 186 "x10/array/DistArray_Block_1.x10"
        final long i$107716 = ((i) - (((long)(t$107798))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$107715).$set__1x10$lang$Rail$$T$G((long)(i$107716), (($T)(v)));
        
        //#line 186 "x10/array/DistArray_Block_1.x10"
        return (($T)
                 v);
    }
    
    
    //#line 199 "x10/array/DistArray_Block_1.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Long)
     */
    final public $T $set__1x10$array$DistArray_Block_1$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 199 "x10/array/DistArray_Block_1.x10"
        final x10.array.DistArray_Block_1 this$107721 = ((x10.array.DistArray_Block_1)(this));
        
        //#line 199 "x10/array/DistArray_Block_1.x10"
        final long i$107719 = p.$apply$O((long)(0L));
        
        //#line 181 . "x10/array/DistArray_Block_1.x10"
        final long t$107879 = ((x10.array.DistArray_Block_1<$T>)this$107721).minLocalIndex;
        
        //#line 181 . "x10/array/DistArray_Block_1.x10"
        boolean t$107880 = ((i$107719) < (((long)(t$107879))));
        
        //#line 181 . "x10/array/DistArray_Block_1.x10"
        if (!(t$107880)) {
            
            //#line 181 . "x10/array/DistArray_Block_1.x10"
            final long t$107881 = ((x10.array.DistArray_Block_1<$T>)this$107721).maxLocalIndex;
            
            //#line 181 . "x10/array/DistArray_Block_1.x10"
            t$107880 = ((i$107719) > (((long)(t$107881))));
        }
        
        //#line 181 . "x10/array/DistArray_Block_1.x10"
        if (t$107880) {
            
            //#line 182 . "x10/array/DistArray_Block_1.x10"
            boolean t$107883 = ((i$107719) < (((long)(0L))));
            
            //#line 182 . "x10/array/DistArray_Block_1.x10"
            if (!(t$107883)) {
                
                //#line 182 . "x10/array/DistArray_Block_1.x10"
                final long t$107884 = ((x10.array.DistArray<$T>)this$107721).size;
                
                //#line 182 . "x10/array/DistArray_Block_1.x10"
                t$107883 = ((i$107719) >= (((long)(t$107884))));
            }
            
            //#line 182 . "x10/array/DistArray_Block_1.x10"
            if (t$107883) {
                
                //#line 182 . "x10/array/DistArray_Block_1.x10"
                x10.array.DistArray.raiseBoundsError((long)(i$107719));
            }
            
            //#line 183 . "x10/array/DistArray_Block_1.x10"
            x10.array.DistArray.raisePlaceError((long)(i$107719));
        }
        
        //#line 186 . "x10/array/DistArray_Block_1.x10"
        final x10.core.Rail r$107723 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$107721).raw));
        
        //#line 186 . "x10/array/DistArray_Block_1.x10"
        final long t$107806 = ((x10.array.DistArray_Block_1<$T>)this$107721).minLocalIndex;
        
        //#line 186 . "x10/array/DistArray_Block_1.x10"
        final long i$107724 = ((i$107719) - (((long)(t$107806))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$107723).$set__1x10$lang$Rail$$T$G((long)(i$107724), (($T)(v)));
        
        //#line 199 "x10/array/DistArray_Block_1.x10"
        return (($T)
                 v);
    }
    
    
    //#line 208 "x10/array/DistArray_Block_1.x10"
    /**
     * Returns the specified rectangular patch of this Array as a Rail.
     * 
     * @param space the DenseIterationSpace representing the portion of this array to copy
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in this array
     */
    public x10.core.Rail getPatch(final x10.array.IterationSpace space) {
        
        //#line 209 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 r = ((x10.array.DenseIterationSpace_1)(x10.rtt.Types.<x10.array.DenseIterationSpace_1> cast(space,x10.array.DenseIterationSpace_1.$RTT)));
        
        //#line 211 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$107807 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
        
        //#line 211 "x10/array/DistArray_Block_1.x10"
        final long t$107808 = t$107807.min;
        
        //#line 211 "x10/array/DistArray_Block_1.x10"
        final long t$107809 = r.min;
        
        //#line 211 "x10/array/DistArray_Block_1.x10"
        boolean t$107813 = ((t$107808) <= (((long)(t$107809))));
        
        //#line 211 "x10/array/DistArray_Block_1.x10"
        if (t$107813) {
            
            //#line 211 "x10/array/DistArray_Block_1.x10"
            final long t$107811 = r.max;
            
            //#line 211 "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$107810 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
            
            //#line 211 "x10/array/DistArray_Block_1.x10"
            final long t$107812 = t$107810.max;
            
            //#line 211 "x10/array/DistArray_Block_1.x10"
            t$107813 = ((t$107811) <= (((long)(t$107812))));
        }
        
        //#line 211 "x10/array/DistArray_Block_1.x10"
        final boolean t$107820 = !(t$107813);
        
        //#line 210 "x10/array/DistArray_Block_1.x10"
        if (t$107820) {
            
            //#line 212 "x10/array/DistArray_Block_1.x10"
            final java.lang.String t$107815 = (("patch to copy: ") + (r));
            
            //#line 212 "x10/array/DistArray_Block_1.x10"
            final java.lang.String t$107816 = ((t$107815) + (" not contained in local indices: "));
            
            //#line 212 "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$107817 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
            
            //#line 212 "x10/array/DistArray_Block_1.x10"
            final java.lang.String t$107818 = ((t$107816) + (t$107817));
            
            //#line 212 "x10/array/DistArray_Block_1.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$107819 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$107818)));
            
            //#line 212 "x10/array/DistArray_Block_1.x10"
            throw t$107819;
        }
        
        //#line 215 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$107821 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
        
        //#line 215 "x10/array/DistArray_Block_1.x10"
        final long min = t$107821.min$O((long)(0L));
        
        //#line 49 . "x10/array/DenseIterationSpace_1.x10"
        final long t$107822 = r.max;
        
        //#line 49 . "x10/array/DenseIterationSpace_1.x10"
        final long t$107823 = r.min;
        
        //#line 49 . "x10/array/DenseIterationSpace_1.x10"
        final long t$107824 = ((t$107822) - (((long)(t$107823))));
        
        //#line 49 . "x10/array/DenseIterationSpace_1.x10"
        final long t$107825 = ((t$107824) + (((long)(1L))));
        
        //#line 216 "x10/array/DistArray_Block_1.x10"
        final x10.core.Rail patch = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$107825)), false)));
        
        //#line 217 "x10/array/DistArray_Block_1.x10"
        long patchIndex = 0L;
        
        //#line 218 "x10/array/DistArray_Block_1.x10"
        final long i$107647min$107899 = r.min$O((long)(0L));
        
        //#line 218 "x10/array/DistArray_Block_1.x10"
        final long i$107647max$107900 = r.max$O((long)(0L));
        
        //#line 218 "x10/array/DistArray_Block_1.x10"
        long i$107895 = i$107647min$107899;
        
        //#line 218 "x10/array/DistArray_Block_1.x10"
        for (;
             true;
             ) {
            
            //#line 218 "x10/array/DistArray_Block_1.x10"
            final boolean t$107897 = ((i$107895) <= (((long)(i$107647max$107900))));
            
            //#line 218 "x10/array/DistArray_Block_1.x10"
            if (!(t$107897)) {
                
                //#line 218 "x10/array/DistArray_Block_1.x10"
                break;
            }
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            final long pre$107886 = patchIndex;
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            final long t$107888 = ((patchIndex) + (((long)(1L))));
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            patchIndex = t$107888;
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            final x10.core.Rail t$107889 = ((x10.core.Rail)(this.raw));
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            final long t$107890 = ((i$107895) - (((long)(min))));
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            final $T t$107891 = (($T)(((x10.core.Rail<$T>)t$107889).$apply$G((long)(t$107890))));
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            ((x10.core.Rail<$T>)patch).$set__1x10$lang$Rail$$T$G((long)(pre$107886), (($T)(t$107891)));
            
            //#line 218 "x10/array/DistArray_Block_1.x10"
            final long t$107894 = ((i$107895) + (((long)(1L))));
            
            //#line 218 "x10/array/DistArray_Block_1.x10"
            i$107895 = t$107894;
        }
        
        //#line 221 "x10/array/DistArray_Block_1.x10"
        return patch;
    }
    
    
    //#line 224 "x10/array/DistArray_Block_1.x10"
    private static long validateSize$O(final long n) {
        
        //#line 225 "x10/array/DistArray_Block_1.x10"
        final boolean t$107836 = ((n) < (((long)(0L))));
        
        //#line 225 "x10/array/DistArray_Block_1.x10"
        if (t$107836) {
            
            //#line 225 "x10/array/DistArray_Block_1.x10"
            x10.array.DistArray.raiseNegativeArraySizeException();
        }
        
        //#line 226 "x10/array/DistArray_Block_1.x10"
        return n;
    }
    
    public static long validateSize$P$O(final long n) {
        return x10.array.DistArray_Block_1.validateSize$O((long)(n));
    }
    
    
    //#line 23 "x10/array/DistArray_Block_1.x10"
    final public x10.array.DistArray_Block_1 x10$array$DistArray_Block_1$$this$x10$array$DistArray_Block_1() {
        
        //#line 23 "x10/array/DistArray_Block_1.x10"
        return x10.array.DistArray_Block_1.this;
    }
    
    
    //#line 23 "x10/array/DistArray_Block_1.x10"
    final public void __fieldInitializers_x10_array_DistArray_Block_1() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$11<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$11> $RTT = 
            x10.rtt.StaticFunType.<$Closure$11> make($Closure$11.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState_B1.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_1.$Closure$11<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.n = $deserializer.readLong();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_1.$Closure$11 $_obj = new x10.array.DistArray_Block_1.$Closure$11((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.n);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$11(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_1.$Closure$11.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState_B1 $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$11 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __2$1x10$lang$Long$3x10$array$DistArray_Block_1$$Closure$11$$T$2 {}
        
    
        
        public x10.array.LocalState_B1 $apply() {
            
            //#line 54 "x10/array/DistArray_Block_1.x10"
            final x10.array.LocalState_B1 t$107853 = x10.array.LocalState_B1.<$T> make__2$1x10$lang$Long$3x10$array$LocalState_B1$$S$2($T, ((x10.lang.PlaceGroup)(this.pg)), (long)(this.n), ((x10.core.fun.Fun_0_1)(this.init)));
            
            //#line 54 "x10/array/DistArray_Block_1.x10"
            return t$107853;
        }
        
        public x10.lang.PlaceGroup pg;
        public long n;
        public x10.core.fun.Fun_0_1<x10.core.Long,$T> init;
        
        public $Closure$11(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final long n, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$array$DistArray_Block_1$$Closure$11$$T$2 $dummy) {
            x10.array.DistArray_Block_1.$Closure$11.$initParams(this, $T);
             {
                ((x10.array.DistArray_Block_1.$Closure$11<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
                ((x10.array.DistArray_Block_1.$Closure$11<$T>)this).n = n;
                ((x10.array.DistArray_Block_1.$Closure$11<$T>)this).init = ((x10.core.fun.Fun_0_1)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$12<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$12> $RTT = 
            x10.rtt.StaticFunType.<$Closure$12> make($Closure$12.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_1.$Closure$12<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_1.$Closure$12 $_obj = new x10.array.DistArray_Block_1.$Closure$12((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$12(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_1.$Closure$12.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$G(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$12 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$73) {
            
            //#line 83 "x10/array/DistArray_Block_1.x10"
            final $T t$107758 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 83 "x10/array/DistArray_Block_1.x10"
            return t$107758;
        }
        
        public $Closure$12(final x10.rtt.Type $T) {
            x10.array.DistArray_Block_1.$Closure$12.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$13<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$13> $RTT = 
            x10.rtt.StaticFunType.<$Closure$13> make($Closure$13.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_1.$Closure$13<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_1.$Closure$13 $_obj = new x10.array.DistArray_Block_1.$Closure$13((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$13(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_1.$Closure$13.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$G(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$13 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$74) {
            
            //#line 95 "x10/array/DistArray_Block_1.x10"
            final $T t$107760 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 95 "x10/array/DistArray_Block_1.x10"
            return t$107760;
        }
        
        public $Closure$13(final x10.rtt.Type $T) {
            x10.array.DistArray_Block_1.$Closure$13.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
}


