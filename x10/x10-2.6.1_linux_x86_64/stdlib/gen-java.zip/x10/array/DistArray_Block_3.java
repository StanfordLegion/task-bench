package x10.array;


/**
 * Implementation of a 3-D DistArray that distributes its data elements
 * over the places in its PlaceGroup by distributing the first dimension 
 * in a 1-D blocked fashion.
 */
@x10.runtime.impl.java.X10Generated
public class DistArray_Block_3<$T> extends x10.array.DistArray<$T> implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray_Block_3> $RTT = 
        x10.rtt.NamedType.<DistArray_Block_3> make("x10.array.DistArray_Block_3",
                                                   DistArray_Block_3.class,
                                                   1,
                                                   new x10.rtt.Type[] {
                                                       x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                                       x10.rtt.ParameterizedType.make(x10.array.DistArray.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                   });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_3<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.globalIndices = $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        $_obj.numElems_3 = $deserializer.readLong();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localIndices = $_obj.reloadLocalIndices();
        $_obj.minIndex_1 = $_obj.reloadMinIndex_1$O();
        $_obj.numElemsLocal_1 = $_obj.reloadNumElemsLocal_1$O();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray_Block_3 $_obj = new x10.array.DistArray_Block_3((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.globalIndices);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        $serializer.write(this.numElems_3);
        
    }
    
    // constructor just for allocation
    public DistArray_Block_3(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.DistArray_Block_3.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
        
    }
    
    // bridge for method abstract public x10.array.DistArray[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.DistArray).rank()}, v:T){}:T{self==v}
    final public $T $set__1x10$array$DistArray$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$DistArray_Block_3$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray_Block_3 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2 {}
    

    
    
    //#line 26 "x10/array/DistArray_Block_3.x10"
    final public long rank$O() {
        
        //#line 26 "x10/array/DistArray_Block_3.x10"
        return 3L;
    }
    
    
    //#line 28 "x10/array/DistArray_Block_3.x10"
    public x10.array.DenseIterationSpace_3 globalIndices;
    
    //#line 30 "x10/array/DistArray_Block_3.x10"
    public long numElems_1;
    
    //#line 32 "x10/array/DistArray_Block_3.x10"
    public long numElems_2;
    
    //#line 34 "x10/array/DistArray_Block_3.x10"
    public long numElems_3;
    
    //#line 37 "x10/array/DistArray_Block_3.x10"
    public transient x10.array.DenseIterationSpace_3 localIndices;
    
    
    //#line 38 "x10/array/DistArray_Block_3.x10"
    final public x10.array.DenseIterationSpace_3 reloadLocalIndices() {
        
        //#line 40 "x10/array/DistArray_Block_3.x10"
        final x10.lang.PlaceLocalHandle t$109342 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 40 "x10/array/DistArray_Block_3.x10"
        final x10.array.LocalState t$109343 = ((x10.lang.PlaceLocalHandle<x10.array.LocalState<$T>>)t$109342).$apply$G();
        
        //#line 40 "x10/array/DistArray_Block_3.x10"
        final x10.array.LocalState_B3 ls = x10.rtt.Types.<x10.array.LocalState_B3<$T>> cast(t$109343,x10.rtt.ParameterizedType.make(x10.array.LocalState_B3.$RTT, $T));
        
        //#line 41 "x10/array/DistArray_Block_3.x10"
        final boolean t$109345 = ((ls) != (null));
        
        //#line 41 "x10/array/DistArray_Block_3.x10"
        x10.array.DenseIterationSpace_3 t$109346 =  null;
        
        //#line 41 "x10/array/DistArray_Block_3.x10"
        if (t$109345) {
            
            //#line 41 "x10/array/DistArray_Block_3.x10"
            final x10.array.Dist_Block_3 t$109344 = ((x10.array.Dist_Block_3)(((x10.array.LocalState_B3<$T>)ls).dist));
            
            //#line 41 "x10/array/DistArray_Block_3.x10"
            t$109346 = ((x10.array.DenseIterationSpace_3)(t$109344.localIndices));
        } else {
            
            //#line 41 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 alloc$109123 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
            
            //#line 41 "x10/array/DistArray_Block_3.x10"
            alloc$109123.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)), ((long)(-1L)));
            
            //#line 41 "x10/array/DistArray_Block_3.x10"
            t$109346 = ((x10.array.DenseIterationSpace_3)(alloc$109123));
        }
        
        //#line 41 "x10/array/DistArray_Block_3.x10"
        return t$109346;
    }
    
    
    //#line 45 "x10/array/DistArray_Block_3.x10"
    public transient long minIndex_1;
    
    
    //#line 46 "x10/array/DistArray_Block_3.x10"
    final public long reloadMinIndex_1$O() {
        
        //#line 46 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 t$109348 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 46 "x10/array/DistArray_Block_3.x10"
        final long t$109349 = t$109348.min$O((long)(0L));
        
        //#line 46 "x10/array/DistArray_Block_3.x10"
        return t$109349;
    }
    
    
    //#line 49 "x10/array/DistArray_Block_3.x10"
    public transient long numElemsLocal_1;
    
    
    //#line 50 "x10/array/DistArray_Block_3.x10"
    final public long reloadNumElemsLocal_1$O() {
        
        //#line 50 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 t$109350 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 50 "x10/array/DistArray_Block_3.x10"
        final long t$109351 = t$109350.max$O((long)(0L));
        
        //#line 50 "x10/array/DistArray_Block_3.x10"
        final long t$109352 = this.minIndex_1;
        
        //#line 50 "x10/array/DistArray_Block_3.x10"
        final long t$109353 = ((t$109351) - (((long)(t$109352))));
        
        //#line 50 "x10/array/DistArray_Block_3.x10"
        final long t$109354 = ((t$109353) + (((long)(1L))));
        
        //#line 50 "x10/array/DistArray_Block_3.x10"
        return t$109354;
    }
    
    
    //#line 63 "x10/array/DistArray_Block_3.x10"
    /**
     * Construct a m by n by p block distributed DistArray
     * whose data is distributed over pg and initialized using
     * the init function.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_3$$init$S(m, n, p, pg, init, (x10.array.DistArray_Block_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_3<$T> x10$array$DistArray_Block_3$$init$S(final long m, final long n, final long p, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2 $dummy) {
         {
            
            //#line 64 "x10/array/DistArray_Block_3.x10"
            final x10.core.fun.Fun_0_0 t$109552 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_Block_3.$Closure$17<$T>($T, pg, m, n, p, init, (x10.array.DistArray_Block_3.$Closure$17.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$Closure$17$$T$2) null)));
            
            //#line 268 . "x10/array/DistArray_Block_3.x10"
            boolean t$109557 = ((m) < (((long)(0L))));
            
            //#line 268 . "x10/array/DistArray_Block_3.x10"
            if (!(t$109557)) {
                
                //#line 268 . "x10/array/DistArray_Block_3.x10"
                t$109557 = ((n) < (((long)(0L))));
            }
            
            //#line 268 . "x10/array/DistArray_Block_3.x10"
            boolean t$109558 = t$109557;
            
            //#line 268 . "x10/array/DistArray_Block_3.x10"
            if (!(t$109557)) {
                
                //#line 268 . "x10/array/DistArray_Block_3.x10"
                t$109558 = ((p) < (((long)(0L))));
            }
            
            //#line 268 . "x10/array/DistArray_Block_3.x10"
            if (t$109558) {
                
                //#line 268 . "x10/array/DistArray_Block_3.x10"
                x10.array.DistArray.raiseNegativeArraySizeException();
            }
            
            //#line 269 . "x10/array/DistArray_Block_3.x10"
            final long t$109560 = ((m) * (((long)(n))));
            
            //#line 269 . "x10/array/DistArray_Block_3.x10"
            final long t$109561 = ((t$109560) * (((long)(p))));
            
            //#line 64 "x10/array/DistArray_Block_3.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$109552)), t$109561, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 63 "x10/array/DistArray_Block_3.x10"
            
            
            //#line 65 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 alloc$109124 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
            
            //#line 65 "x10/array/DistArray_Block_3.x10"
            final long t$109563 = ((m) - (((long)(1L))));
            
            //#line 65 "x10/array/DistArray_Block_3.x10"
            final long t$109564 = ((n) - (((long)(1L))));
            
            //#line 65 "x10/array/DistArray_Block_3.x10"
            final long t$109565 = ((p) - (((long)(1L))));
            
            //#line 65 "x10/array/DistArray_Block_3.x10"
            alloc$109124.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), t$109563, t$109564, t$109565);
            
            //#line 65 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).globalIndices = ((x10.array.DenseIterationSpace_3)(alloc$109124));
            
            //#line 66 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).numElems_1 = m;
            
            //#line 67 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).numElems_2 = n;
            
            //#line 68 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).numElems_3 = p;
            
            //#line 69 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109365 = ((x10.array.DenseIterationSpace_3)(this.reloadLocalIndices()));
            
            //#line 69 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).localIndices = ((x10.array.DenseIterationSpace_3)(t$109365));
            
            //#line 70 "x10/array/DistArray_Block_3.x10"
            final x10.array.DistArray_Block_3 this$109281 = ((x10.array.DistArray_Block_3)(this));
            
            //#line 46 . "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109366 = ((x10.array.DenseIterationSpace_3)(((x10.array.DistArray_Block_3<$T>)this$109281).localIndices));
            
            //#line 46 . "x10/array/DistArray_Block_3.x10"
            final long t$109367 = t$109366.min$O((long)(0L));
            
            //#line 70 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).minIndex_1 = t$109367;
            
            //#line 71 "x10/array/DistArray_Block_3.x10"
            final long t$109368 = this.reloadNumElemsLocal_1$O();
            
            //#line 71 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).numElemsLocal_1 = t$109368;
        }
        return this;
    }
    
    
    
    //#line 85 "x10/array/DistArray_Block_3.x10"
    /**
     * Construct a m by n by p block distributed DistArray
     * whose data is distributed over Place.places() and 
     * initialized using the provided init closure.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_3$$init$S(m, n, p, init, (x10.array.DistArray_Block_3.__3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_3<$T> x10$array$DistArray_Block_3$$init$S(final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2 $dummy) {
         {
            
            //#line 86 "x10/array/DistArray_Block_3.x10"
            final x10.lang.PlaceGroup t$109369 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 86 "x10/array/DistArray_Block_3.x10"
            /*this.*/x10$array$DistArray_Block_3$$init$S(((long)(m)), ((long)(n)), ((long)(p)), t$109369, ((x10.core.fun.Fun_0_3)(init)), (x10.array.DistArray_Block_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 99 "x10/array/DistArray_Block_3.x10"
    /**
     * Construct a m by n by p block distributed DistArray
     * whose data is distributed over pg and zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_3$$init$S(m, n, p, pg);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_3<$T> x10$array$DistArray_Block_3$$init$S(final long m, final long n, final long p, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 100 "x10/array/DistArray_Block_3.x10"
            final x10.core.fun.Fun_0_3 t$109371 = ((x10.core.fun.Fun_0_3)(new x10.array.DistArray_Block_3.$Closure$18<$T>($T)));
            
            //#line 100 "x10/array/DistArray_Block_3.x10"
            /*this.*/x10$array$DistArray_Block_3$$init$S(((long)(m)), ((long)(n)), ((long)(p)), ((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_3)(t$109371)), (x10.array.DistArray_Block_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 113 "x10/array/DistArray_Block_3.x10"
    /**
     * Construct a m by n by p block distributed DistArray
     * whose data is distributed over Place.places() and 
     * zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the second dimension
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_3(final x10.rtt.Type $T, final long m, final long n, final long p) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_3$$init$S(m, n, p);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_3<$T> x10$array$DistArray_Block_3$$init$S(final long m, final long n, final long p) {
         {
            
            //#line 114 "x10/array/DistArray_Block_3.x10"
            final x10.lang.PlaceGroup t$109373 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 114 "x10/array/DistArray_Block_3.x10"
            final x10.core.fun.Fun_0_3 t$109374 = ((x10.core.fun.Fun_0_3)(new x10.array.DistArray_Block_3.$Closure$19<$T>($T)));
            
            //#line 114 "x10/array/DistArray_Block_3.x10"
            /*this.*/x10$array$DistArray_Block_3$$init$S(((long)(m)), ((long)(n)), ((long)(p)), t$109373, ((x10.core.fun.Fun_0_3)(t$109374)), (x10.array.DistArray_Block_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 123 "x10/array/DistArray_Block_3.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the global iteration space (valid indices) of the DistArray.
     * @return an IterationSpace for the DistArray
     */
    final public x10.array.DenseIterationSpace_3 globalIndices() {
        
        //#line 123 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 t$109375 = ((x10.array.DenseIterationSpace_3)(this.globalIndices));
        
        //#line 123 "x10/array/DistArray_Block_3.x10"
        return t$109375;
    }
    
    
    //#line 131 "x10/array/DistArray_Block_3.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the local iteration space (valid indices) of the DistArray at the current Place.
     * @return an IterationSpace for the local portion of the DistArray
     */
    final public x10.array.DenseIterationSpace_3 localIndices() {
        
        //#line 131 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 t$109376 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 131 "x10/array/DistArray_Block_3.x10"
        return t$109376;
    }
    
    
    //#line 145 "x10/array/DistArray_Block_3.x10"
    /**
     * Return the Place which contains the data for the argument
     * index or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param i the index in the first dimension
     * @param j the index in the second dimension
     * @param k the index in the third dimension
     * @return the Place where (i,j,k) is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if (i,j,k) is not contained in globalIndices
     */
    final public x10.lang.Place place(final long i, final long j, final long k) {
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        boolean t$109378 = ((j) < (((long)(0L))));
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        if (!(t$109378)) {
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            final long t$109377 = this.numElems_2;
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            t$109378 = ((j) >= (((long)(t$109377))));
        }
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        boolean t$109379 = t$109378;
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        if (!(t$109378)) {
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            t$109379 = ((k) < (((long)(0L))));
        }
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        boolean t$109381 = t$109379;
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        if (!(t$109379)) {
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            final long t$109380 = this.numElems_3;
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            t$109381 = ((k) >= (((long)(t$109380))));
        }
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        if (t$109381) {
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            final x10.lang.Place t$109382 = ((x10.lang.Place)(x10.lang.Place.get$INVALID_PLACE()));
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            return t$109382;
        }
        
        //#line 147 "x10/array/DistArray_Block_3.x10"
        final long t$109384 = this.numElems_1;
        
        //#line 147 "x10/array/DistArray_Block_3.x10"
        final long t$109385 = ((t$109384) - (((long)(1L))));
        
        //#line 147 "x10/array/DistArray_Block_3.x10"
        final x10.lang.PlaceGroup this$109283 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$109386 = this$109283.numPlaces$O();
        
        //#line 147 "x10/array/DistArray_Block_3.x10"
        final long tmp = x10.array.BlockingUtils.mapIndexToBlockPartition$O((long)(0L), (long)(t$109385), (long)(t$109386), (long)(i));
        
        //#line 148 "x10/array/DistArray_Block_3.x10"
        final boolean t$109388 = ((long) tmp) == ((long) -1L);
        
        //#line 148 "x10/array/DistArray_Block_3.x10"
        x10.lang.Place t$109389 =  null;
        
        //#line 148 "x10/array/DistArray_Block_3.x10"
        if (t$109388) {
            
            //#line 148 "x10/array/DistArray_Block_3.x10"
            t$109389 = x10.lang.Place.get$INVALID_PLACE();
        } else {
            
            //#line 148 "x10/array/DistArray_Block_3.x10"
            final x10.lang.PlaceGroup t$109387 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 148 "x10/array/DistArray_Block_3.x10"
            t$109389 = t$109387.$apply((long)(tmp));
        }
        
        //#line 148 "x10/array/DistArray_Block_3.x10"
        return t$109389;
    }
    
    
    //#line 161 "x10/array/DistArray_Block_3.x10"
    /**
     * Return the Place which contains the data for the argument
     * Point or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param p the Point to lookup
     * @return the Place where p is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if p is not contained in globalIndices
     */
    final public x10.lang.Place place(final x10.lang.Point p) {
        
        //#line 161 "x10/array/DistArray_Block_3.x10"
        final long t$109391 = p.$apply$O((long)(0L));
        
        //#line 161 "x10/array/DistArray_Block_3.x10"
        final long t$109392 = p.$apply$O((long)(1L));
        
        //#line 161 "x10/array/DistArray_Block_3.x10"
        final long t$109393 = p.$apply$O((long)(2L));
        
        //#line 161 "x10/array/DistArray_Block_3.x10"
        final x10.lang.Place t$109394 = this.place((long)(t$109391), (long)(t$109392), (long)(t$109393));
        
        //#line 161 "x10/array/DistArray_Block_3.x10"
        return t$109394;
    }
    
    
    //#line 173 "x10/array/DistArray_Block_3.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @return the element of this array corresponding to the given index.
     * @see #set(T, Long, Long, Long)
     */
    final public $T $apply$G(final long i, final long j, final long k) {
        
        //#line 174 "x10/array/DistArray_Block_3.x10"
        this.validateIndex((long)(i), (long)(j), (long)(k));
        
        //#line 175 "x10/array/DistArray_Block_3.x10"
        final x10.core.Rail r$109290 = ((x10.core.Rail)(this.raw));
        
        //#line 175 "x10/array/DistArray_Block_3.x10"
        final x10.array.DistArray_Block_3 this$109288 = ((x10.array.DistArray_Block_3)(this));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109399 = ((x10.array.DistArray_Block_3<$T>)this$109288).numElems_3;
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109395 = ((x10.array.DistArray_Block_3<$T>)this$109288).minIndex_1;
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109396 = ((i) - (((long)(t$109395))));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109397 = ((x10.array.DistArray_Block_3<$T>)this$109288).numElems_2;
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109398 = ((t$109396) * (((long)(t$109397))));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109400 = ((j) + (((long)(t$109398))));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109401 = ((t$109399) * (((long)(t$109400))));
        
        //#line 175 "x10/array/DistArray_Block_3.x10"
        final long i$109291 = ((k) + (((long)(t$109401))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$109402 = (($T)(((x10.core.Rail<$T>)r$109290).$apply$G((long)(i$109291))));
        
        //#line 175 "x10/array/DistArray_Block_3.x10"
        return t$109402;
    }
    
    
    //#line 186 "x10/array/DistArray_Block_3.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    final public $T $apply$G(final x10.lang.Point p) {
        
        //#line 186 "x10/array/DistArray_Block_3.x10"
        final x10.array.DistArray_Block_3 this$109296 = ((x10.array.DistArray_Block_3)(this));
        
        //#line 186 "x10/array/DistArray_Block_3.x10"
        final long i$109293 = p.$apply$O((long)(0L));
        
        //#line 186 "x10/array/DistArray_Block_3.x10"
        final long j$109294 = p.$apply$O((long)(1L));
        
        //#line 186 "x10/array/DistArray_Block_3.x10"
        final long k$109295 = p.$apply$O((long)(2L));
        
        //#line 174 . "x10/array/DistArray_Block_3.x10"
        ((x10.array.DistArray_Block_3<$T>)this$109296).validateIndex((long)(i$109293), (long)(j$109294), (long)(k$109295));
        
        //#line 175 . "x10/array/DistArray_Block_3.x10"
        final x10.core.Rail r$109302 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$109296).raw));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109407 = ((x10.array.DistArray_Block_3<$T>)this$109296).numElems_3;
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109403 = ((x10.array.DistArray_Block_3<$T>)this$109296).minIndex_1;
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109404 = ((i$109293) - (((long)(t$109403))));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109405 = ((x10.array.DistArray_Block_3<$T>)this$109296).numElems_2;
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109406 = ((t$109404) * (((long)(t$109405))));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109408 = ((j$109294) + (((long)(t$109406))));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109409 = ((t$109407) * (((long)(t$109408))));
        
        //#line 175 . "x10/array/DistArray_Block_3.x10"
        final long i$109303 = ((k$109295) + (((long)(t$109409))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$109410 = (($T)(((x10.core.Rail<$T>)r$109302).$apply$G((long)(i$109303))));
        
        //#line 186 "x10/array/DistArray_Block_3.x10"
        return t$109410;
    }
    
    
    //#line 200 "x10/array/DistArray_Block_3.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long, Long, Long)
     */
    final public $T $set__3x10$array$DistArray_Block_3$$T$G(final long i, final long j, final long k, final $T v) {
        
        //#line 201 "x10/array/DistArray_Block_3.x10"
        this.validateIndex((long)(i), (long)(j), (long)(k));
        
        //#line 202 "x10/array/DistArray_Block_3.x10"
        final x10.core.Rail r$109310 = ((x10.core.Rail)(this.raw));
        
        //#line 202 "x10/array/DistArray_Block_3.x10"
        final x10.array.DistArray_Block_3 this$109308 = ((x10.array.DistArray_Block_3)(this));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109415 = ((x10.array.DistArray_Block_3<$T>)this$109308).numElems_3;
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109411 = ((x10.array.DistArray_Block_3<$T>)this$109308).minIndex_1;
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109412 = ((i) - (((long)(t$109411))));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109413 = ((x10.array.DistArray_Block_3<$T>)this$109308).numElems_2;
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109414 = ((t$109412) * (((long)(t$109413))));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109416 = ((j) + (((long)(t$109414))));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109417 = ((t$109415) * (((long)(t$109416))));
        
        //#line 202 "x10/array/DistArray_Block_3.x10"
        final long i$109311 = ((k) + (((long)(t$109417))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$109310).$set__1x10$lang$Rail$$T$G((long)(i$109311), (($T)(v)));
        
        //#line 202 "x10/array/DistArray_Block_3.x10"
        return (($T)
                 v);
    }
    
    
    //#line 215 "x10/array/DistArray_Block_3.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    final public $T $set__1x10$array$DistArray_Block_3$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 215 "x10/array/DistArray_Block_3.x10"
        final x10.array.DistArray_Block_3 this$109318 = ((x10.array.DistArray_Block_3)(this));
        
        //#line 215 "x10/array/DistArray_Block_3.x10"
        final long i$109314 = p.$apply$O((long)(0L));
        
        //#line 215 "x10/array/DistArray_Block_3.x10"
        final long j$109315 = p.$apply$O((long)(1L));
        
        //#line 215 "x10/array/DistArray_Block_3.x10"
        final long k$109316 = p.$apply$O((long)(2L));
        
        //#line 201 . "x10/array/DistArray_Block_3.x10"
        ((x10.array.DistArray_Block_3<$T>)this$109318).validateIndex((long)(i$109314), (long)(j$109315), (long)(k$109316));
        
        //#line 202 . "x10/array/DistArray_Block_3.x10"
        final x10.core.Rail r$109324 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$109318).raw));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109422 = ((x10.array.DistArray_Block_3<$T>)this$109318).numElems_3;
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109418 = ((x10.array.DistArray_Block_3<$T>)this$109318).minIndex_1;
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109419 = ((i$109314) - (((long)(t$109418))));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109420 = ((x10.array.DistArray_Block_3<$T>)this$109318).numElems_2;
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109421 = ((t$109419) * (((long)(t$109420))));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109423 = ((j$109315) + (((long)(t$109421))));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109424 = ((t$109422) * (((long)(t$109423))));
        
        //#line 202 . "x10/array/DistArray_Block_3.x10"
        final long i$109325 = ((k$109316) + (((long)(t$109424))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$109324).$set__1x10$lang$Rail$$T$G((long)(i$109325), (($T)(v)));
        
        //#line 215 "x10/array/DistArray_Block_3.x10"
        return (($T)
                 v);
    }
    
    
    //#line 223 "x10/array/DistArray_Block_3.x10"
    final public void validateIndex(final long i, final long j, final long k) {
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        boolean t$109426 = ((j) < (((long)(0L))));
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        if (!(t$109426)) {
            
            //#line 225 "x10/array/DistArray_Block_3.x10"
            final long t$109425 = this.numElems_2;
            
            //#line 225 "x10/array/DistArray_Block_3.x10"
            t$109426 = ((j) >= (((long)(t$109425))));
        }
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        boolean t$109427 = t$109426;
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        if (!(t$109426)) {
            
            //#line 225 "x10/array/DistArray_Block_3.x10"
            t$109427 = ((k) < (((long)(0L))));
        }
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        boolean t$109429 = t$109427;
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        if (!(t$109427)) {
            
            //#line 225 "x10/array/DistArray_Block_3.x10"
            final long t$109428 = this.numElems_3;
            
            //#line 225 "x10/array/DistArray_Block_3.x10"
            t$109429 = ((k) >= (((long)(t$109428))));
        }
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        if (t$109429) {
            
            //#line 226 "x10/array/DistArray_Block_3.x10"
            x10.array.DistArray.raiseBoundsError((long)(i), (long)(j), (long)(k));
        }
        
        //#line 228 "x10/array/DistArray_Block_3.x10"
        final long t$109431 = this.minIndex_1;
        
        //#line 228 "x10/array/DistArray_Block_3.x10"
        boolean t$109435 = ((i) < (((long)(t$109431))));
        
        //#line 228 "x10/array/DistArray_Block_3.x10"
        if (!(t$109435)) {
            
            //#line 228 "x10/array/DistArray_Block_3.x10"
            final long t$109432 = this.minIndex_1;
            
            //#line 228 "x10/array/DistArray_Block_3.x10"
            final long t$109433 = this.numElemsLocal_1;
            
            //#line 228 "x10/array/DistArray_Block_3.x10"
            final long t$109434 = ((t$109432) + (((long)(t$109433))));
            
            //#line 228 "x10/array/DistArray_Block_3.x10"
            t$109435 = ((i) >= (((long)(t$109434))));
        }
        
        //#line 228 "x10/array/DistArray_Block_3.x10"
        if (t$109435) {
            
            //#line 229 "x10/array/DistArray_Block_3.x10"
            boolean t$109437 = ((i) < (((long)(0L))));
            
            //#line 229 "x10/array/DistArray_Block_3.x10"
            if (!(t$109437)) {
                
                //#line 229 "x10/array/DistArray_Block_3.x10"
                final long t$109436 = this.numElems_1;
                
                //#line 229 "x10/array/DistArray_Block_3.x10"
                t$109437 = ((i) >= (((long)(t$109436))));
            }
            
            //#line 229 "x10/array/DistArray_Block_3.x10"
            if (t$109437) {
                
                //#line 230 "x10/array/DistArray_Block_3.x10"
                x10.array.DistArray.raiseBoundsError((long)(i), (long)(j), (long)(k));
            }
            
            //#line 232 "x10/array/DistArray_Block_3.x10"
            x10.array.DistArray.raisePlaceError((long)(i), (long)(j), (long)(k));
        }
    }
    
    
    //#line 237 "x10/array/DistArray_Block_3.x10"
    final public long offset$O(final long i, final long j, final long k) {
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109444 = this.numElems_3;
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109440 = this.minIndex_1;
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109441 = ((i) - (((long)(t$109440))));
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109442 = this.numElems_2;
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109443 = ((t$109441) * (((long)(t$109442))));
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109445 = ((j) + (((long)(t$109443))));
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109446 = ((t$109444) * (((long)(t$109445))));
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109447 = ((k) + (((long)(t$109446))));
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        return t$109447;
    }
    
    
    //#line 249 "x10/array/DistArray_Block_3.x10"
    /**
     * Returns the specified rectangular patch of this array as a Rail.
     * 
     * @param space the IterationSpace representing the portion of this array to copy
     * @see offset
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in this array
     */
    public x10.core.Rail getPatch(final x10.array.IterationSpace space) {
        
        //#line 250 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 r = ((x10.array.DenseIterationSpace_3)(x10.rtt.Types.<x10.array.DenseIterationSpace_3> cast(space,x10.array.DenseIterationSpace_3.$RTT)));
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 t$109448 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        final long t$109449 = t$109448.min0;
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        final long t$109450 = r.min0;
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        boolean t$109454 = ((t$109449) <= (((long)(t$109450))));
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        if (t$109454) {
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            final long t$109452 = r.max0;
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109451 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            final long t$109453 = t$109451.max0;
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            t$109454 = ((t$109452) <= (((long)(t$109453))));
        }
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        boolean t$109458 = t$109454;
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        if (t$109454) {
            
            //#line 254 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109455 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 254 "x10/array/DistArray_Block_3.x10"
            final long t$109456 = t$109455.min1;
            
            //#line 254 "x10/array/DistArray_Block_3.x10"
            final long t$109457 = r.min1;
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            t$109458 = ((t$109456) <= (((long)(t$109457))));
        }
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        boolean t$109462 = t$109458;
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        if (t$109458) {
            
            //#line 254 "x10/array/DistArray_Block_3.x10"
            final long t$109460 = r.max1;
            
            //#line 254 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109459 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 254 "x10/array/DistArray_Block_3.x10"
            final long t$109461 = t$109459.max1;
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            t$109462 = ((t$109460) <= (((long)(t$109461))));
        }
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        boolean t$109466 = t$109462;
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        if (t$109462) {
            
            //#line 255 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109463 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 255 "x10/array/DistArray_Block_3.x10"
            final long t$109464 = t$109463.min2;
            
            //#line 255 "x10/array/DistArray_Block_3.x10"
            final long t$109465 = r.min2;
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            t$109466 = ((t$109464) <= (((long)(t$109465))));
        }
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        boolean t$109470 = t$109466;
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        if (t$109466) {
            
            //#line 255 "x10/array/DistArray_Block_3.x10"
            final long t$109468 = r.max2;
            
            //#line 255 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109467 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 255 "x10/array/DistArray_Block_3.x10"
            final long t$109469 = t$109467.max2;
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            t$109470 = ((t$109468) <= (((long)(t$109469))));
        }
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        final boolean t$109477 = !(t$109470);
        
        //#line 252 "x10/array/DistArray_Block_3.x10"
        if (t$109477) {
            
            //#line 256 "x10/array/DistArray_Block_3.x10"
            final java.lang.String t$109472 = (("patch to copy: ") + (r));
            
            //#line 256 "x10/array/DistArray_Block_3.x10"
            final java.lang.String t$109473 = ((t$109472) + (" not contained in local indices: "));
            
            //#line 256 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109474 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 256 "x10/array/DistArray_Block_3.x10"
            final java.lang.String t$109475 = ((t$109473) + (t$109474));
            
            //#line 256 "x10/array/DistArray_Block_3.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$109476 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$109475)));
            
            //#line 256 "x10/array/DistArray_Block_3.x10"
            throw t$109476;
        }
        
        //#line 259 "x10/array/DistArray_Block_3.x10"
        final long t$109478 = r.size$O();
        
        //#line 259 "x10/array/DistArray_Block_3.x10"
        final x10.core.Rail patch = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$109478)), false)));
        
        //#line 260 "x10/array/DistArray_Block_3.x10"
        long patchIndex = 0L;
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        final long i2$109128min$109602 = r.min$O((long)(2L));
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        final long i2$109128max$109603 = r.max$O((long)(2L));
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        final long i1$109159min$109604 = r.min$O((long)(1L));
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        final long i1$109159max$109605 = r.max$O((long)(1L));
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        final long i0$109190min$109606 = r.min$O((long)(0L));
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        final long i0$109190max$109607 = r.max$O((long)(0L));
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        long i$109598 = i0$109190min$109606;
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        for (;
             true;
             ) {
            
            //#line 261 "x10/array/DistArray_Block_3.x10"
            final boolean t$109600 = ((i$109598) <= (((long)(i0$109190max$109607))));
            
            //#line 261 "x10/array/DistArray_Block_3.x10"
            if (!(t$109600)) {
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                break;
            }
            
            //#line 261 "x10/array/DistArray_Block_3.x10"
            long i$109592 = i1$109159min$109604;
            
            //#line 261 "x10/array/DistArray_Block_3.x10"
            for (;
                 true;
                 ) {
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                final boolean t$109594 = ((i$109592) <= (((long)(i1$109159max$109605))));
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                if (!(t$109594)) {
                    
                    //#line 261 "x10/array/DistArray_Block_3.x10"
                    break;
                }
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                long i$109586 = i2$109128min$109602;
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 261 "x10/array/DistArray_Block_3.x10"
                    final boolean t$109588 = ((i$109586) <= (((long)(i2$109128max$109603))));
                    
                    //#line 261 "x10/array/DistArray_Block_3.x10"
                    if (!(t$109588)) {
                        
                        //#line 261 "x10/array/DistArray_Block_3.x10"
                        break;
                    }
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    final long pre$109566 = patchIndex;
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    final long t$109568 = ((patchIndex) + (((long)(1L))));
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    patchIndex = t$109568;
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    final x10.core.Rail t$109569 = ((x10.core.Rail)(this.raw));
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    final x10.array.DistArray_Block_3 this$109570 = ((x10.array.DistArray_Block_3)(this));
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$109574 = ((x10.array.DistArray_Block_3<$T>)this$109570).numElems_3;
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$109575 = ((x10.array.DistArray_Block_3<$T>)this$109570).minIndex_1;
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$109576 = ((i$109598) - (((long)(t$109575))));
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$109577 = ((x10.array.DistArray_Block_3<$T>)this$109570).numElems_2;
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$109578 = ((t$109576) * (((long)(t$109577))));
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$109579 = ((i$109592) + (((long)(t$109578))));
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$109580 = ((t$109574) * (((long)(t$109579))));
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$109581 = ((i$109586) + (((long)(t$109580))));
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    final $T t$109582 = (($T)(((x10.core.Rail<$T>)t$109569).$apply$G((long)(t$109581))));
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    ((x10.core.Rail<$T>)patch).$set__1x10$lang$Rail$$T$G((long)(pre$109566), (($T)(t$109582)));
                    
                    //#line 261 "x10/array/DistArray_Block_3.x10"
                    final long t$109585 = ((i$109586) + (((long)(1L))));
                    
                    //#line 261 "x10/array/DistArray_Block_3.x10"
                    i$109586 = t$109585;
                }
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                final long t$109591 = ((i$109592) + (((long)(1L))));
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                i$109592 = t$109591;
            }
            
            //#line 261 "x10/array/DistArray_Block_3.x10"
            final long t$109597 = ((i$109598) + (((long)(1L))));
            
            //#line 261 "x10/array/DistArray_Block_3.x10"
            i$109598 = t$109597;
        }
        
        //#line 264 "x10/array/DistArray_Block_3.x10"
        return patch;
    }
    
    
    //#line 267 "x10/array/DistArray_Block_3.x10"
    private static long validateSize$O(final long m, final long n, final long p) {
        
        //#line 268 "x10/array/DistArray_Block_3.x10"
        boolean t$109506 = ((m) < (((long)(0L))));
        
        //#line 268 "x10/array/DistArray_Block_3.x10"
        if (!(t$109506)) {
            
            //#line 268 "x10/array/DistArray_Block_3.x10"
            t$109506 = ((n) < (((long)(0L))));
        }
        
        //#line 268 "x10/array/DistArray_Block_3.x10"
        boolean t$109507 = t$109506;
        
        //#line 268 "x10/array/DistArray_Block_3.x10"
        if (!(t$109506)) {
            
            //#line 268 "x10/array/DistArray_Block_3.x10"
            t$109507 = ((p) < (((long)(0L))));
        }
        
        //#line 268 "x10/array/DistArray_Block_3.x10"
        if (t$109507) {
            
            //#line 268 "x10/array/DistArray_Block_3.x10"
            x10.array.DistArray.raiseNegativeArraySizeException();
        }
        
        //#line 269 "x10/array/DistArray_Block_3.x10"
        final long t$109509 = ((m) * (((long)(n))));
        
        //#line 269 "x10/array/DistArray_Block_3.x10"
        final long t$109510 = ((t$109509) * (((long)(p))));
        
        //#line 269 "x10/array/DistArray_Block_3.x10"
        return t$109510;
    }
    
    public static long validateSize$P$O(final long m, final long n, final long p) {
        return x10.array.DistArray_Block_3.validateSize$O((long)(m), (long)(n), (long)(p));
    }
    
    
    //#line 24 "x10/array/DistArray_Block_3.x10"
    final public x10.array.DistArray_Block_3 x10$array$DistArray_Block_3$$this$x10$array$DistArray_Block_3() {
        
        //#line 24 "x10/array/DistArray_Block_3.x10"
        return x10.array.DistArray_Block_3.this;
    }
    
    
    //#line 24 "x10/array/DistArray_Block_3.x10"
    final public void __fieldInitializers_x10_array_DistArray_Block_3() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$17<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$17> $RTT = 
            x10.rtt.StaticFunType.<$Closure$17> make($Closure$17.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState_B3.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_3.$Closure$17<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.m = $deserializer.readLong();
            $_obj.n = $deserializer.readLong();
            $_obj.p = $deserializer.readLong();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_3.$Closure$17 $_obj = new x10.array.DistArray_Block_3.$Closure$17((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.m);
            $serializer.write(this.n);
            $serializer.write(this.p);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$17(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_3.$Closure$17.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState_B3 $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$17 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$Closure$17$$T$2 {}
        
    
        
        public x10.array.LocalState_B3 $apply() {
            
            //#line 64 "x10/array/DistArray_Block_3.x10"
            final x10.array.LocalState_B3 t$109553 = x10.array.LocalState_B3.<$T> make__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$LocalState_B3$$S$2($T, ((x10.lang.PlaceGroup)(this.pg)), (long)(this.m), (long)(this.n), (long)(this.p), ((x10.core.fun.Fun_0_3)(this.init)));
            
            //#line 64 "x10/array/DistArray_Block_3.x10"
            return t$109553;
        }
        
        public x10.lang.PlaceGroup pg;
        public long m;
        public long n;
        public long p;
        public x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init;
        
        public $Closure$17(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$Closure$17$$T$2 $dummy) {
            x10.array.DistArray_Block_3.$Closure$17.$initParams(this, $T);
             {
                ((x10.array.DistArray_Block_3.$Closure$17<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
                ((x10.array.DistArray_Block_3.$Closure$17<$T>)this).m = m;
                ((x10.array.DistArray_Block_3.$Closure$17<$T>)this).n = n;
                ((x10.array.DistArray_Block_3.$Closure$17<$T>)this).p = p;
                ((x10.array.DistArray_Block_3.$Closure$17<$T>)this).init = ((x10.core.fun.Fun_0_3)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$18<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$18> $RTT = 
            x10.rtt.StaticFunType.<$Closure$18> make($Closure$18.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_3.$Closure$18<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_3.$Closure$18 $_obj = new x10.array.DistArray_Block_3.$Closure$18((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$18(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_3.$Closure$18.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$18 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$99, final long id$100, final long id$101) {
            
            //#line 100 "x10/array/DistArray_Block_3.x10"
            final $T t$109370 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 100 "x10/array/DistArray_Block_3.x10"
            return t$109370;
        }
        
        public $Closure$18(final x10.rtt.Type $T) {
            x10.array.DistArray_Block_3.$Closure$18.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$19<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$19> $RTT = 
            x10.rtt.StaticFunType.<$Closure$19> make($Closure$19.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_3.$Closure$19<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_3.$Closure$19 $_obj = new x10.array.DistArray_Block_3.$Closure$19((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$19(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_3.$Closure$19.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$19 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$102, final long id$103, final long id$104) {
            
            //#line 114 "x10/array/DistArray_Block_3.x10"
            final $T t$109372 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 114 "x10/array/DistArray_Block_3.x10"
            return t$109372;
        }
        
        public $Closure$19(final x10.rtt.Type $T) {
            x10.array.DistArray_Block_3.$Closure$19.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
}


