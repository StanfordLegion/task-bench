package x10.array;

@x10.runtime.impl.java.X10Generated
public class LocalState_BB3<$S> extends x10.array.LocalState<$S> implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<LocalState_BB3> $RTT = 
        x10.rtt.NamedType.<LocalState_BB3> make("x10.array.LocalState_BB3",
                                                LocalState_BB3.class,
                                                1,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.array.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $S; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$S> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.LocalState_BB3<$S> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.LocalState.$_deserialize_body($_obj, $deserializer);
        $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
        $_obj.dist = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.LocalState_BB3 $_obj = new x10.array.LocalState_BB3((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$S);
        $serializer.write(this.dist);
        
    }
    
    // constructor just for allocation
    public LocalState_BB3(final java.lang.System[] $dummy, final x10.rtt.Type $S) {
        super($dummy, $S);
        x10.array.LocalState_BB3.$initParams(this, $S);
        
    }
    
    private x10.rtt.Type $S;
    
    // initializer of type parameters
    public static void $initParams(final LocalState_BB3 $this, final x10.rtt.Type $S) {
        $this.$S = $S;
        
    }
    // synthetic type for parameter mangling
    public static final class __1$1x10$array$LocalState_BB3$$S$2 {}
    

    
    //#line 286 "x10/array/DistArray_BlockBlock_3.x10"
    public x10.array.Dist_BlockBlock_3 dist;
    
    
    //#line 288 "x10/array/DistArray_BlockBlock_3.x10"
    // creation method for java code (1-phase java constructor)
    public LocalState_BB3(final x10.rtt.Type $S, final x10.lang.PlaceGroup pg, final x10.core.Rail<$S> data, final long size, final x10.array.Dist_BlockBlock_3 d, __1$1x10$array$LocalState_BB3$$S$2 $dummy) {
        this((java.lang.System[]) null, $S);
        x10$array$LocalState_BB3$$init$S(pg, data, size, d, (x10.array.LocalState_BB3.__1$1x10$array$LocalState_BB3$$S$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.LocalState_BB3<$S> x10$array$LocalState_BB3$$init$S(final x10.lang.PlaceGroup pg, final x10.core.Rail<$S> data, final long size, final x10.array.Dist_BlockBlock_3 d, __1$1x10$array$LocalState_BB3$$S$2 $dummy) {
         {
            
            //#line 290 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.LocalState this$107104 = ((x10.array.LocalState)(this));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$107104).pg = ((x10.lang.PlaceGroup)(pg));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$107104).rail = ((x10.core.Rail)(data));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$107104).size = size;
            
            //#line 288 "x10/array/DistArray_BlockBlock_3.x10"
            
            
            //#line 291 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.LocalState_BB3<$S>)this).dist = ((x10.array.Dist_BlockBlock_3)(d));
        }
        return this;
    }
    
    
    
    //#line 294 "x10/array/DistArray_BlockBlock_3.x10"
    public static <$S>x10.array.LocalState_BB3 make__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$LocalState_BB3$$S$2(final x10.rtt.Type $S, final x10.lang.PlaceGroup pg, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$S> init) {
        
        //#line 295 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 globalSpace = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
        
        //#line 295 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107431 = ((m) - (((long)(1L))));
        
        //#line 295 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107432 = ((n) - (((long)(1L))));
        
        //#line 295 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107433 = ((p) - (((long)(1L))));
        
        //#line 295 "x10/array/DistArray_BlockBlock_3.x10"
        globalSpace.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), t$107431, t$107432, t$107433);
        
        //#line 296 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.Dist_BlockBlock_3 dist = ((x10.array.Dist_BlockBlock_3)(new x10.array.Dist_BlockBlock_3((java.lang.System[]) null)));
        
        //#line 296 "x10/array/DistArray_BlockBlock_3.x10"
        dist.x10$array$Dist_BlockBlock_3$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.array.DenseIterationSpace_3)(globalSpace)));
        
        //#line 298 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.core.Rail data;
        
        //#line 299 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107309 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
        
        //#line 299 "x10/array/DistArray_BlockBlock_3.x10"
        final boolean t$107340 = t$107309.isEmpty$O();
        
        //#line 299 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107340) {
            
            //#line 300 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.core.Rail t$107310 = ((x10.core.Rail)(new x10.core.Rail<$S>($S)));
            
            //#line 300 "x10/array/DistArray_BlockBlock_3.x10"
            data = ((x10.core.Rail)(t$107310));
        } else {
            
            //#line 302 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107311 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 302 "x10/array/DistArray_BlockBlock_3.x10"
            final long low1 = t$107311.min$O((long)(0L));
            
            //#line 303 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107312 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 303 "x10/array/DistArray_BlockBlock_3.x10"
            final long hi1 = t$107312.max$O((long)(0L));
            
            //#line 304 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107313 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 304 "x10/array/DistArray_BlockBlock_3.x10"
            final long low2 = t$107313.min$O((long)(1L));
            
            //#line 305 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107314 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 305 "x10/array/DistArray_BlockBlock_3.x10"
            final long hi2 = t$107314.max$O((long)(1L));
            
            //#line 307 "x10/array/DistArray_BlockBlock_3.x10"
            final long hi3 = ((p) - (((long)(1L))));
            
            //#line 308 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107315 = ((hi1) - (((long)(low1))));
            
            //#line 308 "x10/array/DistArray_BlockBlock_3.x10"
            final long localSize1 = ((t$107315) + (((long)(1L))));
            
            //#line 309 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107316 = ((hi2) - (((long)(low2))));
            
            //#line 309 "x10/array/DistArray_BlockBlock_3.x10"
            final long localSize2 = ((t$107316) + (((long)(1L))));
            
            //#line 311 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107317 = ((localSize1) * (((long)(localSize2))));
            
            //#line 311 "x10/array/DistArray_BlockBlock_3.x10"
            final long dataSize = ((t$107317) * (((long)(p))));
            
            //#line 312 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.core.Rail t$107318 = ((x10.core.Rail)(x10.core.Rail.<$S>makeUnsafe($S, ((long)(dataSize)), false)));
            
            //#line 312 "x10/array/DistArray_BlockBlock_3.x10"
            data = ((x10.core.Rail)(t$107318));
            
            //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
            long i$107426 = low1;
            
            //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
            for (;
                 true;
                 ) {
                
                //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
                final boolean t$107428 = ((i$107426) <= (((long)(hi1))));
                
                //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
                if (!(t$107428)) {
                    
                    //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
                    break;
                }
                
                //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                long i$107418 = low2;
                
                //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                    final boolean t$107420 = ((i$107418) <= (((long)(hi2))));
                    
                    //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                    if (!(t$107420)) {
                        
                        //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                        break;
                    }
                    
                    //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                    long i$107411 = 0L;
                    
                    //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                        final boolean t$107413 = ((i$107411) <= (((long)(hi3))));
                        
                        //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                        if (!(t$107413)) {
                            
                            //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                            break;
                        }
                        
                        //#line 316 "x10/array/DistArray_BlockBlock_3.x10"
                        final long t$107401 = ((i$107418) - (((long)(low2))));
                        
                        //#line 316 "x10/array/DistArray_BlockBlock_3.x10"
                        final long t$107402 = ((i$107426) - (((long)(low1))));
                        
                        //#line 316 "x10/array/DistArray_BlockBlock_3.x10"
                        final long t$107403 = ((localSize2) * (((long)(t$107402))));
                        
                        //#line 316 "x10/array/DistArray_BlockBlock_3.x10"
                        final long t$107404 = ((t$107401) + (((long)(t$107403))));
                        
                        //#line 316 "x10/array/DistArray_BlockBlock_3.x10"
                        final long t$107405 = ((p) * (((long)(t$107404))));
                        
                        //#line 316 "x10/array/DistArray_BlockBlock_3.x10"
                        final long offset$107406 = ((i$107411) + (((long)(t$107405))));
                        
                        //#line 317 "x10/array/DistArray_BlockBlock_3.x10"
                        final $S t$107407 = (($S)((($S)
                                                    ((x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$S>)init).$apply(x10.core.Long.$box(i$107426), x10.rtt.Types.LONG, x10.core.Long.$box(i$107418), x10.rtt.Types.LONG, x10.core.Long.$box(i$107411), x10.rtt.Types.LONG))));
                        
                        //#line 317 "x10/array/DistArray_BlockBlock_3.x10"
                        ((x10.core.Rail<$S>)data).$set__1x10$lang$Rail$$T$G((long)(offset$107406), (($S)(t$107407)));
                        
                        //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                        final long t$107410 = ((i$107411) + (((long)(1L))));
                        
                        //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                        i$107411 = t$107410;
                    }
                    
                    //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107417 = ((i$107418) + (((long)(1L))));
                    
                    //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                    i$107418 = t$107417;
                }
                
                //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
                final long t$107425 = ((i$107426) + (((long)(1L))));
                
                //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
                i$107426 = t$107425;
            }
        }
        
        //#line 322 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.LocalState_BB3 alloc$106891 = ((x10.array.LocalState_BB3)(new x10.array.LocalState_BB3<$S>((java.lang.System[]) null, $S)));
        
        //#line 322 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107434 = ((m) * (((long)(n))));
        
        //#line 322 "x10/array/DistArray_BlockBlock_3.x10"
        alloc$106891.x10$array$LocalState_BB3$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.Rail)(data)), t$107434, ((x10.array.Dist_BlockBlock_3)(dist)), (x10.array.LocalState_BB3.__1$1x10$array$LocalState_BB3$$S$2) null);
        
        //#line 322 "x10/array/DistArray_BlockBlock_3.x10"
        return alloc$106891;
    }
    
    
    //#line 285 "x10/array/DistArray_BlockBlock_3.x10"
    final public x10.array.LocalState_BB3 x10$array$LocalState_BB3$$this$x10$array$LocalState_BB3() {
        
        //#line 285 "x10/array/DistArray_BlockBlock_3.x10"
        return x10.array.LocalState_BB3.this;
    }
    
    
    //#line 285 "x10/array/DistArray_BlockBlock_3.x10"
    final public void __fieldInitializers_x10_array_LocalState_BB3() {
        
    }
}

