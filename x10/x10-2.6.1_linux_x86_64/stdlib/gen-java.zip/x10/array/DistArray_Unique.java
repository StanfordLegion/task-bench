package x10.array;


/**
 * Implementation of DistArray that has exactly one element at each 
 * place in its PlaceGroup such that element i is stored at the
 * ith place as computed by the {@link x10.lang.PlaceGroup#indexOf(Place)}.
 */
@x10.runtime.impl.java.X10Generated
final public class DistArray_Unique<$T> extends x10.array.DistArray<$T> implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray_Unique> $RTT = 
        x10.rtt.NamedType.<DistArray_Unique> make("x10.array.DistArray_Unique",
                                                  DistArray_Unique.class,
                                                  1,
                                                  new x10.rtt.Type[] {
                                                      x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                                      x10.rtt.ParameterizedType.make(x10.array.DistArray.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                  });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Unique<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray_Unique $_obj = new x10.array.DistArray_Unique((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        
    }
    
    // constructor just for allocation
    public DistArray_Unique(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.DistArray_Unique.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        if (t1.equals(x10.rtt.Types.LONG)) { return $apply$G(x10.core.Long.$unbox(a1)); }
        if (t1.equals(x10.lang.Point.$RTT)) { return $apply$G((x10.lang.Point)a1); }
        throw new java.lang.Error("dispatch mechanism not completely implemented for contra-variant types.");
    }
    
    // bridge for method abstract public x10.array.DistArray[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.DistArray).rank()}, v:T){}:T{self==v}
    public $T $set__1x10$array$DistArray$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$DistArray_Unique$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray_Unique $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$array$DistArray_Unique$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$array$DistArray_Unique$$T$2 {}
    

    
    
    //#line 24 "x10/array/DistArray_Unique.x10"
    final public long rank$O() {
        
        //#line 24 "x10/array/DistArray_Unique.x10"
        return 1L;
    }
    
    
    //#line 29 "x10/array/DistArray_Unique.x10"
    /**
     * Construct a zero-initialized DistArray_Unique object over Place.places()
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Unique(final x10.rtt.Type $T) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Unique$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Unique<$T> x10$array$DistArray_Unique$$init$S() {
         {
            
            //#line 30 "x10/array/DistArray_Unique.x10"
            final x10.lang.PlaceGroup t$109734 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 30 "x10/array/DistArray_Unique.x10"
            /*this.*/x10$array$DistArray_Unique$$init$S(t$109734);
        }
        return this;
    }
    
    
    
    //#line 36 "x10/array/DistArray_Unique.x10"
    /**
     * Construct a zero-initialized DistArray_Unique object over the given PlaceGroup
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Unique(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Unique$$init$S(pg);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Unique<$T> x10$array$DistArray_Unique$$init$S(final x10.lang.PlaceGroup pg) {
         {
            
            //#line 37 "x10/array/DistArray_Unique.x10"
            final x10.core.fun.Fun_0_0 t$109789 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_Unique.$Closure$20<$T>($T, pg)));
            
            //#line 35 . "x10/lang/PlaceGroup.x10"
            final long t$109794 = pg.numPlaces$O();
            
            //#line 37 "x10/array/DistArray_Unique.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$109789)), t$109794, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 36 "x10/array/DistArray_Unique.x10"
            
        }
        return this;
    }
    
    
    
    //#line 45 "x10/array/DistArray_Unique.x10"
    /**
     * Construct a DistArray_Unique object over Place.places() using the
     * given initialization function.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Unique(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, __0$1x10$array$DistArray_Unique$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Unique$$init$S(init, (x10.array.DistArray_Unique.__0$1x10$array$DistArray_Unique$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Unique<$T> x10$array$DistArray_Unique$$init$S(final x10.core.fun.Fun_0_0<$T> init, __0$1x10$array$DistArray_Unique$$T$2 $dummy) {
         {
            
            //#line 46 "x10/array/DistArray_Unique.x10"
            final x10.lang.PlaceGroup t$109737 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 46 "x10/array/DistArray_Unique.x10"
            /*this.*/x10$array$DistArray_Unique$$init$S(t$109737, ((x10.core.fun.Fun_0_0)(init)), (x10.array.DistArray_Unique.__1$1x10$array$DistArray_Unique$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 53 "x10/array/DistArray_Unique.x10"
    /**
     * Construct a DistArray_Unique object using the given PlaceGroup and
     * initialization function.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Unique(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<$T> init, __1$1x10$array$DistArray_Unique$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Unique$$init$S(pg, init, (x10.array.DistArray_Unique.__1$1x10$array$DistArray_Unique$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Unique<$T> x10$array$DistArray_Unique$$init$S(final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<$T> init, __1$1x10$array$DistArray_Unique$$T$2 $dummy) {
         {
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            final x10.core.fun.Fun_0_0 t$109796 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_Unique.$Closure$21<$T>($T, init, pg, (x10.array.DistArray_Unique.$Closure$21.__0$1x10$array$DistArray_Unique$$Closure$21$$T$2) null)));
            
            //#line 35 . "x10/lang/PlaceGroup.x10"
            final long t$109802 = pg.numPlaces$O();
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$109796)), t$109802, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 53 "x10/array/DistArray_Unique.x10"
            
        }
        return this;
    }
    
    
    
    //#line 62 "x10/array/DistArray_Unique.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the global iteration space (valid indices) of the DistArray.
     * @return an IterationSpace for the DistArray
     */
    public x10.array.DenseIterationSpace_1 globalIndices() {
        
        //#line 63 "x10/array/DistArray_Unique.x10"
        final x10.array.DenseIterationSpace_1 alloc$109683 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
        
        //#line 63 "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup this$109804 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$109805 = this$109804.numPlaces$O();
        
        //#line 63 "x10/array/DistArray_Unique.x10"
        final long t$109806 = ((t$109805) - (((long)(1L))));
        
        //#line 63 "x10/array/DistArray_Unique.x10"
        alloc$109683.x10$array$DenseIterationSpace_1$$init$S(((long)(0L)), t$109806);
        
        //#line 63 "x10/array/DistArray_Unique.x10"
        return alloc$109683;
    }
    
    
    //#line 71 "x10/array/DistArray_Unique.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the local iteration space (valid indices) of the DistArray at the current Place.
     * @return an IterationSpace for the Array
     */
    public x10.array.DenseIterationSpace_1 localIndices() {
        
        //#line 72 "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup t$109743 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 72 "x10/array/DistArray_Unique.x10"
        final long idx = t$109743.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 73 "x10/array/DistArray_Unique.x10"
        final x10.array.DenseIterationSpace_1 alloc$109684 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
        
        //#line 73 "x10/array/DistArray_Unique.x10"
        alloc$109684.x10$array$DenseIterationSpace_1$$init$S(((long)(idx)), ((long)(idx)));
        
        //#line 73 "x10/array/DistArray_Unique.x10"
        return alloc$109684;
    }
    
    
    //#line 85 "x10/array/DistArray_Unique.x10"
    /**
     * Return the Place which contains the data for the argument
     * index or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param i the index to lookup
     * @return the Place where i is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if i is not contained in globalIndices
     */
    public x10.lang.Place place(final long i) {
        
        //#line 85 "x10/array/DistArray_Unique.x10"
        boolean t$109745 = ((i) >= (((long)(0L))));
        
        //#line 85 "x10/array/DistArray_Unique.x10"
        if (t$109745) {
            
            //#line 85 "x10/array/DistArray_Unique.x10"
            final x10.lang.PlaceGroup this$109705 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 35 . "x10/lang/PlaceGroup.x10"
            final long t$109744 = this$109705.numPlaces$O();
            
            //#line 85 "x10/array/DistArray_Unique.x10"
            t$109745 = ((i) < (((long)(t$109744))));
        }
        
        //#line 85 "x10/array/DistArray_Unique.x10"
        x10.lang.Place t$109748 =  null;
        
        //#line 85 "x10/array/DistArray_Unique.x10"
        if (t$109745) {
            
            //#line 85 "x10/array/DistArray_Unique.x10"
            final x10.lang.PlaceGroup t$109746 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 85 "x10/array/DistArray_Unique.x10"
            t$109748 = t$109746.$apply((long)(i));
        } else {
            
            //#line 85 "x10/array/DistArray_Unique.x10"
            t$109748 = x10.lang.Place.get$INVALID_PLACE();
        }
        
        //#line 85 "x10/array/DistArray_Unique.x10"
        return t$109748;
    }
    
    
    //#line 97 "x10/array/DistArray_Unique.x10"
    /**
     * Return the Place which contains the data for the argument
     * Point or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param p the Point to lookup
     * @return the Place where p is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if p is not contained in globalIndices
     */
    public x10.lang.Place place(final x10.lang.Point p) {
        
        //#line 97 "x10/array/DistArray_Unique.x10"
        final long t$109750 = p.$apply$O((long)(0L));
        
        //#line 97 "x10/array/DistArray_Unique.x10"
        final x10.lang.Place t$109751 = this.place((long)(t$109750));
        
        //#line 97 "x10/array/DistArray_Unique.x10"
        return t$109751;
    }
    
    
    //#line 107 "x10/array/DistArray_Unique.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * 
     * @param i the given index in the first dimension
     * @return the element of this array corresponding to the given index.
     * @see #set(T, Long)
     */
    public $T $apply$G(final long i) {
        
        //#line 108 "x10/array/DistArray_Unique.x10"
        final x10.array.DistArray_Unique this$109814 = ((x10.array.DistArray_Unique)(this));
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup t$109807 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$109814).placeGroup));
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        final long t$109808 = t$109807.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        final boolean t$109809 = ((long) t$109808) != ((long) i);
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        if (t$109809) {
            
            //#line 160 . "x10/array/DistArray_Unique.x10"
            boolean t$109810 = ((i) < (((long)(0L))));
            
            //#line 160 . "x10/array/DistArray_Unique.x10"
            if (!(t$109810)) {
                
                //#line 160 . "x10/array/DistArray_Unique.x10"
                final x10.lang.PlaceGroup this$109811 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$109814).placeGroup));
                
                //#line 35 .. "x10/lang/PlaceGroup.x10"
                final long t$109812 = this$109811.numPlaces$O();
                
                //#line 160 . "x10/array/DistArray_Unique.x10"
                t$109810 = ((i) >= (((long)(t$109812))));
            }
            
            //#line 160 . "x10/array/DistArray_Unique.x10"
            if (t$109810) {
                
                //#line 160 . "x10/array/DistArray_Unique.x10"
                x10.array.DistArray.raiseBoundsError((long)(i));
            }
            
            //#line 161 . "x10/array/DistArray_Unique.x10"
            x10.array.DistArray.raisePlaceError((long)(i));
        }
        
        //#line 109 "x10/array/DistArray_Unique.x10"
        final x10.core.Rail t$109758 = ((x10.core.Rail)(this.raw));
        
        //#line 109 "x10/array/DistArray_Unique.x10"
        final $T t$109759 = (($T)(((x10.core.Rail<$T>)t$109758).$apply$G((long)(0L))));
        
        //#line 109 "x10/array/DistArray_Unique.x10"
        return t$109759;
    }
    
    
    //#line 119 "x10/array/DistArray_Unique.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point p) {
        
        //#line 119 "x10/array/DistArray_Unique.x10"
        final x10.array.DistArray_Unique this$109713 = ((x10.array.DistArray_Unique)(this));
        
        //#line 119 "x10/array/DistArray_Unique.x10"
        final long i$109712 = p.$apply$O((long)(0L));
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup t$109816 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$109713).placeGroup));
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        final long t$109817 = t$109816.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        final boolean t$109818 = ((long) t$109817) != ((long) i$109712);
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        if (t$109818) {
            
            //#line 160 .. "x10/array/DistArray_Unique.x10"
            boolean t$109819 = ((i$109712) < (((long)(0L))));
            
            //#line 160 .. "x10/array/DistArray_Unique.x10"
            if (!(t$109819)) {
                
                //#line 160 .. "x10/array/DistArray_Unique.x10"
                final x10.lang.PlaceGroup this$109820 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$109713).placeGroup));
                
                //#line 35 ... "x10/lang/PlaceGroup.x10"
                final long t$109821 = this$109820.numPlaces$O();
                
                //#line 160 .. "x10/array/DistArray_Unique.x10"
                t$109819 = ((i$109712) >= (((long)(t$109821))));
            }
            
            //#line 160 .. "x10/array/DistArray_Unique.x10"
            if (t$109819) {
                
                //#line 160 .. "x10/array/DistArray_Unique.x10"
                x10.array.DistArray.raiseBoundsError((long)(i$109712));
            }
            
            //#line 161 .. "x10/array/DistArray_Unique.x10"
            x10.array.DistArray.raisePlaceError((long)(i$109712));
        }
        
        //#line 109 . "x10/array/DistArray_Unique.x10"
        final x10.core.Rail t$109766 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$109713).raw));
        
        //#line 109 . "x10/array/DistArray_Unique.x10"
        final $T t$109767 = (($T)(((x10.core.Rail<$T>)t$109766).$apply$G((long)(0L))));
        
        //#line 119 "x10/array/DistArray_Unique.x10"
        return t$109767;
    }
    
    
    //#line 131 "x10/array/DistArray_Unique.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long)
     */
    public $T $set__1x10$array$DistArray_Unique$$T$G(final long i, final $T v) {
        
        //#line 132 "x10/array/DistArray_Unique.x10"
        final x10.array.DistArray_Unique this$109831 = ((x10.array.DistArray_Unique)(this));
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup t$109824 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$109831).placeGroup));
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        final long t$109825 = t$109824.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        final boolean t$109826 = ((long) t$109825) != ((long) i);
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        if (t$109826) {
            
            //#line 160 . "x10/array/DistArray_Unique.x10"
            boolean t$109827 = ((i) < (((long)(0L))));
            
            //#line 160 . "x10/array/DistArray_Unique.x10"
            if (!(t$109827)) {
                
                //#line 160 . "x10/array/DistArray_Unique.x10"
                final x10.lang.PlaceGroup this$109828 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$109831).placeGroup));
                
                //#line 35 .. "x10/lang/PlaceGroup.x10"
                final long t$109829 = this$109828.numPlaces$O();
                
                //#line 160 . "x10/array/DistArray_Unique.x10"
                t$109827 = ((i) >= (((long)(t$109829))));
            }
            
            //#line 160 . "x10/array/DistArray_Unique.x10"
            if (t$109827) {
                
                //#line 160 . "x10/array/DistArray_Unique.x10"
                x10.array.DistArray.raiseBoundsError((long)(i));
            }
            
            //#line 161 . "x10/array/DistArray_Unique.x10"
            x10.array.DistArray.raisePlaceError((long)(i));
        }
        
        //#line 133 "x10/array/DistArray_Unique.x10"
        final x10.core.Rail t$109774 = ((x10.core.Rail)(this.raw));
        
        //#line 133 "x10/array/DistArray_Unique.x10"
        ((x10.core.Rail<$T>)t$109774).$set__1x10$lang$Rail$$T$G((long)(0L), (($T)(v)));
        
        //#line 134 "x10/array/DistArray_Unique.x10"
        return v;
    }
    
    
    //#line 146 "x10/array/DistArray_Unique.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    public $T $set__1x10$array$DistArray_Unique$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 146 "x10/array/DistArray_Unique.x10"
        final x10.array.DistArray_Unique this$109726 = ((x10.array.DistArray_Unique)(this));
        
        //#line 146 "x10/array/DistArray_Unique.x10"
        final long i$109724 = p.$apply$O((long)(0L));
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup t$109833 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$109726).placeGroup));
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        final long t$109834 = t$109833.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        final boolean t$109835 = ((long) t$109834) != ((long) i$109724);
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        if (t$109835) {
            
            //#line 160 .. "x10/array/DistArray_Unique.x10"
            boolean t$109836 = ((i$109724) < (((long)(0L))));
            
            //#line 160 .. "x10/array/DistArray_Unique.x10"
            if (!(t$109836)) {
                
                //#line 160 .. "x10/array/DistArray_Unique.x10"
                final x10.lang.PlaceGroup this$109837 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$109726).placeGroup));
                
                //#line 35 ... "x10/lang/PlaceGroup.x10"
                final long t$109838 = this$109837.numPlaces$O();
                
                //#line 160 .. "x10/array/DistArray_Unique.x10"
                t$109836 = ((i$109724) >= (((long)(t$109838))));
            }
            
            //#line 160 .. "x10/array/DistArray_Unique.x10"
            if (t$109836) {
                
                //#line 160 .. "x10/array/DistArray_Unique.x10"
                x10.array.DistArray.raiseBoundsError((long)(i$109724));
            }
            
            //#line 161 .. "x10/array/DistArray_Unique.x10"
            x10.array.DistArray.raisePlaceError((long)(i$109724));
        }
        
        //#line 133 . "x10/array/DistArray_Unique.x10"
        final x10.core.Rail t$109781 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$109726).raw));
        
        //#line 133 . "x10/array/DistArray_Unique.x10"
        ((x10.core.Rail<$T>)t$109781).$set__1x10$lang$Rail$$T$G((long)(0L), (($T)(v)));
        
        //#line 146 "x10/array/DistArray_Unique.x10"
        return (($T)
                 v);
    }
    
    
    //#line 148 "x10/array/DistArray_Unique.x10"
    public x10.core.Rail getPatch(final x10.array.IterationSpace space) {
        
        //#line 149 "x10/array/DistArray_Unique.x10"
        final java.lang.UnsupportedOperationException t$109782 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException("getPatch not supported for DistArray_Unique")));
        
        //#line 149 "x10/array/DistArray_Unique.x10"
        throw t$109782;
    }
    
    
    //#line 157 "x10/array/DistArray_Unique.x10"
    private void validateIndex(final long i) {
        
        //#line 159 "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup t$109783 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 159 "x10/array/DistArray_Unique.x10"
        final long t$109784 = t$109783.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 159 "x10/array/DistArray_Unique.x10"
        final boolean t$109788 = ((long) t$109784) != ((long) i);
        
        //#line 159 "x10/array/DistArray_Unique.x10"
        if (t$109788) {
            
            //#line 160 "x10/array/DistArray_Unique.x10"
            boolean t$109786 = ((i) < (((long)(0L))));
            
            //#line 160 "x10/array/DistArray_Unique.x10"
            if (!(t$109786)) {
                
                //#line 160 "x10/array/DistArray_Unique.x10"
                final x10.lang.PlaceGroup this$109732 = ((x10.lang.PlaceGroup)(this.placeGroup));
                
                //#line 35 . "x10/lang/PlaceGroup.x10"
                final long t$109785 = this$109732.numPlaces$O();
                
                //#line 160 "x10/array/DistArray_Unique.x10"
                t$109786 = ((i) >= (((long)(t$109785))));
            }
            
            //#line 160 "x10/array/DistArray_Unique.x10"
            if (t$109786) {
                
                //#line 160 "x10/array/DistArray_Unique.x10"
                x10.array.DistArray.raiseBoundsError((long)(i));
            }
            
            //#line 161 "x10/array/DistArray_Unique.x10"
            x10.array.DistArray.raisePlaceError((long)(i));
        }
    }
    
    public static <$T>void validateIndex$P__1$1x10$array$DistArray_Unique$$T$2(final x10.rtt.Type $T, final long i, final x10.array.DistArray_Unique<$T> DistArray_Unique) {
        ((x10.array.DistArray_Unique<$T>)DistArray_Unique).validateIndex((long)(i));
    }
    
    
    //#line 22 "x10/array/DistArray_Unique.x10"
    final public x10.array.DistArray_Unique x10$array$DistArray_Unique$$this$x10$array$DistArray_Unique() {
        
        //#line 22 "x10/array/DistArray_Unique.x10"
        return x10.array.DistArray_Unique.this;
    }
    
    
    //#line 22 "x10/array/DistArray_Unique.x10"
    final public void __fieldInitializers_x10_array_DistArray_Unique() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$20<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$20> $RTT = 
            x10.rtt.StaticFunType.<$Closure$20> make($Closure$20.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Unique.$Closure$20<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Unique.$Closure$20 $_obj = new x10.array.DistArray_Unique.$Closure$20((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$20(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Unique.$Closure$20.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$20 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public x10.array.LocalState $apply() {
            
            //#line 37 "x10/array/DistArray_Unique.x10"
            final x10.array.LocalState alloc$109790 = ((x10.array.LocalState)(new x10.array.LocalState<$T>((java.lang.System[]) null, $T)));
            
            //#line 37 "x10/array/DistArray_Unique.x10"
            final x10.core.Rail rail$109792 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(1L)))));
            
            //#line 37 "x10/array/DistArray_Unique.x10"
            final long size$109793 = this.pg.numPlaces$O();
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$T>)alloc$109790).pg = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$T>)alloc$109790).rail = ((x10.core.Rail)(rail$109792));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$T>)alloc$109790).size = size$109793;
            
            //#line 37 "x10/array/DistArray_Unique.x10"
            return alloc$109790;
        }
        
        public x10.lang.PlaceGroup pg;
        
        public $Closure$20(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg) {
            x10.array.DistArray_Unique.$Closure$20.$initParams(this, $T);
             {
                ((x10.array.DistArray_Unique.$Closure$20<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$21<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$21> $RTT = 
            x10.rtt.StaticFunType.<$Closure$21> make($Closure$21.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Unique.$Closure$21<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Unique.$Closure$21 $_obj = new x10.array.DistArray_Unique.$Closure$21((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$21(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Unique.$Closure$21.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$21 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$array$DistArray_Unique$$Closure$21$$T$2 {}
        
    
        
        public x10.array.LocalState $apply() {
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            final x10.array.LocalState alloc$109797 = ((x10.array.LocalState)(new x10.array.LocalState<$T>((java.lang.System[]) null, $T)));
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            final $T t$109799 = (($T)(((x10.core.fun.Fun_0_0<$T>)this.init).$apply$G()));
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            final x10.core.Rail rail$109800 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(1L)), t$109799, (x10.core.Rail.__1x10$lang$Rail$$T) null)));
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            final long size$109801 = this.pg.numPlaces$O();
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$T>)alloc$109797).pg = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$T>)alloc$109797).rail = ((x10.core.Rail)(rail$109800));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$T>)alloc$109797).size = size$109801;
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            return alloc$109797;
        }
        
        public x10.core.fun.Fun_0_0<$T> init;
        public x10.lang.PlaceGroup pg;
        
        public $Closure$21(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, final x10.lang.PlaceGroup pg, __0$1x10$array$DistArray_Unique$$Closure$21$$T$2 $dummy) {
            x10.array.DistArray_Unique.$Closure$21.$initParams(this, $T);
             {
                ((x10.array.DistArray_Unique.$Closure$21<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.array.DistArray_Unique.$Closure$21<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
            }
        }
        
    }
    
}

