package x10.array;


/**
 * Implementation of 3-dimensional Array using row-major ordering.
 */
@x10.runtime.impl.java.X10Generated
final public class Array_3<$T> extends x10.array.Array<$T> implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Array_3> $RTT = 
        x10.rtt.NamedType.<Array_3> make("x10.array.Array_3",
                                         Array_3.class,
                                         1,
                                         new x10.rtt.Type[] {
                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                             x10.rtt.ParameterizedType.make(x10.array.Array.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.Array_3<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        $_obj.numElems_3 = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array_3 $_obj = new x10.array.Array_3((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        $serializer.write(this.numElems_3);
        
    }
    
    // constructor just for allocation
    public Array_3(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.Array_3.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
        
    }
    
    // bridge for method abstract public x10.array.Array[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.Array).rank()}, v:T){}:T{self==v}
    public $T $set__1x10$array$Array$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$Array_3$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final Array_3 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __3x10$array$Array_3$$T {}
    // synthetic type for parameter mangling
    public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_3$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __0$1x10$array$Array_3$$T$2 {}
    
    // properties
    
    //#line 25 "x10/array/Array_3.x10"
    /**
         * The number of elements in rank 1 (indexed 0..(numElems_1-1))
         */
    public long numElems_1;
    
    //#line 30 "x10/array/Array_3.x10"
    /**
         * The number of elements in rank 2 (indexed 0..(numElems_2-1)).
         */
    public long numElems_2;
    
    //#line 35 "x10/array/Array_3.x10"
    /**
         * The number of elements in rank 3 (indexed 0..(numElems_3-1)).
         */
    public long numElems_3;
    

    
    
    //#line 41 "x10/array/Array_3.x10"
    /**
     * @return the rank (dimensionality) of the Array
     */
    final public long rank$O() {
        
        //#line 41 "x10/array/Array_3.x10"
        return 3L;
    }
    
    
    //#line 47 "x10/array/Array_3.x10"
    /**
     * Construct a 3-dimensional array with indices [0..m-1][0..n-1][0..p-1] 
     * whose elements are zero-initialized.
     */
    // creation method for java code (1-phase java constructor)
    public Array_3(final x10.rtt.Type $T, final long m, final long n, final long p) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_3$$init$S(m, n, p);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_3<$T> x10$array$Array_3$$init$S(final long m, final long n, final long p) {
         {
            
            //#line 214 . "x10/array/Array_3.x10"
            boolean t$100544 = ((m) < (((long)(0L))));
            
            //#line 214 . "x10/array/Array_3.x10"
            if (!(t$100544)) {
                
                //#line 214 . "x10/array/Array_3.x10"
                t$100544 = ((n) < (((long)(0L))));
            }
            
            //#line 214 . "x10/array/Array_3.x10"
            boolean t$100545 = t$100544;
            
            //#line 214 . "x10/array/Array_3.x10"
            if (!(t$100544)) {
                
                //#line 214 . "x10/array/Array_3.x10"
                t$100545 = ((p) < (((long)(0L))));
            }
            
            //#line 214 . "x10/array/Array_3.x10"
            if (t$100545) {
                
                //#line 214 . "x10/array/Array_3.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 215 . "x10/array/Array_3.x10"
            final long t$100547 = ((m) * (((long)(n))));
            
            //#line 215 . "x10/array/Array_3.x10"
            final long t$100548 = ((t$100547) * (((long)(p))));
            
            //#line 48 "x10/array/Array_3.x10"
            /*super.*/x10$array$Array$$init$S(t$100548, ((boolean)(true)));
            
            //#line 49 "x10/array/Array_3.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            
        }
        return this;
    }
    
    
    
    //#line 56 "x10/array/Array_3.x10"
    /**
     * Construct a 3-dimensional array with indices [0..m-1][0..n-1][0..p-1] 
     * whose elements are initialized to init.
     */
    // creation method for java code (1-phase java constructor)
    public Array_3(final x10.rtt.Type $T, final long m, final long n, final long p, final $T init, __3x10$array$Array_3$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_3$$init$S(m, n, p, init, (x10.array.Array_3.__3x10$array$Array_3$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_3<$T> x10$array$Array_3$$init$S(final long m, final long n, final long p, final $T init, __3x10$array$Array_3$$T $dummy) {
         {
            
            //#line 214 . "x10/array/Array_3.x10"
            boolean t$100553 = ((m) < (((long)(0L))));
            
            //#line 214 . "x10/array/Array_3.x10"
            if (!(t$100553)) {
                
                //#line 214 . "x10/array/Array_3.x10"
                t$100553 = ((n) < (((long)(0L))));
            }
            
            //#line 214 . "x10/array/Array_3.x10"
            boolean t$100554 = t$100553;
            
            //#line 214 . "x10/array/Array_3.x10"
            if (!(t$100553)) {
                
                //#line 214 . "x10/array/Array_3.x10"
                t$100554 = ((p) < (((long)(0L))));
            }
            
            //#line 214 . "x10/array/Array_3.x10"
            if (t$100554) {
                
                //#line 214 . "x10/array/Array_3.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 215 . "x10/array/Array_3.x10"
            final long t$100556 = ((m) * (((long)(n))));
            
            //#line 215 . "x10/array/Array_3.x10"
            final long t$100557 = ((t$100556) * (((long)(p))));
            
            //#line 57 "x10/array/Array_3.x10"
            /*super.*/x10$array$Array$$init$S(t$100557, ((boolean)(false)));
            
            //#line 58 "x10/array/Array_3.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            
            
            //#line 59 "x10/array/Array_3.x10"
            final x10.core.Rail t$100368 = ((x10.core.Rail)(this.raw));
            
            //#line 59 "x10/array/Array_3.x10"
            ((x10.core.Rail<$T>)t$100368).fill__0x10$lang$Rail$$T((($T)(init)));
        }
        return this;
    }
    
    
    
    //#line 66 "x10/array/Array_3.x10"
    /**
     * Construct a 3-dimensional array with indices [0..m-1][0..n-1][0..p-1] 
     * whose elements are initialized to the value returned by the init closure for each index.
     */
    // creation method for java code (1-phase java constructor)
    public Array_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_3$$init$S(m, n, p, init, (x10.array.Array_3.__3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_3<$T> x10$array$Array_3$$init$S(final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_3$$T$2 $dummy) {
         {
            
            //#line 214 . "x10/array/Array_3.x10"
            boolean t$100594 = ((m) < (((long)(0L))));
            
            //#line 214 . "x10/array/Array_3.x10"
            if (!(t$100594)) {
                
                //#line 214 . "x10/array/Array_3.x10"
                t$100594 = ((n) < (((long)(0L))));
            }
            
            //#line 214 . "x10/array/Array_3.x10"
            boolean t$100595 = t$100594;
            
            //#line 214 . "x10/array/Array_3.x10"
            if (!(t$100594)) {
                
                //#line 214 . "x10/array/Array_3.x10"
                t$100595 = ((p) < (((long)(0L))));
            }
            
            //#line 214 . "x10/array/Array_3.x10"
            if (t$100595) {
                
                //#line 214 . "x10/array/Array_3.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 215 . "x10/array/Array_3.x10"
            final long t$100597 = ((m) * (((long)(n))));
            
            //#line 215 . "x10/array/Array_3.x10"
            final long t$100598 = ((t$100597) * (((long)(p))));
            
            //#line 67 "x10/array/Array_3.x10"
            /*super.*/x10$array$Array$$init$S(t$100598, ((boolean)(false)));
            
            //#line 68 "x10/array/Array_3.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            
            
            //#line 69 "x10/array/Array_3.x10"
            final long i$99771max$100600 = ((m) - (((long)(1L))));
            
            //#line 69 "x10/array/Array_3.x10"
            long i$100588 = 0L;
            
            //#line 69 "x10/array/Array_3.x10"
            for (;
                 true;
                 ) {
                
                //#line 69 "x10/array/Array_3.x10"
                final boolean t$100590 = ((i$100588) <= (((long)(i$99771max$100600))));
                
                //#line 69 "x10/array/Array_3.x10"
                if (!(t$100590)) {
                    
                    //#line 69 "x10/array/Array_3.x10"
                    break;
                }
                
                //#line 70 "x10/array/Array_3.x10"
                final long i$99753max$100584 = ((n) - (((long)(1L))));
                
                //#line 70 "x10/array/Array_3.x10"
                long i$100581 = 0L;
                
                //#line 70 "x10/array/Array_3.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 70 "x10/array/Array_3.x10"
                    final boolean t$100583 = ((i$100581) <= (((long)(i$99753max$100584))));
                    
                    //#line 70 "x10/array/Array_3.x10"
                    if (!(t$100583)) {
                        
                        //#line 70 "x10/array/Array_3.x10"
                        break;
                    }
                    
                    //#line 71 "x10/array/Array_3.x10"
                    final long i$99735max$100577 = ((p) - (((long)(1L))));
                    
                    //#line 71 "x10/array/Array_3.x10"
                    long i$100574 = 0L;
                    
                    //#line 71 "x10/array/Array_3.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 71 "x10/array/Array_3.x10"
                        final boolean t$100576 = ((i$100574) <= (((long)(i$99735max$100577))));
                        
                        //#line 71 "x10/array/Array_3.x10"
                        if (!(t$100576)) {
                            
                            //#line 71 "x10/array/Array_3.x10"
                            break;
                        }
                        
                        //#line 72 "x10/array/Array_3.x10"
                        final x10.core.Rail t$100559 = ((x10.core.Rail)(this.raw));
                        
                        //#line 72 "x10/array/Array_3.x10"
                        final x10.array.Array_3 this$100560 = ((x10.array.Array_3)(this));
                        
                        //#line 151 . "x10/array/Array_3.x10"
                        final long t$100564 = ((x10.array.Array_3<$T>)this$100560).numElems_3;
                        
                        //#line 151 . "x10/array/Array_3.x10"
                        final long t$100565 = ((x10.array.Array_3<$T>)this$100560).numElems_2;
                        
                        //#line 151 . "x10/array/Array_3.x10"
                        final long t$100566 = ((i$100588) * (((long)(t$100565))));
                        
                        //#line 151 . "x10/array/Array_3.x10"
                        final long t$100567 = ((i$100581) + (((long)(t$100566))));
                        
                        //#line 151 . "x10/array/Array_3.x10"
                        final long t$100568 = ((t$100564) * (((long)(t$100567))));
                        
                        //#line 151 . "x10/array/Array_3.x10"
                        final long t$100569 = ((i$100574) + (((long)(t$100568))));
                        
                        //#line 72 "x10/array/Array_3.x10"
                        final $T t$100570 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T>)init).$apply(x10.core.Long.$box(i$100588), x10.rtt.Types.LONG, x10.core.Long.$box(i$100581), x10.rtt.Types.LONG, x10.core.Long.$box(i$100574), x10.rtt.Types.LONG))));
                        
                        //#line 72 "x10/array/Array_3.x10"
                        ((x10.core.Rail<$T>)t$100559).$set__1x10$lang$Rail$$T$G((long)(t$100569), (($T)(t$100570)));
                        
                        //#line 71 "x10/array/Array_3.x10"
                        final long t$100573 = ((i$100574) + (((long)(1L))));
                        
                        //#line 71 "x10/array/Array_3.x10"
                        i$100574 = t$100573;
                    }
                    
                    //#line 70 "x10/array/Array_3.x10"
                    final long t$100580 = ((i$100581) + (((long)(1L))));
                    
                    //#line 70 "x10/array/Array_3.x10"
                    i$100581 = t$100580;
                }
                
                //#line 69 "x10/array/Array_3.x10"
                final long t$100587 = ((i$100588) + (((long)(1L))));
                
                //#line 69 "x10/array/Array_3.x10"
                i$100588 = t$100587;
            }
        }
        return this;
    }
    
    
    
    //#line 82 "x10/array/Array_3.x10"
    /**
     * Construct a new 3-dimensional array by copying all elements of src
     * @param src The source array to copy
     */
    // creation method for java code (1-phase java constructor)
    public Array_3(final x10.rtt.Type $T, final x10.array.Array_3<$T> src, __0$1x10$array$Array_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_3$$init$S(src, (x10.array.Array_3.__0$1x10$array$Array_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_3<$T> x10$array$Array_3$$init$S(final x10.array.Array_3<$T> src, __0$1x10$array$Array_3$$T$2 $dummy) {
         {
            
            //#line 83 "x10/array/Array_3.x10"
            final x10.array.Array this$99866 = ((x10.array.Array)(this));
            
            //#line 83 "x10/array/Array_3.x10"
            final x10.core.Rail t$100397 = ((x10.core.Rail)(((x10.array.Array<$T>)src).raw));
            
            //#line 83 "x10/array/Array_3.x10"
            final x10.core.Rail r$99865 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((x10.core.Rail)(t$100397)), (x10.core.Rail.__0$1x10$lang$Rail$$T$2) null)));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$100601 = ((x10.core.Rail<$T>)r$99865).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$99866).size = t$100601;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$99866).raw = ((x10.core.Rail)(r$99865));
            
            //#line 84 "x10/array/Array_3.x10"
            final long t$100602 = ((x10.array.Array_3<$T>)src).numElems_1;
            
            //#line 84 "x10/array/Array_3.x10"
            final long t$100603 = ((x10.array.Array_3<$T>)src).numElems_2;
            
            //#line 84 "x10/array/Array_3.x10"
            final long t$100604 = ((x10.array.Array_3<$T>)src).numElems_3;
            
            //#line 84 "x10/array/Array_3.x10"
            this.numElems_1 = t$100602;
            this.numElems_2 = t$100603;
            this.numElems_3 = t$100604;
            
        }
        return this;
    }
    
    
    
    //#line 88 "x10/array/Array_3.x10"
    // creation method for java code (1-phase java constructor)
    public Array_3(final x10.rtt.Type $T, final x10.core.Rail<$T> r, final long m, final long n, final long p, __0$1x10$array$Array_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_3$$init$S(r, m, n, p, (x10.array.Array_3.__0$1x10$array$Array_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_3<$T> x10$array$Array_3$$init$S(final x10.core.Rail<$T> r, final long m, final long n, final long p, __0$1x10$array$Array_3$$T$2 $dummy) {
         {
            
            //#line 89 "x10/array/Array_3.x10"
            final x10.array.Array this$99872 = ((x10.array.Array)(this));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$100606 = ((x10.core.Rail<$T>)r).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$99872).size = t$100606;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$99872).raw = ((x10.core.Rail)(r));
            
            //#line 90 "x10/array/Array_3.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            
        }
        return this;
    }
    
    
    
    //#line 96 "x10/array/Array_3.x10"
    /**
     * Construct an Array_3 view over an existing Rail
     */
    public static <$T>x10.array.Array_3 makeView__0$1x10$array$Array_3$$T$2(final x10.rtt.Type $T, final x10.core.Rail<$T> r, final long m, final long n, final long p) {
        
        //#line 97 "x10/array/Array_3.x10"
        final long t$100403 = ((n) * (((long)(m))));
        
        //#line 97 "x10/array/Array_3.x10"
        final long size = ((t$100403) * (((long)(p))));
        
        //#line 98 "x10/array/Array_3.x10"
        final long t$100404 = ((x10.core.Rail<$T>)r).size;
        
        //#line 98 "x10/array/Array_3.x10"
        final boolean t$100414 = ((long) size) != ((long) t$100404);
        
        //#line 98 "x10/array/Array_3.x10"
        if (t$100414) {
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100405 = (("size mismatch: ") + ((x10.core.Long.$box(m))));
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100406 = ((t$100405) + (" * "));
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100407 = ((t$100406) + ((x10.core.Long.$box(n))));
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100408 = ((t$100407) + (" * "));
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100409 = ((t$100408) + ((x10.core.Long.$box(p))));
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100410 = ((t$100409) + (" != "));
            
            //#line 98 "x10/array/Array_3.x10"
            final long t$100411 = ((x10.core.Rail<$T>)r).size;
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100412 = ((t$100410) + ((x10.core.Long.$box(t$100411))));
            
            //#line 98 "x10/array/Array_3.x10"
            final x10.lang.IllegalOperationException t$100413 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$100412)));
            
            //#line 98 "x10/array/Array_3.x10"
            throw t$100413;
        }
        
        //#line 99 "x10/array/Array_3.x10"
        final x10.array.Array_3 alloc$99732 = ((x10.array.Array_3)(new x10.array.Array_3<$T>((java.lang.System[]) null, $T)));
        
        //#line 99 "x10/array/Array_3.x10"
        alloc$99732.x10$array$Array_3$$init$S(((x10.core.Rail)(r)), ((long)(m)), ((long)(n)), ((long)(p)), (x10.array.Array_3.__0$1x10$array$Array_3$$T$2) null);
        
        //#line 99 "x10/array/Array_3.x10"
        return alloc$99732;
    }
    
    
    //#line 108 "x10/array/Array_3.x10"
    /**
     * Return the string representation of this array.
     * 
     * @return the string representation of this array.
     */
    public java.lang.String toString() {
        
        //#line 109 "x10/array/Array_3.x10"
        final java.lang.String t$100415 = this.toString((long)(10L));
        
        //#line 109 "x10/array/Array_3.x10"
        return t$100415;
    }
    
    
    //#line 118 "x10/array/Array_3.x10"
    /**
     * Return the string representation of this array.
     *
     * @param limit maximum number of elements to print
     * @return the string representation of this array.
     */
    public java.lang.String toString(final long limit) {
        
        //#line 119 "x10/array/Array_3.x10"
        final x10.util.StringBuilder sb = ((x10.util.StringBuilder)(new x10.util.StringBuilder((java.lang.System[]) null)));
        
        //#line 119 "x10/array/Array_3.x10"
        sb.x10$util$StringBuilder$$init$S();
        
        //#line 120 "x10/array/Array_3.x10"
        sb.add(((java.lang.String)("[")));
        
        //#line 121 "x10/array/Array_3.x10"
        long printed = 0L;
        
        //#line 122 "x10/array/Array_3.x10"
        final long t$100665 = this.numElems_1;
        
        //#line 122 "x10/array/Array_3.x10"
        final long i$99825max$100666 = ((t$100665) - (((long)(1L))));
        
        //#line 122 "x10/array/Array_3.x10"
        long i$100661 = 0L;
        
        //#line 122 "x10/array/Array_3.x10"
        outer$100662: 
        //#line 122 "x10/array/Array_3.x10"
        for (;
             true;
             ) {
            
            //#line 122 "x10/array/Array_3.x10"
            final boolean t$100664 = ((i$100661) <= (((long)(i$99825max$100666))));
            
            //#line 122 "x10/array/Array_3.x10"
            if (!(t$100664)) {
                
                //#line 122 "x10/array/Array_3.x10"
                break;
            }
            
            //#line 123 "x10/array/Array_3.x10"
            final long t$100656 = this.numElems_2;
            
            //#line 123 "x10/array/Array_3.x10"
            final long i$99807max$100657 = ((t$100656) - (((long)(1L))));
            
            //#line 123 "x10/array/Array_3.x10"
            long i$100653 = 0L;
            
            //#line 123 "x10/array/Array_3.x10"
            for (;
                 true;
                 ) {
                
                //#line 123 "x10/array/Array_3.x10"
                final boolean t$100655 = ((i$100653) <= (((long)(i$99807max$100657))));
                
                //#line 123 "x10/array/Array_3.x10"
                if (!(t$100655)) {
                    
                    //#line 123 "x10/array/Array_3.x10"
                    break;
                }
                
                //#line 124 "x10/array/Array_3.x10"
                final long t$100643 = this.numElems_3;
                
                //#line 124 "x10/array/Array_3.x10"
                final long i$99789max$100644 = ((t$100643) - (((long)(1L))));
                
                //#line 124 "x10/array/Array_3.x10"
                long i$100640 = 0L;
                
                //#line 124 "x10/array/Array_3.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 124 "x10/array/Array_3.x10"
                    final boolean t$100642 = ((i$100640) <= (((long)(i$99789max$100644))));
                    
                    //#line 124 "x10/array/Array_3.x10"
                    if (!(t$100642)) {
                        
                        //#line 124 "x10/array/Array_3.x10"
                        break;
                    }
                    
                    //#line 125 "x10/array/Array_3.x10"
                    final boolean t$100608 = ((long) i$100640) != ((long) 0L);
                    
                    //#line 125 "x10/array/Array_3.x10"
                    if (t$100608) {
                        
                        //#line 125 "x10/array/Array_3.x10"
                        sb.add(((java.lang.String)(", ")));
                    }
                    
                    //#line 126 "x10/array/Array_3.x10"
                    final x10.array.Array_3 this$100609 = ((x10.array.Array_3)(this));
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    boolean t$100613 = ((i$100661) < (((long)(0L))));
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    if (!(t$100613)) {
                        
                        //#line 164 . "x10/array/Array_3.x10"
                        final long t$100614 = ((x10.array.Array_3<$T>)this$100609).numElems_1;
                        
                        //#line 164 . "x10/array/Array_3.x10"
                        t$100613 = ((i$100661) >= (((long)(t$100614))));
                    }
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    boolean t$100615 = t$100613;
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    if (!(t$100613)) {
                        
                        //#line 164 . "x10/array/Array_3.x10"
                        t$100615 = ((i$100653) < (((long)(0L))));
                    }
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    boolean t$100616 = t$100615;
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    if (!(t$100615)) {
                        
                        //#line 165 . "x10/array/Array_3.x10"
                        final long t$100617 = ((x10.array.Array_3<$T>)this$100609).numElems_2;
                        
                        //#line 164 . "x10/array/Array_3.x10"
                        t$100616 = ((i$100653) >= (((long)(t$100617))));
                    }
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    boolean t$100618 = t$100616;
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    if (!(t$100616)) {
                        
                        //#line 164 . "x10/array/Array_3.x10"
                        t$100618 = ((i$100640) < (((long)(0L))));
                    }
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    boolean t$100619 = t$100618;
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    if (!(t$100618)) {
                        
                        //#line 166 . "x10/array/Array_3.x10"
                        final long t$100620 = ((x10.array.Array_3<$T>)this$100609).numElems_3;
                        
                        //#line 164 . "x10/array/Array_3.x10"
                        t$100619 = ((i$100640) >= (((long)(t$100620))));
                    }
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    if (t$100619) {
                        
                        //#line 167 . "x10/array/Array_3.x10"
                        x10.array.Array.raiseBoundsError((long)(i$100661), (long)(i$100653), (long)(i$100640));
                    }
                    
                    //#line 169 . "x10/array/Array_3.x10"
                    final x10.core.Rail r$100622 = ((x10.core.Rail)(((x10.array.Array<$T>)this$100609).raw));
                    
                    //#line 151 .. "x10/array/Array_3.x10"
                    final long t$100626 = ((x10.array.Array_3<$T>)this$100609).numElems_3;
                    
                    //#line 151 .. "x10/array/Array_3.x10"
                    final long t$100627 = ((x10.array.Array_3<$T>)this$100609).numElems_2;
                    
                    //#line 151 .. "x10/array/Array_3.x10"
                    final long t$100628 = ((i$100661) * (((long)(t$100627))));
                    
                    //#line 151 .. "x10/array/Array_3.x10"
                    final long t$100629 = ((i$100653) + (((long)(t$100628))));
                    
                    //#line 151 .. "x10/array/Array_3.x10"
                    final long t$100630 = ((t$100626) * (((long)(t$100629))));
                    
                    //#line 169 . "x10/array/Array_3.x10"
                    final long i$100631 = ((i$100640) + (((long)(t$100630))));
                    
                    //#line 38 .. "x10/lang/Unsafe.x10"
                    final $T t$100632 = (($T)(((x10.core.Rail<$T>)r$100622).$apply$G((long)(i$100631))));
                    
                    //#line 126 "x10/array/Array_3.x10"
                    sb.add(((java.lang.Object)(t$100632)));
                    
                    //#line 127 "x10/array/Array_3.x10"
                    final long t$100634 = ((printed) + (((long)(1L))));
                    
                    //#line 127 "x10/array/Array_3.x10"
                    final long t$100635 = printed = t$100634;
                    
                    //#line 127 "x10/array/Array_3.x10"
                    final boolean t$100636 = ((t$100635) > (((long)(limit))));
                    
                    //#line 127 "x10/array/Array_3.x10"
                    if (t$100636) {
                        
                        //#line 127 "x10/array/Array_3.x10"
                        break outer$100662;
                    }
                    
                    //#line 124 "x10/array/Array_3.x10"
                    final long t$100639 = ((i$100640) + (((long)(1L))));
                    
                    //#line 124 "x10/array/Array_3.x10"
                    i$100640 = t$100639;
                }
                
                //#line 129 "x10/array/Array_3.x10"
                final long t$100645 = this.numElems_2;
                
                //#line 129 "x10/array/Array_3.x10"
                final long t$100646 = ((t$100645) - (((long)(1L))));
                
                //#line 129 "x10/array/Array_3.x10"
                final boolean t$100647 = ((long) i$100653) == ((long) t$100646);
                
                //#line 129 "x10/array/Array_3.x10"
                java.lang.String t$100648 =  null;
                
                //#line 129 "x10/array/Array_3.x10"
                if (t$100647) {
                    
                    //#line 129 "x10/array/Array_3.x10"
                    t$100648 = ";; ";
                } else {
                    
                    //#line 129 "x10/array/Array_3.x10"
                    t$100648 = "; ";
                }
                
                //#line 129 "x10/array/Array_3.x10"
                sb.add(((java.lang.String)(t$100648)));
                
                //#line 123 "x10/array/Array_3.x10"
                final long t$100652 = ((i$100653) + (((long)(1L))));
                
                //#line 123 "x10/array/Array_3.x10"
                i$100653 = t$100652;
            }
            
            //#line 122 "x10/array/Array_3.x10"
            final long t$100660 = ((i$100661) + (((long)(1L))));
            
            //#line 122 "x10/array/Array_3.x10"
            i$100661 = t$100660;
        }
        
        //#line 132 "x10/array/Array_3.x10"
        final long t$100459 = this.size;
        
        //#line 132 "x10/array/Array_3.x10"
        final boolean t$100464 = ((limit) < (((long)(t$100459))));
        
        //#line 132 "x10/array/Array_3.x10"
        if (t$100464) {
            
            //#line 133 "x10/array/Array_3.x10"
            final long t$100460 = this.size;
            
            //#line 133 "x10/array/Array_3.x10"
            final long t$100461 = ((t$100460) - (((long)(limit))));
            
            //#line 133 "x10/array/Array_3.x10"
            final java.lang.String t$100462 = (("...(omitted ") + ((x10.core.Long.$box(t$100461))));
            
            //#line 133 "x10/array/Array_3.x10"
            final java.lang.String t$100463 = ((t$100462) + (" elements)"));
            
            //#line 133 "x10/array/Array_3.x10"
            sb.add(((java.lang.String)(t$100463)));
        }
        
        //#line 135 "x10/array/Array_3.x10"
        sb.add(((java.lang.String)("]")));
        
        //#line 136 "x10/array/Array_3.x10"
        final java.lang.String t$100465 = sb.toString();
        
        //#line 136 "x10/array/Array_3.x10"
        return t$100465;
    }
    
    
    //#line 142 "x10/array/Array_3.x10"
    /**
     * @return an IterationSpace containing all valid Points for indexing this Array.
     */
    public x10.array.DenseIterationSpace_3 indices() {
        
        //#line 143 "x10/array/Array_3.x10"
        final x10.array.DenseIterationSpace_3 alloc$99733 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
        
        //#line 143 "x10/array/Array_3.x10"
        final long t$100667 = this.numElems_1;
        
        //#line 143 "x10/array/Array_3.x10"
        final long t$100668 = ((t$100667) - (((long)(1L))));
        
        //#line 143 "x10/array/Array_3.x10"
        final long t$100669 = this.numElems_2;
        
        //#line 143 "x10/array/Array_3.x10"
        final long t$100670 = ((t$100669) - (((long)(1L))));
        
        //#line 143 "x10/array/Array_3.x10"
        final long t$100671 = this.numElems_3;
        
        //#line 143 "x10/array/Array_3.x10"
        final long t$100672 = ((t$100671) - (((long)(1L))));
        
        //#line 143 "x10/array/Array_3.x10"
        alloc$99733.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), t$100668, t$100670, t$100672);
        
        //#line 143 "x10/array/Array_3.x10"
        return alloc$99733;
    }
    
    
    //#line 150 "x10/array/Array_3.x10"
    /**
     * Map a 3-D (i,j,k) index into a 1-D index into the backing Rail
     * returned by raw(). Uses row-major ordering.
     */
    public long offset$O(final long i, final long j, final long k) {
        
        //#line 151 "x10/array/Array_3.x10"
        final long t$100474 = this.numElems_3;
        
        //#line 151 "x10/array/Array_3.x10"
        final long t$100472 = this.numElems_2;
        
        //#line 151 "x10/array/Array_3.x10"
        final long t$100473 = ((i) * (((long)(t$100472))));
        
        //#line 151 "x10/array/Array_3.x10"
        final long t$100475 = ((j) + (((long)(t$100473))));
        
        //#line 151 "x10/array/Array_3.x10"
        final long t$100476 = ((t$100474) * (((long)(t$100475))));
        
        //#line 151 "x10/array/Array_3.x10"
        final long t$100477 = ((k) + (((long)(t$100476))));
        
        //#line 151 "x10/array/Array_3.x10"
        return t$100477;
    }
    
    
    //#line 163 "x10/array/Array_3.x10"
    /**
     * Return the element of this array corresponding to the given triple of indices.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @return the element of this array corresponding to the given triple of indices.
     * @see #set(T, Long, Long, Long)
     */
    public $T $apply$G(final long i, final long j, final long k) {
        
        //#line 164 "x10/array/Array_3.x10"
        boolean t$100479 = ((i) < (((long)(0L))));
        
        //#line 164 "x10/array/Array_3.x10"
        if (!(t$100479)) {
            
            //#line 164 "x10/array/Array_3.x10"
            final long t$100478 = this.numElems_1;
            
            //#line 164 "x10/array/Array_3.x10"
            t$100479 = ((i) >= (((long)(t$100478))));
        }
        
        //#line 164 "x10/array/Array_3.x10"
        boolean t$100480 = t$100479;
        
        //#line 164 "x10/array/Array_3.x10"
        if (!(t$100479)) {
            
            //#line 164 "x10/array/Array_3.x10"
            t$100480 = ((j) < (((long)(0L))));
        }
        
        //#line 164 "x10/array/Array_3.x10"
        boolean t$100482 = t$100480;
        
        //#line 164 "x10/array/Array_3.x10"
        if (!(t$100480)) {
            
            //#line 165 "x10/array/Array_3.x10"
            final long t$100481 = this.numElems_2;
            
            //#line 164 "x10/array/Array_3.x10"
            t$100482 = ((j) >= (((long)(t$100481))));
        }
        
        //#line 164 "x10/array/Array_3.x10"
        boolean t$100483 = t$100482;
        
        //#line 164 "x10/array/Array_3.x10"
        if (!(t$100482)) {
            
            //#line 164 "x10/array/Array_3.x10"
            t$100483 = ((k) < (((long)(0L))));
        }
        
        //#line 164 "x10/array/Array_3.x10"
        boolean t$100485 = t$100483;
        
        //#line 164 "x10/array/Array_3.x10"
        if (!(t$100483)) {
            
            //#line 166 "x10/array/Array_3.x10"
            final long t$100484 = this.numElems_3;
            
            //#line 164 "x10/array/Array_3.x10"
            t$100485 = ((k) >= (((long)(t$100484))));
        }
        
        //#line 164 "x10/array/Array_3.x10"
        if (t$100485) {
            
            //#line 167 "x10/array/Array_3.x10"
            x10.array.Array.raiseBoundsError((long)(i), (long)(j), (long)(k));
        }
        
        //#line 169 "x10/array/Array_3.x10"
        final x10.core.Rail r$100320 = ((x10.core.Rail)(this.raw));
        
        //#line 169 "x10/array/Array_3.x10"
        final x10.array.Array_3 this$100318 = ((x10.array.Array_3)(this));
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100489 = ((x10.array.Array_3<$T>)this$100318).numElems_3;
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100487 = ((x10.array.Array_3<$T>)this$100318).numElems_2;
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100488 = ((i) * (((long)(t$100487))));
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100490 = ((j) + (((long)(t$100488))));
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100491 = ((t$100489) * (((long)(t$100490))));
        
        //#line 169 "x10/array/Array_3.x10"
        final long i$100321 = ((k) + (((long)(t$100491))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$100492 = (($T)(((x10.core.Rail<$T>)r$100320).$apply$G((long)(i$100321))));
        
        //#line 169 "x10/array/Array_3.x10"
        return t$100492;
    }
    
    
    //#line 179 "x10/array/Array_3.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point p) {
        
        //#line 179 "x10/array/Array_3.x10"
        final x10.array.Array_3 this$100326 = ((x10.array.Array_3)(this));
        
        //#line 179 "x10/array/Array_3.x10"
        final long i$100323 = p.$apply$O((long)(0L));
        
        //#line 179 "x10/array/Array_3.x10"
        final long j$100324 = p.$apply$O((long)(1L));
        
        //#line 179 "x10/array/Array_3.x10"
        final long k$100325 = p.$apply$O((long)(2L));
        
        //#line 164 . "x10/array/Array_3.x10"
        boolean t$100494 = ((i$100323) < (((long)(0L))));
        
        //#line 164 . "x10/array/Array_3.x10"
        if (!(t$100494)) {
            
            //#line 164 . "x10/array/Array_3.x10"
            final long t$100493 = ((x10.array.Array_3<$T>)this$100326).numElems_1;
            
            //#line 164 . "x10/array/Array_3.x10"
            t$100494 = ((i$100323) >= (((long)(t$100493))));
        }
        
        //#line 164 . "x10/array/Array_3.x10"
        boolean t$100495 = t$100494;
        
        //#line 164 . "x10/array/Array_3.x10"
        if (!(t$100494)) {
            
            //#line 164 . "x10/array/Array_3.x10"
            t$100495 = ((j$100324) < (((long)(0L))));
        }
        
        //#line 164 . "x10/array/Array_3.x10"
        boolean t$100497 = t$100495;
        
        //#line 164 . "x10/array/Array_3.x10"
        if (!(t$100495)) {
            
            //#line 165 . "x10/array/Array_3.x10"
            final long t$100496 = ((x10.array.Array_3<$T>)this$100326).numElems_2;
            
            //#line 164 . "x10/array/Array_3.x10"
            t$100497 = ((j$100324) >= (((long)(t$100496))));
        }
        
        //#line 164 . "x10/array/Array_3.x10"
        boolean t$100498 = t$100497;
        
        //#line 164 . "x10/array/Array_3.x10"
        if (!(t$100497)) {
            
            //#line 164 . "x10/array/Array_3.x10"
            t$100498 = ((k$100325) < (((long)(0L))));
        }
        
        //#line 164 . "x10/array/Array_3.x10"
        boolean t$100500 = t$100498;
        
        //#line 164 . "x10/array/Array_3.x10"
        if (!(t$100498)) {
            
            //#line 166 . "x10/array/Array_3.x10"
            final long t$100499 = ((x10.array.Array_3<$T>)this$100326).numElems_3;
            
            //#line 164 . "x10/array/Array_3.x10"
            t$100500 = ((k$100325) >= (((long)(t$100499))));
        }
        
        //#line 164 . "x10/array/Array_3.x10"
        if (t$100500) {
            
            //#line 167 . "x10/array/Array_3.x10"
            x10.array.Array.raiseBoundsError((long)(i$100323), (long)(j$100324), (long)(k$100325));
        }
        
        //#line 169 . "x10/array/Array_3.x10"
        final x10.core.Rail r$100332 = ((x10.core.Rail)(((x10.array.Array<$T>)this$100326).raw));
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100504 = ((x10.array.Array_3<$T>)this$100326).numElems_3;
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100502 = ((x10.array.Array_3<$T>)this$100326).numElems_2;
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100503 = ((i$100323) * (((long)(t$100502))));
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100505 = ((j$100324) + (((long)(t$100503))));
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100506 = ((t$100504) * (((long)(t$100505))));
        
        //#line 169 . "x10/array/Array_3.x10"
        final long i$100333 = ((k$100325) + (((long)(t$100506))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$100507 = (($T)(((x10.core.Rail<$T>)r$100332).$apply$G((long)(i$100333))));
        
        //#line 179 "x10/array/Array_3.x10"
        return t$100507;
    }
    
    
    //#line 192 "x10/array/Array_3.x10"
    /**
     * Set the element of this array corresponding to the given triple of indices to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @return the new value of the element of this array corresponding to the given triple of indices.
     * @see #operator(Long, Long, Long)
     */
    public $T $set__3x10$array$Array_3$$T$G(final long i, final long j, final long k, final $T v) {
        
        //#line 193 "x10/array/Array_3.x10"
        boolean t$100509 = ((i) < (((long)(0L))));
        
        //#line 193 "x10/array/Array_3.x10"
        if (!(t$100509)) {
            
            //#line 193 "x10/array/Array_3.x10"
            final long t$100508 = this.numElems_1;
            
            //#line 193 "x10/array/Array_3.x10"
            t$100509 = ((i) >= (((long)(t$100508))));
        }
        
        //#line 193 "x10/array/Array_3.x10"
        boolean t$100510 = t$100509;
        
        //#line 193 "x10/array/Array_3.x10"
        if (!(t$100509)) {
            
            //#line 193 "x10/array/Array_3.x10"
            t$100510 = ((j) < (((long)(0L))));
        }
        
        //#line 193 "x10/array/Array_3.x10"
        boolean t$100512 = t$100510;
        
        //#line 193 "x10/array/Array_3.x10"
        if (!(t$100510)) {
            
            //#line 194 "x10/array/Array_3.x10"
            final long t$100511 = this.numElems_2;
            
            //#line 193 "x10/array/Array_3.x10"
            t$100512 = ((j) >= (((long)(t$100511))));
        }
        
        //#line 193 "x10/array/Array_3.x10"
        boolean t$100513 = t$100512;
        
        //#line 193 "x10/array/Array_3.x10"
        if (!(t$100512)) {
            
            //#line 193 "x10/array/Array_3.x10"
            t$100513 = ((k) < (((long)(0L))));
        }
        
        //#line 193 "x10/array/Array_3.x10"
        boolean t$100515 = t$100513;
        
        //#line 193 "x10/array/Array_3.x10"
        if (!(t$100513)) {
            
            //#line 195 "x10/array/Array_3.x10"
            final long t$100514 = this.numElems_3;
            
            //#line 193 "x10/array/Array_3.x10"
            t$100515 = ((k) >= (((long)(t$100514))));
        }
        
        //#line 193 "x10/array/Array_3.x10"
        if (t$100515) {
            
            //#line 196 "x10/array/Array_3.x10"
            x10.array.Array.raiseBoundsError((long)(i), (long)(j), (long)(k));
        }
        
        //#line 198 "x10/array/Array_3.x10"
        final x10.core.Rail r$100340 = ((x10.core.Rail)(this.raw));
        
        //#line 198 "x10/array/Array_3.x10"
        final x10.array.Array_3 this$100338 = ((x10.array.Array_3)(this));
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100519 = ((x10.array.Array_3<$T>)this$100338).numElems_3;
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100517 = ((x10.array.Array_3<$T>)this$100338).numElems_2;
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100518 = ((i) * (((long)(t$100517))));
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100520 = ((j) + (((long)(t$100518))));
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100521 = ((t$100519) * (((long)(t$100520))));
        
        //#line 198 "x10/array/Array_3.x10"
        final long i$100341 = ((k) + (((long)(t$100521))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$100340).$set__1x10$lang$Rail$$T$G((long)(i$100341), (($T)(v)));
        
        //#line 198 "x10/array/Array_3.x10"
        return (($T)
                 v);
    }
    
    
    //#line 210 "x10/array/Array_3.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    public $T $set__1x10$array$Array_3$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 210 "x10/array/Array_3.x10"
        final x10.array.Array_3 this$100348 = ((x10.array.Array_3)(this));
        
        //#line 210 "x10/array/Array_3.x10"
        final long i$100344 = p.$apply$O((long)(0L));
        
        //#line 210 "x10/array/Array_3.x10"
        final long j$100345 = p.$apply$O((long)(1L));
        
        //#line 210 "x10/array/Array_3.x10"
        final long k$100346 = p.$apply$O((long)(2L));
        
        //#line 193 . "x10/array/Array_3.x10"
        boolean t$100523 = ((i$100344) < (((long)(0L))));
        
        //#line 193 . "x10/array/Array_3.x10"
        if (!(t$100523)) {
            
            //#line 193 . "x10/array/Array_3.x10"
            final long t$100522 = ((x10.array.Array_3<$T>)this$100348).numElems_1;
            
            //#line 193 . "x10/array/Array_3.x10"
            t$100523 = ((i$100344) >= (((long)(t$100522))));
        }
        
        //#line 193 . "x10/array/Array_3.x10"
        boolean t$100524 = t$100523;
        
        //#line 193 . "x10/array/Array_3.x10"
        if (!(t$100523)) {
            
            //#line 193 . "x10/array/Array_3.x10"
            t$100524 = ((j$100345) < (((long)(0L))));
        }
        
        //#line 193 . "x10/array/Array_3.x10"
        boolean t$100526 = t$100524;
        
        //#line 193 . "x10/array/Array_3.x10"
        if (!(t$100524)) {
            
            //#line 194 . "x10/array/Array_3.x10"
            final long t$100525 = ((x10.array.Array_3<$T>)this$100348).numElems_2;
            
            //#line 193 . "x10/array/Array_3.x10"
            t$100526 = ((j$100345) >= (((long)(t$100525))));
        }
        
        //#line 193 . "x10/array/Array_3.x10"
        boolean t$100527 = t$100526;
        
        //#line 193 . "x10/array/Array_3.x10"
        if (!(t$100526)) {
            
            //#line 193 . "x10/array/Array_3.x10"
            t$100527 = ((k$100346) < (((long)(0L))));
        }
        
        //#line 193 . "x10/array/Array_3.x10"
        boolean t$100529 = t$100527;
        
        //#line 193 . "x10/array/Array_3.x10"
        if (!(t$100527)) {
            
            //#line 195 . "x10/array/Array_3.x10"
            final long t$100528 = ((x10.array.Array_3<$T>)this$100348).numElems_3;
            
            //#line 193 . "x10/array/Array_3.x10"
            t$100529 = ((k$100346) >= (((long)(t$100528))));
        }
        
        //#line 193 . "x10/array/Array_3.x10"
        if (t$100529) {
            
            //#line 196 . "x10/array/Array_3.x10"
            x10.array.Array.raiseBoundsError((long)(i$100344), (long)(j$100345), (long)(k$100346));
        }
        
        //#line 198 . "x10/array/Array_3.x10"
        final x10.core.Rail r$100354 = ((x10.core.Rail)(((x10.array.Array<$T>)this$100348).raw));
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100533 = ((x10.array.Array_3<$T>)this$100348).numElems_3;
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100531 = ((x10.array.Array_3<$T>)this$100348).numElems_2;
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100532 = ((i$100344) * (((long)(t$100531))));
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100534 = ((j$100345) + (((long)(t$100532))));
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100535 = ((t$100533) * (((long)(t$100534))));
        
        //#line 198 . "x10/array/Array_3.x10"
        final long i$100355 = ((k$100346) + (((long)(t$100535))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$100354).$set__1x10$lang$Rail$$T$G((long)(i$100355), (($T)(v)));
        
        //#line 210 "x10/array/Array_3.x10"
        return (($T)
                 v);
    }
    
    
    //#line 213 "x10/array/Array_3.x10"
    private static long validateSize$O(final long m, final long n, final long p) {
        
        //#line 214 "x10/array/Array_3.x10"
        boolean t$100536 = ((m) < (((long)(0L))));
        
        //#line 214 "x10/array/Array_3.x10"
        if (!(t$100536)) {
            
            //#line 214 "x10/array/Array_3.x10"
            t$100536 = ((n) < (((long)(0L))));
        }
        
        //#line 214 "x10/array/Array_3.x10"
        boolean t$100537 = t$100536;
        
        //#line 214 "x10/array/Array_3.x10"
        if (!(t$100536)) {
            
            //#line 214 "x10/array/Array_3.x10"
            t$100537 = ((p) < (((long)(0L))));
        }
        
        //#line 214 "x10/array/Array_3.x10"
        if (t$100537) {
            
            //#line 214 "x10/array/Array_3.x10"
            x10.array.Array.raiseNegativeArraySizeException();
        }
        
        //#line 215 "x10/array/Array_3.x10"
        final long t$100539 = ((m) * (((long)(n))));
        
        //#line 215 "x10/array/Array_3.x10"
        final long t$100540 = ((t$100539) * (((long)(p))));
        
        //#line 215 "x10/array/Array_3.x10"
        return t$100540;
    }
    
    public static long validateSize$P$O(final long m, final long n, final long p) {
        return x10.array.Array_3.validateSize$O((long)(m), (long)(n), (long)(p));
    }
    
    
    //#line 21 "x10/array/Array_3.x10"
    final public x10.array.Array_3 x10$array$Array_3$$this$x10$array$Array_3() {
        
        //#line 21 "x10/array/Array_3.x10"
        return x10.array.Array_3.this;
    }
    
    
    //#line 21 "x10/array/Array_3.x10"
    final public void __fieldInitializers_x10_array_Array_3() {
        
    }
}

