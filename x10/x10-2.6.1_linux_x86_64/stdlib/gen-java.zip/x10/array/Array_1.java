package x10.array;


/**
 * Implementation of 1-dimensional Array.
 */
@x10.runtime.impl.java.X10Generated
final public class Array_1<$T> extends x10.array.Array<$T> implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Array_1> $RTT = 
        x10.rtt.NamedType.<Array_1> make("x10.array.Array_1",
                                         Array_1.class,
                                         1,
                                         new x10.rtt.Type[] {
                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                             x10.rtt.ParameterizedType.make(x10.array.Array.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.Array_1<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array_1 $_obj = new x10.array.Array_1((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        
    }
    
    // constructor just for allocation
    public Array_1(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.Array_1.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        if (t1.equals(x10.rtt.Types.LONG)) { return $apply$G(x10.core.Long.$unbox(a1)); }
        if (t1.equals(x10.lang.Point.$RTT)) { return $apply$G((x10.lang.Point)a1); }
        throw new java.lang.Error("dispatch mechanism not completely implemented for contra-variant types.");
    }
    
    // bridge for method abstract public x10.array.Array[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.Array).rank()}, v:T){}:T{self==v}
    public $T $set__1x10$array$Array$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$Array_1$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final Array_1 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __1x10$array$Array_1$$T {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Long$3x10$array$Array_1$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __0$1x10$array$Array_1$$T$2 {}
    

    
    
    //#line 24 "x10/array/Array_1.x10"
    /**
     * @return the rank (dimensionality) of the Array
     */
    final public long rank$O() {
        
        //#line 24 "x10/array/Array_1.x10"
        return 1L;
    }
    
    
    //#line 29 "x10/array/Array_1.x10"
    /**
     * Construct a 1-dimensional array with indices 0..n-1 whose elements are zero-initialized.
     */
    // creation method for java code (1-phase java constructor)
    public Array_1(final x10.rtt.Type $T, final long n) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_1$$init$S(n);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_1<$T> x10$array$Array_1$$init$S(final long n) {
         {
            
            //#line 138 . "x10/array/Array_1.x10"
            final boolean t$98237 = ((n) < (((long)(0L))));
            
            //#line 138 . "x10/array/Array_1.x10"
            if (t$98237) {
                
                //#line 138 . "x10/array/Array_1.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 30 "x10/array/Array_1.x10"
            /*super.*/x10$array$Array$$init$S(n, ((boolean)(true)));
            
            //#line 29 "x10/array/Array_1.x10"
            
        }
        return this;
    }
    
    
    
    //#line 36 "x10/array/Array_1.x10"
    /**
     * Construct a 1-dimensional array with indices 0..n-1 whose elements are initialized to init.
     */
    // creation method for java code (1-phase java constructor)
    public Array_1(final x10.rtt.Type $T, final long n, final $T init, __1x10$array$Array_1$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_1$$init$S(n, init, (x10.array.Array_1.__1x10$array$Array_1$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_1<$T> x10$array$Array_1$$init$S(final long n, final $T init, __1x10$array$Array_1$$T $dummy) {
         {
            
            //#line 138 . "x10/array/Array_1.x10"
            final boolean t$98240 = ((n) < (((long)(0L))));
            
            //#line 138 . "x10/array/Array_1.x10"
            if (t$98240) {
                
                //#line 138 . "x10/array/Array_1.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 37 "x10/array/Array_1.x10"
            /*super.*/x10$array$Array$$init$S(n, ((boolean)(false)));
            
            //#line 36 "x10/array/Array_1.x10"
            
            
            //#line 38 "x10/array/Array_1.x10"
            final x10.core.Rail t$98213 = ((x10.core.Rail)(this.raw));
            
            //#line 38 "x10/array/Array_1.x10"
            ((x10.core.Rail<$T>)t$98213).fill__0x10$lang$Rail$$T((($T)(init)));
        }
        return this;
    }
    
    
    
    //#line 45 "x10/array/Array_1.x10"
    /**
     * Construct a 1-dimensional array with indices 0..n-1 whose elements are initialized to 
     * the value computed by the init closure when applied to the element index.
     */
    // creation method for java code (1-phase java constructor)
    public Array_1(final x10.rtt.Type $T, final long n, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __1$1x10$lang$Long$3x10$array$Array_1$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_1$$init$S(n, init, (x10.array.Array_1.__1$1x10$lang$Long$3x10$array$Array_1$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_1<$T> x10$array$Array_1$$init$S(final long n, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __1$1x10$lang$Long$3x10$array$Array_1$$T$2 $dummy) {
         {
            
            //#line 138 . "x10/array/Array_1.x10"
            final boolean t$98251 = ((n) < (((long)(0L))));
            
            //#line 138 . "x10/array/Array_1.x10"
            if (t$98251) {
                
                //#line 138 . "x10/array/Array_1.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 46 "x10/array/Array_1.x10"
            /*super.*/x10$array$Array$$init$S(n, ((boolean)(false)));
            
            //#line 45 "x10/array/Array_1.x10"
            
            
            //#line 47 "x10/array/Array_1.x10"
            final x10.core.Rail rail$98253 = ((x10.core.Rail)(this.raw));
            
            //#line 47 "x10/array/Array_1.x10"
            final long i$97328max$98254 = ((x10.core.Rail<$T>)rail$98253).size;
            
            //#line 47 "x10/array/Array_1.x10"
            long i$98247 = 0L;
            
            //#line 47 "x10/array/Array_1.x10"
            for (;
                 true;
                 ) {
                
                //#line 47 "x10/array/Array_1.x10"
                final boolean t$98249 = ((i$98247) < (((long)(i$97328max$98254))));
                
                //#line 47 "x10/array/Array_1.x10"
                if (!(t$98249)) {
                    
                    //#line 47 "x10/array/Array_1.x10"
                    break;
                }
                
                //#line 48 "x10/array/Array_1.x10"
                final x10.core.Rail t$98242 = ((x10.core.Rail)(this.raw));
                
                //#line 48 "x10/array/Array_1.x10"
                final $T t$98243 = (($T)((($T)
                                           ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)init).$apply(x10.core.Long.$box(i$98247), x10.rtt.Types.LONG))));
                
                //#line 48 "x10/array/Array_1.x10"
                ((x10.core.Rail<$T>)t$98242).$set__1x10$lang$Rail$$T$G((long)(i$98247), (($T)(t$98243)));
                
                //#line 47 "x10/array/Array_1.x10"
                final long t$98246 = ((i$98247) + (((long)(1L))));
                
                //#line 47 "x10/array/Array_1.x10"
                i$98247 = t$98246;
            }
        }
        return this;
    }
    
    
    
    //#line 56 "x10/array/Array_1.x10"
    /**
     * Construct a new 1-dimensional array by copying all elements of src
     * @param src The source array to copy
     */
    // creation method for java code (1-phase java constructor)
    public Array_1(final x10.rtt.Type $T, final x10.array.Array_1<$T> src, __0$1x10$array$Array_1$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_1$$init$S(src, (x10.array.Array_1.__0$1x10$array$Array_1$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_1<$T> x10$array$Array_1$$init$S(final x10.array.Array_1<$T> src, __0$1x10$array$Array_1$$T$2 $dummy) {
         {
            
            //#line 57 "x10/array/Array_1.x10"
            final x10.array.Array this$97359 = ((x10.array.Array)(this));
            
            //#line 57 "x10/array/Array_1.x10"
            final x10.core.Rail t$98222 = ((x10.core.Rail)(((x10.array.Array<$T>)src).raw));
            
            //#line 57 "x10/array/Array_1.x10"
            final x10.core.Rail r$97358 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((x10.core.Rail)(t$98222)), (x10.core.Rail.__0$1x10$lang$Rail$$T$2) null)));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$98255 = ((x10.core.Rail<$T>)r$97358).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$97359).size = t$98255;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$97359).raw = ((x10.core.Rail)(r$97358));
            
            //#line 56 "x10/array/Array_1.x10"
            
        }
        return this;
    }
    
    
    
    //#line 61 "x10/array/Array_1.x10"
    // creation method for java code (1-phase java constructor)
    public Array_1(final x10.rtt.Type $T, final x10.core.Rail<$T> r, __0$1x10$array$Array_1$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_1$$init$S(r, (x10.array.Array_1.__0$1x10$array$Array_1$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_1<$T> x10$array$Array_1$$init$S(final x10.core.Rail<$T> r, __0$1x10$array$Array_1$$T$2 $dummy) {
         {
            
            //#line 62 "x10/array/Array_1.x10"
            final x10.array.Array this$97365 = ((x10.array.Array)(this));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$98257 = ((x10.core.Rail<$T>)r).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$97365).size = t$98257;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$97365).raw = ((x10.core.Rail)(r));
            
            //#line 61 "x10/array/Array_1.x10"
            
        }
        return this;
    }
    
    
    
    //#line 68 "x10/array/Array_1.x10"
    /**
     * Construct an Array_1 view over an existing Rail
     */
    public static <$T>x10.array.Array_1 makeView__0$1x10$array$Array_1$$T$2(final x10.rtt.Type $T, final x10.core.Rail<$T> r) {
        
        //#line 69 "x10/array/Array_1.x10"
        final x10.array.Array_1 alloc$97325 = ((x10.array.Array_1)(new x10.array.Array_1<$T>((java.lang.System[]) null, $T)));
        
        //#line 69 "x10/array/Array_1.x10"
        alloc$97325.x10$array$Array_1$$init$S(((x10.core.Rail)(r)), (x10.array.Array_1.__0$1x10$array$Array_1$$T$2) null);
        
        //#line 69 "x10/array/Array_1.x10"
        return alloc$97325;
    }
    
    
    //#line 78 "x10/array/Array_1.x10"
    /**
     * Return the string representation of this array.
     * 
     * @return the string representation of this array.
     */
    public java.lang.String toString() {
        
        //#line 78 "x10/array/Array_1.x10"
        final x10.core.Rail t$98225 = ((x10.core.Rail)(this.raw));
        
        //#line 78 "x10/array/Array_1.x10"
        final java.lang.String t$98226 = ((x10.core.Rail<$T>)t$98225).toString();
        
        //#line 78 "x10/array/Array_1.x10"
        return t$98226;
    }
    
    
    //#line 84 "x10/array/Array_1.x10"
    /**
     * @return an IterationSpace containing all valid Points for indexing this Array.
     */
    public x10.array.DenseIterationSpace_1 indices() {
        
        //#line 85 "x10/array/Array_1.x10"
        final x10.array.DenseIterationSpace_1 alloc$97326 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
        
        //#line 85 "x10/array/Array_1.x10"
        final long t$98259 = this.size;
        
        //#line 85 "x10/array/Array_1.x10"
        final long t$98260 = ((t$98259) - (((long)(1L))));
        
        //#line 85 "x10/array/Array_1.x10"
        alloc$97326.x10$array$DenseIterationSpace_1$$init$S(((long)(0L)), t$98260);
        
        //#line 85 "x10/array/Array_1.x10"
        return alloc$97326;
    }
    
    
    //#line 95 "x10/array/Array_1.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * 
     * @param i the given index in the first dimension
     * @return the element of this array corresponding to the given index.
     * @see #set(T, Long)
     */
    public $T $apply$G(final long i) {
        
        //#line 97 "x10/array/Array_1.x10"
        final x10.core.Rail t$98229 = ((x10.core.Rail)(this.raw));
        
        //#line 97 "x10/array/Array_1.x10"
        final $T t$98230 = (($T)(((x10.core.Rail<$T>)t$98229).$apply$G((long)(i))));
        
        //#line 97 "x10/array/Array_1.x10"
        return t$98230;
    }
    
    
    //#line 107 "x10/array/Array_1.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point p) {
        
        //#line 107 "x10/array/Array_1.x10"
        final x10.array.Array_1 this$98205 = ((x10.array.Array_1)(this));
        
        //#line 107 "x10/array/Array_1.x10"
        final long i$98204 = p.$apply$O((long)(0L));
        
        //#line 97 . "x10/array/Array_1.x10"
        final x10.core.Rail t$98231 = ((x10.core.Rail)(((x10.array.Array<$T>)this$98205).raw));
        
        //#line 97 . "x10/array/Array_1.x10"
        final $T t$98232 = (($T)(((x10.core.Rail<$T>)t$98231).$apply$G((long)(i$98204))));
        
        //#line 107 "x10/array/Array_1.x10"
        return t$98232;
    }
    
    
    //#line 119 "x10/array/Array_1.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long)
     */
    public $T $set__1x10$array$Array_1$$T$G(final long i, final $T v) {
        
        //#line 121 "x10/array/Array_1.x10"
        final x10.core.Rail t$98233 = ((x10.core.Rail)(this.raw));
        
        //#line 121 "x10/array/Array_1.x10"
        ((x10.core.Rail<$T>)t$98233).$set__1x10$lang$Rail$$T$G((long)(i), (($T)(v)));
        
        //#line 122 "x10/array/Array_1.x10"
        return v;
    }
    
    
    //#line 134 "x10/array/Array_1.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    public $T $set__1x10$array$Array_1$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 134 "x10/array/Array_1.x10"
        final x10.array.Array_1 this$98209 = ((x10.array.Array_1)(this));
        
        //#line 134 "x10/array/Array_1.x10"
        final long i$98207 = p.$apply$O((long)(0L));
        
        //#line 121 . "x10/array/Array_1.x10"
        final x10.core.Rail t$98234 = ((x10.core.Rail)(((x10.array.Array<$T>)this$98209).raw));
        
        //#line 121 . "x10/array/Array_1.x10"
        ((x10.core.Rail<$T>)t$98234).$set__1x10$lang$Rail$$T$G((long)(i$98207), (($T)(v)));
        
        //#line 134 "x10/array/Array_1.x10"
        return (($T)
                 v);
    }
    
    
    //#line 137 "x10/array/Array_1.x10"
    private static long validateSize$O(final long n) {
        
        //#line 138 "x10/array/Array_1.x10"
        final boolean t$98235 = ((n) < (((long)(0L))));
        
        //#line 138 "x10/array/Array_1.x10"
        if (t$98235) {
            
            //#line 138 "x10/array/Array_1.x10"
            x10.array.Array.raiseNegativeArraySizeException();
        }
        
        //#line 139 "x10/array/Array_1.x10"
        return n;
    }
    
    public static long validateSize$P$O(final long n) {
        return x10.array.Array_1.validateSize$O((long)(n));
    }
    
    
    //#line 19 "x10/array/Array_1.x10"
    final public x10.array.Array_1 x10$array$Array_1$$this$x10$array$Array_1() {
        
        //#line 19 "x10/array/Array_1.x10"
        return x10.array.Array_1.this;
    }
    
    
    //#line 19 "x10/array/Array_1.x10"
    final public void __fieldInitializers_x10_array_Array_1() {
        
    }
}

