package x10.array;

/**
 * A DenseIterationSpace_3 represents the rank 3 
 * iteration space of points [min0,min1,min2]..[max0,max1,max2] inclusive.
 */
@x10.runtime.impl.java.X10Generated
final public class DenseIterationSpace_3 extends x10.array.IterationSpace implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DenseIterationSpace_3> $RTT = 
        x10.rtt.NamedType.<DenseIterationSpace_3> make("x10.array.DenseIterationSpace_3",
                                                       DenseIterationSpace_3.class,
                                                       new x10.rtt.Type[] {
                                                           x10.array.IterationSpace.$RTT
                                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_3 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.IterationSpace.$_deserialize_body($_obj, $deserializer);
        $_obj.max0 = $deserializer.readLong();
        $_obj.max1 = $deserializer.readLong();
        $_obj.max2 = $deserializer.readLong();
        $_obj.min0 = $deserializer.readLong();
        $_obj.min1 = $deserializer.readLong();
        $_obj.min2 = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DenseIterationSpace_3 $_obj = new x10.array.DenseIterationSpace_3((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.max0);
        $serializer.write(this.max1);
        $serializer.write(this.max2);
        $serializer.write(this.min0);
        $serializer.write(this.min1);
        $serializer.write(this.min2);
        
    }
    
    // constructor just for allocation
    public DenseIterationSpace_3(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 20 "x10/array/DenseIterationSpace_3.x10"
    public long min0;
    
    //#line 21 "x10/array/DenseIterationSpace_3.x10"
    public long min1;
    
    //#line 22 "x10/array/DenseIterationSpace_3.x10"
    public long min2;
    
    //#line 23 "x10/array/DenseIterationSpace_3.x10"
    public long max0;
    
    //#line 24 "x10/array/DenseIterationSpace_3.x10"
    public long max1;
    
    //#line 25 "x10/array/DenseIterationSpace_3.x10"
    public long max2;
    
    //#line 27 "x10/array/DenseIterationSpace_3.x10"
    private static x10.array.DenseIterationSpace_3 EMPTY;
    
    
    //#line 29 "x10/array/DenseIterationSpace_3.x10"
    // creation method for java code (1-phase java constructor)
    public DenseIterationSpace_3(final long min0, final long min1, final long min2, final long max0, final long max1, final long max2) {
        this((java.lang.System[]) null);
        x10$array$DenseIterationSpace_3$$init$S(min0, min1, min2, max0, max1, max2);
    }
    
    // constructor for non-virtual call
    final public x10.array.DenseIterationSpace_3 x10$array$DenseIterationSpace_3$$init$S(final long min0, final long min1, final long min2, final long max0, final long max1, final long max2) {
         {
            
            //#line 30 "x10/array/DenseIterationSpace_3.x10"
            final x10.array.IterationSpace this$104169 = ((x10.array.IterationSpace)(this));
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104169.rank = 3L;
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104169.rect = true;
            
            //#line 29 "x10/array/DenseIterationSpace_3.x10"
            
            
            //#line 31 "x10/array/DenseIterationSpace_3.x10"
            this.min0 = min0;
            
            //#line 32 "x10/array/DenseIterationSpace_3.x10"
            this.min1 = min1;
            
            //#line 33 "x10/array/DenseIterationSpace_3.x10"
            this.min2 = min2;
            
            //#line 34 "x10/array/DenseIterationSpace_3.x10"
            this.max0 = max0;
            
            //#line 35 "x10/array/DenseIterationSpace_3.x10"
            this.max1 = max1;
            
            //#line 36 "x10/array/DenseIterationSpace_3.x10"
            this.max2 = max2;
        }
        return this;
    }
    
    
    
    //#line 39 "x10/array/DenseIterationSpace_3.x10"
    public x10.array.DenseIterationSpace_4 $times(final x10.lang.LongRange that) {
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final x10.array.DenseIterationSpace_4 alloc$100313 = ((x10.array.DenseIterationSpace_4)(new x10.array.DenseIterationSpace_4((java.lang.System[]) null)));
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104284 = this.min0;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104285 = this.min1;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104286 = this.min2;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104287 = that.min;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104288 = this.max0;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104289 = this.max1;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104290 = this.max2;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104291 = that.max;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        alloc$100313.x10$array$DenseIterationSpace_4$$init$S(((long)(t$104284)), ((long)(t$104285)), ((long)(t$104286)), ((long)(t$104287)), ((long)(t$104288)), ((long)(t$104289)), ((long)(t$104290)), ((long)(t$104291)));
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        return alloc$100313;
    }
    
    
    //#line 43 "x10/array/DenseIterationSpace_3.x10"
    public long min$O(final long i) {
        
        //#line 44 "x10/array/DenseIterationSpace_3.x10"
        final boolean t$104190 = ((long) i) == ((long) 0L);
        
        //#line 44 "x10/array/DenseIterationSpace_3.x10"
        if (t$104190) {
            
            //#line 44 "x10/array/DenseIterationSpace_3.x10"
            final long t$104189 = this.min0;
            
            //#line 44 "x10/array/DenseIterationSpace_3.x10"
            return t$104189;
        }
        
        //#line 45 "x10/array/DenseIterationSpace_3.x10"
        final boolean t$104192 = ((long) i) == ((long) 1L);
        
        //#line 45 "x10/array/DenseIterationSpace_3.x10"
        if (t$104192) {
            
            //#line 45 "x10/array/DenseIterationSpace_3.x10"
            final long t$104191 = this.min1;
            
            //#line 45 "x10/array/DenseIterationSpace_3.x10"
            return t$104191;
        }
        
        //#line 46 "x10/array/DenseIterationSpace_3.x10"
        final boolean t$104194 = ((long) i) == ((long) 2L);
        
        //#line 46 "x10/array/DenseIterationSpace_3.x10"
        if (t$104194) {
            
            //#line 46 "x10/array/DenseIterationSpace_3.x10"
            final long t$104193 = this.min2;
            
            //#line 46 "x10/array/DenseIterationSpace_3.x10"
            return t$104193;
        }
        
        //#line 47 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104195 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
        
        //#line 47 "x10/array/DenseIterationSpace_3.x10"
        final x10.lang.IllegalOperationException t$104196 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104195)));
        
        //#line 47 "x10/array/DenseIterationSpace_3.x10"
        throw t$104196;
    }
    
    
    //#line 50 "x10/array/DenseIterationSpace_3.x10"
    public long max$O(final long i) {
        
        //#line 51 "x10/array/DenseIterationSpace_3.x10"
        final boolean t$104198 = ((long) i) == ((long) 0L);
        
        //#line 51 "x10/array/DenseIterationSpace_3.x10"
        if (t$104198) {
            
            //#line 51 "x10/array/DenseIterationSpace_3.x10"
            final long t$104197 = this.max0;
            
            //#line 51 "x10/array/DenseIterationSpace_3.x10"
            return t$104197;
        }
        
        //#line 52 "x10/array/DenseIterationSpace_3.x10"
        final boolean t$104200 = ((long) i) == ((long) 1L);
        
        //#line 52 "x10/array/DenseIterationSpace_3.x10"
        if (t$104200) {
            
            //#line 52 "x10/array/DenseIterationSpace_3.x10"
            final long t$104199 = this.max1;
            
            //#line 52 "x10/array/DenseIterationSpace_3.x10"
            return t$104199;
        }
        
        //#line 53 "x10/array/DenseIterationSpace_3.x10"
        final boolean t$104202 = ((long) i) == ((long) 2L);
        
        //#line 53 "x10/array/DenseIterationSpace_3.x10"
        if (t$104202) {
            
            //#line 53 "x10/array/DenseIterationSpace_3.x10"
            final long t$104201 = this.max2;
            
            //#line 53 "x10/array/DenseIterationSpace_3.x10"
            return t$104201;
        }
        
        //#line 54 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104203 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
        
        //#line 54 "x10/array/DenseIterationSpace_3.x10"
        final x10.lang.IllegalOperationException t$104204 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104203)));
        
        //#line 54 "x10/array/DenseIterationSpace_3.x10"
        throw t$104204;
    }
    
    
    //#line 57 "x10/array/DenseIterationSpace_3.x10"
    public boolean isEmpty$O() {
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        final long t$104205 = this.max0;
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        final long t$104206 = this.min0;
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        boolean t$104209 = ((t$104205) < (((long)(t$104206))));
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        if (!(t$104209)) {
            
            //#line 57 "x10/array/DenseIterationSpace_3.x10"
            final long t$104207 = this.max1;
            
            //#line 57 "x10/array/DenseIterationSpace_3.x10"
            final long t$104208 = this.min1;
            
            //#line 57 "x10/array/DenseIterationSpace_3.x10"
            t$104209 = ((t$104207) < (((long)(t$104208))));
        }
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        boolean t$104212 = t$104209;
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        if (!(t$104209)) {
            
            //#line 57 "x10/array/DenseIterationSpace_3.x10"
            final long t$104210 = this.max2;
            
            //#line 57 "x10/array/DenseIterationSpace_3.x10"
            final long t$104211 = this.min2;
            
            //#line 57 "x10/array/DenseIterationSpace_3.x10"
            t$104212 = ((t$104210) < (((long)(t$104211))));
        }
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        return t$104212;
    }
    
    
    //#line 59 "x10/array/DenseIterationSpace_3.x10"
    public long size$O() {
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104214 = this.max0;
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104215 = this.min0;
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104216 = ((t$104214) - (((long)(t$104215))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104220 = ((t$104216) + (((long)(1L))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104217 = this.max1;
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104218 = this.min1;
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104219 = ((t$104217) - (((long)(t$104218))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104221 = ((t$104219) + (((long)(1L))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104225 = ((t$104220) * (((long)(t$104221))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104222 = this.max2;
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104223 = this.min2;
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104224 = ((t$104222) - (((long)(t$104223))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104226 = ((t$104224) + (((long)(1L))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104227 = ((t$104225) * (((long)(t$104226))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        return t$104227;
    }
    
    
    //#line 61 "x10/array/DenseIterationSpace_3.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 61 "x10/array/DenseIterationSpace_3.x10"
        final x10.array.DenseIterationSpace_3.DIS3_It alloc$100314 = ((x10.array.DenseIterationSpace_3.DIS3_It)(new x10.array.DenseIterationSpace_3.DIS3_It((java.lang.System[]) null)));
        
        //#line 61 "x10/array/DenseIterationSpace_3.x10"
        alloc$100314.x10$array$DenseIterationSpace_3$DIS3_It$$init$S(this);
        
        //#line 61 "x10/array/DenseIterationSpace_3.x10"
        return alloc$100314;
    }
    
    
    //#line 63 "x10/array/DenseIterationSpace_3.x10"
    @x10.runtime.impl.java.X10Generated
    public static class DIS3_It extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<DIS3_It> $RTT = 
            x10.rtt.NamedType.<DIS3_It> make("x10.array.DenseIterationSpace_3.DIS3_It",
                                             DIS3_It.class,
                                             new x10.rtt.Type[] {
                                                 x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                             });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_3.DIS3_It $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur0 = $deserializer.readLong();
            $_obj.cur1 = $deserializer.readLong();
            $_obj.cur2 = $deserializer.readLong();
            $_obj.out$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DenseIterationSpace_3.DIS3_It $_obj = new x10.array.DenseIterationSpace_3.DIS3_It((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur0);
            $serializer.write(this.cur1);
            $serializer.write(this.cur2);
            $serializer.write(this.out$);
            
        }
        
        // constructor just for allocation
        public DIS3_It(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.lang.Point next$G() {
            return next();
        }
        
        
    
        
        //#line 18 "x10/array/DenseIterationSpace_3.x10"
        public x10.array.DenseIterationSpace_3 out$;
        
        //#line 64 "x10/array/DenseIterationSpace_3.x10"
        public long cur0;
        
        //#line 65 "x10/array/DenseIterationSpace_3.x10"
        public long cur1;
        
        //#line 66 "x10/array/DenseIterationSpace_3.x10"
        public long cur2;
        
        
        //#line 68 "x10/array/DenseIterationSpace_3.x10"
        // creation method for java code (1-phase java constructor)
        public DIS3_It(final x10.array.DenseIterationSpace_3 out$) {
            this((java.lang.System[]) null);
            x10$array$DenseIterationSpace_3$DIS3_It$$init$S(out$);
        }
        
        // constructor for non-virtual call
        final public x10.array.DenseIterationSpace_3.DIS3_It x10$array$DenseIterationSpace_3$DIS3_It$$init$S(final x10.array.DenseIterationSpace_3 out$) {
             {
                
                //#line 18 "x10/array/DenseIterationSpace_3.x10"
                this.out$ = out$;
                
                //#line 68 "x10/array/DenseIterationSpace_3.x10"
                
                
                //#line 63 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3.DIS3_It this$104292 = this;
                
                //#line 63 "x10/array/DenseIterationSpace_3.x10"
                this$104292.cur0 = 0L;
                
                //#line 63 "x10/array/DenseIterationSpace_3.x10"
                this$104292.cur1 = 0L;
                
                //#line 63 "x10/array/DenseIterationSpace_3.x10"
                this$104292.cur2 = 0L;
                
                //#line 69 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104228 = this.out$;
                
                //#line 69 "x10/array/DenseIterationSpace_3.x10"
                final long t$104229 = t$104228.min0;
                
                //#line 69 "x10/array/DenseIterationSpace_3.x10"
                this.cur0 = t$104229;
                
                //#line 70 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104230 = this.out$;
                
                //#line 70 "x10/array/DenseIterationSpace_3.x10"
                final long t$104231 = t$104230.min1;
                
                //#line 70 "x10/array/DenseIterationSpace_3.x10"
                this.cur1 = t$104231;
                
                //#line 71 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104232 = this.out$;
                
                //#line 71 "x10/array/DenseIterationSpace_3.x10"
                final long t$104233 = t$104232.min2;
                
                //#line 71 "x10/array/DenseIterationSpace_3.x10"
                this.cur2 = t$104233;
            }
            return this;
        }
        
        
        
        //#line 74 "x10/array/DenseIterationSpace_3.x10"
        public boolean hasNext$O() {
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            final long t$104235 = this.cur0;
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            final x10.array.DenseIterationSpace_3 t$104234 = this.out$;
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            final long t$104236 = t$104234.max0;
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            boolean t$104240 = ((t$104235) <= (((long)(t$104236))));
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            if (t$104240) {
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                final long t$104238 = this.cur1;
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104237 = this.out$;
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                final long t$104239 = t$104237.max1;
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                t$104240 = ((t$104238) <= (((long)(t$104239))));
            }
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            boolean t$104244 = t$104240;
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            if (t$104240) {
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                final long t$104242 = this.cur2;
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104241 = this.out$;
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                final long t$104243 = t$104241.max2;
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                t$104244 = ((t$104242) <= (((long)(t$104243))));
            }
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            return t$104244;
        }
        
        
        //#line 76 "x10/array/DenseIterationSpace_3.x10"
        public x10.lang.Point next() {
            
            //#line 77 "x10/array/DenseIterationSpace_3.x10"
            final long i$104176 = this.cur0;
            
            //#line 77 "x10/array/DenseIterationSpace_3.x10"
            final long i$104177 = this.cur1;
            
            //#line 77 "x10/array/DenseIterationSpace_3.x10"
            final long i$104178 = this.cur2;
            
            //#line 153 . "x10/lang/Point.x10"
            final x10.lang.Point alloc$104179 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 153 . "x10/lang/Point.x10"
            alloc$104179.x10$lang$Point$$init$S(((long)(i$104176)), ((long)(i$104177)), ((long)(i$104178)));
            
            //#line 78 "x10/array/DenseIterationSpace_3.x10"
            final long t$104246 = this.cur2;
            
            //#line 78 "x10/array/DenseIterationSpace_3.x10"
            final long t$104247 = ((t$104246) + (((long)(1L))));
            
            //#line 78 "x10/array/DenseIterationSpace_3.x10"
            this.cur2 = t$104247;
            
            //#line 79 "x10/array/DenseIterationSpace_3.x10"
            final long t$104249 = this.cur2;
            
            //#line 79 "x10/array/DenseIterationSpace_3.x10"
            final x10.array.DenseIterationSpace_3 t$104248 = this.out$;
            
            //#line 79 "x10/array/DenseIterationSpace_3.x10"
            final long t$104250 = t$104248.max2;
            
            //#line 79 "x10/array/DenseIterationSpace_3.x10"
            final boolean t$104263 = ((t$104249) > (((long)(t$104250))));
            
            //#line 79 "x10/array/DenseIterationSpace_3.x10"
            if (t$104263) {
                
                //#line 80 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104251 = this.out$;
                
                //#line 80 "x10/array/DenseIterationSpace_3.x10"
                final long t$104252 = t$104251.min2;
                
                //#line 80 "x10/array/DenseIterationSpace_3.x10"
                this.cur2 = t$104252;
                
                //#line 81 "x10/array/DenseIterationSpace_3.x10"
                final long t$104253 = this.cur1;
                
                //#line 81 "x10/array/DenseIterationSpace_3.x10"
                final long t$104254 = ((t$104253) + (((long)(1L))));
                
                //#line 81 "x10/array/DenseIterationSpace_3.x10"
                this.cur1 = t$104254;
                
                //#line 82 "x10/array/DenseIterationSpace_3.x10"
                final long t$104256 = this.cur1;
                
                //#line 82 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104255 = this.out$;
                
                //#line 82 "x10/array/DenseIterationSpace_3.x10"
                final long t$104257 = t$104255.max1;
                
                //#line 82 "x10/array/DenseIterationSpace_3.x10"
                final boolean t$104262 = ((t$104256) > (((long)(t$104257))));
                
                //#line 82 "x10/array/DenseIterationSpace_3.x10"
                if (t$104262) {
                    
                    //#line 83 "x10/array/DenseIterationSpace_3.x10"
                    final x10.array.DenseIterationSpace_3 t$104258 = this.out$;
                    
                    //#line 83 "x10/array/DenseIterationSpace_3.x10"
                    final long t$104259 = t$104258.min1;
                    
                    //#line 83 "x10/array/DenseIterationSpace_3.x10"
                    this.cur1 = t$104259;
                    
                    //#line 84 "x10/array/DenseIterationSpace_3.x10"
                    final long t$104260 = this.cur0;
                    
                    //#line 84 "x10/array/DenseIterationSpace_3.x10"
                    final long t$104261 = ((t$104260) + (((long)(1L))));
                    
                    //#line 84 "x10/array/DenseIterationSpace_3.x10"
                    this.cur0 = t$104261;
                }
            }
            
            //#line 87 "x10/array/DenseIterationSpace_3.x10"
            return alloc$104179;
        }
        
        
        //#line 63 "x10/array/DenseIterationSpace_3.x10"
        final public x10.array.DenseIterationSpace_3.DIS3_It x10$array$DenseIterationSpace_3$DIS3_It$$this$x10$array$DenseIterationSpace_3$DIS3_It() {
            
            //#line 63 "x10/array/DenseIterationSpace_3.x10"
            return x10.array.DenseIterationSpace_3.DIS3_It.this;
        }
        
        
        //#line 63 "x10/array/DenseIterationSpace_3.x10"
        final public x10.array.DenseIterationSpace_3 x10$array$DenseIterationSpace_3$DIS3_It$$this$x10$array$DenseIterationSpace_3() {
            
            //#line 63 "x10/array/DenseIterationSpace_3.x10"
            final x10.array.DenseIterationSpace_3 t$104264 = this.out$;
            
            //#line 63 "x10/array/DenseIterationSpace_3.x10"
            return t$104264;
        }
        
        
        //#line 63 "x10/array/DenseIterationSpace_3.x10"
        final public void __fieldInitializers_x10_array_DenseIterationSpace_3_DIS3_It() {
            
            //#line 63 "x10/array/DenseIterationSpace_3.x10"
            this.cur0 = 0L;
            
            //#line 63 "x10/array/DenseIterationSpace_3.x10"
            this.cur1 = 0L;
            
            //#line 63 "x10/array/DenseIterationSpace_3.x10"
            this.cur2 = 0L;
        }
    }
    
    
    
    //#line 91 "x10/array/DenseIterationSpace_3.x10"
    public java.lang.String toString() {
        
        //#line 93 "x10/array/DenseIterationSpace_3.x10"
        final long t$104265 = this.min0;
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104266 = (("[") + ((x10.core.Long.$box(t$104265))));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104267 = ((t$104266) + (".."));
        
        //#line 93 "x10/array/DenseIterationSpace_3.x10"
        final long t$104268 = this.max0;
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104269 = ((t$104267) + ((x10.core.Long.$box(t$104268))));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104270 = ((t$104269) + (","));
        
        //#line 94 "x10/array/DenseIterationSpace_3.x10"
        final long t$104271 = this.min1;
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104272 = ((t$104270) + ((x10.core.Long.$box(t$104271))));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104273 = ((t$104272) + (".."));
        
        //#line 94 "x10/array/DenseIterationSpace_3.x10"
        final long t$104274 = this.max1;
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104275 = ((t$104273) + ((x10.core.Long.$box(t$104274))));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104276 = ((t$104275) + (","));
        
        //#line 95 "x10/array/DenseIterationSpace_3.x10"
        final long t$104277 = this.min2;
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104278 = ((t$104276) + ((x10.core.Long.$box(t$104277))));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104279 = ((t$104278) + (".."));
        
        //#line 95 "x10/array/DenseIterationSpace_3.x10"
        final long t$104280 = this.max2;
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104281 = ((t$104279) + ((x10.core.Long.$box(t$104280))));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104282 = ((t$104281) + ("]"));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        return t$104282;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_3.x10"
    final public x10.array.DenseIterationSpace_3 x10$array$DenseIterationSpace_3$$this$x10$array$DenseIterationSpace_3() {
        
        //#line 18 "x10/array/DenseIterationSpace_3.x10"
        return x10.array.DenseIterationSpace_3.this;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_3.x10"
    final public void __fieldInitializers_x10_array_DenseIterationSpace_3() {
        
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$EMPTY = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$EMPTY;
    
    public static x10.array.DenseIterationSpace_3 get$EMPTY() {
        if (((int) x10.array.DenseIterationSpace_3.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.array.DenseIterationSpace_3.EMPTY;
        }
        if (((int) x10.array.DenseIterationSpace_3.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.array.DenseIterationSpace_3.exception$EMPTY;
        }
        if (x10.array.DenseIterationSpace_3.initStatus$EMPTY.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.array.DenseIterationSpace_3.EMPTY = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null).x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)), ((long)(-1L)))));
            }}catch (java.lang.Throwable exc$104293) {
                x10.array.DenseIterationSpace_3.exception$EMPTY = new x10.lang.ExceptionInInitializer(exc$104293);
                x10.array.DenseIterationSpace_3.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.array.DenseIterationSpace_3.exception$EMPTY;
            }
            x10.array.DenseIterationSpace_3.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.array.DenseIterationSpace_3.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.array.DenseIterationSpace_3.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.array.DenseIterationSpace_3.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.array.DenseIterationSpace_3.exception$EMPTY;
                }
            }
        }
        return x10.array.DenseIterationSpace_3.EMPTY;
    }
}

