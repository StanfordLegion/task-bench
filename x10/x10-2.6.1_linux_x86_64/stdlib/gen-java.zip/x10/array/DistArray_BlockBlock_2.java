package x10.array;


/**
 * Implementation of a 2-D DistArray that distributes its data elements
 * over the places in its PlaceGroup in a 2-D blocked fashion.
 */
@x10.runtime.impl.java.X10Generated
public class DistArray_BlockBlock_2<$T> extends x10.array.DistArray<$T> implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray_BlockBlock_2> $RTT = 
        x10.rtt.NamedType.<DistArray_BlockBlock_2> make("x10.array.DistArray_BlockBlock_2",
                                                        DistArray_BlockBlock_2.class,
                                                        1,
                                                        new x10.rtt.Type[] {
                                                            x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                                            x10.rtt.ParameterizedType.make(x10.array.DistArray.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                        });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_2<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.globalIndices = $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localIndices = $_obj.reloadLocalIndices();
        $_obj.minIndex_1 = $_obj.reloadMinIndex_1$O();
        $_obj.minIndex_2 = $_obj.reloadMinIndex_2$O();
        $_obj.numElemsLocal_1 = $_obj.reloadNumElemsLocal_1$O();
        $_obj.numElemsLocal_2 = $_obj.reloadNumElemsLocal_2$O();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray_BlockBlock_2 $_obj = new x10.array.DistArray_BlockBlock_2((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.globalIndices);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        
    }
    
    // constructor just for allocation
    public DistArray_BlockBlock_2(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.DistArray_BlockBlock_2.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
        
    }
    
    // bridge for method abstract public x10.array.DistArray[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.DistArray).rank()}, v:T){}:T{self==v}
    final public $T $set__1x10$array$DistArray$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$DistArray_BlockBlock_2$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray_BlockBlock_2 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __2$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2 {}
    

    
    
    //#line 25 "x10/array/DistArray_BlockBlock_2.x10"
    final public long rank$O() {
        
        //#line 25 "x10/array/DistArray_BlockBlock_2.x10"
        return 2L;
    }
    
    
    //#line 27 "x10/array/DistArray_BlockBlock_2.x10"
    public x10.array.DenseIterationSpace_2 globalIndices;
    
    //#line 29 "x10/array/DistArray_BlockBlock_2.x10"
    public long numElems_1;
    
    //#line 31 "x10/array/DistArray_BlockBlock_2.x10"
    public long numElems_2;
    
    //#line 34 "x10/array/DistArray_BlockBlock_2.x10"
    public transient x10.array.DenseIterationSpace_2 localIndices;
    
    
    //#line 35 "x10/array/DistArray_BlockBlock_2.x10"
    final public x10.array.DenseIterationSpace_2 reloadLocalIndices() {
        
        //#line 37 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.lang.PlaceLocalHandle t$106143 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 37 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.LocalState t$106144 = ((x10.lang.PlaceLocalHandle<x10.array.LocalState<$T>>)t$106143).$apply$G();
        
        //#line 37 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.LocalState_BB2 ls = x10.rtt.Types.<x10.array.LocalState_BB2<$T>> cast(t$106144,x10.rtt.ParameterizedType.make(x10.array.LocalState_BB2.$RTT, $T));
        
        //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
        final boolean t$106146 = ((ls) != (null));
        
        //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
        x10.array.DenseIterationSpace_2 t$106147 =  null;
        
        //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106146) {
            
            //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.Dist_BlockBlock_2 t$106145 = ((x10.array.Dist_BlockBlock_2)(((x10.array.LocalState_BB2<$T>)ls).dist));
            
            //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
            t$106147 = ((x10.array.DenseIterationSpace_2)(t$106145.localIndices));
        } else {
            
            //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 alloc$105878 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
            
            //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
            alloc$105878.x10$array$DenseIterationSpace_2$$init$S(((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)));
            
            //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
            t$106147 = ((x10.array.DenseIterationSpace_2)(alloc$105878));
        }
        
        //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106147;
    }
    
    
    //#line 42 "x10/array/DistArray_BlockBlock_2.x10"
    public transient long minIndex_1;
    
    
    //#line 43 "x10/array/DistArray_BlockBlock_2.x10"
    final public long reloadMinIndex_1$O() {
        
        //#line 43 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106149 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 43 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106150 = t$106149.min$O((long)(0L));
        
        //#line 43 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106150;
    }
    
    
    //#line 46 "x10/array/DistArray_BlockBlock_2.x10"
    public transient long minIndex_2;
    
    
    //#line 47 "x10/array/DistArray_BlockBlock_2.x10"
    final public long reloadMinIndex_2$O() {
        
        //#line 47 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106151 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 47 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106152 = t$106151.min$O((long)(1L));
        
        //#line 47 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106152;
    }
    
    
    //#line 50 "x10/array/DistArray_BlockBlock_2.x10"
    public transient long numElemsLocal_1;
    
    
    //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
    final public long reloadNumElemsLocal_1$O() {
        
        //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106153 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106154 = t$106153.max$O((long)(0L));
        
        //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106155 = this.minIndex_1;
        
        //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106156 = ((t$106154) - (((long)(t$106155))));
        
        //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106157 = ((t$106156) + (((long)(1L))));
        
        //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106157;
    }
    
    
    //#line 54 "x10/array/DistArray_BlockBlock_2.x10"
    public transient long numElemsLocal_2;
    
    
    //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
    final public long reloadNumElemsLocal_2$O() {
        
        //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106158 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106159 = t$106158.max$O((long)(1L));
        
        //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106160 = this.minIndex_2;
        
        //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106161 = ((t$106159) - (((long)(t$106160))));
        
        //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106162 = ((t$106161) + (((long)(1L))));
        
        //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106162;
    }
    
    
    //#line 67 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Construct a m by n block-block distributed DistArray
     * whose data is distributed over pg and initialized using
     * the init function.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_2(final x10.rtt.Type $T, final long m, final long n, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_2$$init$S(m, n, pg, init, (x10.array.DistArray_BlockBlock_2.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_2<$T> x10$array$DistArray_BlockBlock_2$$init$S(final long m, final long n, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2 $dummy) {
         {
            
            //#line 68 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.core.fun.Fun_0_0 t$106319 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_BlockBlock_2.$Closure$5<$T>($T, pg, m, n, init, (x10.array.DistArray_BlockBlock_2.$Closure$5.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$Closure$5$$T$2) null)));
            
            //#line 263 . "x10/array/DistArray_BlockBlock_2.x10"
            boolean t$106323 = ((m) < (((long)(0L))));
            
            //#line 263 . "x10/array/DistArray_BlockBlock_2.x10"
            if (!(t$106323)) {
                
                //#line 263 . "x10/array/DistArray_BlockBlock_2.x10"
                t$106323 = ((n) < (((long)(0L))));
            }
            
            //#line 263 . "x10/array/DistArray_BlockBlock_2.x10"
            if (t$106323) {
                
                //#line 263 . "x10/array/DistArray_BlockBlock_2.x10"
                x10.array.DistArray.raiseNegativeArraySizeException();
            }
            
            //#line 264 . "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106325 = ((m) * (((long)(n))));
            
            //#line 68 "x10/array/DistArray_BlockBlock_2.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$106319)), t$106325, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 67 "x10/array/DistArray_BlockBlock_2.x10"
            
            
            //#line 69 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 alloc$105879 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
            
            //#line 69 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106327 = ((m) - (((long)(1L))));
            
            //#line 69 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106328 = ((n) - (((long)(1L))));
            
            //#line 69 "x10/array/DistArray_BlockBlock_2.x10"
            alloc$105879.x10$array$DenseIterationSpace_2$$init$S(((long)(0L)), ((long)(0L)), t$106327, t$106328);
            
            //#line 69 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).globalIndices = ((x10.array.DenseIterationSpace_2)(alloc$105879));
            
            //#line 70 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).numElems_1 = m;
            
            //#line 71 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).numElems_2 = n;
            
            //#line 72 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106170 = ((x10.array.DenseIterationSpace_2)(this.reloadLocalIndices()));
            
            //#line 72 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).localIndices = ((x10.array.DenseIterationSpace_2)(t$106170));
            
            //#line 73 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DistArray_BlockBlock_2 this$105986 = ((x10.array.DistArray_BlockBlock_2)(this));
            
            //#line 43 . "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106171 = ((x10.array.DenseIterationSpace_2)(((x10.array.DistArray_BlockBlock_2<$T>)this$105986).localIndices));
            
            //#line 43 . "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106172 = t$106171.min$O((long)(0L));
            
            //#line 73 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).minIndex_1 = t$106172;
            
            //#line 74 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DistArray_BlockBlock_2 this$105988 = ((x10.array.DistArray_BlockBlock_2)(this));
            
            //#line 47 . "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106173 = ((x10.array.DenseIterationSpace_2)(((x10.array.DistArray_BlockBlock_2<$T>)this$105988).localIndices));
            
            //#line 47 . "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106174 = t$106173.min$O((long)(1L));
            
            //#line 74 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).minIndex_2 = t$106174;
            
            //#line 75 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106175 = this.reloadNumElemsLocal_1$O();
            
            //#line 75 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).numElemsLocal_1 = t$106175;
            
            //#line 76 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106176 = this.reloadNumElemsLocal_2$O();
            
            //#line 76 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).numElemsLocal_2 = t$106176;
        }
        return this;
    }
    
    
    
    //#line 89 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Construct a m by n block-block distributed DistArray
     * whose data is distributed over Place.places() and 
     * initialized using the provided init closure.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_2(final x10.rtt.Type $T, final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_2$$init$S(m, n, init, (x10.array.DistArray_BlockBlock_2.__2$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_2<$T> x10$array$DistArray_BlockBlock_2$$init$S(final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2 $dummy) {
         {
            
            //#line 90 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.lang.PlaceGroup t$106177 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 90 "x10/array/DistArray_BlockBlock_2.x10"
            /*this.*/x10$array$DistArray_BlockBlock_2$$init$S(((long)(m)), ((long)(n)), t$106177, ((x10.core.fun.Fun_0_2)(init)), (x10.array.DistArray_BlockBlock_2.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 102 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Construct a m by n block-block distributed DistArray
     * whose data is distributed over pg and zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_2(final x10.rtt.Type $T, final long m, final long n, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_2$$init$S(m, n, pg);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_2<$T> x10$array$DistArray_BlockBlock_2$$init$S(final long m, final long n, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 103 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.core.fun.Fun_0_2 t$106179 = ((x10.core.fun.Fun_0_2)(new x10.array.DistArray_BlockBlock_2.$Closure$6<$T>($T)));
            
            //#line 103 "x10/array/DistArray_BlockBlock_2.x10"
            /*this.*/x10$array$DistArray_BlockBlock_2$$init$S(((long)(m)), ((long)(n)), ((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_2)(t$106179)), (x10.array.DistArray_BlockBlock_2.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 115 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Construct a m by n block-block distributed DistArray
     * whose data is distributed over Place.places() and 
     * zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_2(final x10.rtt.Type $T, final long m, final long n) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_2$$init$S(m, n);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_2<$T> x10$array$DistArray_BlockBlock_2$$init$S(final long m, final long n) {
         {
            
            //#line 116 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.lang.PlaceGroup t$106181 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 116 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.core.fun.Fun_0_2 t$106182 = ((x10.core.fun.Fun_0_2)(new x10.array.DistArray_BlockBlock_2.$Closure$7<$T>($T)));
            
            //#line 116 "x10/array/DistArray_BlockBlock_2.x10"
            /*this.*/x10$array$DistArray_BlockBlock_2$$init$S(((long)(m)), ((long)(n)), t$106181, ((x10.core.fun.Fun_0_2)(t$106182)), (x10.array.DistArray_BlockBlock_2.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 125 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the global iteration space (valid indices) of the DistArray.
     * @return an IterationSpace for the DistArray
     */
    final public x10.array.DenseIterationSpace_2 globalIndices() {
        
        //#line 125 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106183 = ((x10.array.DenseIterationSpace_2)(this.globalIndices));
        
        //#line 125 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106183;
    }
    
    
    //#line 133 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the local iteration space (valid indices) of the DistArray at the current Place.
     * @return an IterationSpace for the local portion of the DistArray
     */
    final public x10.array.DenseIterationSpace_2 localIndices() {
        
        //#line 133 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106184 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 133 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106184;
    }
    
    
    //#line 146 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Return the Place which contains the data for the argument
     * index or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param i the index in the first dimension
     * @param j the index in the second dimension
     * @return the Place where (i,j) is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if (i,j) is not contained in globalIndices
     */
    final public x10.lang.Place place(final long i, final long j) {
        
        //#line 147 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106185 = ((x10.array.DenseIterationSpace_2)(this.globalIndices));
        
        //#line 147 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.lang.PlaceGroup this$106092 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$106186 = this$106092.numPlaces$O();
        
        //#line 147 "x10/array/DistArray_BlockBlock_2.x10"
        final long tmp = x10.array.BlockingUtils.mapIndexToBlockBlockPartition$O(((x10.array.IterationSpace)(t$106185)), (long)(t$106186), (long)(i), (long)(j));
        
        //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
        final boolean t$106188 = ((long) tmp) == ((long) -1L);
        
        //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
        x10.lang.Place t$106189 =  null;
        
        //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106188) {
            
            //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
            t$106189 = x10.lang.Place.get$INVALID_PLACE();
        } else {
            
            //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.lang.PlaceGroup t$106187 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
            t$106189 = t$106187.$apply((long)(tmp));
        }
        
        //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106189;
    }
    
    
    //#line 161 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Return the Place which contains the data for the argument
     * Point or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param p the Point to lookup
     * @return the Place where p is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if p is not contained in globalIndices
     */
    final public x10.lang.Place place(final x10.lang.Point p) {
        
        //#line 161 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106191 = p.$apply$O((long)(0L));
        
        //#line 161 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106192 = p.$apply$O((long)(1L));
        
        //#line 161 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.lang.Place t$106193 = this.place((long)(t$106191), (long)(t$106192));
        
        //#line 161 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106193;
    }
    
    
    //#line 172 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the element of this array corresponding to the given index.
     * @see #set(T, Long, Long)
     */
    final public $T $apply$G(final long i, final long j) {
        
        //#line 173 "x10/array/DistArray_BlockBlock_2.x10"
        this.validateIndex((long)(i), (long)(j));
        
        //#line 174 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.core.Rail r$106098 = ((x10.core.Rail)(this.raw));
        
        //#line 174 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DistArray_BlockBlock_2 this$106096 = ((x10.array.DistArray_BlockBlock_2)(this));
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106194 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106096).minIndex_2;
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106198 = ((j) - (((long)(t$106194))));
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106195 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106096).minIndex_1;
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106196 = ((i) - (((long)(t$106195))));
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106197 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106096).numElemsLocal_2;
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106199 = ((t$106196) * (((long)(t$106197))));
        
        //#line 174 "x10/array/DistArray_BlockBlock_2.x10"
        final long i$106099 = ((t$106198) + (((long)(t$106199))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$106200 = (($T)(((x10.core.Rail<$T>)r$106098).$apply$G((long)(i$106099))));
        
        //#line 174 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106200;
    }
    
    
    //#line 185 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    final public $T $apply$G(final x10.lang.Point p) {
        
        //#line 185 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DistArray_BlockBlock_2 this$106103 = ((x10.array.DistArray_BlockBlock_2)(this));
        
        //#line 185 "x10/array/DistArray_BlockBlock_2.x10"
        final long i$106101 = p.$apply$O((long)(0L));
        
        //#line 185 "x10/array/DistArray_BlockBlock_2.x10"
        final long j$106102 = p.$apply$O((long)(1L));
        
        //#line 173 . "x10/array/DistArray_BlockBlock_2.x10"
        ((x10.array.DistArray_BlockBlock_2<$T>)this$106103).validateIndex((long)(i$106101), (long)(j$106102));
        
        //#line 174 . "x10/array/DistArray_BlockBlock_2.x10"
        final x10.core.Rail r$106108 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$106103).raw));
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106201 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106103).minIndex_2;
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106205 = ((j$106102) - (((long)(t$106201))));
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106202 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106103).minIndex_1;
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106203 = ((i$106101) - (((long)(t$106202))));
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106204 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106103).numElemsLocal_2;
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106206 = ((t$106203) * (((long)(t$106204))));
        
        //#line 174 . "x10/array/DistArray_BlockBlock_2.x10"
        final long i$106109 = ((t$106205) + (((long)(t$106206))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$106207 = (($T)(((x10.core.Rail<$T>)r$106108).$apply$G((long)(i$106109))));
        
        //#line 185 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106207;
    }
    
    
    //#line 198 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long, Long)
     */
    final public $T $set__2x10$array$DistArray_BlockBlock_2$$T$G(final long i, final long j, final $T v) {
        
        //#line 199 "x10/array/DistArray_BlockBlock_2.x10"
        this.validateIndex((long)(i), (long)(j));
        
        //#line 200 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.core.Rail r$106115 = ((x10.core.Rail)(this.raw));
        
        //#line 200 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DistArray_BlockBlock_2 this$106113 = ((x10.array.DistArray_BlockBlock_2)(this));
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106208 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106113).minIndex_2;
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106212 = ((j) - (((long)(t$106208))));
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106209 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106113).minIndex_1;
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106210 = ((i) - (((long)(t$106209))));
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106211 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106113).numElemsLocal_2;
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106213 = ((t$106210) * (((long)(t$106211))));
        
        //#line 200 "x10/array/DistArray_BlockBlock_2.x10"
        final long i$106116 = ((t$106212) + (((long)(t$106213))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$106115).$set__1x10$lang$Rail$$T$G((long)(i$106116), (($T)(v)));
        
        //#line 200 "x10/array/DistArray_BlockBlock_2.x10"
        return (($T)
                 v);
    }
    
    
    //#line 213 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    final public $T $set__1x10$array$DistArray_BlockBlock_2$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 213 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DistArray_BlockBlock_2 this$106122 = ((x10.array.DistArray_BlockBlock_2)(this));
        
        //#line 213 "x10/array/DistArray_BlockBlock_2.x10"
        final long i$106119 = p.$apply$O((long)(0L));
        
        //#line 213 "x10/array/DistArray_BlockBlock_2.x10"
        final long j$106120 = p.$apply$O((long)(1L));
        
        //#line 199 . "x10/array/DistArray_BlockBlock_2.x10"
        ((x10.array.DistArray_BlockBlock_2<$T>)this$106122).validateIndex((long)(i$106119), (long)(j$106120));
        
        //#line 200 . "x10/array/DistArray_BlockBlock_2.x10"
        final x10.core.Rail r$106127 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$106122).raw));
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106214 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106122).minIndex_2;
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106218 = ((j$106120) - (((long)(t$106214))));
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106215 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106122).minIndex_1;
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106216 = ((i$106119) - (((long)(t$106215))));
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106217 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106122).numElemsLocal_2;
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106219 = ((t$106216) * (((long)(t$106217))));
        
        //#line 200 . "x10/array/DistArray_BlockBlock_2.x10"
        final long i$106128 = ((t$106218) + (((long)(t$106219))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$106127).$set__1x10$lang$Rail$$T$G((long)(i$106128), (($T)(v)));
        
        //#line 213 "x10/array/DistArray_BlockBlock_2.x10"
        return (($T)
                 v);
    }
    
    
    //#line 221 "x10/array/DistArray_BlockBlock_2.x10"
    final public void validateIndex(final long i, final long j) {
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106220 = this.minIndex_1;
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106224 = ((i) < (((long)(t$106220))));
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        if (!(t$106224)) {
            
            //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106221 = this.minIndex_1;
            
            //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106222 = this.numElemsLocal_1;
            
            //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106223 = ((t$106221) + (((long)(t$106222))));
            
            //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
            t$106224 = ((i) >= (((long)(t$106223))));
        }
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106226 = t$106224;
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        if (!(t$106224)) {
            
            //#line 224 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106225 = this.minIndex_2;
            
            //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
            t$106226 = ((j) < (((long)(t$106225))));
        }
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106230 = t$106226;
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        if (!(t$106226)) {
            
            //#line 224 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106227 = this.minIndex_2;
            
            //#line 224 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106228 = this.numElemsLocal_2;
            
            //#line 224 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106229 = ((t$106227) + (((long)(t$106228))));
            
            //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
            t$106230 = ((j) >= (((long)(t$106229))));
        }
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106230) {
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            boolean t$106232 = ((i) < (((long)(0L))));
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            if (!(t$106232)) {
                
                //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106231 = this.numElems_1;
                
                //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
                t$106232 = ((i) >= (((long)(t$106231))));
            }
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            boolean t$106233 = t$106232;
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            if (!(t$106232)) {
                
                //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
                t$106233 = ((j) < (((long)(0L))));
            }
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            boolean t$106235 = t$106233;
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            if (!(t$106233)) {
                
                //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106234 = this.numElems_2;
                
                //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
                t$106235 = ((j) >= (((long)(t$106234))));
            }
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            if (t$106235) {
                
                //#line 226 "x10/array/DistArray_BlockBlock_2.x10"
                x10.array.DistArray.raiseBoundsError((long)(i), (long)(j));
            }
            
            //#line 228 "x10/array/DistArray_BlockBlock_2.x10"
            x10.array.DistArray.raisePlaceError((long)(i), (long)(j));
        }
    }
    
    
    //#line 233 "x10/array/DistArray_BlockBlock_2.x10"
    final public long offset$O(final long i, final long j) {
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106238 = this.minIndex_2;
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106242 = ((j) - (((long)(t$106238))));
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106239 = this.minIndex_1;
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106240 = ((i) - (((long)(t$106239))));
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106241 = this.numElemsLocal_2;
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106243 = ((t$106240) * (((long)(t$106241))));
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106244 = ((t$106242) + (((long)(t$106243))));
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106244;
    }
    
    
    //#line 245 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Returns the specified rectangular patch of this array as a Rail.
     * 
     * @param space the IterationSpace representing the portion of this array to copy
     * @see offset
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in this array
     */
    public x10.core.Rail getPatch(final x10.array.IterationSpace space) {
        
        //#line 246 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 r = ((x10.array.DenseIterationSpace_2)(x10.rtt.Types.<x10.array.DenseIterationSpace_2> cast(space,x10.array.DenseIterationSpace_2.$RTT)));
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106245 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106246 = t$106245.min0;
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106247 = r.min0;
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106251 = ((t$106246) <= (((long)(t$106247))));
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106251) {
            
            //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106249 = r.max0;
            
            //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106248 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
            
            //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106250 = t$106248.max0;
            
            //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
            t$106251 = ((t$106249) <= (((long)(t$106250))));
        }
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106255 = t$106251;
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106251) {
            
            //#line 250 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106252 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
            
            //#line 250 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106253 = t$106252.min1;
            
            //#line 250 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106254 = r.min1;
            
            //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
            t$106255 = ((t$106253) <= (((long)(t$106254))));
        }
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106259 = t$106255;
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106255) {
            
            //#line 250 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106257 = r.max1;
            
            //#line 250 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106256 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
            
            //#line 250 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106258 = t$106256.max1;
            
            //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
            t$106259 = ((t$106257) <= (((long)(t$106258))));
        }
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        final boolean t$106266 = !(t$106259);
        
        //#line 248 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106266) {
            
            //#line 251 "x10/array/DistArray_BlockBlock_2.x10"
            final java.lang.String t$106261 = (("patch to copy: ") + (r));
            
            //#line 251 "x10/array/DistArray_BlockBlock_2.x10"
            final java.lang.String t$106262 = ((t$106261) + (" not contained in local indices: "));
            
            //#line 251 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106263 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
            
            //#line 251 "x10/array/DistArray_BlockBlock_2.x10"
            final java.lang.String t$106264 = ((t$106262) + (t$106263));
            
            //#line 251 "x10/array/DistArray_BlockBlock_2.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$106265 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$106264)));
            
            //#line 251 "x10/array/DistArray_BlockBlock_2.x10"
            throw t$106265;
        }
        
        //#line 254 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106267 = r.size$O();
        
        //#line 254 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.core.Rail patch = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$106267)), false)));
        
        //#line 255 "x10/array/DistArray_BlockBlock_2.x10"
        long patchIndex = 0L;
        
        //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
        final long i1$105883min$106357 = r.min$O((long)(1L));
        
        //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
        final long i1$105883max$106358 = r.max$O((long)(1L));
        
        //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
        final long i0$105914min$106359 = r.min$O((long)(0L));
        
        //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
        final long i0$105914max$106360 = r.max$O((long)(0L));
        
        //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
        long i$106353 = i0$105914min$106359;
        
        //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
        for (;
             true;
             ) {
            
            //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
            final boolean t$106355 = ((i$106353) <= (((long)(i0$105914max$106360))));
            
            //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
            if (!(t$106355)) {
                
                //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
                break;
            }
            
            //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
            long i$106347 = i1$105883min$106357;
            
            //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
            for (;
                 true;
                 ) {
                
                //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
                final boolean t$106349 = ((i$106347) <= (((long)(i1$105883max$106358))));
                
                //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
                if (!(t$106349)) {
                    
                    //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
                    break;
                }
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                final long pre$106329 = patchIndex;
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106331 = ((patchIndex) + (((long)(1L))));
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                patchIndex = t$106331;
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                final x10.core.Rail t$106332 = ((x10.core.Rail)(this.raw));
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                final x10.array.DistArray_BlockBlock_2 this$106333 = ((x10.array.DistArray_BlockBlock_2)(this));
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106336 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106333).minIndex_2;
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106337 = ((i$106347) - (((long)(t$106336))));
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106338 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106333).minIndex_1;
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106339 = ((i$106353) - (((long)(t$106338))));
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106340 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106333).numElemsLocal_2;
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106341 = ((t$106339) * (((long)(t$106340))));
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106342 = ((t$106337) + (((long)(t$106341))));
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                final $T t$106343 = (($T)(((x10.core.Rail<$T>)t$106332).$apply$G((long)(t$106342))));
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                ((x10.core.Rail<$T>)patch).$set__1x10$lang$Rail$$T$G((long)(pre$106329), (($T)(t$106343)));
                
                //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106346 = ((i$106347) + (((long)(1L))));
                
                //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
                i$106347 = t$106346;
            }
            
            //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106352 = ((i$106353) + (((long)(1L))));
            
            //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
            i$106353 = t$106352;
        }
        
        //#line 259 "x10/array/DistArray_BlockBlock_2.x10"
        return patch;
    }
    
    
    //#line 262 "x10/array/DistArray_BlockBlock_2.x10"
    private static long validateSize$O(final long m, final long n) {
        
        //#line 263 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106289 = ((m) < (((long)(0L))));
        
        //#line 263 "x10/array/DistArray_BlockBlock_2.x10"
        if (!(t$106289)) {
            
            //#line 263 "x10/array/DistArray_BlockBlock_2.x10"
            t$106289 = ((n) < (((long)(0L))));
        }
        
        //#line 263 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106289) {
            
            //#line 263 "x10/array/DistArray_BlockBlock_2.x10"
            x10.array.DistArray.raiseNegativeArraySizeException();
        }
        
        //#line 264 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106291 = ((m) * (((long)(n))));
        
        //#line 264 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106291;
    }
    
    public static long validateSize$P$O(final long m, final long n) {
        return x10.array.DistArray_BlockBlock_2.validateSize$O((long)(m), (long)(n));
    }
    
    
    //#line 23 "x10/array/DistArray_BlockBlock_2.x10"
    final public x10.array.DistArray_BlockBlock_2 x10$array$DistArray_BlockBlock_2$$this$x10$array$DistArray_BlockBlock_2() {
        
        //#line 23 "x10/array/DistArray_BlockBlock_2.x10"
        return x10.array.DistArray_BlockBlock_2.this;
    }
    
    
    //#line 23 "x10/array/DistArray_BlockBlock_2.x10"
    final public void __fieldInitializers_x10_array_DistArray_BlockBlock_2() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$5<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$5> $RTT = 
            x10.rtt.StaticFunType.<$Closure$5> make($Closure$5.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState_BB2.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_2.$Closure$5<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.m = $deserializer.readLong();
            $_obj.n = $deserializer.readLong();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_BlockBlock_2.$Closure$5 $_obj = new x10.array.DistArray_BlockBlock_2.$Closure$5((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.m);
            $serializer.write(this.n);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$5(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_2.$Closure$5.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState_BB2 $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$5 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$Closure$5$$T$2 {}
        
    
        
        public x10.array.LocalState_BB2 $apply() {
            
            //#line 68 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.LocalState_BB2 t$106320 = x10.array.LocalState_BB2.<$T> make__3$1x10$lang$Long$3x10$lang$Long$3x10$array$LocalState_BB2$$S$2($T, ((x10.lang.PlaceGroup)(this.pg)), (long)(this.m), (long)(this.n), ((x10.core.fun.Fun_0_2)(this.init)));
            
            //#line 68 "x10/array/DistArray_BlockBlock_2.x10"
            return t$106320;
        }
        
        public x10.lang.PlaceGroup pg;
        public long m;
        public long n;
        public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init;
        
        public $Closure$5(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$Closure$5$$T$2 $dummy) {
            x10.array.DistArray_BlockBlock_2.$Closure$5.$initParams(this, $T);
             {
                ((x10.array.DistArray_BlockBlock_2.$Closure$5<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
                ((x10.array.DistArray_BlockBlock_2.$Closure$5<$T>)this).m = m;
                ((x10.array.DistArray_BlockBlock_2.$Closure$5<$T>)this).n = n;
                ((x10.array.DistArray_BlockBlock_2.$Closure$5<$T>)this).init = ((x10.core.fun.Fun_0_2)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$6<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$6> $RTT = 
            x10.rtt.StaticFunType.<$Closure$6> make($Closure$6.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_2.$Closure$6<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_BlockBlock_2.$Closure$6 $_obj = new x10.array.DistArray_BlockBlock_2.$Closure$6((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$6(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_2.$Closure$6.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$6 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$44, final long id$45) {
            
            //#line 103 "x10/array/DistArray_BlockBlock_2.x10"
            final $T t$106178 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 103 "x10/array/DistArray_BlockBlock_2.x10"
            return t$106178;
        }
        
        public $Closure$6(final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_2.$Closure$6.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$7<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$7> $RTT = 
            x10.rtt.StaticFunType.<$Closure$7> make($Closure$7.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_2.$Closure$7<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_BlockBlock_2.$Closure$7 $_obj = new x10.array.DistArray_BlockBlock_2.$Closure$7((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$7(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_2.$Closure$7.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$7 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$46, final long id$47) {
            
            //#line 116 "x10/array/DistArray_BlockBlock_2.x10"
            final $T t$106180 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 116 "x10/array/DistArray_BlockBlock_2.x10"
            return t$106180;
        }
        
        public $Closure$7(final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_2.$Closure$7.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
}


