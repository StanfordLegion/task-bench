package x10.array;

@x10.runtime.impl.java.X10Generated
public class LocalState_B3<$S> extends x10.array.LocalState<$S> implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<LocalState_B3> $RTT = 
        x10.rtt.NamedType.<LocalState_B3> make("x10.array.LocalState_B3",
                                               LocalState_B3.class,
                                               1,
                                               new x10.rtt.Type[] {
                                                   x10.rtt.ParameterizedType.make(x10.array.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                               });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $S; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$S> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.LocalState_B3<$S> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.LocalState.$_deserialize_body($_obj, $deserializer);
        $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
        $_obj.dist = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.LocalState_B3 $_obj = new x10.array.LocalState_B3((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$S);
        $serializer.write(this.dist);
        
    }
    
    // constructor just for allocation
    public LocalState_B3(final java.lang.System[] $dummy, final x10.rtt.Type $S) {
        super($dummy, $S);
        x10.array.LocalState_B3.$initParams(this, $S);
        
    }
    
    private x10.rtt.Type $S;
    
    // initializer of type parameters
    public static void $initParams(final LocalState_B3 $this, final x10.rtt.Type $S) {
        $this.$S = $S;
        
    }
    // synthetic type for parameter mangling
    public static final class __1$1x10$array$LocalState_B3$$S$2 {}
    

    
    //#line 276 "x10/array/DistArray_Block_3.x10"
    public x10.array.Dist_Block_3 dist;
    
    
    //#line 278 "x10/array/DistArray_Block_3.x10"
    // creation method for java code (1-phase java constructor)
    public LocalState_B3(final x10.rtt.Type $S, final x10.lang.PlaceGroup pg, final x10.core.Rail<$S> data, final long size, final x10.array.Dist_Block_3 d, __1$1x10$array$LocalState_B3$$S$2 $dummy) {
        this((java.lang.System[]) null, $S);
        x10$array$LocalState_B3$$init$S(pg, data, size, d, (x10.array.LocalState_B3.__1$1x10$array$LocalState_B3$$S$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.LocalState_B3<$S> x10$array$LocalState_B3$$init$S(final x10.lang.PlaceGroup pg, final x10.core.Rail<$S> data, final long size, final x10.array.Dist_Block_3 d, __1$1x10$array$LocalState_B3$$S$2 $dummy) {
         {
            
            //#line 280 "x10/array/DistArray_Block_3.x10"
            final x10.array.LocalState this$109336 = ((x10.array.LocalState)(this));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$109336).pg = ((x10.lang.PlaceGroup)(pg));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$109336).rail = ((x10.core.Rail)(data));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$109336).size = size;
            
            //#line 278 "x10/array/DistArray_Block_3.x10"
            
            
            //#line 281 "x10/array/DistArray_Block_3.x10"
            ((x10.array.LocalState_B3<$S>)this).dist = ((x10.array.Dist_Block_3)(d));
        }
        return this;
    }
    
    
    
    //#line 284 "x10/array/DistArray_Block_3.x10"
    public static <$S>x10.array.LocalState_B3 make__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$LocalState_B3$$S$2(final x10.rtt.Type $S, final x10.lang.PlaceGroup pg, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$S> init) {
        
        //#line 285 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 globalSpace = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
        
        //#line 285 "x10/array/DistArray_Block_3.x10"
        final long t$109641 = ((m) - (((long)(1L))));
        
        //#line 285 "x10/array/DistArray_Block_3.x10"
        final long t$109642 = ((n) - (((long)(1L))));
        
        //#line 285 "x10/array/DistArray_Block_3.x10"
        final long t$109643 = ((p) - (((long)(1L))));
        
        //#line 285 "x10/array/DistArray_Block_3.x10"
        globalSpace.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), t$109641, t$109642, t$109643);
        
        //#line 286 "x10/array/DistArray_Block_3.x10"
        final x10.array.Dist_Block_3 dist = ((x10.array.Dist_Block_3)(new x10.array.Dist_Block_3((java.lang.System[]) null)));
        
        //#line 286 "x10/array/DistArray_Block_3.x10"
        dist.x10$array$Dist_Block_3$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.array.DenseIterationSpace_3)(globalSpace)));
        
        //#line 288 "x10/array/DistArray_Block_3.x10"
        final x10.core.Rail data;
        
        //#line 289 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 t$109514 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
        
        //#line 289 "x10/array/DistArray_Block_3.x10"
        final boolean t$109549 = t$109514.isEmpty$O();
        
        //#line 289 "x10/array/DistArray_Block_3.x10"
        if (t$109549) {
            
            //#line 290 "x10/array/DistArray_Block_3.x10"
            final x10.core.Rail t$109515 = ((x10.core.Rail)(new x10.core.Rail<$S>($S)));
            
            //#line 290 "x10/array/DistArray_Block_3.x10"
            data = ((x10.core.Rail)(t$109515));
        } else {
            
            //#line 292 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109516 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 292 "x10/array/DistArray_Block_3.x10"
            final long low1 = t$109516.min$O((long)(0L));
            
            //#line 293 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109517 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 293 "x10/array/DistArray_Block_3.x10"
            final long hi1 = t$109517.max$O((long)(0L));
            
            //#line 294 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109518 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 294 "x10/array/DistArray_Block_3.x10"
            final long low2 = t$109518.min$O((long)(1L));
            
            //#line 295 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109519 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 295 "x10/array/DistArray_Block_3.x10"
            final long hi2 = t$109519.max$O((long)(1L));
            
            //#line 296 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109520 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 296 "x10/array/DistArray_Block_3.x10"
            final long low3 = t$109520.min$O((long)(2L));
            
            //#line 297 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109521 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 297 "x10/array/DistArray_Block_3.x10"
            final long hi3 = t$109521.max$O((long)(2L));
            
            //#line 298 "x10/array/DistArray_Block_3.x10"
            final long t$109522 = ((hi1) - (((long)(low1))));
            
            //#line 298 "x10/array/DistArray_Block_3.x10"
            final long localSize1 = ((t$109522) + (((long)(1L))));
            
            //#line 299 "x10/array/DistArray_Block_3.x10"
            final long t$109523 = ((hi2) - (((long)(low2))));
            
            //#line 299 "x10/array/DistArray_Block_3.x10"
            final long localSize2 = ((t$109523) + (((long)(1L))));
            
            //#line 300 "x10/array/DistArray_Block_3.x10"
            final long t$109524 = ((hi3) - (((long)(low3))));
            
            //#line 300 "x10/array/DistArray_Block_3.x10"
            final long localSize3 = ((t$109524) + (((long)(1L))));
            
            //#line 301 "x10/array/DistArray_Block_3.x10"
            final long t$109525 = ((localSize1) * (((long)(localSize2))));
            
            //#line 301 "x10/array/DistArray_Block_3.x10"
            final long dataSize = ((t$109525) * (((long)(localSize3))));
            
            //#line 302 "x10/array/DistArray_Block_3.x10"
            final x10.core.Rail t$109526 = ((x10.core.Rail)(x10.core.Rail.<$S>makeUnsafe($S, ((long)(dataSize)), false)));
            
            //#line 302 "x10/array/DistArray_Block_3.x10"
            data = ((x10.core.Rail)(t$109526));
            
            //#line 303 "x10/array/DistArray_Block_3.x10"
            long i$109636 = low1;
            
            //#line 303 "x10/array/DistArray_Block_3.x10"
            for (;
                 true;
                 ) {
                
                //#line 303 "x10/array/DistArray_Block_3.x10"
                final boolean t$109638 = ((i$109636) <= (((long)(hi1))));
                
                //#line 303 "x10/array/DistArray_Block_3.x10"
                if (!(t$109638)) {
                    
                    //#line 303 "x10/array/DistArray_Block_3.x10"
                    break;
                }
                
                //#line 304 "x10/array/DistArray_Block_3.x10"
                long i$109628 = low2;
                
                //#line 304 "x10/array/DistArray_Block_3.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 304 "x10/array/DistArray_Block_3.x10"
                    final boolean t$109630 = ((i$109628) <= (((long)(hi2))));
                    
                    //#line 304 "x10/array/DistArray_Block_3.x10"
                    if (!(t$109630)) {
                        
                        //#line 304 "x10/array/DistArray_Block_3.x10"
                        break;
                    }
                    
                    //#line 305 "x10/array/DistArray_Block_3.x10"
                    long i$109620 = low3;
                    
                    //#line 305 "x10/array/DistArray_Block_3.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 305 "x10/array/DistArray_Block_3.x10"
                        final boolean t$109622 = ((i$109620) <= (((long)(hi3))));
                        
                        //#line 305 "x10/array/DistArray_Block_3.x10"
                        if (!(t$109622)) {
                            
                            //#line 305 "x10/array/DistArray_Block_3.x10"
                            break;
                        }
                        
                        //#line 306 "x10/array/DistArray_Block_3.x10"
                        final long t$109609 = ((i$109620) - (((long)(low3))));
                        
                        //#line 306 "x10/array/DistArray_Block_3.x10"
                        final long t$109610 = ((i$109628) - (((long)(low2))));
                        
                        //#line 306 "x10/array/DistArray_Block_3.x10"
                        final long t$109611 = ((i$109636) - (((long)(low1))));
                        
                        //#line 306 "x10/array/DistArray_Block_3.x10"
                        final long t$109612 = ((t$109611) * (((long)(localSize2))));
                        
                        //#line 306 "x10/array/DistArray_Block_3.x10"
                        final long t$109613 = ((t$109610) + (((long)(t$109612))));
                        
                        //#line 306 "x10/array/DistArray_Block_3.x10"
                        final long t$109614 = ((localSize3) * (((long)(t$109613))));
                        
                        //#line 306 "x10/array/DistArray_Block_3.x10"
                        final long offset$109615 = ((t$109609) + (((long)(t$109614))));
                        
                        //#line 307 "x10/array/DistArray_Block_3.x10"
                        final $S t$109616 = (($S)((($S)
                                                    ((x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$S>)init).$apply(x10.core.Long.$box(i$109636), x10.rtt.Types.LONG, x10.core.Long.$box(i$109628), x10.rtt.Types.LONG, x10.core.Long.$box(i$109620), x10.rtt.Types.LONG))));
                        
                        //#line 307 "x10/array/DistArray_Block_3.x10"
                        ((x10.core.Rail<$S>)data).$set__1x10$lang$Rail$$T$G((long)(offset$109615), (($S)(t$109616)));
                        
                        //#line 305 "x10/array/DistArray_Block_3.x10"
                        final long t$109619 = ((i$109620) + (((long)(1L))));
                        
                        //#line 305 "x10/array/DistArray_Block_3.x10"
                        i$109620 = t$109619;
                    }
                    
                    //#line 304 "x10/array/DistArray_Block_3.x10"
                    final long t$109627 = ((i$109628) + (((long)(1L))));
                    
                    //#line 304 "x10/array/DistArray_Block_3.x10"
                    i$109628 = t$109627;
                }
                
                //#line 303 "x10/array/DistArray_Block_3.x10"
                final long t$109635 = ((i$109636) + (((long)(1L))));
                
                //#line 303 "x10/array/DistArray_Block_3.x10"
                i$109636 = t$109635;
            }
        }
        
        //#line 312 "x10/array/DistArray_Block_3.x10"
        final x10.array.LocalState_B3 alloc$109125 = ((x10.array.LocalState_B3)(new x10.array.LocalState_B3<$S>((java.lang.System[]) null, $S)));
        
        //#line 312 "x10/array/DistArray_Block_3.x10"
        final long t$109644 = ((m) * (((long)(n))));
        
        //#line 312 "x10/array/DistArray_Block_3.x10"
        final long t$109645 = ((t$109644) * (((long)(p))));
        
        //#line 312 "x10/array/DistArray_Block_3.x10"
        alloc$109125.x10$array$LocalState_B3$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.Rail)(data)), t$109645, ((x10.array.Dist_Block_3)(dist)), (x10.array.LocalState_B3.__1$1x10$array$LocalState_B3$$S$2) null);
        
        //#line 312 "x10/array/DistArray_Block_3.x10"
        return alloc$109125;
    }
    
    
    //#line 275 "x10/array/DistArray_Block_3.x10"
    final public x10.array.LocalState_B3 x10$array$LocalState_B3$$this$x10$array$LocalState_B3() {
        
        //#line 275 "x10/array/DistArray_Block_3.x10"
        return x10.array.LocalState_B3.this;
    }
    
    
    //#line 275 "x10/array/DistArray_Block_3.x10"
    final public void __fieldInitializers_x10_array_LocalState_B3() {
        
    }
}

