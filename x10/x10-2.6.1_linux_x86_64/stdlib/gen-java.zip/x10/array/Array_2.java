package x10.array;


/**
 * Implementation of 2-dimensional Array using row-major ordering.
 */
@x10.runtime.impl.java.X10Generated
final public class Array_2<$T> extends x10.array.Array<$T> implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Array_2> $RTT = 
        x10.rtt.NamedType.<Array_2> make("x10.array.Array_2",
                                         Array_2.class,
                                         1,
                                         new x10.rtt.Type[] {
                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                             x10.rtt.ParameterizedType.make(x10.array.Array.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.Array_2<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array_2 $_obj = new x10.array.Array_2((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        
    }
    
    // constructor just for allocation
    public Array_2(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.Array_2.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
        
    }
    
    // bridge for method abstract public x10.array.Array[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.Array).rank()}, v:T){}:T{self==v}
    public $T $set__1x10$array$Array$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$Array_2$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final Array_2 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __2x10$array$Array_2$$T {}
    // synthetic type for parameter mangling
    public static final class __2$1x10$lang$Long$3x10$lang$Long$3x10$array$Array_2$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __0$1x10$array$Array_2$$T$2 {}
    
    // properties
    
    //#line 25 "x10/array/Array_2.x10"
    /**
         * The number of elements in rank 1 (indexed 0..(numElems_1-1))
         */
    public long numElems_1;
    
    //#line 30 "x10/array/Array_2.x10"
    /**
         * The number of elements in rank 2 (indexed 0..(numElems_2-1)).
         */
    public long numElems_2;
    

    
    
    //#line 36 "x10/array/Array_2.x10"
    /**
     * @return the rank (dimensionality) of the Array
     */
    final public long rank$O() {
        
        //#line 36 "x10/array/Array_2.x10"
        return 2L;
    }
    
    
    //#line 41 "x10/array/Array_2.x10"
    /**
     * Construct a 2-dimensional array with indices [0..m-1][0..n-1] whose elements are zero-initialized.
     */
    // creation method for java code (1-phase java constructor)
    public Array_2(final x10.rtt.Type $T, final long m, final long n) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_2$$init$S(m, n);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_2<$T> x10$array$Array_2$$init$S(final long m, final long n) {
         {
            
            //#line 198 . "x10/array/Array_2.x10"
            boolean t$99186 = ((m) < (((long)(0L))));
            
            //#line 198 . "x10/array/Array_2.x10"
            if (!(t$99186)) {
                
                //#line 198 . "x10/array/Array_2.x10"
                t$99186 = ((n) < (((long)(0L))));
            }
            
            //#line 198 . "x10/array/Array_2.x10"
            if (t$99186) {
                
                //#line 198 . "x10/array/Array_2.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 199 . "x10/array/Array_2.x10"
            final long t$99188 = ((m) * (((long)(n))));
            
            //#line 42 "x10/array/Array_2.x10"
            /*super.*/x10$array$Array$$init$S(t$99188, ((boolean)(true)));
            
            //#line 43 "x10/array/Array_2.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            
        }
        return this;
    }
    
    
    
    //#line 49 "x10/array/Array_2.x10"
    /**
     * Construct a 2-dimensional array with indices [0..m-1][0..n-1] whose elements are initialized to init.
     */
    // creation method for java code (1-phase java constructor)
    public Array_2(final x10.rtt.Type $T, final long m, final long n, final $T init, __2x10$array$Array_2$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_2$$init$S(m, n, init, (x10.array.Array_2.__2x10$array$Array_2$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_2<$T> x10$array$Array_2$$init$S(final long m, final long n, final $T init, __2x10$array$Array_2$$T $dummy) {
         {
            
            //#line 198 . "x10/array/Array_2.x10"
            boolean t$99192 = ((m) < (((long)(0L))));
            
            //#line 198 . "x10/array/Array_2.x10"
            if (!(t$99192)) {
                
                //#line 198 . "x10/array/Array_2.x10"
                t$99192 = ((n) < (((long)(0L))));
            }
            
            //#line 198 . "x10/array/Array_2.x10"
            if (t$99192) {
                
                //#line 198 . "x10/array/Array_2.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 199 . "x10/array/Array_2.x10"
            final long t$99194 = ((m) * (((long)(n))));
            
            //#line 50 "x10/array/Array_2.x10"
            /*super.*/x10$array$Array$$init$S(t$99194, ((boolean)(false)));
            
            //#line 51 "x10/array/Array_2.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            
            
            //#line 52 "x10/array/Array_2.x10"
            final x10.core.Rail t$99073 = ((x10.core.Rail)(this.raw));
            
            //#line 52 "x10/array/Array_2.x10"
            ((x10.core.Rail<$T>)t$99073).fill__0x10$lang$Rail$$T((($T)(init)));
        }
        return this;
    }
    
    
    
    //#line 59 "x10/array/Array_2.x10"
    /**
     * Construct a 2-dimensional array with indices [0..m-1][0..n-1] whose elements are initialized 
     * to the value returned by the init closure for each index.
     */
    // creation method for java code (1-phase java constructor)
    public Array_2(final x10.rtt.Type $T, final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$lang$Long$3x10$array$Array_2$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_2$$init$S(m, n, init, (x10.array.Array_2.__2$1x10$lang$Long$3x10$lang$Long$3x10$array$Array_2$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_2<$T> x10$array$Array_2$$init$S(final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$lang$Long$3x10$array$Array_2$$T$2 $dummy) {
         {
            
            //#line 198 . "x10/array/Array_2.x10"
            boolean t$99219 = ((m) < (((long)(0L))));
            
            //#line 198 . "x10/array/Array_2.x10"
            if (!(t$99219)) {
                
                //#line 198 . "x10/array/Array_2.x10"
                t$99219 = ((n) < (((long)(0L))));
            }
            
            //#line 198 . "x10/array/Array_2.x10"
            if (t$99219) {
                
                //#line 198 . "x10/array/Array_2.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 199 . "x10/array/Array_2.x10"
            final long t$99221 = ((m) * (((long)(n))));
            
            //#line 60 "x10/array/Array_2.x10"
            /*super.*/x10$array$Array$$init$S(t$99221, ((boolean)(false)));
            
            //#line 61 "x10/array/Array_2.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            
            
            //#line 62 "x10/array/Array_2.x10"
            final long i$98601max$99223 = ((m) - (((long)(1L))));
            
            //#line 62 "x10/array/Array_2.x10"
            long i$99214 = 0L;
            
            //#line 62 "x10/array/Array_2.x10"
            for (;
                 true;
                 ) {
                
                //#line 62 "x10/array/Array_2.x10"
                final boolean t$99216 = ((i$99214) <= (((long)(i$98601max$99223))));
                
                //#line 62 "x10/array/Array_2.x10"
                if (!(t$99216)) {
                    
                    //#line 62 "x10/array/Array_2.x10"
                    break;
                }
                
                //#line 63 "x10/array/Array_2.x10"
                final long i$98583max$99210 = ((n) - (((long)(1L))));
                
                //#line 63 "x10/array/Array_2.x10"
                long i$99207 = 0L;
                
                //#line 63 "x10/array/Array_2.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 63 "x10/array/Array_2.x10"
                    final boolean t$99209 = ((i$99207) <= (((long)(i$98583max$99210))));
                    
                    //#line 63 "x10/array/Array_2.x10"
                    if (!(t$99209)) {
                        
                        //#line 63 "x10/array/Array_2.x10"
                        break;
                    }
                    
                    //#line 64 "x10/array/Array_2.x10"
                    final x10.core.Rail t$99196 = ((x10.core.Rail)(this.raw));
                    
                    //#line 64 "x10/array/Array_2.x10"
                    final x10.array.Array_2 this$99197 = ((x10.array.Array_2)(this));
                    
                    //#line 140 . "x10/array/Array_2.x10"
                    final long t$99200 = ((x10.array.Array_2<$T>)this$99197).numElems_2;
                    
                    //#line 140 . "x10/array/Array_2.x10"
                    final long t$99201 = ((i$99214) * (((long)(t$99200))));
                    
                    //#line 140 . "x10/array/Array_2.x10"
                    final long t$99202 = ((i$99207) + (((long)(t$99201))));
                    
                    //#line 64 "x10/array/Array_2.x10"
                    final $T t$99203 = (($T)((($T)
                                               ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)init).$apply(x10.core.Long.$box(i$99214), x10.rtt.Types.LONG, x10.core.Long.$box(i$99207), x10.rtt.Types.LONG))));
                    
                    //#line 64 "x10/array/Array_2.x10"
                    ((x10.core.Rail<$T>)t$99196).$set__1x10$lang$Rail$$T$G((long)(t$99202), (($T)(t$99203)));
                    
                    //#line 63 "x10/array/Array_2.x10"
                    final long t$99206 = ((i$99207) + (((long)(1L))));
                    
                    //#line 63 "x10/array/Array_2.x10"
                    i$99207 = t$99206;
                }
                
                //#line 62 "x10/array/Array_2.x10"
                final long t$99213 = ((i$99214) + (((long)(1L))));
                
                //#line 62 "x10/array/Array_2.x10"
                i$99214 = t$99213;
            }
        }
        return this;
    }
    
    
    
    //#line 73 "x10/array/Array_2.x10"
    /**
     * Construct a new 2-dimensional array by copying all elements of src
     * @param src The source array to copy
     */
    // creation method for java code (1-phase java constructor)
    public Array_2(final x10.rtt.Type $T, final x10.array.Array_2<$T> src, __0$1x10$array$Array_2$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_2$$init$S(src, (x10.array.Array_2.__0$1x10$array$Array_2$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_2<$T> x10$array$Array_2$$init$S(final x10.array.Array_2<$T> src, __0$1x10$array$Array_2$$T$2 $dummy) {
         {
            
            //#line 74 "x10/array/Array_2.x10"
            final x10.array.Array this$98674 = ((x10.array.Array)(this));
            
            //#line 74 "x10/array/Array_2.x10"
            final x10.core.Rail t$99092 = ((x10.core.Rail)(((x10.array.Array<$T>)src).raw));
            
            //#line 74 "x10/array/Array_2.x10"
            final x10.core.Rail r$98673 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((x10.core.Rail)(t$99092)), (x10.core.Rail.__0$1x10$lang$Rail$$T$2) null)));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$99224 = ((x10.core.Rail<$T>)r$98673).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$98674).size = t$99224;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$98674).raw = ((x10.core.Rail)(r$98673));
            
            //#line 75 "x10/array/Array_2.x10"
            final long t$99225 = ((x10.array.Array_2<$T>)src).numElems_1;
            
            //#line 75 "x10/array/Array_2.x10"
            final long t$99226 = ((x10.array.Array_2<$T>)src).numElems_2;
            
            //#line 75 "x10/array/Array_2.x10"
            this.numElems_1 = t$99225;
            this.numElems_2 = t$99226;
            
        }
        return this;
    }
    
    
    
    //#line 79 "x10/array/Array_2.x10"
    // creation method for java code (1-phase java constructor)
    public Array_2(final x10.rtt.Type $T, final x10.core.Rail<$T> r, final long m, final long n, __0$1x10$array$Array_2$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_2$$init$S(r, m, n, (x10.array.Array_2.__0$1x10$array$Array_2$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_2<$T> x10$array$Array_2$$init$S(final x10.core.Rail<$T> r, final long m, final long n, __0$1x10$array$Array_2$$T$2 $dummy) {
         {
            
            //#line 80 "x10/array/Array_2.x10"
            final x10.array.Array this$98680 = ((x10.array.Array)(this));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$99228 = ((x10.core.Rail<$T>)r).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$98680).size = t$99228;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$98680).raw = ((x10.core.Rail)(r));
            
            //#line 81 "x10/array/Array_2.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            
        }
        return this;
    }
    
    
    
    //#line 87 "x10/array/Array_2.x10"
    /**
     * Construct an Array_2 view over an existing Rail
     */
    public static <$T>x10.array.Array_2 makeView__0$1x10$array$Array_2$$T$2(final x10.rtt.Type $T, final x10.core.Rail<$T> r, final long m, final long n) {
        
        //#line 88 "x10/array/Array_2.x10"
        final long size = ((m) * (((long)(n))));
        
        //#line 89 "x10/array/Array_2.x10"
        final long t$99097 = ((x10.core.Rail<$T>)r).size;
        
        //#line 89 "x10/array/Array_2.x10"
        final boolean t$99105 = ((long) size) != ((long) t$99097);
        
        //#line 89 "x10/array/Array_2.x10"
        if (t$99105) {
            
            //#line 89 "x10/array/Array_2.x10"
            final java.lang.String t$99098 = (("size mismatch: ") + ((x10.core.Long.$box(m))));
            
            //#line 89 "x10/array/Array_2.x10"
            final java.lang.String t$99099 = ((t$99098) + (" * "));
            
            //#line 89 "x10/array/Array_2.x10"
            final java.lang.String t$99100 = ((t$99099) + ((x10.core.Long.$box(n))));
            
            //#line 89 "x10/array/Array_2.x10"
            final java.lang.String t$99101 = ((t$99100) + (" != "));
            
            //#line 89 "x10/array/Array_2.x10"
            final long t$99102 = ((x10.core.Rail<$T>)r).size;
            
            //#line 89 "x10/array/Array_2.x10"
            final java.lang.String t$99103 = ((t$99101) + ((x10.core.Long.$box(t$99102))));
            
            //#line 89 "x10/array/Array_2.x10"
            final x10.lang.IllegalOperationException t$99104 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$99103)));
            
            //#line 89 "x10/array/Array_2.x10"
            throw t$99104;
        }
        
        //#line 90 "x10/array/Array_2.x10"
        final x10.array.Array_2 alloc$98580 = ((x10.array.Array_2)(new x10.array.Array_2<$T>((java.lang.System[]) null, $T)));
        
        //#line 90 "x10/array/Array_2.x10"
        alloc$98580.x10$array$Array_2$$init$S(((x10.core.Rail)(r)), ((long)(m)), ((long)(n)), (x10.array.Array_2.__0$1x10$array$Array_2$$T$2) null);
        
        //#line 90 "x10/array/Array_2.x10"
        return alloc$98580;
    }
    
    
    //#line 99 "x10/array/Array_2.x10"
    /**
     * Return the string representation of this array.
     * 
     * @return the string representation of this array.
     */
    public java.lang.String toString() {
        
        //#line 100 "x10/array/Array_2.x10"
        final java.lang.String t$99106 = this.toString((long)(10L));
        
        //#line 100 "x10/array/Array_2.x10"
        return t$99106;
    }
    
    
    //#line 109 "x10/array/Array_2.x10"
    /**
     * Return the string representation of this array.
     *
     * @param limit maximum number of elements to print
     * @return the string representation of this array.
     */
    public java.lang.String toString(final long limit) {
        
        //#line 110 "x10/array/Array_2.x10"
        final x10.util.StringBuilder sb = ((x10.util.StringBuilder)(new x10.util.StringBuilder((java.lang.System[]) null)));
        
        //#line 110 "x10/array/Array_2.x10"
        sb.x10$util$StringBuilder$$init$S();
        
        //#line 111 "x10/array/Array_2.x10"
        sb.add(((java.lang.String)("[")));
        
        //#line 112 "x10/array/Array_2.x10"
        long printed = 0L;
        
        //#line 113 "x10/array/Array_2.x10"
        final long t$99266 = this.numElems_1;
        
        //#line 113 "x10/array/Array_2.x10"
        final long i$98637max$99267 = ((t$99266) - (((long)(1L))));
        
        //#line 113 "x10/array/Array_2.x10"
        long i$99262 = 0L;
        
        //#line 113 "x10/array/Array_2.x10"
        outer$99263: 
        //#line 113 "x10/array/Array_2.x10"
        for (;
             true;
             ) {
            
            //#line 113 "x10/array/Array_2.x10"
            final boolean t$99265 = ((i$99262) <= (((long)(i$98637max$99267))));
            
            //#line 113 "x10/array/Array_2.x10"
            if (!(t$99265)) {
                
                //#line 113 "x10/array/Array_2.x10"
                break;
            }
            
            //#line 114 "x10/array/Array_2.x10"
            final long t$99257 = this.numElems_2;
            
            //#line 114 "x10/array/Array_2.x10"
            final long i$98619max$99258 = ((t$99257) - (((long)(1L))));
            
            //#line 114 "x10/array/Array_2.x10"
            long i$99254 = 0L;
            
            //#line 114 "x10/array/Array_2.x10"
            for (;
                 true;
                 ) {
                
                //#line 114 "x10/array/Array_2.x10"
                final boolean t$99256 = ((i$99254) <= (((long)(i$98619max$99258))));
                
                //#line 114 "x10/array/Array_2.x10"
                if (!(t$99256)) {
                    
                    //#line 114 "x10/array/Array_2.x10"
                    break;
                }
                
                //#line 115 "x10/array/Array_2.x10"
                final boolean t$99230 = ((long) i$99254) != ((long) 0L);
                
                //#line 115 "x10/array/Array_2.x10"
                if (t$99230) {
                    
                    //#line 115 "x10/array/Array_2.x10"
                    sb.add(((java.lang.String)(", ")));
                }
                
                //#line 116 "x10/array/Array_2.x10"
                final x10.array.Array_2 this$99231 = ((x10.array.Array_2)(this));
                
                //#line 152 . "x10/array/Array_2.x10"
                boolean t$99234 = ((i$99262) < (((long)(0L))));
                
                //#line 152 . "x10/array/Array_2.x10"
                if (!(t$99234)) {
                    
                    //#line 152 . "x10/array/Array_2.x10"
                    final long t$99235 = ((x10.array.Array_2<$T>)this$99231).numElems_1;
                    
                    //#line 152 . "x10/array/Array_2.x10"
                    t$99234 = ((i$99262) >= (((long)(t$99235))));
                }
                
                //#line 152 . "x10/array/Array_2.x10"
                boolean t$99236 = t$99234;
                
                //#line 152 . "x10/array/Array_2.x10"
                if (!(t$99234)) {
                    
                    //#line 152 . "x10/array/Array_2.x10"
                    t$99236 = ((i$99254) < (((long)(0L))));
                }
                
                //#line 152 . "x10/array/Array_2.x10"
                boolean t$99237 = t$99236;
                
                //#line 152 . "x10/array/Array_2.x10"
                if (!(t$99236)) {
                    
                    //#line 153 . "x10/array/Array_2.x10"
                    final long t$99238 = ((x10.array.Array_2<$T>)this$99231).numElems_2;
                    
                    //#line 152 . "x10/array/Array_2.x10"
                    t$99237 = ((i$99254) >= (((long)(t$99238))));
                }
                
                //#line 152 . "x10/array/Array_2.x10"
                if (t$99237) {
                    
                    //#line 154 . "x10/array/Array_2.x10"
                    x10.array.Array.raiseBoundsError((long)(i$99262), (long)(i$99254));
                }
                
                //#line 156 . "x10/array/Array_2.x10"
                final x10.core.Rail r$99240 = ((x10.core.Rail)(((x10.array.Array<$T>)this$99231).raw));
                
                //#line 140 .. "x10/array/Array_2.x10"
                final long t$99243 = ((x10.array.Array_2<$T>)this$99231).numElems_2;
                
                //#line 140 .. "x10/array/Array_2.x10"
                final long t$99244 = ((i$99262) * (((long)(t$99243))));
                
                //#line 156 . "x10/array/Array_2.x10"
                final long i$99245 = ((i$99254) + (((long)(t$99244))));
                
                //#line 38 .. "x10/lang/Unsafe.x10"
                final $T t$99246 = (($T)(((x10.core.Rail<$T>)r$99240).$apply$G((long)(i$99245))));
                
                //#line 116 "x10/array/Array_2.x10"
                sb.add(((java.lang.Object)(t$99246)));
                
                //#line 117 "x10/array/Array_2.x10"
                final long t$99248 = ((printed) + (((long)(1L))));
                
                //#line 117 "x10/array/Array_2.x10"
                final long t$99249 = printed = t$99248;
                
                //#line 117 "x10/array/Array_2.x10"
                final boolean t$99250 = ((t$99249) > (((long)(limit))));
                
                //#line 117 "x10/array/Array_2.x10"
                if (t$99250) {
                    
                    //#line 117 "x10/array/Array_2.x10"
                    break outer$99263;
                }
                
                //#line 114 "x10/array/Array_2.x10"
                final long t$99253 = ((i$99254) + (((long)(1L))));
                
                //#line 114 "x10/array/Array_2.x10"
                i$99254 = t$99253;
            }
            
            //#line 119 "x10/array/Array_2.x10"
            sb.add(((java.lang.String)("; ")));
            
            //#line 113 "x10/array/Array_2.x10"
            final long t$99261 = ((i$99262) + (((long)(1L))));
            
            //#line 113 "x10/array/Array_2.x10"
            i$99262 = t$99261;
        }
        
        //#line 121 "x10/array/Array_2.x10"
        final long t$99133 = this.size;
        
        //#line 121 "x10/array/Array_2.x10"
        final boolean t$99138 = ((limit) < (((long)(t$99133))));
        
        //#line 121 "x10/array/Array_2.x10"
        if (t$99138) {
            
            //#line 122 "x10/array/Array_2.x10"
            final long t$99134 = this.size;
            
            //#line 122 "x10/array/Array_2.x10"
            final long t$99135 = ((t$99134) - (((long)(limit))));
            
            //#line 122 "x10/array/Array_2.x10"
            final java.lang.String t$99136 = (("...(omitted ") + ((x10.core.Long.$box(t$99135))));
            
            //#line 122 "x10/array/Array_2.x10"
            final java.lang.String t$99137 = ((t$99136) + (" elements)"));
            
            //#line 122 "x10/array/Array_2.x10"
            sb.add(((java.lang.String)(t$99137)));
        }
        
        //#line 124 "x10/array/Array_2.x10"
        sb.add(((java.lang.String)("]")));
        
        //#line 125 "x10/array/Array_2.x10"
        final java.lang.String t$99139 = sb.toString();
        
        //#line 125 "x10/array/Array_2.x10"
        return t$99139;
    }
    
    
    //#line 131 "x10/array/Array_2.x10"
    /**
     * @return an IterationSpace containing all valid Points for indexing this Array.
     */
    public x10.array.DenseIterationSpace_2 indices() {
        
        //#line 132 "x10/array/Array_2.x10"
        final x10.array.DenseIterationSpace_2 alloc$98581 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 132 "x10/array/Array_2.x10"
        final long t$99268 = this.numElems_1;
        
        //#line 132 "x10/array/Array_2.x10"
        final long t$99269 = ((t$99268) - (((long)(1L))));
        
        //#line 132 "x10/array/Array_2.x10"
        final long t$99270 = this.numElems_2;
        
        //#line 132 "x10/array/Array_2.x10"
        final long t$99271 = ((t$99270) - (((long)(1L))));
        
        //#line 132 "x10/array/Array_2.x10"
        alloc$98581.x10$array$DenseIterationSpace_2$$init$S(((long)(0L)), ((long)(0L)), t$99269, t$99271);
        
        //#line 132 "x10/array/Array_2.x10"
        return alloc$98581;
    }
    
    
    //#line 139 "x10/array/Array_2.x10"
    /**
     * Map a 2-D (i,j) index into a 1-D index into the backing Rail
     * returned by raw(). Uses row-major order.
     */
    public long offset$O(final long i, final long j) {
        
        //#line 140 "x10/array/Array_2.x10"
        final long t$99144 = this.numElems_2;
        
        //#line 140 "x10/array/Array_2.x10"
        final long t$99145 = ((i) * (((long)(t$99144))));
        
        //#line 140 "x10/array/Array_2.x10"
        final long t$99146 = ((j) + (((long)(t$99145))));
        
        //#line 140 "x10/array/Array_2.x10"
        return t$99146;
    }
    
    
    //#line 151 "x10/array/Array_2.x10"
    /**
     * Return the element of this array corresponding to the given pair of indices.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the element of this array corresponding to the given pair of indices.
     * @see #set(T, Long, Long)
     */
    public $T $apply$G(final long i, final long j) {
        
        //#line 152 "x10/array/Array_2.x10"
        boolean t$99148 = ((i) < (((long)(0L))));
        
        //#line 152 "x10/array/Array_2.x10"
        if (!(t$99148)) {
            
            //#line 152 "x10/array/Array_2.x10"
            final long t$99147 = this.numElems_1;
            
            //#line 152 "x10/array/Array_2.x10"
            t$99148 = ((i) >= (((long)(t$99147))));
        }
        
        //#line 152 "x10/array/Array_2.x10"
        boolean t$99149 = t$99148;
        
        //#line 152 "x10/array/Array_2.x10"
        if (!(t$99148)) {
            
            //#line 152 "x10/array/Array_2.x10"
            t$99149 = ((j) < (((long)(0L))));
        }
        
        //#line 152 "x10/array/Array_2.x10"
        boolean t$99151 = t$99149;
        
        //#line 152 "x10/array/Array_2.x10"
        if (!(t$99149)) {
            
            //#line 153 "x10/array/Array_2.x10"
            final long t$99150 = this.numElems_2;
            
            //#line 152 "x10/array/Array_2.x10"
            t$99151 = ((j) >= (((long)(t$99150))));
        }
        
        //#line 152 "x10/array/Array_2.x10"
        if (t$99151) {
            
            //#line 154 "x10/array/Array_2.x10"
            x10.array.Array.raiseBoundsError((long)(i), (long)(j));
        }
        
        //#line 156 "x10/array/Array_2.x10"
        final x10.core.Rail r$99034 = ((x10.core.Rail)(this.raw));
        
        //#line 156 "x10/array/Array_2.x10"
        final x10.array.Array_2 this$99032 = ((x10.array.Array_2)(this));
        
        //#line 140 . "x10/array/Array_2.x10"
        final long t$99153 = ((x10.array.Array_2<$T>)this$99032).numElems_2;
        
        //#line 140 . "x10/array/Array_2.x10"
        final long t$99154 = ((i) * (((long)(t$99153))));
        
        //#line 156 "x10/array/Array_2.x10"
        final long i$99035 = ((j) + (((long)(t$99154))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$99155 = (($T)(((x10.core.Rail<$T>)r$99034).$apply$G((long)(i$99035))));
        
        //#line 156 "x10/array/Array_2.x10"
        return t$99155;
    }
    
    
    //#line 166 "x10/array/Array_2.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point p) {
        
        //#line 166 "x10/array/Array_2.x10"
        final x10.array.Array_2 this$99039 = ((x10.array.Array_2)(this));
        
        //#line 166 "x10/array/Array_2.x10"
        final long i$99037 = p.$apply$O((long)(0L));
        
        //#line 166 "x10/array/Array_2.x10"
        final long j$99038 = p.$apply$O((long)(1L));
        
        //#line 152 . "x10/array/Array_2.x10"
        boolean t$99157 = ((i$99037) < (((long)(0L))));
        
        //#line 152 . "x10/array/Array_2.x10"
        if (!(t$99157)) {
            
            //#line 152 . "x10/array/Array_2.x10"
            final long t$99156 = ((x10.array.Array_2<$T>)this$99039).numElems_1;
            
            //#line 152 . "x10/array/Array_2.x10"
            t$99157 = ((i$99037) >= (((long)(t$99156))));
        }
        
        //#line 152 . "x10/array/Array_2.x10"
        boolean t$99158 = t$99157;
        
        //#line 152 . "x10/array/Array_2.x10"
        if (!(t$99157)) {
            
            //#line 152 . "x10/array/Array_2.x10"
            t$99158 = ((j$99038) < (((long)(0L))));
        }
        
        //#line 152 . "x10/array/Array_2.x10"
        boolean t$99160 = t$99158;
        
        //#line 152 . "x10/array/Array_2.x10"
        if (!(t$99158)) {
            
            //#line 153 . "x10/array/Array_2.x10"
            final long t$99159 = ((x10.array.Array_2<$T>)this$99039).numElems_2;
            
            //#line 152 . "x10/array/Array_2.x10"
            t$99160 = ((j$99038) >= (((long)(t$99159))));
        }
        
        //#line 152 . "x10/array/Array_2.x10"
        if (t$99160) {
            
            //#line 154 . "x10/array/Array_2.x10"
            x10.array.Array.raiseBoundsError((long)(i$99037), (long)(j$99038));
        }
        
        //#line 156 . "x10/array/Array_2.x10"
        final x10.core.Rail r$99044 = ((x10.core.Rail)(((x10.array.Array<$T>)this$99039).raw));
        
        //#line 140 .. "x10/array/Array_2.x10"
        final long t$99162 = ((x10.array.Array_2<$T>)this$99039).numElems_2;
        
        //#line 140 .. "x10/array/Array_2.x10"
        final long t$99163 = ((i$99037) * (((long)(t$99162))));
        
        //#line 156 . "x10/array/Array_2.x10"
        final long i$99045 = ((j$99038) + (((long)(t$99163))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$99164 = (($T)(((x10.core.Rail<$T>)r$99044).$apply$G((long)(i$99045))));
        
        //#line 166 "x10/array/Array_2.x10"
        return t$99164;
    }
    
    
    //#line 178 "x10/array/Array_2.x10"
    /**
     * Set the element of this array corresponding to the given pair of indices to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the new value of the element of this array corresponding to the given pair of indices.
     * @see #operator(Long, Long)
     */
    public $T $set__2x10$array$Array_2$$T$G(final long i, final long j, final $T v) {
        
        //#line 179 "x10/array/Array_2.x10"
        boolean t$99166 = ((i) < (((long)(0L))));
        
        //#line 179 "x10/array/Array_2.x10"
        if (!(t$99166)) {
            
            //#line 179 "x10/array/Array_2.x10"
            final long t$99165 = this.numElems_1;
            
            //#line 179 "x10/array/Array_2.x10"
            t$99166 = ((i) >= (((long)(t$99165))));
        }
        
        //#line 179 "x10/array/Array_2.x10"
        boolean t$99167 = t$99166;
        
        //#line 179 "x10/array/Array_2.x10"
        if (!(t$99166)) {
            
            //#line 179 "x10/array/Array_2.x10"
            t$99167 = ((j) < (((long)(0L))));
        }
        
        //#line 179 "x10/array/Array_2.x10"
        boolean t$99169 = t$99167;
        
        //#line 179 "x10/array/Array_2.x10"
        if (!(t$99167)) {
            
            //#line 180 "x10/array/Array_2.x10"
            final long t$99168 = this.numElems_2;
            
            //#line 179 "x10/array/Array_2.x10"
            t$99169 = ((j) >= (((long)(t$99168))));
        }
        
        //#line 179 "x10/array/Array_2.x10"
        if (t$99169) {
            
            //#line 181 "x10/array/Array_2.x10"
            x10.array.Array.raiseBoundsError((long)(i), (long)(j));
        }
        
        //#line 183 "x10/array/Array_2.x10"
        final x10.core.Rail r$99051 = ((x10.core.Rail)(this.raw));
        
        //#line 183 "x10/array/Array_2.x10"
        final x10.array.Array_2 this$99049 = ((x10.array.Array_2)(this));
        
        //#line 140 . "x10/array/Array_2.x10"
        final long t$99171 = ((x10.array.Array_2<$T>)this$99049).numElems_2;
        
        //#line 140 . "x10/array/Array_2.x10"
        final long t$99172 = ((i) * (((long)(t$99171))));
        
        //#line 183 "x10/array/Array_2.x10"
        final long i$99052 = ((j) + (((long)(t$99172))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$99051).$set__1x10$lang$Rail$$T$G((long)(i$99052), (($T)(v)));
        
        //#line 183 "x10/array/Array_2.x10"
        return (($T)
                 v);
    }
    
    
    //#line 195 "x10/array/Array_2.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    public $T $set__1x10$array$Array_2$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 195 "x10/array/Array_2.x10"
        final x10.array.Array_2 this$99058 = ((x10.array.Array_2)(this));
        
        //#line 195 "x10/array/Array_2.x10"
        final long i$99055 = p.$apply$O((long)(0L));
        
        //#line 195 "x10/array/Array_2.x10"
        final long j$99056 = p.$apply$O((long)(1L));
        
        //#line 179 . "x10/array/Array_2.x10"
        boolean t$99174 = ((i$99055) < (((long)(0L))));
        
        //#line 179 . "x10/array/Array_2.x10"
        if (!(t$99174)) {
            
            //#line 179 . "x10/array/Array_2.x10"
            final long t$99173 = ((x10.array.Array_2<$T>)this$99058).numElems_1;
            
            //#line 179 . "x10/array/Array_2.x10"
            t$99174 = ((i$99055) >= (((long)(t$99173))));
        }
        
        //#line 179 . "x10/array/Array_2.x10"
        boolean t$99175 = t$99174;
        
        //#line 179 . "x10/array/Array_2.x10"
        if (!(t$99174)) {
            
            //#line 179 . "x10/array/Array_2.x10"
            t$99175 = ((j$99056) < (((long)(0L))));
        }
        
        //#line 179 . "x10/array/Array_2.x10"
        boolean t$99177 = t$99175;
        
        //#line 179 . "x10/array/Array_2.x10"
        if (!(t$99175)) {
            
            //#line 180 . "x10/array/Array_2.x10"
            final long t$99176 = ((x10.array.Array_2<$T>)this$99058).numElems_2;
            
            //#line 179 . "x10/array/Array_2.x10"
            t$99177 = ((j$99056) >= (((long)(t$99176))));
        }
        
        //#line 179 . "x10/array/Array_2.x10"
        if (t$99177) {
            
            //#line 181 . "x10/array/Array_2.x10"
            x10.array.Array.raiseBoundsError((long)(i$99055), (long)(j$99056));
        }
        
        //#line 183 . "x10/array/Array_2.x10"
        final x10.core.Rail r$99063 = ((x10.core.Rail)(((x10.array.Array<$T>)this$99058).raw));
        
        //#line 140 .. "x10/array/Array_2.x10"
        final long t$99179 = ((x10.array.Array_2<$T>)this$99058).numElems_2;
        
        //#line 140 .. "x10/array/Array_2.x10"
        final long t$99180 = ((i$99055) * (((long)(t$99179))));
        
        //#line 183 . "x10/array/Array_2.x10"
        final long i$99064 = ((j$99056) + (((long)(t$99180))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$99063).$set__1x10$lang$Rail$$T$G((long)(i$99064), (($T)(v)));
        
        //#line 195 "x10/array/Array_2.x10"
        return (($T)
                 v);
    }
    
    
    //#line 197 "x10/array/Array_2.x10"
    private static long validateSize$O(final long m, final long n) {
        
        //#line 198 "x10/array/Array_2.x10"
        boolean t$99181 = ((m) < (((long)(0L))));
        
        //#line 198 "x10/array/Array_2.x10"
        if (!(t$99181)) {
            
            //#line 198 "x10/array/Array_2.x10"
            t$99181 = ((n) < (((long)(0L))));
        }
        
        //#line 198 "x10/array/Array_2.x10"
        if (t$99181) {
            
            //#line 198 "x10/array/Array_2.x10"
            x10.array.Array.raiseNegativeArraySizeException();
        }
        
        //#line 199 "x10/array/Array_2.x10"
        final long t$99183 = ((m) * (((long)(n))));
        
        //#line 199 "x10/array/Array_2.x10"
        return t$99183;
    }
    
    public static long validateSize$P$O(final long m, final long n) {
        return x10.array.Array_2.validateSize$O((long)(m), (long)(n));
    }
    
    
    //#line 21 "x10/array/Array_2.x10"
    final public x10.array.Array_2 x10$array$Array_2$$this$x10$array$Array_2() {
        
        //#line 21 "x10/array/Array_2.x10"
        return x10.array.Array_2.this;
    }
    
    
    //#line 21 "x10/array/Array_2.x10"
    final public void __fieldInitializers_x10_array_Array_2() {
        
    }
}

